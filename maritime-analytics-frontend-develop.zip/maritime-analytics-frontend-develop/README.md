# Meridia

**Meridia** is a maritime intelligence platform that combines **AI-powered chat analytics (MeridiaIQ)** with **real-time map visualization** to deliver actionable insights across ports, vessels, and zones. Built with **React + TypeScript + Vite**, it enables maritime professionals to query vessel movements, monitor port congestion, detect anomalies like AIS gaps and positional discrepancies, and track Ship-to-Ship (STS) events — all through a conversational interface backed by live geospatial data.

## 🚀 Features

- **MeridiaIQ (AI Chat Assistant)**: Natural language queries for maritime data analysis with real-time map visualization, multi-session support, and WebSocket-based live responses.
- **Interactive Map Visualization**: Mapbox GL and Leaflet-powered maps with real-time vessel tracking, nautical charts, custom zone drawing tools, and position type filtering (AIS, LRIT, Blended).
- **Port Analytics**: Port congestion metrics, utilization trends, inbound vessel predictions, and historical event analysis with time-domain filtering.
- **Vessel Analytics**: Vessel event tracking including AIS gaps, positional discrepancies, STS events, zone/port events, and Port State Control records.
- **Zone Management**: Monitor zone entry/exit events, create custom maritime zones via map-based UI, and analyze zone-level vessel activity.
- **Library**: Searchable, bookmarkable catalog of ports, zones, and vessels for quick access and reference.
- **Real-Time Updates**: STOMP over WebSocket for live vessel position streaming, notifications, and chat response processing.
- **Dark Mode Support**: System-aware theming with light, dark, and auto modes via Flowbite and Tailwind CSS.
- **Modern Frontend Stack**: React 18, TypeScript strict mode, Vite, Zustand, AG Grid/Charts Enterprise, and React Hook Form.
- **Strong Coding Standards**: ESLint, Prettier, TypeScript strict mode, and Vitest for maintainability and test coverage.

---

## 🏗️ Getting Started

### 📌 Prerequisites

Ensure you have the following installed:

- **Git**
- **Node.js 20, 22, or 24+**
- **npm (comes with node)**

### 🛠️ Installation

1. Clone the repository:

   ```sh
   git clone https://github.com/Pole-Star-Space-Applications-USA/maritime-analytics-frontend
   cd maritime-analytics-frontend
   ```

2. Install Dependencies:

   ```sh
   npm install
   ```

   This automatically installs git pre-commit and pre-push hooks via the `prepare` script.

3. Start the development server:
   ```sh
   npm run dev
   ```
4. To take new updates:
   ```sh
   git pull
   ```
   The application will be available at http://localhost:8082/.

### For Developers

| Command             | Description                                             |
| ------------------- | ------------------------------------------------------- |
| `npm run dev`       | Starts the development server (Vite).                   |
| `npm run build`     | Builds the project using TypeScript and Vite.           |
| `npm run preview`   | Runs a local preview of the built application.          |
| `npm run lint`      | Runs ESLint to enforce coding standards.                |
| `npm run typecheck` | Checks TypeScript types.                                |
| `npm run format`    | Formats the code using Prettier.                        |
| `npm run fix`       | Fixes linting and formatting issues.                    |
| `npm run check`     | Runs linting, type checking, and formatting validation. |

### Pre-Commit Hooks

This project uses **Husky** and **lint-staged** to enforce code quality standards automatically before each commit. The hooks **validate and block** on issues without auto-fixing, ensuring developers are aware of code quality problems and learn from them.

#### How It Works

The pre-commit hook runs `lint-staged`, which validates (but does NOT auto-fix) staged files:

- **TypeScript/TSX files**:
  - `eslint --max-warnings 0` — checks for lint errors, blocks if found
  - `prettier --check` — checks formatting, blocks if not formatted
  - `tsc --noEmit` — checks for TypeScript type errors
- **JSON/CSS/Markdown files**:
  - `prettier --check` — checks formatting, blocks if not formatted

#### Recommended Workflow

When pre-commit hook blocks on issues:

```bash
# 1. Pre-commit hook blocks with errors
git commit -m "your message"
# Error: "3 lint issues found, please fix them"

# 2. Run fixes manually to see what needs to be fixed
npm run fix

# 3. Review the changes
git diff

# 4. Stage the fixed changes
git add <files>

# 5. Review staged changes before committing
git diff --staged

# 6. Commit again (should succeed)
git commit -m "your message"
```

#### Key Benefits

- ✅ **Full Transparency** — Developers see every issue in their code
- ✅ **Learning** — Team members understand code quality standards
- ✅ **Accountability** — Commits accurately represent the actual code state
- ✅ **Agent Visibility** — When using agents, changes are clearly visible for review
- ✅ **Team Discipline** — Encourages better coding practices across the team

#### Installation

Hooks are automatically installed when you run `npm install` via the `prepare` script. No manual setup is required.

#### Bypassing Hooks (Not Recommended)

If you need to bypass the pre-commit hook for a specific commit, you can use:

```bash
git commit --no-verify
```

**Note:** This is only recommended for emergency hotfixes and should be avoided in normal development.

# Branching Strategy

A clear and consistent branching strategy to support **Test**, **Staging**, and **Production** environments for a customer-facing application.

---

## Branches

| Branch    | Purpose                        | Environment    |
| --------- | ------------------------------ | -------------- |
| `main`    | Stable, production-ready code  | **Production** |
| `stage`   | Pre-release UAT/testing branch | **Staging**    |
| `develop` | Active development integration | **Test**       |

- **`main`**: Contains production-ready, fully tested code. Protected and deployed to the live environment.
- **`stage`**: Used for final integration, QA, and client review before releasing to production.
- **`develop`**: The working branch for daily development and initial QA testing.

---

## Supporting Branches

| Type    | Naming Convention   | Purpose                                         |
| ------- | ------------------- | ----------------------------------------------- |
| Feature | `feature/{jira-id}` | New feature development                         |
| Bugfix  | `bugfix/{jira-id}`  | Bug fixes before release                        |
| Hotfix  | `hotfix/{jira-id}`  | Emergency patches directly to `main`            |
| Chore   | `chore/{jira-id}`   | Non-functional updates (e.g., tooling, cleanup) |

> All branches must link to a JIRA ticket for tracking.

---

## Branch Workflow

### Developer Flow

```bash
# Create a new feature branch
git checkout develop
git pull origin develop
git checkout -b feature/OP-XXXX
git push origin feature/OP-XXXX
```

1. Work in small commits, push regularly.
2. When feature is complete:
   - Push changes
   - Create a Pull Request (PR) to `develop`
3. QA validates `develop` in the **Test** environment.
4. Once stable, raise a **PR from `develop` → `stage`**.
5. After UAT in staging, raise a **PR from `stage` → `main`**.
6. Tag the release and deploy to production.

---

## Environment Mapping

| Environment | Branch    | Managed By | Used For                               |
| ----------- | --------- | ---------- | -------------------------------------- |
| Test        | `develop` | Dev        | In-progress feature integration        |
| Staging     | `stage`   | QA/PM      | UAT, client approval, regression tests |
| Production  | `main`    | DevOps     | Live app for customers                 |

---

## Pull Request (PR) Process

### Guidelines

- Keep PRs small and focused.
- Reference a valid JIRA ticket.
- Include a clear description and screenshots for UI-related changes.
- Ensure `npm run check`, tests, and linting pass.
- Tag at least one reviewer.

### PR Title Format

```text
[Feature-id] : Implement new login screen
[Bugfix-id] : Fix modal closing issue
[Chore-id] : Upgrade dependencies
```

### PR Description Template

```markdown
### Description

Brief description of the change and purpose.

### Linked Ticket

JIRA-XXXX

### Screenshots

[Attach screenshots if applicable]

### Testing Notes

- [ ] Scenario 1 passed
- [ ] Scenario 2 passed
```

---

## QA & UAT Flow

### QA

- Validate all features in `develop` (Test environment).
- Report bugs or confirm readiness for staging.
- Approve PR from `develop` → `stage`.

### UAT / PM

- Review `staging` for regression/UAT.
- Approve PR from `stage` → `main` when sign-off is complete.
- Tag production release after merging to `main`.

---

## Deployment Workflow

| Branch    | Deploys To       | Trigger                                            |
| --------- | ---------------- | -------------------------------------------------- |
| `develop` | Test Environment | On PR merge                                        |
| `stage`   | Staging Env      | On PR merge + Deployment Approval                  |
| `main`    | Production       | On PR merge + Deployment Approval + Release Tagged |

### Staging Deployment Steps

1. Create a PR from `develop` → `stage`
2. Add reviewers (QA lead, PM)
3. Confirm checklist items in PR
4. Merge to `stage` → CI/CD auto-deploys to staging environment

### Production Deployment Steps

1. After stage approval, raise a PR from `stage` → `main`
2. Tag the release (e.g., `v1.4.0`)
3. CI/CD deploys `main` with tag to production

---

## Commit Convention

```bash
git commit -m "OP-XXXX : Add login screen with validation"
```

- Start with the JIRA ID.
- Use a clear, action-oriented message.
- Keep commits focused and descriptive.

---

## Summary Cheat Sheet

| Branch      | Env        | Description                       |
| ----------- | ---------- | --------------------------------- |
| `main`      | Production | Stable, customer-facing code      |
| `stage`     | Staging    | Pre-release QA/UAT                |
| `develop`   | Test       | Daily development and integration |
| `feature/*` | —          | In-progress features              |
| `bugfix/*`  | —          | Bug fixes before release          |
| `hotfix/*`  | Production | Emergency production patches      |
| `chore/*`   | —          | Refactor, tool updates, cleanups  |

---

## Responsibilities

- **Developers**: Work on feature/bugfix branches, create clean PRs to `develop`, follow commit conventions.
- **QA**: Validate `develop` and `stage`, file bugs, approve readiness for production.
- **Project Managers**: Coordinate releases, monitor UAT in staging, communicate sign-offs.
- **DevOps**: Maintain CI/CD pipelines and deployment triggers for each environment.

---

## Final Tips

- Do **not** commit directly to `main` or `stage` or `develop`.
- Rebase before merging to reduce noise in commit history.
- Tag all production releases clearly (`v1.3.0`, `v1.3.1-hotfix`)
- Use branch protection rules to prevent accidental merges.
