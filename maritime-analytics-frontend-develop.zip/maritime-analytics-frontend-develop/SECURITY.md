# Security Policy

This is a private internal repository. Access is restricted to authorized Polestar Global team members.

## Reporting a Vulnerability

Report security issues directly to the maintainer — do not raise them in GitHub issues or pull request comments.

**Contact:** sourabh.ranka@polestarglobal.com

Include:

- Description of the vulnerability and affected component
- Steps to reproduce
- Potential impact
- Suggested fix if known

## Scope

| Area                        | Examples                                                            |
| --------------------------- | ------------------------------------------------------------------- |
| Authentication & sessions   | `AuthContext`, `ProtectedRoute`, `getAuthHeaders()`                 |
| WebSocket handling          | `useMara2WebSocket` — untrusted payload parsing                     |
| API request construction    | `mara2ApiService.ts`, auth header injection                         |
| Markdown / iframe rendering | XSS via `react-markdown`, chart iframe `src` origin                 |
| Secrets exposure            | `VITE_MAPBOX_ACCESS_TOKEN` and other `VITE_*` keys in client bundle |

Backend API vulnerabilities should be reported to the API team separately.

## Security Guidelines for Contributors

- **No secrets in source.** `VITE_MAPBOX_ACCESS_TOKEN`, API keys, and credentials go in `.env.local` (gitignored), never in committed files.
- **Use `getAuthHeaders()`** from `@/shared/utils/authHeaders` for all authenticated requests.
- **Treat WebSocket payloads as untrusted.** Always parse and type-check before use.
- **Do not bypass `react-markdown`.** Avoid `dangerouslySetInnerHTML` for assistant-provided content without explicit sanitization.
- **Validate iframe `src` origins.** Chart URLs come from the backend — confirm they resolve to the expected S3 origin before rendering.

## Dependency Auditing

Run before each release:

```bash
npm audit
```

High/critical advisories with a realistic attack vector must be resolved before merging to `main`.
