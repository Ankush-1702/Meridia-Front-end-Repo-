# Code Structure

This document is the authoritative reference for how this project is organized. All new code must follow these conventions.

---

## Directory Layout

```
project-root/
│
├── .env                    # Local environment file (gitignored — copy from .env.example)
├── .env.local              # Developer-specific overrides (gitignored)
├── .env.example            # Template listing all required VITE_* vars (committed, no secrets)
├── .gitignore
├── package.json
├── tsconfig.json           # TypeScript config (path aliases, strict mode)
├── vite.config.ts          # Vite config (plugins, @/ alias, port 8082)
├── tailwind.config.js
├── postcss.config.js
├── eslint.config.js
├── prettier.config.js
│
├── public/                 # Static assets served as-is (no bundling)
│   └── images/
│
├── src/
│   ├── main.tsx            # React entry point (ReactDOM.createRoot only)
│   ├── index.css           # Tailwind base imports + global styles
│   │
│   ├── app/                # Application skeleton (global wiring, no business logic)
│   │   ├── routes/         # Top-level <Routes> assembly (imports feature routes)
│   │   │   └── AppRoutes.tsx
│   │   ├── store/          # Global Zustand slices (cross-feature state only)
│   │   ├── context/        # App-wide React Contexts (ThemeContext, AuthContext)
│   │   ├── providers/      # Root-level provider wrappers (Flowbite, etc.)
│   │   ├── components/     # Global components (ErrorBoundary, etc.)
│   │   ├── hooks/          # App-wide hooks (useTheme, useAuth, useApiErrorHandler)
│   │   ├── utils/          # Utility helpers (logger, formatters)
│   │   ├── constants/      # App-wide constants (route paths, config keys)
│   │   ├── config/         # Axios instance, env validation/typing
│   │   │   ├── axios.ts    # Shared Axios instance — use this everywhere
│   │   │   └── config.ts   # Env wrapper with validation & typing
│   │   └── index.tsx       # Root <App /> component
│   │
│   ├── features/           # Self-contained feature modules
│   │   └── [feature]/      # Lowercase or kebab-case name (e.g. auth, custom-zones)
│   │       ├── assets/     # Feature-specific images/icons
│   │       ├── components/ # UI components scoped to this feature
│   │       ├── pages/      # Full-page route components
│   │       ├── hooks/      # Feature-specific React hooks
│   │       ├── services/   # API calls (must use shared Axios instance)
│   │       ├── store/      # Feature-specific Zustand slices
│   │       ├── types/      # TypeScript interfaces/types for this feature
│   │       │   └── index.ts
│   │       ├── utils/      # Pure helper functions scoped to this feature
│   │       ├── routes.ts   # Feature route config (lazy-loaded pages)
│   │       └── index.ts    # Barrel exports
│   │
│   ├── shared/             # Cross-feature reusable modules
│   │   ├── components/     # Low-level atomic components
│   │   ├── ui/             # Composite UI elements (tables, modals, panels)
│   │   ├── hooks/          # Generic hooks (useDebounce, useOnClickOutside)
│   │   ├── lib/            # Library wrappers
│   │   ├── services/       # Shared API services (e.g. overview)
│   │   ├── styles/         # Shared CSS and react-select styles
│   │   ├── constants/      # Shared constants
│   │   ├── types/          # Global TypeScript types
│   │   ├── utils/          # Shared utility functions
│   │   └── assets/         # Shared images/icons
│   │
│   └── types/              # Global ambient type declarations (*.d.ts)
│
├── tests/
│   └── setup.ts            # Vitest + React Testing Library global setup
│
├── scripts/                # Automation and build scripts
│
└── docs/                   # Project documentation
    └── code-structure.md   # This file
```

---

## Key Conventions

### Feature naming

- Use **lowercase or kebab-case** for new feature folder names: `auth`, `custom-zones`, `mara2`.
- Existing PascalCase folders (`Notifications`, `Ports`, `Vessels`, `Zones`) are legacy naming — do not introduce new PascalCase feature folders.

### What goes where

| Code                                        | Location                  |
| ------------------------------------------- | ------------------------- |
| Business logic for a single feature         | `src/features/[feature]/` |
| UI or logic reused across 2+ features       | `src/shared/`             |
| Global providers, routing, top-level config | `src/app/`                |
| Global ambient type declarations            | `src/types/`              |

### Tests

- Colocate tests in a `_test_/` subdirectory **next to the source file**, not in a central folder.
- Example: `src/features/auth/hooks/_test_/useLogin.test.ts`
- Test setup file: `tests/setup.ts`

### Imports

- Always use the `@/` alias for imports from `src/`: `@/shared/hooks/useDebounce`
- Relative imports (`../../`) are acceptable only within the same immediate directory.

### API calls

- All HTTP requests must use the shared Axios instance from `@/app/config/axios.ts`.
- Never create feature-level Axios instances.
- Handle API errors via `useApiErrorHandler` from `@/app/hooks/useApiErrorHandler.ts`.

### Environment variables

- All client-side env vars must be prefixed `VITE_`.
- When adding a new var, update `.env.example` with the key and a placeholder value (no secrets).
- Copy `.env.example` to `.env` locally and fill in real values — both are gitignored.
- Use `.env.local` for personal overrides that differ from team defaults.

### Routing

- All new routes must use **lazy loading** (`React.lazy` + `Suspense`).
- Feature routes are defined in `[feature]/routes.ts` and assembled in `src/app/routes/AppRoutes.tsx`.

### UI components

- Prefer **Flowbite React** components first.
- Use **Tailwind CSS** for customization or when Flowbite doesn't cover the case.
- Build from scratch only when neither Flowbite nor Tailwind classes suffice.

### State management

- Use **Zustand** for global or cross-feature state (`src/app/store/` or `src/features/[feature]/store/`).
- Use **React Context** for feature-scoped or subtree-scoped state.
- No formal rule yet on when to prefer one over the other — use judgment based on scope.
