# Meridia — Claude Guide

Meridia is a maritime analytics SPA for vessel tracking, port analytics, zone management, and AI-assisted querying (MeridiaIQ). React 18 + TypeScript + Vite. REST via Axios, real-time via STOMP over WebSocket.

**Key libraries:** Mapbox GL JS v3 (maps), AG Grid Enterprise (data grids), AG Charts Enterprise (charts), Flowbite React + Tailwind CSS (UI), Zustand (state), React Router v7.

---

## Commands

```bash
npm run dev           # Dev server at http://localhost:8082
npm run typecheck     # Run after making code changes to catch TypeScript errors
npm run fix:staged    # Auto-fix lint and formatting on staged files
npm run check:staged  # Validate staged files (lint + typecheck + prettier) before committing
npm run test          # Run Vitest suite
npm run test:coverage # Tests with coverage report (target: 80%)
```

After making code changes, always run `npm run typecheck` to verify there are no TypeScript errors before proceeding. Fix all type errors before moving to the next step.

If the pre-commit hook blocks a commit: run `npm run fix:staged`, review the diff, re-stage, then commit again. Never use `--no-verify` except emergency hotfixes.

---

## Architecture

Three layers — for full layout, naming rules, and what-goes-where decisions, read `docs/code-structure.md`:

- `src/app/` — global wiring: routes, providers, config, app-wide hooks. No business logic.
- `src/features/[feature]/` — self-contained modules. Each owns: `components/`, `hooks/`, `pages/`, `services/`, `store/`, `types/`, `routes.ts`, `index.ts`.
- `src/shared/` — code reused across 2+ features: components, hooks, utils, services.

New feature folder names: lowercase or kebab-case (`auth`, `custom-zones`). Do not introduce PascalCase feature folders.

---

## Rules (always apply)

**API**

- Use the shared Axios instance from `@/app/config/axios.ts` everywhere. Never create feature-level clients.
- Handle API errors via `useApiErrorHandler` (`@/app/hooks/useApiErrorHandler.ts`).

**Tests**

- Colocate tests in `_test_/` next to the source file: `src/features/auth/hooks/_test_/useLogin.test.ts`.
- Write or update tests whenever logic changes. Target 80% coverage.

**Imports**

- Use `@/` for all imports from `src/`. Avoid deep relative paths.

**Routes**

- Lazy-load all new routes with `React.lazy` + `Suspense`. No exceptions.

**Environment variables**

- Prefix all client-side vars with `VITE_`.
- Update `.env.example` with the key and a placeholder value whenever a new `VITE_*` var is introduced.
- `.env` and `.env.local` are both gitignored — never commit either.

**TypeScript**

- Never use `any` — use `unknown` or define a proper type.
- Never add `@ts-ignore` or `eslint-disable` comments — fix the root cause instead.

**Logging**

- Never use `console.log` — use `@/shared/utils/logger.ts` for all logging.

**UI**

- Flowbite React components first → Tailwind for customization → custom from scratch only as last resort.

**Git**

- Branch format: `feature/{jira-id}`, `bugfix/{jira-id}`, `hotfix/{jira-id}`, `chore/{jira-id}`.
- Commit format: `JIRA-XXXX : Clear action-oriented message`.
- Never push directly to `main`, `stage`, or `develop`.

---

## Feature notes

- `src/features/mara` is **legacy** (MeridiaIQ V1). Ask before modifying it.
- `src/features/mara2` is the active product (MeridiaIQ V2). It has its own `CLAUDE.md` at `src/features/mara2/CLAUDE.md` — loaded automatically when working in that feature.

---

## Before working on specific areas

- **Adding or restructuring features** — read `docs/code-structure.md` first.

---

## Open questions

- **State management**: no formal rule yet. Working heuristic: Zustand for global/cross-feature state, React Context for subtree-scoped state.
- **Accessibility (jsx-a11y) and GTM analytics**: best effort, not mandatory.
