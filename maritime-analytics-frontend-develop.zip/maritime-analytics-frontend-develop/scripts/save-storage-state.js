/**
 * Playwright Login Script
 *
 * Reads credentials from .env.local and logs into the Meridia app,
 * saving the authenticated browser state and generating an inject page
 * that MCP Playwright can use to restore the session.
 *
 * Usage: npm run auth:save
 */

import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(__dirname, '..');

function loadEnvLocal() {
  const envPath = resolve(ROOT, '.env.local');
  let content;
  try {
    content = readFileSync(envPath, 'utf-8');
  } catch {
    console.error('ERROR: .env.local not found. Create it with:');
    console.error('  MCP_PLAYWRIGHT_EMAIL=your-email');
    console.error('  MCP_PLAYWRIGHT_PASSWORD=your-password');
    process.exit(1);
  }

  const vars = {};
  for (const line of content.split('\n')) {
    const match = line.match(/^([^=]+)=(.*)$/);
    if (match) vars[match[1].trim()] = match[2].trim();
  }
  return vars;
}

const env = loadEnvLocal();
const email = env.MCP_PLAYWRIGHT_EMAIL;
const password = env.MCP_PLAYWRIGHT_PASSWORD;

if (!email || !password) {
  console.error(
    'ERROR: MCP_PLAYWRIGHT_EMAIL and MCP_PLAYWRIGHT_PASSWORD must be set in .env.local',
  );
  process.exit(1);
}

const APP_URL = env.MCP_PLAYWRIGHT_APP_URL || 'http://localhost:8082';
const STORAGE_PATH = resolve(ROOT, 'auth', 'storageState.json');

(async () => {
  console.log(`Logging into ${APP_URL} as ${email}...`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  await page.goto(`${APP_URL}/login`);
  await page.getByRole('textbox', { name: 'Email' }).fill(email);
  await page.getByRole('textbox', { name: 'Password' }).fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();

  await page.waitForURL((url) => !url.pathname.includes('/login'), {
    timeout: 30000,
  });

  console.log('Logged in. Saving storage state...');
  const state = await context.storageState({ path: STORAGE_PATH });

  // Generate an HTML page that injects localStorage and redirects.
  // MCP Playwright navigates to this page to restore the session
  // without ever exposing credentials to the AI assistant.
  const localStorageItems = state.origins?.[0]?.localStorage || [];
  const setStatements = localStorageItems
    .map(
      (i) =>
        `localStorage.setItem(${JSON.stringify(i.name)},${JSON.stringify(i.value)});`,
    )
    .join('\n    ');

  const html = `<!DOCTYPE html>
<html><head><title>Auth Inject</title></head>
<body>
  <script>
    ${setStatements}
    window.location.href = '/analytics/library';
  </script>
</body></html>`;

  const INJECT_PATH = resolve(ROOT, 'public', '_auth-inject.html');
  writeFileSync(INJECT_PATH, html);

  await browser.close();
  console.log(`Saved ${localStorageItems.length} localStorage items.`);
  console.log(
    'Done! Navigate to http://localhost:8082/_auth-inject.html to login.',
  );
})();
