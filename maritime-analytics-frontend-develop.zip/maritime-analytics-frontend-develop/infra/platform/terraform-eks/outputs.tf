output "s3_buckets" {
  description = "S3 bucket details"
  value       = module.s3.bucket_details
}

output "cloudfront" {
  description = "CloudFront distribution details"
  value       = module.cloudfront.cloudfront
}

output "application_url" {
  description = "Application URL"
  value       = try(module.cloudfront.cloudfront.domain_name, "")
}

output "s3_bucket_name" {
  description = "S3 bucket name"
  value       = var.bucket_name
}

output "cloudfront_distribution_id" {
  description = "CloudFront distribution ID"
  value       = try(module.cloudfront.cloudfront.id, "")
}
