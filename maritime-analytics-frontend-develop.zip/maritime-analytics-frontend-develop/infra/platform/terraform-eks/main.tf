# Module for S3 bucket
module "s3" {
  source = "git::https://github.com/Pole-Star-Space-Applications-USA/polestar-terraform-module-s3.git?ref=v1.1"

  global_parameters = var.global_parameters
  tags              = var.tags
  s3_parameters     = var.s3_parameters
}

# Data source to get bucket details for CloudFront
data "aws_s3_bucket" "ui_bucket" {
  depends_on = [module.s3]
  bucket     = var.bucket_name
}

# Module for CloudFront distribution
module "cloudfront" {
  source = "git::https://github.com/Pole-Star-Space-Applications-USA/polestar-terraform-module-cloudfront.git?ref=v1.1"

  cloudfront_parameters = merge(var.cloudfront_parameters, {
    origin_domain_name = data.aws_s3_bucket.ui_bucket.bucket_regional_domain_name
    origin_id          = var.bucket_name
    s3_bucket_arn      = data.aws_s3_bucket.ui_bucket.arn
    s3_bucket_id       = var.bucket_name
  })

  global_parameters = var.global_parameters
  tags              = var.tags
}
