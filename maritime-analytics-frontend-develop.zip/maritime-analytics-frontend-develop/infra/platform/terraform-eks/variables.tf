variable "global_parameters" {
  description = "Global parameters for CloudFront and other modules"
  type        = any
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
}

variable "s3_parameters" {
  description = "S3 bucket configuration parameters"
  type        = any
}

variable "cloudfront_parameters" {
  description = "CloudFront distribution configuration parameters"
  type        = any
}

variable "bucket_name" {
  description = "Name of the S3 bucket to associate with CloudFront"
  type        = string
  default     = ""
}
