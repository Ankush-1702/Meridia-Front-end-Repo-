#Local Variables
locals {
  config        = yamldecode(file(find_in_parent_folders("accounts-dictionary.yaml")))
  env_config    = local.config.workload.polestar.legacy-stage
  source_module = "${get_repo_root()}/infra/platform/terraform"
  tfstate_path  = "${local.env_config.aws_region}/${local.env_config.environment}/${basename(get_repo_root())}/platform"
}

# Terraform Block
terraform {
  source = local.source_module

  extra_arguments "auto_approve" {
    arguments = ["-auto-approve"]
    commands  = ["apply"]
  }

  extra_arguments "be_quieter" {
    arguments = ["-compact-warnings"]
    commands  = ["init", "plan", "apply"]
  }
}

# Backend Configuration
remote_state {
  backend = "s3"

  generate = {
    if_exists = "overwrite_terragrunt"
    path      = "backend.tf"
  }

  config = {
    bucket         = local.env_config.tfstate_bucket
    dynamodb_table = local.env_config.tfstate_dynamodb
    encrypt        = true
    key            = "${local.tfstate_path}/terraform.tfstate"
    region         = local.env_config.aws_region
  }
}

# Provider Configuration
generate "provider_config" {
  contents  = templatefile("${get_terragrunt_dir()}/../../providers.tmpl", { aws_region = local.env_config.aws_region })
  if_exists = "overwrite"
  path      = "providers.tf"
}

/* Input Parameters for Terraform code */
inputs = {

  tags = {
    "business-unit" = "shared"
    "cost-center"   = "ai"
    "environment"   = local.env_config.environment
    "Name"          = "maritime-analytics-fe"
    "project"       = "maritime-analytics-fe"
  }

  params_data = {
    "env_app_name"       = "${local.env_config.environment}-maritime-analytics-fe"
    "public_hosted_zone" = local.env_config.public_domain
  }

  cloudfront_parameters = {
    "http_version"             = "http2"
    "aliases"                  = ["${local.env_config.environment}-maritime-analytics-fe.${local.env_config.public_domain}"]
    "cached_methods"           = ["GET", "HEAD"]
    "allowed_methods"          = ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"]
    "compress"                 = false
    "smooth_streaming"         = false
    "default_root_object"      = "index.html"
    "viewer_protocol_policy"   = "allow-all"
    "minimum_protocol_version" = "TLSv1.2_2021"
    "custom_error_response" = {
      "403" = {
        "error_caching_min_ttl" = 10
        "response_code"         = 200
        "response_page_path"    = "/index.html"
      }
      "404" = {
        "error_caching_min_ttl" = 10
        "response_code"         = 200
        "response_page_path"    = "/index.html"
      }
    }
  }
}
