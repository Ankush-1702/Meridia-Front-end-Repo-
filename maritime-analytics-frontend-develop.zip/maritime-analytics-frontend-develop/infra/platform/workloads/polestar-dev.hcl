# Local Variables
locals {
  config        = yamldecode(file(find_in_parent_folders("accounts-dictionary.yaml")))
  env_config    = local.config.workload.polestar.dev
  source_module = "${get_repo_root()}/infra/platform/terraform-eks"
  tfstate_path  = "frontend/applications/oneplatform/maritime-analytics-frontend"
  github_token  = get_env("TF_VAR_GITHUB_TOKEN")
}

# Terraform Block
terraform {
  source = local.source_module

  before_hook "configure_git_credentials" {
    commands = ["init"]
    execute  = ["sh", "-c", "git config --global url.'https://${local.github_token}@github.com/'.insteadOf 'https://github.com/'"]
  }

  extra_arguments "auto_approve" {
    arguments = ["-auto-approve"]
    commands  = ["apply"]
  }

  extra_arguments "be_quieter" {
    arguments = ["-compact-warnings"]
    commands  = ["init", "plan", "apply"]
  }
}

# Backend Configuration
remote_state {
  backend = "s3"

  generate = {
    if_exists = "overwrite_terragrunt"
    path      = "backend.tf"
  }

  config = {
    bucket         = local.env_config.tfstate_bucket
    dynamodb_table = local.env_config.tfstate_dynamodb
    encrypt        = true
    key            = "${local.tfstate_path}/terraform.tfstate"
    region         = local.env_config.aws_region
  }
}

# Provider Configuration
generate "provider_config" {
  contents  = templatefile(find_in_parent_folders("providers.tmpl"), { aws_region = local.env_config.aws_region })
  if_exists = "overwrite"
  path      = "providers.tf"
}

/* Input Parameters for Terraform code */
inputs = {

  global_parameters = {
    account_alias       = local.env_config.account_alias
    account_id          = local.env_config.account_id
    aws_region          = local.env_config.aws_region
    public_domain       = local.env_config.public_domain
    private_domain      = local.env_config.private_domain
    public_hosted_zone  = local.env_config.public_domain
    private_hosted_zone = local.env_config.private_domain
  }

  tags = merge(
    local.config.tags,
    {
      "environment" = "elz"
    }
  )

  # S3 Parameters
  s3_parameters = {
    "ps-dev-maritime-analytics-web" = {
      type                 = "standard"
      acl                  = "private"
      object_ownership     = "BucketOwnerEnforced"
      versioning           = "Disabled"
      block_public_access  = true

      lifecycle_rules = [
        {
          id     = "cleanup-old-versions"
          status = "Enabled"
          filter = {}

          noncurrent_version_expiration = [{ days = 30 }]
        }
      ]
    }
  }

  # CloudFront Parameters
  cloudfront_parameters = {
    cdn_name                   = "maritime-analytics-frontend"
    cdn_comment                = "Maritime Analytics UI Cloudfront Distribution"
    http_version               = "http2and3"
    aliases                    = ["maritime-analytics.${local.env_config.public_domain}"]
    cached_methods             = ["GET", "HEAD"]
    allowed_methods            = ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"]
    compress                   = true
    smooth_streaming           = false
    default_root_object        = "index.html"
    viewer_protocol_policy     = "redirect-to-https"
    minimum_protocol_version   = "TLSv1.2_2021"
    origin_type                = "s3"
    create_route53_record      = true

    custom_error_response = {
      "403" = {
        error_caching_min_ttl = 10
        response_code         = 200
        response_page_path    = "/index.html"
      }
      "404" = {
        error_caching_min_ttl = 10
        response_code         = 200
        response_page_path    = "/index.html"
      }
    }
  }

  bucket_name = "ps-dev-maritime-analytics-web"
}
