data "aws_iam_policy_document" "s3_bucket_policy" {
  statement {
    sid       = "OnlyCloudFrontDistributionAccess"
    actions   = [ "s3:GetObject",
                  "s3:ListBucket"
                ]
    resources = [ "${aws_s3_bucket.application.arn}",
                  "${aws_s3_bucket.application.arn}/*"]
    principals {
      type        = "AWS"
      identifiers = var.policy_principal_identifiers
    }
  }
}
