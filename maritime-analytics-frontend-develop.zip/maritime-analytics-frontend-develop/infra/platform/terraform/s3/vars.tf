variable "tags" { type = map(string) }
variable "params_data" { type = map(string) }
variable "policy_principal_identifiers" { type = list(string) }

locals {
  bucket_name = var.params_data.env_app_name
  bucket_tags = merge(var.tags, { Name = "${local.bucket_name}" })
}
