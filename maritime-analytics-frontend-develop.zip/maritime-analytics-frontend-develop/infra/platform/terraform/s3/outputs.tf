output "ui_bucket_name" {
  value = aws_s3_bucket.application.bucket
}

output "ui_bucket_regional_domain_name" {
  value = aws_s3_bucket.application.bucket_regional_domain_name
}
