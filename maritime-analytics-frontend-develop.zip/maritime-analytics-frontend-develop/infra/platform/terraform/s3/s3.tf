resource "aws_s3_bucket" "application" {
  bucket = local.bucket_name
  tags   = local.bucket_tags
}

resource "aws_s3_bucket_ownership_controls" "application" {
  bucket = aws_s3_bucket.application.id
  rule {
    object_ownership = "BucketOwnerPreferred"
  }
}

resource "aws_s3_bucket_acl" "application" {
  depends_on = [aws_s3_bucket_ownership_controls.application]
  bucket     = aws_s3_bucket.application.id
  acl        = "private"
}

resource "aws_s3_bucket_public_access_block" "application" {
  bucket = aws_s3_bucket.application.id

  block_public_acls       = "true"
  block_public_policy     = "true"
  ignore_public_acls      = "true"
  restrict_public_buckets = "true"
}

resource "aws_s3_bucket_policy" "cf-s3-bucket-policy" {
  depends_on = [aws_s3_bucket_public_access_block.application]
  bucket     = aws_s3_bucket.application.id
  policy     = data.aws_iam_policy_document.s3_bucket_policy.json

  lifecycle {
    ignore_changes = [
      policy,
    ]
  }
}
