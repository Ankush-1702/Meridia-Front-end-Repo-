output "application_url" {
  value = module.cloudfront.application_url
}

output "cloudfront_distribution_id" {
  value = module.cloudfront.cloudfront_distribution_id
}

output "cloudfront_distribution_domain_name" {
  value = module.cloudfront.cloudfront_distribution_domain_name
}

output "s3_bucket_name" {
  value = module.s3.ui_bucket_name
}
