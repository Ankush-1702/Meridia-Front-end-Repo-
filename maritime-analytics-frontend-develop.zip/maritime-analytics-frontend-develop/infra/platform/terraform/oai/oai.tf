resource "aws_cloudfront_origin_access_identity" "application" {
  comment = "${var.params_data.env_app_name} CloudFront OAI"
}
