output "iam_arn" {
  description = "IAM ARN of the OAI"
  value       = aws_cloudfront_origin_access_identity.application.iam_arn
}

output "access_identity_path" {
  description = "ID of the OAI"
  value       = aws_cloudfront_origin_access_identity.application.cloudfront_access_identity_path
}
