# Public Hosted Zone
data "aws_route53_zone" "public" {
  name         = "${var.params_data.public_hosted_zone}."
  private_zone = false
}

# Public Domain ACM Certificate
data "aws_acm_certificate" "public_domain" {
  domain      = "*.${var.params_data.public_hosted_zone}"
  types       = ["AMAZON_ISSUED"]
  most_recent = true
}
