variable "tags" { type = map(string) }
variable "params_data" { type = map(string) }
variable "cloudfront_parameters" { type = any }
variable "cache_policy_id" {
  type    = string
  default = null
}
