module "oai" {
  source      = "./oai"
  params_data = var.params_data
}

module "s3" {
  depends_on                   = [module.oai]
  source                       = "./s3"
  params_data                  = var.params_data
  tags                         = var.tags
  policy_principal_identifiers = [module.oai.iam_arn]
}

module "cloudfront" {
  depends_on      = [module.s3]
  source          = "./cloudfront"
  params_data     = var.params_data
  tags            = var.tags
  origin_id       = module.s3.ui_bucket_name
  cache_policy_id = var.cache_policy_id
  data_parameters = {
    "public_domain_acm_arn" = data.aws_acm_certificate.public_domain.arn
    "public_hosted_zone_id" = data.aws_route53_zone.public.id
  }
  origin_domain_name    = module.s3.ui_bucket_regional_domain_name
  access_identity_path  = module.oai.access_identity_path
  cloudfront_parameters = var.cloudfront_parameters
}
