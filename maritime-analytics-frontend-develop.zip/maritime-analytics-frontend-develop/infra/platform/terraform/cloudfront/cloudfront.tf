resource "aws_cloudfront_distribution" "application" {
  comment = local.cdn_comment
  # aliases             = ["${var.params_data.env_app_name}.${var.params_data.public_hosted_zone}"]
  aliases             = var.cloudfront_parameters.aliases
  http_version        = var.cloudfront_parameters.http_version
  enabled             = true
  is_ipv6_enabled     = false
  default_root_object = var.cloudfront_parameters.default_root_object

  origin {
    domain_name = var.origin_domain_name
    origin_id   = "S3-${var.origin_id}"

    s3_origin_config {
      origin_access_identity = var.access_identity_path
    }
  }

  dynamic "custom_error_response" {
    for_each = var.cloudfront_parameters.custom_error_response
    content {
      error_caching_min_ttl = custom_error_response.value.error_caching_min_ttl
      error_code            = custom_error_response.key
      response_code         = custom_error_response.value.response_code
      response_page_path    = custom_error_response.value.response_page_path
    }

  }

  default_cache_behavior {
    cache_policy_id        = var.cache_policy_id
    min_ttl                = 0
    max_ttl                = 31536000
    default_ttl            = 86400
    cached_methods         = var.cloudfront_parameters.cached_methods
    allowed_methods        = var.cloudfront_parameters.allowed_methods
    target_origin_id       = "S3-${var.origin_id}"
    viewer_protocol_policy = var.cloudfront_parameters.viewer_protocol_policy
    compress               = var.cloudfront_parameters.compress
    smooth_streaming       = var.cloudfront_parameters.smooth_streaming

    forwarded_values {
      query_string = true
      cookies {
        forward = "all"
      }
    }
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    ssl_support_method       = "sni-only"
    acm_certificate_arn      = var.data_parameters.public_domain_acm_arn
    minimum_protocol_version = var.cloudfront_parameters.minimum_protocol_version
  }

  # lifecycle {
  #   ignore_changes = [
  #     aliases
  #   ]
  # }

  tags = local.cdn_tags
}
