resource "aws_route53_record" "application" {
  depends_on = [aws_cloudfront_distribution.application]

  zone_id = var.data_parameters.public_hosted_zone_id
  name    = var.params_data.env_app_name
  type    = "CNAME"
  ttl     = 60

  records = [aws_cloudfront_distribution.application.domain_name]
}
