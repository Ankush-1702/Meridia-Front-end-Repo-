variable "tags" {}
variable "origin_id" {}
variable "params_data" {}
variable "data_parameters" {}
variable "origin_domain_name" {}
variable "access_identity_path" {}
variable "cloudfront_parameters" {}
variable "cache_policy_id" {
  type    = string
  default = null
}

locals {
  cdn_name    = var.params_data.env_app_name
  cdn_tags    = merge(var.tags, { Name = "${local.cdn_name}" })
  cdn_comment = "Maritime Analytics UI Cloudfront Distribution"
}
