output "application_url" {
  value = aws_route53_record.application.fqdn
}

output "cloudfront_distribution_id" {
  value = aws_cloudfront_distribution.application.id
}

output "cloudfront_distribution_domain_name" {
  value = aws_cloudfront_distribution.application.domain_name
}
