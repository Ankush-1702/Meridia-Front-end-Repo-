export interface ZoneEvents {
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
  event_details: {
    course: number;
    draught: number;
    event_id: string;
    event_timestamp: string;
    event_type: 'ZONE_ENTRY' | 'ZONE_EXIT';
    heading: number;
    latitude: number;
    longitude: number;
    navigational_status: {
      status: string;
      code: number;
    };
    reported_destination: string;
    reported_eta: string;
    speed: number;
  };
}

export interface FlatZoneEventsResponse {
  vesselName?: string;
  callSign?: string;
  flag?: string;
  flagCode?: string;
  imo?: string;
  mmsi?: string;
  vesselType?: string;
  course?: number;
  draught?: number;
  eventId?: string;
  eventTimestamp?: string;
  eventType?: 'ZONE_ENTRY' | 'ZONE_EXIT' | '';
  heading?: number;
  latitude?: number;
  longitude?: number;
  navigationalStatusStatus?: string;
  navigationalStatusCode?: number;
  reportedDestination?: string;
  reportedEta?: string;
  speed?: number;
}
