import { useCallback, useEffect, useMemo, useState } from 'react';
import { LuRefreshCw } from 'react-icons/lu';
import { MdAutoAwesome } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';
import { useCustomZoneBanner } from './hooks/useCustomZoneBanner';
import ZoneEventsTab from './ui/ZoneEventsTab';
import { isMara2Enabled } from '@/app/config/config';
import { zoneType } from '@/features/library/utils/TypesSubTypesAndStatus';
import {
  ASK_IQ_PATH,
  askIqPrompts,
  buildAskIqNavigationState,
} from '@/features/mara2/utils/askIq';
import EmptyZoneBanner from '@/features/Zones/components/EmptyZoneBanner';
import { useLiveZoneTraffic } from '@/features/Zones/hooks/useLiveZoneTraffic';
import { useZoneDetails } from '@/features/Zones/hooks/useZoneDetails';
import ZoneTraffic from '@/features/Zones/ui/ZoneTraffic';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import EntityLoadingSkeleton from '@/shared/components/EntityLoadingSkeleton';
import EntityTabs from '@/shared/components/EntityTabs';
import LoadingTemplate from '@/shared/components/LoadingTemplate';
import OverviewCharts from '@/shared/components/OverviewCharts';
import OverviewMap from '@/shared/components/OverviewMap';
import StatsSummary from '@/shared/components/StatsSummary';
import VesselListItem from '@/shared/components/VesselListItem';
import VesselLoadingProgress from '@/shared/components/VesselLoadingProgress';
import VesselSummarySection from '@/shared/components/VesselSummarySection';
import { useOverviewData } from '@/shared/hooks/useOverviewData';
import { EntityDetailsPanel } from '@/shared/ui/EntityDetailsPanel';
import EntityToolBar from '@/shared/ui/EntityToolbar';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';
import { getMovementValues } from '@/shared/utils/CongestionAndTrafficUtils';
import { logger } from '@/shared/utils/logger';
import {
  buildCustomZoneGeometry,
  decryptGeometry,
} from '@/shared/utils/overviewMapUtils';

const POLLING_INTERVAL = 5 * 60 * 1000;

const zoneEventsTabs = [
  { label: 'Entries', value: 'ZONE_ENTRY' },
  { label: 'Exits', value: 'ZONE_EXIT' },
];
export default function ZoneDetailsPage() {
  const {
    id,
    zone,
    loading,
    error,
    refresh,
    setRefresh,
    toggleBookmarkLoading,
    isBookmarked,
    addOrRemoveBookmark,
    subscriptionData,
    manageSubscription,
    getSubscription,
    zoneBoundary,
  } = useZoneDetails();

  const {
    isLoading,
    last30DaysData,
    liveZoneData,
    fetchLast30DaysData,
    fetchLiveZoneTraffic,
  } = useLiveZoneTraffic();

  const showBanner = useCustomZoneBanner(zone);

  const navigate = useNavigate();
  const handleAskIQ = () => {
    if (!zone?.name) return;
    navigate(
      ASK_IQ_PATH,
      buildAskIqNavigationState(askIqPrompts.zone(zone.name)),
    );
  };

  const [activeTab, setActiveTab] = useState('overview');

  const [vesselsInZoneExpanded, setVesselsInZoneExpanded] = useState(false);

  const [timeAgo, setTimeAgo] = useState<string>('0s');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const boundaryGeometry = useMemo(() => {
    if (zone?.type === zoneType.Custom && zone.custom_zone_details) {
      return buildCustomZoneGeometry(zone.custom_zone_details);
    }
    return decryptGeometry(zoneBoundary?.geometry);
  }, [zone?.type, zone?.custom_zone_details, zoneBoundary?.geometry]);

  // Real API data for Overview tab with streaming
  const {
    positions,
    error: overviewError,
    center: overviewCenter,
    progress: overviewProgress,
    refresh: refreshOverview,
  } = useOverviewData({
    entity: zone?.id ? { type: 'zone', id: zone.id } : undefined,
  });
  const vesselsInZoneCount = overviewProgress?.totalVessels ?? positions.length;
  const vesselsInZoneEmptyMessage =
    vesselsInZoneCount === 0
      ? 'No vessels currently in zone'
      : 'No mappable vessels currently in zone';

  const buttonLabel = isBookmarked(zone?.id)
    ? 'Remove from Library'
    : 'Add to Library';

  const bookMarked = isBookmarked(zone?.id);

  const breadcrumbsData = [
    { label: 'Library', href: '/analytics/library' },
    { label: 'Zones', href: '/analytics/library?tab=Zones' },
  ];

  const notificationsType = ['Entries', 'Exits'];

  const zoneRows = [
    { label: 'Name', value: zone?.name },
    { label: 'Type', value: zone?.type },
    { label: 'Sub Type', value: zone?.sub_type },
    { label: 'Country', value: zone?.country_common_name || '-' },
    { label: 'UNLOCODE', value: zone?.unlocode || '-' },
    { label: 'WPI Number', value: zone?.wpi_number || '-' },
    {
      label: 'Sub Division',
      value: zone?.sub_division_name
        ? `${zone?.sub_division_name} (${zone?.sub_division_code})`
        : '-',
    },
  ];

  const refreshAllData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const results = await Promise.allSettled([
        fetchLiveZoneTraffic(),
        fetchLast30DaysData(),
        refreshOverview(),
      ]);
      results.forEach((result, index) => {
        if (result.status === 'rejected') {
          const names = [
            'fetchLiveZoneTraffic',
            'fetchLast30DaysData',
            'overviewRefresh',
          ];
          logger.error(`${names[index]} failed:`, result.reason);
        }
      });
      setLastUpdated(new Date());
    } finally {
      setIsRefreshing(false);
    }
  }, [fetchLiveZoneTraffic, fetchLast30DaysData, refreshOverview]);

  // Time ago updater
  useEffect(() => {
    const updateTimeAgo = () => {
      if (!lastUpdated) {
        setTimeAgo('0s');
        return;
      }

      const now = new Date();
      const diff = Math.floor((now.getTime() - lastUpdated.getTime()) / 1000);

      if (diff < 60) {
        setTimeAgo(`${diff}s`);
      } else {
        const minutes = Math.floor(diff / 60);
        setTimeAgo(`${minutes}m`);
      }
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 1000);

    return () => clearInterval(interval);
  }, [lastUpdated]);

  // Initial load
  useEffect(() => {
    if (zone?.id) {
      refreshAllData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zone?.id]);

  // Polling interval
  useEffect(() => {
    const interval = setInterval(refreshAllData, POLLING_INTERVAL);

    return () => clearInterval(interval);
  }, [refreshAllData]);

  if (loading)
    return (
      <div className="h-screen p-6 dark:bg-gray-900">
        <EntityLoadingSkeleton />
      </div>
    );
  if (error)
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );
  if (!zone)
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );

  return (
    <div className="flex h-screen flex-col bg-gray-100 dark:bg-gray-900 lg:overflow-hidden">
      <header className="sticky top-0 z-10 bg-gray-100 dark:bg-gray-900">
        <EntityToolBar
          id={id}
          breadcrumbs={breadcrumbsData}
          flag={zone.country_code}
          title={zone?.name}
          subtitle={[zone?.type, zone?.sub_type, zone?.country_common_name]
            .filter(Boolean)
            .join(', ')}
          onToggle={() => addOrRemoveBookmark(zone?.id)}
          buttonLabel={buttonLabel}
          loading={toggleBookmarkLoading}
          refresh={refresh}
          setRefresh={setRefresh}
          notificationsType={notificationsType}
          subscriptionData={subscriptionData}
          manageSubscription={manageSubscription}
          isBookmarked={bookMarked}
          getSubscription={getSubscription}
          dontShowDateRange
        />

        <div className="h-12 bg-gray-50">
          <EntityTabs
            tabs={[
              { key: 'overview', label: 'Overview' },
              { key: 'traffic', label: 'Traffic' },
              { key: 'events', label: 'Events' },
            ]}
            activeTab={activeTab}
            onChange={setActiveTab}
            renderActions={
              <div className="flex items-center gap-2">
                {activeTab === 'overview' && (
                  <div className="-mt-5 flex items-center justify-center">
                    <p className="text-xs text-gray-400">
                      Auto-updates every 5 minutes
                    </p>
                  </div>
                )}
                {isMara2Enabled() && (
                  <button
                    onClick={handleAskIQ}
                    className="-mt-5 flex min-w-[110px] items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                  >
                    <MdAutoAwesome className="text-gray-400" />
                    Ask IQ
                  </button>
                )}
              </div>
            }
          />
        </div>
      </header>
      <main className="min-h-0 flex-1 overflow-auto">
        <div className="mt-4 min-h-0 px-6">
          {activeTab === 'overview' && (
            <div className="flex flex-col gap-4">
              {!isLoading && showBanner && <EmptyZoneBanner />}
              {overviewError && (
                <div className="mb-4 rounded-md bg-red-50 p-4 text-sm text-red-700 dark:bg-red-900/20 dark:text-red-400">
                  Error loading vessel data: {overviewError}
                </div>
              )}

              {/* Enhanced progress indicator for streaming */}
              {overviewProgress &&
                !overviewProgress.isComplete &&
                overviewProgress.totalVessels > 0 && (
                  <VesselLoadingProgress progress={overviewProgress} />
                )}
              <div className="flex items-center justify-end gap-2 text-xs text-gray-400 ">
                <LuRefreshCw className="h-3 w-3 text-gray-400" />
                Updated {timeAgo} ago
                <button
                  className="cursor-pointer text-gray-400 underline hover:text-gray-700"
                  onClick={refreshAllData}
                  disabled={isRefreshing}
                >
                  Refresh
                </button>
              </div>

              <div className="flex gap-4">
                {/* Vessel Summary Sections */}
                <div className="flex w-[420px] flex-col space-y-2">
                  {/* Show only expanded section when one is expanded, otherwise show both collapsed */}
                  {vesselsInZoneExpanded ? (
                    /* Only Vessels In Zone Section when expanded */
                    <VesselSummarySection
                      title="In Zone"
                      count={vesselsInZoneCount}
                      isExpanded={vesselsInZoneExpanded}
                      onToggle={() =>
                        setVesselsInZoneExpanded(!vesselsInZoneExpanded)
                      }
                      isEmpty={positions.length === 0}
                      emptyMessage={vesselsInZoneEmptyMessage}
                      viewAllLabel="View all"
                      onViewAll={() => {
                        setActiveTab('events');
                      }}
                    >
                      {positions.map((vessel) => (
                        <VesselListItem
                          key={vessel.id}
                          vesselName={vessel.name || 'Unknown Vessel'}
                          vesselType={vessel.vesselType || 'Unknown'}
                          imo={vessel.imo || ''}
                          flag={vessel.flag || ''}
                          timestamp={vessel.timestampUtc || ''}
                          timestampLabel="ATA"
                        />
                      ))}
                    </VesselSummarySection>
                  ) : (
                    /* Both sections collapsed - show both */
                    <>
                      <VesselSummarySection
                        title="Vessels In Zone"
                        count={vesselsInZoneCount}
                        isExpanded={vesselsInZoneExpanded}
                        onToggle={() =>
                          setVesselsInZoneExpanded(!vesselsInZoneExpanded)
                        }
                        isEmpty={positions.length === 0}
                        emptyMessage={vesselsInZoneEmptyMessage}
                        viewAllLabel="View all"
                        onViewAll={() => {
                          setActiveTab('events');
                        }}
                      >
                        {positions.slice(0, 5).map((vessel) => (
                          <VesselListItem
                            key={vessel.id || vessel.imo}
                            vesselName={vessel.name || 'Unknown Vessel'}
                            vesselType={vessel.vesselType || 'Unknown'}
                            imo={vessel.imo || ''}
                            flag={vessel.flag || ''}
                            timestamp={vessel.timestampUtc || ''}
                            timestampLabel="ATA"
                          />
                        ))}
                      </VesselSummarySection>
                    </>
                  )}
                  {!vesselsInZoneExpanded && (
                    <div className="relative flex flex-1 flex-col gap-4 rounded-lg bg-white p-4 dark:bg-gray-800">
                      <h3 className="text-xs">Traffic (Previous 30 days)</h3>
                      <div className="min-h-0 flex-1">
                        {isLoading || isRefreshing ? (
                          <LoadingTemplate />
                        ) : last30DaysData?.totals &&
                          (last30DaysData?.totals.max_vessels_per_day > 0 ||
                            last30DaysData?.totals.vessels_per_day > 0) ? (
                          <StatsSummary
                            stats={[
                              {
                                label: 'Unique Entries per Day  (avg)',
                                value:
                                  last30DaysData?.totals.vessels_per_day ?? 0,
                              },
                              {
                                label: 'Unique Entries per Day (max)',
                                value:
                                  last30DaysData?.totals.max_vessels_per_day ??
                                  0,
                              },
                              {
                                label: 'Total Entries',
                                value:
                                  getMovementValues(last30DaysData?.totals)
                                    .inflow ?? 0,
                              },
                              {
                                label: 'Total Exits',
                                value:
                                  getMovementValues(last30DaysData?.totals)
                                    .outflow ?? 0,
                              },
                            ]}
                          />
                        ) : (
                          <CongestionEmptyState />
                        )}
                      </div>
                      <button
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-700"
                        onClick={() => setActiveTab('traffic')}
                      >
                        View Traffic Analytics
                      </button>
                    </div>
                  )}
                </div>

                {/* Map Section */}
                <div className="flex-1">
                  <OverviewMap
                    center={
                      overviewCenter || {
                        longitude: zone.centroid.longitude,
                        latitude: zone.centroid.latitude,
                      }
                    }
                    label={zone.name}
                    heightClassName="h-[480px]"
                    positions={positions} // Always show available positions
                    entityType="zone"
                    boundaryGeometry={boundaryGeometry}
                  />
                </div>
              </div>
              <OverviewCharts
                isLoading={isLoading || isRefreshing}
                liveCongestionData={liveZoneData}
                inLabel="Entries"
                outLabel="Exits"
              />
            </div>
          )}
          {activeTab === 'traffic' && <ZoneTraffic zone={zone} />}
          {activeTab === 'details' && (
            <EntityDetailsPanel
              title={zone.name}
              type="zone"
              unlocode={zone.type}
              sections={[{ rows: zoneRows }]}
              flag={zone.country_code}
            />
          )}
          {activeTab === 'events' && (
            <ZoneEventsTab
              zoneName={zone.name}
              zoneId={id!}
              zoneEventsTabs={zoneEventsTabs}
              setRefresh={setRefresh}
              refresh={refresh}
            />
          )}
        </div>
      </main>
    </div>
  );
}
