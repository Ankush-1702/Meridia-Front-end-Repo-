import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  fetchZoneDetails,
  fetchZoneBoundary,
  fetchZoneEvents,
  fetchZoneSubscriptions,
  createZoneSubscription,
  updateZoneSubscription,
} from '../zoneServices';
import type {
  ISubscription,
  ScheduleType,
  SubscriptionResponseDataType,
} from '@/shared/types/subscriptionTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function mockUser() {
  localStorage.setItem('user', JSON.stringify({ user_id: 'user-1' }));
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockOk(data: unknown) {
  const fetchWithAuth = await getFetchWithAuth();
  fetchWithAuth.mockResolvedValue({
    ok: true,
    json: vi.fn().mockResolvedValue(data),
  } as unknown as Response);
}

async function mockError(
  status = 400,
  body: Record<string, unknown> = { message: 'Error' },
) {
  const fetchWithAuth = await getFetchWithAuth();
  fetchWithAuth.mockResolvedValue({
    ok: false,
    status,
    statusText: 'Bad Request',
    json: vi.fn().mockResolvedValue(body),
    text: vi.fn().mockResolvedValue('Text error'),
  } as unknown as Response);
}

async function mockErrorJsonFails(status = 500, statusText = 'Server Error') {
  const fetchWithAuth = await getFetchWithAuth();
  fetchWithAuth.mockResolvedValue({
    ok: false,
    status,
    statusText,
    json: vi.fn().mockRejectedValue(new Error('not json')),
    text: vi.fn().mockResolvedValue('Plain text error'),
  } as unknown as Response);
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('zoneServices', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    mockUser();
  });

  /* ---------------------------------------------------------------- */
  /* fetchZoneDetails                                                 */
  /* ---------------------------------------------------------------- */

  describe('fetchZoneDetails', () => {
    it('fetches zone details and returns data', async () => {
      await mockOk({ data: { id: 'zone-1', name: 'Zone A' } });

      const result = await fetchZoneDetails('zone-1');

      expect(result).toEqual({ id: 'zone-1', name: 'Zone A' });
    });

    it('calls the correct URL with user_id', async () => {
      await mockOk({ data: {} });
      const fetch = await getFetchWithAuth();

      await fetchZoneDetails('zone-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/zone-port-insights/v1/zones/zone-1?user_id=user-1',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockError(404, { message: 'Not Found' });
      await expect(fetchZoneDetails('zone-1')).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockError(400, { error: 'Bad zone id' });
      await expect(fetchZoneDetails('zone-1')).rejects.toThrow('Bad zone id');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockError(422, { detail: 'Validation failed' });
      await expect(fetchZoneDetails('zone-1')).rejects.toThrow(
        'Validation failed',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockError(500, {});
      await expect(fetchZoneDetails('zone-1')).rejects.toThrow('Bad Request');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails(500, 'Server Error');
      await expect(fetchZoneDetails('zone-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockError(403, { message: 'Forbidden' });

      const err = await fetchZoneDetails('zone-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchZoneBoundary                                                */
  /* ---------------------------------------------------------------- */

  describe('fetchZoneBoundary', () => {
    it('fetches zone boundary and returns data', async () => {
      const boundary = { id: 'zone-1', name: 'Zone A', geometry: 'abc' };
      await mockOk(boundary);

      const result = await fetchZoneBoundary('zone-1');

      expect(result).toEqual(boundary);
    });

    it('calls the correct URL', async () => {
      await mockOk({});
      const fetch = await getFetchWithAuth();

      await fetchZoneBoundary('zone-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/zones/zone-1',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockError(404, { message: 'Boundary not found' });
      await expect(fetchZoneBoundary('zone-1')).rejects.toThrow(
        'Boundary not found',
      );
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockError(400, { error: 'Invalid id' });
      await expect(fetchZoneBoundary('zone-1')).rejects.toThrow('Invalid id');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockError(422, { detail: 'Unprocessable' });
      await expect(fetchZoneBoundary('zone-1')).rejects.toThrow(
        'Unprocessable',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails();
      await expect(fetchZoneBoundary('zone-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockError(403, { message: 'Forbidden' });

      const err = await fetchZoneBoundary('zone-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchZoneEvents                                                  */
  /* ---------------------------------------------------------------- */

  describe('fetchZoneEvents', () => {
    it('fetches zone events with required params', async () => {
      await mockOk({
        data: { events: [{ id: 'e1' }] },
        meta: { total_count: 1 },
      });

      const result = await fetchZoneEvents('zone-1');

      expect(result).toEqual({ data: [{ id: 'e1' }], totalCount: 1 });
    });

    it('includes default query params in the URL', async () => {
      await mockOk({ data: { events: [] }, meta: { total_count: 0 } });
      const fetch = await getFetchWithAuth();

      await fetchZoneEvents('zone-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('limit=500');
      expect(calledUrl).toContain('offset=0');
      expect(calledUrl).toContain('flatten_json=true');
      expect(calledUrl).toContain('all_data=true');
      expect(calledUrl).toContain('excl_port_information=true');
      expect(calledUrl).toContain('excl_event_details=true');
    });

    it('appends timestamp_start and timestamp_end when provided', async () => {
      await mockOk({ data: { events: [] }, meta: { total_count: 0 } });
      const fetch = await getFetchWithAuth();

      await fetchZoneEvents('zone-1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('timestamp_start=2025-01-01');
      expect(calledUrl).toContain('timestamp_end=2025-01-31');
    });

    it('does not append timestamp params when not provided', async () => {
      await mockOk({ data: { events: [] }, meta: { total_count: 0 } });
      const fetch = await getFetchWithAuth();

      await fetchZoneEvents('zone-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).not.toContain('timestamp_start');
      expect(calledUrl).not.toContain('timestamp_end');
    });

    it('uses custom limit and offset when provided', async () => {
      await mockOk({ data: { events: [] }, meta: { total_count: 0 } });
      const fetch = await getFetchWithAuth();

      await fetchZoneEvents('zone-1', undefined, undefined, 50, 100);

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('offset=50');
      expect(calledUrl).toContain('limit=100');
    });

    it('throws on error', async () => {
      await mockError(500, { message: 'Events failed' });
      await expect(fetchZoneEvents('zone-1')).rejects.toThrow('Events failed');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails();
      await expect(fetchZoneEvents('zone-1')).rejects.toThrow(
        'Plain text error',
      );
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchZoneSubscriptions                                           */
  /* ---------------------------------------------------------------- */

  describe('fetchZoneSubscriptions', () => {
    const subscription: SubscriptionResponseDataType = {
      subscription_exists: true,
      subscription_id: 'sub-1',
      name: 'Zone',
      active: true,
      notify_on: { ZONE_ENTRY: true, ZONE_EXIT: false },
      vessel_screening: { active: false, severity_filter: [] },
      email_settings: {
        email_enabled: false,
        scheduler: { schedule_type: 1 as ScheduleType, at_time: '08:00' },
      },
    };

    it('fetches and returns subscription data', async () => {
      await mockOk(subscription);
      const result = await fetchZoneSubscriptions('sub-1');
      expect(result).toEqual(subscription);
    });

    it('calls the correct URL with user_id and subscription_id', async () => {
      await mockOk(subscription);
      const fetch = await getFetchWithAuth();

      await fetchZoneSubscriptions('sub-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions/sub-1',
        expect.anything(),
      );
    });

    it('throws on error', async () => {
      await mockError(403, { message: 'Forbidden' });
      await expect(fetchZoneSubscriptions('sub-1')).rejects.toThrow(
        'Forbidden',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails();
      await expect(fetchZoneSubscriptions('sub-1')).rejects.toThrow(
        'Plain text error',
      );
    });
  });

  /* ---------------------------------------------------------------- */
  /* createZoneSubscription                                           */
  /* ---------------------------------------------------------------- */

  describe('createZoneSubscription', () => {
    const body: ISubscription = {
      entity_ref_id: 'zone-1',
      entity_type: 'ZONE',
      name: 'Zone',
      active: true,
      notify_on: { ZONE_ENTRY: true, ZONE_EXIT: true },
      vessel_screening: { active: false, severity_filter: [] },
      email_settings: {
        email_enabled: false,
        scheduler: { schedule_type: 1 as ScheduleType, at_time: '08:00' },
      },
    };

    it('creates and returns subscription', async () => {
      await mockOk({ subscription_exists: true });
      const result = await createZoneSubscription(body);
      expect(result).toEqual({ subscription_exists: true });
    });

    it('calls POST to the correct URL', async () => {
      await mockOk({ subscription_exists: true });
      const fetch = await getFetchWithAuth();

      await createZoneSubscription(body);

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions',
        expect.objectContaining({ method: 'POST' }),
      );
    });

    it('serialises the body as JSON', async () => {
      await mockOk({ subscription_exists: true });
      const fetch = await getFetchWithAuth();

      await createZoneSubscription(body);

      const options = fetch.mock.calls[0][1] as RequestInit;
      expect(options.body).toBe(JSON.stringify(body));
    });

    it('throws on error', async () => {
      await mockError(400, { message: 'Create failed' });
      await expect(createZoneSubscription({} as ISubscription)).rejects.toThrow(
        'Create failed',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails();
      await expect(createZoneSubscription({} as ISubscription)).rejects.toThrow(
        'Plain text error',
      );
    });
  });

  /* ---------------------------------------------------------------- */
  /* updateZoneSubscription                                           */
  /* ---------------------------------------------------------------- */

  describe('updateZoneSubscription', () => {
    const body: ISubscription = {
      entity_ref_id: 'zone-1',
      entity_type: 'ZONE',
      name: 'Zone',
      active: false,
      notify_on: { ZONE_ENTRY: false, ZONE_EXIT: false },
      vessel_screening: { active: false, severity_filter: [] },
      email_settings: {
        email_enabled: false,
        scheduler: { schedule_type: 1 as ScheduleType, at_time: '08:00' },
      },
    };

    it('updates and returns subscription', async () => {
      await mockOk({ subscription_exists: true });
      const result = await updateZoneSubscription(body, 'sub-1');
      expect(result).toEqual({ subscription_exists: true });
    });

    it('calls PUT to the correct URL with subscription_id', async () => {
      await mockOk({ subscription_exists: true });
      const fetch = await getFetchWithAuth();

      await updateZoneSubscription(body, 'sub-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions/sub-1',
        expect.objectContaining({ method: 'PUT' }),
      );
    });

    it('serialises the body as JSON', async () => {
      await mockOk({ subscription_exists: true });
      const fetch = await getFetchWithAuth();

      await updateZoneSubscription(body, 'sub-1');

      const options = fetch.mock.calls[0][1] as RequestInit;
      expect(options.body).toBe(JSON.stringify(body));
    });

    it('throws on error', async () => {
      await mockError(500, { message: 'Update failed' });
      await expect(
        updateZoneSubscription({} as ISubscription, 'sub-1'),
      ).rejects.toThrow('Update failed');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockErrorJsonFails();
      await expect(
        updateZoneSubscription({} as ISubscription, 'sub-1'),
      ).rejects.toThrow('Plain text error');
    });
  });
});
