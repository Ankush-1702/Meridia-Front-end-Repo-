import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import * as authUtil from '@/features/auth/utils/authUtil';
import {
  getEntriesAndExitsByTotals,
  getEntriesByVesselType,
  getEntriesByVesselTypesAndTotals,
  getLiveZoneTrafficData,
  getTopVisitingVessels,
} from '@/features/Zones/services/zoneTrafficApi';
import * as authHeaders from '@/shared/utils/authHeaders';

vi.mock('@/features/auth/utils/authUtil');
vi.mock('@/shared/utils/authHeaders');
vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.test.com',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
  API_BASE_URL: 'https://test-api.com',
}));

describe('zoneTrafficApi', () => {
  const mockAuthHeaders = { Authorization: 'Bearer test-token' };

  const locationInfo = {
    id: 'test-zone-123',
    name: 'Test Zone',
    zone_type: 'EEZ',
    zone_sub_type: 'National',
    country_common_name: 'Test Country',
  };

  const mockRawApiResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    zone_information: locationInfo,
    totals: {
      entries: 300,
      exits: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', entries: 10, exits: 8 }],
      },
    ],
  };

  const mockRawLiveApiResponse = {
    meta: {
      timestamp_start: '2026-03-09T00:00:00Z',
      timestamp_end: '2026-03-09T10:00:00Z',
      request_id: 'req-live-123',
    },
    zone_information: locationInfo,
    totals: {
      entries: 15,
      exits: 12,
      vessels_per_day: 27,
      max_vessels_per_day: 35,
      by_vessel_type: [{ group_by_key: 'Cargo', entries: 10, exits: 8 }],
    },
    data: [
      {
        period_key: '2026-03-09',
        items: [{ group_by_key: 'Cargo', entries: 10, exits: 8 }],
      },
    ],
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (authHeaders.getAuthHeaders as Mock).mockReturnValue(mockAuthHeaders);
  });

  describe('getEntriesAndExitsByTotals', () => {
    it('should fetch entries and exits with required parameters', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getEntriesAndExitsByTotals(
        'zone-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/zones/id/zone-123/entries-exits?group_by=NONE&period_aggregation=DAILY&date_start=2026-01-01&date_end=2026-03-01',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawApiResponse.totals);
      expect(result.data).toEqual(mockRawApiResponse.data);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getEntriesAndExitsByTotals(
        'zone-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier,Oil Tanker',
        'US,GB',
        'Handysize,Panamax',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier%2COil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US%2CGB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize%2CPanamax'),
        expect.anything(),
      );
    });

    it('should throw error with message when response is not ok', async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue({ message: 'Zone not found' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Zone not found');
    });

    it('should throw error with error field when message is not present', async () => {
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue({ error: 'Invalid request' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Invalid request');
    });

    it('should throw error with detail field when message and error are not present', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({ detail: 'Detailed error' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Detailed error');
    });

    it('should throw error with statusText when no error fields are present', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Internal Server Error');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('JSON parse error')),
        text: vi.fn().mockResolvedValue('Plain text error'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Plain text error');
    });

    it('should include status and body in thrown error', async () => {
      const errorBody = { message: 'Zone not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getEntriesAndExitsByTotals(
          'zone-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  describe('getEntriesByVesselType', () => {
    it('should fetch entries by vessel type and map zone_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getEntriesByVesselType(
        'zone-123',
        'VESSEL_TYPE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/zones/id/zone-123/entries-exits?group_by=VESSEL_TYPE&period_aggregation=DAILY&date_start=2026-01-01&date_end=2026-03-01',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawApiResponse.totals);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getEntriesByVesselType(
        'zone-123',
        'VESSEL_TYPE',
        'WEEKLY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        'US',
        'Handysize',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize'),
        expect.anything(),
      );
    });

    it('should throw error when response is not ok', async () => {
      const mockResponse = {
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
        json: vi.fn().mockResolvedValue({ message: 'Unauthorized' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesByVesselType(
          'zone-123',
          'VESSEL_TYPE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Unauthorized');
    });

    it('should handle json parse failure', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Server Error',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Server error text'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesByVesselType(
          'zone-123',
          'VESSEL_TYPE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Server error text');
    });
  });

  describe('getEntriesByVesselTypesAndTotals', () => {
    it('should fetch entries by vessel types and totals and map zone_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getEntriesByVesselTypesAndTotals(
        'zone-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/zones/id/zone-123/entries-exits?group_by=VESSEL_TYPE&period_aggregation=NONE&date_start=2026-01-01&date_end=2026-03-01',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getEntriesByVesselTypesAndTotals(
        'zone-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Oil Tanker',
        'GB',
        'VLCC',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Oil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=GB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=VLCC'),
        expect.anything(),
      );
    });

    it('should throw error when response is not ok', async () => {
      const mockResponse = {
        ok: false,
        status: 429,
        statusText: 'Too Many Requests',
        json: vi.fn().mockResolvedValue({ detail: 'Rate limit exceeded' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesByVesselTypesAndTotals(
          'zone-123',
          'VESSEL_TYPE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Rate limit exceeded');
    });

    it('should handle json parse failure', async () => {
      const mockResponse = {
        ok: false,
        status: 502,
        statusText: 'Bad Gateway',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Gateway timeout'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getEntriesByVesselTypesAndTotals(
          'zone-123',
          'VESSEL_TYPE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Gateway timeout');
    });
  });

  describe('getLiveZoneTrafficData', () => {
    it('should fetch live zone traffic data and map zone_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawLiveApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getLiveZoneTrafficData('zone-123');

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/zones/id/zone-123/live-traffic',
        {
          headers: mockAuthHeaders,
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawLiveApiResponse.totals);
      expect(result.data).toEqual(mockRawLiveApiResponse.data);
    });

    it('should throw error with message when response is not ok', async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue({ message: 'Zone not found' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLiveZoneTrafficData('zone-123')).rejects.toThrow(
        'Zone not found',
      );
    });

    it('should throw error with error field', async () => {
      const mockResponse = {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: vi.fn().mockResolvedValue({ error: 'Service unavailable' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLiveZoneTrafficData('zone-123')).rejects.toThrow(
        'Service unavailable',
      );
    });

    it('should throw error with detail field', async () => {
      const mockResponse = {
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
        json: vi.fn().mockResolvedValue({ detail: 'Authentication required' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLiveZoneTrafficData('zone-123')).rejects.toThrow(
        'Authentication required',
      );
    });

    it('should throw error with statusText when no error fields', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLiveZoneTrafficData('zone-123')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('JSON parse error')),
        text: vi.fn().mockResolvedValue('Raw error text'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLiveZoneTrafficData('zone-123')).rejects.toThrow(
        'Raw error text',
      );
    });

    it('should handle null zone_information in response', async () => {
      const responseWithNulls = {
        meta: {
          timestamp_start: '2026-03-09T00:00:00Z',
          timestamp_end: '2026-03-09T10:00:00Z',
          request_id: 'req-123',
        },
        zone_information: null,
        totals: null,
        data: [],
      };
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(responseWithNulls),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getLiveZoneTrafficData('zone-123');

      expect(result.location_information).toBeNull();
      expect(result.totals).toBeNull();
    });
  });

  describe('getTopVisitingVessels', () => {
    const mockTopVisitorsResponse = {
      ...mockRawApiResponse,
      top_visitors: [
        {
          rank: 1,
          vessel_name: 'VESSEL ONE',
          imo_number: '1234567',
          flag_code: 'US',
          flag_name: 'United States',
          ship_type_level_3: 'Bulk carrier',
          visit_count: 15,
        },
      ],
    };

    it('should fetch top visiting vessels and map zone_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getTopVisitingVessels(
        'zone-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('/analytics/zones/id/zone-123/entries-exits'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('group_by=NONE'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('period_aggregation=NONE'),
        expect.anything(),
      );
      expect(result.location_information).toEqual(locationInfo);
    });

    it('should include top_visitors_sort param for sort', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'zone-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        undefined,
        undefined,
        undefined,
        'ASC',
      );

      // Verify sort parameter is sent for zones
      const calledUrl = (authUtil.fetchWithAuth as Mock).mock
        .calls[0][0] as string;
      expect(calledUrl).toContain('top_visitors_sort=ASC');
    });

    it('should include optional vessel/flag/class params', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'zone-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier,Oil Tanker',
        'US,GB',
        'Handysize,VLCC',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier%2COil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US%2CGB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize%2CVLCC'),
        expect.anything(),
      );
    });

    it('should throw error with message field', async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue({ message: 'Zone not found' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Zone not found');
    });

    it('should throw error with error field when message absent', async () => {
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue({ error: 'Bad request' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Bad request');
    });

    it('should throw error with detail field when others absent', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({ detail: 'Server detail error' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Server detail error');
    });

    it('should throw with statusText when no error fields', async () => {
      const mockResponse = {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Service Unavailable');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Raw error'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Raw error');
    });

    it('should attach status and body to thrown error', async () => {
      const errorBody = { message: 'Zone not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getTopVisitingVessels(
          'zone-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });
});
