import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  GroupBy,
  ICongestionResponse,
  ILiveDataResponse,
  PeriodAggregation,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export const getEntriesAndExitsByTotals = async (
  zoneId: string,
  groupBy: GroupBy = 'NONE',
  periodAggregation: PeriodAggregation,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/zones/id/${zoneId}/entries-exits?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get total entries and exits';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.zone_information,
  };
};

export const getEntriesByVesselType = async (
  zoneId: string,
  groupBy: GroupBy = 'VESSEL_TYPE',
  periodAggregation: PeriodAggregation,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/zones/id/${zoneId}/entries-exits?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get entries by vessel type';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.zone_information,
  };
};

export const getEntriesByVesselTypesAndTotals = async (
  zoneId: string,
  groupBy: GroupBy = 'VESSEL_TYPE',
  periodAggregation: PeriodAggregation = 'NONE',
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/zones/id/${zoneId}/entries-exits?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get entries by totals and vessel types';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.zone_information,
  };
};

export const getLiveZoneTrafficData = async (
  zoneId: string,
): Promise<ILiveDataResponse> => {
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/zones/id/${zoneId}/live-traffic`,
    {
      headers: getAuthHeaders(),
    },
  );
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get live zone traffic data';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.zone_information,
  };
};

export async function getTopVisitingVessels(
  zoneId: string,
  groupBy: GroupBy = 'NONE',
  periodAggregation: PeriodAggregation = 'NONE',
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
  topVisitorSort: 'ASC' | 'DESC' = 'DESC',
  topVisitorsLimit: number = 50,
): Promise<ICongestionResponse> {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
  });
  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  params.append('top_visitors_sort', topVisitorSort);
  params.append('top_visitors_limit', topVisitorsLimit.toString());
  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/zones/id/${zoneId}/entries-exits?${params.toString()}`;
  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get top visiting vessels';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.zone_information,
  };
}
