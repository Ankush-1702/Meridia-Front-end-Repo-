import React from 'react';
import { describe, it, expect } from 'vitest';
import { zoneRoutes } from '@/features/Zones/routes/zoneRoutes';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

describe('zoneRoutes', () => {
  it('defines the zone analytics route', () => {
    expect(zoneRoutes).toHaveLength(1);

    const route = zoneRoutes[0];

    expect(route.path).toBe('/analytics/zone/:id');
    expect(React.isValidElement(route.element)).toBe(true);
  });

  it('wraps ZoneDetailsPage in SuspenseWrapper', () => {
    const route = zoneRoutes[0];

    expect(route.element.type).toBe(SuspenseWrapper);

    const child = route.element.props.children;
    expect(child.type.$$typeof).toBe(Symbol.for('react.lazy'));
  });
});
