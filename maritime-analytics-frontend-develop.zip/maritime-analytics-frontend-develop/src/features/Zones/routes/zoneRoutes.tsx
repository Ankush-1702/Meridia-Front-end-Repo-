import { lazy } from 'react';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

const ZoneDetailsPage = lazy(() => import('@/features/Zones/Zones'));

export const zoneRoutes = [
  {
    path: '/analytics/zone/:id',
    element: (
      <SuspenseWrapper>
        <ZoneDetailsPage />
      </SuspenseWrapper>
    ),
  },
];
