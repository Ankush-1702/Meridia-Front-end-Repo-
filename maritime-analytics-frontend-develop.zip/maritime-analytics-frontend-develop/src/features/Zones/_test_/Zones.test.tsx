import { describe, it, expect, vi, beforeEach } from 'vitest';
import ZoneDetailsPage from '../Zones';
import { renderWithRouter, screen, fireEvent } from '@/test-utils';
import '@/test-setup'; // Import test setup for window.matchMedia mock

// Mock ThemeProvider
vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light', saveTheme: vi.fn() }),
}));

// Mock config
vi.mock(import('@/app/config/config'), async (importOriginal) => {
  const actual = await importOriginal();
  return {
    ...actual,
    isMara2Enabled: () => false,
  };
});

//Mock decryption
vi.mock('@/shared/utils/overviewMapUtils', () => ({
  decryptGeometry: (g: unknown) => g,
  buildCustomZoneGeometry: () => 'custom-geometry',
}));

// Mock logger
vi.mock('@/shared/utils/logger', () => ({
  logger: {
    error: vi.fn(),
    warn: vi.fn(),
    info: vi.fn(),
    debug: vi.fn(),
  },
}));

/* ------------------------------------------------------------------ */
/* dynamic hook mock (CRITICAL FIX)                                   */
/* ------------------------------------------------------------------ */

const useZoneDetailsMock = vi.fn();

vi.mock('@/features/Zones/hooks/useZoneDetails', () => ({
  useZoneDetails: () => useZoneDetailsMock(),
}));

const hasGroupPermissionMock = vi.fn();

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  hasGroupPermission: () => hasGroupPermissionMock(),
}));

/* ------------------------------------------------------------------ */
/* live zone traffic hook                                              */
/* ------------------------------------------------------------------ */

const useLiveZoneTrafficMock = vi.fn();

vi.mock('@/features/Zones/hooks/useLiveZoneTraffic', () => ({
  useLiveZoneTraffic: () => useLiveZoneTrafficMock(),
}));

/* ------------------------------------------------------------------ */
/* overview hook                                                      */
/* ------------------------------------------------------------------ */

const refreshOverviewMock = vi.fn();
const useOverviewDataMock = vi.fn();

vi.mock('@/shared/hooks/useOverviewData', () => ({
  useOverviewData: () => useOverviewDataMock(),
}));

/* ------------------------------------------------------------------ */
/* UI stubs                                                           */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/EntityLoadingSkeleton', () => ({
  default: () => <div>LoadingSkeleton</div>,
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: () => <div>ErrorPage</div>,
}));

vi.mock('@/shared/ui/EntityToolbar', () => ({
  default: ({ title }: { title: string }) => <div>{title}</div>,
}));

vi.mock('@/shared/components/EntityTabs', () => ({
  default: ({
    tabs,
    onChange,
    renderActions,
  }: {
    tabs: { key: string; label: string }[];
    onChange: (key: string) => void;
    renderActions?: React.ReactNode;
  }) => (
    <div>
      {tabs.map((t) => (
        <button key={t.key} onClick={() => onChange(t.key)}>
          {t.label}
        </button>
      ))}
      {renderActions}
    </div>
  ),
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    handleClick,
    textLabel,
  }: {
    handleClick: () => void;
    textLabel: string;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/shared/components/OverviewCharts', () => ({
  default: () => <div>Charts</div>,
}));

const { capturedOverviewMapProps } = vi.hoisted(() => {
  const capturedOverviewMapProps = {
    current: undefined as Record<string, unknown> | undefined,
  };
  return { capturedOverviewMapProps };
});

vi.mock('@/shared/components/OverviewMap', () => ({
  default: (props: Record<string, unknown>) => {
    capturedOverviewMapProps.current = props;
    return <div>Map</div>;
  },
}));

vi.mock('@/shared/components/VesselLoadingProgress', () => ({
  default: () => <div>Progress</div>,
}));

vi.mock('@/shared/components/VesselSummarySection', () => ({
  default: ({
    title,
    count,
    isEmpty,
    emptyMessage,
    onToggle,
    children,
  }: {
    title: string;
    count?: number;
    isEmpty?: boolean;
    emptyMessage?: string;
    onToggle?: () => void;
    children?: React.ReactNode;
  }) => (
    <div>
      <button type="button" onClick={onToggle}>
        {title}
      </button>
      <span>{count}</span>
      {isEmpty ? <span>{emptyMessage}</span> : null}
      {children}
    </div>
  ),
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: () => <div>StatsSummary</div>,
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>CongestionEmptyState</div>,
}));

vi.mock('@/shared/components/LoadingTemplate', () => ({
  default: () => <div>LoadingTemplate</div>,
}));

vi.mock('@/shared/components/VesselListItem', () => ({
  default: () => <div>VesselListItem</div>,
}));

vi.mock('@/features/Zones/ui/ZoneEventsTab', () => ({
  default: () => <div>ZoneEventsTab</div>,
}));

vi.mock('@/features/Zones/ui/ZoneTraffic', () => ({
  default: () => <div>ZoneTraffic</div>,
}));

vi.mock('@/shared/ui/EntityDetailsPanel', () => ({
  EntityDetailsPanel: () => <div>EntityDetailsPanel</div>,
}));

vi.mock('@/features/Zones/components/EmptyZoneBanner', () => ({
  default: () => <div>EmptyZoneBanner</div>,
}));

vi.mock('@/features/Zones/hooks/useCustomZoneBanner', () => ({
  useCustomZoneBanner: () => false,
}));

/* ------------------------------------------------------------------ */
/* defaults                                                           */
/* ------------------------------------------------------------------ */

const baseZoneDetails = {
  id: 'zone-1',
  zone: {
    id: 'zone-1',
    name: 'Test Zone',
    type: 'Port',
    sub_type: 'Harbor',
    country_common_name: 'Norway',
    country_code: 'NO',
    centroid: { latitude: 10, longitude: 20 },
  },
  loading: false,
  error: null,
  refresh: false,
  setRefresh: vi.fn(),
  dateRange: { start: '2023-01-01', end: '2023-01-31' },
  setDateRange: vi.fn(),
  toggleBookmarkLoading: false,
  isBookmarked: () => false,
  addOrRemoveBookmark: vi.fn(),
  subscriptionData: null,
  manageSubscription: vi.fn(),
  getSubscription: vi.fn(),
  zoneBoundary: undefined,
};

const baseLiveZoneTraffic = {
  isLoading: false,
  last30DaysData: null,
  liveZoneData: null,
  fetchLast30DaysData: vi.fn().mockResolvedValue(undefined),
  fetchLiveZoneTraffic: vi.fn().mockResolvedValue(undefined),
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('ZoneDetailsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    capturedOverviewMapProps.current = undefined;
    useZoneDetailsMock.mockReturnValue(baseZoneDetails);
    useLiveZoneTrafficMock.mockReturnValue(baseLiveZoneTraffic);
    useOverviewDataMock.mockReturnValue({
      positions: [],
      loading: false,
      error: null,
      center: null,
      progress: null,
      refresh: refreshOverviewMock,
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('renders loading state', () => {
    useZoneDetailsMock.mockReturnValue({
      ...baseZoneDetails,
      loading: true,
    });

    renderWithRouter(<ZoneDetailsPage />);

    expect(screen.getByText('LoadingSkeleton')).toBeInTheDocument();
  });

  it('renders error state', () => {
    useZoneDetailsMock.mockReturnValue({
      ...baseZoneDetails,
      error: true,
    });

    renderWithRouter(<ZoneDetailsPage />);

    expect(screen.getByText('ErrorPage')).toBeInTheDocument();
  });

  it('renders error state when zone is null', () => {
    useZoneDetailsMock.mockReturnValue({
      ...baseZoneDetails,
      zone: null,
    });

    renderWithRouter(<ZoneDetailsPage />);

    expect(screen.getByText('ErrorPage')).toBeInTheDocument();
  });

  it('renders overview tab by default', () => {
    renderWithRouter(<ZoneDetailsPage />);

    expect(screen.getByText('Charts')).toBeInTheDocument();
    expect(screen.getByText('Map')).toBeInTheDocument();
  });

  it('prefers overview total vessel count over mapped positions length', () => {
    useOverviewDataMock.mockReturnValue({
      positions: [],
      loading: false,
      error: null,
      center: null,
      progress: {
        current: 1,
        total: 4,
        isComplete: false,
        vesselsLoaded: 0,
        totalVessels: 4,
        percentage: 25,
        estimatedTimeRemaining: 2,
      },
      refresh: refreshOverviewMock,
    });

    renderWithRouter(<ZoneDetailsPage />);

    expect(
      screen.getByRole('button', { name: 'Vessels In Zone' }),
    ).toBeInTheDocument();
    expect(screen.getByText('4')).toBeInTheDocument();
  });

  it('shows a no-mappable-vessels empty state when count is non-zero but positions are empty', () => {
    useOverviewDataMock.mockReturnValue({
      positions: [],
      loading: false,
      error: null,
      center: null,
      progress: {
        current: 1,
        total: 2,
        isComplete: false,
        vesselsLoaded: 0,
        totalVessels: 2,
        percentage: 50,
        estimatedTimeRemaining: 1,
      },
      refresh: refreshOverviewMock,
    });

    renderWithRouter(<ZoneDetailsPage />);

    fireEvent.click(screen.getByRole('button', { name: 'Vessels In Zone' }));

    expect(screen.getByRole('button', { name: 'In Zone' })).toBeInTheDocument();
    expect(
      screen.getByText('No mappable vessels currently in zone'),
    ).toBeInTheDocument();
  });

  it('shows auto-update message on overview tab', () => {
    renderWithRouter(<ZoneDetailsPage />);

    expect(
      screen.getByText('Auto-updates every 5 minutes'),
    ).toBeInTheDocument();
  });

  it('switches to events tab', () => {
    renderWithRouter(<ZoneDetailsPage />);

    fireEvent.click(screen.getByText('Events'));

    expect(screen.getByText('ZoneEventsTab')).toBeInTheDocument();
  });

  it('switches to traffic tab', () => {
    renderWithRouter(<ZoneDetailsPage />);

    fireEvent.click(screen.getByText('Traffic'));

    expect(screen.getByText('ZoneTraffic')).toBeInTheDocument();
  });

  it('calls all fetch functions on mount', async () => {
    const fetchLiveZoneTraffic = vi.fn().mockResolvedValue(undefined);
    const fetchLast30DaysData = vi.fn().mockResolvedValue(undefined);

    useLiveZoneTrafficMock.mockReturnValue({
      ...baseLiveZoneTraffic,
      fetchLiveZoneTraffic,
      fetchLast30DaysData,
    });

    renderWithRouter(<ZoneDetailsPage />);

    // Wait for promises to resolve
    await Promise.resolve();
    await Promise.resolve();

    expect(fetchLiveZoneTraffic).toHaveBeenCalled();
    expect(fetchLast30DaysData).toHaveBeenCalled();
    expect(refreshOverviewMock).toHaveBeenCalled();
  });

  it('calls refresh when refresh button is clicked', async () => {
    const fetchLiveZoneTraffic = vi.fn().mockResolvedValue(undefined);
    const fetchLast30DaysData = vi.fn().mockResolvedValue(undefined);

    useLiveZoneTrafficMock.mockReturnValue({
      ...baseLiveZoneTraffic,
      fetchLiveZoneTraffic,
      fetchLast30DaysData,
    });

    renderWithRouter(<ZoneDetailsPage />);

    // Wait for initial mount
    await Promise.resolve();
    await Promise.resolve();

    // Click refresh
    const refreshButton = screen.getByRole('button', { name: /refresh/i });
    fireEvent.click(refreshButton);

    // Wait for refresh promises
    await Promise.resolve();
    await Promise.resolve();

    expect(fetchLiveZoneTraffic).toHaveBeenCalled();
    expect(fetchLast30DaysData).toHaveBeenCalled();
    expect(refreshOverviewMock).toHaveBeenCalled();
  });

  describe('boundaryGeometry prop', () => {
    it('passes undefined boundaryGeometry to OverviewMap when zone has no geometry', () => {
      useZoneDetailsMock.mockReturnValue({
        ...baseZoneDetails,
        zoneBoundary: undefined,
      });

      renderWithRouter(<ZoneDetailsPage />);

      expect(
        capturedOverviewMapProps.current?.boundaryGeometry,
      ).toBeUndefined();
    });

    it('passes zone geometry as boundaryGeometry to OverviewMap', () => {
      const geom = '{"type":"Point","coordinates":[10,20]}';

      useZoneDetailsMock.mockReturnValue({
        ...baseZoneDetails,
        zoneBoundary: { geometry: geom },
      });

      renderWithRouter(<ZoneDetailsPage />);

      expect(capturedOverviewMapProps.current?.boundaryGeometry).toBe(geom);
    });
  });
});
