import { describe, it, expect } from 'vitest';
import { flattenZoneEvent, flattenZoneEvents } from '../zoneUtils';
import type { ZoneEvents } from '@/features/Zones/types/zoneTypes';

const buildZoneEvent = (
  overrides: Partial<ZoneEvents['event_details']> = {},
): ZoneEvents => ({
  vessel_information: {
    asset_id: 'asset-1',
    callsign: 'CALL1',
    flag: 'Norway',
    flag_code: 'NO',
    imo: '1234567',
    mmsi: '987654321',
    name: 'Test Vessel',
    vessel_type: 'Cargo',
  },
  event_details: {
    course: 90,
    draught: 5.5,
    event_id: 'event-1',
    event_timestamp: '2023-01-01T00:00:00Z',
    event_type: 'ZONE_ENTRY',
    heading: 180,
    latitude: 10.1,
    longitude: 20.2,
    navigational_status: {
      status: 'Under way using engine',
      code: 0,
    },
    reported_destination: 'Rotterdam',
    reported_eta: '2023-01-02T00:00:00Z',
    speed: 12.5,
    ...overrides,
  },
});

describe('flattenZoneEvent', () => {
  it('maps every field from the nested ZoneEvents shape to the flat shape', () => {
    const event = buildZoneEvent();

    const result = flattenZoneEvent(event);

    expect(result).toEqual({
      vesselName: 'Test Vessel',
      callSign: 'CALL1',
      flag: 'Norway',
      flagCode: 'NO',
      imo: '1234567',
      mmsi: '987654321',
      vesselType: 'Cargo',
      course: 90,
      draught: 5.5,
      eventId: 'event-1',
      eventTimestamp: '2023-01-01T00:00:00Z',
      eventType: 'ZONE_ENTRY',
      heading: 180,
      latitude: 10.1,
      longitude: 20.2,
      navigationalStatusStatus: 'Under way using engine',
      navigationalStatusCode: 0,
      reportedDestination: 'Rotterdam',
      reportedEta: '2023-01-02T00:00:00Z',
      speed: 12.5,
    });
  });

  it('preserves ZONE_EXIT event type', () => {
    const event = buildZoneEvent({ event_type: 'ZONE_EXIT' });

    const result = flattenZoneEvent(event);

    expect(result.eventType).toBe('ZONE_EXIT');
  });

  it('preserves falsy numeric values such as 0', () => {
    const event = buildZoneEvent({
      course: 0,
      draught: 0,
      heading: 0,
      speed: 0,
    });

    const result = flattenZoneEvent(event);

    expect(result.course).toBe(0);
    expect(result.draught).toBe(0);
    expect(result.heading).toBe(0);
    expect(result.speed).toBe(0);
  });
});

describe('flattenZoneEvents', () => {
  it('flattens an empty array', () => {
    expect(flattenZoneEvents([])).toEqual([]);
  });

  it('fills missing event values with empty values of the matching type', () => {
    const [result] = flattenZoneEvents([{} as ZoneEvents]);

    expect(result.vesselName).toBe('');
    expect(result.eventId).toBe('');
    expect(result.eventType).toBe('');
    expect(result.course).toBe(0);
    expect(result.navigationalStatusStatus).toBe('');
    expect(result.navigationalStatusCode).toBe(0);
  });

  it('flattens a list of events preserving order', () => {
    const events = [
      buildZoneEvent({ event_type: 'ZONE_ENTRY' }),
      buildZoneEvent({ event_type: 'ZONE_EXIT' }),
    ];

    const result = flattenZoneEvents(events);

    expect(result).toHaveLength(2);
    expect(result[0].eventType).toBe('ZONE_ENTRY');
    expect(result[1].eventType).toBe('ZONE_EXIT');
  });
});
