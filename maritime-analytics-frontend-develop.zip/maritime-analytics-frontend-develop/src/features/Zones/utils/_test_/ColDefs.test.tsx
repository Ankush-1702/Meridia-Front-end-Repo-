import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi } from 'vitest';
import { createZoneEventsColDefs } from '../ColDefs';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => (
    <span data-testid="status-badge">{status}</span>
  ),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode?: string }) => (
    <span data-testid="flag-icon">{flagCode}</span>
  ),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: vi.fn((v: string) => `UTC:${v}`),
  convertUTCToLocalTime: vi.fn((v: string) => `LOCAL:${v}`),
  toTitleCase: vi.fn((v: string) => v.toLowerCase()),
  getEventLabel: vi.fn((v: string) => v.toLowerCase()),
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function renderCell(
  renderer: (p: CustomCellRendererProps) => JSX.Element,
  value: unknown,
  data: unknown = {},
) {
  return renderer({
    value,
    data,
  } as CustomCellRendererProps);
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('createZoneEventsColDefs', () => {
  it('creates column definitions', () => {
    const cols = createZoneEventsColDefs('utc');
    expect(cols.length).toBeGreaterThan(10);
  });

  it('marks all columns as sortable', () => {
    const cols = createZoneEventsColDefs('utc');
    expect(cols.every((c) => c.sortable === true)).toBe(true);
  });

  it('uses UTC header and formatter when timezone is utc', () => {
    const cols = createZoneEventsColDefs('utc');
    const tsCol = cols[0];

    expect(tsCol.headerName).toContain('UTC');

    const el = renderCell(tsCol.cellRenderer!, '2023-01-01');
    expect(el.props.children).toBe('UTC:2023-01-01');
  });

  it('uses local formatter when timezone is not utc', () => {
    const cols = createZoneEventsColDefs('local');
    const tsCol = cols[0];

    expect(tsCol.headerName).toContain('System');

    const el = renderCell(tsCol.cellRenderer!, '2023-01-01');
    expect(el.props.children).toBe('LOCAL:2023-01-01');
  });

  it('formats event tooltip correctly using getEventLabel', () => {
    const cols = createZoneEventsColDefs('utc');
    const eventCol = cols[1];

    const tooltip = eventCol.tooltipValueGetter?.({
      value: 'ZONE_ENTRY',
    } as never);

    expect(tooltip).toBe('zone_entry');
  });

  it('renders StatusBadge for event column', () => {
    const cols = createZoneEventsColDefs('utc');
    const eventCol = cols[1];

    const el = renderCell(eventCol.cellRenderer!, 'ZONE_EXIT');
    expect(el.props.status).toBe('ZONE_EXIT');
  });

  it('renders vessel column with FlagIcon and name', () => {
    const cols = createZoneEventsColDefs('utc');
    const vesselCol = cols[2];

    const el = renderCell(vesselCol.cellRenderer!, 'Evergreen', {
      flagCode: 'NO',
    });

    const children = el.props.children;
    expect(children[0].props.flagCode).toBe('NO');
    expect(children[1].props.children).toBe('Evergreen');
  });

  it('renders FlagIcon on the Flag column', () => {
    const cols = createZoneEventsColDefs('utc');
    const flagCol = cols.find((c) => c.headerName === 'Flag');

    const el = renderCell(flagCol!.cellRenderer!, 'Norway', {
      flagCode: 'NO',
    });

    const children = el.props.children;
    expect(children[0].props.flagCode).toBe('NO');
    expect(children[1].props.children).toBe('Norway');
  });

  it('renders dash for empty numeric / optional fields', () => {
    const cols = createZoneEventsColDefs('utc');

    const fallbackHeaders = [
      'Course',
      'Draught',
      'Heading',
      'Latitude',
      'Longitude',
      'Navigational Status (status)',
      'Navigational Status (code)',
      'Reported Destination',
      'Speed',
    ];

    const fallbackCols = cols.filter(
      (c) => c.headerName && fallbackHeaders.includes(c.headerName),
    );

    expect(fallbackCols.length).toBeGreaterThan(0);

    for (const col of fallbackCols) {
      expect(col.cellRenderer).toBeDefined();

      const el = renderCell(col.cellRenderer!, null);
      expect(el.props.children).toBe('-');
    }
  });

  it('renders 0 (not dash) for numeric fields with a 0 value', () => {
    const cols = createZoneEventsColDefs('utc');
    const draughtCol = cols.find((c) => c.headerName === 'Draught');

    const el = renderCell(draughtCol!.cellRenderer!, 0);
    expect(el.props.children).toBe(0);
  });
});
