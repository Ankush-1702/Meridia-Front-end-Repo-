import {
  FlatZoneEventsResponse,
  ZoneEvents,
} from '@/features/Zones/types/zoneTypes';
import { logger } from '@/shared/utils/logger';

export function flattenZoneEvent(event: ZoneEvents): FlatZoneEventsResponse {
  return {
    vesselName: event?.vessel_information?.name ?? '',
    callSign: event?.vessel_information?.callsign ?? '',
    flag: event?.vessel_information?.flag ?? '',
    flagCode: event?.vessel_information?.flag_code ?? '',
    imo: event?.vessel_information?.imo ?? '',
    mmsi: event?.vessel_information?.mmsi ?? '',
    vesselType: event?.vessel_information?.vessel_type ?? '',
    course: event?.event_details?.course ?? 0,
    draught: event?.event_details?.draught ?? 0,
    eventId: event?.event_details?.event_id ?? '',
    eventTimestamp: event?.event_details?.event_timestamp ?? '',
    eventType: event?.event_details?.event_type ?? '',
    heading: event?.event_details?.heading ?? 0,
    latitude: event?.event_details?.latitude ?? 0,
    longitude: event?.event_details?.longitude ?? 0,
    navigationalStatusStatus:
      event?.event_details?.navigational_status?.status ?? '',
    navigationalStatusCode:
      event?.event_details?.navigational_status?.code ?? 0,
    reportedDestination: event?.event_details?.reported_destination ?? '',
    reportedEta: event?.event_details?.reported_eta ?? '',
    speed: event?.event_details?.speed ?? 0,
  };
}

export function flattenZoneEvents(
  events: ZoneEvents[],
): FlatZoneEventsResponse[] {
  return events.flatMap((event) => {
    try {
      return [flattenZoneEvent(event)];
    } catch (error) {
      logger.warn('Skipping zone event that could not be flattened', {
        eventId: event?.event_details?.event_id,
        eventType: event?.event_details?.event_type,
        error,
      });
      return [];
    }
  });
}
