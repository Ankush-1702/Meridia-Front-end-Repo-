import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { FlatZoneEventsResponse } from '@/features/Zones/types/zoneTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  getEventLabel,
} from '@/shared/utils/formatUtils';

export function createZoneEventsColDefs(
  timeZoneSetting: string,
): ColDef<FlatZoneEventsResponse>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'TimeStamp (UTC)' : 'TimeStamp (System)'}`,
      field: 'eventTimestamp',
      sortable: true,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Event',
      field: 'eventType',
      sortable: true,
      flex: 1,

      tooltipValueGetter: (params: ITooltipParams) =>
        getEventLabel(params.value),
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <StatusBadge status={params.value} />
      ),
    },
    {
      headerName: 'Vessel',
      field: 'vesselName',
      sortable: true,
      flex: 1,
      tooltipField: 'vesselName',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.flagCode} />
          <span className="truncate">{params.value}</span>
        </div>
      ),
    },
    {
      headerName: 'IMO',
      field: 'imo',
      sortable: true,
      flex: 1,
      tooltipField: 'imo',
      lockVisible: true,
    },
    {
      headerName: 'Type',
      field: 'vesselType',
      sortable: true,
      flex: 1,
      tooltipField: 'vesselType',
      lockVisible: true,
    },
    {
      headerName: 'Flag',
      field: 'flag',
      sortable: true,
      flex: 1,
      tooltipField: 'flag',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.flagCode} />
          <span className="truncate">{params.value}</span>
        </div>
      ),
    },
    {
      headerName: 'Call Sign',
      field: 'callSign',
      sortable: true,
      flex: 1,
      tooltipField: 'callSign',
      hide: true,
    },
    {
      headerName: 'Course',
      field: 'course',
      sortable: true,
      flex: 1,
      tooltipField: 'course',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'MMSI',
      field: 'mmsi',
      sortable: true,
      flex: 1,
      tooltipField: 'mmsi',
      hide: true,
    },
    {
      headerName: 'Draught',
      field: 'draught',
      sortable: true,
      flex: 1,
      tooltipField: 'draught',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Heading',
      field: 'heading',
      sortable: true,
      flex: 1,
      tooltipField: 'heading',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Latitude',
      field: 'latitude',
      sortable: true,
      flex: 1,
      tooltipField: 'latitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Longitude',
      field: 'longitude',
      sortable: true,
      flex: 1,
      tooltipField: 'longitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Navigational Status (status)',
      field: 'navigationalStatusStatus',
      sortable: true,
      flex: 1,
      width: 500,
      tooltipField: 'navigationalStatusStatus',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Navigational Status (code)',
      field: 'navigationalStatusCode',
      sortable: true,
      flex: 1,
      width: 500,
      tooltipField: 'navigationalStatusCode',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Reported Destination',
      field: 'reportedDestination',
      sortable: true,
      flex: 1,
      tooltipField: 'reportedDestination',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Reported ETA (UTC)' : 'Reported ETA (System)'}`,
      field: 'reportedEta',
      sortable: true,
      flex: 1,
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
    },
    {
      headerName: 'Speed',
      field: 'speed',
      sortable: true,
      flex: 1,
      tooltipField: 'speed',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
  ];
}
