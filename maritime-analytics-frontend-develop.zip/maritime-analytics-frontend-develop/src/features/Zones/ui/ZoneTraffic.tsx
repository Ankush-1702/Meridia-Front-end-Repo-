import { Tooltip } from 'flowbite-react';
import { useState, useRef } from 'react';

import { FaCircleInfo } from 'react-icons/fa6';
import { LuRefreshCw } from 'react-icons/lu';
// import { PiDownloadSimple } from 'react-icons/pi';
import { useNavigate } from 'react-router';
import { useCustomZoneBanner } from '../hooks/useCustomZoneBanner';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { countries } from '@/features/library/utils/countryMapping';
import EmptyZoneBanner from '@/features/Zones/components/EmptyZoneBanner';
import { useZoneTraffic } from '@/features/Zones/hooks/useZoneTraffic';
import BarSeriesChart from '@/shared/components/BarSeriesChart';
import ChartsDownloadDropDown from '@/shared/components/ChartsDownloadDropDown';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import CongestionTimeRangeDropdown from '@/shared/components/CongestionTimeRangeDropdown';
import CountryDropDown from '@/shared/components/CountryDrowdown';
import DonutChart from '@/shared/components/DonutChart';
import EntityActionButton from '@/shared/components/EntityActionButton';
import LineSeriesChart from '@/shared/components/LineSeriesChart';
import LoadingTemplate from '@/shared/components/LoadingTemplate';
import StatsSummary from '@/shared/components/StatsSummary';
import TimeDomainDropDown from '@/shared/components/TimeDomainDropDown';
import VesselClassDropDown from '@/shared/components/VesselClassDropDown';
import VesselTypesDropDown from '@/shared/components/VesselTypesDropDown';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';
import PoleStarEntityGrid from '@/shared/lib/PoleStarEntityGrid';
import { Zone } from '@/shared/types/entities';
import { getMovementValues } from '@/shared/utils/CongestionAndTrafficUtils';
import {
  buildBarSeriesCSV,
  buildDonutCSV,
  buildKeyMetricsCsv,
  buildLineSeriesCSV,
  buildTopVisitingVesselsCsv,
} from '@/shared/utils/exportChartsCsv';
import { sanitizeFilenameSegment } from '@/shared/utils/formatUtils';
import { createTopVisitingVesselsColDef } from '@/shared/utils/TopVisitingVesselsColDefs';
// import TabGroup from '@/shared/components/TabGroup';

export default function ZoneTraffic({ zone }: { zone: Zone }) {
  const {
    activeEntriesAndExitsTab,
    // setActiveArrivalsAndDeparturesTab,
    // arrivalsAndDeparturesTabs,
    vesselTypesOpts,
    selectedVesselType,
    selectedVesselClass,
    selectedCountries,
    hasSelectedVesselTypes,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleCountryToggle,
    setEntriesAndExitsTimeDomain,
    entriesAndExitsTimeDomain,
    entriesTimeDomain,
    setEntriesTimeDomain,
    setDateRange,
    entriesAndExitsByTotals,
    entriesByVesselTypesAndTotals,
    entriesByVesselTypes,
    fetchEntriesAndExitsByTotals,
    fetchEntriesByTotalsAndVesselType,
    fetchEntriesByVesselType,
    timeDomainDays,
    entriesAndExitsTimeDomainDisplay,
    entriesTimeDomainDisplay,
    isEntriesAndExitsByTotalsLoading,
    isEntriesByVesselTypesLoading,
    isEntriesByVesselTypesAndTotalsLoading,
    getTopVisitingVesselsServerSideData,
    topVisitingGridRef,
    isTopVisitingVesselsLoading,
    topVisitingVesselData,
    setDateRangeLabel,
    topVisitingVesselsResponse,
  } = useZoneTraffic();

  const showBanner = useCustomZoneBanner(zone);
  const { exportToCSV } = useLibrary();

  const navigate = useNavigate();

  const lineChartRef = useRef<PoleStarChartHandle>(null);
  const donutChartRef = useRef<PoleStarChartHandle>(null);
  const barChartRef = useRef<PoleStarChartHandle>(null);

  const [refresh, setRefresh] = useState(false);
  const totals = entriesByVesselTypesAndTotals?.totals;
  const movement = totals ? getMovementValues(totals) : null;

  const isLoading =
    isEntriesAndExitsByTotalsLoading ||
    isEntriesByVesselTypesLoading ||
    isEntriesByVesselTypesAndTotalsLoading ||
    isTopVisitingVesselsLoading;

  const startDates =
    entriesAndExitsByTotals?.query.date_start.split('T')[0] ||
    entriesByVesselTypes?.query.date_start.split('T')[0] ||
    entriesByVesselTypesAndTotals?.query.date_start.split('T')[0] ||
    topVisitingVesselsResponse?.query.date_start.split('T')[0];

  const endDates =
    entriesAndExitsByTotals?.query.date_end.split('T')[0] ||
    entriesByVesselTypes?.query.date_end.split('T')[0] ||
    entriesByVesselTypesAndTotals?.query.date_end.split('T')[0] ||
    topVisitingVesselsResponse?.query.date_end.split('T')[0];

  return (
    <div className="">
      <div className="flex flex-col">
        {!isLoading && showBanner && (
          <div className="pb-6">
            <EmptyZoneBanner />
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <CongestionTimeRangeDropdown
              key={`zone analytics time range drop down`}
              onChange={setDateRange}
              onLabelChange={setDateRangeLabel}
            />
            <CountryDropDown
              selected={selectedCountries}
              countriesOpts={countries}
              onToggle={handleCountryToggle}
              key={`zone vessel flags`}
            />
            <VesselTypesDropDown
              onToggle={handleVesselTypeToggle}
              vesselTypesOpts={
                vesselTypesOpts as unknown as {
                  value: string;
                  defaultChecked: boolean;
                  displayValue: string;
                }[]
              }
              selected={selectedVesselType}
              key={`zone vessel types`}
            />
            <div
              className={`${hasSelectedVesselTypes ? '' : 'opacity-50 grayscale'}`}
              style={{
                pointerEvents: hasSelectedVesselTypes ? 'auto' : 'none',
              }}
            >
              <VesselClassDropDown
                selectedVesselTypes={selectedVesselType}
                selected={selectedVesselClass}
                onToggle={handleVesselClassToggle}
                vesselTypeOrder={vesselTypesOpts}
              />
            </div>
          </div>
          <div className="mt-[18px] flex gap-2">
            <EntityActionButton
              icon={<LuRefreshCw className="text-gray-400" />}
              textLabel="Refresh"
              handleClick={async () => {
                setRefresh(true);
                await Promise.all([
                  fetchEntriesAndExitsByTotals(),
                  fetchEntriesByTotalsAndVesselType(),
                  fetchEntriesByVesselType(),
                  topVisitingGridRef.current?.refresh(),
                ]);
                setRefresh(false);
              }}
              refresh={refresh}
            />
            {/* <EntityActionButton
            icon={<PiDownloadSimple className="text-gray-400" />}
            textLabel="Export"
            handleClick={() => console.log('Clicked')}
          /> */}
          </div>
        </div>
        <div className="mt-4 flex gap-4">
          <div className="relative flex h-[410px] w-[360px] flex-col gap-4 rounded-lg bg-white p-4 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                Key Metrics
              </h2>
              <ChartsDownloadDropDown
                loading={isEntriesByVesselTypesAndTotalsLoading}
                hasData={
                  !!(
                    movement &&
                    (movement.inflow > 0 ||
                      movement.outflow > 0 ||
                      totals!.max_vessels_per_day > 0 ||
                      totals!.vessels_per_day > 0)
                  )
                }
                shouldShow={false}
                onExportCSV={() => {
                  const csv = buildKeyMetricsCsv(entriesByVesselTypesAndTotals);
                  if (csv)
                    exportToCSV(
                      csv,
                      sanitizeFilenameSegment(
                        `${zone.name}-key-metrics-${startDates}-${endDates}`,
                      ),
                    );
                }}
              />
            </div>
            {isEntriesByVesselTypesAndTotalsLoading ? (
              <LoadingTemplate />
            ) : movement &&
              (movement.inflow > 0 ||
                movement.outflow > 0 ||
                totals!.max_vessels_per_day > 0 ||
                totals!.vessels_per_day > 0) ? (
              <StatsSummary
                stats={[
                  {
                    label: 'Entries',
                    value: movement?.inflow,
                  },
                  {
                    label: 'Exits',
                    value: movement?.outflow,
                  },
                  {
                    label: 'Unique Entries per Day (avg)',
                    value: totals?.vessels_per_day,
                  },
                  {
                    label: 'Unique Entries per Day (max)',
                    value: totals?.max_vessels_per_day,
                  },
                ]}
              />
            ) : (
              <CongestionEmptyState />
            )}
          </div>
          <div className="flex h-[410px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Entries and Exits
                </h2>
                <p className="text-xs text-gray-500">
                  {activeEntriesAndExitsTab === 'Hourly Averages'
                    ? 'Average per hour of the day'
                    : `Totals per ${entriesAndExitsTimeDomainDisplay}`}
                </p>
              </div>
              <div className="flex gap-2">
                {activeEntriesAndExitsTab === 'Totals' && (
                  <TimeDomainDropDown
                    // paddingYaxis="py-3"
                    key={`Entries and Exits`}
                    onChange={(opt) => setEntriesAndExitsTimeDomain(opt.value)}
                    days={timeDomainDays}
                    value={entriesAndExitsTimeDomain}
                    isLoading={isEntriesAndExitsByTotalsLoading}
                  />
                )}
                {/* <div style={{ pointerEvents: 'none', opacity: 0.7 }}>
                <TabGroup
                  tabs={[...arrivalsAndDeparturesTabs]}
                  active={activeArrivalsAndDeparturesTab}
                  onChange={(tab: string) =>
                    setActiveArrivalsAndDeparturesTab(tab)
                  }
                  className="bg-white dark:bg-gray-800"
                />
              </div> */}
                <ChartsDownloadDropDown
                  loading={isEntriesAndExitsByTotalsLoading}
                  hasData={
                    !!entriesAndExitsByTotals &&
                    entriesAndExitsByTotals.data.length > 0
                  }
                  onExportImage={() =>
                    lineChartRef.current?.downloadImage(
                      sanitizeFilenameSegment(
                        `${zone.name}-traffic-entries-and-exits-per-${entriesAndExitsTimeDomainDisplay}-${startDates}-${endDates}`,
                      ),
                    )
                  }
                  onExportCSV={() => {
                    const csv = buildLineSeriesCSV(entriesAndExitsByTotals);
                    if (csv)
                      exportToCSV(
                        csv,
                        sanitizeFilenameSegment(
                          `${zone.name}-traffic-entries-and-exits-per-${entriesAndExitsTimeDomainDisplay}-${startDates}-${endDates}`,
                        ),
                      );
                  }}
                />
              </div>
            </div>
            <div className="relative mt-4 h-full">
              {isEntriesAndExitsByTotalsLoading ? (
                <LoadingTemplate />
              ) : entriesAndExitsByTotals &&
                entriesAndExitsByTotals.data.length > 0 ? (
                <LineSeriesChart
                  response={entriesAndExitsByTotals}
                  ref={lineChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
        </div>
        <div className="mb-4 mt-4 flex gap-4">
          <div className="flex h-[410px] w-[360px] flex-col rounded-lg bg-white p-4 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Entries
                </h2>
                <p className="text-xs text-gray-500">By Vessel Type, Totals</p>
              </div>
              <ChartsDownloadDropDown
                loading={isEntriesByVesselTypesAndTotalsLoading}
                hasData={
                  !!entriesByVesselTypesAndTotals &&
                  entriesByVesselTypesAndTotals.data[0]?.items?.length > 0
                }
                onExportImage={() =>
                  donutChartRef.current?.downloadImage(
                    sanitizeFilenameSegment(
                      `${zone.name}-traffic-entries-by-vessel-type-totals-${startDates}-${endDates}`,
                    ),
                  )
                }
                onExportCSV={() => {
                  const csv = buildDonutCSV(entriesByVesselTypesAndTotals);
                  if (csv)
                    exportToCSV(
                      csv,
                      sanitizeFilenameSegment(
                        `${zone.name}-traffic-entries-by-vessel-type-totals-${startDates}-${endDates}`,
                      ),
                    );
                }}
              />
            </div>
            <div className="relative mt-4 h-full">
              {isEntriesByVesselTypesAndTotalsLoading ? (
                <LoadingTemplate />
              ) : entriesByVesselTypesAndTotals &&
                entriesByVesselTypesAndTotals.data[0]?.items?.length > 0 ? (
                <DonutChart
                  response={entriesByVesselTypesAndTotals}
                  ref={donutChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
          <div className="flex h-[410px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Entries
                </h2>
                <p className="text-xs text-gray-500">
                  By Vessel Type, Per {entriesTimeDomainDisplay}
                </p>
              </div>
              <div className="flex gap-2">
                <TimeDomainDropDown
                  key={`Entries`}
                  onChange={(opt) => setEntriesTimeDomain(opt.value)}
                  days={timeDomainDays}
                  value={entriesTimeDomain}
                  isLoading={isEntriesByVesselTypesLoading}
                />
                <ChartsDownloadDropDown
                  loading={isEntriesByVesselTypesLoading}
                  hasData={
                    !!entriesByVesselTypes &&
                    entriesByVesselTypes.data.length > 0
                  }
                  onExportImage={() =>
                    barChartRef.current?.downloadImage(
                      sanitizeFilenameSegment(
                        `${zone.name}-traffic-entries-by-vessel-type-per-${entriesTimeDomainDisplay}-${startDates}-${endDates}`,
                      ),
                    )
                  }
                  onExportCSV={() => {
                    const csv = buildBarSeriesCSV(entriesByVesselTypes);
                    if (csv)
                      exportToCSV(
                        csv,
                        sanitizeFilenameSegment(
                          `${zone.name}-traffic-entries-by-vessel-type-per-${entriesTimeDomainDisplay}-${startDates}-${endDates}`,
                        ),
                      );
                  }}
                />
              </div>
            </div>
            <div className="relative mt-4 h-full">
              {isEntriesByVesselTypesLoading ? (
                <LoadingTemplate />
              ) : entriesByVesselTypes &&
                entriesByVesselTypes.data.length > 0 ? (
                <BarSeriesChart
                  response={entriesByVesselTypes}
                  ref={barChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
        </div>
        <div className="mb-6 flex h-[600px] flex-col gap-1 rounded-lg bg-white dark:bg-gray-800">
          <div className="flex items-center justify-between gap-1 px-6 py-4">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                Top Visiting Vessels{' '}
                {topVisitingVesselData &&
                  topVisitingVesselData.length > 0 &&
                  `(${topVisitingVesselData.length})`}
              </h2>
              <Tooltip
                content={`Showing repeat visiting vessels only. Single visit vessels are excluded.`}
                className="w-64 rounded text-xs"
                arrow={false}
                placement="bottom-start"
              >
                <FaCircleInfo className="h-3 w-3 text-gray-400" />
              </Tooltip>
            </div>
            <ChartsDownloadDropDown
              loading={isTopVisitingVesselsLoading}
              hasData={
                !!topVisitingVesselData && topVisitingVesselData.length > 0
              }
              shouldShow={false}
              onExportCSV={() => {
                const csv = buildTopVisitingVesselsCsv(topVisitingVesselData);
                if (csv)
                  exportToCSV(
                    csv,
                    sanitizeFilenameSegment(
                      `${zone.name}-top-visiting-vessels-${startDates}-${endDates}`,
                    ),
                  );
              }}
            />
          </div>
          <div className="min-h-0 flex-1 rounded-b-lg bg-white dark:bg-gray-800">
            <div className="h-full">
              <PoleStarEntityGrid
                ref={topVisitingGridRef}
                columns={createTopVisitingVesselsColDef()}
                getServerSideData={getTopVisitingVesselsServerSideData}
                storageKey="zone-top-visiting-vessels"
                onRowClick={(event) => {
                  const data = event.data;
                  if (!data?.imo_number) return;
                  navigate(`/analytics/vessel/${data.imo_number}`);
                }}
                isSideBar={false}
                roundedTop={false}
                noRowsOverlay={`
            <div class="flex items-center justify-center h-full text-gray-500 text-base">
              No recurring vessels found for the selected period
            </div>
          `}
                pageSize={20}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
