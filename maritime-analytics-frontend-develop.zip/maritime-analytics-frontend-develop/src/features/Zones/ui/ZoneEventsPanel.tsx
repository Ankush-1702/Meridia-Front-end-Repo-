import { ColDef } from 'ag-grid-enterprise';
import { FlatZoneEventsResponse } from '@/features/Zones/types/zoneTypes';
import NewEventsPanel from '@/shared/ui/NewEventsPanel';

interface ZoneEventsPanelProps {
  zoneName?: string;
  zoneId: string;
  zoneEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  buildColumns: (timezone: string) => ColDef[];
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatZoneEventsResponse) => void;
}

export function ZoneEventsPanel({
  zoneEventsTabs,
  storageKey,
  onSelectAll,
  selected,
  onToggle,
  rows,
  refresh,
  setRefresh,
  buildColumns,
  lastUpdated,
  isLoading,
  onRowClick,
  zoneId,
}: ZoneEventsPanelProps) {
  return (
    <NewEventsPanel
      eventsTabs={zoneEventsTabs}
      selected={selected}
      onToggle={onToggle}
      onSelectAll={onSelectAll}
      rows={rows}
      refresh={refresh}
      setRefresh={setRefresh}
      buildColumns={buildColumns}
      storageKey={storageKey}
      lastUpdated={lastUpdated}
      isLoading={isLoading}
      onRowClick={onRowClick}
      entityType="zone"
      entityId={zoneId}
    />
  );
}
