import { act, render, screen, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import ZoneEventsTab from '../ZoneEventsTab';
import type { FlatZoneEventsResponse } from '@/features/Zones/types/zoneTypes';
import type { ZoneEvents } from '@/features/Zones/types/zoneTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const navigateMock = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => navigateMock,
}));

const fetchZoneEventsMock = vi.fn();

vi.mock('@/features/Zones/services/zoneServices', () => ({
  fetchZoneEvents: (...args: unknown[]) => fetchZoneEventsMock(...args),
}));

vi.mock('@/features/Zones/utils/ColDefs', () => ({
  createZoneEventsColDefs: vi.fn(),
}));

interface CapturedZoneEventsPanelProps {
  zoneName?: string;
  zoneId: string;
  zoneEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: FlatZoneEventsResponse[];
  buildColumns: unknown;
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatZoneEventsResponse) => void;
}

let capturedProps: CapturedZoneEventsPanelProps | undefined;

vi.mock('@/features/Zones/ui/ZoneEventsPanel', () => ({
  ZoneEventsPanel: (props: CapturedZoneEventsPanelProps) => {
    capturedProps = props;
    return <div>ZoneEventsPanel</div>;
  },
}));

/* ------------------------------------------------------------------ */
/* fixtures                                                           */
/* ------------------------------------------------------------------ */

const zoneEventsTabs = [
  { label: 'Entries', value: 'ZONE_ENTRY' },
  { label: 'Exits', value: 'ZONE_EXIT' },
];

function buildZoneEvent(overrides: Partial<ZoneEvents> = {}): ZoneEvents {
  return {
    vessel_information: {
      asset_id: 'asset-1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NO',
      imo: '1234567',
      mmsi: '987654321',
      name: 'Test Vessel',
      vessel_type: 'Cargo',
    },
    event_details: {
      course: 90,
      draught: 5.5,
      event_id: 'event-1',
      event_timestamp: '2023-01-01T00:00:00Z',
      event_type: 'ZONE_ENTRY',
      heading: 180,
      latitude: 10.1,
      longitude: 20.2,
      navigational_status: { status: 'Under way', code: 0 },
      reported_destination: 'Rotterdam',
      reported_eta: '2023-01-02T00:00:00Z',
      speed: 12.5,
    },
    ...overrides,
  } as ZoneEvents;
}

const defaultProps = {
  zoneId: 'zone-1',
  zoneName: 'Test Zone',
  refresh: false,
  setRefresh: vi.fn(),
  dateRange: { start: '2023-01-01', end: '2023-01-31' },
  onDateRangeChange: vi.fn(),
  activeEventsTab: 'ZONE_ENTRY',
  setActiveEventsTab: vi.fn(),
  zoneEventsTabs,
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('ZoneEventsTab', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    capturedProps = undefined;
    fetchZoneEventsMock.mockResolvedValue({
      data: [
        buildZoneEvent({
          event_details: {
            ...buildZoneEvent().event_details,
            event_id: 'event-1',
            event_timestamp: '2023-01-01T00:00:00Z',
            event_type: 'ZONE_ENTRY',
          },
        }),
        buildZoneEvent({
          event_details: {
            ...buildZoneEvent().event_details,
            event_id: 'event-2',
            event_timestamp: '2023-01-02T00:00:00Z',
            event_type: 'ZONE_EXIT',
          },
        }),
      ],
      totalCount: 2,
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('fetches zone events on mount with a 90 day window and default paging', async () => {
    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(fetchZoneEventsMock).toHaveBeenCalledTimes(1));

    const [zoneId, start, end, offset, limit] =
      fetchZoneEventsMock.mock.calls[0];
    expect(zoneId).toBe('zone-1');
    expect(offset).toBe(0);
    expect(limit).toBe(500);
    expect(new Date(end).getTime() - new Date(start).getTime()).toBeCloseTo(
      24 * 60 * 60 * 1000 * 90,
      -6,
    );
  });

  it('flattens and sorts fetched rows by timestamp descending', async () => {
    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    expect(capturedProps?.rows[0].eventId).toBe('event-2');
    expect(capturedProps?.rows[1].eventId).toBe('event-1');
  });

  it('polls for new events every 5 minutes', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });

    render(<ZoneEventsTab {...defaultProps} />);

    await vi.waitFor(() =>
      expect(fetchZoneEventsMock).toHaveBeenCalledTimes(1),
    );

    await act(async () => {
      vi.advanceTimersByTime(5 * 60 * 1000);
    });

    await vi.waitFor(() =>
      expect(fetchZoneEventsMock).toHaveBeenCalledTimes(2),
    );
  });

  it('manually refreshes when refresh becomes true', async () => {
    const { rerender } = render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(fetchZoneEventsMock).toHaveBeenCalledTimes(1));

    rerender(<ZoneEventsTab {...defaultProps} refresh={true} />);

    await waitFor(() => expect(fetchZoneEventsMock).toHaveBeenCalledTimes(2));
    expect(defaultProps.setRefresh).toHaveBeenCalledWith(false);
  });

  it('filters cached rows client-side based on selected event types', async () => {
    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    await act(async () => {
      capturedProps?.onToggle('ZONE_EXIT', false);
    });

    await waitFor(() => {
      expect(capturedProps?.rows).toHaveLength(1);
      expect(capturedProps?.rows[0].eventType).toBe('ZONE_ENTRY');
    });
  });

  it('slices cached rows to the first 500 after filtering', async () => {
    const manyEvents = Array.from({ length: 1500 }, (_, i) =>
      buildZoneEvent({
        event_details: {
          ...buildZoneEvent().event_details,
          event_id: `event-${i}`,
          event_timestamp: new Date(2023, 0, 1, 0, 0, i).toISOString(),
          event_type: 'ZONE_ENTRY',
        },
      }),
    );
    fetchZoneEventsMock.mockResolvedValue({
      data: manyEvents,
      totalCount: 1500,
    });

    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(500));

    await act(async () => {
      capturedProps?.onToggle('ZONE_EXIT', false);
    });

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(500));
  });

  it('navigates to the vessel page using the flat imo field on row click', async () => {
    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    capturedProps?.onRowClick?.(capturedProps.rows[0]);

    expect(navigateMock).toHaveBeenCalledWith(
      `/analytics/vessel/${capturedProps?.rows[0].imo}`,
    );
  });

  it('renders ZoneEventsPanel with the expected wiring props', async () => {
    render(<ZoneEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps).toBeDefined());

    expect(screen.getByText('ZoneEventsPanel')).toBeInTheDocument();
    expect(capturedProps?.zoneId).toBe('zone-1');
    expect(capturedProps?.zoneName).toBe('Test Zone');
    expect(capturedProps?.zoneEventsTabs).toEqual(zoneEventsTabs);
    expect(capturedProps?.storageKey).toBe('zone-events');
  });
});
