import { render } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { FlatZoneEventsResponse } from '@/features/Zones/types/zoneTypes';
import { ZoneEventsPanel } from '@/features/Zones/ui/ZoneEventsPanel';

/* ------------------------------------------------------------------ */
/* typed NewEventsPanel mock                                          */
/* ------------------------------------------------------------------ */

interface NewEventsPanelProps {
  eventsTabs: { label: string; value: string }[];
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  buildColumns: (timezone: string) => unknown;
  storageKey?: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatZoneEventsResponse) => void;
}

let capturedProps: NewEventsPanelProps | undefined;

vi.mock('@/shared/ui/NewEventsPanel', () => ({
  default: (props: NewEventsPanelProps) => {
    capturedProps = props;
    return <div>NewEventsPanel</div>;
  },
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

const zoneEventsTabs = [
  { label: 'Entries', value: 'ZONE_ENTRY' },
  { label: 'Exits', value: 'ZONE_EXIT' },
];

const rows: FlatZoneEventsResponse[] = [
  { imo: '1234567', vesselName: 'Test Vessel', eventType: 'ZONE_ENTRY' },
];

const buildColumns = vi.fn();
const onToggle = vi.fn();
const onSelectAll = vi.fn();
const onRowClick = vi.fn();
const setRefresh = vi.fn();

const defaultProps = {
  zoneName: 'Test Zone',
  zoneId: 'zone-1',
  zoneEventsTabs,
  refresh: false,
  setRefresh,
  selected: { ZONE_ENTRY: true, ZONE_EXIT: true },
  onToggle,
  onSelectAll,
  rows,
  buildColumns,
  storageKey: 'zone-events',
  lastUpdated: new Date('2023-01-01T00:00:00Z'),
  isLoading: false,
  onRowClick,
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('ZoneEventsPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    capturedProps = undefined;
  });

  it('renders NewEventsPanel', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps).toBeDefined();
  });

  it('forwards eventsTabs as zoneEventsTabs', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps?.eventsTabs).toEqual(zoneEventsTabs);
  });

  it('forwards selected, onToggle, and onSelectAll', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps?.selected).toEqual({
      ZONE_ENTRY: true,
      ZONE_EXIT: true,
    });
    expect(capturedProps?.onToggle).toBe(onToggle);
    expect(capturedProps?.onSelectAll).toBe(onSelectAll);
  });

  it('forwards rows and buildColumns', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps?.rows).toBe(rows);
    expect(capturedProps?.buildColumns).toBe(buildColumns);
  });

  it('forwards refresh and setRefresh', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps?.refresh).toBe(false);
    expect(capturedProps?.setRefresh).toBe(setRefresh);
  });

  it('forwards storageKey, lastUpdated, and isLoading', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    expect(capturedProps?.storageKey).toBe('zone-events');
    expect(capturedProps?.lastUpdated).toEqual(
      new Date('2023-01-01T00:00:00Z'),
    );
    expect(capturedProps?.isLoading).toBe(false);
  });

  it('forwards onRowClick and invokes it with the flat row shape', () => {
    render(<ZoneEventsPanel {...defaultProps} />);

    capturedProps?.onRowClick?.(rows[0]);

    expect(onRowClick).toHaveBeenCalledWith(rows[0]);
  });
});
