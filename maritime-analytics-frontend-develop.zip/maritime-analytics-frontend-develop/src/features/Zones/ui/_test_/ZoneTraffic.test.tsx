import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import * as useZoneTrafficModule from '@/features/Zones/hooks/useZoneTraffic';
import ZoneTraffic from '@/features/Zones/ui/ZoneTraffic';
import { Zone } from '@/shared/types/entities';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

vi.mock('react-router', () => ({
  useNavigate: () => vi.fn(),
}));

vi.mock('@/features/Zones/hooks/useZoneTraffic');

vi.mock('@/features/Zones/hooks/useCustomZoneBanner', () => ({
  useCustomZoneBanner: vi.fn(() => false),
}));

vi.mock('@/features/Zones/components/EmptyZoneBanner', () => ({
  default: () => <div>Empty Zone Banner</div>,
}));

vi.mock('@/shared/components/BarSeriesChart', () => ({
  default: ({ response }: { response: ICongestionResponse }) => (
    <div>BarSeriesChart - {response.data.length} data points</div>
  ),
}));

vi.mock('@/shared/components/ChartsDownloadDropDown', () => ({
  default: () => <div>Download Dropdown</div>,
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    exportToCSV: vi.fn(),
  }),
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>Empty State</div>,
}));

vi.mock('@/shared/components/CongestionTimeRangeDropdown', () => ({
  default: ({
    onChange,
  }: {
    onChange: (range: { start: string; end: string }) => void;
  }) => (
    <button
      onClick={() => onChange({ start: '2026-01-01', end: '2026-03-01' })}
    >
      Time Range Dropdown
    </button>
  ),
}));

vi.mock('@/shared/components/CountryDrowdown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (country: string, checked: boolean) => void;
  }) => <button onClick={() => onToggle('US', true)}>Country Dropdown</button>,
}));

vi.mock('@/shared/components/DonutChart', () => ({
  default: ({ response }: { response: ICongestionResponse }) => (
    <div>DonutChart - {response.data[0]?.items.length} items</div>
  ),
}));

vi.mock('@/shared/components/LineSeriesChart', () => ({
  default: ({ response }: { response: ICongestionResponse }) => (
    <div>LineSeriesChart - {response.data.length} data points</div>
  ),
}));

vi.mock('@/shared/components/LoadingTemplate', () => ({
  default: () => <div>Loading...</div>,
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: ({ stats }: { stats: { label: string; value: number }[] }) => (
    <div>
      {stats.map((stat) => (
        <div key={stat.label}>
          {stat.label}: {stat.value}
        </div>
      ))}
    </div>
  ),
}));

vi.mock('@/shared/components/TimeDomainDropDown', () => ({
  default: ({
    onChange,
    value,
  }: {
    onChange: (opt: { value: string }) => void;
    value: string;
  }) => (
    <button onClick={() => onChange({ value: 'Weekly' })}>
      Time Domain: {value}
    </button>
  ),
}));

vi.mock('@/shared/components/VesselClassDropDown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (key: string, checked: boolean) => void;
  }) => (
    <button onClick={() => onToggle('Bulk carrier::Handysize', true)}>
      Vessel Class Dropdown
    </button>
  ),
}));

vi.mock('@/shared/components/VesselTypesDropDown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (type: string, checked: boolean) => void;
  }) => (
    <button onClick={() => onToggle('Bulk carrier', true)}>
      Vessel Types Dropdown
    </button>
  ),
}));

vi.mock('@/features/library/utils/countryMapping', () => ({
  countries: { All: 'All Countries', US: 'United States' },
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    textLabel,
    handleClick,
  }: {
    textLabel: string;
    handleClick: () => void;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: vi.fn(() => <div>Entity Grid</div>),
}));

vi.mock('@/shared/utils/TopVisitingVesselsColDefs', () => ({
  createTopVisitingVesselsColDef: vi.fn(() => []),
}));

describe('ZoneTraffic', () => {
  const mockCongestionResponse: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-01-01',
      date_end: '2026-03-01',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: {
      id: 'zone-123',
      name: 'Test Zone',
      zone_type: 'EEZ',
      zone_sub_type: 'National',
      country_common_name: 'Test Country',
    },
    totals: {
      entries: 300,
      exits: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', entries: 10, exits: 8 }],
      },
    ],
  };

  const mockFetchEntriesAndExitsByTotals = vi.fn().mockResolvedValue(undefined);
  const mockFetchEntriesByTotalsAndVesselType = vi
    .fn()
    .mockResolvedValue(undefined);
  const mockFetchEntriesByVesselType = vi.fn().mockResolvedValue(undefined);
  const mockSetEntriesAndExitsTimeDomain = vi.fn();
  const mockSetEntriesTimeDomain = vi.fn();
  const mockSetDateRange = vi.fn();
  const mockHandleVesselTypeToggle = vi.fn();
  const mockHandleVesselClassToggle = vi.fn();
  const mockHandleCountryToggle = vi.fn();

  const mockZone: Zone = {
    id: 'zone-123',
    name: 'Test Zone',
    type: 'EEZ',
    sub_type: 'National',
    country_code: 'US',
    country_common_name: 'United States',
    country_official_name: 'United States of America',
    description: '',
    centroid: { longitude: 0, latitude: 0 },
    sub_division_code: '',
    sub_division_name: '',
    wpi_number: null,
  };

  const defaultHookReturn = {
    activeEntriesAndExitsTab: 'Totals',
    setActiveEntriesAndExitsTab: vi.fn(),
    entriesAndExitsTabs: ['Totals'],
    vesselTypesOpts: [
      {
        value: 'Bulk carrier',
        defaultChecked: true,
        displayValue: 'Bulk Carrier',
      },
    ],
    selectedVesselType: { 'Bulk carrier': true },
    selectedVesselClass: { 'Bulk carrier::Handysize': true },
    selectedCountries: { All: true },
    hasSelectedVesselTypes: true,
    handleVesselTypeToggle: mockHandleVesselTypeToggle,
    handleVesselClassToggle: mockHandleVesselClassToggle,
    handleCountryToggle: mockHandleCountryToggle,
    setEntriesAndExitsTimeDomain: mockSetEntriesAndExitsTimeDomain,
    entriesAndExitsTimeDomain: 'Daily',
    entriesTimeDomain: 'Daily',
    setEntriesTimeDomain: mockSetEntriesTimeDomain,
    setDateRange: mockSetDateRange,
    entriesAndExitsByTotals: mockCongestionResponse,
    entriesByVesselTypesAndTotals: mockCongestionResponse,
    entriesByVesselTypes: mockCongestionResponse,
    fetchEntriesAndExitsByTotals: mockFetchEntriesAndExitsByTotals,
    fetchEntriesByTotalsAndVesselType: mockFetchEntriesByTotalsAndVesselType,
    fetchEntriesByVesselType: mockFetchEntriesByVesselType,
    timeDomainDays: 60,
    entriesAndExitsTimeDomainDisplay: 'Day',
    entriesTimeDomainDisplay: 'Day',
    isEntriesAndExitsByTotalsLoading: false,
    isEntriesByVesselTypesLoading: false,
    isEntriesByVesselTypesAndTotalsLoading: false,
    topVisitingGridRef: { current: null },
    getTopVisitingVesselsServerSideData: vi.fn(),
    topVisitingVesselData: [
      {
        vessel_name: 'TEST VESSEL',
        imo_number: '1234567',
        flag_code: 'US',
        flag_name: 'United States',
        ship_type_level_3: 'Bulk carrier',
        visit_count: 5,
      },
    ],
    isTopVisitingVesselsLoading: false,
    dateRangeLabel: 'Previous 30 Days' as const,
    setDateRangeLabel: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue(
      defaultHookReturn,
    );
  });

  describe('rendering', () => {
    it('should render all dropdowns', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Time Range Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Country Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Vessel Types Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Vessel Class Dropdown')).toBeInTheDocument();
    });

    it('should render refresh button', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Refresh')).toBeInTheDocument();
    });

    it('should render stats summary when data is available', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Entries: 300')).toBeInTheDocument();
      expect(screen.getByText('Exits: 280')).toBeInTheDocument();
      expect(
        screen.getByText('Unique Entries per Day (avg): 20'),
      ).toBeInTheDocument();
      expect(
        screen.getByText('Unique Entries per Day (max): 45'),
      ).toBeInTheDocument();
    });

    it('should render charts when data is available', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(
        screen.getByText('LineSeriesChart - 1 data points'),
      ).toBeInTheDocument();
      expect(screen.getByText('DonutChart - 1 items')).toBeInTheDocument();
      expect(
        screen.getByText('BarSeriesChart - 1 data points'),
      ).toBeInTheDocument();
    });

    it('should render section headings', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Entries and Exits')).toBeInTheDocument();
      expect(screen.getAllByText('Entries')).toHaveLength(2);
    });

    it('should render Top Visiting Vessels section', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText(/Top Visiting Vessels/)).toBeInTheDocument();
      expect(screen.getByText('Entity Grid')).toBeInTheDocument();
    });
  });

  describe('loading states', () => {
    it('should show loading template when entries and exits by totals is loading', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        isEntriesAndExitsByTotalsLoading: true,
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should show loading template when entries by vessel types is loading', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        isEntriesByVesselTypesLoading: true,
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should show loading template when entries by vessel types and totals is loading', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        isEntriesByVesselTypesAndTotalsLoading: true,
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getAllByText('Loading...')).toHaveLength(2);
    });
  });

  describe('empty states', () => {
    it('should show empty state when entries and exits data is empty', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        entriesAndExitsByTotals: { ...mockCongestionResponse, data: [] },
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when entries by vessel types data is empty', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        entriesByVesselTypes: { ...mockCongestionResponse, data: [] },
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when data is undefined', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        entriesAndExitsByTotals: undefined,
        entriesByVesselTypesAndTotals: undefined,
        entriesByVesselTypes: undefined,
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        3,
      );
    });
  });

  describe('interactions', () => {
    it('should call setDateRange when time range dropdown changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      fireEvent.click(screen.getByText('Time Range Dropdown'));

      expect(mockSetDateRange).toHaveBeenCalledWith({
        start: '2026-01-01',
        end: '2026-03-01',
      });
    });

    it('should call handleCountryToggle when country dropdown changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      fireEvent.click(screen.getByText('Country Dropdown'));

      expect(mockHandleCountryToggle).toHaveBeenCalledWith('US', true);
    });

    it('should call handleVesselTypeToggle when vessel types dropdown changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      fireEvent.click(screen.getByText('Vessel Types Dropdown'));

      expect(mockHandleVesselTypeToggle).toHaveBeenCalledWith(
        'Bulk carrier',
        true,
      );
    });

    it('should call handleVesselClassToggle when vessel class dropdown changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      fireEvent.click(screen.getByText('Vessel Class Dropdown'));

      expect(mockHandleVesselClassToggle).toHaveBeenCalledWith(
        'Bulk carrier::Handysize',
        true,
      );
    });

    it('should call setEntriesAndExitsTimeDomain when time domain dropdown changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      fireEvent.click(timeDomainButtons[0]);

      expect(mockSetEntriesAndExitsTimeDomain).toHaveBeenCalledWith('Weekly');
    });

    it('should call all fetch functions when refresh button is clicked', async () => {
      render(<ZoneTraffic zone={mockZone} />);

      fireEvent.click(screen.getByText('Refresh'));

      await waitFor(() => {
        expect(mockFetchEntriesAndExitsByTotals).toHaveBeenCalled();
        expect(mockFetchEntriesByTotalsAndVesselType).toHaveBeenCalled();
        expect(mockFetchEntriesByVesselType).toHaveBeenCalled();
      });
    });
  });

  describe('conditional rendering', () => {
    it('should disable vessel class dropdown when no vessel types are selected', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        hasSelectedVesselTypes: false,
      });

      render(<ZoneTraffic zone={mockZone} />);

      const vesselClassButton = screen.getByText('Vessel Class Dropdown');
      expect(vesselClassButton.closest('div')).toHaveStyle({
        pointerEvents: 'none',
      });
    });

    it('should show time domain dropdown for Totals tab', () => {
      render(<ZoneTraffic zone={mockZone} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      expect(timeDomainButtons.length).toBeGreaterThanOrEqual(2);
    });

    it('should show correct subtitle for Totals tab', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('Totals per Day')).toBeInTheDocument();
    });

    it('should show correct subtitle for Hourly Averages tab', () => {
      (useZoneTrafficModule.useZoneTraffic as Mock).mockReturnValue({
        ...defaultHookReturn,
        activeEntriesAndExitsTab: 'Hourly Averages',
      });

      render(<ZoneTraffic zone={mockZone} />);

      expect(
        screen.getByText('Average per hour of the day'),
      ).toBeInTheDocument();
    });
  });

  describe('entries section', () => {
    it('should render entries donut chart section heading', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('By Vessel Type, Totals')).toBeInTheDocument();
    });

    it('should render entries bar chart section heading with time domain', () => {
      render(<ZoneTraffic zone={mockZone} />);

      expect(screen.getByText('By Vessel Type, Per Day')).toBeInTheDocument();
    });

    it('should call setEntriesTimeDomain when entries time domain changes', () => {
      render(<ZoneTraffic zone={mockZone} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      fireEvent.click(timeDomainButtons[1]);

      expect(mockSetEntriesTimeDomain).toHaveBeenCalledWith('Weekly');
    });
  });
});
