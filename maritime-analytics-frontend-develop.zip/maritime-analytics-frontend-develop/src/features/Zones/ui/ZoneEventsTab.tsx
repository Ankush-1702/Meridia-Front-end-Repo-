import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { fetchZoneEvents } from '@/features/Zones/services/zoneServices';
import { FlatZoneEventsResponse } from '@/features/Zones/types/zoneTypes';
import { ZoneEventsPanel } from '@/features/Zones/ui/ZoneEventsPanel';
import { createZoneEventsColDefs } from '@/features/Zones/utils/ColDefs';
import { flattenZoneEvents } from '@/features/Zones/utils/zoneUtils';
import { clampEnd } from '@/shared/utils/formatUtils';

interface ZoneEventsTabProps {
  zoneId: string;
  zoneName: string;
  refresh: boolean;
  setRefresh: (val: boolean) => void;
  zoneEventsTabs: { label: string; value: string }[];
}

const zoneEventsCache = new Map<string, FlatZoneEventsResponse[]>();

export default function ZoneEventsTab({
  zoneId,
  zoneName,
  refresh,
  setRefresh,
  zoneEventsTabs,
}: ZoneEventsTabProps) {
  const navigate = useNavigate();
  const [rows, setRows] = useState<FlatZoneEventsResponse[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const initialSelected = zoneEventsTabs.reduce<Record<string, boolean>>(
    (acc, tab) => ({ ...acc, [tab.value]: true }),
    {},
  );

  const columnStorageKey = `zone-events`;
  const [selected, setSelected] =
    useState<Record<string, boolean>>(initialSelected);

  const onToggle = useCallback((value: string, checked: boolean) => {
    setSelected((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const onSelectAll = useCallback(
    (checked: boolean) => {
      setSelected(
        zoneEventsTabs.reduce<Record<string, boolean>>(
          (acc, tab) => ({ ...acc, [tab.value]: checked }),
          {},
        ),
      );
    },
    [zoneEventsTabs],
  );

  const selectedValues = useMemo(
    () => Object.keys(selected).filter((key) => selected[key]),
    [selected],
  );

  const selectedValuesRef = useRef(selectedValues);

  useEffect(() => {
    selectedValuesRef.current = selectedValues;
  }, [selectedValues]);

  const getZoneEvents = useCallback(async () => {
    if (!zoneId) return;

    setIsLoading(true);

    const now = new Date();
    const timeStampStart =
      new Date(now.getTime() - 24 * 60 * 60 * 1000 * 90)
        .toISOString()
        .split('.')[0] + 'Z';
    const timeStampEnd =
      clampEnd(now, 60, new Date()).toISOString().split('.')[0] + 'Z';

    try {
      const zoneEvents = await fetchZoneEvents(
        zoneId,
        timeStampStart,
        timeStampEnd,
        0,
        500,
      );
      const flattenedZoneEvents = flattenZoneEvents(zoneEvents.data);
      const combined = flattenedZoneEvents.sort((a, b) => {
        const dateA = a.eventTimestamp
          ? new Date(a.eventTimestamp).getTime()
          : 0;
        const dateB = b.eventTimestamp
          ? new Date(b.eventTimestamp).getTime()
          : 0;
        return dateB - dateA;
      });

      zoneEventsCache.set(zoneId, combined);

      const currentSelectedValues = selectedValuesRef.current;
      const filtered = combined
        .filter(
          (row) =>
            row.eventType && currentSelectedValues.includes(row.eventType),
        )
        .slice(0, 500);

      setRows(filtered);
      setLastUpdated(new Date());
    } catch {
      setRows([]);
    } finally {
      setIsLoading(false);
      setRefresh(false);
    }
  }, [zoneId, setRefresh]);

  useEffect(() => {
    getZoneEvents();
  }, [getZoneEvents]);

  useEffect(() => {
    const interval = setInterval(
      () => {
        getZoneEvents();
      },
      5 * 60 * 1000,
    );

    return () => clearInterval(interval);
  }, [getZoneEvents]);

  // Manual refresh trigger
  useEffect(() => {
    if (refresh) {
      getZoneEvents();
    }
  }, [refresh, getZoneEvents]);

  useEffect(() => {
    const cached = zoneEventsCache.get(zoneId);
    if (cached) {
      const filtered = cached
        .filter(
          (row) => row.eventType && selectedValues.includes(row.eventType),
        )
        .slice(0, 500);
      setRows(filtered);
    }
  }, [selectedValues, zoneId]);

  return (
    <div className="h-[calc(100dvh-135px)]">
      <ZoneEventsPanel
        refresh={refresh}
        zoneName={zoneName}
        zoneId={zoneId}
        zoneEventsTabs={zoneEventsTabs}
        setRefresh={setRefresh}
        selected={selected}
        onToggle={onToggle}
        onSelectAll={onSelectAll}
        rows={rows}
        buildColumns={createZoneEventsColDefs}
        storageKey={columnStorageKey}
        lastUpdated={lastUpdated}
        isLoading={isLoading}
        onRowClick={(ev) => navigate(`/analytics/vessel/${ev.imo}`)}
      />
    </div>
  );
}
