import { useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { countries } from '@/features/library/utils/countryMapping';
import {
  getEntriesAndExitsByTotals,
  getEntriesByVesselType,
  getEntriesByVesselTypesAndTotals,
  getTopVisitingVessels,
} from '@/features/Zones/services/zoneTrafficApi';
import { CongestionTimeRangePreset } from '@/shared/components/CongestionTimeRangeDropdown';
import { useDebouncedEffect } from '@/shared/hooks/useDebouncedEffect';
import { useTopVisitingVessels } from '@/shared/hooks/useTopVisitingVessels';
import {
  ICongestionResponse,
  PeriodAggregation,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import {
  buildClassEntries,
  classKey,
  getSelectedFilters,
  VesselClassData,
} from '@/shared/utils/CongestionAndTrafficUtils';

const TIME_DOMAIN_KEY_TO_VALUE: Record<string, string> = {
  Day: 'Daily',
  Week: 'Weekly',
  Month: 'Monthly',
  Quarter: 'Quarterly',
};

const TIME_DOMAIN_VALUE_TO_KEY: Record<string, string> = Object.fromEntries(
  Object.entries(TIME_DOMAIN_KEY_TO_VALUE).map(([k, v]) => [v, k]),
);

export function getEnabledTimeDomainKeys(
  startIso: string,
  endIso: string,
): string[] {
  if (!startIso || !endIso) return ['Day'];
  const start = new Date(startIso.split('T')[0]);
  const end = new Date(endIso.split('T')[0]);
  const days = Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1;
  if (days <= 7) return ['Day'];
  if (days <= 60) return ['Day', 'Week'];
  if (days <= 90) return ['Day', 'Week', 'Month'];
  return ['Day', 'Week', 'Month', 'Quarter'];
}

function clampTimeDomain(current: string, enabledKeys: string[]): string {
  const currentKey = TIME_DOMAIN_VALUE_TO_KEY[current] ?? current;
  if (enabledKeys.includes(currentKey)) return current;
  const fallbackKey = enabledKeys[0] ?? 'Day';
  return TIME_DOMAIN_KEY_TO_VALUE[fallbackKey] ?? 'Daily';
}

export function useZoneTraffic() {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const vesselTypesOpts = [
    {
      value: 'Bulk carrier',
      defaultChecked: true,
      displayValue: 'Bulk Carrier',
    },
    {
      value: 'Bulk/Oil carrier',
      defaultChecked: true,
      displayValue: 'Bulk/Oil Carrier',
    },
    {
      value: 'Chemical Tanker',
      defaultChecked: true,
      displayValue: 'Chemical Tanker',
    },
    {
      value: 'Container (FC)',
      defaultChecked: true,
      displayValue: 'Container (FC)',
    },
    {
      value: 'Dry Cargo Barge',
      defaultChecked: true,
      displayValue: 'Dry Cargo Barge',
    },
    {
      value: 'Fish Processing',
      defaultChecked: true,
      displayValue: 'Fish Processing',
    },
    {
      value: 'General cargo',
      defaultChecked: true,
      displayValue: 'General Cargo',
    },
    {
      value: 'Liquified gas carrier',
      defaultChecked: true,
      displayValue: 'Liquified Gas Carrier (LNG)',
    },
    {
      value: 'Offshore production/support',
      defaultChecked: true,
      displayValue: 'Offshore Production/Support',
    },
    { value: 'Oil Tanker', defaultChecked: true, displayValue: 'Oil Tanker' },
    {
      value: 'Other tanker',
      defaultChecked: true,
      displayValue: 'Other Tanker',
    },
    {
      value: 'Other types',
      defaultChecked: true,
      displayValue: 'Other Types',
    },
    { value: 'Passenger', defaultChecked: true, displayValue: 'Passenger' },
    {
      value: 'Specialsed Carrier',
      defaultChecked: true,
      displayValue: 'Specialised Carrier',
    },
    { value: 'Tank Barge', defaultChecked: true, displayValue: 'Tank Barge' },
    { value: 'Tow-Boat', defaultChecked: true, displayValue: 'Tow Boat' },
  ] as const;
  const entriesAndExitsTabs = ['Totals'] as const;
  const [activeEntriesAndExitsTab, setActiveEntriesAndExitsTab] =
    useState('Totals');

  const [selectedVesselType, _setSelectedVesselType] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('ZoneSelectedVesselType');
    if (stored) return JSON.parse(stored);
    return vesselTypesOpts.reduce<Record<string, boolean>>((acc, v) => {
      acc[v.value] = v.defaultChecked;
      return acc;
    }, {});
  });

  const [dateRangeLabel, setDateRangeLabel] =
    useState<CongestionTimeRangePreset>('Previous 30 Days');

  const [selectedCountries, _setSelectedCountries] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('ZoneSelectedCountries');
    if (stored) return JSON.parse(stored);
    return Object.keys(countries).reduce<Record<string, boolean>>(
      (acc, code) => {
        acc[code] = true;
        return acc;
      },
      {},
    );
  });

  const [selectedVesselClass, _setSelectedVesselClass] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('ZoneSelectedVesselClass');
    if (stored) return JSON.parse(stored);
    const acc: Record<string, boolean> = {};
    vesselTypesOpts.forEach(({ value, defaultChecked }) => {
      if (defaultChecked && VesselClassData[value]) {
        VesselClassData[value].forEach(({ className }) => {
          acc[classKey(value, className)] = true;
        });
      }
    });
    return acc;
  });

  const [entriesAndExitsTimeDomain, _setEntriesAndExitsTimeDomain] = useState(
    () => {
      return localStorage.getItem('entriesAndExitsTimeDomain') ?? 'Daily';
    },
  );

  const [entriesTimeDomain, _setEntriesTimeDomain] = useState(() => {
    return localStorage.getItem('entriesTimeDomain') ?? 'Daily';
  });

  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const [entriesAndExitsByTotals, setEntriesAndExitsByTotals] = useState<
    ICongestionResponse | undefined
  >(undefined);

  const [entriesByVesselTypes, setentriesByVesselTypes] = useState<
    ICongestionResponse | undefined
  >(undefined);

  const [entriesByVesselTypesAndTotals, setEntriesByVesselTypesAndTotals] =
    useState<ICongestionResponse | undefined>(undefined);

  const [
    isEntriesByVesselTypesAndTotalsLoading,
    setIsEntriesByVesselTypesAndTotalsLoading,
  ] = useState(false);

  const [isEntriesByVesselTypesLoading, setIsEntriesByVesselTypesLoading] =
    useState(false);

  const [
    isEntriesAndExitsByTotalsLoading,
    setIsEntriesAndExitsByTotalsLoading,
  ] = useState(false);

  const timeDomainEnabledKeys = useMemo(
    () => getEnabledTimeDomainKeys(dateRange.start, dateRange.end),
    [dateRange.start, dateRange.end],
  );

  const timeDomainDays = useMemo(() => {
    if (!dateRange.start || !dateRange.end) return undefined;
    const start = new Date(dateRange.start.split('T')[0]);
    const end = new Date(dateRange.end.split('T')[0]);
    return Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1;
  }, [dateRange.start, dateRange.end]);

  useEffect(() => {
    // Don't clamp until we actually have a date range
    if (!dateRange.start || !dateRange.end) return;

    _setEntriesAndExitsTimeDomain((prev) =>
      clampTimeDomain(prev, timeDomainEnabledKeys),
    );
    _setEntriesTimeDomain((prev) =>
      clampTimeDomain(prev, timeDomainEnabledKeys),
    );
  }, [timeDomainEnabledKeys, dateRange.start, dateRange.end]);

  const setEntriesAndExitsTimeDomain = (value: string) => {
    localStorage.setItem('entriesAndExitsTimeDomain', value);
    _setEntriesAndExitsTimeDomain(value);
  };

  const setEntriesTimeDomain = (value: string) => {
    localStorage.setItem('entriesTimeDomain', value);
    _setEntriesTimeDomain(value);
  };

  const setSelectedVesselType = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedVesselType((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('ZoneSelectedVesselType', JSON.stringify(next));
      return next;
    });
  };

  const setSelectedCountries = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedCountries((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('ZoneSelectedCountries', JSON.stringify(next));
      return next;
    });
  };

  const setSelectedVesselClass = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedVesselClass((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('ZoneSelectedVesselClass', JSON.stringify(next));
      return next;
    });
  };

  const handleVesselTypeToggle = (label: string, checked: boolean) => {
    setSelectedVesselType((prev) => ({ ...prev, [label]: checked }));
    if (checked) {
      setSelectedVesselClass((prev) => ({
        ...prev,
        ...buildClassEntries(label),
      }));
    } else {
      setSelectedVesselClass((prev) => {
        const next = { ...prev };
        (VesselClassData[label] ?? []).forEach(({ className }) => {
          next[classKey(label, className)] = false;
        });
        return next;
      });
    }
  };

  const handleCountryToggle = (code: string, checked: boolean) => {
    setSelectedCountries((prev) => {
      let next: Record<string, boolean>;
      if (code === 'All' && checked) {
        next = Object.keys(prev).reduce<Record<string, boolean>>((acc, k) => {
          acc[k] = k === 'All';
          return acc;
        }, {});
      } else if (code !== 'All' && checked) {
        next = { ...prev, All: false, [code]: true };
      } else {
        next = { ...prev, [code]: checked };
      }
      const hasSelection = Object.entries(next).some(
        ([k, v]) => k !== 'All' && v,
      );
      if (!hasSelection) {
        next = Object.keys(next).reduce<Record<string, boolean>>((acc, k) => {
          acc[k] = k === 'All';
          return acc;
        }, {});
      }
      return next;
    });
  };

  const handleVesselClassToggle = (className: string, checked: boolean) => {
    setSelectedVesselClass((prev) => ({ ...prev, [className]: checked }));
  };

  const { flags, vesselTypes, vesselClasses } = getSelectedFilters(
    selectedCountries,
    selectedVesselType,
    selectedVesselClass,
  );

  const flagStr = flags
    .filter((c) => c !== 'All')
    .join(',')
    .toUpperCase();

  const vesselTypeStr = vesselTypes.join(',');

  const vesselClassesStr = vesselClasses.join(',');

  const {
    getServerSideData: getTopVisitingVesselsServerSideData,
    topVisitingGridRef,
    isTopVisitingVesselsLoading,
    topVisitingVesselData,
    topVisitingVesselsResponse,
  } = useTopVisitingVessels(
    id,
    dateRange,
    flagStr,
    vesselTypeStr,
    vesselClassesStr,
    getTopVisitingVessels,
  );

  const entriesAndExitsTimeDomainDisplay =
    TIME_DOMAIN_VALUE_TO_KEY[entriesAndExitsTimeDomain] ?? 'day';

  const entriesTimeDomainDisplay =
    TIME_DOMAIN_VALUE_TO_KEY[entriesTimeDomain] ?? 'day';

  const hasSelectedVesselTypes =
    Object.values(selectedVesselType).filter(Boolean).length > 0;

  const fetchEntriesAndExitsByTotals = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsEntriesAndExitsByTotalsLoading(true);
    try {
      const response = await getEntriesAndExitsByTotals(
        id,
        'NONE',
        entriesAndExitsTimeDomain.toUpperCase() as PeriodAggregation,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setEntriesAndExitsByTotals(response);
    } catch (error) {
      setEntriesAndExitsByTotals(undefined);
      handleApiError(error);
    } finally {
      setIsEntriesAndExitsByTotalsLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    entriesAndExitsTimeDomain,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  const fetchEntriesByVesselType = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsEntriesByVesselTypesLoading(true);
    try {
      const response = await getEntriesByVesselType(
        id,
        'VESSEL_TYPE',
        entriesTimeDomain.toUpperCase() as PeriodAggregation,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setentriesByVesselTypes(response);
    } catch (error) {
      setentriesByVesselTypes(undefined);
      handleApiError(error);
    } finally {
      setIsEntriesByVesselTypesLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    entriesTimeDomain,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  const fetchEntriesByTotalsAndVesselType = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsEntriesByVesselTypesAndTotalsLoading(true);
    try {
      const response = await getEntriesByVesselTypesAndTotals(
        id,
        'VESSEL_TYPE',
        'NONE',
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setEntriesByVesselTypesAndTotals(response);
    } catch (error) {
      setEntriesByVesselTypesAndTotals(undefined);
      handleApiError(error);
    } finally {
      setIsEntriesByVesselTypesAndTotalsLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  useEffect(() => {
    fetchEntriesAndExitsByTotals();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end, entriesAndExitsTimeDomain]);

  useEffect(() => {
    fetchEntriesByVesselType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end, entriesTimeDomain]);

  useEffect(() => {
    fetchEntriesByTotalsAndVesselType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end]);

  // Debounced fetch when filters change
  useDebouncedEffect(
    () => {
      fetchEntriesAndExitsByTotals();
      fetchEntriesByVesselType();
      fetchEntriesByTotalsAndVesselType();
    },
    [vesselTypeStr, flagStr, vesselClassesStr],
    1100,
  );

  return {
    vesselTypesOpts,
    entriesAndExitsTabs,
    activeEntriesAndExitsTab,
    setActiveEntriesAndExitsTab,
    selectedVesselType,
    handleVesselTypeToggle,
    selectedCountries,
    handleCountryToggle,
    selectedVesselClass,
    handleVesselClassToggle,
    hasSelectedVesselTypes,
    entriesAndExitsTimeDomain,
    setEntriesAndExitsTimeDomain,
    entriesTimeDomain,
    setEntriesTimeDomain,
    dateRange,
    setDateRange,
    timeDomainDays,
    timeDomainEnabledKeys,
    entriesAndExitsByTotals,
    entriesByVesselTypes,
    entriesByVesselTypesAndTotals,
    fetchEntriesAndExitsByTotals,
    fetchEntriesByTotalsAndVesselType,
    fetchEntriesByVesselType,
    entriesAndExitsTimeDomainDisplay,
    entriesTimeDomainDisplay,
    isEntriesAndExitsByTotalsLoading,
    isEntriesByVesselTypesLoading,
    isEntriesByVesselTypesAndTotalsLoading,
    getTopVisitingVesselsServerSideData,
    topVisitingGridRef,
    isTopVisitingVesselsLoading,
    topVisitingVesselData,
    setDateRangeLabel,
    dateRangeLabel,
    topVisitingVesselsResponse,
  };
}
