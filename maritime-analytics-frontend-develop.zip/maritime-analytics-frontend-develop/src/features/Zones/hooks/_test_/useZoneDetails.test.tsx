import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useZoneDetails } from '@/features/Zones/hooks/useZoneDetails';
import type { Zone } from '@/shared/types/entities';
import type { SubscriptionResponseDataType } from '@/shared/types/subscriptionTypes';

/* ------------------------------------------------------------------ */
/* shared spies                                                        */
/* ------------------------------------------------------------------ */

const fetchSavedEntitiesMock = vi.fn();
const showToastMock = vi.fn();
const handleApiErrorMock = vi.fn();

/* ------------------------------------------------------------------ */
/* base mocks                                                         */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/hooks/useEntityDetails', () => ({
  useEntityDetails: () => ({
    id: 'zone-1',
    entity: { id: 'zone-1', name: 'Test Zone' } as Zone,
    loading: false,
    error: null,
    refresh: false,
    setRefresh: vi.fn(),
    dateRange: null,
    setDateRange: vi.fn(),
  }),
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: showToastMock,
  }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/features/library/services/libraryApi', () => ({
  toggleBookmark: vi.fn(),
}));

vi.mock('@/features/Zones/services/zoneServices', () => ({
  fetchZoneDetails: vi.fn(),
  fetchZoneSubscriptions: vi.fn(),
  createZoneSubscription: vi.fn(),
  updateZoneSubscription: vi.fn(),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  localToUtc: (time: string) => time,
  utcToLocal: (time: string) => time,
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

const emptySubscription: SubscriptionResponseDataType = {
  subscription_exists: false,
  subscription_id: null,
  name: null,
  active: false,
  notify_on: {
    ZONE_ENTRY: false,
    ZONE_EXIT: false,
  },
  vessel_screening: {
    active: false,
    severity_filter: [],
  },
  email_settings: {
    email_enabled: false,
    scheduler: {
      schedule_type: 1,
      at_time: '08:00',
    },
  },
};

const existingSubscription: SubscriptionResponseDataType = {
  subscription_exists: true,
  subscription_id: 'sub-1',
  name: 'Test Zone',
  active: true,
  notify_on: {
    ZONE_ENTRY: true,
    ZONE_EXIT: false,
  },
  vessel_screening: {
    active: false,
    severity_filter: [],
  },
  email_settings: {
    email_enabled: false,
    scheduler: {
      schedule_type: 1,
      at_time: '08:00',
    },
  },
};

async function mockLibraryEmpty() {
  const lib = await import('@/features/library/context/LibraryContext');
  vi.spyOn(lib, 'useLibrary').mockReturnValue({
    bookmarks: [],
    fetchSavedEntities: fetchSavedEntitiesMock,
    setBookmarks: vi.fn(),
    activeTab: '',
    setActiveTab: vi.fn(),
    exportToCSV: vi.fn(),
    totalCount: 0,
    activeTabCount: 0,
    setActiveTabCount: vi.fn(),
    loading: false,
    setLoading: vi.fn(),
  });
}

async function mockLibraryWithSubscription() {
  const lib = await import('@/features/library/context/LibraryContext');
  vi.spyOn(lib, 'useLibrary').mockReturnValue({
    bookmarks: [
      {
        entityRefId: 'zone-1',
        entityType: 'ZONE',
        createdTimestamp: '2023-08-02T13:00:00.000Z',
        subscription: { ...existingSubscription, subscription_id: 'sub-1' },
      },
    ],
    fetchSavedEntities: fetchSavedEntitiesMock,
    setBookmarks: vi.fn(),
    activeTab: '',
    setActiveTab: vi.fn(),
    exportToCSV: vi.fn(),
    totalCount: 0,
    activeTabCount: 0,
    setActiveTabCount: vi.fn(),
    loading: false,
    setLoading: vi.fn(),
  });
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('useZoneDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('initializes with empty subscription', async () => {
    await mockLibraryEmpty();

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData).toMatchObject({
      subscription_exists: false,
      active: false,
    });
  });

  it('adds a bookmark', async () => {
    await mockLibraryEmpty();

    const { toggleBookmark } = await import(
      '@/features/library/services/libraryApi'
    );

    vi.mocked(toggleBookmark).mockResolvedValue({
      createdTimestamp: '2023-08-02T13:00:00.000Z',
      entityRefId: 'zone-1',
      entityType: 'ZONE',
      subscription: {
        ...existingSubscription,
        subscription_id: 'sub-1',
      },
    });

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('zone-1');
    });

    expect(toggleBookmark).toHaveBeenCalledWith('add', {
      id: 'zone-1',
      type: 'zone',
    });

    expect(showToastMock).toHaveBeenCalledWith(
      'success',
      'Test Zone added to bookmarks',
      5000,
    );

    expect(fetchSavedEntitiesMock).toHaveBeenCalled();
  });

  it('handles bookmark error', async () => {
    await mockLibraryEmpty();

    const { toggleBookmark } = await import(
      '@/features/library/services/libraryApi'
    );

    vi.mocked(toggleBookmark).mockRejectedValue(new Error('fail'));

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('zone-1');
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
  });

  it('creates a subscription when none exists', async () => {
    await mockLibraryEmpty();

    const { createZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(createZoneSubscription).mockResolvedValue({
      ...emptySubscription,
      subscription_exists: true,
      active: true,
    });

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await result.current.manageSubscription(true, 'Live Notifications');
    });

    expect(createZoneSubscription).toHaveBeenCalled();
    expect(result.current.subscriptionData?.subscription_exists).toBe(true);
  });

  it('fetches existing subscription', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(fetchZoneSubscriptions).toHaveBeenCalledWith('sub-1');
    expect(result.current.subscriptionData?.subscription_exists).toBe(true);
  });

  it('updates live notifications subscription', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue({
      ...existingSubscription,
      active: false,
    });

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(false, 'Live Notifications');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({ active: false }),
      'sub-1',
    );
  });

  it('updates auto-screen vessels', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue({
      ...existingSubscription,
      vessel_screening: {
        active: true,
        severity_filter: ['CRITICAL', 'OK', 'UNSCORED', 'WARNING'],
      },
    });

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Auto-Screen Vessels');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        vessel_screening: {
          active: true,
          severity_filter: ['CRITICAL', 'OK', 'UNSCORED', 'WARNING'],
        },
      }),
      'sub-1',
    );
  });

  it('updates severity filter', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue({
      ...existingSubscription,
      vessel_screening: { active: true, severity_filter: ['CRITICAL'] },
    });
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Warning');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        vessel_screening: {
          active: true,
          severity_filter: ['CRITICAL', 'WARNING'],
        },
      }),
      'sub-1',
    );
  });

  it('updates entry notifications', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Entries');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        notify_on: expect.objectContaining({
          ZONE_ENTRY: true,
        }),
      }),
      'sub-1',
    );
  });

  it('updates exit notifications', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Exits');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        notify_on: expect.objectContaining({
          ZONE_EXIT: true,
        }),
      }),
      'sub-1',
    );
  });

  it('updates email notifications', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue({
      ...existingSubscription,
      email_settings: {
        email_enabled: true,
        scheduler: { schedule_type: 1, at_time: '08:00' },
      },
    });

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Email Notifications');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          email_enabled: true,
        }),
      }),
      'sub-1',
    );
  });

  it('updates timing to immediately', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Timing');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            schedule_type: 0,
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('updates frequency', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Frequency:24');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            schedule_type: 24,
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('updates send at time', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'SendAt:14:30');
      await vi.runAllTimersAsync();
    });

    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            at_time: '14:30',
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('handles subscription fetch error', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockRejectedValue(new Error('fail'));

    renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
  });

  it('debounces rapid successive calls', async () => {
    await mockLibraryWithSubscription();

    const { fetchZoneSubscriptions, updateZoneSubscription } = await import(
      '@/features/Zones/services/zoneServices'
    );

    vi.mocked(fetchZoneSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updateZoneSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => useZoneDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(false, 'Entries');
      result.current.manageSubscription(true, 'Exits');
      await vi.runAllTimersAsync();
    });

    // Should only call once with both updates merged
    expect(updateZoneSubscription).toHaveBeenCalledTimes(1);
    expect(updateZoneSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        notify_on: expect.objectContaining({
          ZONE_ENTRY: false,
          ZONE_EXIT: true,
        }),
      }),
      'sub-1',
    );
  });
});
