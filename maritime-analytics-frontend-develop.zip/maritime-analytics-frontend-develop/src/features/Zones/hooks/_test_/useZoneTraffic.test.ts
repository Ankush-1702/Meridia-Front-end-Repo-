import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import * as useApiErrorHandlerModule from '@/app/hooks/useApiErrorHandler';
import {
  useZoneTraffic,
  getEnabledTimeDomainKeys,
} from '@/features/Zones/hooks/useZoneTraffic';
import * as zoneTrafficApi from '@/features/Zones/services/zoneTrafficApi';
import * as useTopVisitingVesselsModule from '@/shared/hooks/useTopVisitingVessels';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import * as CongestionUtils from '@/shared/utils/CongestionAndTrafficUtils';

vi.mock('react-router', () => ({
  useParams: () => ({ id: 'test-zone-123' }),
}));

vi.mock('@/features/Zones/services/zoneTrafficApi');

vi.mock('@/app/hooks/useApiErrorHandler');

vi.mock('@/shared/hooks/useTopVisitingVessels', () => ({
  useTopVisitingVessels: vi.fn(() => ({
    topVisitingGridRef: { current: null },
    getServerSideData: vi.fn(),
    isTopVisitingVesselsLoading: false,
    topVisitingVesselData: undefined,
  })),
}));

vi.mock('@/shared/hooks/useDebouncedEffect', () => ({
  useDebouncedEffect: vi.fn(),
}));

vi.mock('@/features/library/utils/countryMapping', () => ({
  countries: {
    All: 'All Countries',
    US: 'United States',
    GB: 'United Kingdom',
  },
}));

const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: vi.fn((key: string) => store[key] || null),
    setItem: vi.fn((key: string, value: string) => {
      store[key] = value;
    }),
    clear: vi.fn(() => {
      store = {};
    }),
    removeItem: vi.fn((key: string) => {
      delete store[key];
    }),
  };
})();

Object.defineProperty(window, 'localStorage', { value: localStorageMock });

describe('useZoneTraffic', () => {
  const mockHandleApiError = vi.fn();

  const mockCongestionResponse: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: {
      id: 'test-zone-123',
      name: 'Test Zone',
      zone_type: 'EEZ',
      zone_sub_type: 'National',
      country_common_name: 'Test Country',
    },
    totals: {
      entries: 300,
      exits: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', entries: 10, exits: 8 }],
      },
    ],
  };

  beforeEach(() => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    localStorageMock.clear();
    (useApiErrorHandlerModule.useApiErrorHandler as Mock).mockReturnValue(
      mockHandleApiError,
    );
    (zoneTrafficApi.getEntriesAndExitsByTotals as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    (zoneTrafficApi.getEntriesByVesselType as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    (zoneTrafficApi.getEntriesByVesselTypesAndTotals as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    (zoneTrafficApi.getTopVisitingVessels as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    vi.spyOn(CongestionUtils, 'getSelectedFilters').mockReturnValue({
      flags: ['All'],
      vesselTypes: ['Bulk carrier'],
      vesselClasses: ['Handysize'],
      gtRange: { max: Infinity, min: 0 },
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
    vi.useRealTimers();
  });

  describe('getEnabledTimeDomainKeys', () => {
    it('should return ["Day"] for empty dates', () => {
      expect(getEnabledTimeDomainKeys('', '')).toEqual(['Day']);
    });

    it('should return ["Day"] for 7 days or less', () => {
      expect(getEnabledTimeDomainKeys('2026-03-01', '2026-03-07')).toEqual([
        'Day',
      ]);
    });

    it('should return ["Day", "Week"] for 8-60 days', () => {
      expect(getEnabledTimeDomainKeys('2026-01-01', '2026-02-15')).toEqual([
        'Day',
        'Week',
      ]);
    });

    it('should return ["Day", "Week", "Month"] for 61-90 days', () => {
      expect(getEnabledTimeDomainKeys('2026-01-01', '2026-03-15')).toEqual([
        'Day',
        'Week',
        'Month',
      ]);
    });

    it('should return all options for more than 90 days', () => {
      expect(getEnabledTimeDomainKeys('2025-01-01', '2026-03-09')).toEqual([
        'Day',
        'Week',
        'Month',
        'Quarter',
      ]);
    });
  });

  describe('initialization', () => {
    it('should initialize with default values', () => {
      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.activeEntriesAndExitsTab).toBe('Totals');
      expect(result.current.entriesAndExitsTimeDomain).toBe('Daily');
      expect(result.current.entriesTimeDomain).toBe('Daily');
      expect(result.current.dateRange).toEqual({ start: '', end: '' });
      expect(result.current.vesselTypesOpts.length).toBeGreaterThan(0);
    });

    it('should load vessel types from localStorage', () => {
      const storedVesselTypes = { 'Bulk carrier': true, 'Oil Tanker': false };
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'ZoneSelectedVesselType')
          return JSON.stringify(storedVesselTypes);
        return null;
      });

      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.selectedVesselType).toEqual(storedVesselTypes);
    });

    it('should load countries from localStorage', () => {
      const storedCountries = { All: false, US: true };
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'ZoneSelectedCountries')
          return JSON.stringify(storedCountries);
        return null;
      });

      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.selectedCountries).toEqual(storedCountries);
    });

    it('should load time domain from localStorage', () => {
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'entriesAndExitsTimeDomain') return 'Weekly';
        if (key === 'entriesTimeDomain') return 'Monthly';
        return null;
      });

      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.entriesAndExitsTimeDomain).toBe('Weekly');
      expect(result.current.entriesTimeDomain).toBe('Monthly');
    });
  });

  describe('setters', () => {
    it('should update entriesAndExitsTimeDomain and persist to localStorage', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setEntriesAndExitsTimeDomain('Weekly');
      });

      expect(result.current.entriesAndExitsTimeDomain).toBe('Weekly');
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'entriesAndExitsTimeDomain',
        'Weekly',
      );
    });

    it('should update entriesTimeDomain and persist to localStorage', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setEntriesTimeDomain('Monthly');
      });

      expect(result.current.entriesTimeDomain).toBe('Monthly');
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'entriesTimeDomain',
        'Monthly',
      );
    });

    it('should update dateRange', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      expect(result.current.dateRange).toEqual({
        start: '2026-01-01',
        end: '2026-03-01',
      });
    });
  });

  describe('handleVesselTypeToggle', () => {
    it('should toggle vessel type and persist to localStorage', () => {
      vi.spyOn(CongestionUtils, 'buildClassEntries').mockReturnValue({
        'Oil Tanker::VLCC': true,
      });

      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleVesselTypeToggle('Oil Tanker', true);
      });

      expect(result.current.selectedVesselType['Oil Tanker']).toBe(true);
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'ZoneSelectedVesselType',
        expect.any(String),
      );
    });

    it('should disable vessel classes when vessel type is unchecked', () => {
      vi.spyOn(CongestionUtils, 'VesselClassData', 'get').mockReturnValue({
        'Oil Tanker': [{ className: 'VLCC', gtRange: '200000-320000' }],
      });
      vi.spyOn(CongestionUtils, 'classKey').mockImplementation(
        (type, className) => `${type}::${className}`,
      );

      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleVesselTypeToggle('Oil Tanker', false);
      });

      expect(result.current.selectedVesselType['Oil Tanker']).toBe(false);
    });
  });

  describe('handleCountryToggle', () => {
    it('should select All and deselect others when All is checked', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleCountryToggle('All', true);
      });

      expect(result.current.selectedCountries['All']).toBe(true);
    });

    it('should deselect All when specific country is selected', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleCountryToggle('US', true);
      });

      expect(result.current.selectedCountries['All']).toBe(false);
      expect(result.current.selectedCountries['US']).toBe(true);
    });

    it('should revert to All when no countries are selected', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleCountryToggle('US', false);
      });

      act(() => {
        result.current.handleCountryToggle('GB', false);
      });

      expect(result.current.selectedCountries['All']).toBe(true);
    });
  });

  describe('handleVesselClassToggle', () => {
    it('should toggle vessel class and persist to localStorage', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.handleVesselClassToggle('Bulk carrier::Handysize', true);
      });

      expect(
        result.current.selectedVesselClass['Bulk carrier::Handysize'],
      ).toBe(true);
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'ZoneSelectedVesselClass',
        expect.any(String),
      );
    });
  });

  describe('API fetching', () => {
    it('should fetch entries and exits by totals when dateRange is set', async () => {
      const { result } = renderHook(() => useZoneTraffic());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(zoneTrafficApi.getEntriesAndExitsByTotals).toHaveBeenCalled();
    });

    it('should not fetch when dateRange is empty', async () => {
      renderHook(() => useZoneTraffic());

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(zoneTrafficApi.getEntriesAndExitsByTotals).not.toHaveBeenCalled();
    });

    it('should handle API error for entries and exits', async () => {
      const testError = new Error('API Error');
      (zoneTrafficApi.getEntriesAndExitsByTotals as Mock).mockRejectedValue(
        testError,
      );

      const { result } = renderHook(() => useZoneTraffic());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.entriesAndExitsByTotals).toBeUndefined();
    });

    it('should handle API error for entries by vessel type', async () => {
      const testError = new Error('Vessel Type API Error');
      (zoneTrafficApi.getEntriesByVesselType as Mock).mockRejectedValue(
        testError,
      );

      const { result } = renderHook(() => useZoneTraffic());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.entriesByVesselTypes).toBeUndefined();
    });

    it('should handle API error for entries by vessel types and totals', async () => {
      const testError = new Error('Totals API Error');
      (
        zoneTrafficApi.getEntriesByVesselTypesAndTotals as Mock
      ).mockRejectedValue(testError);

      const { result } = renderHook(() => useZoneTraffic());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.entriesByVesselTypesAndTotals).toBeUndefined();
    });

    it('should set loading states during fetch', async () => {
      let resolveEntries: (value: ICongestionResponse) => void;
      (zoneTrafficApi.getEntriesAndExitsByTotals as Mock).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveEntries = resolve;
          }),
      );

      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.isEntriesAndExitsByTotalsLoading).toBe(true);

      await act(async () => {
        resolveEntries!(mockCongestionResponse);
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.isEntriesAndExitsByTotalsLoading).toBe(false);
    });
  });

  describe('computed values', () => {
    it('should compute timeDomainDays correctly', () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-03-01', end: '2026-03-10' });
      });

      expect(result.current.timeDomainDays).toBe(10);
    });

    it('should return undefined for timeDomainDays when no date range', () => {
      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.timeDomainDays).toBeUndefined();
    });

    it('should compute hasSelectedVesselTypes correctly', () => {
      const { result } = renderHook(() => useZoneTraffic());

      expect(result.current.hasSelectedVesselTypes).toBe(true);
    });
  });

  describe('fetch functions', () => {
    it('should call fetchEntriesAndExitsByTotals', async () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchEntriesAndExitsByTotals();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(zoneTrafficApi.getEntriesAndExitsByTotals).toHaveBeenCalledWith(
        'test-zone-123',
        'NONE',
        'WEEKLY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });

    it('should call fetchEntriesByVesselType', async () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchEntriesByVesselType();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(zoneTrafficApi.getEntriesByVesselType).toHaveBeenCalledWith(
        'test-zone-123',
        'VESSEL_TYPE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });

    it('should call fetchEntriesByTotalsAndVesselType', async () => {
      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchEntriesByTotalsAndVesselType();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        zoneTrafficApi.getEntriesByVesselTypesAndTotals,
      ).toHaveBeenCalledWith(
        'test-zone-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });
  });

  describe('time domain clamping', () => {
    it('should clamp time domain when date range changes', async () => {
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'entriesAndExitsTimeDomain') return 'Quarterly';
        if (key === 'entriesTimeDomain') return 'Quarterly';
        return null;
      });

      const { result } = renderHook(() => useZoneTraffic());

      act(() => {
        result.current.setDateRange({ start: '2026-03-01', end: '2026-03-07' });
      });

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.entriesAndExitsTimeDomain).toBe('Daily');
      expect(result.current.entriesTimeDomain).toBe('Daily');
    });
  });

  describe('top visiting vessels integration', () => {
    it('should expose topVisitingGridRef from useTopVisitingVessels', () => {
      const { result } = renderHook(() => useZoneTraffic());
      expect(result.current.topVisitingGridRef).toBeDefined();
    });

    it('should expose getTopVisitingVesselsServerSideData from useTopVisitingVessels', () => {
      const { result } = renderHook(() => useZoneTraffic());
      expect(result.current.getTopVisitingVesselsServerSideData).toBeDefined();
    });

    it('should expose isTopVisitingVesselsLoading from useTopVisitingVessels', () => {
      const { result } = renderHook(() => useZoneTraffic());
      expect(result.current.isTopVisitingVesselsLoading).toBe(false);
    });

    it('should expose topVisitingVesselData from useTopVisitingVessels', () => {
      const { result } = renderHook(() => useZoneTraffic());
      expect(result.current.topVisitingVesselData).toBeUndefined();
    });

    it('should pass id, dateRange, flagStr, vesselTypeStr, vesselClassesStr and fetchFn to useTopVisitingVessels', () => {
      renderHook(() => useZoneTraffic());

      expect(
        useTopVisitingVesselsModule.useTopVisitingVessels,
      ).toHaveBeenCalledWith(
        'test-zone-123',
        { start: '', end: '' },
        expect.any(String),
        expect.any(String),
        expect.any(String),
        expect.any(Function),
      );
    });
  });
});
