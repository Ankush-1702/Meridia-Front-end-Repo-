// useCustomZoneBanner.ts
import { useState, useEffect } from 'react';
import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { Zone } from '@/shared/types/entities';

const isTestEnv = API_GATEWAY_BASE_URL?.includes('test');

// const getNextT1Refresh = (createdAt: Date) => {
//   const nextDay = new Date(createdAt);
//   nextDay.setUTCDate(nextDay.getUTCDate() + 1);
//   nextDay.setUTCHours(0, 0, 0, 0);
//   return nextDay.getTime();
// };

export function useCustomZoneBanner(zone: Zone | null) {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    if (!zone?.custom_zone_details) {
      setShowBanner(false);
      return;
    }

    //    const createdAt = new Date(zone.custom_zone_details.created_at);
    // const refreshTime = isTestEnv
    //   ? createdAt.getTime() + 15 * 60 * 1000
    //   : getNextT1Refresh(createdAt);

    // const remaining = refreshTime - Date.now();

    const createdAt = new Date(zone.custom_zone_details.created_at).getTime();
    const gracePeriod = isTestEnv ? 15 * 60 * 1000 : 24 * 60 * 60 * 1000;
    const remaining = createdAt + gracePeriod - Date.now();

    if (remaining <= 0) {
      setShowBanner(false);
      return;
    }

    setShowBanner(true);
    const timer = setTimeout(() => setShowBanner(false), remaining);
    return () => clearTimeout(timer);
  }, [zone]);

  return showBanner;
}
