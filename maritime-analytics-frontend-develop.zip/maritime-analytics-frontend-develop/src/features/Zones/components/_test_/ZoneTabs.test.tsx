import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ZoneTabs from '@/features/Zones/components/ZoneTabs';

/* ------------------------------------------------------------------ */
/* mock TabGroup                                                       */
/* ------------------------------------------------------------------ */

const tabGroupOnChangeMock = vi.fn();

vi.mock('@/shared/components/TabGroup', () => {
  return {
    default: ({
      tabs,
      active,
      onChange,
      className,
    }: {
      tabs: string[];
      active: string;
      onChange: (tab: string) => void;
      className?: string;
    }) => {
      tabGroupOnChangeMock.mockImplementation(onChange);

      return (
        <div className={className}>
          <span>Active: {active}</span>
          {tabs.map((tab) => (
            <button key={tab} type="button" onClick={() => onChange(tab)}>
              {tab}
            </button>
          ))}
        </div>
      );
    },
  };
});

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('ZoneTabs', () => {
  it('renders tabs via TabGroup', () => {
    render(<ZoneTabs tabs={['One', 'Two']} active="One" onChange={vi.fn()} />);

    expect(screen.getByText('One')).toBeInTheDocument();
    expect(screen.getByText('Two')).toBeInTheDocument();
    expect(screen.getByText('Active: One')).toBeInTheDocument();
  });

  it('passes className to TabGroup', () => {
    render(
      <ZoneTabs tabs={['A']} active="A" className="px-2" onChange={vi.fn()} />,
    );

    expect(screen.getByText('Active: A').parentElement).toHaveClass('px-2');
  });

  it('calls onChange when a tab is clicked', () => {
    const onChange = vi.fn();

    render(
      <ZoneTabs tabs={['Tab1', 'Tab2']} active="Tab1" onChange={onChange} />,
    );

    fireEvent.click(screen.getByText('Tab2'));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith('Tab2');
  });
});
