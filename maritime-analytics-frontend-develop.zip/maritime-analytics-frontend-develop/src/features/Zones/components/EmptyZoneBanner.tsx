import { FaCircleInfo } from 'react-icons/fa6';

export default function EmptyZoneBanner() {
  return (
    <div className="flex h-[53px] w-full items-center rounded-lg bg-primary-100/50 p-4">
      <div className="flex gap-4">
        <FaCircleInfo className="h-5 w-5 text-primary-700" />
        <p className="text-sm text-primary-900">
          Traffic analytics will be available 24 hours after zone creation. Data
          is processed daily.
        </p>
      </div>
    </div>
  );
}
