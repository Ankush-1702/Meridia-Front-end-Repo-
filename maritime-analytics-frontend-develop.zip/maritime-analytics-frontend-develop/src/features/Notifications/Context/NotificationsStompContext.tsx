import {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/context/AuthContext';
import { useNotificationsStomp } from '@/features/Notifications/hooks/useNotificationsStomp';
import { Notifications } from '@/features/Notifications/types/notificationsTypes';
import StatusBadge from '@/shared/components/Badge';
import {
  LOCAL_NOTIFICATIONS_KEY,
  NOTIFICATIONS_SETTINGS_KEY,
} from '@/shared/constants/constants';
import { riskBgMap } from '@/shared/utils/colourUtil';
import {
  convertUTCToLocalTime,
  formatEpochMsToUTCDateString,
  relativeTime,
  toTitleCase,
} from '@/shared/utils/formatUtils';
import { logger } from '@/shared/utils/logger';

interface NotifStompContextType {
  connected: boolean;
  notifications: Notifications[];
  dismissAllNotifications: () => void;
  setNotifications: (notifs: Notifications[]) => void;
  notificationSettings: boolean;
  setNotificationSettings: (value: boolean) => void;
}

const NotifStompContext = createContext<NotifStompContextType | undefined>(
  undefined,
);

export function NotifStompProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const {
    connected,
    newNotifications: notifications,
    setNewNotifications: setNotifications,
  } = useNotificationsStomp();
  const { isAuthenticated } = useAuth();

  const [sidebarExpanded, setSidebarExpanded] = useState(() => {
    const stored = localStorage.getItem('sidebarExpanded');
    return stored !== null ? JSON.parse(stored) : true;
  });

  const [localNotifs, setLocalNotifs] = useState(() => notifications || []);
  const [notificationSettings, setNotificationSettings] = useState(() => {
    const stored = localStorage.getItem(NOTIFICATIONS_SETTINGS_KEY);
    return stored === null ? true : stored === 'true';
  });
  const dismissedAllIdsRef = useRef<Set<string>>(new Set());
  const [, setNow] = useState(Date.now());

  useEffect(() => {
    const handleToggle = (e: Event) => {
      setSidebarExpanded((e as CustomEvent).detail);
    };
    window.addEventListener('sidebarToggle', handleToggle);
    return () => window.removeEventListener('sidebarToggle', handleToggle);
  }, []);

  useEffect(() => {
    // Update the "now" timestamp every 60 seconds to refresh relativeTime
    const interval = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) {
      setLocalNotifs([]);
      dismissedAllIdsRef.current.clear();
      localStorage.removeItem(LOCAL_NOTIFICATIONS_KEY);
      setNotifications([]);
    }
  }, [isAuthenticated, setNotifications]);

  useEffect(() => {
    if (!isAuthenticated) return;

    const existingRaw = localStorage.getItem(LOCAL_NOTIFICATIONS_KEY);
    let existing: Notifications[] = [];
    try {
      existing = existingRaw ? JSON.parse(existingRaw) : [];
    } catch (err) {
      logger.error(
        '[NotificationsStompContext] Failed to parse existing notifications',
        err,
      );
      existing = [];
    }

    const merged = [...existing, ...localNotifs];
    const unique = merged.filter(
      (n, i, arr) =>
        i === arr.findIndex((x) => x.notificationId === n.notificationId),
    );

    localStorage.setItem(LOCAL_NOTIFICATIONS_KEY, JSON.stringify(unique));
  }, [localNotifs, isAuthenticated]);

  useEffect(() => {
    if (!isAuthenticated) return;

    const newNotifications = notifications.filter(
      (n) => !dismissedAllIdsRef.current.has(n.notificationId),
    );

    if (newNotifications.length > 0) {
      setLocalNotifs(newNotifications);
    }
  }, [notifications, isAuthenticated]);

  // Dismiss a single notification
  function dismissNotification(notificationId: string) {
    // Add the dismissed notification ID to the ref (same behavior as dismissAll)
    dismissedAllIdsRef.current.add(notificationId);

    // Remove from local state
    setLocalNotifs((state) =>
      state.filter(
        (notification) => notification.notificationId !== notificationId,
      ),
    );
  }

  // Dismiss all notifications
  function dismissAllNotifications() {
    setLocalNotifs([]);
    notifications.forEach((n) =>
      dismissedAllIdsRef.current.add(n.notificationId),
    );
  }

  const visibleNotifications = localNotifs.slice(-6);

  return (
    <NotifStompContext.Provider
      value={{
        connected,
        notifications,
        dismissAllNotifications,
        setNotifications,
        notificationSettings,
        setNotificationSettings,
      }}
    >
      {children}

      {/* Toast container - top centered */}
      {notificationSettings && isAuthenticated && (
        <div
          aria-live="polite"
          className="pointer-events-none fixed inset-x-0 bottom-4 z-50 flex justify-start px-2"
        >
          <div className="relative w-full max-w-xl">
            {/* Dismiss All button - placed at top-right of stack */}
            {localNotifs.length > 1 && (
              <div
                className={`absolute -top-[85px] z-40 flex items-center gap-2 ${
                  sidebarExpanded ? '-right-[70px]' : 'right-[120px]'
                }`}
                style={{ zIndex: 120 }}
              >
                <button
                  onClick={dismissAllNotifications}
                  className="pointer-events-auto mr-2 rounded-lg border bg-gray-50 px-3 py-2 text-xs font-normal shadow-md hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
                  aria-label="Dismiss all notifications"
                  title="Dismiss All"
                >
                  Dismiss All
                </button>
              </div>
            )}

            {visibleNotifications.map((n, index) => {
              const revIndex = visibleNotifications.length - 1 - index;
              const maxDepth = 4;
              const depth = Math.min(revIndex, maxDepth - 1);

              const yOffset = depth * 4;
              const zOffset = depth * -20;
              const scale = 1 - depth * 0.03;
              const rotateX = Math.min(depth * 2.5, 12);
              const opacity = Math.max(1 - depth * 0.12, 0.45);
              const blur = Math.min(depth * 0.1, 4);
              const zIndex = 100 + (100 - revIndex);

              const isTopmost = revIndex === 0;

              const transform = `translateX(-50%) translateY(${yOffset}px) translateZ(${zOffset}px) scale(${scale}) rotateX(${rotateX}deg)`;

              const risk =
                n.eventType === 'ZONE_EXIT' ||
                n.eventType === 'PORT_ARRIVAL' ||
                n.eventType === 'PORT_DEPARTURE' ||
                n.eventType === 'PORT_AREA_DEPARTURE' ||
                n.vesselType?.toLowerCase() === 'tug' ||
                n.vesselType?.toLowerCase() === 'push-boat'
                  ? 'NA'
                  : n.screeningResult !== '-' && n.screeningResult !== null
                    ? n.screeningResult
                    : 'UNSCORED';

              return (
                <div
                  key={n.notificationId}
                  className={`fixed z-40 max-w-xl ${
                    sidebarExpanded ? 'left-[400px]' : 'left-52'
                  } ${isTopmost ? 'pointer-events-auto' : 'pointer-events-none'}`}
                  style={{ bottom: 24 }}
                >
                  <div
                    className="mx-auto w-full rounded-lg bg-white shadow-sm ring-1 ring-black/5 dark:bg-gray-800 dark:ring-white/5"
                    style={{
                      transform,
                      transformStyle: 'preserve-3d',
                      WebkitTransformStyle: 'preserve-3d',
                      transition:
                        'transform 260ms cubic-bezier(0.2, 0.9, 0.2, 1), opacity 200ms',
                      opacity,
                      filter: blur ? `blur(${blur}px)` : undefined,
                      zIndex: zIndex,
                    }}
                  >
                    {/* Close button */}
                    <button
                      onClick={() => dismissNotification(n.notificationId)}
                      aria-label="Close notification"
                      className="absolute right-2 top-2 z-50 inline-flex h-7 w-7 items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-gray-700"
                      style={{ zIndex: 120 }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 text-gray-600 dark:text-gray-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                        aria-hidden="true"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </button>

                    {/* Clickable body */}
                    <div
                      className={`flex h-20 w-[300px] cursor-pointer flex-col space-y-5 rounded-lg border-b px-3 py-3  ${risk ? riskBgMap[risk] : 'bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-white  dark:hover:bg-gray-700'} dark:border-gray-700`}
                      onClick={() => {
                        navigate('/analytics/notifications');
                        localStorage.setItem(
                          LOCAL_NOTIFICATIONS_KEY,
                          JSON.stringify([]),
                        );
                        dismissAllNotifications();
                        setNotifications([]);
                      }}
                      role="button"
                      tabIndex={isTopmost ? 0 : -1}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          navigate('/analytics/notifications');
                          localStorage.setItem(
                            LOCAL_NOTIFICATIONS_KEY,
                            JSON.stringify([]),
                          );
                          setNotifications([]);
                        }
                      }}
                      style={{ position: 'relative', zIndex: 101 }}
                    >
                      <div className="flex gap-2">
                        <StatusBadge status={risk!} />
                        <span
                          className="truncate text-sm font-semibold"
                          title={n.zonePortName}
                        >
                          {n.zonePortName}
                        </span>
                      </div>
                      <div
                        className="truncate text-xs text-gray-500 dark:text-gray-400"
                        title={`${n.vesselName} - ${n.eventType} - ${relativeTime(convertUTCToLocalTime(formatEpochMsToUTCDateString(n.createdAt)))}`}
                      >
                        {n.vesselName} -{' '}
                        {toTitleCase(n.eventType.split('_').slice(1).join('_'))}{' '}
                        -{' '}
                        {relativeTime(
                          convertUTCToLocalTime(
                            formatEpochMsToUTCDateString(n.createdAt),
                          ),
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </NotifStompContext.Provider>
  );
}

export const useNotificationsStompContext = () => {
  const context = useContext(NotifStompContext);
  if (!context) {
    throw new Error(
      'useNotificationsStompContext must be used within a Provider',
    );
  }
  return context;
};
