import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  NotifStompProvider,
  useNotificationsStompContext,
} from '@/features/Notifications/Context/NotificationsStompContext';
import type { Notifications } from '@/features/Notifications/types/notificationsTypes';
import { LOCAL_NOTIFICATIONS_KEY } from '@/shared/constants/constants';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

const navigateMock = vi.fn();

vi.mock('react-router-dom', async () => {
  const actual =
    await vi.importActual<typeof import('react-router-dom')>(
      'react-router-dom',
    );
  return {
    ...actual,
    useNavigate: () => navigateMock,
  };
});

const authState = { isAuthenticated: true };

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => authState,
}));

const stompState = {
  connected: true,
  newNotifications: [] as Notifications[],
  setNewNotifications: vi.fn(),
};

vi.mock('@/features/Notifications/hooks/useNotificationsStomp', () => ({
  useNotificationsStomp: () => stompState,
}));

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => (
    <span data-testid="badge">{status}</span>
  ),
}));

vi.mock('@/shared/utils/colourUtil', () => ({
  riskBgMap: { NA: 'bg-na' },
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  convertUTCToLocalTime: (v: string) => v,
  formatEpochMsToUTCDateString: (v: number) => String(v),
  relativeTime: () => 'just now',
  toTitleCase: (v: string) => v,
}));

/* ------------------------------------------------------------------ */
/* Test helpers */
/* ------------------------------------------------------------------ */

function TestConsumer() {
  const ctx = useNotificationsStompContext();
  return (
    <div>
      <span data-testid="connected">{String(ctx.connected)}</span>
      <button onClick={ctx.dismissAllNotifications}>dismiss</button>
    </div>
  );
}

const mockNotification: Notifications = {
  notificationId: '1',
  vesselName: 'Vessel A',
  eventType: 'PORT_ARRIVAL',
  createdAt: String(Date.now()),
  zonePortName: 'Port A',
  screeningResult: '-',
  vesselType: 'fishing Vessel',
  eventId: '1',
  eventTimestamp: String(Date.now()),
  imo: '123456',
  flag: 'Flag A',
  flagCode: 'A',
  zonePortId: '1',
  subscriptionId: null,
  subscriptionName: null,
};

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotifStompProvider', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    stompState.newNotifications = [];
    authState.isAuthenticated = true;
  });

  it('renders children and provides context values', () => {
    render(
      <MemoryRouter>
        <NotifStompProvider>
          <TestConsumer />
        </NotifStompProvider>
      </MemoryRouter>,
    );

    expect(screen.getByTestId('connected')).toHaveTextContent('true');
  });

  it('renders incoming notifications as toast', async () => {
    stompState.newNotifications = [mockNotification];

    render(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    expect(await screen.findByText('Port A')).toBeInTheDocument();
    expect(screen.getByTestId('badge')).toHaveTextContent('NA');
  });

  it('does not render toasts when not authenticated', () => {
    authState.isAuthenticated = false;
    stompState.newNotifications = [mockNotification];

    render(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    expect(screen.queryByText('Port A')).not.toBeInTheDocument();
  });

  it('clears notifications when authentication is lost', async () => {
    stompState.newNotifications = [mockNotification];
    localStorage.setItem(
      LOCAL_NOTIFICATIONS_KEY,
      JSON.stringify([mockNotification]),
    );

    const { rerender } = render(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    expect(await screen.findByText('Port A')).toBeInTheDocument();

    // Simulate logout
    authState.isAuthenticated = false;
    stompState.newNotifications = [];

    rerender(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    expect(screen.queryByText('Port A')).not.toBeInTheDocument();
    expect(stompState.setNewNotifications).toHaveBeenCalledWith([]);
    expect(localStorage.getItem(LOCAL_NOTIFICATIONS_KEY)).toBeNull();
  });

  it('dismisses all notifications when Dismiss All is clicked', async () => {
    stompState.newNotifications = [
      mockNotification,
      { ...mockNotification, notificationId: '2' },
    ];

    render(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    const dismissBtn = await screen.findByRole('button', {
      name: /dismiss all notifications/i,
    });

    fireEvent.click(dismissBtn);

    expect(screen.queryByText('Port A')).not.toBeInTheDocument();
  });

  it('navigates and clears notifications when toast is clicked', async () => {
    stompState.newNotifications = [mockNotification];

    render(
      <MemoryRouter>
        <NotifStompProvider>
          <div>child</div>
        </NotifStompProvider>
      </MemoryRouter>,
    );

    fireEvent.click(await screen.findByText('Port A'));

    expect(navigateMock).toHaveBeenCalledWith('/analytics/notifications');
    expect(localStorage.getItem(LOCAL_NOTIFICATIONS_KEY)).toBe(
      JSON.stringify([]),
    );
    expect(stompState.setNewNotifications).toHaveBeenCalledWith([]);
  });
});

describe('useNotificationsStompContext', () => {
  it('throws if used outside provider', () => {
    const Broken = () => {
      useNotificationsStompContext();
      return null;
    };

    expect(() =>
      render(
        <MemoryRouter>
          <Broken />
        </MemoryRouter>,
      ),
    ).toThrow('useNotificationsStompContext must be used within a Provider');
  });
});
