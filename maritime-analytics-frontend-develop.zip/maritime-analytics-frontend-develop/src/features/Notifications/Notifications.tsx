import { ColDef, IServerSideGetRowsParams } from 'ag-grid-enterprise';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LuRefreshCw } from 'react-icons/lu';
import { PiDownloadSimple } from 'react-icons/pi';
import { useLocation } from 'react-router-dom';
import { useLibrary } from '../library/context/LibraryContext';
import HighFrequencyNotice from './components/HighFrequencyNotice';
import { NotificationsKebabMenu } from './components/NotificationsKebabMenu';
import { useNotificationsStompContext } from './Context/NotificationsStompContext';
import { useNotifications } from './hooks/useNotifications';
import { useNotificationsStomp } from './hooks/useNotificationsStomp';
import { getNotifications } from './services/notificationsService';
import { Notifications } from './types/notificationsTypes';
import Downloads from './ui/Downloads';
import { createNotificationsColDefs } from './utils/ColDefs';
import { TIME_ZONE_KEY } from '@/app/constants/constants';
import NotificationsHeader from '@/features/Notifications/components/NotificationsHeader';
import NotificationsTabs from '@/features/Notifications/components/NotificationsTabs';
import EntityActionButton from '@/shared/components/EntityActionButton';
import EntityTabs from '@/shared/components/EntityTabs';
import { LOCAL_NOTIFICATIONS_KEY } from '@/shared/constants/constants';
import PoleStarEntityGrid, {
  type PoleStarEntityGridRef,
} from '@/shared/lib/PoleStarEntityGrid';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  formatEpochMsToUTCDateString,
} from '@/shared/utils/formatUtils';

const TABS = [
  { key: 'notifications', label: 'Notifications' },
  { key: 'downloads', label: 'Downloads' },
];

export default function NotificationsPage() {
  const location = useLocation();
  const entitiesGroupTabs = ['All', 'Ports', 'Zones'];
  const { dismissAllNotifications, setNotifications } =
    useNotificationsStompContext();
  const { exportToCSV } = useLibrary();
  const {
    showBurstNotice,
    burstCount,
    resetBurst,
    bumpRefreshToken,
    refreshToken,
  } = useNotificationsStomp();

  const {
    preference,
    loading: notificationsLoading,
    options,
    updateRecencyPreference,
  } = useNotifications();

  const [loading, setLoading] = useState<boolean>(false);
  const [hasFetched, setHasFetched] = useState(false);
  const [activeEntitiesGroupTab, setActiveEntitiesGroupTab] = useState('All');
  const [rows, setRows] = useState<Notifications[]>([]);

  const [tz, setTz] = useState(
    () => localStorage.getItem(TIME_ZONE_KEY) ?? 'system',
  );

  const gridRef = useRef<PoleStarEntityGridRef | null>(null);

  // Read the active tab from navigation state, default to 'notifications'
  const [activeTab, setActiveTab] = useState(
    () =>
      (location.state as { activeTab?: string })?.activeTab || 'notifications',
  );

  // Listen for changes from other tabs/components
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === TIME_ZONE_KEY) {
        setTz(e.newValue ?? 'system');
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  // Re-build columns whenever tz changes
  const columns = useMemo(
    () => createNotificationsColDefs(tz, activeEntitiesGroupTab),
    [tz, activeEntitiesGroupTab],
  );

  const getServerSideData = useCallback(
    async (params: IServerSideGetRowsParams) => {
      setHasFetched(false);
      params.api.setGridOption('loading', true);
      const { startRow } = params.request;
      setRows([]);
      setLoading(true);
      try {
        const event_type =
          activeEntitiesGroupTab === 'All'
            ? ''
            : activeEntitiesGroupTab === 'Ports'
              ? 'PORT_ARRIVAL,PORT_DEPARTURE,PORT_AREA_ARRIVAL,PORT_AREA_DEPARTURE'
              : 'ZONE_ENTRY,ZONE_EXIT';
        const response = await getNotifications(event_type, startRow);

        const filteredData = response.data;

        setRows(filteredData);

        params.success({
          rowData: filteredData,
          rowCount: response.meta.total_count,
        });

        params.api.setGridOption('loading', false);
        const count = response.meta.total_count;
        if (count === 0) {
          params.api.showNoRowsOverlay();
        } else {
          params.api.hideOverlay();
        }
      } catch (error) {
        console.error('Failed to fetch server-side data:', error);
        params.api.setGridOption('loading', false);
        params.api.showNoRowsOverlay();
        params.fail();
      } finally {
        setLoading(false);
        setHasFetched(true);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [activeEntitiesGroupTab, refreshToken, preference],
  );

  const getCSVContent = (): string => {
    const gridColDefs = gridRef.current?.getDisplayedColDefs?.();
    const displayedColDefs: ColDef[] =
      gridColDefs && gridColDefs.length > 0 ? gridColDefs : columns;

    const headers = displayedColDefs
      .map((c) => c.headerName ?? c.colId ?? c.field ?? '')
      .join(',');

    const fields = displayedColDefs.map((c) => c.field ?? '');

    const pageRows = gridRef.current?.getCurrentPageRows?.() as
      | Notifications[]
      | undefined;
    const currentRows = pageRows !== undefined ? pageRows : rows;

    const dataRows = currentRows.map((row) =>
      fields
        .map((field) => {
          if (!field) return '';

          if (field === 'createdAt') {
            const utc = formatEpochMsToUTCDateString(row.createdAt);
            const formatted =
              tz === 'utc'
                ? convertDateAndTimeToHumanReadableFormat(utc)
                : convertUTCToLocalTime(utc);

            const escaped = String(formatted).replace(/"/g, '""');
            return /[,"\n]/.test(escaped) ? `"${escaped}"` : escaped;
          }

          if (field === 'screeningResult') {
            const risk =
              row.eventType === 'ZONE_EXIT' ||
              row.eventType === 'PORT_ARRIVAL' ||
              row.eventType === 'PORT_DEPARTURE' ||
              row.eventType === 'PORT_AREA_DEPARTURE' ||
              row.vesselType?.toLowerCase() === 'tug' ||
              row.vesselType?.toLowerCase() === 'push-boat'
                ? 'NA'
                : row.screeningResult !== '-' && row.screeningResult !== null
                  ? row.screeningResult
                  : 'UNSCORED';

            return risk;
          }

          const raw = row[field as keyof Notifications];
          if (raw == null) return '';

          const str = String(raw).replace(/"/g, '""');
          return /[,"\n]/.test(str) ? `"${str}"` : str;
        })
        .join(','),
    );

    return [headers, ...dataRows].join('\n');
  };

  return (
    <div className="flex h-screen flex-col bg-gray-100 text-black dark:bg-gray-900">
      <div className="bg-white dark:bg-gray-800 dark:text-white">
        <NotificationsHeader headerText={`Notifications`} />
      </div>
      <EntityTabs tabs={TABS} activeTab={activeTab} onChange={setActiveTab} />
      {activeTab === 'notifications' && (
        <>
          <div className="px-6 pb-4 pt-4">
            <div className="flex justify-between">
              <div className="flex gap-4">
                <NotificationsTabs
                  tabs={entitiesGroupTabs}
                  active={activeEntitiesGroupTab}
                  onChange={setActiveEntitiesGroupTab}
                  className=""
                />
              </div>
              <div className="flex items-center gap-3">
                <div className="mt-5">
                  <EntityActionButton
                    className="py-2.5"
                    textLabel={`Refresh`}
                    icon={<LuRefreshCw className="text-gray-400" />}
                    handleClick={() => {
                      setLoading(true);
                      bumpRefreshToken();
                      setNotifications([]);
                      dismissAllNotifications();
                      localStorage.setItem(
                        LOCAL_NOTIFICATIONS_KEY,
                        JSON.stringify([]),
                      );
                    }}
                    refresh={loading}
                  />
                </div>
                <div className="mt-5 flex items-center justify-end gap-3">
                  <EntityActionButton
                    textLabel={'Export'}
                    handleClick={() => {
                      exportToCSV(
                        getCSVContent(),
                        `${activeEntitiesGroupTab}-Notifications`,
                      );
                    }}
                    icon={<PiDownloadSimple className="text-gray-400" />}
                  />
                </div>
                <NotificationsKebabMenu
                  notifSettingsOptions={options}
                  loading={notificationsLoading}
                  selectedRecencyPreference={preference}
                  updateRecencyPreference={updateRecencyPreference}
                />
              </div>
            </div>
          </div>
          <div className="px-6">
            {showBurstNotice && (
              <HighFrequencyNotice
                count={burstCount}
                show={() => {
                  resetBurst();
                  setLoading(true);
                  bumpRefreshToken();
                  setNotifications([]);
                  dismissAllNotifications();
                  localStorage.setItem(
                    LOCAL_NOTIFICATIONS_KEY,
                    JSON.stringify([]),
                  );
                }}
              />
            )}
          </div>
          <div className="min-h-0 flex-1 overflow-hidden px-6">
            <div className={`${loading ? 'block' : 'hidden'}`}>
              <div className="animate-pulse rounded-md bg-gray-200 dark:bg-gray-700">
                <div className="h-[44rem] w-full rounded-md" />
              </div>
            </div>
            <div
              className={`${rows.length === 0 && hasFetched ? '' : 'hidden'}`}
            >
              <GenericErrorPage
                errorHeading="Your notifications will appear here"
                errorText="Configure notifications on items in your library"
              />
            </div>
            <div
              className={`${rows.length > 0 && hasFetched ? 'h-full flex-1 overflow-hidden pb-6' : 'hidden'}`}
            >
              <PoleStarEntityGrid
                key={'Notifications'}
                ref={gridRef}
                columns={columns}
                getServerSideData={getServerSideData}
                isSideBar={false}
                pageSize={500}
              />
            </div>
          </div>
        </>
      )}
      {activeTab === 'downloads' && (
        <div className="min-h-0 flex-1 overflow-hidden px-6 pb-6 pt-4">
          <Downloads />
        </div>
      )}
    </div>
  );
}
