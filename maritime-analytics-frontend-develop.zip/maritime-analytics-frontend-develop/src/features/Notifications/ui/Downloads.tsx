// import { Spinner } from 'flowbite-react';
import { Spinner } from 'flowbite-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LuRefreshCw } from 'react-icons/lu';
import { useExportDownloads } from '../hooks/useExportDownloads';
import { CreateDownloadsColDefs } from '../utils/DownloadColDefs';
import { getExpiresText, SCOPE_LABEL } from '../utils/downloadUtils';
import { searchFieldTheme } from '@/app/config/flowbite-theme';
import { TIME_ZONE_KEY } from '@/app/constants/constants';
import Filter from '@/shared/components/Filter';
import MultiSelectDropdown from '@/shared/components/MultiSelectDropdown';
import PoleStarEntityGrid, {
  type PoleStarEntityGridRef,
} from '@/shared/lib/PoleStarEntityGrid';
import { ReturnedEntity } from '@/shared/services/exportServices/exportTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
} from '@/shared/utils/formatUtils';

const TYPE_TABS = [
  {
    label: 'Port',
    value: 'PORT',
  },
  {
    label: 'Zone',
    value: 'ZONE',
  },
  {
    label: 'Vessel',
    value: 'VESSEL',
  },
  {
    label: 'Fleet',
    value: 'FLEET',
  },
];

export default function Downloads() {
  const gridRef = useRef<PoleStarEntityGridRef | null>(null);
  const initialSelected = TYPE_TABS.reduce<Record<string, boolean>>(
    (acc, tab) => ({ ...acc, [tab.value]: true }),
    {},
  );
  const [selected, setSelected] =
    useState<Record<string, boolean>>(initialSelected);
  const [query, setQuery] = useState<string>('');

  const retryingJobsRef = useRef<Set<string>>(new Set());
  const downloadingJobsRef = useRef<Set<string>>(new Set());

  const {
    jobs,
    isLoading,
    retryJobWithPolling,
    downloadCsv,
    fetchRecentExportJobs,
    timeAgo,
  } = useExportDownloads();

  const [nowTick, setNowTick] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => {
      setNowTick(Date.now());
      gridRef.current?.refresh();
    }, 60_000);
    return () => clearInterval(id);
  }, []);

  const [tz, setTz] = useState(
    () => localStorage.getItem(TIME_ZONE_KEY) ?? 'system',
  );

  const onToggle = useCallback((value: string, checked: boolean) => {
    setSelected((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const onSelectAll = useCallback((checked: boolean) => {
    setSelected(
      TYPE_TABS.reduce<Record<string, boolean>>(
        (acc, tab) => ({ ...acc, [tab.value]: checked }),
        {},
      ),
    );
  }, []);

  const retryWithState = useCallback(
    (jobId: string, entityType?: ReturnedEntity, eventTypes?: string[]) => {
      retryJobWithPolling(
        jobId,
        () => {
          retryingJobsRef.current.add(jobId);
          gridRef.current?.refresh();
        },
        () => {
          retryingJobsRef.current.delete(jobId);
          gridRef.current?.refresh();
        },
        entityType,
        eventTypes,
      );
    },
    [retryJobWithPolling],
  );

  const downloadWithState = useCallback(
    async (jobId: string) => {
      downloadingJobsRef.current.add(jobId);
      gridRef.current?.refresh();
      try {
        await downloadCsv(jobId);
      } finally {
        downloadingJobsRef.current.delete(jobId);
        gridRef.current?.refresh();
      }
    },
    [downloadCsv],
  );

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === TIME_ZONE_KEY) {
        setTz(e.newValue ?? 'system');
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  // Update columns to use nowTick (need to create a ref for the column defs to read)
  const nowRef = useRef(nowTick);
  useEffect(() => {
    nowRef.current = nowTick;
  }, [nowTick]);

  const columns = useMemo(
    () =>
      CreateDownloadsColDefs(
        tz,
        nowRef,
        retryWithState,
        downloadWithState,
        retryingJobsRef,
        downloadingJobsRef,
      ),
    [tz, retryWithState, downloadWithState],
  );

  const selectedValues = useMemo(
    () => Object.keys(selected).filter((key) => selected[key]),
    [selected],
  );

  const selectedValuesRef = useRef(selectedValues);

  const filteredRows = useMemo(() => {
    selectedValuesRef.current = selectedValues;

    // First filter by selected types
    const filtered = jobs.filter((job) =>
      selectedValues.includes(job.entity_type),
    );

    // Then filter by search query
    if (!query.trim()) return filtered;

    const lower = query.toLowerCase().replace(/_/g, ' ');

    return filtered.filter((job) => {
      // Format timestamps to match what the user sees in the grid
      const formattedRequestedAt =
        tz === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(job.requested_at ?? '')
          : convertUTCToLocalTime(job.requested_at ?? '');

      const formattedDateStart =
        tz === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(job.date_start ?? '')
          : convertUTCToLocalTime(job.date_start ?? '');

      const formattedDateEnd =
        tz === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(job.date_end ?? '')
          : convertUTCToLocalTime(job.date_end ?? '');

      // Only search fields that are visible in the column defs
      const entityName = job.entity_display_name?.toLowerCase() || '';
      const eventTypes = job.event_type
        .join(', ')
        .toLowerCase()
        .replace(/_/g, ' ');
      const dateRange =
        `${formattedDateStart.split(',')[0]} - ${formattedDateEnd.split(',')[0]}`.toLowerCase();
      const entityType = (
        SCOPE_LABEL[job.entity_type] || job.entity_type
      ).toLowerCase();
      const requestedAt = formattedRequestedAt.toLowerCase();
      const status = job.status?.toLowerCase() || '';
      const expires = getExpiresText(job, nowTick).toLowerCase();

      return (
        entityName.includes(lower) ||
        eventTypes.includes(lower) ||
        dateRange.includes(lower) ||
        entityType.includes(lower) ||
        requestedAt.includes(lower) ||
        status.includes(lower) ||
        expires.includes(lower)
      );
    });
  }, [jobs, selectedValues, query, tz, nowTick]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex justify-between">
        <MultiSelectDropdown
          title={'Type'}
          key={'Types'}
          options={TYPE_TABS}
          selected={selected}
          onToggle={onToggle}
          onSelectAll={onSelectAll}
          width={150}
          shouldShowAll
          showSearch={false}
        />
        <div className="flex items-center gap-2 text-xs text-gray-400 ">
          <LuRefreshCw className="h-3 w-3 text-gray-400" />
          Updated {timeAgo} ago
          <button
            className="cursor-pointer text-gray-400 underline hover:text-gray-700"
            onClick={fetchRecentExportJobs}
            disabled={Boolean(isLoading)}
          >
            Refresh
          </button>
        </div>
      </div>
      <div className="mt-4 flex flex-1 flex-col gap-1 rounded-lg bg-white dark:bg-gray-800">
        <div className="flex items-center justify-between px-3 py-3">
          <div className="flex items-center gap-3">
            <Filter
              width={`w-[280px]`}
              placeholder={'Search exports...'}
              query={query}
              setQuery={setQuery}
              theme={searchFieldTheme}
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-400 ">
            Exports are available to download for 24 hours after they're
            generated.
          </div>
        </div>
        <div className="relative min-h-0 flex-1 overflow-auto rounded-b-lg bg-white dark:bg-gray-800">
          {isLoading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/80 dark:bg-gray-800/80">
              <div className="flex flex-col items-center gap-3">
                <Spinner size="xl" color="psgPrimary" light />
              </div>
            </div>
          )}
          <div className="h-full min-h-0">
            <PoleStarEntityGrid
              ref={gridRef}
              key={`Downloads`}
              roundedTop={false}
              isServerSide={false}
              rows={filteredRows}
              columns={columns}
              pageSize={100}
              isSideBar={false}
              rowHeight={60}
              noRowsOverlay={`
            <div class="flex items-center justify-center h-full text-gray-500 text-base">
              No downloads available
            </div>
          `}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
