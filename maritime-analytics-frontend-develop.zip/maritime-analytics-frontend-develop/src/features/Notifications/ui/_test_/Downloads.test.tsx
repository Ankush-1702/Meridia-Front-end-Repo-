import { fireEvent, render, screen } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

import Downloads from '@/features/Notifications/ui/Downloads';
import type { ExportListData } from '@/shared/services/exportServices/exportTypes';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

const mockFetchRecentExportJobs = vi.fn();
const mockRetryJobWithPolling = vi.fn();
const mockDownloadCsv = vi.fn();

let mockHookState: {
  jobs: ExportListData[];
  isLoading: boolean;
  retryJobWithPolling: typeof mockRetryJobWithPolling;
  downloadCsv: typeof mockDownloadCsv;
  fetchRecentExportJobs: typeof mockFetchRecentExportJobs;
  timeAgo: string;
};

vi.mock('@/features/Notifications/hooks/useExportDownloads', () => ({
  useExportDownloads: () => mockHookState,
}));

type MockGridProps = {
  rows: ExportListData[];
  columns: unknown[];
};

const mockGridRender = vi.fn();

vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: React.forwardRef((props: MockGridProps, ref: React.Ref<unknown>) => {
    mockGridRender(props);
    React.useImperativeHandle(ref, () => ({
      refresh: vi.fn(),
      expandAll: vi.fn(),
      collapseAll: vi.fn(),
      getDisplayedColumns: vi.fn(() => []),
      getDisplayedColDefs: vi.fn(() => []),
      getDisplayedRows: vi.fn(() => []),
      getCurrentPageRows: vi.fn(() => []),
      resetColumnState: vi.fn(),
      isColumnsDirty: vi.fn(() => false),
    }));
    return (
      <div data-testid="grid">
        {props.rows.map((row) => (
          <div key={row.export_id} data-testid="grid-row">
            {row.export_id}
          </div>
        ))}
      </div>
    );
  }),
}));

/* ------------------------------------------------------------------ */
/* Fixtures */
/* ------------------------------------------------------------------ */

function makeJob(overrides: Partial<ExportListData> = {}): ExportListData {
  return {
    export_id: 'job-1',
    entity_type: 'VESSEL',
    entity_id: 'entity-1',
    entity_display_name: 'MV Test Vessel',
    event_type: ['PORT_ARRIVAL'],
    date_start: '2026-08-01T00:00:00Z',
    date_end: '2026-08-02T00:00:00Z',
    status: 'COMPLETED',
    requested_at: '2026-08-01T00:00:00Z',
    download_url_expires_at: '2026-08-10T00:00:00Z',
    error_message: null,
    unlocode: null,
    ...overrides,
  };
}

const vesselJob = makeJob({
  export_id: 'job-vessel',
  entity_type: 'VESSEL',
  entity_display_name: 'MV Vessel Export',
  status: 'COMPLETED',
});

const portJob = makeJob({
  export_id: 'job-port',
  entity_type: 'PORT',
  entity_display_name: 'Rotterdam Export',
  status: 'FAILED',
});

const zoneJob = makeJob({
  export_id: 'job-zone',
  entity_type: 'ZONE',
  entity_display_name: 'Baltic Zone Export',
  status: 'PROCESSING',
});

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('Downloads', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    mockHookState = {
      jobs: [vesselJob, portJob, zoneJob],
      isLoading: false,
      retryJobWithPolling: mockRetryJobWithPolling,
      downloadCsv: mockDownloadCsv,
      fetchRecentExportJobs: mockFetchRecentExportJobs,
      timeAgo: '5s',
    };
  });

  it('renders the grid with all jobs by default (all types selected)', () => {
    render(<Downloads />);

    expect(screen.getAllByTestId('grid-row')).toHaveLength(3);
  });

  it('passes the 6 column definitions through to the grid', () => {
    render(<Downloads />);

    expect(mockGridRender).toHaveBeenCalled();
    const lastCallProps = mockGridRender.mock.calls.at(
      -1,
    )?.[0] as MockGridProps;
    expect(lastCallProps.columns).toHaveLength(6);
  });

  it('renders the "Updated Xs ago" text from the hook', () => {
    render(<Downloads />);
    expect(screen.getByText(/Updated 5s ago/)).toBeInTheDocument();
  });

  it('shows the loading overlay when isLoading is true', () => {
    mockHookState.isLoading = true;
    render(<Downloads />);
    expect(document.querySelector('.absolute.inset-0')).toBeInTheDocument();
  });

  it('does not show the loading overlay when isLoading is false', () => {
    render(<Downloads />);
    expect(document.querySelector('.absolute.inset-0')).not.toBeInTheDocument();
  });

  it('calls fetchRecentExportJobs when the Refresh button is clicked', () => {
    render(<Downloads />);
    fireEvent.click(screen.getByRole('button', { name: 'Refresh' }));
    expect(mockFetchRecentExportJobs).toHaveBeenCalled();
  });

  it('disables the Refresh button while loading', () => {
    mockHookState.isLoading = true;
    render(<Downloads />);
    expect(screen.getByRole('button', { name: 'Refresh' })).toBeDisabled();
  });

  it('filters rows to the entity types selected in the Type dropdown', () => {
    render(<Downloads />);

    // Open the "Type" dropdown.
    fireEvent.click(screen.getByRole('button', { name: /Type/ }));

    // Uncheck "Vessel" so only Port/Zone jobs remain.
    fireEvent.click(screen.getByLabelText('Vessel'));

    const rows = screen.getAllByTestId('grid-row').map((el) => el.textContent);
    expect(rows).toEqual(['job-port', 'job-zone']);
  });

  it('filters out all rows when every type is deselected', () => {
    render(<Downloads />);

    fireEvent.click(screen.getByRole('button', { name: /Type/ }));
    fireEvent.click(screen.getByLabelText('Select All'));

    expect(screen.queryAllByTestId('grid-row')).toHaveLength(0);
  });

  describe('search filter', () => {
    it('filters rows by entity display name', () => {
      render(<Downloads />);

      fireEvent.change(screen.getByPlaceholderText('Search exports...'), {
        target: { value: 'Rotterdam' },
      });

      expect(screen.getAllByTestId('grid-row')).toHaveLength(1);
      expect(screen.getByTestId('grid-row')).toHaveTextContent('job-port');
    });

    it('filters rows by status', () => {
      render(<Downloads />);

      fireEvent.change(screen.getByPlaceholderText('Search exports...'), {
        target: { value: 'processing' },
      });

      expect(screen.getAllByTestId('grid-row')).toHaveLength(1);
      expect(screen.getByTestId('grid-row')).toHaveTextContent('job-zone');
    });

    it('shows no rows for a query that matches nothing', () => {
      render(<Downloads />);

      fireEvent.change(screen.getByPlaceholderText('Search exports...'), {
        target: { value: 'no-such-export' },
      });

      expect(screen.queryAllByTestId('grid-row')).toHaveLength(0);
    });

    it('shows all currently type-filtered rows when the query is cleared', () => {
      render(<Downloads />);
      const input = screen.getByPlaceholderText('Search exports...');

      fireEvent.change(input, { target: { value: 'Rotterdam' } });
      expect(screen.getAllByTestId('grid-row')).toHaveLength(1);

      fireEvent.change(input, { target: { value: '' } });
      expect(screen.getAllByTestId('grid-row')).toHaveLength(3);
    });
  });
});
