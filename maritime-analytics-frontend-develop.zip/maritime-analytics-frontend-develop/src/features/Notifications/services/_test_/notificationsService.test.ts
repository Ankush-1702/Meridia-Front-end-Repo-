import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  getNotifications,
  getNotificationsPreference,
  updateNotificationsPreference,
} from '@/features/Notifications/services/notificationsService';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const { fetchWithAuthMock } = vi.hoisted(() => ({
  fetchWithAuthMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Module mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'http://localhost',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
}));

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: fetchWithAuthMock,
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({
    Authorization: 'Bearer token',
  }),
}));

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function mockResponse(ok: boolean, status = 200, body: unknown = {}) {
  return {
    ok,
    status,
    statusText: 'Error',
    json: vi.fn().mockResolvedValue(body),
    text: vi.fn().mockResolvedValue('error'),
  } as unknown as Response;
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('notificationsService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    localStorage.setItem('user', JSON.stringify({ user_id: 'user-1' }));
  });

  /* ------------------------------------------------------------------ */
  /* getNotifications */
  /* ------------------------------------------------------------------ */

  it('fetches notifications successfully with params', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(true, 200, { data: [] }),
    );

    const res = await getNotifications('PORT_ARRIVAL', 10, 20);

    expect(fetchWithAuthMock).toHaveBeenCalledWith(
      expect.stringContaining(
        '/users/user-1/notifications?limit=20&offset=10&event_type=PORT_ARRIVAL',
      ),
      { Authorization: 'Bearer token' },
    );

    expect(res).toEqual({ data: [] });
  });

  it('throws error when getNotifications fails', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(false, 500, { message: 'Boom' }),
    );

    await expect(getNotifications()).rejects.toMatchObject({
      message: 'Boom',
      status: 500,
    });
  });

  /* ------------------------------------------------------------------ */
  /* getNotificationsPreference */
  /* ------------------------------------------------------------------ */

  it('fetches notification preferences successfully', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(true, 200, {
        recencyOptions: [],
        selectedRecencyPreference: 'ALL',
      }),
    );

    const res = await getNotificationsPreference();

    expect(fetchWithAuthMock).toHaveBeenCalledWith(
      'http://localhost/maritime-analytics/v1/users/user-1/notification-settings/options',
      { Authorization: 'Bearer token' },
    );

    expect(res.selectedRecencyPreference).toBe('ALL');
  });

  it('throws error when getNotificationsPreference fails', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(false, 403, { error: 'Forbidden' }),
    );

    await expect(getNotificationsPreference()).rejects.toMatchObject({
      message: 'Forbidden',
      status: 403,
    });
  });

  /* ------------------------------------------------------------------ */
  /* updateNotificationsPreference */
  /* ------------------------------------------------------------------ */

  it('updates notification preference successfully', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(true, 200, { recencyPreference: 'LAST_24_HOURS' }),
    );

    const res = await updateNotificationsPreference('LAST_24_HOURS');

    expect(fetchWithAuthMock).toHaveBeenCalledWith(
      'http://localhost/maritime-analytics/v1/users/user-1/notification-settings',
      {
        method: 'PUT',
        headers: { Authorization: 'Bearer token' },
        body: JSON.stringify({ recencyPreference: 'LAST_24_HOURS' }),
      },
    );

    expect(res.recencyPreference).toBe('LAST_24_HOURS');
  });

  it('returns response even when updateNotificationsPreference response is not ok', async () => {
    fetchWithAuthMock.mockResolvedValueOnce(
      mockResponse(false, 400, { recencyPreference: 'ALL' }),
    );

    const res = await updateNotificationsPreference('ALL');

    expect(res.recencyPreference).toBe('ALL');
  });
});
