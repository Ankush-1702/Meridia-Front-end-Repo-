import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  NotificationsResponse,
  NotificationsSettingsOptions,
  SelectedRecencyPreference,
  UpdateNotificationsPreference,
} from '@/features/Notifications/types/notificationsTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export async function getNotifications(
  event_type?: string,
  offset?: number,
  limit?: number,
): Promise<NotificationsResponse> {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
    event_type: event_type?.toString() || '',
  });
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/notifications?${params.toString()}`,
    getAuthHeaders(),
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });

    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;

    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;

    throw err || new Error('Failed to get notifications');
  }
  const response = await res.json();
  return response;
}

export async function getNotificationsPreference(): Promise<NotificationsSettingsOptions> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/notification-settings/options`,
    getAuthHeaders(),
  );
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to get notifications preference');
  }
  const response = await res.json();
  return response;
}

export async function updateNotificationsPreference(
  value: SelectedRecencyPreference,
): Promise<UpdateNotificationsPreference> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/notification-settings`,
    {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ recencyPreference: value }),
    },
  );
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
  }

  const response = await res.json();
  return response;
}
