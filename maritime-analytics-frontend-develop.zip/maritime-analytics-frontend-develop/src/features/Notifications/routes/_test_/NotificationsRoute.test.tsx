import React from 'react';
import { describe, it, expect } from 'vitest';
import { notificationsRoutes } from '@/features/Notifications/routes/NotificationsRoute';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

describe('notificationsRoutes', () => {
  it('defines the notifications route', () => {
    const routes = notificationsRoutes();

    expect(routes).toHaveLength(1);

    const route = routes[0];

    expect(route.path).toBe('/analytics/notifications');
    expect(React.isValidElement(route.element)).toBe(true);
  });

  it('wraps NotificationsPage in SuspenseWrapper', () => {
    const routes = notificationsRoutes();
    const route = routes[0];

    expect(route.element.type).toBe(SuspenseWrapper);

    const child = route.element.props.children;
    expect(child.type.$$typeof).toBe(Symbol.for('react.lazy'));
  });
});
