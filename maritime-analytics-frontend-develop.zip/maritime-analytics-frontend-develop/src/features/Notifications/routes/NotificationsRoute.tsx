import { lazy } from 'react';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

const NotificationsPage = lazy(
  () => import('@/features/Notifications/Notifications'),
);

export const notificationsRoutes = () => [
  {
    path: '/analytics/notifications',
    element: (
      <SuspenseWrapper>
        <NotificationsPage />
      </SuspenseWrapper>
    ),
  },
];
