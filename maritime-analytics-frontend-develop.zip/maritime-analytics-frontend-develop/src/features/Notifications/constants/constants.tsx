export const NOTIFICATIONS_TOPIC = '/user/topic/notifications';
