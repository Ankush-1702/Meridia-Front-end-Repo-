import Header from '@/shared/ui/Header';

interface NotificationsHeaderProps {
  headerText: string;
}
export default function NotificationsHeader({
  headerText,
}: NotificationsHeaderProps) {
  return <Header headerText={headerText} />;
}
