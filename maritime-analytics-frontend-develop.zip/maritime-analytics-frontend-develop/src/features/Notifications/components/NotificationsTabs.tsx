import TabGroup from '@/shared/components/TabGroup';

interface Props {
  className: string;
  tabs: string[];
  active: string;
  onChange: (tab: string) => void;
}

export default function NotificationsTabs({
  className,
  tabs,
  active,
  onChange,
}: Props) {
  return (
    <div>
      <TabGroup
        tabs={tabs}
        active={active}
        onChange={onChange}
        className={className}
      />
    </div>
  );
}
