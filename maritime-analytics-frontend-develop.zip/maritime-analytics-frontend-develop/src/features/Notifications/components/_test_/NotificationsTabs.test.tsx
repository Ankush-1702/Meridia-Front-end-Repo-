import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import NotificationsTabs from '@/features/Notifications/components/NotificationsTabs';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/TabGroup', () => ({
  default: ({
    tabs,
    active,
    onChange,
    className,
  }: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
    className: string;
  }) => (
    <div data-testid="tab-group" className={className}>
      {tabs.map((tab) => (
        <button
          key={tab}
          data-active={tab === active}
          onClick={() => onChange(tab)}
        >
          {tab}
        </button>
      ))}
    </div>
  ),
}));

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotificationsTabs', () => {
  const tabs = ['All', 'Unread', 'Archived'];

  it('renders TabGroup with provided tabs', () => {
    render(
      <NotificationsTabs
        className="px-4"
        tabs={tabs}
        active="All"
        onChange={vi.fn()}
      />,
    );

    expect(screen.getByTestId('tab-group')).toBeInTheDocument();

    tabs.forEach((tab) => {
      expect(screen.getByText(tab)).toBeInTheDocument();
    });
  });

  it('passes active tab correctly', () => {
    render(
      <NotificationsTabs
        className="px-4"
        tabs={tabs}
        active="Unread"
        onChange={vi.fn()}
      />,
    );

    const activeButton = screen.getByText('Unread');
    expect(activeButton).toHaveAttribute('data-active', 'true');
  });

  it('calls onChange when a tab is clicked', () => {
    const onChangeMock = vi.fn();

    render(
      <NotificationsTabs
        className="px-4"
        tabs={tabs}
        active="All"
        onChange={onChangeMock}
      />,
    );

    fireEvent.click(screen.getByText('Archived'));

    expect(onChangeMock).toHaveBeenCalledTimes(1);
    expect(onChangeMock).toHaveBeenCalledWith('Archived');
  });

  it('applies provided className to TabGroup', () => {
    render(
      <NotificationsTabs
        className="px-4"
        tabs={tabs}
        active="All"
        onChange={vi.fn()}
      />,
    );

    expect(screen.getByTestId('tab-group')).toHaveClass('px-4');
  });
});
