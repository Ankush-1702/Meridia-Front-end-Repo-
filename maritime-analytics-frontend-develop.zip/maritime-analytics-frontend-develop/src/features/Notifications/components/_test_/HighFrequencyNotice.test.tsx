import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import HighFrequencyNotice from '@/features/Notifications/components/HighFrequencyNotice';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('HighFrequencyNotice', () => {
  it('renders notification count correctly', () => {
    render(<HighFrequencyNotice count={3} />);

    expect(
      screen.getByText('3 new notifications received'),
    ).toBeInTheDocument();
  });

  it('renders the show button', () => {
    render(<HighFrequencyNotice count={1} />);

    expect(screen.getByRole('button', { name: /show/i })).toBeInTheDocument();
  });

  it('calls show callback when button is clicked', () => {
    const showMock = vi.fn();

    render(<HighFrequencyNotice count={5} show={showMock} />);

    fireEvent.click(screen.getByRole('button', { name: /show/i }));

    expect(showMock).toHaveBeenCalledTimes(1);
  });

  it('does not throw if show prop is not provided', () => {
    render(<HighFrequencyNotice count={2} />);

    fireEvent.click(screen.getByRole('button', { name: /show/i }));

    expect(
      screen.getByText('2 new notifications received'),
    ).toBeInTheDocument();
  });

  it('renders even when count is undefined', () => {
    render(<HighFrequencyNotice />);

    expect(
      screen.getByText('0 new notifications received'),
    ).toBeInTheDocument();
  });
});
