import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import NotificationsHeader from '@/features/Notifications/components/NotificationsHeader';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/ui/Header', () => ({
  default: ({ headerText }: { headerText: string }) => (
    <h1 data-testid="header">{headerText}</h1>
  ),
}));

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotificationsHeader', () => {
  it('renders the header text via Header component', () => {
    render(<NotificationsHeader headerText="Notifications" />);

    expect(screen.getByTestId('header')).toHaveTextContent('Notifications');
  });

  it('renders provided headerText in the document', () => {
    render(<NotificationsHeader headerText="Alerts" />);

    expect(screen.getByText('Alerts')).toBeInTheDocument();
  });
});
