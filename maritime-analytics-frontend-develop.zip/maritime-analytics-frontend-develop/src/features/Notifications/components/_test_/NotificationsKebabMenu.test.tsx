import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { NotificationsKebabMenu } from '@/features/Notifications/components/NotificationsKebabMenu';
import type {
  RecencyOptions,
  SelectedRecencyPreference,
} from '@/features/Notifications/types/notificationsTypes';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', () => ({
  Spinner: () => <div data-testid="spinner" />,
}));

vi.mock('@/shared/ui/KebabMenu', () => ({
  KebabMenu: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="kebab-menu">{children}</div>
  ),
}));

vi.mock('react-icons/io5', () => ({
  IoCheckmark: () => <span data-testid="checkmark" />,
}));

/* ------------------------------------------------------------------ */
/* Test data */
/* ------------------------------------------------------------------ */

const options: RecencyOptions[] = [
  {
    label: 'All notifications',
    description: 'Show all notifications',
    code: 'ALL' as SelectedRecencyPreference,
  },
  {
    label: 'Last 24 hours',
    description: 'Show recent notifications',
    code: 'LAST_24_HOURS' as SelectedRecencyPreference,
  },
];

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotificationsKebabMenu', () => {
  it('renders kebab menu container and title text', () => {
    render(<NotificationsKebabMenu />);

    expect(screen.getByTestId('kebab-menu')).toBeInTheDocument();
    expect(screen.getByText('Show Notifications')).toBeInTheDocument();
  });

  it('shows spinner when loading is true', () => {
    render(<NotificationsKebabMenu loading />);

    expect(screen.getByTestId('spinner')).toBeInTheDocument();
  });

  it('renders notification options when not loading', () => {
    render(
      <NotificationsKebabMenu notifSettingsOptions={options} loading={false} />,
    );

    expect(screen.getByText('All')).toBeInTheDocument();
    expect(screen.getByText('Last 24 hours')).toBeInTheDocument();
  });

  it('renders "All" instead of "All notifications"', () => {
    render(
      <NotificationsKebabMenu notifSettingsOptions={options} loading={false} />,
    );

    expect(screen.getByText('All')).toBeInTheDocument();
    expect(screen.queryByText('All notifications')).not.toBeInTheDocument();
  });

  it('shows checkmark for selected recency preference', () => {
    render(
      <NotificationsKebabMenu
        notifSettingsOptions={options}
        selectedRecencyPreference="LAST_24_HOURS"
      />,
    );

    expect(screen.getByTestId('checkmark')).toBeInTheDocument();
  });

  it('calls updateRecencyPreference when option is clicked', () => {
    const updateMock = vi.fn();

    render(
      <NotificationsKebabMenu
        notifSettingsOptions={options}
        updateRecencyPreference={updateMock}
      />,
    );

    fireEvent.click(screen.getByText('All'));

    expect(updateMock).toHaveBeenCalledWith('ALL');
  });

  it('does not throw if updateRecencyPreference is not provided', () => {
    render(
      <NotificationsKebabMenu notifSettingsOptions={options} loading={false} />,
    );

    fireEvent.click(screen.getByText('All'));

    expect(screen.getByText('All')).toBeInTheDocument();
  });
});
