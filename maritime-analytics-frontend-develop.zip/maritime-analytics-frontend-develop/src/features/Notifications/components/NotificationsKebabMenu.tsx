import { Spinner } from 'flowbite-react';
import { IoCheckmark } from 'react-icons/io5';
import {
  RecencyOptions,
  SelectedRecencyPreference,
} from '@/features/Notifications/types/notificationsTypes';
import { KebabMenu } from '@/shared/ui/KebabMenu';

type Props = {
  notifSettingsOptions?: RecencyOptions[];
  selectedRecencyPreference?: SelectedRecencyPreference;
  loading?: boolean;
  updateRecencyPreference?: (value: SelectedRecencyPreference) => void;
};

export function NotificationsKebabMenu({
  notifSettingsOptions,
  selectedRecencyPreference,
  loading,
  updateRecencyPreference,
}: Props) {
  return (
    <KebabMenu>
      <div>
        <p className="px-4 py-3 text-xs text-gray-500 dark:text-gray-400">
          Show Notifications
        </p>
      </div>

      <div className="p-1">
        {loading && (
          <div className="flex items-center justify-center py-3">
            <Spinner light size="md" color="default" />
          </div>
        )}

        {!loading &&
          notifSettingsOptions?.map((option) => (
            <div
              tabIndex={0}
              role="button"
              onKeyDown={() => updateRecencyPreference?.(option.code)}
              key={option.code}
              className="cursor-pointer rounded-lg px-1 py-2 text-sm hover:bg-gray-200 dark:hover:bg-gray-700"
              onClick={() => updateRecencyPreference?.(option.code)}
            >
              <p
                className="flex items-center justify-between px-2 dark:text-white"
                title={option.description}
              >
                {option.label === 'All notifications' ? 'All' : option.label}

                {selectedRecencyPreference === option.code && (
                  <IoCheckmark className="text-primary-600" />
                )}
              </p>
            </div>
          ))}
      </div>
    </KebabMenu>
  );
}
