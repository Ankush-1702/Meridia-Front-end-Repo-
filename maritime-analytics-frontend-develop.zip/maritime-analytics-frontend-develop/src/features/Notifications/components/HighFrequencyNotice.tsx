import { FaInfoCircle } from 'react-icons/fa';

interface Props {
  count?: number;
  show?: () => void;
}

export default function HighFrequencyNotice({ count, show }: Props) {
  return (
    <div className="flex w-full items-center justify-between rounded-lg border border-primary-200 bg-primary-50 p-4">
      <div className="flex items-center gap-2">
        <FaInfoCircle className="h-3 w-3 text-primary-800" />
        <p className="text-sm text-primary-800">
          {count ?? 0} new notifications received
        </p>
      </div>
      <button
        onClick={() => show?.()}
        className="rounded-lg border border-gray-200 bg-white px-2 py-2 text-sm hover:bg-gray-100"
      >
        show
      </button>
    </div>
  );
}
