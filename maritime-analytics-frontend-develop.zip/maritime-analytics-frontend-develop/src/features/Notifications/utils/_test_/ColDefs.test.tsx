import { render, screen } from '@testing-library/react';
import type { ITooltipParams } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';

import type { Notifications } from '@/features/Notifications/types/notificationsTypes';
import { createNotificationsColDefs } from '@/features/Notifications/utils/ColDefs';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => (
    <span data-testid="status-badge">{status}</span>
  ),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode: string }) => (
    <span data-testid="flag-icon">{flagCode}</span>
  ),
}));

vi.mock('@/shared/utils/NavigatetoDetailsPage', () => ({
  NavigateToDetailsPage: ({
    detailsRoute,
    children,
  }: {
    detailsRoute: string;
    children?: React.ReactNode;
  }) => (
    <div data-testid="navigate" data-route={detailsRoute}>
      {children}
    </div>
  ),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: vi.fn(() => 'UTC_DATE'),
  convertUTCToLocalTime: vi.fn(() => 'LOCAL_DATE'),
  formatEpochMsToUTCDateString: vi.fn(() => 'RAW_DATE'),
  toTitleCase: (v: string) => v.toUpperCase(),
}));

/* ------------------------------------------------------------------ */
/* Fixtures */
/* ------------------------------------------------------------------ */

const baseNotification: Notifications = {
  notificationId: '1',
  vesselName: 'Vessel A',
  eventType: 'ZONE_ENTRY',
  createdAt: '123456',
  zonePortName: 'Zone A',
  screeningResult: 'CRITICAL',
  vesselType: 'cargo',
  eventId: '1',
  eventTimestamp: '123456',
  imo: 'IMO123',
  flag: 'Flag',
  flagCode: 'US',
  zonePortId: 'zone-1',
  subscriptionId: null,
  subscriptionName: null,
};

/* ------------------------------------------------------------------ */
/* Helpers (strict, no any) */
/* ------------------------------------------------------------------ */

function renderCell(
  renderer: (p: CustomCellRendererProps<Notifications>) => JSX.Element,
  data: Notifications,
) {
  const params = { data } as unknown as CustomCellRendererProps<Notifications>;
  render(renderer(params));
}

function tooltipParams(overrides: Partial<ITooltipParams>): ITooltipParams {
  return {
    value: undefined,
    data: baseNotification,
    ...overrides,
  } as unknown as ITooltipParams;
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('createNotificationsColDefs – coverage optimized', () => {
  it('returns expected number of columns', () => {
    expect(createNotificationsColDefs('utc', 'All')).toHaveLength(7);
  });

  it('uses UTC header when timezone is utc', () => {
    expect(createNotificationsColDefs('utc', 'All')[0].headerName).toContain(
      'UTC',
    );
  });

  it('uses System header when timezone is system', () => {
    expect(createNotificationsColDefs('system', 'All')[0].headerName).toContain(
      'System',
    );
  });

  it('changes header for Zones tab', () => {
    expect(createNotificationsColDefs('utc', 'Zones')[1].headerName).toBe(
      'Zone Name',
    );
  });

  it('changes header for Ports tab', () => {
    expect(createNotificationsColDefs('utc', 'Ports')[1].headerName).toBe(
      'Port Name',
    );
  });

  it('renders UTC date cell', () => {
    const cols = createNotificationsColDefs('utc', 'All');
    render(
      cols[0].cellRenderer!({
        value: '123456',
      } as unknown as CustomCellRendererProps<Notifications>),
    );
    expect(screen.getByText('UTC_DATE')).toBeInTheDocument();
  });

  it('navigates to zone page for zone events', () => {
    const cols = createNotificationsColDefs('utc', 'All');
    renderCell(cols[1].cellRenderer!, baseNotification);
    expect(screen.getByTestId('navigate')).toHaveAttribute(
      'data-route',
      '/analytics/zone/zone-1',
    );
  });

  it('navigates to port page for port events', () => {
    const cols = createNotificationsColDefs('utc', 'All');
    renderCell(cols[1].cellRenderer!, {
      ...baseNotification,
      eventType: 'PORT_ARRIVAL',
    });
    expect(screen.getByTestId('navigate')).toHaveAttribute(
      'data-route',
      '/analytics/port/zone-1',
    );
  });

  it('formats event type tooltip correctly', () => {
    const tooltip = createNotificationsColDefs('utc', 'All')[2]
      .tooltipValueGetter!(tooltipParams({ value: 'ZONE_ENTRY' }));
    expect(tooltip).toBe('ENTRY');
  });

  it('renders vessel navigation with flag icon', () => {
    const cols = createNotificationsColDefs('utc', 'All');
    renderCell(cols[3].cellRenderer!, baseNotification);
    expect(screen.getByTestId('flag-icon')).toHaveTextContent('US');
  });

  it('risk tooltip returns UNSCORED when screeningResult is "-"', () => {
    const tooltip = createNotificationsColDefs('utc', 'All')[6]
      .tooltipValueGetter!(
      tooltipParams({
        data: { ...baseNotification, screeningResult: '-' },
      }),
    );
    expect(tooltip).toBe('UNSCORED');
  });

  it('risk tooltip explains NA for port departure', () => {
    const tooltip = createNotificationsColDefs('utc', 'All')[6]
      .tooltipValueGetter!(
      tooltipParams({
        data: { ...baseNotification, eventType: 'PORT_DEPARTURE' },
      }),
    );
    expect(tooltip).toContain('Auto-screening');
  });

  it('risk tooltip explains NA for tug vessels', () => {
    const tooltip = createNotificationsColDefs('utc', 'All')[6]
      .tooltipValueGetter!(
      tooltipParams({
        data: { ...baseNotification, vesselType: 'tug' },
      }),
    );
    expect(tooltip).toContain('Auto-screening');
  });

  it('renders risk badge with computed CRITICAL risk', () => {
    const cols = createNotificationsColDefs('utc', 'All');
    renderCell(cols[6].cellRenderer!, baseNotification);
    expect(screen.getByTestId('status-badge')).toHaveTextContent('CRITICAL');
  });
});
