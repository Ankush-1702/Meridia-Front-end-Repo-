import { fireEvent, render, screen } from '@testing-library/react';
import type { ITooltipParams } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';

import { CreateDownloadsColDefs } from '@/features/Notifications/utils/DownloadColDefs';
import type { ExportListData } from '@/shared/services/exportServices/exportTypes';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => (
    <span data-testid="status-badge">{status}</span>
  ),
}));

vi.mock('@/features/Notifications/utils/downloadUtils', () => ({
  SCOPE_LABEL: { VESSEL: 'Vessel', FLEET: 'Fleet' },
  getExpiresText: vi.fn(() => 'EXPIRES_TEXT'),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: vi.fn(() => 'UTC_DATE, 10:00:00'),
  convertUTCToLocalTime: vi.fn(() => 'LOCAL_DATE, 11:00:00'),
  toTitleCase: (v: string) => v.toUpperCase(),
  EVENT_LABEL_MAP: { PORT_ARRIVAL: 'Arrival', ZONE_ENTRY: 'Entry' },
}));

/* ------------------------------------------------------------------ */
/* Fixtures */
/* ------------------------------------------------------------------ */

const baseJob: ExportListData = {
  export_id: 'job-1',
  entity_type: 'VESSEL',
  entity_id: 'entity-1',
  entity_display_name: 'MV Test Vessel',
  event_type: ['PORT_ARRIVAL', 'ZONE_ENTRY'],
  date_start: '2026-08-01T00:00:00Z',
  date_end: '2026-08-02T00:00:00Z',
  status: 'COMPLETED',
  requested_at: '2026-08-01T00:00:00Z',
  download_url_expires_at: '2026-08-10T00:00:00Z',
  error_message: null,
  unlocode: null,
};

function makeJob(overrides: Partial<ExportListData> = {}): ExportListData {
  return { ...baseJob, ...overrides };
}

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function getColDefs(timeZoneSetting: string = 'utc') {
  const retryWithPolling = vi.fn();
  const download = vi.fn();
  const retryingJobsRef = { current: new Set<string>() };
  const downloadingJobsRef = { current: new Set<string>() };
  const nowRef = { current: Date.now() };

  const cols = CreateDownloadsColDefs(
    timeZoneSetting,
    nowRef,
    retryWithPolling,
    download,
    retryingJobsRef,
    downloadingJobsRef,
  );

  return {
    cols,
    retryWithPolling,
    download,
    retryingJobsRef,
    downloadingJobsRef,
    nowRef,
  };
}

function renderCell(
  renderer: (p: CustomCellRendererProps<ExportListData>) => React.ReactNode,
  data?: ExportListData,
) {
  const params = { data } as unknown as CustomCellRendererProps<ExportListData>;
  return render(<>{renderer(params)}</>);
}

function tooltipParams(
  overrides: Partial<ITooltipParams<ExportListData>>,
): ITooltipParams<ExportListData> {
  return {
    value: undefined,
    data: baseJob,
    ...overrides,
  } as unknown as ITooltipParams<ExportListData>;
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('CreateDownloadsColDefs', () => {
  it('returns 6 columns', () => {
    const { cols } = getColDefs();
    expect(cols).toHaveLength(6);
  });

  describe('Export column', () => {
    it('renders display name and mapped event labels with the date range', () => {
      const { cols } = getColDefs();
      renderCell(cols[0].cellRenderer!, baseJob);

      expect(screen.getByText('MV Test Vessel')).toBeInTheDocument();
      expect(screen.getByText(/Arrival, Entry/)).toBeInTheDocument();
    });

    it('renders "—" when no data is present', () => {
      const { cols } = getColDefs();
      renderCell(cols[0].cellRenderer!);
      expect(screen.getByText('—')).toBeInTheDocument();
    });

    it('omits the date range when date_start/date_end are missing', () => {
      const { cols } = getColDefs();
      renderCell(
        cols[0].cellRenderer!,
        makeJob({ date_start: '', date_end: '' }),
      );
      expect(screen.getByText('Arrival, Entry')).toBeInTheDocument();
    });

    it('builds a tooltip string including display name and event labels', () => {
      const { cols } = getColDefs();
      const tooltip = cols[0].tooltipValueGetter!(
        tooltipParams({ data: baseJob }),
      );
      expect(tooltip).toContain('MV Test Vessel');
      expect(tooltip).toContain('Arrival, Entry');
    });

    it('tooltip returns "—" when there is no data', () => {
      const { cols } = getColDefs();
      const tooltip = cols[0].tooltipValueGetter!(
        tooltipParams({ data: undefined }),
      );
      expect(tooltip).toBe('—');
    });
  });

  describe('Type column', () => {
    it('renders the mapped scope label', () => {
      const { cols } = getColDefs();
      renderCell(cols[1].cellRenderer!, makeJob({ entity_type: 'VESSEL' }));
      expect(screen.getByText('Vessel')).toBeInTheDocument();
    });

    it('falls back to the raw entity_type for an unmapped scope', () => {
      const { cols } = getColDefs();
      renderCell(
        cols[1].cellRenderer!,
        makeJob({ entity_type: 'PORT' as ExportListData['entity_type'] }),
      );
      expect(screen.getByText('PORT')).toBeInTheDocument();
    });

    it('renders "—" when no data is present', () => {
      const { cols } = getColDefs();
      renderCell(cols[1].cellRenderer!);
      expect(screen.getByText('—')).toBeInTheDocument();
    });

    it('tooltip returns "—" when there is no data', () => {
      const { cols } = getColDefs();
      const tooltip = cols[1].tooltipValueGetter!(
        tooltipParams({ data: undefined }),
      );
      expect(tooltip).toBe('—');
    });
  });

  describe('Requested On column', () => {
    it('uses the UTC header label when timeZoneSetting is "utc"', () => {
      const { cols } = getColDefs('utc');
      expect(cols[2].headerName).toBe('Requested On (UTC)');
    });

    it('uses the system header label when timeZoneSetting is not "utc"', () => {
      const { cols } = getColDefs('system');
      expect(cols[2].headerName).toBe('Requested On (System)');
    });

    it('renders the UTC-formatted date when timeZoneSetting is "utc"', () => {
      const { cols } = getColDefs('utc');
      render(
        cols[2].cellRenderer!({
          value: baseJob.requested_at,
        } as unknown as CustomCellRendererProps<ExportListData>),
      );
      expect(screen.getByText('UTC_DATE, 10:00:00')).toBeInTheDocument();
    });

    it('renders the local-formatted date when timeZoneSetting is not "utc"', () => {
      const { cols } = getColDefs('system');
      render(
        cols[2].cellRenderer!({
          value: baseJob.requested_at,
        } as unknown as CustomCellRendererProps<ExportListData>),
      );
      expect(screen.getByText('LOCAL_DATE, 11:00:00')).toBeInTheDocument();
    });
  });

  describe('Status column', () => {
    it('renders a StatusBadge with the job status', () => {
      const { cols } = getColDefs();
      renderCell(cols[3].cellRenderer!, makeJob({ status: 'FAILED' }));
      expect(screen.getByTestId('status-badge')).toHaveTextContent('FAILED');
    });

    it('renders "—" when no data is present', () => {
      const { cols } = getColDefs();
      renderCell(cols[3].cellRenderer!);
      expect(screen.getByText('—')).toBeInTheDocument();
    });

    it('tooltip title-cases the status', () => {
      const { cols } = getColDefs();
      const tooltip = cols[3].tooltipValueGetter!(
        tooltipParams({ data: makeJob({ status: 'PROCESSING' }) }),
      );
      expect(tooltip).toBe('PROCESSING');
    });

    it('tooltip returns "—" when there is no status', () => {
      const { cols } = getColDefs();
      const tooltip = cols[3].tooltipValueGetter!(
        tooltipParams({ data: undefined }),
      );
      expect(tooltip).toBe('—');
    });
  });

  describe('Expires column', () => {
    it('renders "Expired" for an EXPIRED job without calling getExpiresText', () => {
      const { cols } = getColDefs();
      renderCell(cols[4].cellRenderer!, makeJob({ status: 'EXPIRED' }));
      expect(screen.getByText('Expired')).toBeInTheDocument();
    });

    it('delegates to getExpiresText for non-expired jobs', () => {
      const { cols } = getColDefs();
      renderCell(cols[4].cellRenderer!, makeJob({ status: 'COMPLETED' }));
      expect(screen.getByText('EXPIRES_TEXT')).toBeInTheDocument();
    });

    it('renders "—" when no data is present', () => {
      const { cols } = getColDefs();
      renderCell(cols[4].cellRenderer!);
      expect(screen.getByText('—')).toBeInTheDocument();
    });

    it('tooltip returns "Expired" for an EXPIRED job', () => {
      const { cols } = getColDefs();
      const tooltip = cols[4].tooltipValueGetter!(
        tooltipParams({ data: makeJob({ status: 'EXPIRED' }) }),
      );
      expect(tooltip).toBe('Expired');
    });

    it('tooltip returns "—" when there is no data', () => {
      const { cols } = getColDefs();
      const tooltip = cols[4].tooltipValueGetter!(
        tooltipParams({ data: undefined }),
      );
      expect(tooltip).toBe('—');
    });
  });

  describe('Actions column', () => {
    it('renders nothing when there is no data', () => {
      const { cols } = getColDefs();
      const { container } = renderCell(cols[5].cellRenderer!);
      expect(container).toBeEmptyDOMElement();
    });

    it('renders an enabled Download CSV button for a COMPLETED job and invokes download on click', () => {
      const { cols, download } = getColDefs();
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'COMPLETED' }));

      const btn = screen.getByRole('button', { name: /Download CSV/i });
      expect(btn).not.toBeDisabled();

      fireEvent.click(btn);
      expect(download).toHaveBeenCalledWith('job-1');
    });

    it('shows a disabled "Downloading..." state when the job id is in downloadingJobsRef', () => {
      const { cols, downloadingJobsRef } = getColDefs();
      downloadingJobsRef.current.add('job-1');
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'COMPLETED' }));

      const btn = screen.getByRole('button', { name: /Downloading\.\.\./i });
      expect(btn).toBeDisabled();
    });

    it('renders an enabled Retry button for a FAILED job and invokes retryWithPolling on click', () => {
      const { cols, retryWithPolling } = getColDefs();
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'FAILED' }));

      const btn = screen.getByRole('button', { name: /^Retry$/i });
      expect(btn).not.toBeDisabled();

      fireEvent.click(btn);
      expect(retryWithPolling).toHaveBeenCalledWith('job-1', 'VESSEL', [
        'PORT_ARRIVAL',
        'ZONE_ENTRY',
      ]);
    });

    it('shows a disabled "Retrying..." state when the job id is in retryingJobsRef', () => {
      const { cols, retryingJobsRef } = getColDefs();
      retryingJobsRef.current.add('job-1');
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'FAILED' }));

      const btn = screen.getByRole('button', { name: /Retrying\.\.\./i });
      expect(btn).toBeDisabled();
    });

    it('renders a "Request again" button for an EXPIRED job and invokes retryWithPolling on click', () => {
      const { cols, retryWithPolling } = getColDefs();
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'EXPIRED' }));

      const btn = screen.getByRole('button', { name: /Request again/i });
      expect(btn).not.toBeDisabled();

      fireEvent.click(btn);
      expect(retryWithPolling).toHaveBeenCalledWith('job-1', 'VESSEL', [
        'PORT_ARRIVAL',
        'ZONE_ENTRY',
      ]);
    });

    it('shows a disabled "Requesting..." state for an EXPIRED job in retryingJobsRef', () => {
      const { cols, retryingJobsRef } = getColDefs();
      retryingJobsRef.current.add('job-1');
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'EXPIRED' }));

      const btn = screen.getByRole('button', { name: /Requesting\.\.\./i });
      expect(btn).toBeDisabled();
    });

    it('renders a placeholder dash for any other status (e.g. PROCESSING)', () => {
      const { cols } = getColDefs();
      renderCell(cols[5].cellRenderer!, makeJob({ status: 'PROCESSING' }));
      expect(screen.getByText('—')).toBeInTheDocument();
      expect(screen.queryByRole('button')).not.toBeInTheDocument();
    });
  });
});
