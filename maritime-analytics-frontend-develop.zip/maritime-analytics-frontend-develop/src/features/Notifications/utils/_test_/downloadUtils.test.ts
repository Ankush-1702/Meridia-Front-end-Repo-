import { describe, it, expect } from 'vitest';
import {
  SCOPE_LABEL,
  getExpiresText,
} from '@/features/Notifications/utils/downloadUtils';
import type { ExportListData } from '@/shared/services/exportServices/exportTypes';

function makeExport(overrides: Partial<ExportListData> = {}): ExportListData {
  return {
    status: 'COMPLETED',
    download_url_expires_at: null,
    ...overrides,
  } as ExportListData;
}

describe('SCOPE_LABEL', () => {
  it('maps each known scope to its display label', () => {
    expect(SCOPE_LABEL.VESSEL).toBe('Vessel');
    expect(SCOPE_LABEL.FLEET).toBe('Fleet');
    expect(SCOPE_LABEL.ZONE).toBe('Zone');
    expect(SCOPE_LABEL.PORT).toBe('Port');
  });

  it('is undefined for an unknown scope key', () => {
    expect(SCOPE_LABEL.UNKNOWN_SCOPE).toBeUndefined();
  });
});

describe('getExpiresText', () => {
  const NOW = new Date('2026-08-31T12:00:00Z').getTime();

  it('returns "Expired" when status is EXPIRED, regardless of expiry timestamp', () => {
    const data = makeExport({
      status: 'EXPIRED',
      download_url_expires_at: new Date(NOW + 60_000).toISOString(), // future, ignored
    });
    expect(getExpiresText(data, NOW)).toBe('Expired');
  });

  it('returns "Expired" when status is EXPIRED and there is no expiry timestamp at all', () => {
    const data = makeExport({
      status: 'EXPIRED',
      download_url_expires_at: null,
    });
    expect(getExpiresText(data, NOW)).toBe('Expired');
  });

  it('returns "—" when download_url_expires_at is missing (and status is not EXPIRED)', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: null,
    });
    expect(getExpiresText(data, NOW)).toBe('—');
  });

  it('returns "—" when download_url_expires_at is an empty string', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: '',
    });
    expect(getExpiresText(data, NOW)).toBe('—');
  });

  it('returns "Expired" when the expiry timestamp is exactly now', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expired');
  });

  it('returns "Expired" when the expiry timestamp is in the past', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW - 60_000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expired');
  });

  it('returns days remaining when more than a day is left', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(
        NOW + 3 * 24 * 60 * 60 * 1000,
      ).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 3d');
  });

  it('returns hours remaining when less than a day but more than an hour is left', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW + 5 * 60 * 60 * 1000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 5h');
  });

  it('returns minutes remaining when less than an hour but more than a minute is left', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW + 15 * 60 * 1000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 15m');
  });

  it('returns "< 1m" when less than a minute remains', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW + 30_000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('< 1m');
  });

  it('rounds down to whole days even when there is a partial extra day', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(
        NOW + 1 * 24 * 60 * 60 * 1000 + 23 * 60 * 60 * 1000, // 1 day 23 hours
      ).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 1d');
  });

  it('rounds down to whole hours even when there is a partial extra hour', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(
        NOW + 2 * 60 * 60 * 1000 + 59 * 60 * 1000, // 2 hours 59 minutes
      ).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 2h');
  });

  it('rounds down to whole minutes even when there is a partial extra minute', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(
        NOW + 4 * 60 * 1000 + 59_000, // 4 minutes 59 seconds
      ).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 4m');
  });

  it('treats exactly 24 hours remaining as 1 day, not 24 hours', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(
        NOW + 24 * 60 * 60 * 1000,
      ).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 1d');
  });

  it('treats exactly 60 minutes remaining as 1 hour, not 60 minutes', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW + 60 * 60 * 1000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 1h');
  });

  it('treats exactly 60 seconds remaining as 1 minute, not "< 1m"', () => {
    const data = makeExport({
      status: 'COMPLETED',
      download_url_expires_at: new Date(NOW + 60_000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 1m');
  });

  it('is not affected by status when status is any non-EXPIRED value and time remains', () => {
    const data = makeExport({
      status: 'PROCESSING',
      download_url_expires_at: new Date(NOW + 10 * 60 * 1000).toISOString(),
    });
    expect(getExpiresText(data, NOW)).toBe('Expires in 10m');
  });
});
