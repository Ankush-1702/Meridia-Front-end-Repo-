import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import type React from 'react';
import { LuRefreshCw } from 'react-icons/lu';
import { PiDownloadSimple } from 'react-icons/pi';
import { getExpiresText, SCOPE_LABEL } from './downloadUtils';
import StatusBadge from '@/shared/components/Badge';
import {
  ExportListData,
  ReturnedEntity,
} from '@/shared/services/exportServices/exportTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  EVENT_LABEL_MAP,
  toTitleCase,
} from '@/shared/utils/formatUtils';

const btn =
  'flex items-center gap-1.5 border border-gray-300 dark:border-gray-700 rounded-md px-2 py-1 text-xs font-medium transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-accent-foreground';

export function CreateDownloadsColDefs(
  timeZoneSetting: string,
  nowRef: React.MutableRefObject<number>,
  retryWithPolling: (
    id: string,
    entityType?: ReturnedEntity,
    eventTypes?: string[],
  ) => void,
  download: (id: string) => void,
  retryingJobsRef: React.MutableRefObject<Set<string>>,
  downloadingJobsRef: React.MutableRefObject<Set<string>>,
): ColDef<ExportListData>[] {
  const fmtTime = (value?: string) =>
    timeZoneSetting === 'utc'
      ? convertDateAndTimeToHumanReadableFormat(value) || '—'
      : convertUTCToLocalTime(value) || '—';

  return [
    {
      headerName: 'Export',
      field: 'entity_display_name',
      flex: 1.6,
      minWidth: 300,
      sortable: true,
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) =>
        p.data ? (
          <div className="flex h-full flex-col justify-center gap-1 leading-tight">
            <span className="truncate text-sm font-medium text-gray-900 dark:text-white">
              {p.data.entity_display_name}
            </span>
            <span className="truncate text-[10px] text-gray-500">
              {p.data.event_type
                ?.map((event) => EVENT_LABEL_MAP[event] || event)
                .join(', ')}
              {p.data.date_start && p.data.date_end && (
                <>
                  {p.data.event_type?.length ? ' · ' : ''}
                  {fmtTime(p.data.date_start).split(',')[0]} -{' '}
                  {fmtTime(p.data.date_end).split(',')[0]}
                </>
              )}
            </span>
          </div>
        ) : (
          <span>—</span>
        ),
      tooltipValueGetter: (p: ITooltipParams<ExportListData>) =>
        p.data
          ? `${p.data.entity_display_name}${
              p.data.event_type?.length
                ? ` - ${p.data.event_type
                    .map((event: string) => EVENT_LABEL_MAP[event] || event)
                    .join(', ')}`
                : ''
            }${
              p.data.date_start && p.data.date_end
                ? ` · ${fmtTime(p.data.date_start).split(',')[0]} - ${fmtTime(p.data.date_end).split(',')[0]}`
                : ''
            }`
          : '—',

      lockVisible: true,
    },
    {
      headerName: 'Type',
      field: 'entity_type',
      width: 110,
      sortable: true,
      cellClass: 'flex items-center',
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) => (
        <span>
          {p.data ? SCOPE_LABEL[p.data.entity_type] || p.data.entity_type : '—'}
        </span>
      ),
      tooltipValueGetter: (p: ITooltipParams) =>
        p.data ? SCOPE_LABEL[p.data.entity_type] || p.data.entity_type : '—',
      lockVisible: true,
    },
    {
      headerName:
        timeZoneSetting === 'utc'
          ? 'Requested On (UTC)'
          : 'Requested On (System)',
      field: 'requested_at',
      width: 180,
      sortable: true,
      cellClass: 'flex items-center',
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) => (
        <span>{fmtTime(p.value as string)}</span>
      ),
      tooltipValueGetter: (p: ITooltipParams) => fmtTime(p.value as string),
      lockVisible: true,
    },
    {
      headerName: 'Status',
      field: 'status',
      width: 130,
      cellClass: 'flex items-center',
      sortable: true,
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) =>
        p.data ? <StatusBadge status={p.data.status} /> : <span>—</span>,
      tooltipValueGetter: (p: ITooltipParams) =>
        p.data?.status ? toTitleCase(p.data.status) : '—',
      lockVisible: true,
    },
    {
      headerName: 'Expires',
      field: 'download_url_expires_at',
      width: 120,
      sortable: true,
      cellClass: 'flex items-center',
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) => {
        if (!p.data) return <span>—</span>;
        if (p.data.status === 'EXPIRED') return <span>Expired</span>;
        return <span>{getExpiresText(p.data, nowRef.current)}</span>;
      },
      tooltipValueGetter: (p: ITooltipParams) => {
        if (!p.data) return '—';
        if (p.data.status === 'EXPIRED') return 'Expired';
        return getExpiresText(p.data, nowRef.current);
      },
      lockVisible: true,
    },
    {
      width: 160,
      sortable: false,
      pinned: 'right',
      lockVisible: true,
      cellRenderer: (p: CustomCellRendererProps<ExportListData>) => {
        if (!p.data) return null;

        const isRetrying = retryingJobsRef.current.has(p.data.export_id);
        const isDownloading = downloadingJobsRef.current.has(p.data.export_id);

        if (p.data.status === 'COMPLETED') {
          const id = p.data.export_id;
          return (
            <div className="flex h-full items-center">
              <button
                onClick={() => download(id)}
                className={btn}
                disabled={isDownloading}
              >
                <PiDownloadSimple
                  className={`size-3.5 text-gray-400 ${isDownloading ? 'animate-pulse' : ''}`}
                />
                {isDownloading ? 'Downloading...' : 'Download CSV'}
              </button>
            </div>
          );
        }

        if (p.data.status === 'FAILED') {
          const id = p.data.export_id;
          return (
            <div className="flex h-full items-center">
              <button
                type="button"
                className={btn}
                onClick={() =>
                  retryWithPolling(id, p.data?.entity_type, p.data?.event_type)
                }
                disabled={isRetrying}
              >
                <LuRefreshCw
                  className={`size-3.5 text-gray-400 ${isRetrying ? 'animate-spin' : ''}`}
                />
                {isRetrying ? 'Retrying...' : 'Retry'}
              </button>
            </div>
          );
        }

        if (p.data.status === 'EXPIRED') {
          const id = p.data.export_id;
          return (
            <div className="flex h-full items-center">
              <button
                type="button"
                className={btn}
                onClick={() =>
                  retryWithPolling(id, p.data?.entity_type, p.data?.event_type)
                }
                disabled={isRetrying}
              >
                <LuRefreshCw
                  className={`size-3.5 text-gray-400 ${isRetrying ? 'animate-spin' : ''}`}
                />
                {isRetrying ? 'Requesting...' : 'Request again'}
              </button>
            </div>
          );
        }

        return (
          <span className="flex h-full items-center text-xs text-gray-900 dark:text-white">
            —
          </span>
        );
      },
    },
  ];
}
