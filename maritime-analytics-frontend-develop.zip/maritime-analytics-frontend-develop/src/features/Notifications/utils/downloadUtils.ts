import { ExportListData } from '@/shared/services/exportServices/exportTypes';

export const SCOPE_LABEL: Record<string, string> = {
  VESSEL: 'Vessel',
  FLEET: 'Fleet',
  ZONE: 'Zone',
  PORT: 'Port',
  // Add other scope types as needed
};

export function getExpiresText(data: ExportListData, now: number): string {
  if (data.status === 'EXPIRED') return 'Expired';

  if (!data.download_url_expires_at) return '—';

  const expiresAt = new Date(data.download_url_expires_at).getTime();
  const diffMs = expiresAt - now;

  if (diffMs <= 0) return 'Expired';

  // Calculate all units from the same base (diffMs)
  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const totalHours = Math.floor(diffMs / (1000 * 60 * 60));
  const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (totalDays > 0) return `Expires in ${totalDays}d`;
  if (totalHours > 0) return `Expires in ${totalHours}h`;
  if (totalMinutes > 0) return `Expires in ${totalMinutes}m`;
  return '< 1m';
}
