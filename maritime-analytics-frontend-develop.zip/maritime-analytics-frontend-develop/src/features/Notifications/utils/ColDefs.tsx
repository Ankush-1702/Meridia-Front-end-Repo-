import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { Notifications } from '@/features/Notifications/types/notificationsTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  formatEpochMsToUTCDateString,
  toTitleCase,
} from '@/shared/utils/formatUtils';
import { NavigateToDetailsPage } from '@/shared/utils/NavigatetoDetailsPage';

export function createNotificationsColDefs(
  timeZoneSetting: string,
  activeTab: string,
): ColDef<Notifications>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Date/Time (UTC)' : 'Date/Time (System)'}`,
      field: 'createdAt',
      sortable: false,
      flex: 1,
      // tooltipField: 'eventTimestamp',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(
                formatEpochMsToUTCDateString(params.value),
              )
            : convertUTCToLocalTime(formatEpochMsToUTCDateString(params.value))}
        </span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: `${activeTab === 'All' ? 'Zone/Port Name' : activeTab === 'Zones' ? 'Zone Name' : 'Port Name'}`,
      field: 'zonePortName',
      sortable: false,
      flex: 1,
      tooltipField: 'zonePortName',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => {
        const path =
          params.data.eventType === 'ZONE_ENTRY' ||
          params.data.eventType === 'ZONE_EXIT'
            ? 'zone'
            : 'port';
        return (
          <NavigateToDetailsPage
            params={params}
            detailsRoute={`/analytics/${path}/${params.data.zonePortId}`}
          />
        );
      },
    },
    {
      headerName: 'Event Type',
      field: 'eventType',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <StatusBadge status={params.value} />
      ),
      cellStyle: {
        cursor: 'default',
      },
      tooltipValueGetter: (params: ITooltipParams) => {
        const newStatus = params.value.split('_').slice(1).join('_');
        return toTitleCase(newStatus);
      },
    },
    {
      headerName: 'Vessel Name',
      field: 'vesselName',
      sortable: false,
      flex: 1,
      tooltipField: 'vesselName',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
      cellRenderer: (params: CustomCellRendererProps) => (
        <NavigateToDetailsPage
          params={params}
          detailsRoute={`/analytics/vessel/${params.data.imo}`}
        >
          <FlagIcon flagCode={params.data.flagCode} />
        </NavigateToDetailsPage>
      ),
    },
    {
      headerName: 'Vessel IMO',
      field: 'imo',
      sortable: false,
      flex: 1,
      tooltipField: 'imo',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <NavigateToDetailsPage
          params={params}
          detailsRoute={`/analytics/vessel/${params.data.imo}`}
        />
      ),
    },
    {
      headerName: 'Vessel Type',
      field: 'vesselType',
      sortable: false,
      flex: 1,
      tooltipField: 'vesselType',
      lockVisible: true,
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Risk',
      field: 'screeningResult',
      sortable: false,
      flex: 1,
      tooltipValueGetter: (params: ITooltipParams) => {
        const risk =
          params.data.eventType === 'ZONE_EXIT' ||
          params.data.eventType === 'PORT_ARRIVAL' ||
          params.data.eventType === 'PORT_DEPARTURE' ||
          params.data.eventType === 'PORT_AREA_DEPARTURE' ||
          params.data.vesselType?.toLowerCase() === 'tug' ||
          params.data.vesselType?.toLowerCase() === 'push-boat'
            ? 'NA'
            : params.data.screeningResult !== '-' &&
                params.data.screeningResult !== null
              ? params.data.screeningResult
              : 'UNSCORED';
        if (
          risk === 'NA' &&
          params.data.eventType !== 'ZONE_ENTRY' &&
          params.data.eventType !== 'PORT_AREA_ARRIVAL'
        ) {
          return 'Auto-screening currently only available for Port Area Arrival and Zone Entry events';
        }
        if (
          risk === 'NA' &&
          (params.data.vesselType?.toLowerCase() === 'tug' ||
            params.data.vesselType?.toLowerCase() === 'push-boat' ||
            params.data.eventType === 'ZONE_ENTRY' ||
            params.data.eventType === 'PORT_AREA_ARRIVAL')
        ) {
          return 'Auto-screening currently not available for tug and push-boat vessels';
        }
        return risk;
      },
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => {
        const risk =
          params.data.eventType === 'ZONE_EXIT' ||
          params.data.eventType === 'PORT_ARRIVAL' ||
          params.data.eventType === 'PORT_DEPARTURE' ||
          params.data.eventType === 'PORT_AREA_DEPARTURE' ||
          params.data.vesselType?.toLowerCase() === 'tug' ||
          params.data.vesselType?.toLowerCase() === 'push-boat'
            ? 'NA'
            : params.data.screeningResult !== '-' &&
                params.data.screeningResult !== null
              ? params.data.screeningResult
              : 'UNSCORED';
        return <StatusBadge status={risk} location="notifications Page" />;
      },

      cellStyle: {
        cursor: 'default',
      },
    },
  ];
}
