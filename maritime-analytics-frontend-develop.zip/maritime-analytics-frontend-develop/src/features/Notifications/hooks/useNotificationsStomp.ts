import { Client, IMessage } from '@stomp/stompjs';
import { useEffect, useReducer, useRef, useState } from 'react';
import SockJS from 'sockjs-client';
import { API_BASE_URL } from '@/app/config/config';
import { NOTIFICATIONS_TOPIC } from '@/features/Notifications/constants/constants';
import { Notifications } from '@/features/Notifications/types/notificationsTypes';

const TOPIC = NOTIFICATIONS_TOPIC;

export function useNotificationsStomp() {
  const [connected, setConnected] = useState(false);
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const [newNotifications, setNewNotifications] = useState<Notifications[]>([]);
  const [refreshToken, bumpRefreshToken] = useReducer((x: number) => x + 1, 0);

  // Use refs to avoid stale closures and unnecessary re-renders
  const timestampsRef = useRef<number[]>([]);
  const showBurstNoticeRef = useRef(false);

  const [burstCount, setBurstCount] = useState(0);
  const [showBurstNotice, setShowBurstNotice] = useState(false);

  // Keep the ref in sync with state so other effects / UI still read state
  useEffect(() => {
    showBurstNoticeRef.current = showBurstNotice;
  }, [showBurstNotice]);

  const WINDOW_MS = 10_000; // 10 second window
  const THRESHOLD = 3;

  useEffect(() => {
    if (!user_id) return;
    const socket = new SockJS(
      `${API_BASE_URL.replace(/\/v1$/, '/ws')}?userId=${user_id}`,
    );

    const stompClient = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 5000,
      debug: () => {}, // Disable default STOMP debug logging
      onConnect: () => {
        setConnected(true);

        stompClient.subscribe(TOPIC, (message: IMessage) => {
          try {
            const data = JSON.parse(message.body);
            const wsMessage = data as Notifications;

            // add notification (prevent duplicate ids)
            setNewNotifications((prevNotifications) => {
              if (
                prevNotifications.some(
                  (n) => n.notificationId === wsMessage.notificationId,
                )
              ) {
                return prevNotifications;
              }
              return [...prevNotifications, wsMessage];
            });

            // ---- Burst detection & refresh logic ----
            const now = Date.now();

            // If we're already in burst mode, increment the persistent burstCount
            if (showBurstNoticeRef.current) {
              setBurstCount((c) => c + 1);
              return;
            }

            // NOT in burst mode -> do detection using timestampsRef (no state updates)
            const recent = timestampsRef.current.filter(
              (t) => now - t < WINDOW_MS,
            );
            const updated = [...recent, now];
            timestampsRef.current = updated;

            if (updated.length > THRESHOLD) {
              // Enter burst mode
              setShowBurstNotice(true);
              showBurstNoticeRef.current = true;

              // Set the initial burst count to ALL messages that led to the burst
              setBurstCount(updated.length);

              // From now on, timestamps don't matter; freeze this list
              timestampsRef.current = [];

              return;
            }

            // Not a burst: bump refresh token once to trigger server refresh
            bumpRefreshToken();
          } catch (err) {
            console.log('Message parsing failed', err, {
              messageBody: message.body,
              headers: message.headers,
            });
          }
        });
      },
      onStompError: (frame) => {
        console.log('STOMP Broker Error', frame.headers['message'], {
          frameBody: frame.body,
          frameHeaders: frame.headers,
        });
      },
    });

    stompClient.activate();

    return () => {
      if (stompClient && stompClient.active) {
        stompClient.deactivate();
      }
    };
  }, [user_id]);

  // Manual reset that your UI can call to end burst mode
  const resetBurst = () => {
    setShowBurstNotice(false);
    showBurstNoticeRef.current = false;
    setBurstCount(0);
    timestampsRef.current = [];
  };

  return {
    connected,
    newNotifications,
    setNewNotifications,
    burstCount,
    showBurstNotice,
    setShowBurstNotice,
    bumpRefreshToken,
    refreshToken,
    resetBurst,
  };
}
