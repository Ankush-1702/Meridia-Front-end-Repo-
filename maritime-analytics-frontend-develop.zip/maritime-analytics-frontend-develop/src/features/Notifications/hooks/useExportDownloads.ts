import { useCallback, useEffect, useRef, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import {
  getRecentExportJobs,
  pollEventsExportStatus,
  reRunEventsExport,
  reRunFleetExport,
} from '@/shared/services/exportServices/eventsExportServices';
import {
  ExportListData,
  ReturnedEntity,
} from '@/shared/services/exportServices/exportTypes';
import { logger } from '@/shared/utils/logger';

function rerunExport(
  jobId: string,
  entityType?: ReturnedEntity,
  eventTypes?: string[],
) {
  if (entityType === 'FLEET' && !eventTypes?.length) {
    return reRunFleetExport(jobId);
  }

  return reRunEventsExport(jobId);
}

export function useExportDownloads() {
  const { showToast } = useToastNotification();
  const handleApiError = useApiErrorHandler();
  const [exportIds, setExportIds] = useState<string[]>(() => {
    const stored = localStorage.getItem('exportIds');
    return stored ? JSON.parse(stored) : [];
  });
  const [jobs, setJobs] = useState<ExportListData[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [timeAgo, setTimeAgo] = useState<string>('0s');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const jobsRef = useRef<ExportListData[]>([]);
  const activePolls = useRef<Set<ReturnType<typeof setInterval>>>(new Set());

  useEffect(() => {
    jobsRef.current = jobs;
  }, [jobs]);

  useEffect(() => {
    const polls = activePolls.current; // Capture current value

    return () => {
      polls.forEach((poll) => clearInterval(poll));
      polls.clear();
    };
  }, []);

  useEffect(() => {
    if (exportIds.length > 0) {
      localStorage.setItem('exportIds', JSON.stringify(exportIds));
    }
  }, [exportIds]);

  const fetchRecentExportJobs = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await getRecentExportJobs(100, 0);
      setJobs(res.data);
      setLastUpdated(new Date());
    } catch {
      setJobs([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const retryJobWithPolling = useCallback(
    async (
      jobId: string,
      onStart?: () => void,
      onComplete?: () => void,
      type?: ReturnedEntity,
      eventTypes?: string[],
    ) => {
      onStart?.();
      try {
        const res = await rerunExport(jobId, type, eventTypes);
        setExportIds((prev) => [...prev, res.data.export_id]);

        // Start polling
        const INTERVAL = 3000;
        const MAX_ATTEMPTS = 10;
        let attempts = 0;

        const poll = setInterval(() => {
          attempts++;
          fetchRecentExportJobs();

          const job = jobsRef.current.find(
            (j) => j.export_id === res.data.export_id,
          );
          if (!job || job.status !== 'PROCESSING' || attempts >= MAX_ATTEMPTS) {
            clearInterval(poll);
            activePolls.current.delete(poll); // Remove from tracking
            onComplete?.();
          }
        }, INTERVAL);

        activePolls.current.add(poll); // Track this interval
      } catch (e) {
        handleApiError(e);
        onComplete?.();
      }
    },
    [handleApiError, fetchRecentExportJobs],
  );

  useEffect(() => {
    fetchRecentExportJobs();
  }, [fetchRecentExportJobs]);

  useEffect(() => {
    const interval = setInterval(
      () => {
        fetchRecentExportJobs();
      },
      5 * 60 * 1000,
    );

    return () => clearInterval(interval);
  }, [fetchRecentExportJobs]);

  useEffect(() => {
    const updateTimeAgo = () => {
      if (!lastUpdated) {
        setTimeAgo('0s');
        return;
      }

      const now = new Date();
      const diff = Math.floor((now.getTime() - lastUpdated.getTime()) / 1000);

      if (diff < 60) {
        setTimeAgo(`${diff}s`);
      } else {
        const minutes = Math.floor(diff / 60);
        setTimeAgo(`${minutes}m`);
      }
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 1000);

    return () => clearInterval(interval);
  }, [lastUpdated]);

  const downloadCsv = useCallback(
    async (jobId: string) => {
      if (!jobId) return;

      try {
        const res = await pollEventsExportStatus(jobId);

        if (res.data.status === 'COMPLETED') {
          if (res.data.download_url) {
            // Create a temporary link element and trigger download
            const link = document.createElement('a');
            link.href = res.data.download_url;
            link.download = `.csv`; // or use a more descriptive filename
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            // Optional: Show success toast
            showToast?.('success', 'CSV downloaded successfully!', 3000);
          } else {
            logger.warn('Export completed but no download URL available');
            showToast?.(
              'warning',
              'Export completed but download URL is missing',
              3000,
            );
          }
        } else if (res.data.status === 'FAILED') {
          showToast?.('error', 'Export failed', 3000);
        } else if (res.data.status === 'PROCESSING') {
          showToast?.('info', 'Export is still processing...', 2000);
        }
      } catch (e) {
        logger.error('Failed to download CSV:', e);
        handleApiError?.(e);
      }
    },
    [showToast, handleApiError],
  );

  const retryJob = useCallback(
    async (jobId: string, type?: ReturnedEntity, eventTypes?: string[]) => {
      try {
        const res = await rerunExport(jobId, type, eventTypes);
        setExportIds((prev) => [...prev, res.data.export_id]);
      } catch (e) {
        handleApiError(e);
      }
    },
    [handleApiError],
  );
  return {
    retryJob,
    jobs,
    retryJobWithPolling,
    isLoading,
    downloadCsv,
    timeAgo,
    fetchRecentExportJobs,
  };
}
