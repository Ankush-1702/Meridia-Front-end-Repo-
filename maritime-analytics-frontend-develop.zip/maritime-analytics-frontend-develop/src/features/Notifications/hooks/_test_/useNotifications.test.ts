import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useNotifications } from '@/features/Notifications/hooks/useNotifications';
import type {
  Notifications,
  RecencyOptions,
  SelectedRecencyPreference,
} from '@/features/Notifications/types/notificationsTypes';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const {
  getNotificationsMock,
  getNotificationsPreferenceMock,
  updateNotificationsPreferenceMock,
  handleApiErrorMock,
} = vi.hoisted(() => ({
  getNotificationsMock: vi.fn(),
  getNotificationsPreferenceMock: vi.fn(),
  updateNotificationsPreferenceMock: vi.fn(),
  handleApiErrorMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Module mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/features/Notifications/services/notificationsService', () => ({
  getNotifications: getNotificationsMock,
  getNotificationsPreference: getNotificationsPreferenceMock,
  updateNotificationsPreference: updateNotificationsPreferenceMock,
}));

/* ------------------------------------------------------------------ */
/* Fixtures */
/* ------------------------------------------------------------------ */

const mockNotifications: Notifications[] = [
  {
    notificationId: '1',
    vesselName: 'Vessel A',
    eventType: 'PORT_ARRIVAL',
    createdAt: String(Date.now()),
    zonePortName: 'Port A',
    screeningResult: '-',
    vesselType: 'fishing Vessel',
    eventId: '1',
    eventTimestamp: String(Date.now()),
    imo: '123456',
    flag: 'Flag A',
    flagCode: 'A',
    zonePortId: '1',
    subscriptionId: null,
    subscriptionName: null,
  },
];

const mockOptions: RecencyOptions[] = [
  {
    code: 'ALL',
    label: 'All notifications',
    description: 'Show all notifications',
  },
];

const mockPreference: SelectedRecencyPreference = 'ALL';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('useNotifications', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('fetches notifications and preferences on mount (success path)', async () => {
    getNotificationsMock.mockResolvedValueOnce({
      data: mockNotifications,
    });

    getNotificationsPreferenceMock.mockResolvedValueOnce({
      recencyOptions: mockOptions,
      selectedRecencyPreference: mockPreference,
    });

    const { result } = renderHook(() => useNotifications());

    expect(result.current.loading).toBe(true);

    await act(async () => {});

    expect(getNotificationsPreferenceMock).toHaveBeenCalledTimes(1);
    expect(getNotificationsMock).toHaveBeenCalledTimes(1);

    expect(result.current.notifications).toEqual(mockNotifications);
    expect(result.current.options).toEqual(mockOptions);
    expect(result.current.preference).toBe(mockPreference);
    expect(result.current.loading).toBe(false);
  });

  it('handles error when fetching notifications', async () => {
    getNotificationsMock.mockRejectedValueOnce(new Error('fetch failed'));

    getNotificationsPreferenceMock.mockResolvedValueOnce({
      recencyOptions: mockOptions,
      selectedRecencyPreference: mockPreference,
    });

    const { result } = renderHook(() => useNotifications());

    await act(async () => {});

    expect(handleApiErrorMock).toHaveBeenCalled();
    expect(result.current.notifications).toEqual([]);
    expect(result.current.loading).toBe(false);
  });

  it('handles error when fetching preferences', async () => {
    getNotificationsMock.mockResolvedValueOnce({
      data: mockNotifications,
    });

    getNotificationsPreferenceMock.mockRejectedValueOnce(
      new Error('preference failed'),
    );

    const { result } = renderHook(() => useNotifications());

    await act(async () => {});

    expect(handleApiErrorMock).toHaveBeenCalled();
    expect(result.current.options).toEqual([]);
    expect(result.current.preference).toBeUndefined();
  });

  it('updates recency preference successfully', async () => {
    getNotificationsMock.mockResolvedValueOnce({
      data: mockNotifications,
    });

    getNotificationsPreferenceMock.mockResolvedValueOnce({
      recencyOptions: mockOptions,
      selectedRecencyPreference: mockPreference,
    });

    updateNotificationsPreferenceMock.mockResolvedValueOnce({
      recencyPreference: 'RECENT',
    });

    const { result } = renderHook(() => useNotifications());

    await act(async () => {});

    await act(async () => {
      await result.current.updateRecencyPreference('ALL');
    });

    expect(updateNotificationsPreferenceMock).toHaveBeenCalledWith('ALL');
    expect(result.current.preference).toBe('RECENT');
  });

  it('handles error when updating recency preference', async () => {
    getNotificationsMock.mockResolvedValueOnce({
      data: mockNotifications,
    });

    getNotificationsPreferenceMock.mockResolvedValueOnce({
      recencyOptions: mockOptions,
      selectedRecencyPreference: mockPreference,
    });

    updateNotificationsPreferenceMock.mockRejectedValueOnce(
      new Error('update failed'),
    );

    const { result } = renderHook(() => useNotifications());

    await act(async () => {});

    await act(async () => {
      await result.current.updateRecencyPreference('LAST_24_HOURS');
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
    expect(result.current.preference).toBe(mockPreference);
  });
});
