import type { IMessage } from '@stomp/stompjs';
import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useNotificationsStomp } from '@/features/Notifications/hooks/useNotificationsStomp';
import type { Notifications } from '@/features/Notifications/types/notificationsTypes';

/* ------------------------------------------------------------------ */
/* Hoisted STOMP mocks (MUST be hoisted) */
/* ------------------------------------------------------------------ */

const {
  subscribeMock,
  activateMock,
  deactivateMock,
  getOnMessage,
  triggerConnect,
} = vi.hoisted(() => {
  let onConnect: (() => void) | undefined;
  let onMessage: ((msg: IMessage) => void) | undefined;

  return {
    subscribeMock: vi.fn((_topic: string, cb: (msg: IMessage) => void) => {
      onMessage = cb;
    }),
    activateMock: vi.fn(() => {
      onConnect?.();
    }),
    deactivateMock: vi.fn(),
    triggerConnect: (cb: () => void) => {
      onConnect = cb;
    },
    getOnMessage: () => onMessage,
  };
});

/* ------------------------------------------------------------------ */
/* Module mocks */
/* ------------------------------------------------------------------ */

vi.mock('@stomp/stompjs', () => {
  class MockClient {
    active = true;
    subscribe = subscribeMock;
    activate = activateMock;
    deactivate = deactivateMock;

    constructor(config: { onConnect: () => void }) {
      triggerConnect(config.onConnect);
    }
  }

  return { Client: MockClient };
});

vi.mock('sockjs-client', () => ({
  default: vi.fn(),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'http://localhost/v1',
}));

vi.mock('@/features/Notifications/constants/constants', () => ({
  NOTIFICATIONS_TOPIC: '/topic/notifications',
}));

/* ------------------------------------------------------------------ */
/* System under test (IMPORT AFTER MOCKS) */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Fixtures */
/* ------------------------------------------------------------------ */

const baseNotification: Notifications = {
  notificationId: '1',
  vesselName: 'Vessel A',
  eventType: 'PORT_ARRIVAL',
  createdAt: String(Date.now()),
  zonePortName: 'Port A',
  screeningResult: '-',
  vesselType: 'fishing Vessel',
  eventId: '1',
  eventTimestamp: String(Date.now()),
  imo: '123456',
  flag: 'Flag A',
  flagCode: 'A',
  zonePortId: '1',
  subscriptionId: null,
  subscriptionName: null,
};

function sendMessage(notification: Notifications) {
  const cb = getOnMessage();
  cb?.({
    body: JSON.stringify(notification),
    headers: {},
  } as IMessage);
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('useNotificationsStomp', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    localStorage.setItem('user', JSON.stringify({ user_id: 'user-1' }));
  });

  it('connects and sets connected=true', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    expect(result.current.connected).toBe(true);
  });

  it('adds new notifications and prevents duplicates', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    act(() => {
      sendMessage(baseNotification);
      sendMessage(baseNotification);
    });

    expect(result.current.newNotifications).toHaveLength(1);
  });

  it('bumps refreshToken for non-burst messages', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    const initial = result.current.refreshToken;

    act(() => {
      sendMessage(baseNotification);
    });

    expect(result.current.refreshToken).toBe(initial + 1);
  });

  it('enters burst mode after threshold and tracks burstCount', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    act(() => {
      sendMessage({ ...baseNotification, notificationId: '1' });
      sendMessage({ ...baseNotification, notificationId: '2' });
      sendMessage({ ...baseNotification, notificationId: '3' });
      sendMessage({ ...baseNotification, notificationId: '4' });
    });

    expect(result.current.showBurstNotice).toBe(true);
    expect(result.current.burstCount).toBeGreaterThan(3);
  });

  it('increments burstCount when already in burst mode', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    act(() => {
      sendMessage({ ...baseNotification, notificationId: '1' });
      sendMessage({ ...baseNotification, notificationId: '2' });
      sendMessage({ ...baseNotification, notificationId: '3' });
      sendMessage({ ...baseNotification, notificationId: '4' });
      sendMessage({ ...baseNotification, notificationId: '5' });
    });

    expect(result.current.burstCount).toBe(5);
  });

  it('resets burst state via resetBurst', async () => {
    const { result } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    act(() => {
      sendMessage({ ...baseNotification, notificationId: '1' });
      sendMessage({ ...baseNotification, notificationId: '2' });
      sendMessage({ ...baseNotification, notificationId: '3' });
      sendMessage({ ...baseNotification, notificationId: '4' });
    });

    act(() => {
      result.current.resetBurst();
    });

    expect(result.current.showBurstNotice).toBe(false);
    expect(result.current.burstCount).toBe(0);
  });

  it('cleans up stomp client on unmount', async () => {
    const { unmount } = renderHook(() => useNotificationsStomp());

    await act(async () => {});

    unmount();

    expect(deactivateMock).toHaveBeenCalled();
  });
});
