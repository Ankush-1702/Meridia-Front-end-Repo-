import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useExportDownloads } from '@/features/Notifications/hooks/useExportDownloads';

const handleApiError = vi.fn();
const showToast = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiError,
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast }),
}));

const getRecentExportJobs = vi.fn();
const pollEventsExportStatus = vi.fn();
const reRunEventsExport = vi.fn();
const reRunFleetExport = vi.fn();

vi.mock('@/shared/services/exportServices/eventsExportServices', () => ({
  getRecentExportJobs: (...args: unknown[]) => getRecentExportJobs(...args),
  pollEventsExportStatus: (...args: unknown[]) =>
    pollEventsExportStatus(...args),
  reRunEventsExport: (...args: unknown[]) => reRunEventsExport(...args),
  reRunFleetExport: (...args: unknown[]) => reRunFleetExport(...args),
}));

function makeJob(
  overrides: Partial<{ export_id: string; status: string }> = {},
) {
  return { export_id: 'job-1', status: 'PROCESSING', ...overrides };
}

// With fake timers installed, RTL's `waitFor` cannot self-advance the clock
// to retry its assertion (it relies on real setTimeout/setInterval under the
// hood) — so instead of `waitFor`, we explicitly flush pending microtasks
// (promise resolutions from mocked async calls) inside `act`. This resolves
// the initial mount-time fetch deterministically without needing real time
// to pass, and without hanging until Vitest's test timeout.
async function flushMicrotasks() {
  await act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });
}

// Renders the hook and flushes the mount-time fetchRecentExportJobs() call so
// that `result.current` reflects post-fetch state before assertions run.
async function renderAndFlush() {
  const utils = renderHook(() => useExportDownloads());
  await flushMicrotasks();
  return utils;
}

describe('useExportDownloads', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    localStorage.clear();
    getRecentExportJobs.mockReset().mockResolvedValue({ data: [] });
    pollEventsExportStatus.mockReset();
    reRunEventsExport.mockReset();
    reRunFleetExport.mockReset();
    handleApiError.mockReset();
    showToast.mockReset();
    vi.spyOn(document.body, 'appendChild');
    vi.spyOn(document.body, 'removeChild');
  });

  afterEach(() => {
    vi.runOnlyPendingTimers();
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('initializes exportIds from localStorage without throwing', async () => {
    localStorage.setItem('exportIds', JSON.stringify(['a', 'b']));
    const { result } = await renderAndFlush();
    expect(result.current).toBeDefined();
  });

  it('initializes jobs to an empty array before any fetch resolves', () => {
    // Deliberately not flushed — checks the synchronous initial state.
    getRecentExportJobs.mockReturnValue(new Promise(() => {})); // never resolves
    const { result } = renderHook(() => useExportDownloads());
    expect(result.current.jobs).toEqual([]);
  });

  it('fetches recent export jobs on mount', async () => {
    getRecentExportJobs.mockResolvedValue({ data: [makeJob()] });
    const { result } = await renderAndFlush();

    expect(getRecentExportJobs).toHaveBeenCalledWith(100, 0);
    expect(result.current.jobs).toHaveLength(1);
  });

  it('sets isLoading around the fetch', async () => {
    let resolveFetch: (v: { data: never[] }) => void = () => {};
    getRecentExportJobs.mockReturnValue(
      new Promise((resolve) => {
        resolveFetch = resolve;
      }),
    );

    const { result } = renderHook(() => useExportDownloads());
    expect(result.current.isLoading).toBe(true);

    await act(async () => {
      resolveFetch({ data: [] });
      await Promise.resolve();
    });

    expect(result.current.isLoading).toBe(false);
  });

  it('clears jobs when the initial fetch fails', async () => {
    getRecentExportJobs.mockRejectedValue(new Error('network error'));
    const { result } = await renderAndFlush();

    expect(result.current.isLoading).toBe(false);
    expect(result.current.jobs).toEqual([]);
  });

  it('refetches jobs on the 5-minute interval', async () => {
    getRecentExportJobs.mockResolvedValue({ data: [] });
    await renderAndFlush();

    expect(getRecentExportJobs).toHaveBeenCalledTimes(1);

    await act(async () => {
      await vi.advanceTimersByTimeAsync(5 * 60 * 1000);
    });
    expect(getRecentExportJobs).toHaveBeenCalledTimes(2);
  });

  it('updates timeAgo every second after lastUpdated changes', async () => {
    getRecentExportJobs.mockResolvedValue({ data: [] });
    const { result } = await renderAndFlush();

    expect(result.current.timeAgo).toBe('0s');

    await act(async () => {
      await vi.advanceTimersByTimeAsync(1000);
    });
    expect(result.current.timeAgo).toBe('1s');

    await act(async () => {
      await vi.advanceTimersByTimeAsync(60_000);
    });
    expect(result.current.timeAgo).toBe('1m');
  });

  describe('retryJob', () => {
    it('reruns the export and returns without throwing on success', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJob('job-1', 'PORT');
      });

      expect(reRunEventsExport).toHaveBeenCalledWith('job-1');
      expect(reRunFleetExport).not.toHaveBeenCalled();
      expect(handleApiError).not.toHaveBeenCalled();
    });

    it('uses the fleet vessel rerun path for Fleet rows without event types', async () => {
      reRunFleetExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJob('job-1', 'FLEET', []);
      });

      expect(reRunFleetExport).toHaveBeenCalledWith('job-1');
      expect(reRunEventsExport).not.toHaveBeenCalled();
    });

    it('uses the events rerun path for Fleet rows with event types', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJob('job-1', 'FLEET', ['AIS_GAP']);
      });

      expect(reRunEventsExport).toHaveBeenCalledWith('job-1');
      expect(reRunFleetExport).not.toHaveBeenCalled();
    });

    it('persists the new export id to localStorage', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJob('job-1');
      });

      const stored = JSON.parse(localStorage.getItem('exportIds') ?? '[]');
      expect(stored).toContain('new-job');
    });

    it('calls handleApiError when the rerun request fails', async () => {
      const error = new Error('boom');
      reRunEventsExport.mockRejectedValue(error);
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJob('job-1');
      });

      expect(handleApiError).toHaveBeenCalledWith(error);
    });
  });

  describe('retryJobWithPolling', () => {
    it('uses the events rerun path for non-Fleet rows', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      getRecentExportJobs.mockResolvedValue({ data: [] });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          undefined,
          'VESSEL',
        );
      });

      expect(reRunEventsExport).toHaveBeenCalledWith('job-1');
      expect(reRunFleetExport).not.toHaveBeenCalled();
    });

    it('uses the fleet vessel rerun path for Fleet rows without event types', async () => {
      reRunFleetExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      getRecentExportJobs.mockResolvedValue({ data: [] });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          undefined,
          'FLEET',
          [],
        );
      });

      expect(reRunFleetExport).toHaveBeenCalledWith('job-1');
      expect(reRunEventsExport).not.toHaveBeenCalled();
    });

    it('uses the events rerun path for Fleet rows with event types', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'new-job' } });
      getRecentExportJobs.mockResolvedValue({ data: [] });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          undefined,
          'FLEET',
          ['AIS_GAP'],
        );
      });

      expect(reRunEventsExport).toHaveBeenCalledWith('job-1');
      expect(reRunFleetExport).not.toHaveBeenCalled();
    });

    it('calls onStart immediately', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'job-1' } });
      getRecentExportJobs.mockResolvedValue({
        data: [makeJob({ status: 'PROCESSING' })],
      });
      const onStart = vi.fn();
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling('job-1', onStart);
      });

      expect(onStart).toHaveBeenCalledTimes(1);
    });

    it('calls handleApiError and onComplete when the rerun request fails, without starting polling', async () => {
      const error = new Error('boom');
      reRunEventsExport.mockRejectedValue(error);
      const onComplete = vi.fn();
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          onComplete,
        );
      });

      expect(handleApiError).toHaveBeenCalledWith(error);
      expect(onComplete).toHaveBeenCalledTimes(1);

      // No polling should have been scheduled — advancing timers triggers no
      // extra fetches beyond the initial mount fetch.
      getRecentExportJobs.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(getRecentExportJobs).not.toHaveBeenCalled();
    });

    it('stops polling and calls onComplete after the first tick when jobsRef has not caught up yet', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'job-1' } });
      getRecentExportJobs
        .mockResolvedValueOnce({ data: [] }) // initial mount fetch
        .mockResolvedValueOnce({ data: [makeJob({ status: 'PROCESSING' })] }); // 1st poll tick

      const onComplete = vi.fn();
      const { result } = await renderAndFlush();

      expect(getRecentExportJobs).toHaveBeenCalledTimes(1);

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          onComplete,
        );
      });

      await act(async () => {
        await vi.advanceTimersByTimeAsync(3000);
      });
      expect(onComplete).toHaveBeenCalledTimes(1);

      getRecentExportJobs.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(3000);
      });
      expect(getRecentExportJobs).not.toHaveBeenCalled();
    });

    it('stops polling and calls onComplete after reaching the max attempt count, even if still PROCESSING', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'job-1' } });
      getRecentExportJobs.mockResolvedValue({
        data: [makeJob({ status: 'PROCESSING' })],
      });

      const onComplete = vi.fn();
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling(
          'job-1',
          undefined,
          onComplete,
        );
      });

      // MAX_ATTEMPTS = 10, INTERVAL = 3000ms.
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10 * 3000);
      });

      expect(onComplete).toHaveBeenCalledTimes(1);
    });

    it('persists the new export id returned from reRunEventsExport', async () => {
      reRunEventsExport.mockResolvedValue({
        data: { export_id: 'polled-job' },
      });
      getRecentExportJobs.mockResolvedValue({ data: [] });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling('job-1');
      });

      const stored = JSON.parse(localStorage.getItem('exportIds') ?? '[]');
      expect(stored).toContain('polled-job');
    });
  });

  describe('downloadCsv', () => {
    it('does nothing when jobId is falsy', async () => {
      const { result } = await renderAndFlush();
      await act(async () => {
        await result.current.downloadCsv('');
      });
      expect(pollEventsExportStatus).not.toHaveBeenCalled();
    });

    it('triggers a download and shows a success toast when completed with a URL', async () => {
      pollEventsExportStatus.mockResolvedValue({
        data: {
          status: 'COMPLETED',
          download_url: 'https://example.com/export.csv',
        },
      });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.downloadCsv('job-1');
      });

      expect(document.body.appendChild).toHaveBeenCalled();
      expect(document.body.removeChild).toHaveBeenCalled();
      expect(showToast).toHaveBeenCalledWith(
        'success',
        'CSV downloaded successfully!',
        3000,
      );
    });

    it('shows a warning toast when completed but no download URL is present', async () => {
      pollEventsExportStatus.mockResolvedValue({
        data: { status: 'COMPLETED', download_url: undefined },
      });
      const { result } = await renderAndFlush();

      vi.mocked(document.body.appendChild).mockClear();

      await act(async () => {
        await result.current.downloadCsv('job-1');
      });

      expect(showToast).toHaveBeenCalledWith(
        'warning',
        'Export completed but download URL is missing',
        3000,
      );
      const appendedAnchor = vi
        .mocked(document.body.appendChild)
        .mock.calls.find(([node]) => (node as HTMLElement).tagName === 'A');
      expect(appendedAnchor).toBeUndefined();
    });

    it('shows an error toast when the export failed', async () => {
      pollEventsExportStatus.mockResolvedValue({ data: { status: 'FAILED' } });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.downloadCsv('job-1');
      });

      expect(showToast).toHaveBeenCalledWith('error', 'Export failed', 3000);
    });

    it('shows an info toast when the export is still processing', async () => {
      pollEventsExportStatus.mockResolvedValue({
        data: { status: 'PROCESSING' },
      });
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.downloadCsv('job-1');
      });

      expect(showToast).toHaveBeenCalledWith(
        'info',
        'Export is still processing...',
        2000,
      );
    });

    it('calls handleApiError when the status request itself fails', async () => {
      const error = new Error('boom');
      pollEventsExportStatus.mockRejectedValue(error);
      const { result } = await renderAndFlush();

      await act(async () => {
        await result.current.downloadCsv('job-1');
      });

      expect(handleApiError).toHaveBeenCalledWith(error);
    });
  });

  describe('cleanup', () => {
    it('clears any active polling intervals on unmount', async () => {
      reRunEventsExport.mockResolvedValue({ data: { export_id: 'job-1' } });
      getRecentExportJobs.mockResolvedValue({
        data: [makeJob({ status: 'PROCESSING' })],
      });

      const { result, unmount } = await renderAndFlush();

      await act(async () => {
        await result.current.retryJobWithPolling('job-1');
      });

      unmount();

      getRecentExportJobs.mockClear();
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30_000);
      });
      // No further polling fetches should occur once unmounted.
      expect(getRecentExportJobs).not.toHaveBeenCalled();
    });
  });
});
