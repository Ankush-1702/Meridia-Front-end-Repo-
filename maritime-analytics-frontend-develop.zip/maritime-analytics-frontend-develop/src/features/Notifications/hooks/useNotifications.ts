import { useCallback, useEffect, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  getNotifications,
  getNotificationsPreference,
  updateNotificationsPreference,
} from '@/features/Notifications/services/notificationsService';
import {
  Notifications,
  RecencyOptions,
  SelectedRecencyPreference,
} from '@/features/Notifications/types/notificationsTypes';

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notifications[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [options, setOptions] = useState<RecencyOptions[]>();
  const [preference, setPreference] = useState<SelectedRecencyPreference>();
  const handleApiError = useApiErrorHandler();

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    try {
      const notifications = await getNotifications();
      setNotifications(notifications.data);
    } catch (err) {
      handleApiError(err);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  }, [handleApiError]);

  const fetchNotificationsOptions = useCallback(async () => {
    setLoading(true);
    try {
      const preferenceSettings = await getNotificationsPreference();
      setOptions(preferenceSettings.recencyOptions);
      setPreference(preferenceSettings.selectedRecencyPreference);
    } catch (err) {
      setOptions([]);
      setPreference(undefined);
      handleApiError(err);
    } finally {
      setLoading(false);
    }
  }, [handleApiError]);

  const updateRecencyPreference = async (value: SelectedRecencyPreference) => {
    try {
      const response = await updateNotificationsPreference(value);
      setPreference(response.recencyPreference);
    } catch (err) {
      handleApiError(err);
    }
  };

  useEffect(() => {
    fetchNotificationsOptions();
  }, [fetchNotificationsOptions]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  return {
    notifications,
    loading,
    preference,
    options,
    updateRecencyPreference,
  };
}
