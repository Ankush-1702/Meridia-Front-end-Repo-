import { NotifyKey } from '@/shared/types/subscriptionTypes';
import { IPaginatedResponse } from '@/types/genericTypes';

export interface Notifications {
  notificationId: string;
  eventId: string;
  eventTimestamp: string;
  zonePortName: string;
  eventType: NotifyKey;
  vesselName: string;
  imo: string;
  vesselType: string;
  subscriptionId: string | null;
  subscriptionName: string | null;
  screeningResult: ScreeningResult | null | '-';
  flagCode: string;
  flag: string;
  zonePortId: string;
  createdAt: string;
}

export type SelectedRecencyPreference = 'ALL' | 'LAST_7_DAYS' | 'LAST_24_HOURS';
export type RecencyOptions = {
  code: SelectedRecencyPreference;
  label: string;
  description: string;
};

export type ScreeningResult = 'CRITICAL' | 'WARNING' | 'OK';

export type NotificationsResponse = IPaginatedResponse<Notifications>;

export interface NotificationsSettingsOptions {
  selectedRecencyPreference: SelectedRecencyPreference;
  recencyOptions: RecencyOptions[];
}

export interface UpdateNotificationsPreference {
  userId: string;
  recencyPreference: SelectedRecencyPreference;
}
