import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import {
  GridApi,
  IRowNode,
  IServerSideGetRowsParams,
} from 'ag-grid-enterprise';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { Notifications } from '../types/notificationsTypes';
import NotificationsPage from '@/features/Notifications/Notifications';
import * as notificationsService from '@/features/Notifications/services/notificationsService';

/* ------------------------------------------------------------------ */
/* Mocks: hooks & services */
/* ------------------------------------------------------------------ */

let mockLocationState: { activeTab?: string } | undefined;
vi.mock('react-router-dom', () => ({
  useLocation: () => ({ pathname: '/', state: mockLocationState }),
}));

vi.mock('@/features/Notifications/services/notificationsService', () => ({
  getNotifications: vi.fn(),
}));

vi.mock('@/features/Notifications/hooks/useNotifications', () => ({
  useNotifications: () => ({
    preference: 'ALL',
    loading: false,
    options: [],
    updateRecencyPreference: vi.fn(),
  }),
}));

const bumpRefreshTokenMock = vi.fn();
vi.mock('@/features/Notifications/hooks/useNotificationsStomp', () => ({
  useNotificationsStomp: () => ({
    showBurstNotice: false,
    burstCount: 0,
    resetBurst: vi.fn(),
    bumpRefreshToken: bumpRefreshTokenMock,
    refreshToken: 0,
  }),
}));

const dismissAllMock = vi.fn();
vi.mock('@/features/Notifications/Context/NotificationsStompContext', () => ({
  useNotificationsStompContext: () => ({
    dismissAllNotifications: dismissAllMock,
    setNotifications: vi.fn(),
  }),
}));

/* ------------------------------------------------------------------ */
/* Mocks: UI components */
/* ------------------------------------------------------------------ */

vi.mock('@/features/Notifications/components/NotificationsHeader', () => ({
  default: ({ headerText }: { headerText: string }) => <h1>{headerText}</h1>,
}));

vi.mock('@/features/Notifications/components/NotificationsTabs', () => ({
  default: ({
    tabs,
    active,
    onChange,
  }: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
  }) => (
    <div>
      {tabs.map((t: string) => (
        <button key={t} onClick={() => onChange(t)}>
          {t} {t === active && '(active)'}
        </button>
      ))}
    </div>
  ),
}));

// Mocking the grid is key: we simulate it calling the "getServerSideData" prop
vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: ({
    getServerSideData,
  }: {
    getServerSideData: (params: IServerSideGetRowsParams) => void;
  }) => {
    return (
      <div data-testid="grid">
        <button
          data-testid="trigger-fetch"
          onClick={() =>
            getServerSideData({
              request: {
                startRow: 0,
                endRow: undefined,
                rowGroupCols: [],
                valueCols: [],
                pivotCols: [],
                pivotMode: false,
                groupKeys: [],
                filterModel: null,
                sortModel: [],
              },
              api: {
                setGridOption: vi.fn(),
                showNoRowsOverlay: vi.fn(),
                hideOverlay: vi.fn(),
              } as unknown as GridApi,
              success: vi.fn(),
              fail: vi.fn(),
              parentNode: {} as IRowNode,
              context: undefined,
            })
          }
        >
          Fetch Data
        </button>
      </div>
    );
  },
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: ({ errorHeading }: { errorHeading: string }) => (
    <div>{errorHeading}</div>
  ),
}));

vi.mock('@/shared/components/EntityTabs', () => ({
  default: ({
    tabs,
    activeTab,
    onChange,
  }: {
    tabs: Array<{ key: string; label: string }>;
    activeTab: string;
    onChange: (tabKey: string) => void;
  }) => (
    <div>
      {tabs.map((t) => (
        <button key={t.key} onClick={() => onChange(t.key)}>
          {t.label} {t.key === activeTab && '(active)'}
        </button>
      ))}
    </div>
  ),
}));

vi.mock('@/features/Notifications/ui/Downloads', () => ({
  default: () => <div data-testid="downloads-tab" />,
}));

const exportToCSVMock = vi.fn();
vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    exportToCSV: exportToCSVMock,
  }),
}));

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotificationsPage Enhanced Coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    mockLocationState = undefined;
  });

  it('renders all core UI elements', () => {
    render(<NotificationsPage />);
    expect(screen.getByText('Notifications')).toBeInTheDocument();
    expect(screen.getByText('Refresh')).toBeInTheDocument();
    expect(screen.getByText('Export')).toBeInTheDocument();
  });

  it('updates storage and context on Refresh click', () => {
    localStorage.setItem('local_notifications', '[]');
    render(<NotificationsPage />);

    fireEvent.click(screen.getByText('Refresh'));

    expect(bumpRefreshTokenMock).toHaveBeenCalled();
    expect(dismissAllMock).toHaveBeenCalled();
    expect(localStorage.getItem('local_notifications')).toBe('[]');
  });

  it('fetches data with correct filters when Port tab is active', async () => {
    const spy = vi
      .spyOn(notificationsService, 'getNotifications')
      .mockResolvedValue({
        data: [],
        meta: {
          total_count: 0,
          request_id: '',
          request_timestamp: '',
          offset: 0,
          limit: 0,
        },
      });

    render(<NotificationsPage />);

    // Switch to Ports tab
    fireEvent.click(screen.getByText('Ports'));

    // Trigger the grid fetch
    fireEvent.click(screen.getByTestId('trigger-fetch'));

    await waitFor(() => {
      expect(spy).toHaveBeenCalledWith(
        'PORT_ARRIVAL,PORT_DEPARTURE,PORT_AREA_ARRIVAL,PORT_AREA_DEPARTURE',
        0,
      );
    });
  });

  it('handles API failure gracefully in getServerSideData', async () => {
    vi.spyOn(notificationsService, 'getNotifications').mockRejectedValue(
      new Error('Network Error'),
    );
    render(<NotificationsPage />);

    fireEvent.click(screen.getByTestId('trigger-fetch'));

    // Verify it doesn't crash and shows empty state eventually
    await waitFor(() => {
      expect(
        screen.getByText('Your notifications will appear here'),
      ).toBeInTheDocument();
    });
  });

  it('generates CSV with correct Risk assessment logic (Coverage for getCSVContent)', async () => {
    // Mocking a row that triggers the "NA" risk logic (ZONE_EXIT)
    const mockRow: Notifications = {
      notificationId: '1',
      eventType: 'ZONE_EXIT',
      vesselName: 'Test Vessel',
      screeningResult: 'CRITICAL',
      createdAt: '1706828400000',
      eventId: '',
      eventTimestamp: '',
      zonePortName: '',
      imo: '',
      vesselType: '',
      subscriptionId: null,
      subscriptionName: null,
      flagCode: '',
      flag: '',
      zonePortId: '',
    };

    vi.spyOn(notificationsService, 'getNotifications').mockResolvedValue({
      data: [mockRow],
      meta: {
        total_count: 1,
        request_id: '',
        request_timestamp: '',
        offset: 0,
        limit: 0,
      },
    });

    render(<NotificationsPage />);

    // 1. Fetch data so 'rows' state is populated
    fireEvent.click(screen.getByTestId('trigger-fetch'));

    // 2. Click Export
    await waitFor(() =>
      expect(screen.queryByText('Fetch Data')).toBeInTheDocument(),
    );
    fireEvent.click(screen.getByText('Export'));

    // 3. Check CSV content passed to the mock
    // The logic says if eventType is ZONE_EXIT, risk = 'NA'
    expect(exportToCSVMock).toHaveBeenCalledWith(
      expect.stringContaining('NA'),
      'All-Notifications',
    );
    expect(exportToCSVMock).toHaveBeenCalledWith(
      expect.stringContaining('Test Vessel'),
      expect.any(String),
    );
  });

  it('reacts to system timezone changes via storage event', async () => {
    render(<NotificationsPage />);

    // Simulate storage event from another tab
    fireEvent(
      window,
      new StorageEvent('storage', {
        key: 'timezone', // Match your TIME_ZONE_KEY
        newValue: 'UTC',
      }),
    );

    // This triggers a re-render and re-calculation of columns useMemo
    // Verified by checking that the component didn't crash
    expect(screen.getByText('Notifications')).toBeInTheDocument();
  });

  it('defaults to the Notifications tab when location.state has no activeTab', () => {
    mockLocationState = undefined;
    render(<NotificationsPage />);

    expect(screen.getByText('Refresh')).toBeInTheDocument();
    expect(screen.getByText('Export')).toBeInTheDocument();
    expect(screen.queryByTestId('downloads-tab')).toBeNull();
  });

  it('initializes on the Downloads tab when location.state.activeTab is "downloads"', () => {
    mockLocationState = { activeTab: 'downloads' };
    render(<NotificationsPage />);

    expect(screen.getByTestId('downloads-tab')).toBeInTheDocument();
    expect(screen.queryByText('Refresh')).toBeNull();
    expect(screen.queryByText('Export')).toBeNull();
  });

  it('switches to Downloads tab when tab button is clicked', () => {
    mockLocationState = undefined;
    render(<NotificationsPage />);

    expect(screen.getByText('Refresh')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Downloads'));

    expect(screen.queryByText('Refresh')).toBeNull();
    expect(screen.getByTestId('downloads-tab')).toBeInTheDocument();
  });

  it('switches back to Notifications tab when tab button is clicked', () => {
    mockLocationState = { activeTab: 'downloads' };
    render(<NotificationsPage />);

    expect(screen.getByTestId('downloads-tab')).toBeInTheDocument();

    const allNotifButtons = screen.getAllByText('Notifications');
    fireEvent.click(allNotifButtons[allNotifButtons.length - 1]);

    expect(screen.getByText('Refresh')).toBeInTheDocument();
    expect(screen.queryByTestId('downloads-tab')).toBeNull();
  });
});
