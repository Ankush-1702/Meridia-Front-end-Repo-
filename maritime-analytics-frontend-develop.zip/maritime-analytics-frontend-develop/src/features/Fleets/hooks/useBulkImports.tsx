import type React from 'react';
import { useRef, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { verifyVessels } from '@/features/Fleets/services/vesselSearchService';
import { BulkImoVerificationResponse } from '@/features/Fleets/types/fleetTypes';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { logger } from '@/shared/utils/logger';

export default function useBulkImports() {
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const [bulkImos, setBulkImos] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [vessels, setVessels] = useState<
    BulkImoVerificationResponse | undefined
  >(undefined);
  const [verifying, setVerifying] = useState<boolean>(false);

  const downloadTemplate = () => {
    const link = document.createElement('a');
    link.href = `${import.meta.env.BASE_URL}fleet-imo-template.csv`;
    link.download = 'fleet-imo-template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const uploadImos = async () => {
    if (!bulkImos && !file) return;
    setVerifying(true);
    try {
      showToast('info', 'Verifying imos...', 2000);
      const imos = bulkImos
        .split(/[\s,]+/)
        .map((imo) => imo.trim())
        .filter(Boolean);
      const res =
        imos.length > 0
          ? await verifyVessels(imos, undefined)
          : await verifyVessels(undefined, file ?? undefined);
      setVessels(res);
      setBulkImos('');
      setFile(null);
      showToast('success', 'Vessels verified', 5000);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (e) {
      handleApiError(e);
      logger.error(e as string);
    } finally {
      setVerifying(false);
    }
  };

  const handleFile = (f: File) => {
    if (f.type === 'text/csv' || f.name.endsWith('.csv')) {
      setFile(f);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  return {
    bulkImos,
    setBulkImos,
    downloadTemplate,
    uploadImos,
    file,
    handleDragOver,
    handleDrop,
    fileInputRef,
    handleFile,
    setFile,
    vessels,
    verifying,
  };
}
