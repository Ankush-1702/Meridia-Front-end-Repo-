import { useCallback, useEffect, useState } from 'react';
import { getFleets } from '../services/fleetService';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { Fleet } from '@/features/Fleets/types/fleetTypes';
import { logger } from '@/shared/utils/logger';

export function useGetFleets(activeTab: string) {
  const [fleetsLoading, setFleetsLoading] = useState<boolean>(false);
  const [fleets, setFleets] = useState<Fleet[] | undefined>([]);
  const handleApiError = useApiErrorHandler();

  const fetchFleets = useCallback(async () => {
    if (activeTab !== 'Fleets') return;
    setFleetsLoading(true);
    try {
      const res = await getFleets(500, 0);
      setFleets(res.data);
    } catch (error) {
      setFleets(undefined);
      handleApiError(error);
      logger.error(error as string);
    } finally {
      setFleetsLoading(false);
    }
  }, [activeTab, handleApiError]);

  useEffect(() => {
    fetchFleets();
  }, [fetchFleets]);

  return { fleets, fetchFleets, fleetsLoading };
}
