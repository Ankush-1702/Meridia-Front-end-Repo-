import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getVesselsInAFleet } from '../services/fleetService';
import { VesselData } from '../types/fleetTypes';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { getFleetEvents } from '@/features/Fleets/services/fleetEventService';
import {
  FlatFleetEventsResponse,
  FleetEventType,
} from '@/features/Fleets/types/fleetEventTypes';
import { flattenFleetEvent } from '@/features/Fleets/utils/fleetEventUtils';
import { TAB_EVENT_TYPES } from '@/features/Vessels/utils/vesselUtils';
import { clampEnd } from '@/shared/utils/formatUtils';
import { logger } from '@/shared/utils/logger';

const VESSELS_LIMIT = 500;
export function useFleetEvents(
  fleetId: string,
  fleetEventsTabs: { label: string; value: string; groupings: string }[],
) {
  const handleApiError = useApiErrorHandler();
  const columnStorageKey = `fleet-events`;
  const [rows, setRows] = useState<FlatFleetEventsResponse[]>([]);
  const [refresh, setRefresh] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const initialSelected = fleetEventsTabs.reduce<Record<string, boolean>>(
    (acc, tab) => ({ ...acc, [tab.value]: true }),
    {},
  );
  const [selectedRow, setSelectedRow] = useState<
    FlatFleetEventsResponse | undefined
  >(undefined);
  const [vessels, setVessels] = useState<VesselData[]>([]);

  const [selected, setSelected] =
    useState<Record<string, boolean>>(initialSelected);
  const eventsRequestIdRef = useRef(0);

  const onToggle = useCallback((value: string, checked: boolean) => {
    setSelected((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const onSelectAll = useCallback(
    (checked: boolean) => {
      setSelected(
        fleetEventsTabs.reduce<Record<string, boolean>>(
          (acc, tab) => ({ ...acc, [tab.value]: checked }),
          {},
        ),
      );
    },
    [fleetEventsTabs],
  );

  const selectedValues = useMemo(
    () => Object.keys(selected).filter((key) => selected[key]),
    [selected],
  );

  const allowedEventTypes = useMemo(
    () => selectedValues.flatMap((tab) => TAB_EVENT_TYPES[tab] ?? tab),
    [selectedValues],
  );

  const fetchFleetEvents = useCallback(async () => {
    const requestId = ++eventsRequestIdRef.current;
    if (!fleetId) {
      setRows([]);
      setRefresh(false);
      setIsLoading(false);
      return;
    }
    if (allowedEventTypes.length === 0) {
      setRows([]);
      setRefresh(false);
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    const now = new Date();
    const timeStampStart =
      new Date(now.getTime() - 24 * 60 * 60 * 1000 * 90)
        .toISOString()
        .split('.')[0] + 'Z';
    const timeStampEnd =
      clampEnd(now, 60, new Date()).toISOString().split('.')[0] + 'Z';
    try {
      const res = await getFleetEvents(
        fleetId,
        allowedEventTypes as FleetEventType[],
        timeStampStart,
        timeStampEnd,
        0,
        500,
      );
      if (requestId !== eventsRequestIdRef.current) return;

      const flattenedRows = res.data.events.flatMap((event) => {
        try {
          return [flattenFleetEvent(event)];
        } catch (error) {
          logger.warn('Skipping fleet event that could not be flattened', {
            eventId: event?.event_details?.event_id,
            eventType: event?.event_details?.event_type,
            error,
          });
          return [];
        }
      });

      setRows(flattenedRows);
      setLastUpdated(new Date());
    } catch {
      if (requestId === eventsRequestIdRef.current) {
        setRows([]);
      }
    } finally {
      if (requestId === eventsRequestIdRef.current) {
        setRefresh(false);
        setIsLoading(false);
      }
    }
  }, [fleetId, allowedEventTypes]);

  const fetchFleetVessels = useCallback(async () => {
    if (!fleetId) return;
    try {
      let offset = 0;
      let totalCount = Infinity;
      let allVessels: VesselData[] = [];
      while (offset < totalCount) {
        const vessels = await getVesselsInAFleet(
          fleetId,
          VESSELS_LIMIT,
          offset,
        );
        allVessels = allVessels.concat(vessels.data);
        totalCount = vessels.meta.total_count;
        offset += VESSELS_LIMIT;
      }
      setVessels(allVessels);
    } catch (error) {
      handleApiError(error);
      setVessels([]);
    }
  }, [fleetId, handleApiError]);

  useEffect(() => {
    fetchFleetVessels();
  }, [fetchFleetVessels]);

  useEffect(() => {
    fetchFleetEvents();
  }, [fetchFleetEvents]);

  useEffect(() => {
    const interval = setInterval(
      () => {
        fetchFleetEvents();
      },
      5 * 60 * 1000,
    );

    return () => clearInterval(interval);
  }, [fetchFleetEvents]);

  // Manual refresh trigger
  useEffect(() => {
    if (refresh) {
      setLastUpdated(new Date());
      fetchFleetEvents();
    }
  }, [refresh, fetchFleetEvents]);

  return {
    refresh,
    setRefresh,
    selected,
    onToggle,
    rows,
    lastUpdated,
    isLoading,
    columnStorageKey,
    onSelectAll,
    selectedRow,
    setSelectedRow,
    vessels,
  };
}
