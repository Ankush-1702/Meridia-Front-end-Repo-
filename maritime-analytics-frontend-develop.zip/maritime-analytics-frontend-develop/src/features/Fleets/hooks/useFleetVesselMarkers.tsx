import mapboxgl from 'mapbox-gl';
import { useEffect, useRef } from 'react';
import FleetVesselMarkerIcon from '../components/FleetVesselMarkerIcon';
import { VesselData } from '../types/fleetTypes';
import { buildFleetVesselPopupHtml } from '../utils/fleetMapUtils';
import {
  HOVER_SIZE,
  MARKER_SIZE,
} from '@/shared/constants/overviewMapConstants';
import {
  createReactMarkerElement,
  type ReactMarkerHandle,
} from '@/shared/hooks/useReactMarker';
import { getColor } from '@/shared/utils/CongestionAndTrafficUtils';
import { logger } from '@/shared/utils/logger';
import {
  formatUtcDisplay,
  hashToRotation,
  isValidCoordinate,
} from '@/shared/utils/overviewMapUtils';

function getRotation(vessel: VesselData): number {
  const heading = vessel.vessel_position?.heading;
  const course = vessel.vessel_position?.course;
  if (typeof heading === 'number' && heading >= 0 && heading <= 360) {
    return heading;
  }
  if (typeof course === 'number' && course >= 0 && course <= 360) {
    return course;
  }
  return hashToRotation(vessel.vessel_information.imo);
}

function stylePopupElement(popup: mapboxgl.Popup): void {
  const popupEl = popup.getElement();
  if (!popupEl) return;

  const content = popupEl.querySelector(
    '.mapboxgl-popup-content',
  ) as HTMLElement | null;
  const tip = popupEl.querySelector(
    '.mapboxgl-popup-tip',
  ) as HTMLElement | null;

  if (content) {
    content.style.background = 'transparent';
    content.style.boxShadow = 'none';
    content.style.padding = '0';
    content.style.border = 'none';
  }
  if (tip) {
    tip.style.display = 'none';
  }
}

export function useFleetVesselMarkers(
  mapRef: React.RefObject<mapboxgl.Map | null>,
  mapReady: boolean,
  vessels: VesselData[],
  onVesselClick: (vessel: VesselData) => void,
) {
  const markersRef = useRef<
    { marker: mapboxgl.Marker; handle: ReactMarkerHandle }[]
  >([]);
  const sharedPopupRef = useRef<mapboxgl.Popup | null>(null);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    markersRef.current.forEach(({ marker, handle }) => {
      marker.remove();
      handle.unmount();
    });
    markersRef.current = [];

    const validVessels = vessels.filter((v) =>
      isValidCoordinate(
        v.vessel_position?.latitude,
        v.vessel_position?.longitude,
      ),
    );

    if (vessels.length > 0 && validVessels.length === 0) {
      logger.warn(
        '[useFleetVesselMarkers] vessels were provided but none had a valid vessel_position — check the shape of the first vessel:',
        vessels[0],
      );
    }

    validVessels.forEach((vessel) => {
      const position = vessel.vessel_position;
      if (!position) return;

      const rotation = getRotation(vessel);
      const { latitude, longitude } = position;
      const color = getColor(vessel.vessel_information.vessel_type);
      const hoverBg = `${color}33`;

      const handle = createReactMarkerElement(
        <div
          className="flex items-center justify-center rounded-full"
          style={{ width: HOVER_SIZE, height: HOVER_SIZE }}
        >
          <FleetVesselMarkerIcon
            size={MARKER_SIZE}
            rotationDeg={rotation}
            color={color}
          />
        </div>,
      );

      handle.element.style.cursor = 'pointer';

      const marker = new mapboxgl.Marker({ element: handle.element })
        .setLngLat([longitude, latitude])
        .addTo(map);

      const popupHtml = buildFleetVesselPopupHtml({
        vesselName: vessel.vessel_information.name || 'Unknown Vessel',
        imo: vessel.vessel_information.imo || '',
        vesselType: vessel.vessel_information.vessel_type || '',
        vesselClass: vessel.vessel_information.vessel_class || '',
        flag: vessel.vessel_information.flag || '',
        speed: position.speed,
        course: position.course || 0,
        reportedDestination: position.reported_destination || '',
        reportedEta: position.reported_eta || '',
        timeStr: formatUtcDisplay(position.timestamp),
      });

      handle.element.addEventListener('mouseenter', () => {
        if (sharedPopupRef.current) {
          sharedPopupRef.current.remove();
          sharedPopupRef.current = null;
        }

        handle.update(
          <div
            className="flex items-center justify-center rounded-full"
            style={{
              width: HOVER_SIZE,
              height: HOVER_SIZE,
              backgroundColor: hoverBg,
            }}
          >
            <FleetVesselMarkerIcon
              size={MARKER_SIZE}
              rotationDeg={rotation}
              color={color}
              isHovered
            />
          </div>,
        );

        const popup = new mapboxgl.Popup({
          offset: 12,
          closeButton: false,
          closeOnClick: false,
        })
          .setHTML(popupHtml)
          .setLngLat([longitude, latitude])
          .addTo(map);

        stylePopupElement(popup);
        sharedPopupRef.current = popup;
      });

      handle.element.addEventListener('mouseleave', () => {
        handle.update(
          <div
            className="flex items-center justify-center rounded-full"
            style={{ width: HOVER_SIZE, height: HOVER_SIZE }}
          >
            <FleetVesselMarkerIcon
              size={MARKER_SIZE}
              rotationDeg={rotation}
              color={color}
            />
          </div>,
        );

        if (sharedPopupRef.current) {
          sharedPopupRef.current.remove();
          sharedPopupRef.current = null;
        }
      });

      handle.element.addEventListener('click', (e) => {
        e.stopPropagation();
        onVesselClick(vessel);
      });

      markersRef.current.push({ marker, handle });
    });

    return () => {
      if (sharedPopupRef.current) {
        sharedPopupRef.current.remove();
        sharedPopupRef.current = null;
      }
      markersRef.current.forEach(({ marker, handle }) => {
        marker.remove();
        handle.unmount();
      });
      markersRef.current = [];
    };
  }, [vessels, mapReady, onVesselClick, mapRef]);

  return {};
}
