import { useCallback, useEffect, useMemo, useState } from 'react';

import { useParams } from 'react-router';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { IFleetExportBody } from '@/features/Fleets/types/fleetTypes';
import { fleetExportManager } from '@/features/Fleets/utils/fleetExportsManager';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';

export function useFleetExports(
  flagCode: string[],
  mtiScore: string[],
  vesselClass: string[],
  vesselType: string[],
) {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const [isPolling, setIsPolling] = useState(fleetExportManager.isPolling());

  const body: IFleetExportBody = useMemo(
    () => ({
      filters: {
        flag_code: flagCode,
        mti_score: mtiScore,
        vessel_class: vesselClass,
        vessel_type: vesselType,
      },
    }),
    [flagCode, mtiScore, vesselClass, vesselType],
  );

  const buildCallbacks = useCallback(
    () => ({
      onStatus: () => setIsPolling(true),
      onDownloadReady: (url: string) => {
        setIsPolling(false);
        showToast('info', 'Downloading export...', 500);
        setTimeout(() => {
          const link = document.createElement('a');
          link.href = url;
          link.download = 'berths-export.csv';
          link.click();
          showToast('success', 'CSV Exported!', 5000);
        }, 500);
      },
      onError: (e: unknown) => {
        setIsPolling(false);
        handleApiError(e);
      },
    }),
    [showToast, handleApiError],
  );
  // Re-register callbacks on every mount so the live component always receives events
  // No cleanup — intentionally do NOT stop polling on unmount
  useEffect(() => {
    fleetExportManager.registerCallbacks(buildCallbacks());
  }, [buildCallbacks]);

  const handleExportClick = useCallback(async () => {
    if (!id || fleetExportManager.isPolling()) return;

    showToast('info', 'Exporting CSV...', 2000);
    setIsPolling(true);

    try {
      await fleetExportManager.trigger(id, body, buildCallbacks());
    } catch (e) {
      setIsPolling(false);
      handleApiError(e);
    }
  }, [id, body, buildCallbacks, showToast, handleApiError]);

  return { handleExportClick, isPolling };
}
