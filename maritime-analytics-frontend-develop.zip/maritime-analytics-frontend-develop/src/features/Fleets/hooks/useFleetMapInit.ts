import mapboxgl from 'mapbox-gl';
import { useEffect, useRef, useState } from 'react';
import { MAPBOX_TOKEN } from '@/app/config/config';
import type { OverviewMapCenter } from '@/shared/types/OverviewMapTypes';

// World view — fleet vessels are scattered globally, so there's no single
// natural center. Matches the default used by other global vessel maps
// (e.g. VesselActivityMap) rather than Mapbox's [0,0]/zoom-0 fallback.
const DEFAULT_CENTER: OverviewMapCenter = { latitude: 20, longitude: 0 };
const DEFAULT_ZOOM = 1;

export function useFleetMapInit(
  containerRef: React.RefObject<HTMLDivElement | null>,
  initialStyle: string,
  center: OverviewMapCenter = DEFAULT_CENTER,
  zoom: number = DEFAULT_ZOOM,
) {
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const currentStyleRef = useRef<string | null>(null);

  useEffect(() => {
    // This effect runs first, so its cleanup runs LAST (React cleans up in reverse order)
    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (mapRef.current || !containerRef.current || !MAPBOX_TOKEN) return;

    currentStyleRef.current = initialStyle;

    mapRef.current = new mapboxgl.Map({
      container: containerRef.current,
      style: initialStyle,
      center: [center.longitude, center.latitude],
      zoom,
      attributionControl: false,
    });

    mapRef.current.on('load', () => {
      setMapReady(true);
      // Trigger a resize to ensure the map fills the container on initial mount
      mapRef.current?.resize();
    });

    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
      setMapReady(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { mapRef, mapReady, currentStyleRef };
}
