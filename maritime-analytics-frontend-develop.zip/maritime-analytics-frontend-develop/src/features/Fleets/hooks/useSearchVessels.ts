import { useCallback } from 'react';
import { searchVesselsforFleets } from '@/features/Fleets/services/vesselSearchService';
import { usePaginatedSearch } from '@/features/library/hooks/usePaginatedSearch';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

const SEARCH_LIMIT = 500;

export function useSearchVessels(debouncedQuery: string) {
  const searchVesselsFn = useCallback(
    async (query: string, limit: number, offset: number) => {
      const res = await searchVesselsforFleets(query, limit, offset);
      return {
        data: res.data,
        meta: res.meta ?? { total_count: res.data.length },
      };
    },
    [],
  );
  const vessels = usePaginatedSearch<VesselSearch>({
    searchFn: searchVesselsFn,
    getItemId: (v) => v.imo,
    limit: SEARCH_LIMIT,
    query: debouncedQuery,
    enabled: debouncedQuery.trim().length >= 3,
  });
  return { vessels };
}
