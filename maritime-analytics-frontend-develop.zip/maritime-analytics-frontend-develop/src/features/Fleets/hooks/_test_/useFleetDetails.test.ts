import { renderHook, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import { useFleetDetails } from '@/features/Fleets/hooks/useFleetDetails';
import * as fleetService from '@/features/Fleets/services/fleetService';
import { Fleet, FleetDetailResponse } from '@/features/Fleets/types/fleetTypes';

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/Fleets/services/fleetService');

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    fleet_id: 'fleet-1',
    name: 'Test Fleet',
    description: 'desc',
    type: 'STATIC',
    vessel_count: 3,
    created_by: 'user-1',
    created_at: '2026-01-01T00:00:00Z',
    last_modified_by: 'user-1',
    last_modified_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

function makeResponse(fleet: Fleet): FleetDetailResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    data: fleet,
  };
}

describe('useFleetDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('does not fetch when id is undefined', () => {
    renderHook(() => useFleetDetails(undefined));

    expect(fleetService.getFleetById).not.toHaveBeenCalled();
  });

  it('fetches fleet details when id is provided', async () => {
    const fleet = makeFleet();
    (fleetService.getFleetById as Mock).mockResolvedValue(makeResponse(fleet));

    const { result } = renderHook(() => useFleetDetails('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-1');
    expect(result.current.fleet).toEqual(fleet);
    expect(result.current.loadError).toBe(false);
  });

  it('sets loading to true while fetching', async () => {
    let resolveFn: (value: FleetDetailResponse) => void;
    (fleetService.getFleetById as Mock).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveFn = resolve;
        }),
    );

    const { result } = renderHook(() => useFleetDetails('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(true));

    resolveFn!(makeResponse(makeFleet()));

    await waitFor(() => expect(result.current.loading).toBe(false));
  });

  it('sets loadError and calls error handler on failure', async () => {
    const error = new Error('not found');
    (fleetService.getFleetById as Mock).mockRejectedValue(error);

    const { result } = renderHook(() => useFleetDetails('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.loadError).toBe(true);
    expect(result.current.fleet).toBeUndefined();
    expect(mockHandleApiError).toHaveBeenCalledWith(error);
  });

  it('refetches when id changes', async () => {
    (fleetService.getFleetById as Mock).mockResolvedValue(
      makeResponse(makeFleet()),
    );

    const { rerender } = renderHook(({ id }) => useFleetDetails(id), {
      initialProps: { id: 'fleet-1' as string | undefined },
    });

    await waitFor(() =>
      expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-1'),
    );

    rerender({ id: 'fleet-2' });

    await waitFor(() =>
      expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-2'),
    );
  });
});
