import { renderHook, waitFor, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import { useGetFleets } from '@/features/Fleets/hooks/useGetFleets';
import * as fleetService from '@/features/Fleets/services/fleetService';
import { Fleet, FleetsResponse } from '@/features/Fleets/types/fleetTypes';

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/Fleets/services/fleetService');

vi.mock('@/shared/utils/logger', () => ({
  logger: { error: vi.fn(), warn: vi.fn(), info: vi.fn() },
}));

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    fleet_id: 'fleet-1',
    name: 'Test Fleet',
    description: 'desc',
    type: 'STATIC',
    vessel_count: 3,
    created_by: 'user-1',
    created_at: '2026-01-01T00:00:00Z',
    last_modified_by: 'user-1',
    last_modified_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

function makeResponse(data: Fleet[]): FleetsResponse {
  return {
    meta: {
      limit: 500,
      offset: 0,
      total_count: data.length,
      request_id: 'req-1',
      request_timestamp: '2026-01-01T00:00:00Z',
    },
    data,
  };
}

describe('useGetFleets', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('fetches fleets when activeTab is "Fleets"', async () => {
    const fleets = [makeFleet()];
    (fleetService.getFleets as Mock).mockResolvedValue(makeResponse(fleets));

    const { result } = renderHook(() => useGetFleets('Fleets'));

    await waitFor(() => expect(result.current.fleetsLoading).toBe(false));

    expect(fleetService.getFleets).toHaveBeenCalledWith(500, 0);
    expect(result.current.fleets).toEqual(fleets);
  });

  it('does not fetch fleets when activeTab is not "Fleets"', () => {
    renderHook(() => useGetFleets('Other'));

    expect(fleetService.getFleets).not.toHaveBeenCalled();
  });

  it('sets fleetsLoading to true while fetching', async () => {
    let resolveFn: (value: FleetsResponse) => void;
    (fleetService.getFleets as Mock).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveFn = resolve;
        }),
    );

    const { result } = renderHook(() => useGetFleets('Fleets'));

    await waitFor(() => expect(result.current.fleetsLoading).toBe(true));

    resolveFn!(makeResponse([]));

    await waitFor(() => expect(result.current.fleetsLoading).toBe(false));
  });

  it('sets fleets to undefined and calls error handlers on failure', async () => {
    const error = new Error('network error');
    (fleetService.getFleets as Mock).mockRejectedValue(error);

    const { result } = renderHook(() => useGetFleets('Fleets'));

    await waitFor(() => expect(result.current.fleetsLoading).toBe(false));

    expect(result.current.fleets).toBeUndefined();
    expect(mockHandleApiError).toHaveBeenCalledWith(error);
  });

  it('refetches when fetchFleets is invoked again', async () => {
    (fleetService.getFleets as Mock).mockResolvedValue(makeResponse([]));

    const { result } = renderHook(() => useGetFleets('Fleets'));

    await waitFor(() => expect(result.current.fleetsLoading).toBe(false));

    (fleetService.getFleets as Mock).mockClear();

    await act(async () => {
      await result.current.fetchFleets();
    });

    expect(fleetService.getFleets).toHaveBeenCalledTimes(1);
  });

  it('refetches when activeTab changes back to "Fleets"', async () => {
    (fleetService.getFleets as Mock).mockResolvedValue(makeResponse([]));

    const { rerender } = renderHook(
      ({ activeTab }) => useGetFleets(activeTab),
      { initialProps: { activeTab: 'Other' } },
    );

    expect(fleetService.getFleets).not.toHaveBeenCalled();

    rerender({ activeTab: 'Fleets' });

    await waitFor(() =>
      expect(fleetService.getFleets).toHaveBeenCalledTimes(1),
    );
  });
});
