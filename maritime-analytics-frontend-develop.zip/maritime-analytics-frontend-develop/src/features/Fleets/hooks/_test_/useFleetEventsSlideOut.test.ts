import { act, renderHook, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useFleetEventSlideOut } from '@/features/Fleets/hooks/useFleetEventsSlideOut';
import { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';
import type { VesselData } from '@/features/Fleets/types/fleetTypes';
import { getLivePortCongestionData } from '@/features/Ports/services/portCongestionApi';
import {
  fetchZoneBoundary,
  fetchZoneDetails,
} from '@/features/Zones/services/zoneServices';
import { getLiveZoneTrafficData } from '@/features/Zones/services/zoneTrafficApi';
import { getOverviewDataStream } from '@/shared/services/overview/overviewService';
import type { OverviewDataResult } from '@/shared/services/overview/types';
import { ILiveDataResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

vi.mock('@/features/Ports/services/portCongestionApi');
vi.mock('@/features/Zones/services/zoneServices');
vi.mock('@/features/Zones/services/zoneTrafficApi');
vi.mock('@/shared/services/overview/overviewService', () => ({
  getOverviewDataStream: vi.fn(),
}));

const vessel = {
  vessel_information: { imo: 'IMO-1', name: 'Test vessel' },
} as VesselData;
const liveData = {} as unknown as ILiveDataResponse;

function overviewStream(totalVessels: number) {
  return (async function* () {
    yield {
      data: { positions: [] } satisfies OverviewDataResult,
      progress: {
        current: 1,
        total: 2,
        isComplete: false,
        vesselsLoaded: 500,
        totalVessels,
        percentage: 50,
      },
    };
    throw new Error('The hook should stop after receiving the total count');
  })();
}

function makeRow(
  values: Partial<FlatFleetEventsResponse> = {},
): FlatFleetEventsResponse {
  return {
    callSign: 'CALL-1',
    flag: 'Nigeria',
    flagCode: 'NG',
    imo: 'IMO-1',
    mmsi: 'MMSI-1',
    vesselName: 'Test vessel',
    vesselType: 'Cargo',
    eventType: 'PORT_ARRIVAL',
    zoneId: 'zone-1',
    zoneType: 'Standard',
    ...values,
  };
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise;
  });
  return { promise, resolve };
}

describe('useFleetEventSlideOut', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(fetchZoneBoundary).mockResolvedValue({
      geometry: 'boundary',
    } as never);
    vi.mocked(fetchZoneDetails).mockResolvedValue({
      geometry: 'custom-boundary',
    } as never);
    vi.mocked(getLivePortCongestionData).mockResolvedValue(liveData);
    vi.mocked(getLiveZoneTrafficData).mockResolvedValue(liveData);
    vi.mocked(getOverviewDataStream).mockReturnValue(overviewStream(42));
  });

  it('selects the primary vessel from the supplied fleet vessels while loading event details', async () => {
    const row = makeRow();

    const { result } = renderHook(() =>
      useFleetEventSlideOut(row, undefined, [vessel]),
    );

    expect(result.current.vessel).toBe(vessel);
    expect(fetchZoneBoundary).toHaveBeenCalledWith('zone-1');
    expect(getLivePortCongestionData).toHaveBeenCalledWith('zone-1');
    expect(fetchZoneDetails).not.toHaveBeenCalled();

    await waitFor(() => {
      expect(result.current.zoneBoundary).toBe('boundary');
      expect(result.current.locationEvents).toBe(liveData);
      expect(result.current.vesselInPortOrZone).toBe(42);
    });

    expect(getOverviewDataStream).toHaveBeenCalledWith({
      entity: { type: 'port', id: 'zone-1' },
    });
  });

  it('uses embedded paired vessel data for STS events and clears it for ineligible rows', async () => {
    const { result, rerender } = renderHook(
      ({ row }: { row: FlatFleetEventsResponse }) => useFleetEventSlideOut(row),
      { initialProps: { row: makeRow() } },
    );

    await waitFor(() => {
      expect(result.current.zoneBoundary).toBe('boundary');
      expect(result.current.locationEvents).toBe(liveData);
    });

    const stsRow = makeRow({
      eventType: 'STS_PAIRING',
      pairedIMO: 'IMO-2',
      pairedVesselData: {
        vessel_information: { imo: 'IMO-2' },
      } as VesselData,
    });
    rerender({ row: stsRow });

    await waitFor(() =>
      expect(result.current.pairedVessel).toBe(stsRow.pairedVesselData),
    );
    expect(getLivePortCongestionData).toHaveBeenCalledTimes(1);

    rerender({ row: makeRow({ eventType: 'AIS_GAP', zoneId: undefined }) });

    await waitFor(() => {
      expect(result.current.zoneBoundary).toBeUndefined();
      expect(result.current.locationEvents).toBeUndefined();
      expect(result.current.pairedVessel).toBeUndefined();
      expect(result.current.location).toBeUndefined();
    });
    expect(fetchZoneBoundary).toHaveBeenCalledTimes(2);
    expect(fetchZoneDetails).not.toHaveBeenCalled();
  });

  it('returns to the event view when the selected row changes during vessel drill-down', async () => {
    const { result, rerender } = renderHook(
      ({ row }: { row: FlatFleetEventsResponse }) =>
        useFleetEventSlideOut(row, undefined, [vessel]),
      { initialProps: { row: makeRow() } },
    );

    act(() => result.current.setViewVessel(true));
    expect(result.current.viewVessel).toBe(true);

    rerender({ row: makeRow({ imo: 'IMO-2', zoneId: 'zone-2' }) });
    expect(result.current.viewVessel).toBe(false);

    await waitFor(() => expect(result.current.vessel).toBeUndefined());
  });

  it('ignores boundary and movement data from a previously selected row', async () => {
    const firstBoundary =
      deferred<Awaited<ReturnType<typeof fetchZoneBoundary>>>();
    const latestBoundary =
      deferred<Awaited<ReturnType<typeof fetchZoneBoundary>>>();
    const firstMovement = deferred<ILiveDataResponse>();
    const latestMovement = deferred<ILiveDataResponse>();
    const firstLiveData = {} as unknown as ILiveDataResponse;
    const latestLiveData = {} as unknown as ILiveDataResponse;

    vi.mocked(fetchZoneBoundary)
      .mockReturnValueOnce(firstBoundary.promise)
      .mockReturnValueOnce(latestBoundary.promise);
    vi.mocked(getLivePortCongestionData)
      .mockReturnValueOnce(firstMovement.promise)
      .mockReturnValueOnce(latestMovement.promise);

    const { result, rerender } = renderHook(
      ({ row }: { row: FlatFleetEventsResponse }) => useFleetEventSlideOut(row),
      { initialProps: { row: makeRow({ zoneId: 'zone-1' }) } },
    );
    await waitFor(() =>
      expect(getLivePortCongestionData).toHaveBeenCalledTimes(1),
    );

    rerender({ row: makeRow({ zoneId: 'zone-2' }) });
    await waitFor(() =>
      expect(getLivePortCongestionData).toHaveBeenCalledTimes(2),
    );

    await act(async () => {
      latestBoundary.resolve({ geometry: 'latest-boundary' } as never);
      latestMovement.resolve(latestLiveData);
    });
    await waitFor(() => {
      expect(result.current.zoneBoundary).toBe('latest-boundary');
      expect(result.current.locationEvents).toBe(latestLiveData);
    });

    await act(async () => {
      firstBoundary.resolve({ geometry: 'stale-boundary' } as never);
      firstMovement.resolve(firstLiveData);
    });
    expect(result.current.zoneBoundary).toBe('latest-boundary');
    expect(result.current.locationEvents).toBe(latestLiveData);
  });

  it('uses custom zone details for custom zone rows', async () => {
    vi.mocked(fetchZoneDetails).mockResolvedValue({
      geometry: 'custom-boundary',
    } as never);
    const row = makeRow({ zoneType: 'Custom' });

    const { result } = renderHook(() => useFleetEventSlideOut(row));

    await waitFor(() =>
      expect(result.current.zoneBoundary).toBe('custom-boundary'),
    );
    expect(fetchZoneDetails).toHaveBeenCalledWith('zone-1');
    expect(fetchZoneBoundary).not.toHaveBeenCalled();
  });

  it('fetches the total count for zone events', async () => {
    vi.mocked(getOverviewDataStream).mockReturnValue(overviewStream(18));
    const row = makeRow({ eventType: 'ZONE_ENTRY' });

    const { result } = renderHook(() => useFleetEventSlideOut(row));

    await waitFor(() => expect(result.current.vesselInPortOrZone).toBe(18));
    expect(getOverviewDataStream).toHaveBeenCalledWith({
      entity: { type: 'zone', id: 'zone-1' },
    });
  });

  it('resets the count for unrelated events and failed requests', async () => {
    vi.mocked(getOverviewDataStream).mockRejectedValue(new Error('failed'));
    const { result, rerender } = renderHook(
      ({ row }: { row: FlatFleetEventsResponse }) => useFleetEventSlideOut(row),
      { initialProps: { row: makeRow() } },
    );

    await waitFor(() => expect(result.current.vesselInPortOrZone).toBe(0));

    rerender({ row: makeRow({ eventType: 'AIS_GAP' }) });
    await waitFor(() => expect(result.current.vesselInPortOrZone).toBe(0));
    expect(getOverviewDataStream).toHaveBeenCalledTimes(1);
  });

  it('ignores a count response from a previously selected row', async () => {
    let resolvePortCount: ((count: number) => void) | undefined;
    vi.mocked(getOverviewDataStream)
      .mockReturnValueOnce(
        (async function* () {
          const totalVessels = await new Promise<number>((resolve) => {
            resolvePortCount = resolve;
          });
          yield {
            data: { positions: [] } satisfies OverviewDataResult,
            progress: {
              current: 1,
              total: 1,
              isComplete: true,
              vesselsLoaded: totalVessels,
              totalVessels,
              percentage: 100,
            },
          };
        })(),
      )
      .mockReturnValueOnce(overviewStream(88));

    const { result, rerender } = renderHook(
      ({ row }: { row: FlatFleetEventsResponse }) => useFleetEventSlideOut(row),
      { initialProps: { row: makeRow() } },
    );

    rerender({ row: makeRow({ eventType: 'ZONE_EXIT', zoneId: 'zone-2' }) });
    await waitFor(() => expect(result.current.vesselInPortOrZone).toBe(88));

    await act(async () => {
      resolvePortCount?.(12);
    });
    expect(result.current.vesselInPortOrZone).toBe(88);
  });
});
