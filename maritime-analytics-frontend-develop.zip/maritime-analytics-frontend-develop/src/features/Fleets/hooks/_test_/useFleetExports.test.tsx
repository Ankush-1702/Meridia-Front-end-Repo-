import { act, renderHook } from '@testing-library/react';
import type { ReactNode } from 'react';
import { MemoryRouter, Route, Routes } from 'react-router';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useFleetExports } from '../useFleetExports';
import { fleetExportManager } from '@/features/Fleets/utils/fleetExportsManager';

const { handleApiError, showToast, polling } = vi.hoisted(() => ({
  handleApiError: vi.fn(),
  showToast: vi.fn(),
  polling: { value: false },
}));
vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiError,
}));
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast }),
}));
vi.mock('@/features/Fleets/utils/fleetExportsManager', () => ({
  fleetExportManager: {
    isPolling: () => polling.value,
    registerCallbacks: vi.fn(),
    trigger: vi.fn(),
  },
}));

function wrapper({ children }: { children: ReactNode }) {
  return (
    <MemoryRouter initialEntries={['/fleets/fleet-1']}>
      <Routes>
        <Route path="/fleets/:id" element={<>{children}</>} />
      </Routes>
    </MemoryRouter>
  );
}

describe('useFleetExports', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    polling.value = false;
  });

  it('registers live callbacks and triggers export with the current filters', async () => {
    vi.mocked(fleetExportManager.trigger).mockResolvedValue(undefined);
    const flags = ['NG'];
    const { result } = renderHook(
      () => useFleetExports(flags, ['high'], ['Bulk Carrier'], ['Dry Cargo']),
      { wrapper },
    );

    expect(fleetExportManager.registerCallbacks).toHaveBeenCalledWith(
      expect.objectContaining({
        onStatus: expect.any(Function),
        onDownloadReady: expect.any(Function),
        onError: expect.any(Function),
      }),
    );

    await act(async () => result.current.handleExportClick());
    expect(fleetExportManager.trigger).toHaveBeenCalledWith(
      'fleet-1',
      {
        filters: {
          flag_code: flags,
          mti_score: ['high'],
          vessel_class: ['Bulk Carrier'],
          vessel_type: ['Dry Cargo'],
        },
      },
      expect.any(Object),
    );
    expect(showToast).toHaveBeenCalledWith('info', 'Exporting CSV...', 2000);
    expect(result.current.isPolling).toBe(true);
  });

  it('skips export without a fleet ID or while an export is already polling', async () => {
    const { result, rerender } = renderHook(
      () => useFleetExports([], [], [], []),
      { wrapper: ({ children }) => <MemoryRouter>{children}</MemoryRouter> },
    );

    await act(async () => result.current.handleExportClick());
    expect(fleetExportManager.trigger).not.toHaveBeenCalled();

    polling.value = true;
    rerender();
    await act(async () => result.current.handleExportClick());
    expect(fleetExportManager.trigger).not.toHaveBeenCalled();
  });

  it('handles a trigger failure and clears polling state', async () => {
    const error = new Error('trigger failed');
    vi.mocked(fleetExportManager.trigger).mockRejectedValue(error);
    const { result } = renderHook(() => useFleetExports([], [], [], []), {
      wrapper,
    });

    await act(async () => result.current.handleExportClick());
    expect(result.current.isPolling).toBe(false);
    expect(handleApiError).toHaveBeenCalledWith(error);
  });

  it('handles download and manager error callbacks', async () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useFleetExports([], [], [], []), {
      wrapper,
    });
    const callbacks = vi.mocked(fleetExportManager.registerCallbacks).mock
      .calls[0][0];
    const click = vi.fn();
    const createElement = vi.spyOn(document, 'createElement');
    createElement.mockImplementation(((tagName: string) => {
      const element = document.createElementNS(
        'http://www.w3.org/1999/xhtml',
        tagName,
      ) as HTMLElement;
      if (tagName === 'a') element.click = click;
      return element;
    }) as typeof document.createElement);

    act(() =>
      callbacks.onDownloadReady?.('https://download/file.csv', 'fleets-export'),
    );
    expect(result.current.isPolling).toBe(false);
    expect(showToast).toHaveBeenCalledWith(
      'info',
      'Downloading export...',
      500,
    );
    await act(async () => vi.advanceTimersByTimeAsync(500));
    expect(click).toHaveBeenCalledOnce();
    expect(showToast).toHaveBeenCalledWith('success', 'CSV Exported!', 5000);

    act(() => callbacks.onError?.(new Error('poll failed')));
    expect(handleApiError).toHaveBeenCalledWith(
      expect.objectContaining({ message: 'poll failed' }),
    );
    createElement.mockRestore();
    vi.useRealTimers();
  });
});
