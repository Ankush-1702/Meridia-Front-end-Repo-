import { renderHook, act } from '@testing-library/react';
import mapboxgl from 'mapbox-gl';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useFleetVesselMarkers } from '@/features/Fleets/hooks/useFleetVesselMarkers';
import { VesselData } from '@/features/Fleets/types/fleetTypes';

/* ---------------- hoisted (referenced inside vi.mock factories) ---------------- */

const {
  mockMarkerRemove,
  mockMarkerSetLngLat,
  mockMarkerAddTo,
  mockMarkerInstance,
  mockPopupRemove,
  mockPopupSetHTML,
  mockPopupSetLngLat,
  mockPopupAddTo,
  mockPopupInstance,
  mockCreateReactMarkerElement,
  mockIsValidCoordinate,
  mockBuildFleetVesselPopupHtml,
  mockGetColor,
  mockLoggerWarn,
} = vi.hoisted(() => {
  const mockMarkerRemove = vi.fn();
  const mockMarkerSetLngLat = vi.fn();
  const mockMarkerAddTo = vi.fn();
  const mockMarkerInstance = {
    setLngLat: mockMarkerSetLngLat,
    addTo: mockMarkerAddTo,
    remove: mockMarkerRemove,
  };
  mockMarkerSetLngLat.mockReturnValue(mockMarkerInstance);
  mockMarkerAddTo.mockReturnValue(mockMarkerInstance);

  const mockPopupRemove = vi.fn();
  const mockPopupSetHTML = vi.fn();
  const mockPopupSetLngLat = vi.fn();
  const mockPopupAddTo = vi.fn();
  const mockPopupInstance = {
    remove: mockPopupRemove,
    setHTML: mockPopupSetHTML,
    setLngLat: mockPopupSetLngLat,
    addTo: mockPopupAddTo,
    getElement: vi.fn().mockReturnValue(null),
  };
  mockPopupSetHTML.mockReturnValue(mockPopupInstance);
  mockPopupSetLngLat.mockReturnValue(mockPopupInstance);
  mockPopupAddTo.mockReturnValue(mockPopupInstance);

  const mockCreateReactMarkerElement = vi.fn().mockImplementation(() => {
    const element = document.createElement('div');
    return { element, unmount: vi.fn(), update: vi.fn(), root: {} };
  });

  const mockIsValidCoordinate = vi.fn().mockReturnValue(true);
  const mockBuildFleetVesselPopupHtml = vi
    .fn()
    .mockReturnValue('<div>popup</div>');
  const mockGetColor = vi.fn().mockReturnValue('#123456');
  const mockLoggerWarn = vi.fn();

  return {
    mockMarkerRemove,
    mockMarkerSetLngLat,
    mockMarkerAddTo,
    mockMarkerInstance,
    mockPopupRemove,
    mockPopupSetHTML,
    mockPopupSetLngLat,
    mockPopupAddTo,
    mockPopupInstance,
    mockCreateReactMarkerElement,
    mockIsValidCoordinate,
    mockBuildFleetVesselPopupHtml,
    mockGetColor,
    mockLoggerWarn,
  };
});

/* ---------------- mocks ---------------- */

vi.mock('mapbox-gl', () => ({
  default: {
    Marker: vi.fn().mockImplementation(function () {
      return mockMarkerInstance;
    }),
    Popup: vi.fn().mockImplementation(function () {
      return mockPopupInstance;
    }),
  },
}));

vi.mock('@/shared/hooks/useReactMarker', () => ({
  createReactMarkerElement: mockCreateReactMarkerElement,
}));

vi.mock('@/features/Fleets/utils/fleetMapUtils', () => ({
  buildFleetVesselPopupHtml: mockBuildFleetVesselPopupHtml,
}));

vi.mock('@/shared/utils/CongestionAndTrafficUtils', () => ({
  getColor: mockGetColor,
}));

vi.mock('@/shared/utils/logger', () => ({
  logger: { warn: mockLoggerWarn, error: vi.fn(), info: vi.fn() },
}));

vi.mock('@/shared/utils/overviewMapUtils', () => ({
  isValidCoordinate: mockIsValidCoordinate,
  formatUtcDisplay: vi.fn().mockReturnValue('01 Jan 2026 12:00 UTC'),
  hashToRotation: vi.fn().mockReturnValue(45),
}));

/* ---------------- helpers ---------------- */

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Cargo',
      vessel_class: 'General Cargo',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    ...overrides,
  };
}

function makeMockMap() {
  return {} as unknown as mapboxgl.Map;
}

type HandleMock = {
  element: HTMLDivElement;
  unmount: ReturnType<typeof vi.fn>;
  update: ReturnType<typeof vi.fn>;
};

function getHandle(callIndex = 0): HandleMock {
  return mockCreateReactMarkerElement.mock.results[callIndex]
    .value as HandleMock;
}

const noop = () => {};

/* ---------------- tests ---------------- */

describe('useFleetVesselMarkers', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockMarkerSetLngLat.mockReturnValue(mockMarkerInstance);
    mockMarkerAddTo.mockReturnValue(mockMarkerInstance);
    mockPopupSetHTML.mockReturnValue(mockPopupInstance);
    mockPopupSetLngLat.mockReturnValue(mockPopupInstance);
    mockPopupAddTo.mockReturnValue(mockPopupInstance);
    mockIsValidCoordinate.mockReturnValue(true);
    mockBuildFleetVesselPopupHtml.mockReturnValue('<div>popup</div>');
    mockGetColor.mockReturnValue('#123456');
    mockCreateReactMarkerElement.mockImplementation(() => {
      const element = document.createElement('div');
      return { element, unmount: vi.fn(), update: vi.fn(), root: {} };
    });
  });

  describe('guards', () => {
    it('does not create markers when map is null', () => {
      renderHook(() =>
        useFleetVesselMarkers({ current: null }, true, [makeVessel()], noop),
      );

      expect(mapboxgl.Marker).not.toHaveBeenCalled();
    });

    it('does not create markers when mapReady is false', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          false,
          [makeVessel()],
          noop,
        ),
      );

      expect(mapboxgl.Marker).not.toHaveBeenCalled();
    });

    it('skips vessels with invalid coordinates', () => {
      mockIsValidCoordinate.mockReturnValue(false);

      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      expect(mapboxgl.Marker).not.toHaveBeenCalled();
    });

    it('logs a warning when vessels are provided but none have valid positions', () => {
      mockIsValidCoordinate.mockReturnValue(false);

      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      expect(mockLoggerWarn).toHaveBeenCalled();
    });

    it('does not log a warning when vessel list is empty', () => {
      renderHook(() =>
        useFleetVesselMarkers({ current: makeMockMap() }, true, [], noop),
      );

      expect(mockLoggerWarn).not.toHaveBeenCalled();
    });
  });

  describe('marker creation', () => {
    it('creates one marker per valid vessel', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [
            makeVessel({
              vessel_information: {
                ...makeVessel().vessel_information,
                imo: '111',
              },
            }),
            makeVessel({
              vessel_information: {
                ...makeVessel().vessel_information,
                imo: '222',
              },
            }),
          ],
          noop,
        ),
      );

      expect(mapboxgl.Marker).toHaveBeenCalledTimes(2);
    });

    it('positions each marker at the vessel coordinates', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      expect(mockMarkerSetLngLat).toHaveBeenCalledWith([4.0, 52.0]);
    });

    it('adds each marker to the map', () => {
      const map = makeMockMap();

      renderHook(() =>
        useFleetVesselMarkers({ current: map }, true, [makeVessel()], noop),
      );

      expect(mockMarkerAddTo).toHaveBeenCalledWith(map);
    });

    it('sets cursor to pointer on the handle element', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      expect(getHandle(0).element.style.cursor).toBe('pointer');
    });

    it('uses heading for rotation when valid', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      expect(mapboxgl.Marker).toHaveBeenCalled();
    });
  });

  describe('mouseenter', () => {
    it('creates a popup with the built HTML', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      getHandle(0).element.dispatchEvent(new MouseEvent('mouseenter'));

      expect(mapboxgl.Popup).toHaveBeenCalled();
      expect(mockPopupSetHTML).toHaveBeenCalledWith('<div>popup</div>');
    });

    it('positions the popup at the vessel coordinates', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      getHandle(0).element.dispatchEvent(new MouseEvent('mouseenter'));

      expect(mockPopupSetLngLat).toHaveBeenCalledWith([4.0, 52.0]);
    });

    it('calls handle.update to switch to hover state', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const handle = getHandle(0);
      handle.element.dispatchEvent(new MouseEvent('mouseenter'));

      expect(handle.update).toHaveBeenCalled();
    });

    it('removes an existing popup before showing a new one', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const el = getHandle(0).element;
      el.dispatchEvent(new MouseEvent('mouseenter'));
      el.dispatchEvent(new MouseEvent('mouseenter'));

      expect(mockPopupRemove).toHaveBeenCalled();
    });
  });

  describe('mouseleave', () => {
    it('removes the popup on mouseleave', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const el = getHandle(0).element;
      el.dispatchEvent(new MouseEvent('mouseenter'));
      el.dispatchEvent(new MouseEvent('mouseleave'));

      expect(mockPopupRemove).toHaveBeenCalled();
    });

    it('calls handle.update to reset the marker state', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const handle = getHandle(0);
      handle.element.dispatchEvent(new MouseEvent('mouseenter'));
      handle.update.mockClear();
      handle.element.dispatchEvent(new MouseEvent('mouseleave'));

      expect(handle.update).toHaveBeenCalled();
    });
  });

  describe('click', () => {
    it('calls onVesselClick with the vessel', () => {
      const onVesselClick = vi.fn();
      const vessel = makeVessel();

      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [vessel],
          onVesselClick,
        ),
      );

      getHandle(0).element.dispatchEvent(
        new MouseEvent('click', { bubbles: true }),
      );

      expect(onVesselClick).toHaveBeenCalledWith(vessel);
    });

    it('stops event propagation', () => {
      renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const event = new MouseEvent('click', { bubbles: true });
      vi.spyOn(event, 'stopPropagation');
      getHandle(0).element.dispatchEvent(event);

      expect(event.stopPropagation).toHaveBeenCalled();
    });
  });

  describe('cleanup', () => {
    it('removes all markers on unmount', () => {
      const { unmount } = renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [
            makeVessel({
              vessel_information: {
                ...makeVessel().vessel_information,
                imo: '111',
              },
            }),
            makeVessel({
              vessel_information: {
                ...makeVessel().vessel_information,
                imo: '222',
              },
            }),
          ],
          noop,
        ),
      );

      act(() => {
        unmount();
      });

      expect(mockMarkerRemove).toHaveBeenCalledTimes(2);
    });

    it('unmounts all handles on unmount', () => {
      const { unmount } = renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      const handle0 = getHandle(0);

      act(() => {
        unmount();
      });

      expect(handle0.unmount).toHaveBeenCalled();
    });

    it('removes the popup on unmount if one is open', () => {
      const { unmount } = renderHook(() =>
        useFleetVesselMarkers(
          { current: makeMockMap() },
          true,
          [makeVessel()],
          noop,
        ),
      );

      getHandle(0).element.dispatchEvent(new MouseEvent('mouseenter'));

      act(() => {
        unmount();
      });

      expect(mockPopupRemove).toHaveBeenCalled();
    });

    it('clears previous markers when the vessel list changes', () => {
      const map = makeMockMap();

      const { rerender } = renderHook(
        ({ vessels }) =>
          useFleetVesselMarkers({ current: map }, true, vessels, noop),
        {
          initialProps: {
            vessels: [
              makeVessel({
                vessel_information: {
                  ...makeVessel().vessel_information,
                  imo: '111',
                },
              }),
            ],
          },
        },
      );

      act(() => {
        rerender({
          vessels: [
            makeVessel({
              vessel_information: {
                ...makeVessel().vessel_information,
                imo: '222',
              },
            }),
          ],
        });
      });

      expect(mockMarkerRemove).toHaveBeenCalled();
    });
  });
});
