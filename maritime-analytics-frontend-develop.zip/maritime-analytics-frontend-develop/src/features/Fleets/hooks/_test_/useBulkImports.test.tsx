import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import useBulkImports from '@/features/Fleets/hooks/useBulkImports';
import { verifyVessels } from '@/features/Fleets/services/vesselSearchService';
import { BulkImoVerificationResponse } from '@/features/Fleets/types/fleetTypes';

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

const mockShowToast = vi.fn();
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

vi.mock('@/features/Fleets/services/vesselSearchService');

function makeVerificationResponse(
  overrides: Partial<BulkImoVerificationResponse> = {},
): BulkImoVerificationResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    summary: { requested: 1, found: 1, not_found: 0, invalid: 0 },
    data: {
      found: [
        {
          asset_id: 'a1',
          imo: '1234567',
          vessel_name: 'Test Vessel',
          mmsi: 123456789,
          flag: 'Norway',
          vessel_type: 'Cargo',
          flag_code: 'NOR',
          vessel_status: 'ACTIVE',
        },
      ],
      not_found: [],
      invalid: [],
    },
    ...overrides,
  };
}

function makeCsvFile(name = 'imos.csv') {
  return new File(['1234567\n7654321'], name, { type: 'text/csv' });
}

describe('useBulkImports', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (verifyVessels as Mock).mockResolvedValue(makeVerificationResponse());
  });

  describe('initial state', () => {
    it('starts with empty bulkImos, no file, no vessels, not verifying', () => {
      const { result } = renderHook(() => useBulkImports());

      expect(result.current.bulkImos).toBe('');
      expect(result.current.file).toBeNull();
      expect(result.current.vessels).toBeUndefined();
      expect(result.current.verifying).toBe(false);
    });
  });

  describe('setBulkImos', () => {
    it('updates the pasted IMOs text', () => {
      const { result } = renderHook(() => useBulkImports());

      act(() => {
        result.current.setBulkImos('1234567, 7654321');
      });

      expect(result.current.bulkImos).toBe('1234567, 7654321');
    });
  });

  describe('handleFile / handleDrop / handleDragOver', () => {
    it('accepts a csv file via handleFile', () => {
      const { result } = renderHook(() => useBulkImports());
      const file = makeCsvFile();

      act(() => {
        result.current.handleFile(file);
      });

      expect(result.current.file).toBe(file);
    });

    it('rejects a non-csv file via handleFile', () => {
      const { result } = renderHook(() => useBulkImports());
      const file = new File(['data'], 'imos.txt', { type: 'text/plain' });

      act(() => {
        result.current.handleFile(file);
      });

      expect(result.current.file).toBeNull();
    });

    it('accepts a .csv-named file even without a text/csv mime type', () => {
      const { result } = renderHook(() => useBulkImports());
      const file = new File(['data'], 'imos.csv', { type: '' });

      act(() => {
        result.current.handleFile(file);
      });

      expect(result.current.file).toBe(file);
    });

    it('handleDrop sets the file from the drop event and prevents default', () => {
      const { result } = renderHook(() => useBulkImports());
      const file = makeCsvFile();
      const preventDefault = vi.fn();
      const dropEvent = {
        preventDefault,
        dataTransfer: { files: [file] },
      } as unknown as React.DragEvent;

      act(() => {
        result.current.handleDrop(dropEvent);
      });

      expect(preventDefault).toHaveBeenCalled();
      expect(result.current.file).toBe(file);
    });

    it('handleDrop does nothing when there is no dropped file', () => {
      const { result } = renderHook(() => useBulkImports());
      const preventDefault = vi.fn();
      const dropEvent = {
        preventDefault,
        dataTransfer: { files: [] },
      } as unknown as React.DragEvent;

      act(() => {
        result.current.handleDrop(dropEvent);
      });

      expect(preventDefault).toHaveBeenCalled();
      expect(result.current.file).toBeNull();
    });

    it('handleDragOver prevents default', () => {
      const { result } = renderHook(() => useBulkImports());
      const preventDefault = vi.fn();
      const dragOverEvent = {
        preventDefault,
      } as unknown as React.DragEvent;

      act(() => {
        result.current.handleDragOver(dragOverEvent);
      });

      expect(preventDefault).toHaveBeenCalled();
    });
  });

  describe('uploadImos', () => {
    it('does nothing when there are no pasted imos and no file', async () => {
      const { result } = renderHook(() => useBulkImports());

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(verifyVessels).not.toHaveBeenCalled();
      expect(result.current.verifying).toBe(false);
    });

    it('parses and trims pasted imos (split on whitespace/commas) and verifies them', async () => {
      const { result } = renderHook(() => useBulkImports());

      act(() => {
        result.current.setBulkImos(' 1234567,  7654321\n9999999 ');
      });

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(verifyVessels).toHaveBeenCalledWith(
        ['1234567', '7654321', '9999999'],
        undefined,
      );
    });

    it('verifies via file when no imos are pasted', async () => {
      const { result } = renderHook(() => useBulkImports());
      const file = makeCsvFile();

      act(() => {
        result.current.handleFile(file);
      });

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(verifyVessels).toHaveBeenCalledWith(undefined, file);
    });

    it('prefers pasted imos over a selected file when both are present', async () => {
      const { result } = renderHook(() => useBulkImports());
      const file = makeCsvFile();

      act(() => {
        result.current.setBulkImos('1234567');
        result.current.handleFile(file);
      });

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(verifyVessels).toHaveBeenCalledWith(['1234567'], undefined);
    });

    it('sets verifying true while the request is in flight', async () => {
      let resolveFn: (value: BulkImoVerificationResponse) => void;
      (verifyVessels as Mock).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveFn = resolve;
          }),
      );
      const { result } = renderHook(() => useBulkImports());

      act(() => {
        result.current.setBulkImos('1234567');
      });

      let uploadPromise: Promise<void>;
      act(() => {
        uploadPromise = result.current.uploadImos();
      });

      expect(result.current.verifying).toBe(true);

      await act(async () => {
        resolveFn!(makeVerificationResponse());
        await uploadPromise;
      });

      expect(result.current.verifying).toBe(false);
    });

    it('on success, stores the resolved vessels, clears bulkImos/file, and shows toasts', async () => {
      const response = makeVerificationResponse();
      (verifyVessels as Mock).mockResolvedValue(response);
      const { result } = renderHook(() => useBulkImports());

      act(() => {
        result.current.setBulkImos('1234567');
      });

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(result.current.vessels).toEqual(response);
      expect(result.current.bulkImos).toBe('');
      expect(result.current.file).toBeNull();
      expect(mockShowToast).toHaveBeenCalledWith(
        'info',
        'Verifying imos...',
        2000,
      );
      expect(mockShowToast).toHaveBeenCalledWith(
        'success',
        'Vessels verified',
        5000,
      );
    });

    it('on error, calls the API error handler and leaves vessels unset', async () => {
      const error = new Error('verify failed');
      (verifyVessels as Mock).mockRejectedValue(error);
      const { result } = renderHook(() => useBulkImports());

      act(() => {
        result.current.setBulkImos('1234567');
      });

      await act(async () => {
        await result.current.uploadImos();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
      expect(result.current.vessels).toBeUndefined();
      expect(result.current.verifying).toBe(false);
    });
  });

  describe('downloadTemplate', () => {
    it('creates a download link, clicks it, and removes it', () => {
      const { result } = renderHook(() => useBulkImports());
      const appendSpy = vi.spyOn(document.body, 'appendChild');
      const removeSpy = vi.spyOn(document.body, 'removeChild');
      const clickSpy = vi
        .spyOn(HTMLAnchorElement.prototype, 'click')
        .mockImplementation(() => {});

      act(() => {
        result.current.downloadTemplate();
      });

      expect(appendSpy).toHaveBeenCalled();
      expect(clickSpy).toHaveBeenCalled();
      expect(removeSpy).toHaveBeenCalled();

      appendSpy.mockRestore();
      removeSpy.mockRestore();
      clickSpy.mockRestore();
    });
  });
});
