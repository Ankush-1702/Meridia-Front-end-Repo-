import { act, renderHook } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useFleetEventMarkers } from '@/features/Fleets/hooks/useFleetEventMarkers';
import type { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';
import { createReactMarkerElement } from '@/shared/hooks/useReactMarker';

const {
  mockMarkerRemove,
  mockSetLngLat,
  mockAddTo,
  mockMarkerInstance,
  mockFlyTo,
  mockFitBounds,
  mockAddSource,
  mockAddLayer,
  mockGetLayer,
  mockGetSource,
  mockRemoveLayer,
  mockRemoveSource,
  mockOn,
  mockOff,
  mockHandleUnmount,
} = vi.hoisted(() => {
  const mockMarkerRemove = vi.fn();
  const mockSetLngLat = vi.fn();
  const mockAddTo = vi.fn();
  const mockMarkerInstance = {
    setLngLat: mockSetLngLat,
    addTo: mockAddTo,
    remove: mockMarkerRemove,
  };
  mockSetLngLat.mockReturnValue(mockMarkerInstance);
  mockAddTo.mockReturnValue(mockMarkerInstance);

  return {
    mockMarkerRemove,
    mockSetLngLat,
    mockAddTo,
    mockMarkerInstance,
    mockFlyTo: vi.fn(),
    mockFitBounds: vi.fn(),
    mockAddSource: vi.fn(),
    mockAddLayer: vi.fn(),
    mockGetLayer: vi.fn(() => undefined),
    mockGetSource: vi.fn(() => undefined),
    mockRemoveLayer: vi.fn(),
    mockRemoveSource: vi.fn(),
    mockOn: vi.fn(),
    mockOff: vi.fn(),
    mockHandleUnmount: vi.fn(),
  };
});

vi.mock('mapbox-gl', () => ({
  default: {
    Marker: vi.fn().mockImplementation(function () {
      return mockMarkerInstance;
    }),
  },
}));

vi.mock('@/shared/hooks/useReactMarker', () => ({
  createReactMarkerElement: vi.fn(() => ({
    element: document.createElement('div'),
    unmount: mockHandleUnmount,
    update: vi.fn(),
    root: {},
  })),
}));

function makeMap() {
  return {
    isStyleLoaded: () => true,
    addSource: mockAddSource,
    addLayer: mockAddLayer,
    getLayer: mockGetLayer,
    getSource: mockGetSource,
    removeLayer: mockRemoveLayer,
    removeSource: mockRemoveSource,
    on: mockOn,
    off: mockOff,
    flyTo: mockFlyTo,
    fitBounds: mockFitBounds,
  } as unknown as mapboxgl.Map;
}

function makeEvent(
  fields: Partial<FlatFleetEventsResponse>,
): FlatFleetEventsResponse {
  return {
    callSign: 'CALLSIGN',
    flag: 'Flag',
    flagCode: 'GB',
    imo: '1234567',
    mmsi: '123456789',
    vesselName: 'Vessel',
    vesselType: 'Cargo',
    ...fields,
  };
}

describe('useFleetEventMarkers', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSetLngLat.mockReturnValue(mockMarkerInstance);
    mockAddTo.mockReturnValue(mockMarkerInstance);
    mockGetLayer.mockReturnValue(undefined);
    mockGetSource.mockReturnValue(undefined);
  });

  it('renders Mara2-colored AIS endpoints and a dashed red track, then cleans up', () => {
    const map = makeMap();
    const event = makeEvent({
      eventType: 'AIS_GAP',
      gapStartedLatitude: 51.5,
      gapStartedLongitude: -0.1,
      gapEndedLatitude: 52,
      gapEndedLongitude: 0.2,
    });
    const { unmount } = renderHook(() =>
      useFleetEventMarkers({ current: map }, true, event),
    );

    expect(mockSetLngLat).toHaveBeenNthCalledWith(1, [-0.1, 51.5]);
    expect(mockSetLngLat).toHaveBeenNthCalledWith(2, [0.2, 52]);
    expect(createReactMarkerElement).toHaveBeenNthCalledWith(
      1,
      expect.objectContaining({
        props: expect.objectContaining({ color: 'bg-red-600' }),
      }),
    );
    expect(createReactMarkerElement).toHaveBeenNthCalledWith(
      2,
      expect.objectContaining({
        props: expect.objectContaining({ color: 'bg-red-600' }),
      }),
    );
    expect(mockAddLayer).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'line',
        paint: expect.objectContaining({
          'line-color': '#dc2626',
          'line-dasharray': [4, 2],
        }),
      }),
    );
    expect(mockFitBounds).toHaveBeenCalledWith(
      [
        [-0.1, 51.5],
        [0.2, 52],
      ],
      { padding: 32, maxZoom: 12, duration: 0 },
    );

    act(() => unmount());

    expect(mockMarkerRemove).toHaveBeenCalledTimes(2);
    expect(mockHandleUnmount).toHaveBeenCalledTimes(2);
    expect(mockOff).toHaveBeenCalledWith('style.load', expect.any(Function));
  });

  it('shows the valid AIS endpoint without drawing a track for incomplete data', () => {
    const map = makeMap();
    const event = makeEvent({
      eventType: 'AIS_GAP',
      gapStartedLatitude: 51.5,
      gapStartedLongitude: -0.1,
    });

    renderHook(() => useFleetEventMarkers({ current: map }, true, event));

    expect(mockSetLngLat).toHaveBeenCalledTimes(1);
    expect(mockAddSource).not.toHaveBeenCalled();
    expect(mockFlyTo).toHaveBeenCalledWith({
      center: [-0.1, 51.5],
      zoom: 12,
      speed: 0.6,
    });
  });

  it('renders positional discrepancy markers and a yellow dashed track', () => {
    const event = makeEvent({
      eventType: 'POSITIONAL_DISCREPANCY',
      startedLatitude: 30,
      startedLongitude: 40,
      stoppedLatitude: 31,
      stoppedLongitude: 41,
    });

    renderHook(() => useFleetEventMarkers({ current: makeMap() }, true, event));

    expect(mockSetLngLat).toHaveBeenNthCalledWith(1, [40, 30]);
    expect(mockSetLngLat).toHaveBeenNthCalledWith(2, [41, 31]);
    expect(createReactMarkerElement).toHaveBeenCalledWith(
      expect.objectContaining({
        props: expect.objectContaining({ color: 'bg-yellow-400' }),
      }),
    );
    expect(mockAddLayer).toHaveBeenCalledWith(
      expect.objectContaining({
        paint: expect.objectContaining({
          'line-color': '#facc15',
          'line-dasharray': [4, 2],
        }),
      }),
    );
  });

  it('renders one STS marker and does not add a track', () => {
    const event = makeEvent({
      eventType: 'STS_PAIRING',
      stsLatitude: 30,
      stsLongitude: 40,
    });

    renderHook(() => useFleetEventMarkers({ current: makeMap() }, true, event));

    expect(mockSetLngLat).toHaveBeenCalledWith([40, 30]);
    expect(createReactMarkerElement).toHaveBeenCalledWith(
      expect.objectContaining({
        props: expect.objectContaining({ color: 'bg-blue-500' }),
      }),
    );
    expect(mockAddSource).not.toHaveBeenCalled();
  });
});
