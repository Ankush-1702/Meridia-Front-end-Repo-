import { renderHook, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import { useSearchVessels } from '@/features/Fleets/hooks/useSearchVessels';
import * as vesselSearchService from '@/features/Fleets/services/vesselSearchService';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

vi.mock('@/features/Fleets/services/vesselSearchService');

function makeVessel(imo = '1234567'): VesselSearch {
  return {
    imo,
    name: 'Test Vessel',
    flag: 'Norway',
    flag_code: 'NOR',
    vessel_type: 'Cargo',
  } as VesselSearch;
}

describe('useSearchVessels', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('does not search when query is shorter than 3 characters', () => {
    renderHook(() => useSearchVessels('ab'));

    expect(vesselSearchService.searchVesselsforFleets).not.toHaveBeenCalled();
  });

  it('does not search for an empty query', () => {
    renderHook(() => useSearchVessels(''));

    expect(vesselSearchService.searchVesselsforFleets).not.toHaveBeenCalled();
  });

  it('searches when query is 3 or more characters', async () => {
    (vesselSearchService.searchVesselsforFleets as Mock).mockResolvedValue({
      data: [makeVessel()],
      meta: { total_count: 1 },
    });

    const { result } = renderHook(() => useSearchVessels('abc'));

    await waitFor(() =>
      expect(result.current.vessels.initialLoading).toBe(false),
    );

    expect(vesselSearchService.searchVesselsforFleets).toHaveBeenCalledWith(
      'abc',
      500,
      0,
    );
    expect(result.current.vessels.items).toEqual([makeVessel()]);
  });

  it('falls back to items length as total_count when meta is missing', async () => {
    (vesselSearchService.searchVesselsforFleets as Mock).mockResolvedValue({
      data: [makeVessel('111'), makeVessel('222')],
    });

    const { result } = renderHook(() => useSearchVessels('abc'));

    await waitFor(() =>
      expect(result.current.vessels.initialLoading).toBe(false),
    );

    expect(result.current.vessels.items).toHaveLength(2);
    expect(result.current.vessels.hasMore).toBe(false);
  });

  it('surfaces a search error', async () => {
    (vesselSearchService.searchVesselsforFleets as Mock).mockRejectedValue(
      new Error('search failed'),
    );

    const { result } = renderHook(() => useSearchVessels('abc'));

    await waitFor(() =>
      expect(result.current.vessels.initialLoading).toBe(false),
    );

    expect(result.current.vessels.error).toBe('search failed');
    expect(result.current.vessels.items).toEqual([]);
  });

  it('re-searches when the query changes', async () => {
    (vesselSearchService.searchVesselsforFleets as Mock).mockResolvedValue({
      data: [],
      meta: { total_count: 0 },
    });

    const { rerender } = renderHook(({ query }) => useSearchVessels(query), {
      initialProps: { query: 'abc' },
    });

    await waitFor(() =>
      expect(vesselSearchService.searchVesselsforFleets).toHaveBeenCalledWith(
        'abc',
        500,
        0,
      ),
    );

    rerender({ query: 'xyz' });

    await waitFor(() =>
      expect(vesselSearchService.searchVesselsforFleets).toHaveBeenCalledWith(
        'xyz',
        500,
        0,
      ),
    );
  });
});
