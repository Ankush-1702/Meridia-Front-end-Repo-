import { renderHook, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import { useFleetEdit } from '@/features/Fleets/hooks/useFleetEdit';
import * as fleetService from '@/features/Fleets/services/fleetService';
import {
  Fleet,
  FleetDetailResponse,
  VesselData,
  VesselsInAFleetResponse,
} from '@/features/Fleets/types/fleetTypes';

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/Fleets/services/fleetService');

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    fleet_id: 'fleet-1',
    name: 'Test Fleet',
    description: 'desc',
    type: 'STATIC',
    vessel_count: 1,
    created_by: 'user-1',
    created_at: '2026-01-01T00:00:00Z',
    last_modified_by: 'user-1',
    last_modified_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Cargo',
      vessel_class: 'General Cargo',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    ...overrides,
  };
}

function makeFleetResponse(fleet: Fleet): FleetDetailResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    data: fleet,
  };
}

function makeVesselsResponse(data: VesselData[]): VesselsInAFleetResponse {
  return {
    meta: {
      limit: 500,
      offset: 0,
      total_count: data.length,
      request_id: 'req-1',
      request_timestamp: '2026-01-01T00:00:00Z',
    },
    data,
  };
}

describe('useFleetEdit', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('does not fetch when id is undefined', () => {
    renderHook(() => useFleetEdit(undefined));

    expect(fleetService.getFleetById).not.toHaveBeenCalled();
    expect(fleetService.getVesselsInAFleet).not.toHaveBeenCalled();
  });

  it('fetches fleet and its vessels when id is provided', async () => {
    const fleet = makeFleet();
    const vessel = makeVessel();
    (fleetService.getFleetById as Mock).mockResolvedValue(
      makeFleetResponse(fleet),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([vessel]),
    );

    const { result } = renderHook(() => useFleetEdit('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-1');
    expect(fleetService.getVesselsInAFleet).toHaveBeenCalledWith(
      'fleet-1',
      500,
      0,
    );
    expect(result.current.fleet).toEqual(fleet);
    expect(result.current.vessels).toEqual([vessel]);
    expect(result.current.loadError).toBe(false);
  });

  it('maps vessels to VesselSearch shape for initialVessels', async () => {
    const vessel = makeVessel();
    (fleetService.getFleetById as Mock).mockResolvedValue(
      makeFleetResponse(makeFleet()),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([vessel]),
    );

    const { result } = renderHook(() => useFleetEdit('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.initialVessels).toHaveLength(1);
    expect(result.current.initialVessels[0]).toMatchObject({
      imo: vessel.vessel_information.imo,
      name: vessel.vessel_information.name,
    });
  });

  it('sets loading to true while fetching', async () => {
    let resolveFn: (value: FleetDetailResponse) => void;
    (fleetService.getFleetById as Mock).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveFn = resolve;
        }),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([]),
    );

    const { result } = renderHook(() => useFleetEdit('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(true));

    resolveFn!(makeFleetResponse(makeFleet()));

    await waitFor(() => expect(result.current.loading).toBe(false));
  });

  it('sets loadError, clears initialVessels, and calls error handler when fleet fetch fails', async () => {
    const error = new Error('not found');
    (fleetService.getFleetById as Mock).mockRejectedValue(error);

    const { result } = renderHook(() => useFleetEdit('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.loadError).toBe(true);
    expect(result.current.initialVessels).toEqual([]);
    expect(mockHandleApiError).toHaveBeenCalledWith(error);
  });

  it('sets loadError when vessel fetch fails', async () => {
    (fleetService.getFleetById as Mock).mockResolvedValue(
      makeFleetResponse(makeFleet()),
    );
    const error = new Error('vessels fetch failed');
    (fleetService.getVesselsInAFleet as Mock).mockRejectedValue(error);

    const { result } = renderHook(() => useFleetEdit('fleet-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.loadError).toBe(true);
    expect(mockHandleApiError).toHaveBeenCalledWith(error);
  });

  it('refetches when id changes', async () => {
    (fleetService.getFleetById as Mock).mockResolvedValue(
      makeFleetResponse(makeFleet()),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([]),
    );

    const { rerender } = renderHook(({ id }) => useFleetEdit(id), {
      initialProps: { id: 'fleet-1' as string | undefined },
    });

    await waitFor(() =>
      expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-1'),
    );

    rerender({ id: 'fleet-2' });

    await waitFor(() =>
      expect(fleetService.getFleetById).toHaveBeenCalledWith('fleet-2'),
    );
  });
});
