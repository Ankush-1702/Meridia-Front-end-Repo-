import { renderHook, act } from '@testing-library/react';
import mapboxgl from 'mapbox-gl';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useFleetMapInit } from '@/features/Fleets/hooks/useFleetMapInit';

const mockRemove = vi.fn();
const mockOn = vi.fn();
const mockResize = vi.fn();

vi.mock('mapbox-gl', () => ({
  default: {
    Map: vi.fn().mockImplementation(function () {
      return {
        on: mockOn,
        remove: mockRemove,
        resize: mockResize,
      };
    }),
  },
}));

let mockToken = 'test-token';

vi.mock('@/app/config/config', () => ({
  get MAPBOX_TOKEN() {
    return mockToken;
  },
}));

function makeContainerRef(el?: HTMLDivElement | null) {
  return { current: el ?? document.createElement('div') };
}

const style = 'mapbox://styles/mapbox/dark-v10';

describe('useFleetMapInit', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockToken = 'test-token';
  });

  it('starts with mapReady as false', () => {
    const { result } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    expect(result.current.mapReady).toBe(false);
  });

  it('does not initialize the map when token is missing', () => {
    mockToken = '';

    renderHook(() => useFleetMapInit(makeContainerRef(), style));

    expect(mapboxgl.Map).not.toHaveBeenCalled();
  });

  it('does not initialize the map when containerRef is null', () => {
    renderHook(() => useFleetMapInit({ current: null }, style));

    expect(mapboxgl.Map).not.toHaveBeenCalled();
  });

  it('initializes mapboxgl.Map with the default world-view center and zoom', () => {
    const container = document.createElement('div');

    renderHook(() => useFleetMapInit({ current: container }, style));

    expect(mapboxgl.Map).toHaveBeenCalledWith({
      container,
      style,
      center: [0, 20],
      zoom: 1,
      attributionControl: false,
    });
  });

  it('initializes mapboxgl.Map with a custom center and zoom', () => {
    const container = document.createElement('div');
    const center = { latitude: 51.5, longitude: -0.1 };

    renderHook(() => useFleetMapInit({ current: container }, style, center, 8));

    expect(mapboxgl.Map).toHaveBeenCalledWith({
      container,
      style,
      center: [center.longitude, center.latitude],
      zoom: 8,
      attributionControl: false,
    });
  });

  it('sets mapReady to true and resizes the map when the load event fires', () => {
    mockOn.mockImplementation((event: string, cb: () => void) => {
      if (event === 'load') cb();
    });

    const { result } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    expect(result.current.mapReady).toBe(true);
    expect(mockResize).toHaveBeenCalledTimes(1);
  });

  it('stores the initial style in currentStyleRef', () => {
    const { result } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    expect(result.current.currentStyleRef.current).toBe(style);
  });

  it('exposes a non-null mapRef after initialization', () => {
    const { result } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    expect(result.current.mapRef.current).not.toBeNull();
  });

  it('removes the map and resets mapReady on unmount', () => {
    mockOn.mockImplementation((event: string, cb: () => void) => {
      if (event === 'load') cb();
    });

    const { result, unmount } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    expect(result.current.mapReady).toBe(true);

    act(() => {
      unmount();
    });

    expect(mockRemove).toHaveBeenCalled();
  });

  it('nulls out mapRef after unmount', () => {
    const { result, unmount } = renderHook(() =>
      useFleetMapInit(makeContainerRef(), style),
    );

    act(() => {
      unmount();
    });

    expect(result.current.mapRef.current).toBeNull();
  });

  it('does not create a second map instance on re-render', () => {
    const container = document.createElement('div');

    const { rerender } = renderHook(
      () => useFleetMapInit({ current: container }, style),
      {},
    );

    rerender();

    expect(mapboxgl.Map).toHaveBeenCalledTimes(1);
  });
});
