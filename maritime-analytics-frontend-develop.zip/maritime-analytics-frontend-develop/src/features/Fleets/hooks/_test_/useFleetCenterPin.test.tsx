import { act, renderHook } from '@testing-library/react';
import mapboxgl from 'mapbox-gl';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useFleetCenterPin } from '@/features/Fleets/hooks/useFleetCenterPin';

const {
  mockFlyTo,
  mockMarkerRemove,
  mockSetLngLat,
  mockAddTo,
  mockMarkerInstance,
  mockHandleUnmount,
  mockHandleElement,
} = vi.hoisted(() => {
  const mockFlyTo = vi.fn();
  const mockMarkerRemove = vi.fn();
  const mockSetLngLat = vi.fn();
  const mockAddTo = vi.fn();
  const mockMarkerInstance = {
    setLngLat: mockSetLngLat,
    addTo: mockAddTo,
    remove: mockMarkerRemove,
  };
  mockSetLngLat.mockReturnValue(mockMarkerInstance);
  mockAddTo.mockReturnValue(mockMarkerInstance);

  return {
    mockFlyTo,
    mockMarkerRemove,
    mockSetLngLat,
    mockAddTo,
    mockMarkerInstance,
    mockHandleUnmount: vi.fn(),
    mockHandleElement: document.createElement('div'),
  };
});

vi.mock('mapbox-gl', () => ({
  default: {
    Marker: vi.fn().mockImplementation(function () {
      return mockMarkerInstance;
    }),
  },
}));

vi.mock('@/shared/hooks/useReactMarker', () => ({
  createReactMarkerElement: vi.fn().mockReturnValue({
    element: mockHandleElement,
    unmount: mockHandleUnmount,
    update: vi.fn(),
    root: {},
  }),
}));

describe('useFleetCenterPin', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSetLngLat.mockReturnValue(mockMarkerInstance);
    mockAddTo.mockReturnValue(mockMarkerInstance);
  });

  it('does not create a marker or fly the map when center is omitted', () => {
    const map = { flyTo: mockFlyTo } as unknown as mapboxgl.Map;

    renderHook(() => useFleetCenterPin({ current: map }, true, undefined, 8));

    expect(mockFlyTo).not.toHaveBeenCalled();
    expect(mapboxgl.Marker).not.toHaveBeenCalled();
  });

  it('flies to a viewport center without creating a pin when location center is missing', () => {
    const map = { flyTo: mockFlyTo } as unknown as mapboxgl.Map;
    const viewportCenter = { latitude: 56, longitude: -78 };

    renderHook(() =>
      useFleetCenterPin(
        { current: map },
        true,
        undefined,
        11,
        undefined,
        viewportCenter,
      ),
    );

    expect(mockFlyTo).toHaveBeenCalledWith({
      center: [-78, 56],
      zoom: 11,
      speed: 0.6,
    });
    expect(mapboxgl.Marker).not.toHaveBeenCalled();
  });

  it('flies to the supplied center and removes its marker on unmount', () => {
    const map = { flyTo: mockFlyTo } as unknown as mapboxgl.Map;
    const center = { latitude: 51.5, longitude: -0.1 };
    const { unmount } = renderHook(() =>
      useFleetCenterPin({ current: map }, true, center, 8, 'London'),
    );

    expect(mockFlyTo).toHaveBeenCalledWith({
      center: [-0.1, 51.5],
      zoom: 8,
      speed: 0.6,
    });
    expect(mockSetLngLat).toHaveBeenCalledWith([-0.1, 51.5]);

    act(() => unmount());

    expect(mockMarkerRemove).toHaveBeenCalledTimes(1);
    expect(mockHandleUnmount).toHaveBeenCalledTimes(1);
  });

  it('can fly to a viewport center while keeping the pin at the supplied center', () => {
    const map = { flyTo: mockFlyTo } as unknown as mapboxgl.Map;
    const locationCenter = { latitude: 10, longitude: 20 };
    const viewportCenter = { latitude: 56, longitude: -78 };

    renderHook(() =>
      useFleetCenterPin(
        { current: map },
        true,
        locationCenter,
        11,
        'Harbour',
        viewportCenter,
      ),
    );

    expect(mockFlyTo).toHaveBeenCalledWith({
      center: [-78, 56],
      zoom: 11,
      speed: 0.6,
    });
    expect(mockSetLngLat).toHaveBeenCalledWith([20, 10]);
  });
});
