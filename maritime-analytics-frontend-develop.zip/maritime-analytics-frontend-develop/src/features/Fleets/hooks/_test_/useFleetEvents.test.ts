import { act, renderHook, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useFleetEvents } from '@/features/Fleets/hooks/useFleetEvents';
import * as fleetEventService from '@/features/Fleets/services/fleetEventService';
import * as fleetService from '@/features/Fleets/services/fleetService';
import {
  FleetEventResponse,
  FleetEvents,
} from '@/features/Fleets/types/fleetEventTypes';
import type {
  VesselData,
  VesselsInAFleetResponse,
} from '@/features/Fleets/types/fleetTypes';

const { mockLoggerWarn, mockHandleApiError } = vi.hoisted(() => ({
  mockLoggerWarn: vi.fn(),
  mockHandleApiError: vi.fn(),
}));

vi.mock('@/features/Fleets/services/fleetEventService');
vi.mock('@/features/Fleets/services/fleetService', () => ({
  getVesselsInAFleet: vi.fn(),
}));
vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));
vi.mock('@/shared/utils/logger', () => ({
  logger: { warn: mockLoggerWarn },
}));

const tabs = [
  { label: 'Zone Entry', value: 'ZONE_ENTRY', groupings: 'Zone Events' },
];

function makeEvent(): FleetEvents {
  return {
    event_details: {
      event_id: 'event-1',
      draught: 500,
      heading: 180,
      event_type: 'ZONE_ENTRY',
      event_timestamp: '2026-01-01T00:00:00Z',
      course: 90,
      navigational_status: { status: 'Under way', code: '0' },
      reported_destination: 'Lagos',
      reported_eta: '2026-01-02T00:00:00Z',
      speed: 12,
      zone_port_event_location: { latitude: 6.45, longitude: 3.4 },
    },
    vessel_information: {
      asset_id: 'asset-1',
      callsign: 'CALL1',
      imo: 'IMO1',
      mmsi: 'MMSI1',
      name: 'Test Vessel',
      flag_code: 'NG',
      flag: 'Nigeria',
      vessel_type: 'Cargo',
    },
  };
}

function makeOngoingGapEvent(): FleetEvents {
  return {
    event_details: {
      event_id: 'gap-1',
      event_type: 'AIS_GAP',
      event_timestamp: '2026-01-03T00:00:00Z',
      gap_duration_hours: 'Ongoing',
      draught_change: undefined,
      gap_started: {
        course: 300.9,
        draught: 10,
        latitude: -21.38,
        longitude: -32.51,
        navigational_status: { status: 'Under way', code: '1' },
        speed: 2,
        gap_started_timestamp: '2026-01-01T00:00:00Z',
      },
      gap_ended: {},
    },
    vessel_information: {
      asset_id: 'asset-1',
      callsign: 'CALL1',
      imo: 'IMO1',
      mmsi: 'MMSI1',
      name: 'Test Vessel',
      flag_code: 'NG',
      flag: 'Nigeria',
      vessel_type: 'Cargo',
    },
  };
}

function makeResponse(events: FleetEvents[]): FleetEventResponse {
  return {
    meta: {
      request_id: 'request-1',
      request_timestamp: '2026-01-01T00:00:00Z',
      limit: 500,
      offset: 0,
      total_count: events.length,
    },
    data: { events },
  };
}

function makeVesselsResponse(
  data: VesselData[] = [],
  totalCount = data.length,
): VesselsInAFleetResponse {
  return {
    meta: {
      request_id: 'request-1',
      request_timestamp: '2026-01-01T00:00:00Z',
      limit: 500,
      offset: 0,
      total_count: totalCount,
    },
    data,
  };
}

function makeVessel(imo: string): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: `asset-${imo}`,
      callsign: 'CALL1',
      flag: 'Nigeria',
      flag_code: 'NG',
      imo,
      mmsi: '123456789',
      name: `Vessel ${imo}`,
      vessel_status: 'ACTIVE',
      vessel_type: 'Cargo',
      vessel_class: 'Class',
      build_year: 2000,
      age: 26,
      deadweight: 1000,
    },
    vessel_position: null,
  };
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise;
  });
  return { promise, resolve };
}

describe('useFleetEvents', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(fleetService.getVesselsInAFleet).mockResolvedValue(
      makeVesselsResponse(),
    );
  });

  it('loads all pages of fleet vessels for the slide-out', async () => {
    vi.mocked(fleetService.getVesselsInAFleet)
      .mockResolvedValueOnce(makeVesselsResponse([makeVessel('IMO-1')], 501))
      .mockResolvedValueOnce(makeVesselsResponse([makeVessel('IMO-2')], 501));

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));

    await waitFor(() => expect(result.current.vessels).toHaveLength(2));
    expect(fleetService.getVesselsInAFleet).toHaveBeenNthCalledWith(
      1,
      'fleet-1',
      500,
      0,
    );
    expect(fleetService.getVesselsInAFleet).toHaveBeenNthCalledWith(
      2,
      'fleet-1',
      500,
      500,
    );
  });

  it('loads rows from the events array in the response data', async () => {
    vi.mocked(fleetEventService.getFleetEvents).mockResolvedValue(
      makeResponse([makeEvent()]),
    );

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));

    await waitFor(() => expect(result.current.rows).toHaveLength(1));

    expect(result.current.rows[0]).toMatchObject({
      eventType: 'ZONE_ENTRY',
      vesselName: 'Test Vessel',
    });
  });

  it('keeps ongoing AIS gaps with empty end details as visible rows', async () => {
    vi.mocked(fleetEventService.getFleetEvents).mockResolvedValue(
      makeResponse([makeOngoingGapEvent()]),
    );

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));

    await waitFor(() => expect(result.current.rows).toHaveLength(1));

    expect(result.current.rows[0]).toMatchObject({
      eventType: 'AIS_GAP',
      eventTimestamp: '2026-01-03T00:00:00Z',
      duration: 'Ongoing',
      vesselName: 'Test Vessel',
    });
    expect(result.current.rows[0].navigationalStatusStatus).toBeUndefined();
    expect(mockLoggerWarn).not.toHaveBeenCalled();
  });

  it('keeps valid rows and logs metadata for an event that cannot be flattened', async () => {
    const malformedEvent = {
      event_details: {
        event_id: 'invalid-event',
        event_type: 'ZONE_ENTRY',
      },
      vessel_information: null,
    } as unknown as FleetEvents;
    vi.mocked(fleetEventService.getFleetEvents).mockResolvedValue(
      makeResponse([makeEvent(), malformedEvent]),
    );

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));

    await waitFor(() => expect(result.current.rows).toHaveLength(1));

    expect(result.current.rows[0].vesselName).toBe('Test Vessel');
    expect(mockLoggerWarn).toHaveBeenCalledWith(
      'Skipping fleet event that could not be flattened',
      expect.objectContaining({
        eventId: 'invalid-event',
        eventType: 'ZONE_ENTRY',
        error: expect.any(TypeError),
      }),
    );
  });

  it('only applies the response for the latest event filter selection', async () => {
    const firstRequest = deferred<FleetEventResponse>();
    const secondRequest = deferred<FleetEventResponse>();
    const latestRequest = deferred<FleetEventResponse>();
    vi.mocked(fleetEventService.getFleetEvents)
      .mockReturnValueOnce(firstRequest.promise)
      .mockReturnValueOnce(secondRequest.promise)
      .mockReturnValueOnce(latestRequest.promise);

    const selectionTabs = [
      ...tabs,
      { label: 'Zone Exit', value: 'ZONE_EXIT', groupings: 'Zone Events' },
      { label: 'AIS Gap', value: 'AIS_GAP', groupings: 'Other Events' },
    ];
    const { result } = renderHook(() =>
      useFleetEvents('fleet-1', selectionTabs),
    );

    await waitFor(() =>
      expect(fleetEventService.getFleetEvents).toHaveBeenCalledTimes(1),
    );
    act(() => result.current.onToggle('AIS_GAP', false));
    await waitFor(() =>
      expect(fleetEventService.getFleetEvents).toHaveBeenCalledTimes(2),
    );
    act(() => result.current.onToggle('ZONE_EXIT', false));
    await waitFor(() =>
      expect(fleetEventService.getFleetEvents).toHaveBeenCalledTimes(3),
    );
    expect(
      vi.mocked(fleetEventService.getFleetEvents).mock.calls[2][1],
    ).toEqual(['ZONE_ENTRY']);

    await act(async () => {
      latestRequest.resolve(makeResponse([makeEvent()]));
    });
    await waitFor(() => expect(result.current.rows).toHaveLength(1));
    expect(result.current.rows[0].eventType).toBe('ZONE_ENTRY');
    expect(result.current.isLoading).toBe(false);

    await act(async () => {
      secondRequest.resolve(makeResponse([makeOngoingGapEvent()]));
      firstRequest.resolve(makeResponse([]));
    });
    expect(result.current.rows).toHaveLength(1);
    expect(result.current.rows[0].eventType).toBe('ZONE_ENTRY');
  });

  it('invalidates pending requests when all event filters are cleared', async () => {
    const pendingRequest = deferred<FleetEventResponse>();
    vi.mocked(fleetEventService.getFleetEvents).mockReturnValueOnce(
      pendingRequest.promise,
    );

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));
    await waitFor(() =>
      expect(fleetEventService.getFleetEvents).toHaveBeenCalledTimes(1),
    );

    act(() => result.current.onToggle('ZONE_ENTRY', false));
    expect(result.current.rows).toEqual([]);
    expect(result.current.isLoading).toBe(false);

    await act(async () => {
      pendingRequest.resolve(makeResponse([makeEvent()]));
    });
    expect(result.current.rows).toEqual([]);
    expect(result.current.isLoading).toBe(false);
  });

  it('resets lastUpdated as soon as a manual refresh starts', async () => {
    let resolveRefresh: ((response: FleetEventResponse) => void) | undefined;
    vi.mocked(fleetEventService.getFleetEvents)
      .mockResolvedValueOnce(makeResponse([makeEvent()]))
      .mockImplementationOnce(
        () =>
          new Promise((resolve) => {
            resolveRefresh = resolve;
          }),
      );

    const { result } = renderHook(() => useFleetEvents('fleet-1', tabs));

    await waitFor(() => expect(result.current.rows).toHaveLength(1));
    const previousLastUpdated = result.current.lastUpdated;

    act(() => result.current.setRefresh(true));

    await waitFor(() =>
      expect(fleetEventService.getFleetEvents).toHaveBeenCalledTimes(2),
    );
    await waitFor(() =>
      expect(result.current.lastUpdated).not.toBe(previousLastUpdated),
    );

    act(() => resolveRefresh?.(makeResponse([makeEvent()])));
    await waitFor(() => expect(result.current.isLoading).toBe(false));
  });
});
