import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import { useFilters } from '@/features/Fleets/hooks/useFilters';
import * as filtersService from '@/features/Fleets/services/filtersService';
import * as fleetService from '@/features/Fleets/services/fleetService';
import {
  FiltersResponse,
  VesselData,
  VesselsInAFleetResponse,
} from '@/features/Fleets/types/fleetTypes';

let mockId: string | undefined = 'fleet-1';

vi.mock('react-router', () => ({
  useParams: () => ({ id: mockId }),
}));

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/Fleets/services/filtersService');
vi.mock('@/features/Fleets/services/fleetService');

function makeFiltersResponse(
  overrides: Partial<FiltersResponse> = {},
): FiltersResponse {
  return {
    vessel_class: [
      { vessel_type: 'Bulk carrier', classes: ['Handysize'] },
      { vessel_type: 'Oil Tanker', classes: ['VLCC'] },
    ],
    vessel_type: ['Bulk carrier', 'Oil Tanker'],
    flag_code: ['NOR', 'PAN'],
    mti_score: ['LOW', 'HIGH'],
    ...overrides,
  };
}

function makeVessel(imo = '1234567'): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo,
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
  };
}

function makeVesselsResponse(data: VesselData[]): VesselsInAFleetResponse {
  return {
    meta: {
      limit: 500,
      offset: 0,
      total_count: data.length,
      request_id: 'req-1',
      request_timestamp: '2026-01-01T00:00:00Z',
    },
    data,
  };
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise;
  });
  return { promise, resolve };
}

describe('useFilters', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
    mockId = 'fleet-1';
    (filtersService.getDynamicFilters as Mock).mockResolvedValue(
      makeFiltersResponse(),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([makeVessel()]),
    );
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('initialization', () => {
    it('does not fetch when id is undefined', async () => {
      mockId = undefined;

      renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).not.toHaveBeenCalled();
    });

    it('fetches initial filters and selects all values by default', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).toHaveBeenCalledWith('fleet-1');
      expect(result.current.flags).toEqual(['NOR', 'PAN']);
      expect(result.current.selectedFlags).toEqual({ NOR: true, PAN: true });
      expect(result.current.selectedVesselTypes).toEqual({
        'Bulk carrier': true,
        'Oil Tanker': true,
      });
      expect(result.current.selectedVesselClasses).toEqual({
        Handysize: true,
        VLCC: true,
      });
      expect(result.current.selectedMtiScores).toEqual({
        LOW: true,
        HIGH: true,
      });
    });

    it('fetches vessels for the fleet after loading filters', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledWith(
        'fleet-1',
        500,
        0,
        undefined,
        ['NOR', 'PAN'],
        ['Bulk carrier', 'Oil Tanker'],
        undefined,
        ['Handysize', 'VLCC'],
        ['LOW', 'HIGH'],
      );
      expect(result.current.vessels).toEqual([makeVessel()]);
    });

    it('toggles filtersLoading during the initial fetch', async () => {
      let resolveFilters: (value: FiltersResponse) => void;
      (filtersService.getDynamicFilters as Mock).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveFilters = resolve;
          }),
      );

      const { result } = renderHook(() => useFilters());

      expect(result.current.filtersLoading).toBe(true);

      await act(async () => {
        resolveFilters!(makeFiltersResponse());
        await vi.runAllTimersAsync();
      });

      expect(result.current.filtersLoading).toBe(false);
    });

    it('toggles vesselsLoading during vessel fetch', async () => {
      let resolveVessels: (value: VesselsInAFleetResponse) => void;
      (fleetService.getVesselsInAFleet as Mock).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveVessels = resolve;
          }),
      );

      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(result.current.vesselsLoading).toBe(true);

      await act(async () => {
        resolveVessels!(makeVesselsResponse([]));
        await vi.runAllTimersAsync();
      });

      expect(result.current.vesselsLoading).toBe(false);
    });

    it('calls the error handler when the initial filters fetch fails', async () => {
      const error = new Error('filters failed');
      (filtersService.getDynamicFilters as Mock).mockRejectedValue(error);

      renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
    });

    it('clears vessels and calls the error handler when the initial vessel fetch fails', async () => {
      const error = new Error('vessels failed');
      (fleetService.getVesselsInAFleet as Mock).mockRejectedValue(error);

      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
      expect(result.current.vessels).toEqual([]);
    });
  });

  describe('hasActiveFilters', () => {
    it('is false after initial load selects all values', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(result.current.hasActiveFilters).toBe(false);
      expect(result.current.filtersAppliedCount).toBe(0);
    });

    it('becomes active when a facet is partially selected', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      act(() => result.current.handleFlagToggle('NOR', false));

      expect(result.current.hasActiveFilters).toBe(true);
      expect(result.current.filtersAppliedCount).toBe(1);
    });
  });

  describe('handleFlagToggle', () => {
    it('updates selectedFlags immediately', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (filtersService.getDynamicFilters as Mock).mockClear();

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedFlags.NOR).toBe(false);
    });

    it('re-fetches vessels against the updated flag selection, without re-fetching filters', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (filtersService.getDynamicFilters as Mock).mockClear();
      (fleetService.getVesselsInAFleet as Mock).mockClear();

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).not.toHaveBeenCalled();
      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledWith(
        'fleet-1',
        500,
        0,
        undefined,
        ['PAN'],
        ['Bulk carrier', 'Oil Tanker'],
        undefined,
        ['Handysize', 'VLCC'],
        ['LOW', 'HIGH'],
      );
    });

    it('debounces the vessel refetch by 1000ms', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (fleetService.getVesselsInAFleet as Mock).mockClear();

      act(() => {
        result.current.handleFlagToggle('NOR', false);
      });

      await act(async () => {
        await vi.advanceTimersByTimeAsync(500);
      });
      expect(fleetService.getVesselsInAFleet).not.toHaveBeenCalled();

      await act(async () => {
        await vi.advanceTimersByTimeAsync(500);
      });
      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledTimes(1);
    });

    it('cancels a pending debounced fetch when toggled again quickly', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (fleetService.getVesselsInAFleet as Mock).mockClear();

      act(() => {
        result.current.handleFlagToggle('NOR', false);
      });
      await act(async () => {
        await vi.advanceTimersByTimeAsync(500);
      });

      act(() => {
        result.current.handleFlagToggle('NOR', true);
      });
      await act(async () => {
        await vi.advanceTimersByTimeAsync(1000);
      });

      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledTimes(1);
    });

    it('calls the error handler when the debounced vessel refetch fails', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      const error = new Error('vessel refetch failed');
      (fleetService.getVesselsInAFleet as Mock).mockRejectedValue(error);

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
    });
  });

  describe('handleVesselTypeToggle', () => {
    it('re-scopes class options locally and selects every class for selected types', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselTypeToggle('Bulk carrier', false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselTypes['Bulk carrier']).toBe(false);
      expect(result.current.vesselClassGroups).toEqual([
        { vessel_type: 'Oil Tanker', classes: ['VLCC'] },
      ]);
      expect(result.current.selectedVesselClasses).toEqual({ VLCC: true });
      expect(filtersService.getDynamicFilters).toHaveBeenCalledTimes(1);
    });

    it('clears class options and selections when no vessel types remain selected', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      act(() => result.current.handleVesselTypeSelectAll(false));

      expect(result.current.vesselClassGroups).toEqual([]);
      expect(result.current.selectedVesselClasses).toEqual({});
      expect(filtersService.getDynamicFilters).toHaveBeenCalledTimes(1);
    });
  });

  describe('handleVesselClassToggle', () => {
    it('updates selectedVesselClasses', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselClassToggle('Handysize', false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselClasses.Handysize).toBe(false);
    });
  });

  describe('handleMtiScoreToggle', () => {
    it('updates selectedMtiScores and includes them in vessel requests', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleMtiScoreToggle('LOW', false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedMtiScores.LOW).toBe(false);
      expect(fleetService.getVesselsInAFleet).toHaveBeenLastCalledWith(
        'fleet-1',
        500,
        0,
        undefined,
        ['NOR', 'PAN'],
        ['Bulk carrier', 'Oil Tanker'],
        undefined,
        ['Handysize', 'VLCC'],
        ['HIGH'],
      );
    });
  });

  describe('select all handlers', () => {
    it('handleFlagSelectAll(false) deselects all flags', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagSelectAll(false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedFlags).toEqual({ NOR: false, PAN: false });
    });

    it('handleVesselTypeSelectAll(false) deselects all vessel types', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselTypeSelectAll(false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselTypes).toEqual({
        'Bulk carrier': false,
        'Oil Tanker': false,
      });
      expect(result.current.vesselClassGroups).toEqual([]);
      expect(result.current.selectedVesselClasses).toEqual({});
    });

    it('handleVesselClassSelectAll(false) deselects all vessel classes', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselClassSelectAll(false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselClasses).toEqual({
        Handysize: false,
        VLCC: false,
      });
    });

    it('handleMtiScoreSelectAll(false) deselects all mti scores', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleMtiScoreSelectAll(false);
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedMtiScores).toEqual({
        LOW: false,
        HIGH: false,
      });
    });
  });

  describe('resetFilters', () => {
    it('re-selects cached values and refetches vessels without re-fetching filters', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
      });

      (fleetService.getVesselsInAFleet as Mock).mockClear();
      (filtersService.getDynamicFilters as Mock).mockClear();

      await act(async () => {
        await result.current.resetFilters();
        await vi.advanceTimersByTimeAsync(1000);
      });

      expect(result.current.selectedFlags).toEqual({ NOR: true, PAN: true });
      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledTimes(1);
      expect(filtersService.getDynamicFilters).not.toHaveBeenCalled();
    });
  });

  describe('refresh', () => {
    it('re-fetches vessels with the currently active selection', async () => {
      const { result } = renderHook(() => useFilters());

      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (fleetService.getVesselsInAFleet as Mock).mockClear();

      await act(async () => {
        await result.current.refresh();
      });

      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledWith(
        'fleet-1',
        500,
        0,
        undefined,
        ['NOR', 'PAN'],
        ['Bulk carrier', 'Oil Tanker'],
        undefined,
        ['Handysize', 'VLCC'],
        ['LOW', 'HIGH'],
      );
    });
  });

  it('ignores a vessel response for an older filter selection', async () => {
    const olderResponse = deferred<VesselsInAFleetResponse>();
    const latestResponse = deferred<VesselsInAFleetResponse>();
    const { result } = renderHook(() => useFilters());

    await act(async () => {
      await vi.runAllTimersAsync();
    });
    await act(async () => {
      await vi.runAllTimersAsync();
    });

    (fleetService.getVesselsInAFleet as Mock)
      .mockImplementationOnce(() => olderResponse.promise)
      .mockImplementationOnce(() => latestResponse.promise);

    act(() => result.current.handleFlagToggle('NOR', false));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(1000);
    });
    act(() => result.current.handleFlagToggle('NOR', true));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(1000);
    });

    await act(async () => {
      latestResponse.resolve(makeVesselsResponse([makeVessel('latest')]));
    });
    expect(result.current.vessels).toEqual([makeVessel('latest')]);

    await act(async () => {
      olderResponse.resolve(makeVesselsResponse([makeVessel('stale')]));
    });
    expect(result.current.vessels).toEqual([makeVessel('latest')]);
  });
});
