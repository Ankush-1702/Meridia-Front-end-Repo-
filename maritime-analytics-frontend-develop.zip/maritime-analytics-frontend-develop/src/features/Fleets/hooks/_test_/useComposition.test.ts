import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import { useComposition } from '@/features/Fleets/hooks/useComposition';
import * as filtersService from '@/features/Fleets/services/filtersService';
import * as fleetCompositionService from '@/features/Fleets/services/fleetCompositionService';
import * as fleetService from '@/features/Fleets/services/fleetService';
import {
  FiltersResponse,
  FleetCompositionResponse,
  VesselData,
  VesselsInAFleetResponse,
} from '@/features/Fleets/types/fleetTypes';

let mockId: string | undefined = 'fleet-1';

vi.mock('react-router', () => ({
  useParams: () => ({ id: mockId }),
}));

const mockHandleApiError = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/Fleets/services/filtersService');
vi.mock('@/features/Fleets/services/fleetCompositionService');
vi.mock('@/features/Fleets/services/fleetService');

function makeFiltersResponse(
  overrides: Partial<FiltersResponse> = {},
): FiltersResponse {
  return {
    vessel_class: [
      { vessel_type: 'Bulk carrier', classes: ['Handysize'] },
      { vessel_type: 'Oil Tanker', classes: ['VLCC'] },
    ],
    vessel_type: ['Bulk carrier', 'Oil Tanker'],
    flag_code: ['NOR', 'PAN'],
    mti_score: ['LOW', 'HIGH'],
    ...overrides,
  };
}

function makeCompositionResponse(
  overrides: Partial<FleetCompositionResponse> = {},
): FleetCompositionResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    fleet_information: {
      fleet_id: 'fleet-1',
      name: 'Test Fleet',
      vessel_count: 1,
    },
    data: {
      summary: {
        vessels: { filtered_count: 1 },
        average_age: { unit: 'years', value: 10 },
        total_dwt: { unit: 'MT', value: 5000, vessels_with_data: 1 },
        flag_states_count: 1,
      },
      type_and_class: {
        vessel_type: [{ label: 'Bulk carrier', count: 1, percentage: 100 }],
        vessel_class: [{ label: 'Handysize', count: 1, percentage: 100 }],
      },
      registration_and_flag: {
        port_of_registry: { total_categories: 1, items: [] },
        vessel_flag: { total_categories: 1, items: [] },
      },
      build_and_origin: {
        country_of_build: { total_categories: 1, items: [] },
        builder: { total_categories: 1, items: [] },
        age_profile: [],
      },
      size_and_dimensions: {
        size: {
          deadweight_tonnage: { vessels_with_data: 1, unit: 'MT', items: [] },
          gross_tonnage: { vessels_with_data: 1, unit: 'MT', items: [] },
        },
        dimensions: {
          length_overall: { unit: 'm', vessels_with_data: 1, items: [] },
          beam: { unit: 'm', vessels_with_data: 1, items: [] },
          draught: { unit: 'm', vessels_with_data: 1, items: [] },
        },
      },
    },
    ...overrides,
  };
}

function makeVessel(imo = '1234567'): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo,
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
  };
}

function makeVesselsResponse(data: VesselData[]): VesselsInAFleetResponse {
  return {
    meta: {
      limit: 500,
      offset: 0,
      total_count: data.length,
      request_id: 'req-1',
      request_timestamp: '2026-01-01T00:00:00Z',
    },
    data,
  };
}

describe('useComposition', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
    mockId = 'fleet-1';
    (filtersService.getDynamicFilters as Mock).mockResolvedValue(
      makeFiltersResponse(),
    );
    (fleetCompositionService.getFleetComposition as Mock).mockResolvedValue(
      makeCompositionResponse(),
    );
    (fleetService.getVesselsInAFleet as Mock).mockResolvedValue(
      makeVesselsResponse([makeVessel()]),
    );
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('initialization', () => {
    it('does not fetch filters when id is undefined', async () => {
      mockId = undefined;

      renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).not.toHaveBeenCalled();
    });

    it('fetches filters on mount and selects all values by default', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).toHaveBeenCalledWith('fleet-1');
      expect(result.current.flags).toEqual(['NOR', 'PAN']);
      expect(result.current.vesselTypes).toEqual([
        'Bulk carrier',
        'Oil Tanker',
      ]);
      expect(result.current.selectedFlags).toEqual({ NOR: true, PAN: true });
      expect(result.current.selectedVesselTypes).toEqual({
        'Bulk carrier': true,
        'Oil Tanker': true,
      });
      expect(result.current.selectedVesselClasses).toEqual({
        Handysize: true,
        VLCC: true,
      });
    });

    it('fetches composition and vessels once filters are ready (after debounce)', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(fleetCompositionService.getFleetComposition).toHaveBeenCalledWith(
        'fleet-1',
        ['NOR', 'PAN'],
        ['Bulk carrier', 'Oil Tanker'],
        ['Handysize', 'VLCC'],
      );
      expect(fleetService.getVesselsInAFleet).toHaveBeenCalled();
      expect(result.current.composition).toEqual(makeCompositionResponse());
      expect(result.current.vessels).toEqual([makeVessel()]);
      expect(result.current.loading).toBe(false);
    });

    it('paginates through vessels using the vessels limit until total_count is exhausted', async () => {
      const page1 = makeVesselsResponse([makeVessel('1111111')]);
      page1.meta.total_count = 600;
      const page2 = makeVesselsResponse([makeVessel('2222222')]);
      page2.meta.total_count = 600;
      (fleetService.getVesselsInAFleet as Mock)
        .mockResolvedValueOnce(page1)
        .mockResolvedValueOnce(page2);

      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(fleetService.getVesselsInAFleet).toHaveBeenCalledTimes(2);
      expect(result.current.vessels).toEqual([
        makeVessel('1111111'),
        makeVessel('2222222'),
      ]);
    });

    it('calls the error handler and clears composition when the filters fetch fails', async () => {
      const error = new Error('filters failed');
      (filtersService.getDynamicFilters as Mock).mockRejectedValue(error);

      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
      // Filters failing leaves selectedFlags/selectedVesselTypes empty, so although
      // filtersReady still flips and the debounced effect runs, fetchComposition's
      // empty-selection guard skips the API call and keeps composition null.
      expect(result.current.composition).toBeNull();
    });

    it('calls the error handler and clears composition when the composition fetch fails', async () => {
      const error = new Error('composition failed');
      (fleetCompositionService.getFleetComposition as Mock).mockRejectedValue(
        error,
      );

      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
      expect(result.current.composition).toBeNull();
    });

    it('calls the error handler when the vessels fetch fails', async () => {
      const error = new Error('vessels failed');
      (fleetService.getVesselsInAFleet as Mock).mockRejectedValue(error);

      renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
    });

    it('toggles loading true during the filters/composition fetch cycle', async () => {
      let resolveFilters: (value: FiltersResponse) => void;
      (filtersService.getDynamicFilters as Mock).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveFilters = resolve;
          }),
      );

      const { result } = renderHook(() => useComposition());

      expect(result.current.loading).toBe(true);

      await act(async () => {
        resolveFilters!(makeFiltersResponse());
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(result.current.loading).toBe(false);
    });
  });

  describe('handleVesselTypeToggle', () => {
    it('updates selectedVesselTypes and re-scopes vessel classes to the new selection', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      (filtersService.getDynamicFilters as Mock).mockClear();
      (filtersService.getDynamicFilters as Mock).mockResolvedValue({
        vessel_class: [{ vessel_type: 'Bulk carrier', classes: ['Handysize'] }],
        vessel_type: ['Bulk carrier'],
        flag_code: [],
        mti_score: [],
      });

      await act(async () => {
        result.current.handleVesselTypeToggle('Oil Tanker', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselTypes['Oil Tanker']).toBe(false);
      expect(filtersService.getDynamicFilters).toHaveBeenCalledWith('fleet-1', [
        'Bulk carrier',
      ]);
      expect(result.current.selectedVesselClasses).toEqual({
        Handysize: true,
      });
    });

    it('clears vessel classes when no vessel types remain selected', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselTypeToggle('Bulk carrier', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        result.current.handleVesselTypeToggle('Oil Tanker', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.vesselClassGroups).toEqual([]);
      expect(result.current.selectedVesselClasses).toEqual({});
    });

    it('calls the error handler when re-scoping vessel classes fails', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      const error = new Error('class groups failed');
      (filtersService.getDynamicFilters as Mock).mockRejectedValue(error);

      await act(async () => {
        result.current.handleVesselTypeToggle('Oil Tanker', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(error);
    });
  });

  describe('handleFlagToggle / handleVesselClassToggle', () => {
    it('updates selectedFlags', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedFlags.NOR).toBe(false);
      expect(result.current.activeFlags).toEqual(['PAN']);
    });

    it('updates selectedVesselClasses', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselClassToggle('Handysize', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselClasses.Handysize).toBe(false);
      expect(result.current.activeVesselClasses).toEqual(['VLCC']);
    });
  });

  describe('select all handlers', () => {
    it('handleFlagSelectAll(false) deselects all flags', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagSelectAll(false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedFlags).toEqual({ NOR: false, PAN: false });
    });

    it('handleVesselTypeSelectAll(false) deselects vessel types and clears vessel classes', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselTypeSelectAll(false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselTypes).toEqual({
        'Bulk carrier': false,
        'Oil Tanker': false,
      });
      expect(result.current.vesselClassGroups).toEqual([]);
    });

    it('handleVesselClassSelectAll(false) deselects all vessel classes', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleVesselClassSelectAll(false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedVesselClasses).toEqual({
        Handysize: false,
        VLCC: false,
      });
    });
  });

  describe('hasActiveFilters', () => {
    it('is false right after the initial load selects everything', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      expect(result.current.hasActiveFilters).toBe(false);
    });

    it('becomes true after a filter is deselected', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(result.current.hasActiveFilters).toBe(true);
    });
  });

  describe('resetFilters', () => {
    it('re-fetches filters and re-selects all values', async () => {
      const { result } = renderHook(() => useComposition());

      await act(async () => {
        await vi.runAllTimersAsync();
      });
      await act(async () => {
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        result.current.handleFlagToggle('NOR', false);
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      (filtersService.getDynamicFilters as Mock).mockClear();

      await act(async () => {
        result.current.resetFilters();
        await vi.runAllTimersAsync();
        await vi.runAllTimersAsync();
      });

      expect(filtersService.getDynamicFilters).toHaveBeenCalledWith('fleet-1');
      expect(result.current.selectedFlags).toEqual({ NOR: true, PAN: true });
    });
  });
});
