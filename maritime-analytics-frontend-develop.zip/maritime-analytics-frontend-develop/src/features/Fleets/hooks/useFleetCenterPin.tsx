import mapboxgl from 'mapbox-gl';
import { useEffect } from 'react';
import PortPinIcon from '@/shared/components/PortPinIcon';
import {
  createReactMarkerElement,
  type ReactMarkerHandle,
} from '@/shared/hooks/useReactMarker';
import type { OverviewMapCenter } from '@/shared/types/OverviewMapTypes';

export function useFleetCenterPin(
  mapRef: React.RefObject<mapboxgl.Map | null>,
  mapReady: boolean,
  center: OverviewMapCenter | undefined,
  zoom: number,
  label?: string,
  viewportCenter?: OverviewMapCenter,
) {
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    const targetCenter = viewportCenter ?? center;
    if (targetCenter) {
      map.flyTo({
        center: [targetCenter.longitude, targetCenter.latitude],
        zoom,
        speed: 0.6,
      });
    }

    if (!center) return;

    const handle: ReactMarkerHandle = createReactMarkerElement(
      <PortPinIcon label={label ?? ''} />,
    );
    const marker = new mapboxgl.Marker({ element: handle.element })
      .setLngLat([center.longitude, center.latitude])
      .addTo(map);

    return () => {
      marker.remove();
      handle.unmount();
    };
  }, [center, label, mapReady, mapRef, viewportCenter, zoom]);
}
