import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatFleetEventsResponse,
  ZoneInformation,
} from '../types/fleetEventTypes';
import { VesselData } from '../types/fleetTypes';
import { getLivePortCongestionData } from '@/features/Ports/services/portCongestionApi';
import {
  fetchZoneBoundary,
  fetchZoneDetails,
} from '@/features/Zones/services/zoneServices';
import { getLiveZoneTrafficData } from '@/features/Zones/services/zoneTrafficApi';
import { getOverviewDataStream } from '@/shared/services/overview/overviewService';
import { ILiveDataResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { logger } from '@/shared/utils/logger';
import { decryptGeometry } from '@/shared/utils/overviewMapUtils';

export function useFleetEventSlideOut(
  currentRow?: FlatFleetEventsResponse,
  setSelectedRow?: (row?: FlatFleetEventsResponse) => void,
  vessels: VesselData[] = [],
) {
  const [drilldown, setDrilldown] = useState<{
    row?: FlatFleetEventsResponse;
    view: 'vessel' | 'location' | 'pairedVessel' | null;
  }>({ row: currentRow, view: null });
  const isCurrentDrilldown = drilldown.row === currentRow;
  const viewVessel = isCurrentDrilldown && drilldown.view === 'vessel';
  const viewLocation = isCurrentDrilldown && drilldown.view === 'location';
  const viewPairedVessel =
    isCurrentDrilldown && drilldown.view === 'pairedVessel';
  const setViewVessel = useCallback(
    (show: boolean) =>
      setDrilldown({ row: currentRow, view: show ? 'vessel' : null }),
    [currentRow],
  );
  const setViewLocation = useCallback(
    (show: boolean) =>
      setDrilldown({ row: currentRow, view: show ? 'location' : null }),
    [currentRow],
  );
  const setViewPairedVessel = useCallback(
    (show: boolean) =>
      setDrilldown({ row: currentRow, view: show ? 'pairedVessel' : null }),
    [currentRow],
  );
  const isOpen = currentRow !== undefined;
  const slideOutModalRef = useRef<HTMLDivElement>(null);
  const pairedVessel = useMemo(
    () => currentRow?.pairedVesselData,
    [currentRow],
  );
  const vessel = useMemo(
    () =>
      currentRow?.imo
        ? vessels.find((item) => item.vessel_information.imo === currentRow.imo)
        : undefined,
    [currentRow, vessels],
  );
  const location = useMemo<ZoneInformation | undefined>(() => {
    if (!currentRow?.zoneId) return undefined;
    return {
      centroid: {
        latitude: currentRow.centrePointLat ?? 0,
        longitude: currentRow.centrePointLng ?? 0,
      },
      country_official_name: currentRow.countryOfficialName ?? '',
      country_code: currentRow.countryFlag ?? '',
      description: undefined,
      id: currentRow.zoneId,
      name: currentRow.zoneName ?? '',
      sub_type: currentRow.zoneSubType ?? '',
      type: currentRow.zoneType ?? '',
      unlocode: currentRow.unlocode,
      country_common_name: currentRow.country ?? '',
      sub_division_code: undefined,
      sub_division_name: undefined,
      wpi_number: undefined,
    };
  }, [currentRow]);
  const [locationEvents, setLocationEvents] = useState<
    ILiveDataResponse | undefined
  >(undefined);

  const [zoneBoundary, setZoneBoundary] = useState<string | undefined>(
    undefined,
  );

  const [vesselInPortOrZone, setVesselInPortOrZone] = useState<number>(0);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const detailsRequestIdRef = useRef(0);

  useEffect(() => {
    setDrilldown({ row: currentRow, view: null });
  }, [currentRow]);

  const getZoneBoundary = useCallback(async (): Promise<string | undefined> => {
    if (!currentRow || !currentRow.zoneId) {
      return undefined;
    }
    try {
      if (currentRow.zoneType === 'Custom') {
        const res = await fetchZoneDetails(currentRow.zoneId);
        return res.geometry;
      } else {
        const res = await fetchZoneBoundary(currentRow.zoneId);
        return decryptGeometry(res.geometry);
      }
    } catch {
      return undefined;
    }
  }, [currentRow]);

  const fetchLocationEvents = useCallback(async (): Promise<
    ILiveDataResponse | undefined
  > => {
    if (!currentRow || !currentRow.zoneId) {
      return undefined;
    }
    if (
      currentRow.eventType !== 'PORT_AREA_ARRIVAL' &&
      currentRow.eventType !== 'PORT_AREA_DEPARTURE' &&
      currentRow.eventType !== 'PORT_ARRIVAL' &&
      currentRow.eventType !== 'PORT_DEPARTURE' &&
      currentRow.eventType !== 'ZONE_ENTRY' &&
      currentRow.eventType !== 'ZONE_EXIT'
    ) {
      return undefined;
    }
    try {
      if (
        currentRow.eventType === 'ZONE_ENTRY' ||
        currentRow.eventType === 'ZONE_EXIT'
      ) {
        return await getLiveZoneTrafficData(currentRow.zoneId);
      }
      return await getLivePortCongestionData(currentRow.zoneId);
    } catch {
      return undefined;
    }
  }, [currentRow]);

  const fetchVesselsInPortsOrZones = useCallback(async (): Promise<number> => {
    if (!currentRow || !currentRow.zoneId) {
      return 0;
    }

    const eventType = currentRow.eventType;
    const entityType =
      eventType === 'PORT_AREA_ARRIVAL' ||
      eventType === 'PORT_AREA_DEPARTURE' ||
      eventType === 'PORT_ARRIVAL' ||
      eventType === 'PORT_DEPARTURE'
        ? 'port'
        : eventType === 'ZONE_ENTRY' || eventType === 'ZONE_EXIT'
          ? 'zone'
          : undefined;

    if (!entityType) {
      return 0;
    }

    try {
      for await (const { progress } of getOverviewDataStream({
        entity: { type: entityType, id: currentRow.zoneId },
      })) {
        // The first result has the API's total count; remaining pages are not needed.
        return progress.totalVessels;
      }
      return 0;
    } catch {
      return 0;
    }
  }, [currentRow]);

  useEffect(() => {
    let cancelled = false;
    const requestId = ++detailsRequestIdRef.current;
    const isLatestRequest = () =>
      !cancelled && requestId === detailsRequestIdRef.current;
    const labels = [
      'getZoneBoundary',
      'fetchLocationEvents',
      'fetchVesselsInPortsOrZones',
    ];

    setZoneBoundary(undefined);
    setLocationEvents(undefined);
    setVesselInPortOrZone(0);

    const run = async () => {
      setIsLoading(true);

      const results = await Promise.allSettled([
        getZoneBoundary(),
        fetchLocationEvents(),
        fetchVesselsInPortsOrZones(),
      ]);

      if (!isLatestRequest()) return;

      const [boundaryResult, eventsResult, vesselCountResult] = results;
      setZoneBoundary(
        boundaryResult.status === 'fulfilled'
          ? boundaryResult.value
          : undefined,
      );
      setLocationEvents(
        eventsResult.status === 'fulfilled' ? eventsResult.value : undefined,
      );
      setVesselInPortOrZone(
        vesselCountResult.status === 'fulfilled' ? vesselCountResult.value : 0,
      );

      setIsLoading(false);
      results.forEach((r, i) => {
        if (r.status === 'rejected') {
          logger.error(`${labels[i]} failed:`, r.reason);
        }
      });
    };

    void run();

    return () => {
      cancelled = true;
    };
  }, [
    currentRow,
    fetchLocationEvents,
    fetchVesselsInPortsOrZones,
    getZoneBoundary,
  ]);

  const handleBackClick = () => {
    setDrilldown({ row: currentRow, view: null });
  };

  const handleClose = () => {
    setDrilldown({ row: currentRow, view: null });
    detailsRequestIdRef.current += 1;
    setSelectedRow?.(undefined);
    setLocationEvents(undefined);
    setZoneBoundary(undefined);
    setVesselInPortOrZone(0);
    setIsLoading(false);
  };

  return {
    viewVessel,
    setViewVessel,
    viewLocation,
    setViewLocation,
    viewPairedVessel,
    setViewPairedVessel,
    isOpen,
    slideOutModalRef,
    handleBackClick,
    handleClose,
    pairedVessel,
    vessel,
    location,
    locationEvents,
    zoneBoundary,
    vesselInPortOrZone,
    isLoading,
  };
}
