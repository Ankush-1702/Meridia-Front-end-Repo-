import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router';
import { getDynamicFilters } from '../services/filtersService';
import { getVesselsInAFleet } from '../services/fleetService';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  VesselClassGroup,
  VesselData,
} from '@/features/Fleets/types/fleetTypes';
import { useDebouncedEffect } from '@/shared/hooks/useDebouncedEffect';

interface ActiveSelection {
  flags: string[];
  vesselTypes: string[];
  vesselClasses: string[];
  mtiScores: string[];
}

const DEBOUNCE_MS = 1000;
const VESSELS_LIMIT = 500;

type SelectionMap = Record<string, boolean>;

interface FiltersState {
  selectedFlags: SelectionMap;
  selectedVesselTypes: SelectionMap;
  selectedVesselClasses: SelectionMap;
  selectedMtiScores: SelectionMap;
}

const getSelected = (record: SelectionMap): string[] =>
  Object.entries(record)
    .filter(([, v]) => v)
    .map(([k]) => k);

const selectAll = (values: string[] | undefined): SelectionMap =>
  Object.fromEntries((values || []).map((v) => [v, true]));

const isFullySelected = (
  values: string[] | undefined,
  selected: SelectionMap,
): boolean => (values ?? []).every((value) => !!selected[value]);

const flattenClasses = (groups: VesselClassGroup[] | undefined): string[] =>
  (groups || []).flatMap((g) => g.classes);

const hasSameSelection = (
  first: ActiveSelection,
  second: ActiveSelection,
): boolean => {
  const areEqual = (a: string[], b: string[]) =>
    a.length === b.length && a.every((value, index) => value === b[index]);
  return (
    areEqual(first.flags, second.flags) &&
    areEqual(first.vesselTypes, second.vesselTypes) &&
    areEqual(first.vesselClasses, second.vesselClasses) &&
    areEqual(first.mtiScores, second.mtiScores)
  );
};

export function useFilters() {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();

  const [flags, setFlags] = useState<string[] | undefined>(undefined);
  const [vesselTypes, setVesselTypes] = useState<string[] | undefined>(
    undefined,
  );
  const [allVesselClassGroups, setAllVesselClassGroups] = useState<
    VesselClassGroup[] | undefined
  >(undefined);
  const [mtiScores, setMtiScores] = useState<string[] | undefined>(undefined);

  const [selectedFlags, setSelectedFlags] = useState<SelectionMap>({});
  const [selectedVesselTypes, setSelectedVesselTypes] = useState<SelectionMap>(
    {},
  );
  const [selectedVesselClasses, setSelectedVesselClasses] =
    useState<SelectionMap>({});
  const [selectedMtiScores, setSelectedMtiScores] = useState<SelectionMap>({});

  const [vessels, setVessels] = useState<VesselData[]>([]);
  const [filtersLoading, setFiltersLoading] = useState<boolean>(false);
  const [vesselsLoading, setVesselsLoading] = useState<boolean>(false);
  const [filtersReady, setFiltersReady] = useState(false);

  const filtersRef = useRef<FiltersState>({
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    selectedMtiScores,
  });
  filtersRef.current = {
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    selectedMtiScores,
  };

  const activeFlags = useMemo(
    () => getSelected(selectedFlags),
    [selectedFlags],
  );
  const activeVesselTypes = useMemo(
    () => getSelected(selectedVesselTypes),
    [selectedVesselTypes],
  );
  const activeVesselClasses = useMemo(
    () => getSelected(selectedVesselClasses),
    [selectedVesselClasses],
  );
  const activeMtiScores = useMemo(
    () => getSelected(selectedMtiScores),
    [selectedMtiScores],
  );
  const vesselClassGroups = useMemo(() => {
    if (!allVesselClassGroups) return undefined;
    const activeTypes = new Set(activeVesselTypes);
    return allVesselClassGroups.filter((group) =>
      activeTypes.has(group.vessel_type),
    );
  }, [allVesselClassGroups, activeVesselTypes]);

  const vesselRequestIdRef = useRef(0);

  const currentActive = useCallback(
    (): ActiveSelection => ({
      flags: getSelected(filtersRef.current.selectedFlags),
      vesselTypes: getSelected(filtersRef.current.selectedVesselTypes),
      vesselClasses: getSelected(filtersRef.current.selectedVesselClasses),
      mtiScores: getSelected(filtersRef.current.selectedMtiScores),
    }),
    [],
  );

  const fetchVessels = useCallback(
    async (active: ActiveSelection) => {
      if (!id) return;
      const requestId = ++vesselRequestIdRef.current;
      const isCurrentRequest = () =>
        requestId === vesselRequestIdRef.current &&
        hasSameSelection(active, currentActive());
      setVesselsLoading(true);
      try {
        let offset = 0;
        let totalCount = Infinity;
        let allVessels: VesselData[] = [];
        if (
          active.flags.length === 0 ||
          active.vesselTypes.length === 0 ||
          active.vesselClasses.length === 0 ||
          // MTI is optional: no available score options means no MTI constraint.
          ((mtiScores?.length ?? 0) > 0 && active.mtiScores.length === 0)
        ) {
          setVessels([]);
          return;
        }
        while (offset < totalCount) {
          const response = await getVesselsInAFleet(
            id,
            VESSELS_LIMIT,
            offset,
            undefined,
            active.flags,
            active.vesselTypes,
            undefined,
            active.vesselClasses,
            active.mtiScores,
          );
          if (!isCurrentRequest()) return;
          allVessels = allVessels.concat(response.data);
          totalCount = response.meta.total_count;
          offset += VESSELS_LIMIT;
        }
        if (isCurrentRequest()) setVessels(allVessels);
      } catch (e) {
        if (!isCurrentRequest()) return;
        handleApiError(e);
        setVessels([]);
      } finally {
        if (isCurrentRequest()) setVesselsLoading(false);
      }
    },
    [id, handleApiError, mtiScores, currentActive],
  );

  const fetchInitialFilters = useCallback(async () => {
    if (!id) return;
    setFiltersReady(false);
    setFiltersLoading(true);
    try {
      const response = await getDynamicFilters(id);
      setFlags(response.flag_code);
      setVesselTypes(response.vessel_type);
      setAllVesselClassGroups(response.vessel_class);
      setMtiScores(response.mti_score);

      const allFlags = selectAll(response.flag_code);
      const allVesselTypes = selectAll(response.vessel_type);
      const allVesselClasses = selectAll(flattenClasses(response.vessel_class));
      const allMtiScores = selectAll(response.mti_score);

      setSelectedFlags(allFlags);
      setSelectedVesselTypes(allVesselTypes);
      setSelectedVesselClasses(allVesselClasses);
      setSelectedMtiScores(allMtiScores);
      filtersRef.current = {
        selectedFlags: allFlags,
        selectedVesselTypes: allVesselTypes,
        selectedVesselClasses: allVesselClasses,
        selectedMtiScores: allMtiScores,
      };
    } catch (e) {
      handleApiError(e);
    } finally {
      setFiltersLoading(false);
      setFiltersReady(true);
    }
  }, [id, handleApiError]);

  useEffect(() => {
    void fetchInitialFilters();
  }, [fetchInitialFilters]);

  const selectClassesForVesselTypes = useCallback(
    (types: string[]) => {
      const scopedGroups = (allVesselClassGroups ?? []).filter((group) =>
        types.includes(group.vessel_type),
      );
      const updated = selectAll(flattenClasses(scopedGroups));
      setSelectedVesselClasses(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedVesselClasses: updated,
      };
    },
    [allVesselClassGroups],
  );

  const handleFlagToggle = useCallback((value: string, checked: boolean) => {
    const updated = {
      ...filtersRef.current.selectedFlags,
      [value]: checked,
    };
    setSelectedFlags(updated);
    filtersRef.current = { ...filtersRef.current, selectedFlags: updated };
  }, []);

  const handleVesselTypeToggle = useCallback(
    (value: string, checked: boolean) => {
      const updated = {
        ...filtersRef.current.selectedVesselTypes,
        [value]: checked,
      };
      setSelectedVesselTypes(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedVesselTypes: updated,
      };
      selectClassesForVesselTypes(getSelected(updated));
    },
    [selectClassesForVesselTypes],
  );

  const handleVesselClassToggle = useCallback(
    (value: string, checked: boolean) => {
      const updated = {
        ...filtersRef.current.selectedVesselClasses,
        [value]: checked,
      };
      setSelectedVesselClasses(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedVesselClasses: updated,
      };
    },
    [],
  );

  const handleMtiScoreToggle = useCallback(
    (value: string, checked: boolean) => {
      const updated = {
        ...filtersRef.current.selectedMtiScores,
        [value]: checked,
      };
      setSelectedMtiScores(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedMtiScores: updated,
      };
    },
    [],
  );

  const handleFlagSelectAll = useCallback(
    (checked: boolean) => {
      const updated = Object.fromEntries(
        (flags || []).map((v) => [v, checked]),
      );
      setSelectedFlags(updated);
      filtersRef.current = { ...filtersRef.current, selectedFlags: updated };
    },
    [flags],
  );

  const handleVesselTypeSelectAll = useCallback(
    (checked: boolean) => {
      const updated = Object.fromEntries(
        (vesselTypes || []).map((v) => [v, checked]),
      );
      setSelectedVesselTypes(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedVesselTypes: updated,
      };
      selectClassesForVesselTypes(getSelected(updated));
    },
    [selectClassesForVesselTypes, vesselTypes],
  );

  const handleVesselClassSelectAll = useCallback(
    (checked: boolean) => {
      const updated = Object.fromEntries(
        flattenClasses(vesselClassGroups).map((v) => [v, checked]),
      );
      setSelectedVesselClasses(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedVesselClasses: updated,
      };
    },
    [vesselClassGroups],
  );

  const handleMtiScoreSelectAll = useCallback(
    (checked: boolean) => {
      const updated = Object.fromEntries(
        (mtiScores || []).map((v) => [v, checked]),
      );
      setSelectedMtiScores(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedMtiScores: updated,
      };
    },
    [mtiScores],
  );

  const resetFilters = useCallback(() => {
    if (!id) return;
    const allFlags = selectAll(flags);
    const allVesselTypes = selectAll(vesselTypes);
    const allVesselClasses = selectAll(flattenClasses(allVesselClassGroups));
    const allMtiScores = selectAll(mtiScores);

    setSelectedFlags(allFlags);
    setSelectedVesselTypes(allVesselTypes);
    setSelectedVesselClasses(allVesselClasses);
    setSelectedMtiScores(allMtiScores);
    filtersRef.current = {
      selectedFlags: allFlags,
      selectedVesselTypes: allVesselTypes,
      selectedVesselClasses: allVesselClasses,
      selectedMtiScores: allMtiScores,
    };
  }, [id, flags, vesselTypes, allVesselClassGroups, mtiScores]);

  const refresh = useCallback(async () => {
    if (!id) return;
    await fetchVessels(currentActive());
  }, [id, fetchVessels, currentActive]);

  useDebouncedEffect(
    () => {
      if (!filtersReady) return;
      void fetchVessels(currentActive());
    },
    [
      id,
      filtersReady,
      activeFlags.join(','),
      activeVesselTypes.join(','),
      activeVesselClasses.join(','),
      activeMtiScores.join(','),
    ],
    DEBOUNCE_MS,
  );

  const hasActiveFilters =
    !isFullySelected(flags, selectedFlags) ||
    !isFullySelected(vesselTypes, selectedVesselTypes) ||
    !isFullySelected(
      flattenClasses(vesselClassGroups),
      selectedVesselClasses,
    ) ||
    !isFullySelected(mtiScores, selectedMtiScores);

  const filtersAppliedCount = [
    (flags?.length ?? 0) > 0 && !isFullySelected(flags, selectedFlags),
    (vesselTypes?.length ?? 0) > 0 &&
      !isFullySelected(vesselTypes, selectedVesselTypes),
    flattenClasses(vesselClassGroups).length > 0 &&
      !isFullySelected(
        flattenClasses(vesselClassGroups),
        selectedVesselClasses,
      ),
    (mtiScores?.length ?? 0) > 0 &&
      !isFullySelected(mtiScores, selectedMtiScores),
  ].filter(Boolean).length;

  return {
    flags,
    vesselTypes,
    vesselClassGroups,
    mtiScores,
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    selectedMtiScores,
    handleFlagToggle,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleMtiScoreToggle,
    handleFlagSelectAll,
    handleVesselTypeSelectAll,
    handleVesselClassSelectAll,
    handleMtiScoreSelectAll,
    resetFilters,
    refresh,
    vessels,
    filtersLoading,
    vesselsLoading,
    hasActiveFilters,
    activeFlags,
    activeVesselTypes,
    activeVesselClasses,
    activeMtiScores,
    filtersAppliedCount,
  };
}
