import { useCallback, useEffect, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  getFleetById,
  getVesselsInAFleet,
} from '@/features/Fleets/services/fleetService';

import { Fleet, VesselData } from '@/features/Fleets/types/fleetTypes';
import { toVesselSearch } from '@/features/Fleets/utils/fleetUtils';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

const VESSELS_LIMIT = 500;

export function useFleetEdit(id: string | undefined) {
  const [fleet, setFleet] = useState<Fleet | undefined>(undefined);
  const [initialVessels, setInitialVessels] = useState<VesselSearch[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const handleApiError = useApiErrorHandler();
  const [vessels, setVessels] = useState<VesselData[]>([]);

  const fetchFleet = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setLoadError(false);
    try {
      const res = await getFleetById(id);
      setFleet(res.data);

      let offset = 0;
      let totalCount = Infinity;
      let allVessels: VesselData[] = [];
      while (offset < totalCount) {
        const vessels = await getVesselsInAFleet(id, VESSELS_LIMIT, offset);
        allVessels = allVessels.concat(vessels.data);
        totalCount = vessels.meta.total_count;
        offset += VESSELS_LIMIT;
      }
      setVessels(allVessels);
      setInitialVessels(allVessels.map(toVesselSearch));
    } catch (error) {
      setLoadError(true);
      setInitialVessels([]);
      await handleApiError(error);
    } finally {
      setLoading(false);
    }
  }, [id, handleApiError]);

  useEffect(() => {
    fetchFleet();
  }, [fetchFleet]);

  return { fleet, initialVessels, loading, loadError, vessels };
}
