import mapboxgl from 'mapbox-gl';
import { useEffect } from 'react';
import type { FlatFleetEventsResponse } from '../types/fleetEventTypes';
import LegendIcon from '@/features/mara2/components/LegendIcon';
import { iconMap } from '@/features/mara2/utils/iconUtil';
import { createReactMarkerElement } from '@/shared/hooks/useReactMarker';
import type { OverviewMapCenter } from '@/shared/types/OverviewMapTypes';
import { logger } from '@/shared/utils/logger';
import { isValidCoordinate } from '@/shared/utils/overviewMapUtils';

type LngLat = [longitude: number, latitude: number];

interface EventMarker {
  iconKey: 'sts' | 'a_g_stop' | 'a_g_resume' | 'p_d';
  position: LngLat;
}

interface EventTrack {
  coordinates: [LngLat, LngLat];
  color: string;
}

const TRACK_SOURCE_ID = 'fleet-event-track-source';
const TRACK_LAYER_ID = 'fleet-event-track-layer';
const AIS_GAP_COLOR = '#dc2626';
const POSITIONAL_DISCREPANCY_COLOR = '#facc15';
const EVENT_FIT_PADDING = 32;
const EVENT_MAX_ZOOM = 12;

function isValidPosition(
  latitude: number | undefined,
  longitude: number | undefined,
): latitude is number {
  return isValidCoordinate(latitude, longitude);
}

function getEventMarkers(event?: FlatFleetEventsResponse): {
  markers: EventMarker[];
  track?: EventTrack;
} {
  if (!event) return { markers: [] };

  if (event.eventType === 'STS_PAIRING') {
    return isValidPosition(event.stsLatitude, event.stsLongitude)
      ? {
          markers: [
            {
              iconKey: 'sts',
              position: [event.stsLongitude!, event.stsLatitude],
            },
          ],
        }
      : { markers: [] };
  }

  if (event.eventType === 'AIS_GAP') {
    const hasStart = isValidPosition(
      event.gapStartedLatitude,
      event.gapStartedLongitude,
    );
    const hasEnd = isValidPosition(
      event.gapEndedLatitude,
      event.gapEndedLongitude,
    );
    const start: LngLat | undefined = hasStart
      ? [event.gapStartedLongitude!, event.gapStartedLatitude!]
      : undefined;
    const end: LngLat | undefined = hasEnd
      ? [event.gapEndedLongitude!, event.gapEndedLatitude!]
      : undefined;
    const markers: EventMarker[] = [];

    if (start) markers.push({ iconKey: 'a_g_stop', position: start });
    if (end) markers.push({ iconKey: 'a_g_resume', position: end });

    return {
      markers,
      ...(start && end
        ? {
            track: {
              coordinates: [start, end],
              color: AIS_GAP_COLOR,
            },
          }
        : {}),
    };
  }

  if (event.eventType === 'POSITIONAL_DISCREPANCY') {
    const hasStart = isValidPosition(
      event.startedLatitude,
      event.startedLongitude,
    );
    const hasEnd = isValidPosition(
      event.stoppedLatitude,
      event.stoppedLongitude,
    );
    const start: LngLat | undefined = hasStart
      ? [event.startedLongitude!, event.startedLatitude!]
      : undefined;
    const end: LngLat | undefined = hasEnd
      ? [event.stoppedLongitude!, event.stoppedLatitude!]
      : undefined;
    const markers: EventMarker[] = [];

    if (start) markers.push({ iconKey: 'p_d', position: start });
    if (end) markers.push({ iconKey: 'p_d', position: end });

    return {
      markers,
      ...(start && end
        ? {
            track: {
              coordinates: [start, end],
              color: POSITIONAL_DISCREPANCY_COLOR,
            },
          }
        : {}),
    };
  }

  return { markers: [] };
}

function fitMapToEvent(map: mapboxgl.Map, positions: LngLat[]) {
  if (positions.length === 0) return;

  const first = positions[0];
  const hasDistinctPositions = positions.some(
    ([longitude, latitude]) => longitude !== first[0] || latitude !== first[1],
  );

  if (!hasDistinctPositions) {
    map.flyTo({ center: first, zoom: EVENT_MAX_ZOOM, speed: 0.6 });
    return;
  }

  const longitudes = positions.map(([longitude]) => longitude);
  const latitudes = positions.map(([, latitude]) => latitude);
  const west = Math.min(...longitudes);
  const east = Math.max(...longitudes);
  const south = Math.min(...latitudes);
  const north = Math.max(...latitudes);

  map.fitBounds(
    [
      [west, south],
      [east, north],
    ],
    { padding: EVENT_FIT_PADDING, maxZoom: EVENT_MAX_ZOOM, duration: 0 },
  );
}

export function useFleetEventMarkers(
  mapRef: React.RefObject<mapboxgl.Map | null>,
  mapReady: boolean,
  event: FlatFleetEventsResponse | undefined,
  center?: OverviewMapCenter,
) {
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady || !event || !map.isStyleLoaded()) return;

    const { markers, track } = getEventMarkers(event);
    const markerHandles = markers.map(({ iconKey, position }) => {
      const icon = iconMap[iconKey];
      const color = iconKey === 'a_g_resume' ? 'bg-red-600' : icon.color;
      const handle = createReactMarkerElement(
        <LegendIcon icon={icon.icon} color={color} hoverable />,
      );
      const marker = new mapboxgl.Marker({ element: handle.element })
        .setLngLat(position)
        .addTo(map);

      return { marker, handle };
    });

    const removeTrack = () => {
      try {
        if (!map.isStyleLoaded()) return;
        if (map.getLayer(TRACK_LAYER_ID)) map.removeLayer(TRACK_LAYER_ID);
        if (map.getSource(TRACK_SOURCE_ID)) map.removeSource(TRACK_SOURCE_ID);
      } catch (error) {
        logger.error('[useFleetEventMarkers] Track cleanup failed', error);
      }
    };

    const addTrack = () => {
      removeTrack();
      if (!track || !map.isStyleLoaded()) return;

      try {
        map.addSource(TRACK_SOURCE_ID, {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'LineString',
              coordinates: track.coordinates,
            },
            properties: {},
          },
        });
        map.addLayer({
          id: TRACK_LAYER_ID,
          type: 'line',
          source: TRACK_SOURCE_ID,
          slot: 'top',
          paint: {
            'line-color': track.color,
            'line-width': 2,
            'line-opacity': 0.9,
            'line-dasharray': [4, 2],
          },
        });
      } catch (error) {
        logger.error('[useFleetEventMarkers] Track rendering failed', error);
      }
    };

    addTrack();
    map.on('style.load', addTrack);

    if (!center) {
      fitMapToEvent(
        map,
        markers.map(({ position }) => position),
      );
    }

    return () => {
      map.off('style.load', addTrack);
      markerHandles.forEach(({ marker, handle }) => {
        marker.remove();
        handle.unmount();
      });
      removeTrack();
    };
  }, [center, event, mapReady, mapRef]);
}
