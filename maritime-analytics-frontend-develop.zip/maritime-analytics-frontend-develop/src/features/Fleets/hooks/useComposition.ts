import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router';
import { getDynamicFilters } from '../services/filtersService';
import { getFleetComposition } from '../services/fleetCompositionService';
import { getVesselsInAFleet } from '../services/fleetService';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  FleetCompositionResponse,
  VesselClassGroup,
  VesselData,
} from '@/features/Fleets/types/fleetTypes';
import { useDebouncedEffect } from '@/shared/hooks/useDebouncedEffect';
import { logger } from '@/shared/utils/logger';

const VESSELS_LIMIT = 500;
const COMPOSITION_DEBOUNCE_MS = 1000;

type SelectionMap = Record<string, boolean>;

const getSelected = (record: SelectionMap): string[] =>
  Object.entries(record)
    .filter(([, v]) => v)
    .map(([k]) => k);

const selectAll = (values: string[] | undefined): SelectionMap =>
  Object.fromEntries((values || []).map((v) => [v, true]));

const isFullySelected = (
  values: string[] | undefined,
  selected: SelectionMap,
): boolean => (values ?? []).every((v) => !!selected[v]);

const flattenClassNames = (groups: VesselClassGroup[] | undefined): string[] =>
  (groups ?? []).flatMap((g) => g.classes);

export function useComposition() {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const [loading, setLoading] = useState<boolean>(false);
  const [composition, setComposition] =
    useState<FleetCompositionResponse | null>(null);
  const [vessels, setVessels] = useState<VesselData[] | undefined>(undefined);

  // Flags/Types are frozen — fetched once on load, never re-fetched. Vessel Class is
  // rescoped to the selected Vessel Type(s) via fetchVesselClassGroups below.
  const [flags, setFlags] = useState<string[]>();
  const [vesselTypes, setVesselTypes] = useState<string[]>();
  const [vesselClassGroups, setVesselClassGroups] =
    useState<VesselClassGroup[]>();

  // Guards the composition/vessels fetch below from firing with an empty (unset)
  // filter selection while fetchFilters is still in flight.
  const [filtersReady, setFiltersReady] = useState(false);

  const [selectedFlags, setSelectedFlags] = useState<SelectionMap>({});
  const [selectedVesselTypes, setSelectedVesselTypes] = useState<SelectionMap>(
    {},
  );
  const [selectedVesselClasses, setSelectedVesselClasses] =
    useState<SelectionMap>({});

  const selectedVesselTypesRef = useRef(selectedVesselTypes);
  selectedVesselTypesRef.current = selectedVesselTypes;

  const activeFlags = useMemo(
    () => getSelected(selectedFlags),
    [selectedFlags],
  );
  const activeVesselTypes = useMemo(
    () => getSelected(selectedVesselTypes),
    [selectedVesselTypes],
  );
  const activeVesselClasses = useMemo(
    () => getSelected(selectedVesselClasses),
    [selectedVesselClasses],
  );

  const fetchVessels = useCallback(async () => {
    if (!id) return;
    try {
      let offset = 0;
      let totalCount = Infinity;
      let allVessels: VesselData[] = [];
      if (
        activeFlags.length === 0 ||
        activeVesselTypes.length === 0 ||
        activeVesselClasses.length === 0
      ) {
        setVessels([]);
        return;
      }
      while (offset < totalCount) {
        const res = await getVesselsInAFleet(
          id,
          VESSELS_LIMIT,
          offset,
          undefined,
          activeFlags,
          activeVesselTypes,
          undefined,
          activeVesselClasses,
        );
        allVessels = allVessels.concat(res.data);
        totalCount = res.meta.total_count;
        offset += VESSELS_LIMIT;
      }
      setVessels(allVessels);
    } catch (e) {
      handleApiError(e);
      logger.error(e as string);
    }
  }, [id, activeFlags, activeVesselTypes, activeVesselClasses, handleApiError]);

  const vesselClassRequestIdRef = useRef(0);

  // Re-scopes Vessel Class options to the given Vessel Type selection (mirrors
  // useFilters.ts's fetchVesselClassGroups), always defaulting the rescoped classes
  // to selected rather than pruning a prior manual selection.
  const fetchVesselClassGroups = useCallback(
    async (activeTypes: string[]) => {
      if (!id) return;
      const requestId = ++vesselClassRequestIdRef.current;
      if (activeTypes.length === 0) {
        setVesselClassGroups([]);
        setSelectedVesselClasses({});
        return;
      }
      try {
        const res = await getDynamicFilters(id, activeTypes);
        if (requestId !== vesselClassRequestIdRef.current) return;
        setVesselClassGroups(res.vessel_class);
        setSelectedVesselClasses(
          selectAll(flattenClassNames(res.vessel_class)),
        );
      } catch (error) {
        if (requestId !== vesselClassRequestIdRef.current) return;
        handleApiError(error);
        logger.error(error as string);
      }
    },
    [id, handleApiError],
  );

  const fetchFilters = useCallback(async () => {
    if (!id) return;
    setFiltersReady(false);
    // No `finally` reset here — `loading` stays true through the debounce and into
    // fetchComposition, which is the only place that clears it.
    setLoading(true);
    try {
      const res = await getDynamicFilters(id);
      setFlags(res.flag_code);
      setVesselTypes(res.vessel_type);
      setVesselClassGroups(res.vessel_class);

      setSelectedFlags(selectAll(res.flag_code));
      setSelectedVesselTypes(selectAll(res.vessel_type));
      setSelectedVesselClasses(selectAll(flattenClassNames(res.vessel_class)));
    } catch (error) {
      handleApiError(error);
      logger.error(error as string);
      setComposition(null);
    } finally {
      setFiltersReady(true);
    }
  }, [id, handleApiError]);

  useEffect(() => {
    fetchFilters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleFlagToggle = useCallback((value: string, checked: boolean) => {
    setSelectedFlags((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const handleVesselTypeToggle = useCallback(
    (value: string, checked: boolean) => {
      const next = { ...selectedVesselTypesRef.current, [value]: checked };
      setSelectedVesselTypes(next);
      selectedVesselTypesRef.current = next;
      fetchVesselClassGroups(getSelected(next));
    },
    [fetchVesselClassGroups],
  );

  const handleVesselClassToggle = useCallback(
    (value: string, checked: boolean) => {
      setSelectedVesselClasses((prev) => ({ ...prev, [value]: checked }));
    },
    [],
  );

  const handleFlagSelectAll = useCallback(
    (checked: boolean) => {
      setSelectedFlags(
        Object.fromEntries((flags ?? []).map((v) => [v, checked])),
      );
    },
    [flags],
  );

  const handleVesselTypeSelectAll = useCallback(
    (checked: boolean) => {
      const next = Object.fromEntries(
        (vesselTypes ?? []).map((v) => [v, checked]),
      );
      setSelectedVesselTypes(next);
      selectedVesselTypesRef.current = next;
      fetchVesselClassGroups(getSelected(next));
    },
    [vesselTypes, fetchVesselClassGroups],
  );

  const handleVesselClassSelectAll = useCallback(
    (checked: boolean) => {
      setSelectedVesselClasses(
        Object.fromEntries(
          flattenClassNames(vesselClassGroups).map((v) => [v, checked]),
        ),
      );
    },
    [vesselClassGroups],
  );

  const resetFilters = useCallback(() => {
    fetchFilters();
  }, [fetchFilters]);

  const hasActiveFilters = useMemo(
    () =>
      !isFullySelected(flags, selectedFlags) ||
      !isFullySelected(vesselTypes, selectedVesselTypes) ||
      !isFullySelected(
        flattenClassNames(vesselClassGroups),
        selectedVesselClasses,
      ),
    [
      flags,
      vesselTypes,
      vesselClassGroups,
      selectedFlags,
      selectedVesselTypes,
      selectedVesselClasses,
    ],
  );

  const fetchComposition = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      if (
        activeFlags.length === 0 ||
        activeVesselTypes.length === 0 ||
        activeVesselClasses.length === 0
      ) {
        setComposition(null);
        return;
      }
      const res = await getFleetComposition(
        id,
        activeFlags,
        activeVesselTypes,
        activeVesselClasses,
      );
      setComposition(res);
    } catch (error) {
      handleApiError(error);
      logger.error(error as string);
      setComposition(null);
    } finally {
      setLoading(false);
    }
  }, [id, activeFlags, activeVesselTypes, activeVesselClasses, handleApiError]);

  useDebouncedEffect(
    () => {
      if (!filtersReady) return;
      fetchComposition();
      fetchVessels();
    },
    [
      id,
      filtersReady,
      activeFlags.join(','),
      activeVesselTypes.join(','),
      activeVesselClasses.join(','),
    ],
    COMPOSITION_DEBOUNCE_MS,
  );

  return {
    composition,
    vessels,
    flags,
    vesselTypes,
    vesselClassGroups,
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    activeFlags,
    activeVesselClasses,
    handleFlagToggle,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleFlagSelectAll,
    handleVesselTypeSelectAll,
    handleVesselClassSelectAll,
    resetFilters,
    hasActiveFilters,
    loading,
  };
}
