import { useCallback, useEffect, useState } from 'react';
import { getFleetById } from '../services/fleetService';
import { Fleet } from '../types/fleetTypes';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';

export function useFleetDetails(id?: string) {
  const handleApiError = useApiErrorHandler();
  const [fleet, setFleet] = useState<Fleet | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(false);

  const fetchFleet = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setLoadError(false);
    try {
      const res = await getFleetById(id);
      setFleet(res.data);
    } catch (error) {
      setLoadError(true);
      await handleApiError(error);
    } finally {
      setLoading(false);
    }
  }, [id, handleApiError]);

  useEffect(() => {
    fetchFleet();
  }, [fetchFleet]);

  return { fleet, loading, loadError };
}
