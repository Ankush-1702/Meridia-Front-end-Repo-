export type SortBy =
  | 'added_at'
  | '-added_at'
  | 'imo'
  | '-imo'
  | 'mmsi'
  | '-mmsi'
  | 'name'
  | '-name';

export type VesselResultReason = 'INVALID_FORMAT' | 'NOT_FOUND';

export type FleetType = 'STATIC' | 'DYNAMIC';

export interface Meta {
  limit: number;
  offset: number;
  total_count: number;
  request_id: string;
  request_timestamp: string;
}

export interface Fleet {
  fleet_id: string;
  name: string;
  description: string;
  type: FleetType;
  vessel_count: number;
  created_by: string;
  created_at: string;
  last_modified_by: string;
  last_modified_at: string;
}

export interface UnResolvedImo {
  reason: VesselResultReason;
  imo_numbers: string[];
}

export interface UnresolvedImos {
  notFound: BulkImoVerificationResponseDataInvalidOrNotFound[];
  inValid: BulkImoVerificationResponseDataInvalidOrNotFound[];
}

export interface VesselResults {
  requested: number;
  added: number;
  rejected: UnResolvedImo[];
}

export interface CreateFleetData {
  fleet: {
    fleet_id: string;
    name: string;
    description: string;
    vessel_count: number;
    created_at: string;
    created_by: string;
  };
}

export interface UpdateFleetData {
  fleet_id: string;
  name: string;
  description: string;
  vessel_count: number;
  created_at: string;
  created_by: string;
  last_modified_at: string;
}

export interface UpdateFleetVesselResults {
  added: {
    imo: string;
    name: string;
    status: string;
  }[];
  removed: {
    imo: string;
    name: string;
    status: string;
  }[];
  failed: {
    imo: string;
    reason: VesselResultReason;
    action: string;
  }[];
}

export interface FleetsResponse {
  meta: Meta;
  data: Fleet[];
}

export interface FleetDetailResponse {
  meta: Pick<Meta, 'request_id' | 'request_timestamp'>;
  data: Fleet;
}

export interface ICreateFleets {
  name: string;
  description?: string;
  imo_numbers: string[];
}

export interface IUpdateFleets {
  name?: string;
  description?: string;
  add_imo?: string[];
  remove_imo?: string[];
}

export interface CreateFleetResponse {
  meta: Pick<Meta, 'request_id' | 'request_timestamp'>;
  data: CreateFleetData;
  vessel_results: VesselResults;
}

export interface UpdateFleetResponse {
  meta: Pick<Meta, 'request_id' | 'request_timestamp'>;
  data: UpdateFleetData;
  vessel_results: UpdateFleetVesselResults;
}

export interface VesselData {
  added_at: string;
  added_by: string;
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_status: string;
    vessel_type: string | null;
    vessel_class: string;
    build_year: number;
    age: number;
    deadweight: number;
  };
  vessel_position:
    | {
        latitude: number;
        longitude: number;
        course: number;
        heading: number;
        speed: number;
        navigational_status: {
          status: string;
          code: number;
        };
        draught: number;
        reported_destination: string;
        reported_eta: string;
        timestamp: string;
        source: string;
      }
    | null
    | undefined;
  mti_score?: string;
}

export interface VesselsInAFleetResponse {
  meta: Meta;
  data: VesselData[];
}

export interface VesselClassGroup {
  vessel_type: string;
  classes: string[];
}

export interface FiltersResponse {
  vessel_class: VesselClassGroup[];
  vessel_type: string[];
  flag_code: string[];
  mti_score: string[];
}

export type FleetOverviewView = 'map' | 'list';

export interface FleetVesselPopupData {
  vesselName: string;
  imo: string;
  vesselType: string;
  vesselClass: string;
  flag: string;
  speed?: number;
  course?: number;
  reportedDestination: string;
  reportedEta: string;
  timeStr: string;
}

export interface IPasteBulkImoDTO {
  imos: string[];
}

export interface BulkImoVerificationResponseSummary {
  requested: number;
  found: number;
  not_found: number;
  invalid: number;
}

export interface BulkImoVerificationResponseDataFound {
  asset_id: string;
  imo: string;
  vessel_name: string;
  mmsi: number;
  flag: string;
  vessel_type: string;
  call_sign?: string;
  flag_code: string;
  vessel_status: string;
}

export interface BulkImoVerificationResponseDataInvalidOrNotFound {
  imo: string;
  message: string;
}

export interface BulkImoVerificationResponseData {
  found: BulkImoVerificationResponseDataFound[];
  not_found: BulkImoVerificationResponseDataInvalidOrNotFound[];
  invalid: BulkImoVerificationResponseDataInvalidOrNotFound[];
}

export interface BulkImoVerificationResponse {
  meta: Pick<Meta, 'request_id' | 'request_timestamp'>;
  summary: BulkImoVerificationResponseSummary;
  data: BulkImoVerificationResponseData;
}
export interface IFleetExportBody {
  filters?: {
    flag_code: string[];
    mti_score: string[];
    vessel_class: string[];
    vessel_type: string[];
  };
}

export interface FleetCompositionItems {
  label: string;
  count: number;
  percentage: number;
}

export interface FleetInformation {
  fleet_id: string;
  name: string;
  vessel_count: number;
}

export interface FleetCompositionSummary {
  vessels: {
    filtered_count: number;
  };
  average_age: {
    unit: string;
    value: number;
  };
  total_dwt: {
    unit: string;
    value: number;
    vessels_with_data: number;
  };
  flag_states_count: number;
}

export interface FleetCompositionTypeAndClass {
  vessel_type: FleetCompositionItems[];
  vessel_class: FleetCompositionItems[];
}

export interface FleetCompositionRegistrationAndFlag {
  port_of_registry: {
    total_categories: number;
    items: FleetCompositionItems[];
  };
  vessel_flag: {
    total_categories: number;
    items: FleetCompositionItems[];
  };
}

export interface FleetCompositionBuildAndOrigin {
  country_of_build: {
    total_categories: number;
    items: FleetCompositionItems[];
  };
  builder: {
    total_categories: number;
    items: FleetCompositionItems[];
  };
  age_profile: FleetCompositionItems[];
}

export interface FleetCompositionSizeAndDimensions {
  size: {
    deadweight_tonnage: {
      vessels_with_data: number;
      unit: string;
      items: FleetCompositionItems[];
    };
    gross_tonnage: {
      vessels_with_data: number;
      unit: string;
      items: FleetCompositionItems[];
    };
  };
  dimensions: {
    length_overall: {
      unit: string;
      vessels_with_data: number;
      items: FleetCompositionItems[];
    };
    beam: {
      unit: string;
      vessels_with_data: number;
      items: FleetCompositionItems[];
    };
    draught: {
      unit: string;
      vessels_with_data: number;
      items: FleetCompositionItems[];
    };
  };
}

export interface FleetCompositionData {
  summary: FleetCompositionSummary;
  type_and_class: FleetCompositionTypeAndClass;
  registration_and_flag: FleetCompositionRegistrationAndFlag;
  build_and_origin: FleetCompositionBuildAndOrigin;
  size_and_dimensions: FleetCompositionSizeAndDimensions;
}

export interface FleetCompositionResponse {
  meta: Pick<Meta, 'request_id' | 'request_timestamp'>;
  fleet_information: FleetInformation;
  data: FleetCompositionData;
}
