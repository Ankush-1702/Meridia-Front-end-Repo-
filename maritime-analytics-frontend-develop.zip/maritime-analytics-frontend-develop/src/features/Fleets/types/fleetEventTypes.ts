import { VesselData } from './fleetTypes';

export type FleetEventType =
  | 'STS_PAIRING'
  | 'AIS_GAP'
  | 'POSITIONAL_DISCREPANCY'
  | 'ZONE_ENTRY'
  | 'ZONE_EXIT'
  | 'PORT_ARRIVAL'
  | 'PORT_DEPARTURE'
  | 'PORT_AREA_ARRIVAL'
  | 'PORT_AREA_DEPARTURE'
  | 'PORT_STATE_CONTROL';

export interface Meta {
  request_id: string;
  request_timestamp: string;
  limit: number;
  offset: number;
  total_count: number;
}

// export interface FleetOverview {
//   event_timestamp: string;
//   location: string | null;
//   country: string | null;
//   unlocode: string | null;
//   zone_type: string | null;
//   speed: number | null;
//   course: number | null;
//   duration_hours: number | null;
// }

export interface ZoneInformation {
  centroid: {
    longitude: number;
    latitude: number;
  };
  country_official_name: string;
  country_code: string;
  description: string | undefined;
  id: string;
  name: string;
  sub_type: string;
  type: string;
  unlocode: string | undefined;
  country_common_name: string;
  sub_division_code: string | undefined;
  sub_division_name: string | undefined;
  wpi_number: null | string | number | undefined;
}

export interface VesselIdentity {
  asset_id: string;
  callsign: string;
  imo: string;
  mmsi: string;
  name: string;
  flag_code: string;
  flag: string;
  vessel_type: string;
}

export interface ZoneAndPortEvents {
  event_id: string;
  event_type: FleetEventType;
  event_timestamp: string;
  course: number;
  navigational_status: {
    status: string;
    code: string;
  };
  reported_destination: string;
  reported_eta: string;
  speed: number;
  heading: number;
  draught: number;
  zone_port_event_location: {
    latitude: number;
    longitude: number;
  };
}

export interface STSPairing {
  event_id: string;
  event_type: FleetEventType;
  event_timestamp: string;
  sts_location: { latitude: number; longitude: number };
  duration_hours: number;
  paired_vessel: VesselData;
  sts_start_timestamp: string;
  sts_end_timestamp: string;
  sts_type: string;
}

export interface AISGap {
  event_id: string;
  event_type: FleetEventType;
  event_timestamp: string;
  gap_duration_hours: number | string;
  draught_change: number | undefined | string;
  gap_started: {
    course: number;
    draught: number;
    latitude: number;
    longitude: number;
    navigational_status: {
      status: string;
      code: string;
    };
    speed: number;
    gap_started_timestamp: string;
  };
  gap_ended: {
    course?: number;
    draught?: number;
    latitude?: number;
    longitude?: number;
    navigational_status?: {
      status?: string;
      code?: string;
    };
    speed?: number;
    gap_ended_timestamp?: string;
  };
}

export interface PortStateControl {
  event_id: string;
  event_type: FleetEventType;
  event_timestamp: string;
  authority: string;
  detained: boolean;
  expanded_inspection: boolean;
  follow_up_inspection: string;
  inspection_timestamp: string;
  inspection_type: string;
  no_days_detained: number;
  no_defects: number;
  port_information: {
    name: string;
    country: string;
    country_code: string;
  };
  release_timestamp: string;
}

export interface PositionalDiscrepancy {
  event_id: string;
  event_type: FleetEventType;
  event_subtype: string;
  event_timestamp: string;
  has_ended: boolean;
  duration_hours: number;
  mmsi: string;
  start: {
    draught: null | number | string;
    latitude: number;
    longitude: number;
    start_timestamp: string;
  };
  end: {
    draught: null | number | string;
    latitude: number;
    longitude: number;
    end_timestamp: string;
  };
}

export interface FleetEvents {
  event_details:
    | STSPairing
    | AISGap
    | PositionalDiscrepancy
    | PortStateControl
    | ZoneAndPortEvents;
  vessel_information: VesselIdentity;
  zone_information?: ZoneInformation;
}

export interface FleetEventData {
  events: FleetEvents[];
}

export interface FleetEventResponse {
  meta: Meta;
  data: FleetEventData;
}

export interface FlatFleetEventsResponse {
  // ── Default Columns ──────────────────────────
  eventTimestamp?: string;
  eventType?: FleetEventType;
  location?: string;
  country?: string;
  unlocode?: string;
  zoneType?: string;
  zoneSubType?: string;
  zoneId?: string;
  speed?: number;
  course?: number;
  duration?: number | string;
  countryFlag?: string;

  // ── Vessel Information ──────────────────────────
  callSign: string;
  flag: string;
  flagCode: string;
  imo: string;
  mmsi: string;
  vesselName: string;
  vesselType: string;

  // –– Position & Movement –––––––––––––––––––––––
  heading?: number;
  draught?: number | string;
  navigationalStatusStatus?: string;
  navigationalStatusCode?: number | string;
  reportedDestination?: string;
  reportedEta?: string;

  // ── Port State Control ──────────────────────────
  authority?: string;
  inspectionType?: string;
  inspectionDate?: string;
  detained?: boolean;
  daysDetained?: number;
  numberOfDefects?: number;
  releaseDate?: string;

  // ── STS Pairings ──────────────────────────────────────
  stsType?: string;
  pairedVessel?: string;
  pairedIMO?: string;
  stsEnded?: string;

  // ── AIS Gaps ──────────────────────────────────────────
  gapStopped?: string;
  gapResumed?: string;
  draughtChange?: string | number;

  // ── Positional Discrepancies ────────────────────────────────
  hasEnded?: boolean;
  startedLatitude?: number;
  startedLongitude?: number;
  stoppedTimestamp?: string;
  stoppedLatitude?: number;
  stoppedLongitude?: number;

  // ── Map positions ──────────────────────────────────────
  eventLatitude?: number;
  eventLongitude?: number;
  stsLatitude?: number;
  stsLongitude?: number;
  gapStartedLatitude?: number;
  gapStartedLongitude?: number;
  gapEndedLatitude?: number;
  gapEndedLongitude?: number;

  // —— Zone Information —————————————————————————————————
  centrePointLat?: number;
  centrePointLng?: number;
  zoneName?: string;
  countryOfficialName?: string;

  // ———— Other Cats —————————————————————————————————————
  pairedVesselData?: VesselData;
  zonePortEventLocationLat?: number;
  zonePortEventLocationLng?: number;
}
