import {
  API_GATEWAY_BASE_URL,
  FLEET_MANAGEMENT_BASE_API_URL,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { BulkImoVerificationResponse } from '@/features/Fleets/types/fleetTypes';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import { shouldImoSearch } from '@/features/library/utils/libraryHelpers';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

export async function searchVesselsforFleets(
  query: string,
  limit: number,
  offSet: number,
): Promise<{ data: VesselSearch[]; meta?: { total_count: number } }> {
  const params = new URLSearchParams({
    limit: limit.toString(),
    offset: offSet.toString(),
  });
  if (shouldImoSearch(query)) params.append('imo', query.trim());
  if (!shouldImoSearch(query)) params.append('name_contains', query.trim());
  const url = `${API_GATEWAY_BASE_URL}/vessel-insights/v2/vessel-search?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });
  await throwOnError(res, 'Failed to get vessels');
  return await res.json();
}

export async function verifyVessels(
  imos?: string[],
  csv?: File,
): Promise<BulkImoVerificationResponse> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/vessel-insights/v1/vessels/bulk-search`;

  if (csv) {
    const formData = new FormData();
    formData.append('file', csv);
    const res = await fetchWithAuth(url, {
      method: 'POST',
      headers: { ...getAuthHeaders() },
      body: formData,
    });
    await throwOnError(res, 'Failed to verify vessel');
    return res.json();
  } else {
    const res = await fetchWithAuth(url, {
      method: 'POST',
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ imos }),
    });
    await throwOnError(res, 'Failed to verify vessel');
    return res.json();
  }
}
