import { FleetCompositionResponse } from '../types/fleetTypes';
import {
  FLEET_MANAGEMENT_BASE_API_URL,
  FLEET_MANAGEMENT_SLUG,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

export async function getFleetComposition(
  fleetId: string,
  flagCode: string[],
  vesselType: string[],
  vesselClass: string[],
): Promise<FleetCompositionResponse> {
  const params = new URLSearchParams({});
  if (flagCode?.length) params.append('flag_code', flagCode.join(','));
  if (vesselType?.length) params.append('vessel_type', vesselType.join(','));
  if (vesselClass?.length) params.append('vessel_class', vesselClass.join(','));
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets/${fleetId}/composition?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });
  await throwOnError(res, 'Failed to get fleet composition');
  return res.json();
}
