import {
  FLEET_MANAGEMENT_BASE_API_URL,
  FLEET_MANAGEMENT_SLUG,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { FiltersResponse } from '@/features/Fleets/types/fleetTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

export async function getDynamicFilters(
  fleetId: string,
  vesselType?: string[],
): Promise<FiltersResponse> {
  const params = new URLSearchParams({});
  if (vesselType?.length) params.append('vessel_type', vesselType.join(','));
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets/${fleetId}/filters?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });
  await throwOnError(res, 'Failed to get filters');
  return res.json();
}
