import {
  FLEET_MANAGEMENT_BASE_API_URL,
  FLEET_MANAGEMENT_SLUG,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  CreateFleetResponse,
  FleetDetailResponse,
  FleetsResponse,
  ICreateFleets,
  IUpdateFleets,
  SortBy,
  UpdateFleetResponse,
  VesselsInAFleetResponse,
} from '@/features/Fleets/types/fleetTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

export async function getFleets(
  limit: number,
  offSet: number,
): Promise<FleetsResponse> {
  const params = new URLSearchParams({
    limit: limit.toString() || '500',
    offset: offSet.toString() || '0',
  });
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  await throwOnError(res, 'Failed to get fleets');
  return res.json();
}

export async function getFleetById(id: string): Promise<FleetDetailResponse> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets/${id}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  await throwOnError(res, 'Failed to get fleet');
  return res.json();
}

export async function getVesselsInAFleet(
  id: string,
  limit?: number,
  offset?: number,
  sortBy?: SortBy,
  flagCode?: string[],
  vesselType?: string[],
  navigationalStatus?: string,
  vesselClass?: string[],
  mtiScore?: string[],
): Promise<VesselsInAFleetResponse> {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
  });
  if (sortBy) params.append('sort_by', sortBy);
  if (flagCode?.length) params.append('flag_code', flagCode.join(','));
  if (vesselType?.length) params.append('vessel_type', vesselType.join(','));
  if (navigationalStatus)
    params.append('navigational_status', navigationalStatus);
  if (vesselClass?.length) params.append('vessel_class', vesselClass.join(','));
  if (mtiScore?.length) params.append('mti_score', mtiScore.join(','));
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets/${id}/vessels?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  await throwOnError(res, 'Failed to get vessels in a fleet');
  return res.json();
}

export async function createFleet(
  payload: ICreateFleets,
): Promise<CreateFleetResponse> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/fleet-management/v2/fleets`;
  const res = await fetchWithAuth(url, {
    method: 'POST',
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  await throwOnError(res, 'Failed to create fleet');
  return res.json();
}

export async function updateFleet(
  id: string,
  payload: IUpdateFleets,
): Promise<UpdateFleetResponse> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/fleet-management/v2/fleets/${id}`;
  const res = await fetchWithAuth(url, {
    method: 'PUT',
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  await throwOnError(res, 'Failed to update fleet');
  return res.json();
}

export async function deleteFleet(id: string): Promise<void> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/fleet-management/v2/fleets/${id}`;
  const res = await fetchWithAuth(url, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });

  await throwOnError(res, 'Failed to delete fleet');
}
