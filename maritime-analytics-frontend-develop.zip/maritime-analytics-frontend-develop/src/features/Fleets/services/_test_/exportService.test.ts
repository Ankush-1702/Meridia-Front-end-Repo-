import { describe, it, expect, vi, beforeEach } from 'vitest';
import { triggerFleetCsvExport } from '../exportService';
import type { IFleetExportBody } from '@/features/Fleets/types/fleetTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'https://api.base',
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  FLEET_MANAGEMENT_BASE_API_URL: 'https://fleet-management.api',
  FLEET_MANAGEMENT_SLUG: 'fleet-management/v2',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}

function errorWithPlainText(
  status: number,
  text: string,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => text,
  };
}

function errorWithNoBody(
  status: number,
  statusText: string,
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => '',
  };
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('exportService', () => {
  const body: IFleetExportBody = {
    filters: {
      flag_code: ['GB'],
      mti_score: ['HIGH'],
      vessel_class: ['VLCC'],
      vessel_type: ['Tanker'],
    },
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('triggerFleetCsvExport', () => {
    it('triggers an export and returns data', async () => {
      const data = {
        data: { export_id: 'exp-1', status: 'PROCESSING', download_url: null },
      };
      await mockFetch(okResponse(data));

      const result = await triggerFleetCsvExport('f1', body);

      expect(result).toEqual(data);
    });

    it('calls POST to the correct URL with JSON body and auth headers', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await triggerFleetCsvExport('f1', body);

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets/f1/exports/vessels',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
          body: JSON.stringify(body),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Export failed' }));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Export failed',
      );
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Bad request',
      );
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Validation failed',
      );
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Plain text error',
      );
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to the provided fallback message when body, text and statusText are all empty', async () => {
      await mockFetch(errorWithNoBody(500, ''));
      await expect(triggerFleetCsvExport('f1', body)).rejects.toThrow(
        'Failed to initiate exports',
      );
    });
  });
});
