import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getDynamicFilters } from '../filtersService';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'https://api.base',
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  FLEET_MANAGEMENT_BASE_API_URL: 'https://fleet-management.api',
  FLEET_MANAGEMENT_SLUG: 'fleet-management/v2',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}

function errorWithPlainText(
  status: number,
  text: string,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => text,
  };
}

function errorWithNoBody(
  status: number,
  statusText: string,
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => '',
  };
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('getDynamicFilters', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('fetches filters and returns data', async () => {
    const data = { flags: [], vessel_types: [] };
    await mockFetch(okResponse(data));

    const result = await getDynamicFilters('f1');

    expect(result).toEqual(data);
  });

  it('calls the correct URL with no query params when none provided', async () => {
    await mockFetch(okResponse({}));
    const fetch = await getFetchWithAuth();

    await getDynamicFilters('f1');

    expect(fetch).toHaveBeenCalledWith(
      'https://fleet-management.api/fleet-management/v2/fleets/f1/filters?',
      expect.objectContaining({
        headers: expect.objectContaining({ Authorization: 'Bearer token' }),
      }),
    );
  });

  it('joins vessel_type arrays with commas', async () => {
    await mockFetch(okResponse({}));
    const fetch = await getFetchWithAuth();

    await getDynamicFilters('f1', ['Tanker', 'Cargo']);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain('vessel_type=Tanker%2CCargo');
  });

  it('omits params for empty arrays', async () => {
    await mockFetch(okResponse({}));
    const fetch = await getFetchWithAuth();

    await getDynamicFilters('f1', []);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toBe(
      'https://fleet-management.api/fleet-management/v2/fleets/f1/filters?',
    );
  });

  it('throws with message from errBody.message', async () => {
    await mockFetch(errorResponse(404, { message: 'Filters not found' }));
    await expect(getDynamicFilters('f1')).rejects.toThrow('Filters not found');
  });

  it('throws with message from errBody.error when message is absent', async () => {
    await mockFetch(errorResponse(400, { error: 'Bad request' }));
    await expect(getDynamicFilters('f1')).rejects.toThrow('Bad request');
  });

  it('throws with message from errBody.detail when message and error are absent', async () => {
    await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
    await expect(getDynamicFilters('f1')).rejects.toThrow('Validation failed');
  });

  it('falls back to raw text when body is not valid JSON', async () => {
    await mockFetch(errorWithPlainText(500, 'Plain text error'));
    await expect(getDynamicFilters('f1')).rejects.toThrow('Plain text error');
  });

  it('falls back to statusText when body and text are empty', async () => {
    await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
    await expect(getDynamicFilters('f1')).rejects.toThrow(
      'Internal Server Error',
    );
  });
});
