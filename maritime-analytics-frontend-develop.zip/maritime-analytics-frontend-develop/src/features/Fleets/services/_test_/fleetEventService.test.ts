import { afterEach, describe, expect, it, vi } from 'vitest';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { getFleetEvents } from '@/features/Fleets/services/fleetEventService';

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

describe('getFleetEvents', () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  it('requests events with the supplied filters and returns the response', async () => {
    const payload = {
      meta: {
        request_id: 'request-1',
        request_timestamp: '2026-01-02T00:00:00Z',
        limit: 250,
        offset: 5,
        total_count: 0,
      },
      data: { events: [] },
    };
    vi.mocked(fetchWithAuth).mockResolvedValue(
      new Response(JSON.stringify(payload), { status: 200 }),
    );

    const response = await getFleetEvents(
      'fleet-1',
      ['AIS_GAP', 'ZONE_ENTRY'],
      '2026-01-01T00:00:00Z',
      '2026-01-02T00:00:00Z',
      5,
      250,
    );

    expect(response).toEqual(payload);
    expect(fetchWithAuth).toHaveBeenCalledOnce();

    const requestUrl = vi.mocked(fetchWithAuth).mock.calls[0]?.[0];
    expect(requestUrl).toContain('/fleet-management/v2/fleets/fleet-1/events?');

    const query = new URLSearchParams(requestUrl?.split('?')[1]);
    expect(query.get('limit')).toBe('250');
    expect(query.get('offset')).toBe('5');
    expect(query.get('timestamp_start')).toBe('2026-01-01T00:00:00Z');
    expect(query.get('timestamp_end')).toBe('2026-01-02T00:00:00Z');
    expect(query.get('event_type')).toBe('AIS_GAP,ZONE_ENTRY');
  });
});
