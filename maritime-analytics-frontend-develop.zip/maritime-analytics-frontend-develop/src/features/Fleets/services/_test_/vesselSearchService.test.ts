import { describe, it, expect, vi, beforeEach } from 'vitest';
import { searchVesselsforFleets } from '../vesselSearchService';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'https://api.base',
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  LEGACY_API_GATEWAY_BASE_URL: 'https://api.gateway',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}

function errorWithPlainText(
  status: number,
  text: string,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => text,
  };
}

function errorWithNoBody(
  status: number,
  statusText: string,
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => '',
  };
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('searchVesselsforFleets', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('searches vessels and returns data', async () => {
    const data = { data: [{ imo: '1234567' }], meta: { total_count: 1 } };
    await mockFetch(okResponse(data));

    const result = await searchVesselsforFleets('Maersk', 50, 0);

    expect(result).toEqual(data);
  });

  it('includes limit and offset in the URL', async () => {
    await mockFetch(okResponse({ data: [] }));
    const fetch = await getFetchWithAuth();

    await searchVesselsforFleets('Maersk', 50, 10);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain('limit=50');
    expect(calledUrl).toContain('offset=10');
  });

  it('uses the imo query param for a 7-digit query', async () => {
    await mockFetch(okResponse({ data: [] }));
    const fetch = await getFetchWithAuth();

    await searchVesselsforFleets('1234567', 50, 0);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain('imo=1234567');
    expect(calledUrl).not.toContain('name_contains');
  });

  it('uses the name_contains query param for a non-numeric query', async () => {
    await mockFetch(okResponse({ data: [] }));
    const fetch = await getFetchWithAuth();

    await searchVesselsforFleets('Maersk', 50, 0);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain('name_contains=Maersk');
    expect(calledUrl).not.toContain('imo=');
  });

  it('trims whitespace from the query', async () => {
    await mockFetch(okResponse({ data: [] }));
    const fetch = await getFetchWithAuth();

    await searchVesselsforFleets('  Maersk  ', 50, 0);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain('name_contains=Maersk');
  });

  it('calls the correct base URL', async () => {
    await mockFetch(okResponse({ data: [] }));
    const fetch = await getFetchWithAuth();

    await searchVesselsforFleets('Maersk', 50, 0);

    const calledUrl = fetch.mock.calls[0][0] as string;
    expect(calledUrl).toContain(
      'https://api.gateway/vessel-insights/v2/vessel-search?',
    );
    expect(fetch).toHaveBeenCalledWith(
      calledUrl,
      expect.objectContaining({
        headers: expect.objectContaining({ Authorization: 'Bearer token' }),
      }),
    );
  });

  it('throws with message from errBody.message', async () => {
    await mockFetch(errorResponse(404, { message: 'No vessels found' }));
    await expect(searchVesselsforFleets('Maersk', 50, 0)).rejects.toThrow(
      'No vessels found',
    );
  });

  it('throws with message from errBody.error when message is absent', async () => {
    await mockFetch(errorResponse(400, { error: 'Bad request' }));
    await expect(searchVesselsforFleets('Maersk', 50, 0)).rejects.toThrow(
      'Bad request',
    );
  });

  it('throws with message from errBody.detail when message and error are absent', async () => {
    await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
    await expect(searchVesselsforFleets('Maersk', 50, 0)).rejects.toThrow(
      'Validation failed',
    );
  });

  it('falls back to raw text when body is not valid JSON', async () => {
    await mockFetch(errorWithPlainText(500, 'Plain text error'));
    await expect(searchVesselsforFleets('Maersk', 50, 0)).rejects.toThrow(
      'Plain text error',
    );
  });

  it('falls back to statusText when body and text are empty', async () => {
    await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
    await expect(searchVesselsforFleets('Maersk', 50, 0)).rejects.toThrow(
      'Internal Server Error',
    );
  });
});
