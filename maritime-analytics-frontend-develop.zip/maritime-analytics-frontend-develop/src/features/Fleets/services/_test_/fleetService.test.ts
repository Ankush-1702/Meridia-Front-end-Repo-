import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  getFleets,
  getFleetById,
  getVesselsInAFleet,
  createFleet,
  updateFleet,
  deleteFleet,
} from '../fleetService';
import type {
  ICreateFleets,
  IUpdateFleets,
} from '@/features/Fleets/types/fleetTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'https://api.base',
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  FLEET_MANAGEMENT_BASE_API_URL: 'https://fleet-management.api',
  FLEET_MANAGEMENT_SLUG: 'fleet-management/v2',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}

function errorWithPlainText(
  status: number,
  text: string,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => text,
  };
}

function errorWithNoBody(
  status: number,
  statusText: string,
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => ({}),
    text: async () => '',
  };
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('fleetService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getFleets', () => {
    it('fetches fleets and returns data', async () => {
      const data = { data: [{ id: 'f1' }] };
      await mockFetch(okResponse(data));

      const result = await getFleets(50, 0);

      expect(result).toEqual(data);
    });

    it('calls the correct URL with limit and offset', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getFleets(50, 10);

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets?limit=50&offset=10',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(getFleets(50, 0)).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(getFleets(50, 0)).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(getFleets(50, 0)).rejects.toThrow('Validation failed');
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(getFleets(50, 0)).rejects.toThrow('Plain text error');
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(getFleets(50, 0)).rejects.toThrow('Internal Server Error');
    });
  });

  describe('getFleetById', () => {
    it('fetches a fleet by id and returns data', async () => {
      const data = { id: 'f1', name: 'Fleet A' };
      await mockFetch(okResponse(data));

      const result = await getFleetById('f1');

      expect(result).toEqual(data);
    });

    it('calls the correct URL', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getFleetById('f1');

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets/f1',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Fleet not found' }));
      await expect(getFleetById('f1')).rejects.toThrow('Fleet not found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Invalid id' }));
      await expect(getFleetById('f1')).rejects.toThrow('Invalid id');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Unprocessable' }));
      await expect(getFleetById('f1')).rejects.toThrow('Unprocessable');
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(getFleetById('f1')).rejects.toThrow('Plain text error');
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(getFleetById('f1')).rejects.toThrow('Internal Server Error');
    });
  });

  describe('getVesselsInAFleet', () => {
    it('fetches vessels in a fleet and returns data', async () => {
      const data = { data: [{ imo: '123' }] };
      await mockFetch(okResponse(data));

      const result = await getVesselsInAFleet('f1');

      expect(result).toEqual(data);
    });

    it('includes default limit and offset in the URL', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet('f1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/fleet-management/v2/fleets/f1/vessels?');
      expect(calledUrl).toContain('limit=500');
      expect(calledUrl).toContain('offset=0');
    });

    it('uses custom limit and offset when provided', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet('f1', 25, 5);

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('limit=25');
      expect(calledUrl).toContain('offset=5');
    });

    it('appends sort_by when provided', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet('f1', 25, 5, 'name');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('sort_by=name');
    });

    it('joins flag_code, vessel_type, vessel_class and mti_score arrays with commas', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet(
        'f1',
        25,
        5,
        undefined,
        ['GB', 'US'],
        ['Tanker', 'Cargo'],
        undefined,
        ['ClassA', 'ClassB'],
        ['High', 'Low'],
      );

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('flag_code=GB%2CUS');
      expect(calledUrl).toContain('vessel_type=Tanker%2CCargo');
      expect(calledUrl).toContain('vessel_class=ClassA%2CClassB');
      expect(calledUrl).toContain('mti_score=High%2CLow');
    });

    it('appends navigational_status when provided', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet(
        'f1',
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        'Underway',
      );

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('navigational_status=Underway');
    });

    it('omits optional params when not provided or empty arrays', async () => {
      await mockFetch(okResponse({ data: [] }));
      const fetch = await getFetchWithAuth();

      await getVesselsInAFleet('f1', 25, 5, undefined, [], [], undefined, []);

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).not.toContain('sort_by');
      expect(calledUrl).not.toContain('flag_code');
      expect(calledUrl).not.toContain('vessel_type');
      expect(calledUrl).not.toContain('vessel_class');
      expect(calledUrl).not.toContain('navigational_status');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(500, { message: 'Server Error' }));
      await expect(getVesselsInAFleet('f1')).rejects.toThrow('Server Error');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(getVesselsInAFleet('f1')).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(getVesselsInAFleet('f1')).rejects.toThrow(
        'Validation failed',
      );
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(getVesselsInAFleet('f1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(getVesselsInAFleet('f1')).rejects.toThrow(
        'Internal Server Error',
      );
    });
  });

  describe('createFleet', () => {
    const payload: ICreateFleets = {
      name: 'New Fleet',
      description: 'desc',
      imo_numbers: ['1234567'],
    };

    it('creates and returns a fleet', async () => {
      const data = { id: 'f1', name: 'New Fleet' };
      await mockFetch(okResponse(data));

      const result = await createFleet(payload);

      expect(result).toEqual(data);
    });

    it('calls POST to the correct URL with JSON body', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await createFleet(payload);

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            Authorization: 'Bearer token',
            'Content-Type': 'application/json',
          }),
          body: JSON.stringify(payload),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Create failed' }));
      await expect(createFleet(payload)).rejects.toThrow('Create failed');
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(createFleet(payload)).rejects.toThrow('Plain text error');
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(createFleet(payload)).rejects.toThrow(
        'Internal Server Error',
      );
    });
  });

  describe('updateFleet', () => {
    const payload: IUpdateFleets = {
      name: 'Updated Fleet',
      description: 'desc',
    };

    it('updates and returns a fleet', async () => {
      const data = { id: 'f1', name: 'Updated Fleet' };
      await mockFetch(okResponse(data));

      const result = await updateFleet('f1', payload);

      expect(result).toEqual(data);
    });

    it('calls PUT to the correct URL with JSON body', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await updateFleet('f1', payload);

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets/f1',
        expect.objectContaining({
          method: 'PUT',
          headers: expect.objectContaining({
            Authorization: 'Bearer token',
            'Content-Type': 'application/json',
          }),
          body: JSON.stringify(payload),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Update failed' }));
      await expect(updateFleet('f1', payload)).rejects.toThrow('Update failed');
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(updateFleet('f1', payload)).rejects.toThrow(
        'Plain text error',
      );
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(updateFleet('f1', payload)).rejects.toThrow(
        'Internal Server Error',
      );
    });
  });

  describe('deleteFleet', () => {
    it('resolves when deletion succeeds', async () => {
      await mockFetch(okResponse(undefined));

      await expect(deleteFleet('f1')).resolves.toBeUndefined();
    });

    it('calls DELETE to the correct URL', async () => {
      await mockFetch(okResponse(undefined));
      const fetch = await getFetchWithAuth();

      await deleteFleet('f1');

      expect(fetch).toHaveBeenCalledWith(
        'https://fleet-management.api/fleet-management/v2/fleets/f1',
        expect.objectContaining({
          method: 'DELETE',
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Delete failed' }));
      await expect(deleteFleet('f1')).rejects.toThrow('Delete failed');
    });

    it('falls back to raw text when body is not valid JSON', async () => {
      await mockFetch(errorWithPlainText(500, 'Plain text error'));
      await expect(deleteFleet('f1')).rejects.toThrow('Plain text error');
    });

    it('falls back to statusText when body and text are empty', async () => {
      await mockFetch(errorWithNoBody(500, 'Internal Server Error'));
      await expect(deleteFleet('f1')).rejects.toThrow('Internal Server Error');
    });
  });
});
