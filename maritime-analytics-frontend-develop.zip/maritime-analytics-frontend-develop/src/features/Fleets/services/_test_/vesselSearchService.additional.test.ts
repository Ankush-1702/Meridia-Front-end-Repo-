import { beforeEach, describe, expect, it, vi } from 'vitest';
import { searchVesselsforFleets, verifyVessels } from '../vesselSearchService';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

vi.mock('@/features/auth/utils/authUtil', () => ({ fetchWithAuth: vi.fn() }));
vi.mock('@/shared/utils/authHeaders', () => ({ getAuthHeaders: vi.fn() }));
vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  FLEET_MANAGEMENT_BASE_API_URL: 'https://fleet-management.api',
}));

describe('vesselSearchService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(getAuthHeaders).mockReturnValue({
      Authorization: 'Bearer token',
    });
  });

  it('searches by trimmed IMO when the query is seven digits', async () => {
    const body = { data: [], meta: { total_count: 0 } };
    vi.mocked(fetchWithAuth).mockResolvedValue({
      ok: true,
      json: async () => body,
    } as Response);

    await expect(searchVesselsforFleets(' 1234567 ', 20, 5)).resolves.toEqual(
      body,
    );

    const [url, init] = vi.mocked(fetchWithAuth).mock.calls[0];
    const parsed = new URL(String(url));
    expect(parsed.searchParams.get('imo')).toBe('1234567');
    expect(parsed.searchParams.has('name_contains')).toBe(false);
    expect(parsed.searchParams.get('limit')).toBe('20');
    expect(parsed.searchParams.get('offset')).toBe('5');
    expect(init?.headers).toEqual({ Authorization: 'Bearer token' });
  });

  it('searches by trimmed name for non-IMO queries', async () => {
    vi.mocked(fetchWithAuth).mockResolvedValue({
      ok: true,
      json: async () => ({ data: [] }),
    } as Response);

    await searchVesselsforFleets('  Blue Star  ', 10, 0);

    const [url] = vi.mocked(fetchWithAuth).mock.calls[0];
    expect(new URL(String(url)).searchParams.get('name_contains')).toBe(
      'Blue Star',
    );
    expect(new URL(String(url)).searchParams.has('imo')).toBe(false);
  });

  it('posts IMO verification as JSON', async () => {
    const response = { data: { found: [], invalid: [] } };
    vi.mocked(fetchWithAuth).mockResolvedValue({
      ok: true,
      json: async () => response,
    } as Response);

    await expect(verifyVessels(['1234567'])).resolves.toEqual(response);

    const [, init] = vi.mocked(fetchWithAuth).mock.calls[0];
    expect(init?.method).toBe('POST');
    expect(init?.headers).toEqual({
      Authorization: 'Bearer token',
      'Content-Type': 'application/json',
    });
    expect(init?.body).toBe(JSON.stringify({ imos: ['1234567'] }));
  });

  it('posts CSV verification as multipart form data without a JSON content type', async () => {
    const response = { data: { found: [], invalid: [] } };
    const csv = new File(['imo\n1234567'], 'vessels.csv', { type: 'text/csv' });
    vi.mocked(fetchWithAuth).mockResolvedValue({
      ok: true,
      json: async () => response,
    } as Response);

    await expect(verifyVessels(undefined, csv)).resolves.toEqual(response);

    const [, init] = vi.mocked(fetchWithAuth).mock.calls[0];
    expect(init?.method).toBe('POST');
    expect(init?.body).toBeInstanceOf(FormData);
    expect((init?.body as FormData).get('file')).toBe(csv);
    expect(init?.headers).toEqual({ Authorization: 'Bearer token' });
  });

  it('throws the API error for failed searches and verifications', async () => {
    vi.mocked(fetchWithAuth).mockResolvedValue({
      ok: false,
      statusText: 'Bad Request',
      text: async () => JSON.stringify({ message: 'invalid input' }),
    } as Response);

    await expect(searchVesselsforFleets('name', 10, 0)).rejects.toThrow(
      'invalid input',
    );
    await expect(verifyVessels(['bad'])).rejects.toThrow('invalid input');
  });
});
