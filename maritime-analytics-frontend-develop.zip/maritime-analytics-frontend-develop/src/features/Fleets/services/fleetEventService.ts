// import eventsResponseJson from '../../../../EventsResponse.json?raw';
import {
  FLEET_MANAGEMENT_BASE_API_URL,
  FLEET_MANAGEMENT_SLUG,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  FleetEventResponse,
  FleetEventType,
} from '@/features/Fleets/types/fleetEventTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

// const eventsResponseFixture = JSON.parse(
//   eventsResponseJson,
// ) as unknown as FleetEventResponse;

export async function getFleetEvents(
  fleetId: string,
  eventType: FleetEventType[],
  from: string,
  to: string,
  offset: number,
  limit: number = 500,
): Promise<FleetEventResponse> {
  // // Temporary fixture override for local fleet events grid debugging.
  // if (import.meta.env.DEV) {
  //   return eventsResponseFixture;
  // }

  const params = new URLSearchParams({
    limit: limit.toString() || '500',
    offset: offset.toString() || '0',
    timestamp_start: from,
    timestamp_end: to,
  });
  if (eventType.length) params.append('event_type', eventType.join(','));
  // const url = `http://internal-analytics-api-572865986.us-east-1.elb.amazonaws.com/v2/fleets/${fleetId}/events?${params.toString()}`;
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/${FLEET_MANAGEMENT_SLUG}/fleets/${fleetId}/events?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });
  await throwOnError(res, 'Failed to get fleet events');
  return res.json();
}
