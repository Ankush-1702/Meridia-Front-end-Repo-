import { FLEET_MANAGEMENT_BASE_API_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { IFleetExportBody } from '@/features/Fleets/types/fleetTypes';
import { EventsExportResponse } from '@/shared/services/exportServices/exportTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';
import { throwOnError } from '@/shared/utils/errorHandling';

export async function triggerFleetCsvExport(
  fleetId: string,
  body: IFleetExportBody,
): Promise<EventsExportResponse> {
  const url = `${FLEET_MANAGEMENT_BASE_API_URL}/fleet-management/v2/fleets/${fleetId}/exports/vessels`;
  const res = await fetchWithAuth(url, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(body),
  });
  await throwOnError(res, 'Failed to initiate exports');
  return res.json();
}
