import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import CreateFleetDetailsCard from '../CreateFleetDetailsCard';

describe('CreateFleetDetailsCard', () => {
  it('renders the current name and description', () => {
    render(
      <CreateFleetDetailsCard
        name="My Fleet"
        description="My description"
        setName={vi.fn()}
        setDescription={vi.fn()}
      />,
    );

    expect(screen.getByDisplayValue('My Fleet')).toBeInTheDocument();
    expect(screen.getByDisplayValue('My description')).toBeInTheDocument();
  });

  it('calls setName when the name input changes', () => {
    const setName = vi.fn();
    render(
      <CreateFleetDetailsCard
        name=""
        description=""
        setName={setName}
        setDescription={vi.fn()}
      />,
    );

    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'New Name' },
    });

    expect(setName).toHaveBeenCalledWith('New Name');
  });

  it('calls setDescription when the description textarea changes', () => {
    const setDescription = vi.fn();
    render(
      <CreateFleetDetailsCard
        name=""
        description=""
        setName={vi.fn()}
        setDescription={setDescription}
      />,
    );

    fireEvent.change(screen.getByPlaceholderText('What this fleet is for'), {
      target: { value: 'New description' },
    });

    expect(setDescription).toHaveBeenCalledWith('New description');
  });

  it('shows the name character count', () => {
    render(
      <CreateFleetDetailsCard
        name="abc"
        description=""
        setName={vi.fn()}
        setDescription={vi.fn()}
      />,
    );

    expect(screen.getByText('3/100')).toBeInTheDocument();
  });

  it('shows the description character count', () => {
    render(
      <CreateFleetDetailsCard
        name=""
        description="abcdef"
        setName={vi.fn()}
        setDescription={vi.fn()}
      />,
    );

    expect(screen.getByText('6/200')).toBeInTheDocument();
  });

  it('does not show the name error before the field is touched', () => {
    render(
      <CreateFleetDetailsCard
        name=""
        description=""
        setName={vi.fn()}
        setDescription={vi.fn()}
        nameError="Name is required"
      />,
    );

    expect(screen.queryByText('Name is required')).not.toBeInTheDocument();
  });

  it('shows the name error after the field is touched via change', () => {
    render(
      <CreateFleetDetailsCard
        name=""
        description=""
        setName={vi.fn()}
        setDescription={vi.fn()}
        nameError="Name is required"
      />,
    );

    fireEvent.change(screen.getAllByRole('textbox')[0], {
      target: { value: 'a' },
    });

    expect(screen.getByText('Name is required')).toBeInTheDocument();
  });

  it('shows the name error after the field is touched via blur', () => {
    render(
      <CreateFleetDetailsCard
        name=""
        description=""
        setName={vi.fn()}
        setDescription={vi.fn()}
        nameError="Name is required"
      />,
    );

    fireEvent.blur(screen.getAllByRole('textbox')[0]);

    expect(screen.getByText('Name is required')).toBeInTheDocument();
  });
});
