import { act, render, screen } from '@testing-library/react';
import mapboxgl from 'mapbox-gl';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import VesselMiniMap from '../VesselMiniMap';
import { VesselData } from '@/features/Fleets/types/fleetTypes';

const mockOn = vi.fn();
const mockRemove = vi.fn();
const mockResize = vi.fn();
const mockMarkerSetLngLat = vi.fn();
const mockMarkerAddTo = vi.fn();
const mockMarkerRemove = vi.fn();
const mockMarkerInstance = {
  setLngLat: mockMarkerSetLngLat,
  addTo: mockMarkerAddTo,
  remove: mockMarkerRemove,
};
mockMarkerSetLngLat.mockReturnValue(mockMarkerInstance);
mockMarkerAddTo.mockReturnValue(mockMarkerInstance);

vi.mock('mapbox-gl', () => ({
  default: {
    Map: vi.fn().mockImplementation(function () {
      return {
        on: mockOn,
        remove: mockRemove,
        resize: mockResize,
      };
    }),
    Marker: vi.fn().mockImplementation(function () {
      return mockMarkerInstance;
    }),
  },
}));

let mockToken = 'test-token';

vi.mock('@/app/config/config', () => ({
  get MAPBOX_TOKEN() {
    return mockToken;
  },
  MAP_STYLES: undefined,
}));

vi.mock('@/shared/constants/overviewMapConstants', () => ({
  MAP_STYLES: { dark: 'dark-style', light: 'light-style' },
  MARKER_SIZE: 20,
  HOVER_SIZE: 32,
}));

let mockThemeMode: 'light' | 'dark' | 'system' = 'light';

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: mockThemeMode }),
}));

vi.mock('@/shared/components/MapboxMissingToken', () => ({
  default: () => <div>MapboxMissingToken</div>,
}));

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    ...overrides,
  };
}

describe('VesselMiniMap', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockToken = 'test-token';
    mockThemeMode = 'light';
    mockMarkerSetLngLat.mockReturnValue(mockMarkerInstance);
    mockMarkerAddTo.mockReturnValue(mockMarkerInstance);
    window.matchMedia = vi.fn().mockReturnValue({ matches: false });
  });

  it('initializes the map with the light style in light mode', () => {
    render(<VesselMiniMap vessel={makeVessel()} />);

    expect(mapboxgl.Map).toHaveBeenCalledWith(
      expect.objectContaining({ style: 'light-style' }),
    );
  });

  it('initializes the map with the dark style in dark mode', () => {
    mockThemeMode = 'dark';

    render(<VesselMiniMap vessel={makeVessel()} />);

    expect(mapboxgl.Map).toHaveBeenCalledWith(
      expect.objectContaining({ style: 'dark-style' }),
    );
  });

  it('centers the map on the vessel position when valid', () => {
    render(<VesselMiniMap vessel={makeVessel()} />);

    expect(mapboxgl.Map).toHaveBeenCalledWith(
      expect.objectContaining({ center: [4.0, 52.0], zoom: 8 }),
    );
  });

  it('shows the missing-token message when MAPBOX_TOKEN is empty', () => {
    mockToken = '';

    render(<VesselMiniMap vessel={makeVessel()} />);

    expect(screen.getByText('MapboxMissingToken')).toBeInTheDocument();
  });

  it('does not show the missing-token message when a token is present', () => {
    render(<VesselMiniMap vessel={makeVessel()} />);

    expect(screen.queryByText('MapboxMissingToken')).not.toBeInTheDocument();
  });

  it('creates a vessel marker once the map is ready and position is valid', () => {
    mockOn.mockImplementation((event: string, cb: () => void) => {
      if (event === 'load') cb();
    });

    act(() => {
      render(<VesselMiniMap vessel={makeVessel()} />);
    });

    expect(mapboxgl.Marker).toHaveBeenCalled();
    expect(mockMarkerSetLngLat).toHaveBeenCalledWith([4.0, 52.0]);
    expect(mockMarkerAddTo).toHaveBeenCalled();
  });

  it('does not create a marker when the vessel position is invalid', () => {
    mockOn.mockImplementation((event: string, cb: () => void) => {
      if (event === 'load') cb();
    });

    act(() => {
      render(
        <VesselMiniMap
          vessel={makeVessel({
            vessel_position: {
              ...makeVessel().vessel_position!,
              latitude: NaN,
              longitude: NaN,
            },
          })}
        />,
      );
    });

    expect(mapboxgl.Marker).not.toHaveBeenCalled();
  });

  it('removes the marker on unmount', () => {
    mockOn.mockImplementation((event: string, cb: () => void) => {
      if (event === 'load') cb();
    });

    let unmount: () => void = () => {};
    act(() => {
      unmount = render(<VesselMiniMap vessel={makeVessel()} />).unmount;
    });

    act(() => {
      unmount();
    });

    expect(mockMarkerRemove).toHaveBeenCalled();
  });
});
