import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import SubHeadingToggle from '../SubHeadingToggle';

describe('SubHeadingToggle', () => {
  it('shows "Show top 5" when view is "all"', () => {
    render(<SubHeadingToggle view="all" onChange={vi.fn()} />);

    expect(screen.getByText('Show top 5')).toBeInTheDocument();
  });

  it('shows "Show all (count)" when view is "top5"', () => {
    render(<SubHeadingToggle view="top5" onChange={vi.fn()} count={12} />);

    expect(screen.getByText('Show all (12)')).toBeInTheDocument();
  });

  it('calls onChange with "top5" when clicked while view is "all"', () => {
    const onChange = vi.fn();
    render(<SubHeadingToggle view="all" onChange={onChange} />);

    fireEvent.click(screen.getByText('Show top 5'));

    expect(onChange).toHaveBeenCalledWith('top5');
  });

  it('calls onChange with "all" when clicked while view is "top5"', () => {
    const onChange = vi.fn();
    render(<SubHeadingToggle view="top5" onChange={onChange} count={5} />);

    fireEvent.click(screen.getByText('Show all (5)'));

    expect(onChange).toHaveBeenCalledWith('all');
  });

  it('is disabled when disabled prop is true', () => {
    render(<SubHeadingToggle view="all" onChange={vi.fn()} disabled />);

    expect(screen.getByText('Show top 5')).toBeDisabled();
  });

  it('does not call onChange when disabled and clicked', () => {
    const onChange = vi.fn();
    render(<SubHeadingToggle view="all" onChange={onChange} disabled />);

    fireEvent.click(screen.getByText('Show top 5'));

    expect(onChange).not.toHaveBeenCalled();
  });

  it('accepts a string count value', () => {
    render(<SubHeadingToggle view="top5" onChange={vi.fn()} count="10+" />);

    expect(screen.getByText('Show all (10+)')).toBeInTheDocument();
  });
});
