import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import LocationSection from '../LocationSection';
import type { ZoneInformation } from '@/features/Fleets/types/fleetEventTypes';

vi.mock('../LocationMiniMap', () => ({
  default: (props: { label?: string }) => (
    <div>Map: {props.label ?? 'unknown'}</div>
  ),
}));

const location: ZoneInformation = {
  centroid: { latitude: 10, longitude: 20 },
  country_official_name: 'Test Country',
  country_code: 'TC',
  description: undefined,
  id: 'location-1',
  name: 'Test Port',
  sub_type: 'Harbour',
  type: 'Ports',
  unlocode: 'TST01',
  country_common_name: 'Test Country',
  sub_division_code: undefined,
  sub_division_name: undefined,
  wpi_number: undefined,
};

describe('LocationSection', () => {
  it('shows location metadata and opens the selected location', () => {
    const setViewLocation = vi.fn();
    render(
      <LocationSection
        eventType="PORT_ARRIVAL"
        location={location}
        setViewLocation={setViewLocation}
      />,
    );

    expect(screen.getByText('Test Port')).toBeInTheDocument();
    expect(screen.getByText('Port · TST01 · Test Country')).toBeInTheDocument();
    expect(screen.getByText('Map: Test Port')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /Test Port/ }));
    expect(setViewLocation).toHaveBeenCalledWith(true);
  });

  it('uses a zone card and position rows for zone entry events', () => {
    const zone = { ...location, type: 'Jurisdictional', sub_type: 'EEZ' };
    render(
      <LocationSection
        eventType="AIS_GAP"
        location={zone}
        setViewLocation={vi.fn()}
        event={{
          callSign: 'CALL',
          flag: 'Flag',
          flagCode: 'NG',
          imo: 'IMO-1',
          mmsi: 'MMSI-1',
          vesselName: 'Vessel',
          vesselType: 'Cargo',
          gapStartedLatitude: 1,
          gapStartedLongitude: -2,
          gapEndedLatitude: 3,
          gapEndedLongitude: -4,
        }}
      />,
    );

    expect(screen.getByText('Zone · EEZ · Test Country')).toBeInTheDocument();
    expect(screen.getByText('1.000°N, 2.000°W')).toBeInTheDocument();
    expect(screen.getByText('3.000°N, 4.000°W')).toBeInTheDocument();
  });

  it('hides the map for port state control and tolerates missing location data', () => {
    const { rerender } = render(
      <LocationSection
        eventType="PORT_STATE_CONTROL"
        setViewLocation={vi.fn()}
      />,
    );
    expect(screen.queryByText(/Map:/)).not.toBeInTheDocument();
    expect(screen.queryByRole('button')).not.toBeInTheDocument();

    rerender(
      <LocationSection eventType="PORT_ARRIVAL" setViewLocation={vi.fn()} />,
    );
    expect(screen.getByText('Map: unknown')).toBeInTheDocument();
  });
});
