import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import EventsSlideOutDetails from '../EventsSlideOutDetails';
import type { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';

function renderEvent(values: Partial<FlatFleetEventsResponse>) {
  const event = {
    callSign: 'CALL',
    flag: 'Flag',
    flagCode: 'NG',
    imo: 'IMO-1',
    mmsi: 'MMSI-1',
    vesselName: 'Vessel',
    vesselType: 'Cargo',
    ...values,
  } as FlatFleetEventsResponse;
  render(<EventsSlideOutDetails event={event} />);
}

describe('EventsSlideOutDetails', () => {
  it('shows port state control details and false detention distinctly', () => {
    renderEvent({
      eventType: 'PORT_STATE_CONTROL',
      authority: 'Port Authority',
      inspectionType: 'Initial',
      detained: false,
      numberOfDefects: 3,
    });

    expect(screen.getByText('Details')).toBeInTheDocument();
    expect(screen.getByText('Port Authority')).toBeInTheDocument();
    expect(screen.getByText('Initial')).toBeInTheDocument();
    expect(screen.getByText('No')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
  });

  it.each([
    ['POSITIONAL_DISCREPANCY', 'Ongoing'],
    ['STS_PAIRING', 'Ongoing'],
    ['AIS_GAP', 'Ongoing'],
  ] as const)('shows an ongoing duration for %s', (eventType, duration) => {
    renderEvent({ eventType, duration });
    expect(screen.getByText(duration)).toBeInTheDocument();
  });

  it('shows movement details for arrival and departure event families', () => {
    const { unmount } = render(
      <EventsSlideOutDetails
        event={
          {
            callSign: 'CALL',
            flag: 'Flag',
            flagCode: 'NG',
            imo: 'IMO-1',
            mmsi: 'MMSI-1',
            vesselName: 'Vessel',
            vesselType: 'Cargo',
            eventType: 'ZONE_ENTRY',
            speed: 5,
            course: 90,
            draught: 8,
            navigationalStatusStatus: 'Moored',
          } as FlatFleetEventsResponse
        }
      />,
    );
    expect(screen.getByText('5 kn')).toBeInTheDocument();
    expect(screen.getByText('90°')).toBeInTheDocument();
    expect(screen.getByText('8 m')).toBeInTheDocument();
    expect(screen.getByText('Moored')).toBeInTheDocument();
    unmount();

    renderEvent({
      eventType: 'PORT_DEPARTURE',
      speed: undefined,
      course: undefined,
    });
    expect(screen.getAllByText('-')).toHaveLength(5);
  });
});
