import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import SlideOutPanelHeader from '../SlideOutPanelHeader';

const mockNavigate = vi.fn();
let mockMara2Enabled = true;

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

vi.mock('@/app/config/config', () => ({
  isMara2Enabled: () => mockMara2Enabled,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode: string }) => <span>flag:{flagCode}</span>,
}));

describe('SlideOutPanelHeader', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockMara2Enabled = true;
  });

  it('renders the vessel name, flag, and IMO', () => {
    render(
      <SlideOutPanelHeader
        vesselName="Test Vessel"
        vesselFlagCode="NOR"
        vesselImo="1234567"
      />,
    );

    expect(screen.getByText('Test Vessel')).toBeInTheDocument();
    expect(screen.getByText('IMO 1234567')).toBeInTheDocument();
    expect(screen.getByText('flag:NOR')).toBeInTheDocument();
  });

  it('navigates to the vessel analytics page when the name is clicked', () => {
    render(
      <SlideOutPanelHeader
        vesselName="Test Vessel"
        vesselFlagCode="NOR"
        vesselImo="1234567"
      />,
    );

    fireEvent.click(screen.getByText('Test Vessel'));

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/vessel/1234567');
  });

  it('calls onClose when the close button is clicked', () => {
    const onClose = vi.fn();
    render(
      <SlideOutPanelHeader
        vesselName="Test Vessel"
        vesselFlagCode="NOR"
        vesselImo="1234567"
        onClose={onClose}
      />,
    );

    fireEvent.click(screen.getByLabelText('Close panel'));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('shows the Ask IQ button when mara2 is enabled and navigates on click', () => {
    render(
      <SlideOutPanelHeader
        vesselName="Test Vessel"
        vesselFlagCode="NOR"
        vesselImo="1234567"
      />,
    );

    const askIqButton = screen.getByText('Ask IQ');
    fireEvent.click(askIqButton);

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/chat2', {
      state: {
        initialPrompt:
          'Summarise Test Vessel (IMO: 1234567) over the last 30 days: current voyage status, port calls, zone events, AIS gaps, and anything else that is notable.',
      },
    });
  });

  it('hides the Ask IQ button when mara2 is disabled', () => {
    mockMara2Enabled = false;

    render(
      <SlideOutPanelHeader
        vesselName="Test Vessel"
        vesselFlagCode="NOR"
        vesselImo="1234567"
      />,
    );

    expect(screen.queryByText('Ask IQ')).not.toBeInTheDocument();
  });

  it('does not navigate to Ask IQ when vessel name is empty', () => {
    render(
      <SlideOutPanelHeader
        vesselName=""
        vesselFlagCode="NOR"
        vesselImo="1234567"
      />,
    );

    fireEvent.click(screen.getByText('Ask IQ'));

    expect(mockNavigate).not.toHaveBeenCalledWith(
      '/analytics/chat2',
      expect.anything(),
    );
  });
});
