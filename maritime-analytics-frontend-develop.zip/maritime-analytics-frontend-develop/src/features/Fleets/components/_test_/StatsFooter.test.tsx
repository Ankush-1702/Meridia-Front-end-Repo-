import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import StatsFooter from '../StatsFooter';

const stats = {
  avgAge: 12,
  avgDwt: 45,
  topFlag: 'Panama',
  topType: 'Bulk carrier',
};

describe('StatsFooter', () => {
  it('shows "Show Stats" and hides stat rows by default', () => {
    render(<StatsFooter stats={stats} />);

    expect(screen.getByText('Show Stats')).toBeInTheDocument();
    expect(screen.queryByText('Average age')).not.toBeInTheDocument();
  });

  it('expands to show stat rows when clicked', () => {
    render(<StatsFooter stats={stats} />);

    fireEvent.click(screen.getByText('Show Stats'));

    expect(screen.getByText('Hide Stats')).toBeInTheDocument();
    expect(screen.getByText('Average age')).toBeInTheDocument();
    expect(screen.getByText('12 yrs')).toBeInTheDocument();
    expect(screen.getByText('45k')).toBeInTheDocument();
    expect(screen.getByText('Panama')).toBeInTheDocument();
    expect(screen.getByText('Bulk carrier')).toBeInTheDocument();
  });

  it('collapses again on a second click', () => {
    render(<StatsFooter stats={stats} />);

    const button = screen.getByText('Show Stats');
    fireEvent.click(button);
    fireEvent.click(screen.getByText('Hide Stats'));

    expect(screen.getByText('Show Stats')).toBeInTheDocument();
    expect(screen.queryByText('Average age')).not.toBeInTheDocument();
  });
});
