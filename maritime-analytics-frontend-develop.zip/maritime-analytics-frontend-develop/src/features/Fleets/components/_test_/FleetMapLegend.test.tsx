import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import FleetMapLegend from '../FleetMapLegend';

const baseProps = {
  activeTab: 'Type' as const,
  onTabChange: vi.fn(),
  types: ['Bulk carrier', 'Oil Tanker'],
  flags: ['NOR', 'PAN'],
  visibleTypes: {},
  visibleFlags: {},
  onToggleType: vi.fn(),
  onToggleFlag: vi.fn(),
};

describe('FleetMapLegend', () => {
  it('renders collapsed by default, showing only the header', () => {
    render(<FleetMapLegend {...baseProps} />);

    expect(screen.getByText('Legend')).toBeInTheDocument();
    expect(screen.queryByText('By')).not.toBeInTheDocument();
  });

  it('expands to show tab options and legend items when clicked', () => {
    render(<FleetMapLegend {...baseProps} />);

    fireEvent.click(screen.getByText('Legend'));

    expect(screen.getByText('By')).toBeInTheDocument();
    expect(screen.getByText('Type')).toBeInTheDocument();
  });

  it('renders one row per type when the Type tab is active', () => {
    render(<FleetMapLegend {...baseProps} />);
    fireEvent.click(screen.getByText('Legend'));

    expect(screen.getAllByText('Bulk Carrier').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Oil Tanker').length).toBeGreaterThan(0);
  });

  it('checks a type checkbox by default when not explicitly hidden', () => {
    render(<FleetMapLegend {...baseProps} />);
    fireEvent.click(screen.getByText('Legend'));

    const checkboxes = screen.getAllByRole('checkbox');
    expect(checkboxes[0]).toBeChecked();
  });

  it('unchecks a type checkbox when explicitly set to false', () => {
    render(
      <FleetMapLegend
        {...baseProps}
        visibleTypes={{ 'Bulk carrier': false }}
      />,
    );
    fireEvent.click(screen.getByText('Legend'));

    const checkboxes = screen.getAllByRole('checkbox');
    expect(checkboxes[0]).not.toBeChecked();
  });

  it('calls onToggleType when a type checkbox is toggled', () => {
    const onToggleType = vi.fn();
    render(<FleetMapLegend {...baseProps} onToggleType={onToggleType} />);
    fireEvent.click(screen.getByText('Legend'));

    fireEvent.click(screen.getAllByRole('checkbox')[0]);

    expect(onToggleType).toHaveBeenCalledWith('Bulk carrier', false);
  });
});
