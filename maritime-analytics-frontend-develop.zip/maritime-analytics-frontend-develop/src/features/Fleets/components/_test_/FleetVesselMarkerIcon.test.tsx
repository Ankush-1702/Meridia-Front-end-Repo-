import { render } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import FleetVesselMarkerIcon from '../FleetVesselMarkerIcon';

describe('FleetVesselMarkerIcon', () => {
  it('renders an svg with the given size', () => {
    const { container } = render(
      <FleetVesselMarkerIcon size={24} rotationDeg={0} color="#123456" />,
    );

    const svg = container.querySelector('svg');
    expect(svg).toHaveAttribute('width', '24');
    expect(svg).toHaveAttribute('height', '24');
  });

  it('applies the rotation transform', () => {
    const { container } = render(
      <FleetVesselMarkerIcon size={24} rotationDeg={90} color="#123456" />,
    );

    const svg = container.querySelector('svg');
    expect(svg).toHaveStyle({ transform: 'rotate(90deg)' });
  });

  it('applies the given fill color to the path', () => {
    const { container } = render(
      <FleetVesselMarkerIcon size={24} rotationDeg={0} color="#abcdef" />,
    );

    const path = container.querySelector('path[fill]');
    expect(path).toHaveAttribute('fill', '#abcdef');
  });

  it('uses a stronger drop-shadow filter when hovered', () => {
    const { container } = render(
      <FleetVesselMarkerIcon
        size={24}
        rotationDeg={0}
        color="#123456"
        isHovered
      />,
    );

    const svg = container.querySelector('svg');
    expect(svg?.getAttribute('style')).toContain(
      'drop-shadow(0 0 3px rgba(0,0,0,0.5))',
    );
  });

  it('uses the default drop-shadow filter when not hovered', () => {
    const { container } = render(
      <FleetVesselMarkerIcon size={24} rotationDeg={0} color="#123456" />,
    );

    const svg = container.querySelector('svg');
    expect(svg?.getAttribute('style')).toContain(
      'drop-shadow(0 1px 1px rgba(0,0,0,0.3))',
    );
  });
});
