import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import LocationSlideOutBody from '../LocationSlideOutBody';
import type { ZoneInformation } from '@/features/Fleets/types/fleetEventTypes';
import type { ILiveDataResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

function makeLocation(type: string): ZoneInformation {
  return {
    centroid: { latitude: 0, longitude: 0 },
    country_official_name: 'Test Country',
    country_code: 'TC',
    description: undefined,
    id: 'location-1',
    name: 'Test Location',
    sub_type: 'Test subtype',
    type,
    unlocode: 'TST01',
    country_common_name: 'Test Country',
    sub_division_code: undefined,
    sub_division_name: undefined,
    wpi_number: undefined,
  };
}

function makeLocationEvents(totals: object | null): ILiveDataResponse {
  return { totals } as unknown as ILiveDataResponse;
}

function expectCardValue(label: string, value: string | number) {
  const valueElement = screen.getByText(label).parentElement?.firstElementChild;
  if (!valueElement) throw new Error(`Could not find value for ${label}`);
  expect(valueElement).toHaveTextContent(String(value));
}

describe('LocationSlideOutBody', () => {
  it('shows zone movement counts with Entries, Exits, and In zone labels', () => {
    render(
      <LocationSlideOutBody
        location={makeLocation('Jurisdictional')}
        vesselsInPortOrZone={7}
        locationEvents={makeLocationEvents({ entries: 12, exits: 5 })}
      />,
    );

    expect(screen.getByText('Entries')).toBeInTheDocument();
    expect(screen.getByText('Exits')).toBeInTheDocument();
    expect(screen.getByText('In zone')).toBeInTheDocument();
    expectCardValue('Entries', 12);
    expectCardValue('Exits', 5);
    expectCardValue('In zone', 7);
  });

  it('shows port movement counts with Arrivals, Departures, and In port labels', () => {
    render(
      <LocationSlideOutBody
        location={makeLocation('Ports')}
        vesselsInPortOrZone={9}
        locationEvents={makeLocationEvents({ arrivals: 14, departures: 8 })}
      />,
    );

    expect(screen.getByText('Arrivals')).toBeInTheDocument();
    expect(screen.getByText('Departures')).toBeInTheDocument();
    expect(screen.getByText('In port')).toBeInTheDocument();
    expectCardValue('Arrivals', 14);
    expectCardValue('Departures', 8);
    expectCardValue('In port', 9);
  });

  it('shows the fallback when movement totals are unavailable', () => {
    render(
      <LocationSlideOutBody
        location={makeLocation('Ports')}
        vesselsInPortOrZone={0}
        locationEvents={makeLocationEvents(null)}
      />,
    );

    expectCardValue('Arrivals', '-');
    expectCardValue('Departures', '-');
  });
});
