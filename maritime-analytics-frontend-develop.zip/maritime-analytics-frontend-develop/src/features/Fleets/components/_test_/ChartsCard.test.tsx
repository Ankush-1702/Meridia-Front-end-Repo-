import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ChartsCard from '../ChartsCard';
import { Coverage } from '../ShowCoverage';

vi.mock('@/shared/components/ChartsDownloadDropDown', () => ({
  default: ({ loading, hasData }: { loading?: boolean; hasData?: boolean }) => (
    <div data-testid="download-dropdown">
      {String(loading)}-{String(hasData)}
    </div>
  ),
}));

describe('ChartsCard', () => {
  it('renders the title', () => {
    render(<ChartsCard title="Vessel Types" />);

    expect(screen.getByText('Vessel Types')).toBeInTheDocument();
  });

  it('shows the loading template when isLoading is true', () => {
    const { container } = render(<ChartsCard title="Vessel Types" isLoading />);

    expect(screen.getByText('Loading...')).toBeInTheDocument();
    expect(container.querySelector('[role="status"]')).toBeInTheDocument();
  });

  it('shows the chart when hasData is true and not loading', () => {
    render(
      <ChartsCard title="Vessel Types" hasData chart={<div>My Chart</div>} />,
    );

    expect(screen.getByText('My Chart')).toBeInTheDocument();
    expect(screen.queryByText('No data available')).not.toBeInTheDocument();
  });

  it('shows the empty state when not loading and there is no data', () => {
    render(<ChartsCard title="Vessel Types" hasData={false} />);

    expect(screen.getByText('No data available')).toBeInTheDocument();
    expect(
      screen.getByText('Adjust your filters or refresh the page.'),
    ).toBeInTheDocument();
  });

  it('prefers the loading state over the chart even when hasData is true', () => {
    render(
      <ChartsCard
        title="Vessel Types"
        isLoading
        hasData
        chart={<div>My Chart</div>}
      />,
    );

    expect(screen.getByText('Loading...')).toBeInTheDocument();
    expect(screen.queryByText('My Chart')).not.toBeInTheDocument();
  });

  it('renders the subHeading and subHeadingAction', () => {
    render(
      <ChartsCard
        title="Vessel Types"
        subHeading="Last 30 days"
        subHeadingAction={<span>Refresh</span>}
      />,
    );

    expect(
      screen.getByText((_, element) =>
        Boolean(element?.textContent?.startsWith('Last 30 days')),
      ),
    ).toBeInTheDocument();
    expect(screen.getByText('Refresh')).toBeInTheDocument();
  });

  it('renders the tabGroup', () => {
    render(<ChartsCard title="Vessel Types" tabGroup={<div>Tab Group</div>} />);

    expect(screen.getByText('Tab Group')).toBeInTheDocument();
  });

  it('renders the coverage note when showCoverage is true and coverage is incomplete', () => {
    const coverage: Coverage = { known: 8, total: 10, complete: false };
    render(
      <ChartsCard title="Vessel Types" showCoverage coverage={coverage} />,
    );

    expect(screen.getByText('Based on 8 of 10 vessels')).toBeInTheDocument();
  });

  it('does not render the coverage note when coverage is complete', () => {
    const coverage: Coverage = { known: 10, total: 10, complete: true };
    render(
      <ChartsCard title="Vessel Types" showCoverage coverage={coverage} />,
    );

    expect(
      screen.queryByText(/Based on \d+ of \d+ vessels/),
    ).not.toBeInTheDocument();
  });

  it('shows the "no data available" coverage message when coverage.known is 0', () => {
    const coverage: Coverage = { known: 0, total: 10, complete: false };
    render(
      <ChartsCard
        title="Vessel Types"
        showCoverage
        coverage={coverage}
        section="fleet"
      />,
    );

    expect(screen.getByText('No fleet data available')).toBeInTheDocument();
  });

  it('does not render any coverage messaging when showCoverage is false', () => {
    const coverage: Coverage = { known: 0, total: 10, complete: false };
    render(<ChartsCard title="Vessel Types" coverage={coverage} />);

    expect(screen.queryByText(/No .* data available/)).not.toBeInTheDocument();
    expect(
      screen.queryByText(/Based on \d+ of \d+ vessels/),
    ).not.toBeInTheDocument();
  });

  it('passes isLoading, hasData, onExportImage, onExportCSV through to the download dropdown', () => {
    render(<ChartsCard title="Vessel Types" isLoading={false} hasData />);

    expect(screen.getByTestId('download-dropdown')).toHaveTextContent(
      'false-true',
    );
  });
});
