import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import RenameFleetContent from '../RenameFleetContent';

describe('RenameFleetContent', () => {
  it('renders the fleet name and current value', () => {
    render(
      <RenameFleetContent
        fleetName="Original Fleet"
        name="Original Fleet"
        setName={vi.fn()}
      />,
    );

    expect(
      screen.getByText('Enter a new name for Original Fleet.'),
    ).toBeInTheDocument();
    expect(screen.getByDisplayValue('Original Fleet')).toBeInTheDocument();
  });

  it('shows the character counter', () => {
    render(
      <RenameFleetContent fleetName="Fleet" name="Fleet" setName={vi.fn()} />,
    );

    expect(screen.getByText('5/100')).toBeInTheDocument();
  });

  it('updates the counter as the name prop changes', () => {
    const { rerender } = render(
      <RenameFleetContent fleetName="Fleet" name="Fl" setName={vi.fn()} />,
    );

    expect(screen.getByText('2/100')).toBeInTheDocument();

    rerender(
      <RenameFleetContent fleetName="Fleet" name="Fleeter" setName={vi.fn()} />,
    );

    expect(screen.getByText('7/100')).toBeInTheDocument();
  });

  it('calls setName when the input changes', () => {
    const setName = vi.fn();
    render(
      <RenameFleetContent fleetName="Fleet" name="Fleet" setName={setName} />,
    );

    fireEvent.change(screen.getByDisplayValue('Fleet'), {
      target: { value: 'New Fleet' },
    });

    expect(setName).toHaveBeenCalledWith('New Fleet');
  });

  it('does not show the error message before the input is touched', () => {
    render(
      <RenameFleetContent
        fleetName="Fleet"
        name="Fleet"
        setName={vi.fn()}
        nameError="Name already exists"
      />,
    );

    expect(screen.queryByText('Name already exists')).not.toBeInTheDocument();
  });

  it('shows the error message after the input is changed', () => {
    render(
      <RenameFleetContent
        fleetName="Fleet"
        name="Fleet"
        setName={vi.fn()}
        nameError="Name already exists"
      />,
    );

    fireEvent.change(screen.getByDisplayValue('Fleet'), {
      target: { value: 'Fleet2' },
    });

    expect(screen.getByText('Name already exists')).toBeInTheDocument();
  });

  it('shows the error message after the input is blurred', () => {
    render(
      <RenameFleetContent
        fleetName="Fleet"
        name="Fleet"
        setName={vi.fn()}
        nameError="Name already exists"
      />,
    );

    fireEvent.blur(screen.getByDisplayValue('Fleet'));

    expect(screen.getByText('Name already exists')).toBeInTheDocument();
  });

  it('does not show an error message when nameError is not set, even after blur', () => {
    render(
      <RenameFleetContent fleetName="Fleet" name="Fleet" setName={vi.fn()} />,
    );

    fireEvent.blur(screen.getByDisplayValue('Fleet'));

    expect(screen.queryByText(/exists/)).not.toBeInTheDocument();
  });
});
