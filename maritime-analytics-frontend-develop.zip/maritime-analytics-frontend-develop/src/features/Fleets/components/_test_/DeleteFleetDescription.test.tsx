import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import DeleteFleetDescription from '../DeleteFleetDescription';
import { Fleet } from '@/features/Fleets/types/fleetTypes';

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    fleet_id: 'fleet-1',
    name: 'North Sea Fleet',
    description: 'desc',
    type: 'STATIC',
    vessel_count: 5,
    created_by: 'user-1',
    created_at: '2026-01-01T00:00:00Z',
    last_modified_by: 'user-1',
    last_modified_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

describe('DeleteFleetDescription', () => {
  it('renders the fleet name in the confirmation message', () => {
    render(
      <DeleteFleetDescription fleet={makeFleet({ name: 'Test Fleet' })} />,
    );

    expect(screen.getByText('Test Fleet')).toBeInTheDocument();
  });

  it('pluralizes vessel count for multiple vessels', () => {
    render(<DeleteFleetDescription fleet={makeFleet({ vessel_count: 5 })} />);

    expect(screen.getByText(/5 vessels/)).toBeInTheDocument();
  });

  it('uses singular "vessel" for a single vessel', () => {
    render(<DeleteFleetDescription fleet={makeFleet({ vessel_count: 1 })} />);

    expect(screen.getByText(/1 vessel$/)).toBeInTheDocument();
  });

  it('renders the "cannot be undone" warning', () => {
    render(<DeleteFleetDescription fleet={makeFleet()} />);

    expect(screen.getByText("This can't be undone.")).toBeInTheDocument();
  });

  it('renders all consequence messages', () => {
    render(<DeleteFleetDescription fleet={makeFleet()} />);

    expect(
      screen.getByText('The fleet definition and its vessel list are removed.'),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        'Notification settings and alerts for this fleet stop immediately.',
      ),
    ).toBeInTheDocument();
  });
});
