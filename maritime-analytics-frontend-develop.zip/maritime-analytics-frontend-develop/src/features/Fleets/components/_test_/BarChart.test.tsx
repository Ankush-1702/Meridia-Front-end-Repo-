import { render, screen } from '@testing-library/react';
import { AgChartOptions } from 'ag-charts-enterprise';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useTheme } from '@/app/context/ThemeProvider';
import Bars from '@/features/Fleets/components/BarChart';
import { FleetCompositionItems } from '@/features/Fleets/types/fleetTypes';

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: vi.fn(() => ({ theme: 'light' })),
}));

vi.mock('@/shared/lib/PoleStarCharts', () => ({
  PoleStarChart: ({ options }: { options: AgChartOptions }) => (
    <div data-testid="polestar-chart" data-options={JSON.stringify(options)} />
  ),
}));

// ── fixtures ─────────────────────────────────────────────────────────────────

const mockData: FleetCompositionItems[] = [
  { label: 'Bulk Carrier', count: 10, percentage: 50 },
  { label: 'Container', count: 10, percentage: 50 },
];

function getChartOptions() {
  const chartEl = screen.getByTestId('polestar-chart');
  return JSON.parse(chartEl.getAttribute('data-options')!);
}

// ── tests ─────────────────────────────────────────────────────────────────────

describe('Bars', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    Object.defineProperty(window, 'matchMedia', {
      value: vi.fn(() => ({ matches: false })),
      writable: true,
    });
    vi.mocked(useTheme).mockReturnValue({
      theme: 'light',
      setTheme: vi.fn(),
      saveTheme: vi.fn(),
    });
  });

  it('renders PoleStarChart with the provided data', () => {
    render(<Bars data={mockData} total={20} />);

    expect(screen.getByTestId('polestar-chart')).toBeTruthy();
    expect(getChartOptions().data).toEqual(mockData);
  });

  it('configures a bar series', () => {
    render(<Bars data={mockData} total={20} />);

    const options = getChartOptions();
    expect(options.series[0].type).toBe('bar');
    expect(options.series[0].xKey).toBe('label');
    expect(options.series[0].yKey).toBe('count');
  });

  it('uses horizontal direction when horizontal prop is false/undefined', () => {
    render(<Bars data={mockData} total={20} />);

    expect(getChartOptions().series[0].direction).toBe('horizontal');
  });

  it('uses vertical direction when horizontal prop is true', () => {
    render(<Bars data={mockData} total={20} horizontal />);

    expect(getChartOptions().series[0].direction).toBe('vertical');
  });

  it('applies a minHeight style to the wrapping div when provided', () => {
    const { container } = render(
      <Bars data={mockData} total={20} minHeight={240} />,
    );

    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.style.height).toBe('240px');
  });

  it('does not apply an explicit height style when minHeight is not provided', () => {
    const { container } = render(<Bars data={mockData} total={20} />);

    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.style.height).toBe('');
    expect(wrapper.className).toContain('h-full');
    expect(wrapper.className).toContain('w-full');
  });

  it('uses light background in light mode and dark background in dark mode', () => {
    const { rerender } = render(<Bars data={mockData} total={20} />);
    expect(getChartOptions().background.fill).toBe('#fff');

    vi.mocked(useTheme).mockReturnValue({
      theme: 'dark',
      setTheme: vi.fn(),
      saveTheme: vi.fn(),
    });
    rerender(<Bars data={mockData} total={20} />);
    expect(getChartOptions().background.fill).toBe('#1F2937');
  });
});
