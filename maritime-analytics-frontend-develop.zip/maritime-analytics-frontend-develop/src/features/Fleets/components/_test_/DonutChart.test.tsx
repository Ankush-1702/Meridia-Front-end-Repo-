import { render, screen } from '@testing-library/react';
import { AgChartOptions } from 'ag-charts-enterprise';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useTheme } from '@/app/context/ThemeProvider';
import Donut from '@/features/Fleets/components/DonutChart';
import { FleetCompositionItems } from '@/features/Fleets/types/fleetTypes';

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: vi.fn(() => ({ theme: 'light' })),
}));

vi.mock('@/shared/lib/PoleStarCharts', () => ({
  PoleStarChart: ({ options }: { options: AgChartOptions }) => (
    <div data-testid="polestar-chart" data-options={JSON.stringify(options)} />
  ),
}));

// ── fixtures ─────────────────────────────────────────────────────────────────

const mockData: FleetCompositionItems[] = [
  { label: 'Bulk Carrier', count: 15, percentage: 75 },
  { label: 'Container', count: 5, percentage: 25 },
];

function getChartOptions() {
  const chartEl = screen.getByTestId('polestar-chart');
  return JSON.parse(chartEl.getAttribute('data-options')!);
}

// ── tests ─────────────────────────────────────────────────────────────────────

describe('Donut', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    Object.defineProperty(window, 'matchMedia', {
      value: vi.fn(() => ({ matches: false })),
      writable: true,
    });
    vi.mocked(useTheme).mockReturnValue({
      theme: 'light',
      setTheme: vi.fn(),
      saveTheme: vi.fn(),
    });
  });

  it('renders PoleStarChart with the provided data', () => {
    render(<Donut data={mockData} total={20} />);

    expect(screen.getByTestId('polestar-chart')).toBeTruthy();
    expect(getChartOptions().data).toEqual(mockData);
  });

  it('configures a donut series with angleKey and legendItemKey', () => {
    render(<Donut data={mockData} total={20} />);

    const options = getChartOptions();
    expect(options.series[0].type).toBe('donut');
    expect(options.series[0].angleKey).toBe('count');
    expect(options.series[0].legendItemKey).toBe('label');
  });

  it('sets inner/outer radius ratios', () => {
    render(<Donut data={mockData} total={20} />);

    const options = getChartOptions();
    expect(options.series[0].outerRadiusRatio).toBe(1);
    expect(options.series[0].innerRadiusRatio).toBe(0.67);
  });

  it('assigns one fill and stroke per data item', () => {
    render(<Donut data={mockData} total={20} />);

    const options = getChartOptions();
    expect(options.series[0].fills).toHaveLength(mockData.length);
    expect(options.series[0].strokes).toHaveLength(mockData.length);
  });

  it('places the legend at the bottom and enables it', () => {
    render(<Donut data={mockData} total={20} />);

    const options = getChartOptions();
    expect(options.legend.position).toBe('bottom');
    expect(options.legend.enabled).toBe(true);
  });

  it('uses light background in light mode and dark background in dark mode', () => {
    const { rerender } = render(<Donut data={mockData} total={20} />);
    expect(getChartOptions().background.fill).toBe('#fff');

    vi.mocked(useTheme).mockReturnValue({
      theme: 'dark',
      setTheme: vi.fn(),
      saveTheme: vi.fn(),
    });
    rerender(<Donut data={mockData} total={20} />);
    expect(getChartOptions().background.fill).toBe('#1F2937');
  });
});
