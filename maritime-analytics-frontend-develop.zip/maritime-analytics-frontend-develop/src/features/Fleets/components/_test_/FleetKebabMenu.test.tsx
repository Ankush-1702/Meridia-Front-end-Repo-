import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { FleetKebabMenu } from '../FleetKebabMenu';

const openMenu = () => {
  fireEvent.click(screen.getByTitle('More options'));
};

describe('FleetKebabMenu', () => {
  it('does not show Edit or Delete before the menu is opened', () => {
    render(<FleetKebabMenu onEdit={vi.fn()} onDelete={vi.fn()} />);

    expect(screen.queryByText('Edit')).not.toBeInTheDocument();
    expect(screen.queryByText('Delete')).not.toBeInTheDocument();
  });

  it('shows Edit and Delete when both callbacks are provided and menu is opened', () => {
    render(<FleetKebabMenu onEdit={vi.fn()} onDelete={vi.fn()} />);

    openMenu();

    expect(screen.getByText('Edit')).toBeInTheDocument();
    expect(screen.getByText('Delete')).toBeInTheDocument();
  });

  it('only shows Edit when onDelete is not provided', () => {
    render(<FleetKebabMenu onEdit={vi.fn()} />);

    openMenu();

    expect(screen.getByText('Edit')).toBeInTheDocument();
    expect(screen.queryByText('Delete')).not.toBeInTheDocument();
  });

  it('only shows Delete when onEdit is not provided', () => {
    render(<FleetKebabMenu onDelete={vi.fn()} />);

    openMenu();

    expect(screen.queryByText('Edit')).not.toBeInTheDocument();
    expect(screen.getByText('Delete')).toBeInTheDocument();
  });

  it('calls onEdit when Edit is clicked', () => {
    const onEdit = vi.fn();
    render(<FleetKebabMenu onEdit={onEdit} onDelete={vi.fn()} />);

    openMenu();
    fireEvent.click(screen.getByText('Edit'));

    expect(onEdit).toHaveBeenCalledTimes(1);
  });

  it('calls onDelete when Delete is clicked', () => {
    const onDelete = vi.fn();
    render(<FleetKebabMenu onEdit={vi.fn()} onDelete={onDelete} />);

    openMenu();
    fireEvent.click(screen.getByText('Delete'));

    expect(onDelete).toHaveBeenCalledTimes(1);
  });

  it('renders nothing in the menu when neither callback is provided', () => {
    render(<FleetKebabMenu />);

    openMenu();

    expect(screen.queryByText('Edit')).not.toBeInTheDocument();
    expect(screen.queryByText('Delete')).not.toBeInTheDocument();
  });
});
