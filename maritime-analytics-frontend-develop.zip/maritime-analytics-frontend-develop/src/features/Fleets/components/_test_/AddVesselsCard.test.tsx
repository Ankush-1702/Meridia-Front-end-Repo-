import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import AddVesselsCard from '../AddVesselsCard';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

function makeVessel(overrides: Partial<VesselSearch> = {}): VesselSearch {
  return {
    imo: '1234567',
    name: 'Test Vessel',
    flag: 'Norway',
    flag_code: 'NOR',
    vessel_type: 'Cargo',
    ...overrides,
  } as VesselSearch;
}

const baseProps = {
  query: '',
  tabs: ['Search', 'Bulk Import'],
  onTabChange: vi.fn(),
  activeTab: 'Search',
  onQueryChange: vi.fn(),
  onClear: vi.fn(),
  results: [] as VesselSearch[],
  handleScroll: vi.fn(),
  onSelectVessel: vi.fn(),
  selectedImos: new Set<string>(),
  isLoading: false,
  loadingMore: false,
  error: null,
  hasSearched: false,
  debouncedQuery: '',
  bulkImos: '',
  setBulkImos: vi.fn(),
  onUpload: vi.fn(),
  onDownload: vi.fn(),
  fileInputRef: { current: null },
  file: null,
  setFile: vi.fn(),
  handleDrop: vi.fn(),
  handleDragOver: vi.fn(),
  handleFile: vi.fn(),
  verifying: false,
};

describe('AddVesselsCard', () => {
  it('renders the search input on the Search tab', () => {
    render(<AddVesselsCard {...baseProps} />);

    expect(
      screen.getByPlaceholderText('Search vessel name or IMO...'),
    ).toBeInTheDocument();
  });

  it('calls onQueryChange when typing in the search input', () => {
    const onQueryChange = vi.fn();
    render(<AddVesselsCard {...baseProps} onQueryChange={onQueryChange} />);

    fireEvent.change(
      screen.getByPlaceholderText('Search vessel name or IMO...'),
      { target: { value: 'abc' } },
    );

    expect(onQueryChange).toHaveBeenCalledWith('abc');
  });

  it('renders search results with vessel name and IMO', () => {
    render(
      <AddVesselsCard {...baseProps} results={[makeVessel()]} query="test" />,
    );

    expect(screen.getByText('Test Vessel')).toBeInTheDocument();
    expect(screen.getByText('1234567 · Cargo')).toBeInTheDocument();
  });

  it('calls onSelectVessel when an unselected result is clicked', () => {
    const onSelectVessel = vi.fn();
    const vessel = makeVessel();
    render(
      <AddVesselsCard
        {...baseProps}
        results={[vessel]}
        onSelectVessel={onSelectVessel}
      />,
    );

    fireEvent.click(screen.getByText('Test Vessel'));

    expect(onSelectVessel).toHaveBeenCalledWith(vessel);
  });

  it('disables and does not select an already-selected vessel', () => {
    const onSelectVessel = vi.fn();
    const vessel = makeVessel();
    render(
      <AddVesselsCard
        {...baseProps}
        results={[vessel]}
        selectedImos={new Set([vessel.imo])}
        onSelectVessel={onSelectVessel}
      />,
    );

    fireEvent.click(screen.getByText('Test Vessel'));

    expect(onSelectVessel).not.toHaveBeenCalled();
  });

  it('shows a loading spinner while isLoading is true', () => {
    const { container } = render(
      <AddVesselsCard {...baseProps} isLoading query="test" />,
    );

    expect(container.querySelector('[role="status"]')).toBeInTheDocument();
  });

  it('renders the error message when provided', () => {
    render(<AddVesselsCard {...baseProps} error="Something went wrong" />);

    expect(screen.getByText('Something went wrong')).toBeInTheDocument();
  });

  it('does not render the results dropdown when there are no results', () => {
    render(<AddVesselsCard {...baseProps} results={[]} />);

    expect(screen.queryByRole('list')).not.toBeInTheDocument();
  });

  it('renders the Bulk Import tab content when active', () => {
    render(<AddVesselsCard {...baseProps} activeTab="Bulk Import" />);

    expect(screen.getByText('Paste IMO numbers')).toBeInTheDocument();
    expect(screen.getByText('Upload CSV')).toBeInTheDocument();
    expect(
      screen.queryByPlaceholderText('Search vessel name or IMO...'),
    ).not.toBeInTheDocument();
  });

  it('calls onTabChange when a tab is clicked', () => {
    const onTabChange = vi.fn();
    render(<AddVesselsCard {...baseProps} onTabChange={onTabChange} />);

    fireEvent.click(screen.getByLabelText('Bulk Import'));

    expect(onTabChange).toHaveBeenCalledWith('Bulk Import');
  });
});
