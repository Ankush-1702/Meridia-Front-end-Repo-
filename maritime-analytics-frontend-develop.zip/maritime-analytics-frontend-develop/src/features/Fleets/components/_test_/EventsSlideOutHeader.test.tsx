import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import EventsSlideOutHeader from '../EventsSlideOutHeader';

describe('EventsSlideOutHeader', () => {
  it('shows event type and closes the panel', () => {
    const onClose = vi.fn();
    render(<EventsSlideOutHeader eventType="AIS Gap" onClose={onClose} />);

    expect(screen.getByText('Event Details')).toBeInTheDocument();
    expect(screen.getByText('AIS Gap')).toBeInTheDocument();
    fireEvent.click(screen.getAllByRole('button', { name: 'Close panel' })[0]);
    expect(onClose).toHaveBeenCalledOnce();
  });

  it('only shows the back action when requested', () => {
    const onBack = vi.fn();
    const { rerender } = render(
      <EventsSlideOutHeader eventType="STS Pairing" onBack={onBack} />,
    );
    expect(screen.getAllByRole('button')).toHaveLength(1);

    rerender(
      <EventsSlideOutHeader
        eventType="STS Pairing"
        showBackButton
        onBack={onBack}
      />,
    );
    fireEvent.click(screen.getAllByRole('button', { name: 'Close panel' })[0]);
    expect(onBack).toHaveBeenCalledOnce();
  });
});
