import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import KpiCards from '../KpiCards';

describe('KpiCards', () => {
  it('renders the title and value', () => {
    render(<KpiCards title="Total Vessels" value={42} />);

    expect(screen.getByText('Total Vessels')).toBeInTheDocument();
    expect(screen.getByText('42')).toBeInTheDocument();
  });

  it('calls handleClick when clicked and isClickable is true', () => {
    const handleClick = vi.fn();
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        isClickable
        handleClick={handleClick}
      />,
    );

    fireEvent.click(screen.getByRole('button'));

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('calls handleClick on Enter keydown when isClickable is true', () => {
    const handleClick = vi.fn();
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        isClickable
        handleClick={handleClick}
      />,
    );

    fireEvent.keyDown(screen.getByRole('button'), { key: 'Enter' });

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('does not call handleClick on other key presses', () => {
    const handleClick = vi.fn();
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        isClickable
        handleClick={handleClick}
      />,
    );

    fireEvent.keyDown(screen.getByRole('button'), { key: 'Escape' });

    expect(handleClick).not.toHaveBeenCalled();
  });

  it('shows the CoverageNote when showCoverage is true and known is non-zero', () => {
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        showCoverage
        coverage={{ known: 4, total: 10, complete: false }}
      />,
    );

    expect(screen.getByText('Based on 4 of 10 vessels')).toBeInTheDocument();
  });

  it('shows the "no data" message when showCoverage is true and known is zero', () => {
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        showCoverage
        section="fuel"
        coverage={{ known: 0, total: 10, complete: false }}
      />,
    );

    expect(screen.getByText('No fuel data available')).toBeInTheDocument();
  });

  it('does not show coverage information when showCoverage is false', () => {
    render(
      <KpiCards
        title="Total Vessels"
        value={42}
        coverage={{ known: 0, total: 10, complete: false }}
      />,
    );

    expect(screen.queryByText(/data available/)).not.toBeInTheDocument();
    expect(screen.queryByText(/Based on/)).not.toBeInTheDocument();
  });

  it('does not render a chevron icon when isClickable is false', () => {
    const { container } = render(<KpiCards title="Total Vessels" value={42} />);

    expect(container.querySelector('svg')).not.toBeInTheDocument();
  });
});
