import { fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import LocationSlideOutHeader from '../LocationSlideOutHeader';
import type { ZoneInformation } from '@/features/Fleets/types/fleetEventTypes';

const { navigate, mara2Enabled } = vi.hoisted(() => ({
  navigate: vi.fn(),
  mara2Enabled: { value: false },
}));
vi.mock('react-router', () => ({ useNavigate: () => navigate }));
vi.mock('@/app/config/config', () => ({
  isMara2Enabled: () => mara2Enabled.value,
}));

const location: ZoneInformation = {
  centroid: { latitude: 1, longitude: 2 },
  country_official_name: 'Country',
  country_code: 'TC',
  description: undefined,
  id: 'loc-1',
  name: 'Harbour',
  sub_type: 'EEZ',
  type: 'Ports',
  unlocode: 'TST01',
  country_common_name: 'Country',
  sub_division_code: undefined,
  sub_division_name: undefined,
  wpi_number: undefined,
};

describe('LocationSlideOutHeader', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mara2Enabled.value = false;
  });

  it('navigates to full port details and invokes back and close actions', () => {
    const onBack = vi.fn();
    const onClose = vi.fn();
    render(
      <LocationSlideOutHeader
        locationInformation={location}
        showBackButton
        onBack={onBack}
        onClose={onClose}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: /Harbour/ }));
    expect(navigate).toHaveBeenCalledWith('/analytics/port/loc-1');
    fireEvent.click(screen.getAllByRole('button', { name: 'Close panel' })[0]);
    expect(onBack).toHaveBeenCalledOnce();
    fireEvent.click(screen.getAllByRole('button', { name: 'Close panel' })[1]);
    expect(onClose).toHaveBeenCalledOnce();
  });

  it('uses the zone route and offers Ask IQ when enabled', () => {
    mara2Enabled.value = true;
    render(
      <LocationSlideOutHeader
        locationInformation={{ ...location, type: 'Jurisdictional' }}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: /Harbour/ }));
    expect(navigate).toHaveBeenCalledWith('/analytics/zone/loc-1');
    fireEvent.click(screen.getByRole('button', { name: 'Ask IQ' }));
    expect(navigate).toHaveBeenLastCalledWith(
      '/analytics/chat2',
      expect.anything(),
    );
  });
});
