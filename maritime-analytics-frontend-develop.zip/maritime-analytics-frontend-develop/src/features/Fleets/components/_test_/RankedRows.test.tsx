import { render } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import RankedRows from '@/features/Fleets/components/RankedRows';
import { FleetCompositionItems } from '@/features/Fleets/types/fleetTypes';

const items: FleetCompositionItems[] = [
  { label: 'Panama', count: 40, percentage: 40 },
  { label: 'Liberia', count: 30, percentage: 30 },
  { label: 'Marshall Islands', count: 20, percentage: 20 },
  { label: 'Unknown', count: 10, percentage: 10 },
];

describe('RankedRows', () => {
  it('renders one row per item, in the order given', () => {
    const { container } = render(<RankedRows items={items} />);

    const rows = container.querySelectorAll('li');
    expect(rows).toHaveLength(items.length);
    expect(rows[0].textContent).toContain('Panama');
    expect(rows[3].textContent).toContain('Unknown');
  });

  it('shows the count for each row', () => {
    const { getByText } = render(<RankedRows items={items} />);

    expect(getByText('40')).toBeInTheDocument();
    expect(getByText('10')).toBeInTheDocument();
  });

  it('colours the "unknown" bar grey, distinct from ranked colours', () => {
    const { container } = render(<RankedRows items={items} />);

    const bars = container.querySelectorAll('li span[aria-hidden] > span');
    const unknownBar = bars[3] as HTMLElement;

    expect(unknownBar.style.backgroundColor).toBe('rgb(156, 163, 175)');
  });

  it('renders nothing when there are no items', () => {
    const { container } = render(<RankedRows items={[]} />);

    expect(container.querySelectorAll('li')).toHaveLength(0);
  });
});
