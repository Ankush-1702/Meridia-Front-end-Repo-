import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { CoverageNote } from '../ShowCoverage';

describe('CoverageNote', () => {
  it('renders nothing when coverage is complete', () => {
    const { container } = render(
      <CoverageNote coverage={{ known: 10, total: 10, complete: true }} />,
    );

    expect(container).toBeEmptyDOMElement();
  });

  it('renders the coverage text when coverage is incomplete', () => {
    render(
      <CoverageNote coverage={{ known: 4, total: 10, complete: false }} />,
    );

    expect(screen.getByText('Based on 4 of 10 vessels')).toBeInTheDocument();
  });

  it('applies a custom className when provided', () => {
    render(
      <CoverageNote
        coverage={{ known: 4, total: 10, complete: false }}
        className="px-2"
      />,
    );

    expect(
      screen.getByText('Based on 4 of 10 vessels').closest('span'),
    ).toHaveClass('px-2');
  });

  it('renders a tooltip trigger with the info icon', () => {
    const { container } = render(
      <CoverageNote coverage={{ known: 4, total: 10, complete: false }} />,
    );

    expect(container.querySelector('svg')).toBeInTheDocument();
  });
});
