import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import VesselsSlideOutHeader from '../VesselsSlideOutHeader';

describe('VesselsSlideOutHeader', () => {
  it('renders the filtered and total vessel counts', () => {
    render(
      <VesselsSlideOutHeader
        totalCount={10}
        filteredCount={4}
        onClose={vi.fn()}
      />,
    );

    expect(screen.getByText('Vessels (4 of 10)')).toBeInTheDocument();
  });

  it('renders the same count for total and filtered when equal', () => {
    render(
      <VesselsSlideOutHeader
        totalCount={7}
        filteredCount={7}
        onClose={vi.fn()}
      />,
    );

    expect(screen.getByText('Vessels (7 of 7)')).toBeInTheDocument();
  });

  it('renders a close button with the correct aria-label', () => {
    render(
      <VesselsSlideOutHeader
        totalCount={10}
        filteredCount={4}
        onClose={vi.fn()}
      />,
    );

    expect(screen.getByLabelText('Close panel')).toBeInTheDocument();
  });

  it('calls onClose when the close button is clicked', () => {
    const onClose = vi.fn();
    render(
      <VesselsSlideOutHeader
        totalCount={10}
        filteredCount={4}
        onClose={onClose}
      />,
    );

    fireEvent.click(screen.getByLabelText('Close panel'));

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('does not throw when onClose is not provided and the button is clicked', () => {
    render(<VesselsSlideOutHeader totalCount={10} filteredCount={4} />);

    expect(() =>
      fireEvent.click(screen.getByLabelText('Close panel')),
    ).not.toThrow();
  });
});
