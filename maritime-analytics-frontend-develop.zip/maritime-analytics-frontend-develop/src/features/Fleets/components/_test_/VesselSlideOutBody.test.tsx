import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import VesselSlideOutBody from '../VesselSlideOutBody';
import { VesselData } from '@/features/Fleets/types/fleetTypes';

function makeVessel(
  overrides: Partial<VesselData['vessel_information']> = {},
): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
      ...overrides,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
  };
}

const vesselA = makeVessel({
  imo: '2222222',
  name: 'Bravo Star',
  vessel_type: 'Bulk carrier',
  vessel_class: 'Handysize',
  flag: 'Norway',
  flag_code: 'NOR',
});

const vesselB = makeVessel({
  imo: '3333333',
  name: 'Alpha Voyager',
  vessel_type: 'Oil Tanker',
  vessel_class: 'VLCC',
  flag: 'Panama',
  flag_code: 'PAN',
});

const vessels = [vesselA, vesselB];

const baseProps = {
  query: '',
  setQuery: vi.fn(),
  sort: 'name' as const,
  setSort: vi.fn(),
  setDrillImo: vi.fn(),
  vessels,
};

describe('VesselSlideOutBody', () => {
  it('renders all vessels with name and details', () => {
    render(<VesselSlideOutBody {...baseProps} />);

    expect(screen.getByText('Bravo Star')).toBeInTheDocument();
    expect(screen.getByText('Alpha Voyager')).toBeInTheDocument();
    expect(
      screen.getByText('2222222 · Bulk carrier · Handysize'),
    ).toBeInTheDocument();
    expect(screen.getByText('3333333 · Oil Tanker · VLCC')).toBeInTheDocument();
  });

  it('sorts vessels by name by default', () => {
    render(<VesselSlideOutBody {...baseProps} />);

    const names = screen
      .getAllByText(/Voyager|Star/)
      .map((el) => el.textContent);
    expect(names).toEqual(['Alpha Voyager', 'Bravo Star']);
  });

  it('sorts vessels by imo when sort is "imo"', () => {
    render(<VesselSlideOutBody {...baseProps} sort="imo" />);

    const names = screen
      .getAllByText(/Voyager|Star/)
      .map((el) => el.textContent);
    expect(names).toEqual(['Bravo Star', 'Alpha Voyager']);
  });

  it('calls setQuery when typing in the search input', () => {
    const setQuery = vi.fn();
    render(<VesselSlideOutBody {...baseProps} setQuery={setQuery} />);

    fireEvent.change(
      screen.getByPlaceholderText('Search name, IMO, type, class…'),
      { target: { value: 'alpha' } },
    );

    expect(setQuery).toHaveBeenCalledWith('alpha');
  });

  it('filters vessels matching a single search term case-insensitively', () => {
    render(<VesselSlideOutBody {...baseProps} query="ALPHA" />);

    expect(screen.getByText('Alpha Voyager')).toBeInTheDocument();
    expect(screen.queryByText('Bravo Star')).not.toBeInTheDocument();
  });

  it('filters vessels matching on imo, vessel_type, vessel_class, or flag', () => {
    const { rerender } = render(
      <VesselSlideOutBody {...baseProps} query="3333333" />,
    );
    expect(screen.getByText('Alpha Voyager')).toBeInTheDocument();
    expect(screen.queryByText('Bravo Star')).not.toBeInTheDocument();

    rerender(<VesselSlideOutBody {...baseProps} query="vlcc" />);
    expect(screen.getByText('Alpha Voyager')).toBeInTheDocument();
    expect(screen.queryByText('Bravo Star')).not.toBeInTheDocument();

    rerender(<VesselSlideOutBody {...baseProps} query="panama" />);
    expect(screen.getByText('Alpha Voyager')).toBeInTheDocument();
    expect(screen.queryByText('Bravo Star')).not.toBeInTheDocument();
  });

  it('requires every space-separated term to match (AND semantics)', () => {
    render(<VesselSlideOutBody {...baseProps} query="bravo vlcc" />);

    expect(screen.queryByText('Bravo Star')).not.toBeInTheDocument();
    expect(screen.queryByText('Alpha Voyager')).not.toBeInTheDocument();
  });

  it('matches when all space-separated terms are found across fields', () => {
    render(<VesselSlideOutBody {...baseProps} query="bravo handysize" />);

    expect(screen.getByText('Bravo Star')).toBeInTheDocument();
    expect(screen.queryByText('Alpha Voyager')).not.toBeInTheDocument();
  });

  it('calls setDrillImo with the clicked vessel and clears the query', () => {
    const setDrillImo = vi.fn();
    const setQuery = vi.fn();
    render(
      <VesselSlideOutBody
        {...baseProps}
        setDrillImo={setDrillImo}
        setQuery={setQuery}
      />,
    );

    fireEvent.click(screen.getByText('Bravo Star'));

    expect(setDrillImo).toHaveBeenCalledWith(vesselA);
    expect(setQuery).toHaveBeenCalledWith('');
  });

  it('shows a generic empty message when there is no query and nothing matches', () => {
    render(<VesselSlideOutBody {...baseProps} vessels={[]} />);

    expect(
      screen.getByText('No vessels match these filters.'),
    ).toBeInTheDocument();
  });

  it('shows a query-specific empty message when a search has no matches', () => {
    render(<VesselSlideOutBody {...baseProps} query="nonexistent" />);

    expect(
      screen.getByText('No vessels match “nonexistent”.'),
    ).toBeInTheDocument();
  });

  it('opens the sort dropdown and calls setSort when an option is clicked', () => {
    const setSort = vi.fn();
    render(<VesselSlideOutBody {...baseProps} setSort={setSort} />);

    fireEvent.click(screen.getByRole('button', { name: /Sort Name/ }));
    fireEvent.click(screen.getByRole('button', { name: 'IMO' }));

    expect(setSort).toHaveBeenCalledWith('imo');
  });
});
