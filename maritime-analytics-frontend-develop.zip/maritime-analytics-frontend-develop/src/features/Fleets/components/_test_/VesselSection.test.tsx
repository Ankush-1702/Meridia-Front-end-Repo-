import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import VesselSection from '../VesselSection';
import type { VesselData } from '@/features/Fleets/types/fleetTypes';

const primary = {
  vessel_information: {
    name: 'Primary Vessel',
    vessel_type: 'Cargo',
    imo: 'IMO-1',
    flag_code: 'NG',
  },
} as VesselData;
const paired = {
  vessel_information: {
    name: 'Paired Vessel',
    imo: 'IMO-2',
    flag_code: 'GB',
  },
} as VesselData;

describe('VesselSection', () => {
  it('opens primary and paired vessel details for an STS event', () => {
    const setPrimary = vi.fn();
    const setPaired = vi.fn();
    render(
      <VesselSection
        eventType="STS_PAIRING"
        primaryVessel={primary}
        setViewPrimaryVessel={setPrimary}
        pairedVessel={paired}
        setViewPairedVessel={setPaired}
      />,
    );

    expect(screen.getByText('Primary vessel')).toBeInTheDocument();
    expect(screen.getByText('Paired vessel')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /Primary Vessel/ }));
    fireEvent.click(screen.getByRole('button', { name: /Paired Vessel/ }));
    expect(setPrimary).toHaveBeenCalledWith(true);
    expect(setPaired).toHaveBeenCalledWith(true);
  });

  it('omits unavailable paired vessels and supports an omitted paired callback', () => {
    const { rerender } = render(
      <VesselSection
        eventType="PORT_ARRIVAL"
        primaryVessel={primary}
        setViewPrimaryVessel={vi.fn()}
        pairedVessel={undefined}
      />,
    );

    expect(screen.queryByText('Paired Vessel')).not.toBeInTheDocument();

    rerender(
      <VesselSection
        eventType="PORT_ARRIVAL"
        primaryVessel={primary}
        setViewPrimaryVessel={vi.fn()}
        pairedVessel={paired}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: /Paired Vessel/ }));
    expect(screen.getByText('Primary Vessel')).toBeInTheDocument();
  });
});
