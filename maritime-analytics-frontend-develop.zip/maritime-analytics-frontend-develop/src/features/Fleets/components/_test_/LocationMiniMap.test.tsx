import { render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import LocationMiniMap from '../LocationMiniMap';
import type {
  FlatFleetEventsResponse,
  FleetEventType,
} from '@/features/Fleets/types/fleetEventTypes';
import type { VesselData } from '@/features/Fleets/types/fleetTypes';
import {
  MAP_STYLES,
  MARKER_SIZE,
} from '@/shared/constants/overviewMapConstants';
import { hashToRotation } from '@/shared/utils/overviewMapUtils';

const { mapState, themeState, tokenState, marker, createMarker } = vi.hoisted(
  () => ({
    mapState: { ready: false, ref: { current: {} as unknown } },
    themeState: { value: 'light' },
    tokenState: { value: 'token' },
    marker: {
      setLngLat: vi.fn().mockReturnThis(),
      addTo: vi.fn().mockReturnThis(),
      remove: vi.fn(),
    },
    createMarker: vi.fn<
      (...args: [unknown]) => {
        element: HTMLDivElement;
        unmount: () => void;
      }
    >(() => ({
      element: document.createElement('div'),
      unmount: vi.fn(),
    })),
  }),
);
vi.mock('mapbox-gl', () => ({
  default: {
    Marker: vi.fn(function Marker() {
      return marker;
    }),
  },
}));
vi.mock('@/features/Fleets/hooks/useFleetMapInit', () => ({
  useFleetMapInit: (...args: unknown[]) => {
    mapInitArgs.current = args;
    return { mapRef: mapState.ref, mapReady: mapState.ready };
  },
}));
const mapInitArgs = vi.hoisted(() => ({ current: [] as unknown[] }));
vi.mock('@/features/Fleets/hooks/useFleetCenterPin', () => ({
  useFleetCenterPin: (...args: unknown[]) => (centerPinArgs.current = args),
}));
const centerPinArgs = vi.hoisted(() => ({ current: [] as unknown[] }));
vi.mock('@/features/Fleets/hooks/useFleetEventMarkers', () => ({
  useFleetEventMarkers: (...args: unknown[]) =>
    (eventMarkerArgs.current = args),
}));
const eventMarkerArgs = vi.hoisted(() => ({ current: [] as unknown[] }));
vi.mock('@/shared/hooks/useZoneBoundary', () => ({
  useZoneBoundary: (...args: unknown[]) => (boundaryArgs.current = args),
}));
const boundaryArgs = vi.hoisted(() => ({ current: [] as unknown[] }));
vi.mock('@/shared/hooks/useReactMarker', () => ({
  createReactMarkerElement: (element: unknown) => {
    createMarker(element);
    return { element: document.createElement('div'), unmount: vi.fn() };
  },
}));
vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: themeState.value }),
}));
vi.mock('@/app/config/config', () => ({
  get MAPBOX_TOKEN() {
    return tokenState.value;
  },
}));
vi.mock('@/shared/components/MapboxMissingToken', () => ({
  default: () => <div>Missing map token</div>,
}));

function makeVessel(
  position: Partial<NonNullable<VesselData['vessel_position']>>,
): VesselData {
  return {
    added_at: '',
    added_by: '',
    vessel_information: {
      asset_id: 'asset-1',
      callsign: 'CALL',
      flag: 'Flag',
      flag_code: 'NG',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Cargo',
      vessel_class: 'Class',
      build_year: 2000,
      age: 26,
      deadweight: 1000,
    },
    vessel_position: {
      latitude: 12,
      longitude: 34,
      course: 90,
      heading: 100,
      speed: 10,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 4,
      reported_destination: '',
      reported_eta: '',
      timestamp: '',
      source: 'AIS',
      ...position,
    },
  };
}

function makeEvent(
  eventType: FleetEventType,
  position?: { latitude?: number; longitude?: number },
): FlatFleetEventsResponse {
  return {
    callSign: 'CALL',
    flag: 'Flag',
    flagCode: 'NG',
    imo: '1234567',
    mmsi: '123456789',
    vesselName: 'Vessel',
    vesselType: 'Cargo',
    eventType,
    heading: 180,
    zonePortEventLocationLat: position?.latitude,
    zonePortEventLocationLng: position?.longitude,
  };
}

const portAndZoneEventTypes: FleetEventType[] = [
  'PORT_ARRIVAL',
  'PORT_DEPARTURE',
  'PORT_AREA_ARRIVAL',
  'PORT_AREA_DEPARTURE',
  'ZONE_ENTRY',
  'ZONE_EXIT',
];

describe('LocationMiniMap', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mapState.ready = false;
    themeState.value = 'light';
    tokenState.value = 'token';
    marker.setLngLat.mockReturnThis();
    marker.addTo.mockReturnThis();
    window.matchMedia = vi.fn().mockReturnValue({ matches: false });
  });

  it('configures the miniature map, center marker, event markers, and boundary', () => {
    mapState.ready = true;
    themeState.value = 'dark';
    const center = { latitude: 12, longitude: 34 };
    const event = { eventType: 'AIS_GAP' } as never;
    render(
      <LocationMiniMap
        center={center}
        label="Harbour"
        event={event}
        boundaryGeometry="geometry"
      />,
    );

    expect(mapInitArgs.current[1]).toBe(MAP_STYLES.dark);
    expect(mapInitArgs.current[2]).toBe(center);
    expect(mapInitArgs.current[3]).toBe(8);
    expect(centerPinArgs.current).toEqual([
      mapState.ref,
      true,
      center,
      8,
      'Harbour',
      undefined,
    ]);
    expect(eventMarkerArgs.current).toEqual([
      mapState.ref,
      true,
      event,
      center,
    ]);
    expect(boundaryArgs.current).toEqual([mapState.ref, true, 'geometry']);
  });

  it('zooms to a port or zone event position when its vessel is available', () => {
    mapState.ready = true;
    const locationCenter = { latitude: 10, longitude: 20 };
    const vessel = makeVessel({ latitude: 12, longitude: 34 });
    const event = makeEvent('PORT_ARRIVAL', {
      latitude: 56,
      longitude: -78,
    });

    render(
      <LocationMiniMap
        center={locationCenter}
        label="Harbour"
        event={event}
        vessel={vessel}
      />,
    );

    expect(mapInitArgs.current[2]).toEqual({ latitude: 56, longitude: -78 });
    expect(mapInitArgs.current[3]).toBe(11);
    expect(centerPinArgs.current).toEqual([
      mapState.ref,
      true,
      locationCenter,
      11,
      'Harbour',
      { latitude: 56, longitude: -78 },
    ]);
  });

  it('uses the closer boundary view when a port or zone vessel is unavailable', () => {
    const locationCenter = { latitude: 10, longitude: 20 };
    render(
      <LocationMiniMap
        center={locationCenter}
        event={makeEvent('ZONE_ENTRY', { latitude: 56, longitude: -78 })}
      />,
    );

    expect(mapInitArgs.current[2]).toBe(locationCenter);
    expect(mapInitArgs.current[3]).toBe(9);
    expect(centerPinArgs.current).toEqual([
      mapState.ref,
      false,
      locationCenter,
      9,
      undefined,
      undefined,
    ]);
  });

  it('uses the boundary view when the resolved vessel has invalid event coordinates', () => {
    const locationCenter = { latitude: 10, longitude: 20 };
    render(
      <LocationMiniMap
        center={locationCenter}
        event={makeEvent('PORT_ARRIVAL', { latitude: 91, longitude: 34 })}
        vessel={makeVessel({ latitude: 12, longitude: 34 })}
      />,
    );

    expect(mapInitArgs.current[2]).toBe(locationCenter);
    expect(mapInitArgs.current[3]).toBe(9);
  });

  it('adds and cleans up a vessel marker using a valid heading', () => {
    mapState.ready = true;
    const vessel = makeVessel({ latitude: 12, longitude: 34, heading: 180 });
    const event = makeEvent('PORT_ARRIVAL', {
      latitude: 15,
      longitude: 25,
    });
    const { unmount } = render(
      <LocationMiniMap vessel={vessel} event={event} />,
    );

    expect(createMarker).toHaveBeenCalledOnce();
    const icon = createMarker.mock.calls[0][0] as React.ReactElement;
    expect(icon.props).toMatchObject({ size: MARKER_SIZE, rotationDeg: 180 });
    expect(marker.setLngLat).toHaveBeenCalledWith([25, 15]);
    expect(marker.addTo).toHaveBeenCalledWith(mapState.ref.current);

    unmount();
    expect(marker.remove).toHaveBeenCalledOnce();
  });

  it.each(portAndZoneEventTypes)(
    'uses event coordinates for %s even when no vessel position is provided',
    (eventType) => {
      mapState.ready = true;
      render(
        <LocationMiniMap
          event={makeEvent(eventType, { latitude: 56, longitude: -78 })}
        />,
      );

      expect(createMarker).toHaveBeenCalledOnce();
      expect(marker.setLngLat).toHaveBeenCalledWith([-78, 56]);
      expect(
        (createMarker.mock.calls[0][0] as React.ReactElement).props.rotationDeg,
      ).toBe(180);
    },
  );

  it('does not fall back to the vessel position when event coordinates are missing', () => {
    mapState.ready = true;
    render(
      <LocationMiniMap
        vessel={makeVessel({ latitude: 12, longitude: 34 })}
        event={makeEvent('ZONE_ENTRY')}
      />,
    );

    expect(createMarker).not.toHaveBeenCalled();
    expect(marker.setLngLat).not.toHaveBeenCalled();
  });

  it('does not create a marker when port or zone event coordinates are invalid', () => {
    mapState.ready = true;
    render(
      <LocationMiniMap
        vessel={makeVessel({ latitude: 12, longitude: 34 })}
        event={makeEvent('PORT_ARRIVAL', { latitude: 91, longitude: 34 })}
      />,
    );

    expect(createMarker).not.toHaveBeenCalled();
    expect(marker.setLngLat).not.toHaveBeenCalled();
  });

  it('does not add a vessel marker for non-port and non-zone events', () => {
    mapState.ready = true;
    const event = makeEvent('AIS_GAP', {
      latitude: 56,
      longitude: -78,
    });
    render(
      <LocationMiniMap
        vessel={makeVessel({ latitude: 12, longitude: 34 })}
        event={event}
      />,
    );

    expect(createMarker).not.toHaveBeenCalled();
    expect(marker.setLngLat).not.toHaveBeenCalled();
    expect(eventMarkerArgs.current[2]).toBe(event);
  });

  it('falls back to course and then a stable IMO rotation when heading is invalid', () => {
    mapState.ready = true;
    const vessel = makeVessel({ heading: 361, course: 45 });
    const event = makeEvent('ZONE_ENTRY', {
      latitude: 12,
      longitude: 34,
    });
    event.heading = 361;
    event.course = 361;
    const { rerender } = render(
      <LocationMiniMap vessel={vessel} event={event} />,
    );
    expect(
      (createMarker.mock.calls[0][0] as React.ReactElement).props.rotationDeg,
    ).toBe(45);

    const noHeading = makeVessel({ heading: -1, course: 361 });
    rerender(<LocationMiniMap vessel={noHeading} event={event} />);
    expect(
      (createMarker.mock.calls[1][0] as React.ReactElement).props.rotationDeg,
    ).toBe(hashToRotation('1234567'));
  });

  it('does not create a vessel marker until the map and valid position are ready', () => {
    const invalid = makeVessel({ latitude: 100, longitude: 34 });
    const { rerender } = render(
      <LocationMiniMap
        vessel={invalid}
        event={makeEvent('PORT_ARRIVAL', { latitude: 100, longitude: 34 })}
      />,
    );
    expect(createMarker).not.toHaveBeenCalled();

    mapState.ready = true;
    rerender(
      <LocationMiniMap
        vessel={makeVessel({ latitude: 1, longitude: 2 })}
        event={makeEvent('PORT_ARRIVAL', { latitude: 1, longitude: 2 })}
      />,
    );
    expect(createMarker).toHaveBeenCalledOnce();
  });

  it('uses system dark preference and displays the missing-token message', () => {
    themeState.value = 'system';
    tokenState.value = '';
    window.matchMedia = vi.fn().mockReturnValue({ matches: true });
    render(<LocationMiniMap />);

    expect(mapInitArgs.current[1]).toBe(MAP_STYLES.dark);
    expect(screen.getByText('Missing map token')).toBeInTheDocument();
  });
});
