import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import UnresolvedPanel from '../UnresolvedPanel';
import { UnresolvedImos } from '@/features/Fleets/types/fleetTypes';

const items: UnresolvedImos = {
  notFound: [
    { imo: '1111111', message: 'Not found' },
    { imo: '2222222', message: 'Not found' },
  ],
  inValid: [{ imo: 'abc', message: 'Invalid format' }],
};

describe('UnresolvedPanel', () => {
  it('shows the total unresolved count, collapsed by default', () => {
    render(
      <UnresolvedPanel
        items={items}
        onDismiss={vi.fn()}
        onDismissAll={vi.fn()}
      />,
    );

    expect(screen.getByText(/3 IMOs couldn.t be added/)).toBeInTheDocument();
    expect(screen.queryByText('1111111')).not.toBeInTheDocument();
  });

  it('shows the not-found and invalid-format breakdown', () => {
    render(
      <UnresolvedPanel
        items={items}
        onDismiss={vi.fn()}
        onDismissAll={vi.fn()}
      />,
    );

    expect(
      screen.getByText('2 not found · 1 invalid format'),
    ).toBeInTheDocument();
  });

  it('expands to list each unresolved IMO with its reason', () => {
    render(
      <UnresolvedPanel
        items={items}
        onDismiss={vi.fn()}
        onDismissAll={vi.fn()}
      />,
    );

    fireEvent.click(
      screen.getByRole('button', { name: /IMOs couldn.t be added/ }),
    );

    expect(screen.getByText('1111111')).toBeInTheDocument();
    expect(screen.getAllByText('Not found')).toHaveLength(2);
    expect(screen.getByText('Invalid format')).toBeInTheDocument();
  });

  it('calls onDismiss with the correct imo when its dismiss button is clicked', () => {
    const onDismiss = vi.fn();
    render(
      <UnresolvedPanel
        items={items}
        onDismiss={onDismiss}
        onDismissAll={vi.fn()}
      />,
    );

    fireEvent.click(
      screen.getByRole('button', { name: /IMOs couldn.t be added/ }),
    );
    fireEvent.click(screen.getByLabelText('Dismiss 1111111'));

    expect(onDismiss).toHaveBeenCalledWith('1111111');
  });

  it('calls onDismissAll when "Dismiss all" is clicked', () => {
    const onDismissAll = vi.fn();
    render(
      <UnresolvedPanel
        items={items}
        onDismiss={vi.fn()}
        onDismissAll={onDismissAll}
      />,
    );

    fireEvent.click(
      screen.getByRole('button', { name: /IMOs couldn.t be added/ }),
    );
    fireEvent.click(screen.getByText('Dismiss all'));

    expect(onDismissAll).toHaveBeenCalledTimes(1);
  });

  it('uses singular "IMO" when there is exactly one unresolved item', () => {
    render(
      <UnresolvedPanel
        items={{
          notFound: [{ imo: '1111111', message: 'Not found' }],
          inValid: [],
        }}
        onDismiss={vi.fn()}
        onDismissAll={vi.fn()}
      />,
    );

    expect(screen.getByText(/1 IMO couldn.t be added/)).toBeInTheDocument();
  });
});
