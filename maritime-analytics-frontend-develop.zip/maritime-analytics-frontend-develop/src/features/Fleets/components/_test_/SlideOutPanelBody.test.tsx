import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import SlideOutPanelBody from '../SlideOutPanelBody';
import { VesselData } from '@/features/Fleets/types/fleetTypes';
import { PtracOverallStatus } from '@/features/Vessels/types/ptracTypes';

const mockUsePtracScreening = vi.fn();

vi.mock('@/features/Vessels/hooks/usePtracScreening', () => ({
  usePtracScreening: (imo: string) => mockUsePtracScreening(imo),
}));

vi.mock('@/features/Fleets/components/VesselMiniMap', () => ({
  default: () => <div>VesselMiniMap</div>,
}));

vi.mock('@/shared/components/ScoreChips', () => ({
  MtiScoreChip: ({ score }: { score: number | null }) => (
    <span>MtiScore:{score ?? 'null'}</span>
  ),
  PtracRiskChip: ({ risk }: { risk: string }) => <span>PtracRisk:{risk}</span>,
}));

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    mti_score: '4',
    ...overrides,
  };
}

describe('SlideOutPanelBody', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockUsePtracScreening.mockReturnValue({ status: null, loading: false });
  });

  it('renders vessel information rows', () => {
    render(<SlideOutPanelBody vesselData={makeVessel()} />);

    expect(screen.getByText('Bulk carrier')).toBeInTheDocument();
    expect(screen.getByText('Handysize')).toBeInTheDocument();
    expect(screen.getByText('123456789')).toBeInTheDocument();
  });

  it('renders the vessel mini map', () => {
    render(<SlideOutPanelBody vesselData={makeVessel()} />);

    expect(screen.getByText('VesselMiniMap')).toBeInTheDocument();
  });

  it('renders the latest position section', () => {
    render(<SlideOutPanelBody vesselData={makeVessel()} />);

    expect(screen.getByText('Latest position')).toBeInTheDocument();
    expect(screen.getByText('Under way')).toBeInTheDocument();
    expect(screen.getByText('12.0 kn')).toBeInTheDocument();
    expect(screen.getByText('90°')).toBeInTheDocument();
    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
  });

  it('does not query ptrac screening when hasPtracAccess is false', () => {
    render(
      <SlideOutPanelBody vesselData={makeVessel()} hasPtracAccess={false} />,
    );

    expect(mockUsePtracScreening).toHaveBeenCalledWith('');
  });

  it('queries ptrac screening with the vessel imo when hasPtracAccess is true', () => {
    render(<SlideOutPanelBody vesselData={makeVessel()} hasPtracAccess />);

    expect(mockUsePtracScreening).toHaveBeenCalledWith('1234567');
  });

  it('maps a WARNING ptrac status to the Warning risk chip', () => {
    mockUsePtracScreening.mockReturnValue({
      status: 'WARNING' as PtracOverallStatus,
      loading: false,
    });

    render(<SlideOutPanelBody vesselData={makeVessel()} hasPtracAccess />);

    expect(screen.getByText('PtracRisk:Warning')).toBeInTheDocument();
  });

  it('shows N/A risk chip when ptrac status is null', () => {
    render(<SlideOutPanelBody vesselData={makeVessel()} hasPtracAccess />);

    expect(screen.getByText('PtracRisk:N/A')).toBeInTheDocument();
  });

  it('renders the MTI score chip using the vessel mti_score', () => {
    render(
      <SlideOutPanelBody
        vesselData={makeVessel({ mti_score: '3' })}
        hasMTIScore
      />,
    );

    expect(screen.getByText('MtiScore:3')).toBeInTheDocument();
  });

  it('renders a null MTI score when mti_score is missing', () => {
    render(
      <SlideOutPanelBody
        vesselData={makeVessel({ mti_score: undefined })}
        hasMTIScore
      />,
    );

    expect(screen.getByText('MtiScore:null')).toBeInTheDocument();
  });
});
