import { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa6';
import { LuAlertTriangle, LuX } from 'react-icons/lu';
import { UnresolvedImos } from '../types/fleetTypes';
import { cn } from '@/shared/utils/classMerge';

export default function UnresolvedPanel({
  items,
  onDismiss,
  onDismissAll,
}: {
  items: UnresolvedImos;
  onDismiss: (imo: string) => void;
  onDismissAll: () => void;
}) {
  const [open, setOpen] = useState(false);
  const flattened = [
    ...items.notFound.map((i) => ({ ...i, reason: 'NOT_FOUND' as const })),
    ...items.inValid.map((i) => ({ ...i, reason: 'INVALID_FORMAT' as const })),
  ];
  const notFound = items.notFound.length;
  const invalid = items.inValid.length;
  return (
    <div className="shrink-0 border-b border-yellow-200 bg-yellow-50 dark:border-yellow-900/40 dark:bg-yellow-900/40">
      <div className="flex items-start gap-2.5 px-5 py-2.5">
        <LuAlertTriangle className="mt-0.5 size-3.5 shrink-0 text-yellow-500" />
        <div className="min-w-0 flex-1">
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="flex w-full items-center gap-1.5 text-left text-xs font-medium text-yellow-900 dark:text-yellow-200"
            aria-expanded={open}
          >
            <span className="flex-1">
              {flattened.length.toLocaleString()} IMO
              {flattened.length === 1 ? '' : 's'} couldn't be added
            </span>
            <FaChevronDown
              className={cn(
                'size-3.5 shrink-0 transition-transform',
                open && 'rotate-180',
              )}
            />
          </button>
          <p className="mt-0.5 text-[11px] text-yellow-800/80 dark:text-yellow-200/70">
            {[
              notFound > 0 && `${notFound.toLocaleString()} not found`,
              invalid > 0 && `${invalid.toLocaleString()} invalid format`,
            ]
              .filter(Boolean)
              .join(' · ')}
          </p>
          {open && (
            <>
              <ul className="mt-2 max-h-40 space-y-1 overflow-auto">
                {flattened.map((u) => (
                  <li
                    key={u.imo}
                    className="flex items-center gap-2 text-[11px]"
                  >
                    <span className="font-mono text-yellow-900 dark:text-yellow-100">
                      {u.imo}
                    </span>
                    <span className="flex-1 truncate text-yellow-800/80 dark:text-yellow-200/70">
                      {u.message}
                    </span>
                    <button
                      type="button"
                      aria-label={`Dismiss ${u.imo}`}
                      onClick={() => onDismiss(u.imo)}
                      className="text-yellow-700/70 hover:text-yellow-900 dark:text-yellow-300/70 dark:hover:text-yellow-100"
                    >
                      <LuX className="size-3" />
                    </button>
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={onDismissAll}
                className="mt-2 text-[11px] font-medium text-yellow-900 underline decoration-dotted hover:no-underline dark:text-yellow-200"
              >
                Dismiss all
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
