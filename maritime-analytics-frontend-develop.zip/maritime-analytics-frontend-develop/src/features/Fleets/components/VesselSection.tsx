import { VesselData } from '../types/fleetTypes';
import { FleetEventType } from '@/features/Fleets/types/fleetEventTypes';
import { EntityCard } from '@/shared/components/EntityCard';
import { Heading } from '@/shared/components/SlideOutComponents';
import FlagIcon from '@/shared/ui/FlagIcon';

export default function VesselSection({
  eventType,
  primaryVessel,
  setViewPrimaryVessel,
  pairedVessel,
  setViewPairedVessel,
}: {
  eventType: FleetEventType;
  primaryVessel: VesselData;
  setViewPrimaryVessel: (v: boolean) => void;
  pairedVessel?: VesselData;
  setViewPairedVessel?: (v: boolean) => void;
}) {
  return (
    <div className={`flex flex-col gap-2`}>
      <Heading className="mt-0">Vessels</Heading>
      {eventType === 'STS_PAIRING' && (
        <span className={`text-xs font-semibold text-gray-500`}>
          Primary vessel
        </span>
      )}
      <EntityCard
        icon={
          <FlagIcon flagCode={primaryVessel.vessel_information.flag_code} />
        }
        name={primaryVessel.vessel_information.name}
        sub={`Vessel · ${primaryVessel.vessel_information.vessel_type} · IMO ${primaryVessel.vessel_information.imo}`}
        onClick={() => {
          setViewPrimaryVessel(true);
        }}
      />
      {eventType === 'STS_PAIRING' && (
        <span className={`text-xs font-semibold text-gray-500`}>
          Paired vessel
        </span>
      )}
      {pairedVessel && (
        <EntityCard
          icon={
            <FlagIcon flagCode={pairedVessel.vessel_information.flag_code} />
          }
          name={pairedVessel.vessel_information.name}
          sub={`Vessel  · IMO ${pairedVessel.vessel_information.imo}`}
          onClick={() => {
            setViewPairedVessel?.(true);
          }}
        />
      )}
    </div>
  );
}
