import { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';
import { Heading, Row } from '@/shared/components/SlideOutComponents';
import { convertDateAndTimeToHumanReadableFormat } from '@/shared/utils/formatUtils';

interface EventsProps {
  event: FlatFleetEventsResponse;
}
export default function EventsSlideOutDetails({ event }: EventsProps) {
  return (
    <>
      <Heading>Details</Heading>
      {event.eventType === 'PORT_STATE_CONTROL' && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Timestamp"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          <Row label="Authority" value={event.authority || '-'} />
          <Row label="Inspection type" value={event.inspectionType || '-'} />
          <Row
            label="Detained"
            value={event.detained === true ? 'Yes' : 'No'}
          />
          <Row
            label="Defects"
            value={event.numberOfDefects !== null ? event.numberOfDefects : '-'}
          />
        </div>
      )}
      {event.eventType === 'POSITIONAL_DISCREPANCY' && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Start"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          <Row
            label="End"
            value={
              convertDateAndTimeToHumanReadableFormat(event.stoppedTimestamp) ||
              '-'
            }
          />
          <Row
            label="Duration"
            value={
              event.duration !== 'Ongoing'
                ? `${event.duration} ${event.duration === 1 ? 'hr' : 'hrs'}`
                : 'Ongoing'
            }
          />
        </div>
      )}
      {event.eventType === 'STS_PAIRING' && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Start"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          <Row
            label="End"
            value={
              convertDateAndTimeToHumanReadableFormat(event.stsEnded) || '-'
            }
          />
          <Row
            label="Duration"
            value={
              event.duration !== 'Ongoing'
                ? `${event.duration} ${event.duration === 1 ? 'hr' : 'hrs'}`
                : 'Ongoing'
            }
          />
          <Row label="STS type" value={event.stsType || '-'} />
        </div>
      )}
      {event.eventType === 'AIS_GAP' && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Start"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          <Row
            label="End"
            value={
              convertDateAndTimeToHumanReadableFormat(event.gapResumed) || '-'
            }
          />
          <Row
            label="Duration"
            value={
              event.duration !== 'Ongoing'
                ? `${event.duration} ${event.duration === 1 ? 'hr' : 'hrs'}`
                : 'Ongoing'
            }
          />
        </div>
      )}
      {(event.eventType === 'PORT_AREA_ARRIVAL' ||
        event.eventType === 'PORT_ARRIVAL' ||
        event.eventType === 'ZONE_ENTRY' ||
        event.eventType === 'ZONE_EXIT') && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Timestamp"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          <Row
            label="Speed"
            value={event.speed != null ? `${event.speed} kn` : '-'}
          />
          <Row
            label="Course"
            value={event.course != null ? `${event.course}°` : '-'}
          />
          <Row
            label="Draught"
            value={event.draught != null ? `${event.draught} m` : '-'}
          />
          <Row
            label="Navigational status"
            value={event.navigationalStatusStatus || '-'}
          />
        </div>
      )}
      {(event.eventType === 'PORT_AREA_DEPARTURE' ||
        event.eventType === 'PORT_DEPARTURE') && (
        <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Timestamp"
            value={
              convertDateAndTimeToHumanReadableFormat(event.eventTimestamp) ||
              '-'
            }
          />
          {/* <Row label="Duration" value={event.duration || '-'} /> */}
          <Row
            label="Speed"
            value={event.speed != null ? `${event.speed} kn` : '-'}
          />
          <Row
            label="Course"
            value={event.course != null ? `${event.course}°` : '-'}
          />
          <Row
            label="Draught"
            value={event.draught != null ? `${event.draught} m` : '-'}
          />
          <Row
            label="Navigational status"
            value={event.navigationalStatusStatus || '-'}
          />
        </div>
      )}
    </>
  );
}
