import { Tooltip } from 'flowbite-react';
import { FaVectorSquare } from 'react-icons/fa6';
import { HiX } from 'react-icons/hi';
import { LuArrowLeft } from 'react-icons/lu';
import { MdAutoAwesome } from 'react-icons/md';
import { useNavigate } from 'react-router';
import { isMara2Enabled } from '@/app/config/config';
import { ZoneInformation } from '@/features/Fleets/types/fleetEventTypes';
import {
  ASK_IQ_PATH,
  askIqPrompts,
  buildAskIqNavigationState,
} from '@/features/mara2/utils/askIq';
import FlagIcon from '@/shared/ui/FlagIcon';
import { truncateTitle } from '@/shared/utils/formatUtils';

interface SlideOutPanelHeaderProps {
  locationInformation: ZoneInformation;
  onClose?: () => void;
  showBackButton?: boolean;
  onBack?: () => void;
}
export default function LocationSlideOutHeader({
  locationInformation,
  onClose,
  showBackButton = false,
  onBack,
}: SlideOutPanelHeaderProps) {
  const navigate = useNavigate();

  const handleAskIQ = () => {
    if (!locationInformation.name) return;

    if (locationInformation.type === 'Ports') {
      navigate(
        ASK_IQ_PATH,
        buildAskIqNavigationState(askIqPrompts.port(locationInformation.name)),
      );
    } else {
      navigate(
        ASK_IQ_PATH,
        buildAskIqNavigationState(askIqPrompts.zone(locationInformation.name)),
      );
    }
  };

  return (
    <div className="flex w-full min-w-0 items-center justify-between gap-3">
      <div className={`flex w-full items-center gap-2`}>
        {showBackButton && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Close panel"
            className="shrink-0 rounded p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <LuArrowLeft className={`text-gray-400`} size={20} />
          </button>
        )}
        <Tooltip
          content={`View full details`}
          className={`flex h-6 items-center justify-center rounded-3xl text-xs`}
        >
          <button
            type="button"
            className="flex w-48 items-center justify-start gap-3 rounded-lg px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
            onClick={() => {
              if (locationInformation.type === 'Ports') {
                navigate(`/analytics/port/${locationInformation.id}`);
              } else {
                navigate(`/analytics/zone/${locationInformation.id}`);
              }
            }}
          >
            {locationInformation.type === 'Ports' ? (
              <FlagIcon flagCode={locationInformation.country_code} />
            ) : (
              <div
                className={`rounded-lg border border-gray-300 px-3 py-3 dark:border-gray-700`}
              >
                <FaVectorSquare className={`text-gray-500`} />
              </div>
            )}

            <span className="flex min-w-0 flex-col items-start">
              <span className="max-w-full truncate text-base font-bold">
                {locationInformation.name}
              </span>

              <span className="truncate text-xs text-gray-500 dark:text-gray-400">
                {locationInformation.type !== 'Ports'
                  ? truncateTitle(locationInformation.sub_type, 15)
                  : `${locationInformation.country_common_name} · ${locationInformation.unlocode}`}
              </span>
            </span>
          </button>
        </Tooltip>
      </div>

      <div className="flex shrink-0 items-center gap-4">
        {isMara2Enabled() && (
          <button
            type="button"
            onClick={handleAskIQ}
            className="flex shrink-0 items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
          >
            <MdAutoAwesome className="shrink-0 text-gray-400" />
            <span>Ask IQ</span>
          </button>
        )}

        <button
          type="button"
          onClick={onClose}
          aria-label="Close panel"
          className="shrink-0 rounded p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <HiX size={20} />
        </button>
      </div>
    </div>
  );
}
