import { AgChartOptions, AgDonutSeriesOptions } from 'ag-charts-enterprise';
import { forwardRef, useMemo } from 'react';
import { FleetCompositionItems } from '../types/fleetTypes';
import { colorForItem, shareTooltip } from '../utils/fleetUtils';
import { useTheme } from '@/app/context/ThemeProvider';
import {
  PoleStarChart,
  PoleStarChartHandle,
} from '@/shared/lib/PoleStarCharts';

export interface DonutChartProps {
  data: FleetCompositionItems[];
  total: number;
}

const Donut = forwardRef<PoleStarChartHandle, DonutChartProps>(
  ({ data, total }, ref) => {
    const { theme: themeMode } = useTheme();
    const prefersDark = window.matchMedia(
      '(prefers-color-scheme: dark)',
    ).matches;
    const isDarkMode =
      themeMode === 'dark' || (themeMode === 'system' && prefersDark);
    const textColor = isDarkMode ? '#E5E7EB' : '#111827';

    const options: AgChartOptions = useMemo(() => {
      const series: AgDonutSeriesOptions[] = [
        {
          type: 'donut',
          angleKey: 'count',
          legendItemKey: 'label',
          sectorSpacing: 4,
          fills: data.map((item, i) => colorForItem(item, i)),
          strokes: data.map((item, i) => colorForItem(item, i)),
          tooltip: {
            renderer: shareTooltip(total, data),
          },
          highlight: {
            unhighlightedItem: { opacity: 0.35 },
          },
        },
      ];

      return {
        data,
        series: series.map((s) => ({
          ...s,
          outerRadiusRatio: 1,
          innerRadiusRatio: 0.67,
        })),
        padding: { top: 4, right: 4, bottom: 4, left: 4 },
        legend: {
          position: 'bottom' as const,
          enabled: true,
          maxHeight: 60,
          item: {
            label: {
              color: textColor,
              fontSize: 11,
            },
            paddingX: 6,
            paddingY: 2,
          },
          pagination: {
            marker: {
              size: 12,
              shape: 'triangle',
            },
            label: {
              color: textColor,
            },
            activeStyle: {
              fill: textColor,
            },
            inactiveStyle: {
              fill: isDarkMode ? '#6B7280' : '#9CA3AF',
            },
          },
        },
        background: { fill: isDarkMode ? '#1F2937' : '#fff' },
        animation: { enabled: true, duration: 800 },
      };
    }, [data, total, isDarkMode, textColor]);

    return (
      <div className="h-full w-full">
        <PoleStarChart options={options} ref={ref} />
      </div>
    );
  },
);

Donut.displayName = 'Donut';

export default Donut;
