import { LuChevronRight } from 'react-icons/lu';
import { type Coverage, CoverageNote } from './ShowCoverage';

interface KpiCardsProps {
  title: string;
  value: string | number | undefined;
  isClickable?: boolean;
  handleClick?: () => void;
  showCoverage?: boolean;
  coverage?: Coverage;
  section?: string;
}

export default function KpiCards({
  title,
  value,
  isClickable = false,
  handleClick,
  showCoverage = false,
  coverage,
  section,
}: KpiCardsProps) {
  return (
    <div
      className={`flex h-24 w-full ${isClickable ? 'cursor-pointer items-center hover:bg-gray-200 dark:hover:bg-gray-700' : 'cursor-default items-start'} justify-between rounded-lg bg-white px-4 py-4 dark:bg-gray-800`}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          handleClick?.();
        }
      }}
    >
      <div className="flex flex-col gap-1">
        <p className="text-xs font-normal text-gray-500">{title}</p>
        <h3 className="text-xl font-bold">{value}</h3>
        {showCoverage && coverage && coverage?.known !== 0 && (
          <CoverageNote coverage={coverage} />
        )}
        {showCoverage && coverage && coverage?.known === 0 && (
          <span
            className={`inline-flex items-center gap-1 text-xs text-gray-500`}
          >
            No {section} data available
          </span>
        )}
      </div>
      {isClickable && <LuChevronRight className={`h-4 w-4 text-gray-400`} />}
    </div>
  );
}
