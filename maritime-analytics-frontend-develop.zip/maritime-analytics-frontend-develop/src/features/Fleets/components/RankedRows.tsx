import { toPng } from 'html-to-image';
import { forwardRef, useImperativeHandle, useRef } from 'react';
import { FleetCompositionItems } from '@/features/Fleets/types/fleetTypes';
import { colorForItem } from '@/features/Fleets/utils/fleetUtils';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';
import { logger } from '@/shared/utils/logger';

export interface RankedRowsProps {
  items: FleetCompositionItems[];
}

/**
 * Full ranked list shown when a chart's "Show all" toggle is on. The chart
 * itself stays capped at the top 5 — this is the only place the rest of the
 * ranking is visible.
 *
 * Exposes the same `PoleStarChartHandle` shape as the AG Charts wrappers so a
 * card's export-image button keeps working when it swaps between a chart and
 * this list — there's no chart instance here, so the image is a rasterized
 * snapshot of the list DOM instead.
 */
const RankedRows = forwardRef<PoleStarChartHandle, RankedRowsProps>(
  ({ items }, ref) => {
    const listRef = useRef<HTMLUListElement>(null);
    const max = Math.max(1, ...items.map((item) => item.count));

    useImperativeHandle(ref, () => ({
      downloadImage: (fileName = 'ranked-rows') => {
        if (!listRef.current) return;
        toPng(listRef.current, { pixelRatio: 2 })
          .then((dataUrl) => {
            const link = document.createElement('a');
            link.download = `${fileName}.png`;
            link.href = dataUrl;
            link.click();
          })
          .catch(() => {
            logger.error('Failed to export ranked rows as an image');
          });
      },
    }));

    return (
      <ul
        ref={listRef}
        className="flex h-full flex-col gap-1.5 overflow-y-auto bg-white dark:bg-gray-800"
      >
        {items.map((item, index) => (
          <li key={item.label} className="flex items-center gap-3 px-2 py-1.5">
            <span
              className="w-28 shrink-0 truncate text-right text-xs text-gray-800 dark:text-white"
              title={item.label}
            >
              {item.label}
            </span>
            <span
              aria-hidden
              className="block h-2.5 min-w-0 flex-1 rounded-full bg-gray-100 dark:bg-gray-700"
            >
              <span
                style={{
                  width: `${Math.max((item.count / max) * 100, 2)}%`,
                  backgroundColor: colorForItem(item, index),
                }}
                className="block h-full rounded-full"
              />
            </span>
            <span className="shrink-0 text-xs tabular-nums text-gray-500">
              {item.count.toLocaleString()}
            </span>
          </li>
        ))}
      </ul>
    );
  },
);

RankedRows.displayName = 'RankedRows';

export default RankedRows;
