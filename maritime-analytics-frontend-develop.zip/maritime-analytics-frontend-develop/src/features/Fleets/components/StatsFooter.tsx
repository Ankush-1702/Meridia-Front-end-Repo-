import { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa6';
import StatRow from '@/shared/components/StatRow';
import { cn } from '@/shared/utils/classMerge';

export default function StatsFooter({
  stats,
}: {
  stats: { avgAge: number; avgDwt: number; topFlag: string; topType: string };
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-t border-gray-200 dark:border-gray-700">
      {open && (
        <div className="border-b border-gray-200 px-5 dark:border-gray-700">
          <StatRow label="Average age" value={`${stats.avgAge} yrs`} />
          <StatRow label="Average DWT" value={`${stats.avgDwt}k`} />
          <StatRow label="Top flag" value={stats.topFlag} />
          <StatRow label="Top type" value={stats.topType} />
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-5 py-2.5 text-xs font-medium text-gray-900/60 hover:bg-gray-100/40 dark:text-white/60 dark:hover:bg-gray-700"
      >
        {open ? 'Hide Stats' : 'Show Stats'}
        <FaChevronDown
          className={cn('size-4 transition-transform', open && 'rotate-180')}
        />
      </button>
    </div>
  );
}
