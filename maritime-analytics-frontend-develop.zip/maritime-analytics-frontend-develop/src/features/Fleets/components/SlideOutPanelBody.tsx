import VesselMiniMap from '@/features/Fleets/components/VesselMiniMap';
import { VesselData } from '@/features/Fleets/types/fleetTypes';
import { formatCoordinate } from '@/features/Fleets/utils/fleetUtils';
import { usePtracScreening } from '@/features/Vessels/hooks/usePtracScreening';
import { PtracOverallStatus } from '@/features/Vessels/types/ptracTypes';
import {
  MtiScoreChip,
  PtracRisk,
  PtracRiskChip,
} from '@/shared/components/ScoreChips';
import {
  ComplianceRow,
  Heading,
  Row,
} from '@/shared/components/SlideOutComponents';
import {
  convertDateAndTimeToHumanReadableFormat,
  relativeTime,
} from '@/shared/utils/formatUtils';

const PTRAC_STATUS_TO_RISK: Record<PtracOverallStatus, PtracRisk> = {
  OK: 'OK',
  WARNING: 'Warning',
  CRITICAL: 'Critical',
  UNSCORED: 'N/A',
};

export default function SlideOutPanelBody({
  vesselData,
  hasMTIScore,
  hasPtracAccess,
}: {
  vesselData: VesselData;
  hasMTIScore?: boolean;
  hasPtracAccess?: boolean;
}) {
  const imo = vesselData?.vessel_information.imo;
  const { status: ptracStatus, loading: ptracLoading } = usePtracScreening(
    hasPtracAccess && imo ? imo : '',
  );
  const ptracRisk: PtracRisk = ptracStatus
    ? PTRAC_STATUS_TO_RISK[ptracStatus]
    : 'N/A';

  return (
    <>
      {/* TODO: Readd Image later */}
      {/* <div className="h-28 w-full overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700 ">
  
        <img
          alt={vesselData.vessel_information.name}
          className="size-full object-cover"
        />
      </div> */}
      {/* TODO: Readd the mt-4 when the image gets added */}
      <div className=" -mt-4 divide-y divide-gray-200 dark:divide-gray-700">
        <Row
          label="Type"
          value={vesselData.vessel_information.vessel_type || '-'}
        />
        <Row
          label="Class"
          value={vesselData.vessel_information.vessel_class || '-'}
        />
        <Row label="MMSI" value={vesselData.vessel_information.mmsi || '-'} />
        <Row
          label="Callsign"
          value={vesselData.vessel_information.callsign || '-'}
        />
        <Row label="Flag" value={vesselData.vessel_information.flag || '-'} />
        <Row
          label="Build year"
          value={vesselData.vessel_information.build_year || '-'}
        />
        <Row
          label="Age"
          value={
            vesselData.vessel_information.age != null
              ? `${vesselData.vessel_information.age} ${vesselData.vessel_information.age === 1 ? 'yr' : 'yrs'}`
              : vesselData.vessel_information.build_year != null
                ? `${new Date().getFullYear() - vesselData.vessel_information.build_year} ${new Date().getFullYear() - vesselData.vessel_information.build_year === 1 ? 'yr' : 'yrs'}`
                : '-'
          }
        />
        <Row
          label="DWT"
          value={
            vesselData.vessel_information.deadweight != null
              ? `${vesselData.vessel_information.deadweight.toLocaleString()} t`
              : '-'
          }
        />
        <Row
          label="Registry status"
          value={vesselData.vessel_information.vessel_status || '-'}
        />
        <ComplianceRow
          label="PurpleTRAC screening"
          info={`This vessel's sanctions-compliance risk, checked against global watchlists. Powered by PurpleTRAC.`}
          enabled={!!hasPtracAccess}
          loading={ptracLoading}
          href={`https://www.polestarglobal.com/purpletrac/`}
          upsell={{
            title: 'Unlock PurpleTRAC Screening',
            blurb:
              'Streamlined sanctions compliance — clear this vessel against global watchlists and demonstrate best efforts.',
            product: 'PurpleTRAC',
          }}
          value={<PtracRiskChip risk={ptracRisk} />}
          categoryUpsell={
            hasPtracAccess
              ? {
                  title: 'Get the full breakdown',
                  blurb:
                    'See every check behind this result — sanctions, PSC history, ship movement and more.',
                  product: 'PurpleTRAC',
                }
              : undefined
          }
        />
        <ComplianceRow
          label="MTI score"
          info={
            "A 0-5 score of how transparent and compliant this vessel's operations are — the higher the score, the lower the risk. Powered by the Maritime Transparency Index (MTI)."
          }
          enabled={hasMTIScore!}
          href={`https://www.polestarglobal.com/maritime-transparency-index/`}
          upsell={{
            title: 'Unlock MTI Score',
            blurb:
              'A credit score for the seas — benchmark this vessel and prioritise your exposure at a glance.',
            product: 'MTI',
          }}
          value={
            <MtiScoreChip
              score={vesselData.mti_score ? Number(vesselData.mti_score) : null}
            />
          }
          categoryUpsell={
            hasMTIScore
              ? {
                  title: "See what's behind the score",
                  blurb:
                    'See the full score profile across vessel, voyage, reporting and sanctions — and how this vessel ranks against its class and the global fleet.',
                  product: 'MTI',
                }
              : undefined
          }
        />
      </div>
      <Heading>Latest position</Heading>
      <div className={`h-40 w-full`}>
        <VesselMiniMap vessel={vesselData} />
      </div>
      <div className="mt-2 divide-y divide-gray-200 dark:divide-gray-700">
        <Row
          label="Nav Status"
          value={`${vesselData.vessel_position ? vesselData.vessel_position.navigational_status.status : '-'}`}
        />
        <Row
          label="Coordinates"
          value={`${
            vesselData.vessel_position
              ? `${formatCoordinate(vesselData.vessel_position?.latitude, 'N', 'S')}, ${formatCoordinate(
                  vesselData.vessel_position?.longitude,
                  'E',
                  'W',
                )}`
              : '-'
          }`}
        />
        <Row
          label="Speed"
          value={`${vesselData.vessel_position ? `${vesselData.vessel_position?.speed.toFixed(1)} kn` : '-'}`}
        />
        <Row
          label="Course"
          value={`${vesselData.vessel_position ? `${Math.round(vesselData.vessel_position?.course)}°` : '-'}`}
        />
        <Row
          label="Destination"
          value={
            vesselData.vessel_position?.reported_destination
              ? vesselData.vessel_position.reported_destination
              : '-'
          }
        />
        <Row
          label="ETA"
          value={`${
            vesselData.vessel_position
              ? `${convertDateAndTimeToHumanReadableFormat(
                  vesselData.vessel_position?.reported_eta,
                )} UTC`
              : '-'
          }`}
        />
        <Row
          label="Last reported"
          value={`${vesselData.vessel_position ? relativeTime(vesselData.vessel_position?.timestamp) : '-'}`}
        />
        <Row
          label="Source"
          value={`${vesselData.vessel_position ? vesselData.vessel_position?.source : '-'}`}
        />
      </div>
    </>
  );
}
