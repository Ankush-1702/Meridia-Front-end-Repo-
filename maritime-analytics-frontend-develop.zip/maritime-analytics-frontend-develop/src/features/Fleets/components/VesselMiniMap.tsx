import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { useEffect, useRef } from 'react';
import { useFleetMapInit } from '../hooks/useFleetMapInit';
import { VesselData } from '../types/fleetTypes';
import FleetVesselMarkerIcon from './FleetVesselMarkerIcon';
import { MAPBOX_TOKEN } from '@/app/config/config';
import { useTheme } from '@/app/context/ThemeProvider';
import MapboxMissingToken from '@/shared/components/MapboxMissingToken';
import {
  MAP_STYLES,
  MARKER_SIZE,
} from '@/shared/constants/overviewMapConstants';
import {
  createReactMarkerElement,
  type ReactMarkerHandle,
} from '@/shared/hooks/useReactMarker';
import {
  hashToRotation,
  isValidCoordinate,
} from '@/shared/utils/overviewMapUtils';

const VESSEL_MARKER_COLOR = '#f88e63'; // psg-orange-700
const MINI_MAP_ZOOM = 8;

interface VesselMiniMapProps {
  vessel: VesselData;
}

function getRotation(vessel: VesselData): number {
  const heading = vessel.vessel_position?.heading;
  const course = vessel.vessel_position?.course;
  if (typeof heading === 'number' && heading >= 0 && heading <= 360) {
    return heading;
  }
  if (typeof course === 'number' && course >= 0 && course <= 360) {
    return course;
  }
  return hashToRotation(vessel.vessel_information.imo);
}

export default function VesselMiniMap({ vessel }: VesselMiniMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  const position = vessel.vessel_position;
  const hasValidPosition = isValidCoordinate(
    position?.latitude,
    position?.longitude,
  );

  const { mapRef, mapReady } = useFleetMapInit(
    containerRef,
    isDarkMode ? MAP_STYLES.dark : MAP_STYLES.light,
    position && hasValidPosition
      ? {
          latitude: position.latitude,
          longitude: position.longitude,
        }
      : undefined,
    hasValidPosition ? MINI_MAP_ZOOM : undefined,
  );

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady || !position || !hasValidPosition) return;

    const { latitude, longitude } = position;
    const rotation = getRotation(vessel);

    const handle: ReactMarkerHandle = createReactMarkerElement(
      <FleetVesselMarkerIcon
        size={MARKER_SIZE}
        rotationDeg={rotation}
        color={VESSEL_MARKER_COLOR}
      />,
    );

    const marker = new mapboxgl.Marker({ element: handle.element })
      .setLngLat([longitude, latitude])
      .addTo(map);

    return () => {
      marker.remove();
      handle.unmount();
    };
  }, [mapRef, mapReady, hasValidPosition, vessel, position]);

  return (
    <div
      className={`relative h-full w-full overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700`}
    >
      <div ref={containerRef} className="h-full w-full" />
      {!MAPBOX_TOKEN && <MapboxMissingToken />}
    </div>
  );
}
