import { ZoneInformation } from '../types/fleetEventTypes';
import { formatCoordinate } from '../utils/fleetUtils';
import { Heading, Row } from '@/shared/components/SlideOutComponents';
import { ILiveDataResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

export interface LocationSlideOutBodyProps {
  location: ZoneInformation;
  vesselsInPortOrZone: number;
  locationEvents?: ILiveDataResponse;
}
export default function LocationSlideOutBody({
  location,
  vesselsInPortOrZone,
  locationEvents,
}: LocationSlideOutBodyProps) {
  const isZone = location.type !== 'Ports';
  const movementTotals = locationEvents?.totals;
  let arrivalsOrEntries: number | undefined;
  let departuresOrExits: number | undefined;

  if (movementTotals && isZone && 'entries' in movementTotals) {
    arrivalsOrEntries = movementTotals.entries;
    departuresOrExits = movementTotals.exits;
  } else if (movementTotals && !isZone && 'arrivals' in movementTotals) {
    arrivalsOrEntries = movementTotals.arrivals;
    departuresOrExits = movementTotals.departures;
  }

  return (
    <>
      {location.type === 'Ports' && (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Country"
            value={
              location.country_common_name ? location.country_common_name : '-'
            }
          />
          <Row
            label="UN/LOCODE"
            value={location.unlocode ? location.unlocode : '-'}
          />
          <Row
            label="Centre Point"
            value={`${
              location.centroid
                ? `${formatCoordinate(location.centroid.latitude, 'N', 'S')}, ${formatCoordinate(
                    location.centroid.longitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }`}
          />
        </div>
      )}
      {location.type !== 'Ports' && (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          <Row label="Type" value={location.type ? location.type : '-'} />
          <Row
            label="Sub Type"
            value={location.sub_type ? location.sub_type : '-'}
          />
        </div>
      )}
      <Heading>Last 24 hours</Heading>
      <div className="grid grid-cols-3 gap-2">
        <LocationCard
          label={isZone ? 'Entries' : 'Arrivals'}
          value={arrivalsOrEntries}
        />
        <LocationCard
          label={isZone ? 'In zone' : 'In port'}
          value={vesselsInPortOrZone}
        />
        <LocationCard
          label={isZone ? 'Exits' : 'Departures'}
          value={departuresOrExits}
        />
      </div>
    </>
  );
}

function LocationCard({
  label,
  value,
}: {
  label: string;
  value: string | number | undefined;
}) {
  return (
    <div
      className={`flex flex-col rounded-lg border border-gray-200 bg-gray-100 px-3 py-3 text-left dark:border-gray-700 dark:bg-gray-800`}
    >
      <span className={`text-lg font-bold text-gray-900 dark:text-white`}>
        {value ?? '-'}
      </span>
      <span className={`text-xs text-gray-500 dark:text-gray-400`}>
        {label}
      </span>
    </div>
  );
}
