import { Checkbox, Tooltip } from 'flowbite-react';
import { useState } from 'react';
import { FaChevronDown, FaChevronUp } from 'react-icons/fa';
import FleetVesselMarkerIcon from './FleetVesselMarkerIcon';
// import { countries } from '@/features/library/utils/countryMapping';
// import FlagIcon from '@/shared/ui/FlagIcon';
import {
  getColor,
  getDisplayName,
} from '@/shared/utils/CongestionAndTrafficUtils';
import { truncateTitle } from '@/shared/utils/formatUtils';

interface FleetMapLegendProps {
  activeTab: 'Flag' | 'Type';
  onTabChange: (tab: 'Flag' | 'Type') => void;
  types: string[];
  flags: string[];
  visibleTypes: Record<string, boolean>;
  visibleFlags: Record<string, boolean>;
  onToggleType: (type: string, checked: boolean) => void;
  onToggleFlag: (flag: string, checked: boolean) => void;
}

export default function FleetMapLegend({
  activeTab,
  onTabChange,
  types,
  // flags,
  visibleTypes,
  // visibleFlags,
  onToggleType,
  // onToggleFlag,
}: FleetMapLegendProps) {
  const [open, setOpen] = useState(false);

  return (
    <div
      className={`select-none overflow-hidden rounded-lg bg-white shadow-2xl transition-all duration-200 dark:bg-gray-800 ${
        open ? 'w-[240px]' : 'w-[150px]'
      }`}
    >
      {/* Header */}
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex w-full cursor-pointer items-center justify-between px-4 py-2.5 transition-colors hover:bg-gray-50 dark:hover:bg-gray-700"
      >
        <span className="text-xs font-semibold text-gray-900 dark:text-white">
          Legend
        </span>
        {open ? (
          <FaChevronUp size={10} className="text-gray-400" />
        ) : (
          <FaChevronDown size={10} className="text-gray-400" />
        )}
      </button>
      {open && (
        <div className="max-h-56 overflow-y-auto px-4 pb-4">
          <div
            className={`-mx-4 flex h-9 items-center gap-3 border-b border-t border-gray-200 px-4 dark:border-gray-700`}
          >
            <p className={`text-xs`}>By</p>
            {/* <button
              className={`rounded px-1 py-1 text-xs ${activeTab === 'Flag' ? 'bg-psg-orange-200 text-psg-orange-700 dark:bg-gray-700' : 'hover:bg-orange-200 hover:text-psg-orange-700 dark:hover:bg-gray-700'}`}
              onClick={() => onTabChange('Flag')}
            >
              Flag
            </button> */}
            <button
              className={`rounded px-1 py-1 text-xs ${activeTab === 'Type' ? 'bg-psg-orange-200 text-psg-orange-700 dark:bg-gray-700' : 'hover:bg-orange-200 hover:text-psg-orange-700 dark:hover:bg-gray-700'}`}
              onClick={() => onTabChange('Type')}
            >
              Type
            </button>
          </div>

          <div className="mt-3 space-y-3">
            {activeTab === 'Type' &&
              types.map((type) => (
                <Tooltip
                  key={type}
                  content={getDisplayName(type)}
                  placement="right"
                  className="whitespace-nowrap rounded text-xs"
                  arrow={false}
                >
                  <label
                    htmlFor={`fleet-legend-type-${type}`}
                    className="flex cursor-pointer items-center gap-2"
                  >
                    <Checkbox
                      id={`fleet-legend-type-${type}`}
                      checked={visibleTypes[type] !== false}
                      onChange={(e) => onToggleType(type, e.target.checked)}
                      color="psgLightPrimary"
                    />
                    <FleetVesselMarkerIcon
                      size={16}
                      rotationDeg={-60}
                      color={getColor(type)}
                    />
                    <span className="flex-1 truncate text-xs text-gray-700 dark:text-gray-300">
                      {truncateTitle(getDisplayName(type))}
                    </span>
                  </label>
                </Tooltip>
              ))}

            {/* {activeTab === 'Flag' &&
              flags.map((flag) => (
                <Tooltip
                  key={flag}
                  content={countries[flag] ?? flag}
                  placement="right"
                  className="whitespace-nowrap rounded text-xs"
                  arrow={false}
                >
                  <label
                    htmlFor={`fleet-legend-flag-${flag}`}
                    className="flex cursor-pointer items-center gap-2"
                  >
                    <Checkbox
                      id={`fleet-legend-flag-${flag}`}
                      checked={visibleFlags[flag] !== false}
                      onChange={(e) => onToggleFlag(flag, e.target.checked)}
                      color="psgLightPrimary"
                    />
                    <FlagIcon flagCode={flag} />
                    <span className="flex-1 truncate text-xs text-gray-700 dark:text-gray-300">
                      {truncateTitle(countries[flag]) ?? flag}
                    </span>
                  </label>
                </Tooltip>
              ))} */}
          </div>
        </div>
      )}
    </div>
  );
}
