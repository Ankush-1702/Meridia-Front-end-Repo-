import { Tooltip } from 'flowbite-react';
import { FaCircleInfo } from 'react-icons/fa6';
import { cn } from '@/shared/utils/classMerge';

export interface Coverage {
  known: number;
  total: number;
  complete: boolean;
}

export function CoverageNote({
  coverage,
  className,
}: {
  coverage: Coverage;
  className?: string;
}) {
  if (coverage.complete) return null;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 text-xs text-gray-500',
        className,
      )}
    >
      Based on {coverage.known} of {coverage.total} vessels
      <Tooltip
        content={`Only ${coverage.known} of the ${coverage.total} vessels in this fleet have adequate data for this metric.`}
        className="max-w-xs !px-2.5 !py-2 !text-xs"
      >
        <FaCircleInfo className="size-3.5 shrink-0 cursor-help text-gray-500/60 hover:text-gray-500" />
      </Tooltip>
    </span>
  );
}
