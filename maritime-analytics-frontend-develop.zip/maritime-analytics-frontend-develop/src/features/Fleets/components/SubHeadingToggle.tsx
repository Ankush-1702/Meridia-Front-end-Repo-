export type SubHeadingView = 'top5' | 'all';

export interface SubHeadingToggleProps {
  view: SubHeadingView;
  onChange: (view: SubHeadingView) => void;
  disabled?: boolean;
  count?: number | string;
}

export default function SubHeadingToggle({
  view,
  onChange,
  disabled = false,
  count,
}: SubHeadingToggleProps) {
  return (
    <button
      type="button"
      className="cursor-pointer text-xs text-gray-400/60 enabled:text-gray-400  enabled:hover:underline disabled:cursor-default"
      onClick={() => onChange(view === 'top5' ? 'all' : 'top5')}
      disabled={disabled}
    >
      {view === 'top5' ? `Show all (${count})` : 'Show top 5'}
    </button>
  );
}
