import { Label, Textarea, TextInput } from 'flowbite-react';
import { useState } from 'react';

const MAX_NAME_LENGTH = 100;
const MAX_DESCRIPTION_LENGTH = 200;

interface CreateFleetDetailsCardProps {
  name: string;
  description: string;
  setName: (val: string) => void;
  setDescription: (val: string) => void;
  nameError?: string;
}

export default function CreateFleetDetailsCard({
  name,
  description,
  setName,
  setDescription,
  nameError,
}: CreateFleetDetailsCardProps) {
  const [nameTouched, setNameTouched] = useState(false);
  const showNameError = nameTouched && !!nameError;

  return (
    <div
      className={`flex max-w-[1000px] flex-col rounded-lg bg-white dark:bg-gray-800`}
    >
      <header className={`border-b p-4 text-sm font-bold dark:border-gray-700`}>
        Details
      </header>
      <div className={`flex flex-col gap-3 px-4 pt-4`}>
        <Label
          value={'Name'}
          className="font-semibold after:ml-0.5 after:text-red-600 after:content-['*']"
        />
        <TextInput
          className={`w-full max-w-[500px]`}
          maxLength={MAX_NAME_LENGTH}
          value={name}
          color={showNameError ? 'failure' : undefined}
          onChange={(e) => {
            setName(e.target.value);
            if (!nameTouched) setNameTouched(true);
          }}
          onBlur={() => setNameTouched(true)}
        />
        <div className={`flex w-full max-w-[500px]`}>
          {showNameError && (
            <span className={`text-xs text-red-600`}>{nameError}</span>
          )}
          <span className={`ml-auto text-right text-[10px] text-gray-500`}>
            {name.length}/{MAX_NAME_LENGTH}
          </span>
        </div>
      </div>
      <div className={`flex flex-col gap-3 p-4`}>
        <Label
          value={`Description`}
          className="font-semibold after:ml-1.5 after:font-medium after:text-gray-500 after:content-['(optional)']"
        />
        <Textarea
          rows={3}
          value={description}
          className={`max-h-[140px] min-h-[72px] w-full max-w-[500px] resize-y overflow-y-auto`}
          placeholder={`What this fleet is for`}
          maxLength={MAX_DESCRIPTION_LENGTH}
          onChange={(e) => setDescription(e.target.value)}
        />
        <span
          className={`w-full max-w-[500px] text-right text-[10px] text-gray-500`}
        >
          {description.length}/{MAX_DESCRIPTION_LENGTH}
        </span>
      </div>
    </div>
  );
}
