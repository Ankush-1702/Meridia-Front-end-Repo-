import { Dropdown, TextInput } from 'flowbite-react';
import { useMemo, useRef } from 'react';
import { FaMagnifyingGlass } from 'react-icons/fa6';
import { LuChevronDown } from 'react-icons/lu';
import { VesselData } from '../types/fleetTypes';
import {
  filterPanelTheme,
  searchFieldTheme,
} from '@/app/config/flowbite-theme';
import { EntityCard } from '@/shared/components/EntityCard';
import FlagIcon from '@/shared/ui/FlagIcon';
import { cn } from '@/shared/utils/classMerge';

const SORTS = [
  { id: 'name', label: 'Name' },
  { id: 'imo', label: 'IMO' },
] as const;

export type SortId = (typeof SORTS)[number]['id'];
interface VesselSlideOutBodyProps {
  query: string;
  setQuery: (value: string) => void;
  sort: SortId;
  setSort: (sort: SortId) => void;
  setDrillImo: (v: VesselData) => void;
  vessels: VesselData[];
}

export default function VesselSlideOutBody({
  query,
  setQuery,
  sort,
  setSort,
  setDrillImo,
  vessels,
}: VesselSlideOutBodyProps) {
  const rowRef = useRef<HTMLDivElement>(null);

  const found = useMemo(() => {
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    const filtered = terms.length
      ? vessels.filter((v) => {
          const hay =
            `${v.vessel_information.name} ${v.vessel_information.imo} ${v.vessel_information.vessel_type} ${v.vessel_information.vessel_class} ${v.vessel_information.flag}`.toLowerCase();
          return terms.every((t) => hay.includes(t));
        })
      : vessels;
    return [...filtered].sort((a, b) =>
      a.vessel_information[sort].localeCompare(b.vessel_information[sort]),
    );
  }, [vessels, query, sort]);

  return (
    <>
      <div
        ref={rowRef}
        className="sticky -top-6 z-10 -mx-5 -mt-4 flex items-center gap-2 bg-white px-5 py-3 dark:bg-gray-800"
      >
        <TextInput
          theme={searchFieldTheme}
          icon={FaMagnifyingGlass}
          placeholder="Search name, IMO, type, class…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="min-w-0 flex-1"
        />
        <Dropdown
          inline
          label
          arrowIcon={false}
          placement="bottom-end"
          theme={filterPanelTheme}
          renderTrigger={() => (
            <button
              type="button"
              className="flex shrink-0 cursor-pointer items-center gap-1.5 rounded-md border border-gray-200 bg-white px-2.5 py-1.5 text-sm text-gray-900 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
            >
              <span className="text-gray-900/70 dark:text-white/70">Sort</span>
              {SORTS.find((o) => o.id === sort)?.label}
              <LuChevronDown className="size-3.5 text-gray-400" />
            </button>
          )}
        >
          <div className="w-36 p-1">
            {SORTS.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => setSort(o.id)}
                className={`block w-full cursor-pointer rounded-md px-3 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 ${
                  o.id === sort
                    ? 'bg-gray-100 font-medium dark:bg-gray-700'
                    : ''
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>
        </Dropdown>
        {/* Only once something is actually underneath it. Permanently on, a
                  gradient under a header reads as a bolted-on shadow. */}
        <div
          className={cn(
            'pointer-events-none absolute inset-x-0 top-full h-4 bg-gradient-to-b from-card to-transparent transition-opacity duration-200',
          )}
        />
      </div>
      <div className="flex flex-col gap-2">
        {found.map((v) => (
          <EntityCard
            key={v.vessel_information.imo}
            icon={<FlagIcon flagCode={v.vessel_information.flag_code} />}
            name={v.vessel_information.name}
            sub={`${v.vessel_information.imo} · ${v.vessel_information.vessel_type} · ${v.vessel_information.vessel_class}`}
            onClick={() => {
              setDrillImo(v);
              setQuery('');
            }}
          />
        ))}
      </div>
      {found.length === 0 && (
        <p className="absolute inset-0 flex items-center justify-center px-5 text-center text-sm text-gray-900 dark:text-white">
          {query
            ? `No vessels match “${query}”.`
            : 'No vessels match these filters.'}
        </p>
      )}
    </>
  );
}
