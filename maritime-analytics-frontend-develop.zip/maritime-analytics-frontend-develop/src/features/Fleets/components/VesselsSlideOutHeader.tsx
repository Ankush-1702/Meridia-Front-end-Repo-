import { HiX } from 'react-icons/hi';

interface VesselsSlideOutHeaderProps {
  onClose?: () => void;
  totalCount: number;
  filteredCount: number;
}
export default function VesselsSlideOutHeader({
  onClose,
  totalCount,
  filteredCount,
}: VesselsSlideOutHeaderProps) {
  return (
    <div className="flex w-full min-w-0 items-center justify-between gap-3 px-2">
      <span className={`flex items-center text-base font-bold`}>
        Vessels ({filteredCount} of {totalCount})
      </span>
      <button
        type="button"
        onClick={onClose}
        aria-label="Close panel"
        className="shrink-0 rounded p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
      >
        <HiX size={20} />
      </button>
    </div>
  );
}
