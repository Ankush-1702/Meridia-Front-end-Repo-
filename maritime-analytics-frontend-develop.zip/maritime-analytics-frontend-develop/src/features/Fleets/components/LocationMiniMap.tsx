import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { useEffect, useMemo, useRef } from 'react';
import { useFleetCenterPin } from '../hooks/useFleetCenterPin';
import { useFleetEventMarkers } from '../hooks/useFleetEventMarkers';
import { useFleetMapInit } from '../hooks/useFleetMapInit';
import type { FlatFleetEventsResponse } from '../types/fleetEventTypes';
import type { VesselData } from '../types/fleetTypes';
import FleetVesselMarkerIcon from './FleetVesselMarkerIcon';
import { MAPBOX_TOKEN } from '@/app/config/config';
import { useTheme } from '@/app/context/ThemeProvider';
import MapboxMissingToken from '@/shared/components/MapboxMissingToken';
import {
  MAP_STYLES,
  MARKER_SIZE,
} from '@/shared/constants/overviewMapConstants';
import {
  ReactMarkerHandle,
  createReactMarkerElement,
} from '@/shared/hooks/useReactMarker';
import { useZoneBoundary } from '@/shared/hooks/useZoneBoundary';
import { OverviewMapCenter } from '@/shared/types/OverviewMapTypes';
import {
  hashToRotation,
  isValidCoordinate,
} from '@/shared/utils/overviewMapUtils';

const VESSEL_MARKER_COLOR = '#f88e63'; // psg-orange-700
const MINI_MAP_ZOOM = 8;
const VESSEL_EVENT_ZOOM = 11;
const LOCATION_BOUNDARY_ZOOM = 9;
const PORT_AND_ZONE_EVENT_TYPES = new Set<string>([
  'PORT_ARRIVAL',
  'PORT_DEPARTURE',
  'PORT_AREA_ARRIVAL',
  'PORT_AREA_DEPARTURE',
  'ZONE_ENTRY',
  'ZONE_EXIT',
]);

export interface LocationMiniMapProps {
  vessel?: VesselData;
  boundaryGeometry?: string;
  label?: string;
  center?: OverviewMapCenter;
  event?: FlatFleetEventsResponse;
}

function getRotation(
  vessel?: VesselData,
  event?: FlatFleetEventsResponse,
): number {
  const heading = vessel?.vessel_position?.heading;
  const course = vessel?.vessel_position?.course;
  if (typeof heading === 'number' && heading >= 0 && heading <= 360) {
    return heading;
  }
  if (typeof course === 'number' && course >= 0 && course <= 360) {
    return course;
  }
  if (
    typeof event?.heading === 'number' &&
    event.heading >= 0 &&
    event.heading <= 360
  ) {
    return event.heading;
  }
  if (
    typeof event?.course === 'number' &&
    event.course >= 0 &&
    event.course <= 360
  ) {
    return event.course;
  }
  const imo = vessel?.vessel_information.imo ?? event?.imo;
  return imo ? hashToRotation(imo) : 0;
}

export default function LocationMiniMap({
  vessel,
  boundaryGeometry,
  label,
  center,
  event,
}: LocationMiniMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  const usesEventPosition = PORT_AND_ZONE_EVENT_TYPES.has(
    event?.eventType ?? '',
  );
  const latitude = usesEventPosition
    ? event?.zonePortEventLocationLat
    : undefined;
  const longitude = usesEventPosition
    ? event?.zonePortEventLocationLng
    : undefined;
  const hasValidPosition = isValidCoordinate(latitude, longitude);
  const shouldZoomToVessel =
    usesEventPosition && Boolean(vessel) && hasValidPosition;
  const viewportCenter = useMemo(
    () =>
      shouldZoomToVessel && latitude != null && longitude != null
        ? { latitude, longitude }
        : center,
    [center, latitude, longitude, shouldZoomToVessel],
  );
  const mapZoom = usesEventPosition
    ? shouldZoomToVessel
      ? VESSEL_EVENT_ZOOM
      : center
        ? LOCATION_BOUNDARY_ZOOM
        : undefined
    : center
      ? MINI_MAP_ZOOM
      : undefined;

  const { mapRef, mapReady } = useFleetMapInit(
    containerRef,
    isDarkMode ? MAP_STYLES.dark : MAP_STYLES.light,
    viewportCenter,
    mapZoom,
  );

  useFleetCenterPin(
    mapRef,
    mapReady,
    center,
    mapZoom ?? MINI_MAP_ZOOM,
    label,
    shouldZoomToVessel ? viewportCenter : undefined,
  );
  useFleetEventMarkers(mapRef, mapReady, event, center);

  useZoneBoundary(mapRef, mapReady, boundaryGeometry);

  useEffect(() => {
    const map = mapRef.current;
    if (
      !map ||
      !mapReady ||
      !usesEventPosition ||
      !hasValidPosition ||
      latitude == null ||
      longitude == null
    ) {
      return;
    }

    const rotation = getRotation(vessel, event);

    const handle: ReactMarkerHandle = createReactMarkerElement(
      <FleetVesselMarkerIcon
        size={MARKER_SIZE}
        rotationDeg={rotation}
        color={VESSEL_MARKER_COLOR}
      />,
    );

    const marker = new mapboxgl.Marker({ element: handle.element })
      .setLngLat([longitude, latitude])
      .addTo(map);

    return () => {
      marker.remove();
      handle.unmount();
    };
  }, [
    mapRef,
    mapReady,
    usesEventPosition,
    hasValidPosition,
    latitude,
    longitude,
    vessel,
    event,
  ]);

  return (
    <div
      className={`relative h-full w-full overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700`}
    >
      <div ref={containerRef} className="h-full w-full" />
      {!MAPBOX_TOKEN && <MapboxMissingToken />}
    </div>
  );
}
