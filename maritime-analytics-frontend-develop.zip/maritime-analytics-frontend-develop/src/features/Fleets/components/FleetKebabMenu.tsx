import { KebabMenu } from '@/shared/ui/KebabMenu';

type Props = {
  onEdit?: () => void;
  onDelete?: () => void;
};

export function FleetKebabMenu({ onEdit, onDelete }: Props) {
  return (
    <KebabMenu className="px-2 py-2">
      {onEdit && (
        <div className="border-b border-gray-200 dark:border-gray-700">
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
            onClick={onEdit}
          >
            Edit
          </button>
        </div>
      )}
      {onDelete && (
        <div>
          <button
            className="w-full px-4 py-2 text-left text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
            onClick={onDelete}
          >
            Delete
          </button>
        </div>
      )}
    </KebabMenu>
  );
}
