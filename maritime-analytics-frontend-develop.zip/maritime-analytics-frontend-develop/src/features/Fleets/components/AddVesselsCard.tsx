import { Button, Spinner, Textarea } from 'flowbite-react';
import React from 'react';
import { LuCheck, LuDownload, LuUpload, LuX } from 'react-icons/lu';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import Filter from '@/shared/components/Filter';
import TabGroup from '@/shared/components/TabGroup';
import { useEscapeClose } from '@/shared/hooks/useEscapeClose';
import { useOnClickOutside } from '@/shared/hooks/useOnClickOutside';
import FlagIcon from '@/shared/ui/FlagIcon';
import { cn } from '@/shared/utils/classMerge';

interface AddVesselCardProps {
  query: string;
  tabs: string[];
  onTabChange: (tab: string) => void;
  activeTab: string;
  onQueryChange: (value: string) => void;
  onClear: () => void;
  results: VesselSearch[];
  handleScroll: (e: React.UIEvent<HTMLDivElement>) => void;
  onSelectVessel: (v: VesselSearch) => void;
  selectedImos: Set<string>;
  isLoading: boolean;
  loadingMore: boolean;
  error: string | null;
  hasSearched: boolean;
  debouncedQuery: string;
  bulkImos: string;
  setBulkImos: (imos: string) => void;
  onUpload: () => void;
  onDownload: () => void;
  fileInputRef: React.RefObject<HTMLInputElement>;
  file: File | null;
  setFile: (f: File | null) => void;
  handleDrop: (e: React.DragEvent) => void;
  handleDragOver: (e: React.DragEvent) => void;
  handleFile: (f: File) => void;
  verifying: boolean;
}

export default function AddVesselsCard({
  query,
  tabs,
  onTabChange,
  activeTab,
  onQueryChange,
  onClear,
  results,
  handleScroll,
  onSelectVessel,
  selectedImos,
  isLoading,
  loadingMore,
  error,
  hasSearched,
  debouncedQuery,
  bulkImos,
  setBulkImos,
  onUpload,
  onDownload,
  fileInputRef,
  file,
  setFile,
  handleDrop,
  handleDragOver,
  handleFile,
  verifying,
}: AddVesselCardProps) {
  const searchAreaRef = React.useRef<HTMLDivElement>(null);
  const [isDropdownOpen, setIsDropdownOpen] = React.useState(false);

  const isSettled = query === debouncedQuery;
  const showNoResults =
    isSettled &&
    hasSearched &&
    !isLoading &&
    !error &&
    results.length === 0 &&
    query.trim().length > 0;

  React.useEffect(() => {
    if (results.length > 0) setIsDropdownOpen(true);
  }, [results]);

  useOnClickOutside(searchAreaRef, () => setIsDropdownOpen(false));
  useEscapeClose(() => setIsDropdownOpen(false));

  const handleClear = () => {
    onClear();
    setIsDropdownOpen(false);
  };

  const handleFocus = () => {
    if (results.length > 0 && query.trim().length > 0) {
      setIsDropdownOpen(true);
    }
  };

  return (
    <div
      className={`flex max-w-[1000px] flex-col rounded-lg bg-white dark:bg-gray-800`}
    >
      {' '}
      <header className={`border-b p-4 text-sm font-bold dark:border-gray-700`}>
        Add Vessels
      </header>
      <div className="w-fit p-4">
        <TabGroup
          tabs={tabs}
          active={activeTab}
          onChange={onTabChange}
          size="sm"
          className={`bg-white dark:bg-gray-800`}
          key={`Fleet type`}
        />
      </div>
      {activeTab === 'Search' && (
        <div className="mb-3 w-full p-4">
          <div className="relative" ref={searchAreaRef}>
            <div onFocusCapture={handleFocus}>
              <Filter
                width={`w-full`}
                placeholder="Search vessel name or IMO..."
                query={query}
                setQuery={onQueryChange}
              />
            </div>
            {isLoading && (
              <div className="absolute right-2 top-1/2 -translate-y-1/2">
                <Spinner size="sm" light color="psgPrimary" />
              </div>
            )}
            {!isLoading && query.length > 0 && (
              <button
                type="button"
                onClick={handleClear}
                aria-label="Clear search"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 focus:outline-none dark:text-gray-400 dark:hover:text-gray-200"
              >
                <LuX className="size-4" />
              </button>
            )}
            {isDropdownOpen && results.length > 0 && (
              <div
                className="absolute z-20 mt-3 max-h-60 w-full overflow-y-auto rounded-lg border border-gray-300 bg-white shadow-lg dark:border-gray-700 dark:bg-gray-800"
                onScroll={handleScroll}
                style={{ maxHeight: 'min(15rem, calc(100dvh - 20rem))' }}
              >
                <ul className="space-y-1">
                  {results.map((v) => {
                    const isSelected = selectedImos.has(v.imo);
                    return (
                      <li key={v.imo}>
                        <button
                          type="button"
                          disabled={isSelected}
                          onClick={() => !isSelected && onSelectVessel(v)}
                          className={cn(
                            'flex w-full items-center justify-between gap-2 px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700',
                            isSelected &&
                              'cursor-default opacity-50 hover:bg-transparent dark:hover:bg-transparent',
                          )}
                        >
                          <div className={`flex items-center gap-2`}>
                            <FlagIcon flagCode={v.flag_code} />
                            <div className={`flex flex-col`}>
                              <span className="flex-1 font-semibold">
                                {v.name}
                              </span>
                              <span className="text-xs text-gray-500">
                                {v.imo} · {v.vessel_type}
                              </span>
                            </div>
                          </div>
                          {isSelected && (
                            <LuCheck className="size-4 shrink-0 text-psg-orange-700" />
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
                {loadingMore && (
                  <div className="flex justify-center py-3">
                    <Spinner light size="sm" color="psgPrimary" />
                  </div>
                )}
              </div>
            )}
          </div>

          {error && (
            <div
              className="mt-2 text-sm text-red-600 dark:text-red-400"
              role="alert"
            >
              {error}
            </div>
          )}
          {showNoResults && (
            <div className="mt-2 text-sm text-gray-500">
              No results found for{' '}
              <span className="font-semibold">"{query}"</span>
            </div>
          )}
        </div>
      )}
      {activeTab === 'Bulk Import' &&
        (() => {
          const isPasteEnabled = !file;
          const isUploadEnabled = bulkImos.trim().length === 0;
          return (
            <div className={`mb-3 flex gap-4 px-4 pb-4`}>
              <div
                className={cn(
                  `mr-10 w-full`,
                  !isPasteEnabled && 'pointer-events-none opacity-50',
                )}
              >
                <div className={`flex flex-col space-y-2`}>
                  <p className={`text-sm font-semibold`}>Paste IMO numbers</p>
                  <p className={`text-xs text-gray-400`}>
                    Comma or space separated
                  </p>
                  <Textarea
                    placeholder={`e.g 9459044, 9459045, 9459046`}
                    rows={5}
                    className={`max-h-[140px] min-h-[72px]`}
                    value={bulkImos}
                    onChange={(e) => setBulkImos(e.target.value)}
                    disabled={!isPasteEnabled}
                  />
                </div>
                <Button
                  color={`gray`}
                  size={`xs`}
                  className={`mt-2`}
                  disabled={!bulkImos || !isPasteEnabled || verifying}
                  onClick={onUpload}
                >
                  {verifying && bulkImos ? 'Adding...' : 'Add'}
                </Button>
              </div>
              <div className="w-px self-stretch bg-gray-300 dark:bg-gray-700" />
              <div
                className={cn(
                  `ml-10 w-full`,
                  !isUploadEnabled && 'pointer-events-none opacity-50',
                )}
              >
                <div className={`flex flex-col space-y-2`}>
                  <div className={`flex justify-between`}>
                    <div className={`flex flex-col gap-1`}>
                      <p className={`text-sm font-semibold`}>Upload CSV</p>
                      <p className={`text-xs text-gray-400`}>One IMO per row</p>
                    </div>
                    <Button
                      color={`gray`}
                      size={`xs`}
                      className={`flex items-center font-medium`}
                      onClick={onDownload}
                      disabled={!isUploadEnabled}
                    >
                      <div className={`mr-1 flex items-center`}>
                        <LuDownload className={`font-medium text-gray-500`} />
                      </div>
                      Download template
                    </Button>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv"
                    className="hidden"
                    disabled={!isUploadEnabled}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFile(f);
                    }}
                  />
                  <div
                    className="mb-6 flex h-32 cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 transition-colors dark:border-gray-700"
                    role="button"
                    tabIndex={isUploadEnabled ? 0 : -1}
                    aria-label="Click to upload or drag and drop"
                    aria-disabled={!isUploadEnabled}
                    onClick={() =>
                      isUploadEnabled && fileInputRef.current?.click()
                    }
                    onKeyDown={(e) =>
                      isUploadEnabled &&
                      e.key === 'Enter' &&
                      fileInputRef.current?.click()
                    }
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                  >
                    <LuUpload className="h-4 w-4 text-gray-500" />
                    {file ? (
                      <div className="flex items-center gap-2">
                        <p className="max-w-[180px] truncate text-sm font-semibold text-gray-500">
                          {file.name}
                        </p>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFile(null);
                            if (fileInputRef.current)
                              fileInputRef.current.value = '';
                          }}
                          aria-label="Remove file"
                        >
                          <LuX className="h-4 w-4 text-gray-500 hover:text-red-500" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm font-semibold text-gray-500">
                          Drag & drop a file
                        </p>
                        <p className="text-xs font-medium text-gray-500">
                          or click to browse
                        </p>
                      </>
                    )}
                  </div>
                </div>
                <Button
                  color={`gray`}
                  size={`xs`}
                  className={`mt-2`}
                  disabled={!file || !isUploadEnabled || verifying}
                  onClick={onUpload}
                >
                  <div className={`mr-1 flex items-center`}>
                    <LuUpload className={`font-medium text-gray-500`} />
                  </div>
                  {verifying && file ? 'Uploading...' : 'Upload'}
                </Button>
              </div>
            </div>
          );
        })()}
    </div>
  );
}
