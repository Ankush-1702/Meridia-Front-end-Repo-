import { AgChartOptions } from 'ag-charts-enterprise';
import { forwardRef, useMemo, useRef } from 'react';
import { FleetCompositionItems } from '../types/fleetTypes';
import {
  colorForItem,
  horizontalAxis,
  shareTooltip,
} from '../utils/fleetUtils';
import { useTheme } from '@/app/context/ThemeProvider';
import {
  PoleStarChart,
  PoleStarChartHandle,
} from '@/shared/lib/PoleStarCharts';
import { getChartTheme } from '@/shared/utils/chartUtils';

export interface BarChartProps {
  data: FleetCompositionItems[];
  total: number;
  horizontal?: boolean;
  minHeight?: number;
  isItemSelected?: (item: FleetCompositionItems) => boolean;
  getItemColor?: (item: FleetCompositionItems) => string | undefined;
}

const Bars = forwardRef<PoleStarChartHandle, BarChartProps>(
  (
    { data, total, horizontal, minHeight, isItemSelected, getItemColor },
    ref,
  ) => {
    const { theme: themeMode } = useTheme();
    const prefersDark = window.matchMedia(
      '(prefers-color-scheme: dark)',
    ).matches;
    const isDarkMode =
      themeMode === 'dark' || (themeMode === 'system' && prefersDark);
    const textColor = isDarkMode ? '#E5E7EB' : '#111827';
    const gridLineColor = '#9CA3AF';
    const containerRef = useRef<HTMLDivElement>(null);

    // AG Charts sometimes fails to hide the custom crosshair label on mouse
    // leave, so we force it hidden ourselves, scoped to this chart's own
    // container so we don't touch other charts on the page. AG Charts' own
    // `show()` only ever removes our override via its internal class toggle,
    // never our inline styles directly, so we must also clear the override
    // on mouseenter or the label would stay hidden forever after the first hide.
    const crosshairLabelSelector =
      '.ag-charts-crosshair-label, [class*="crosshair-label"]';

    const hideCrosshairLabels = () => {
      containerRef.current
        ?.querySelectorAll<HTMLElement>(crosshairLabelSelector)
        .forEach((el) => {
          el.style.opacity = '0';
          el.style.visibility = 'hidden';
        });
    };

    const resetCrosshairLabels = () => {
      containerRef.current
        ?.querySelectorAll<HTMLElement>(crosshairLabelSelector)
        .forEach((el) => {
          el.style.opacity = '';
          el.style.visibility = '';
        });
    };

    const options: AgChartOptions = useMemo(
      () => ({
        data,
        theme: getChartTheme(isDarkMode),
        series: [
          {
            type: 'bar',
            xKey: 'label',
            yKey: 'count',
            direction: horizontal ? 'vertical' : 'horizontal',
            cornerRadius: 4,
            itemStyler: ({ datum }: { datum?: FleetCompositionItems }) => {
              if (!datum) return {};
              const index = data.indexOf(datum);
              const selected = isItemSelected ? isItemSelected(datum) : true;
              const overrideColor = getItemColor?.(datum);
              return {
                fill: colorForItem(datum, index, selected, overrideColor),
                stroke: colorForItem(datum, index, selected, overrideColor),
              };
            },
            highlight: {
              unhighlightedItem: { opacity: 0.35 },
            },
            label: {
              enabled: true,
              placement: 'outside-end',
              padding: 6,
              color: '#9CA3AF',
              formatter: ({ datum }: { datum?: FleetCompositionItems }) =>
                datum ? datum.count.toLocaleString() : '',
            },
            tooltip: {
              renderer: shareTooltip(total, data, isItemSelected, getItemColor),
            },
          },
        ],
        axes: horizontal
          ? {
              x: {
                ...horizontalAxis(),
                label: {
                  ...horizontalAxis().label,
                  color: textColor,
                  autoRotate: true,
                  autoRotateAngle: 335,
                  truncate: true,
                },
                crosshair: { enabled: false },
              },
              y: {
                ...horizontalAxis(),
                label: {
                  ...horizontalAxis().label,
                  color: textColor,
                  rotation: 0,
                  autoRotate: true,
                  autoRotateAngle: 335,
                },
                gridLine: { style: [{ stroke: gridLineColor }] },
                crosshair: {
                  enabled: true,
                  snap: true,
                  lineDash: [4, 4],
                  strokeWidth: 1.5,
                  stroke: isDarkMode ? '#9CA3AF' : '#6B7280',
                  label: {
                    enabled: true,
                    renderer: ({ value }: { value: unknown }) => {
                      const text =
                        typeof value === 'number'
                          ? value.toLocaleString()
                          : String(value);
                      return `<div style="
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
    color: #9CA3AF;
    background: ${isDarkMode ? '#FFFFFF' : '#1F2937'};
    border: 1px solid ${isDarkMode ? '#374151' : '#E5E7EB'};
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    pointer-events: none;
  ">${text}</div>`;
                    },
                  },
                },
              },
            }
          : {
              x: {
                label: { color: textColor },
                gridLine: { style: [{ stroke: gridLineColor }] },
                crosshair: {
                  enabled: true,
                  snap: true,
                  lineDash: [4, 4],
                  strokeWidth: 1.5,
                  stroke: isDarkMode ? '#9CA3AF' : '#6B7280',
                  label: {
                    enabled: true,
                    renderer: ({ value }: { value: unknown }) => {
                      const text =
                        typeof value === 'number'
                          ? value.toLocaleString()
                          : String(value);
                      return `<div style="
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
    color: #9CA3AF;
    background: ${isDarkMode ? '#FFFFFF' : '#1F2937'};
    border: 1px solid ${isDarkMode ? '#374151' : '#E5E7EB'};
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    pointer-events: none;
  ">${text}</div>`;
                    },
                  },
                },
              },
              y: {
                maxThicknessRatio: 0.3,
                label: { color: textColor },
                crosshair: { enabled: false },
              },
            },
        background: { fill: isDarkMode ? '#1F2937' : '#fff' },
        animation: { enabled: true, duration: 800 },
        padding: horizontal
          ? { top: 32, bottom: 48, left: 8, right: 28 }
          : { top: 22, bottom: 8, left: 8, right: 48 },
      }),
      [
        data,
        total,
        horizontal,
        isDarkMode,
        textColor,
        gridLineColor,
        isItemSelected,
        getItemColor,
      ],
    ) as AgChartOptions;

    return (
      <div
        ref={containerRef}
        className={minHeight ? 'w-full' : 'h-full w-full'}
        style={minHeight ? { height: minHeight } : undefined}
        onMouseEnter={resetCrosshairLabels}
        onMouseLeave={hideCrosshairLabels}
      >
        <PoleStarChart options={options} ref={ref} />
      </div>
    );
  },
);
Bars.displayName = 'Bars';

export default Bars;
