interface FleetVesselMarkerIconProps {
  size: number;
  rotationDeg: number;
  color: string;
  isHovered?: boolean;
}

export default function FleetVesselMarkerIcon({
  size,
  rotationDeg,
  color,
  isHovered = false,
}: FleetVesselMarkerIconProps) {
  return (
    <div
      className="flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 22 22"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{
          transform: `rotate(${rotationDeg}deg)`,
          transformOrigin: 'center',
          filter: isHovered
            ? 'drop-shadow(0 0 3px rgba(0,0,0,0.5))'
            : 'drop-shadow(0 1px 1px rgba(0,0,0,0.3))',
        }}
      >
        <path
          d="M15.1823 13.8349C15.5651 13.8565 15.9235 13.6439 16.0909 13.2992C16.2583 12.9544 16.2035 12.5419 15.9494 12.2551L8.46162 3.76428C8.15982 3.42166 7.6595 3.34323 7.26552 3.57129C6.87154 3.79934 6.69628 4.27598 6.84555 4.70618L8.56256 9.65487L3.60792 11.3739C3.17721 11.5234 2.91379 11.955 2.97567 12.4061C3.03755 12.8571 3.41191 13.1998 3.86824 13.2242L15.1823 13.8349Z"
          fill={color}
        />
        <path
          d="M16.5406 13.5178C16.2859 14.042 15.7406 14.3666 15.1551 14.334L3.84067 13.7236C3.14723 13.6862 2.57486 13.1639 2.48016 12.4736C2.38624 11.7876 2.78749 11.1296 3.44411 10.9017L7.92597 9.34669L6.37275 4.87005C6.14573 4.21552 6.41193 3.48785 7.0146 3.13874C7.61238 2.79272 8.37567 2.91041 8.8369 3.434L16.3246 11.9241C16.7134 12.3635 16.7952 12.9934 16.5406 13.5178Z"
          stroke="white"
        />
      </svg>
    </div>
  );
}
