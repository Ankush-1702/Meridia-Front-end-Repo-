import { FaVectorSquare } from 'react-icons/fa';
import { VesselData } from '../types/fleetTypes';
import { formatCoordinate } from '../utils/fleetUtils';
import LocationMiniMap from './LocationMiniMap';
import {
  FlatFleetEventsResponse,
  FleetEventType,
  ZoneInformation,
} from '@/features/Fleets/types/fleetEventTypes';
import { EntityCard } from '@/shared/components/EntityCard';
import { Heading, Row } from '@/shared/components/SlideOutComponents';
import FlagIcon from '@/shared/ui/FlagIcon';

export default function LocationSection({
  eventType,
  location,
  setViewLocation,
  boundaryGeometry,
  event,
  vessel,
}: {
  eventType: FleetEventType;
  location?: ZoneInformation;
  setViewLocation: (v: boolean) => void;
  boundaryGeometry?: string;
  event?: FlatFleetEventsResponse;
  vessel?: VesselData;
}) {
  return (
    <div className={`flex flex-col gap-2`}>
      <Heading>Location</Heading>
      {location && (
        <EntityCard
          icon={
            eventType !== 'ZONE_ENTRY' && eventType !== 'ZONE_EXIT' ? (
              <FlagIcon flagCode={location.country_code} />
            ) : (
              <div
                className={`rounded-lg border border-gray-300 px-3 py-3 dark:border-gray-700`}
              >
                <FaVectorSquare className={`text-gray-500`} />
              </div>
            )
          }
          name={location.name}
          sub={(location.type === 'Ports'
            ? ['Port', location.unlocode, location.country_common_name]
            : ['Zone', location.sub_type, location.country_common_name]
          )
            .filter(Boolean)
            .join(' · ')}
          onClick={() => {
            setViewLocation(true);
          }}
        />
      )}
      {eventType !== 'PORT_STATE_CONTROL' && (
        <div className={`h-56 w-full`}>
          <LocationMiniMap
            vessel={vessel}
            label={location?.name}
            boundaryGeometry={boundaryGeometry}
            event={event}
            center={location?.centroid}
          />
        </div>
      )}

      {eventType === 'POSITIONAL_DISCREPANCY' && (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Start Position"
            value={
              event?.startedLatitude && event?.startedLongitude
                ? `${formatCoordinate(event.startedLatitude, 'N', 'S')}, ${formatCoordinate(
                    event.startedLongitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }
          />
          <Row
            label="End Position"
            value={
              event?.stoppedLatitude && event?.stoppedLongitude
                ? `${formatCoordinate(event.stoppedLatitude, 'N', 'S')}, ${formatCoordinate(
                    event.stoppedLongitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }
          />
        </div>
      )}

      {eventType === 'AIS_GAP' ? (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Start Position"
            value={
              event?.gapStartedLatitude && event?.gapStartedLongitude
                ? `${formatCoordinate(event.gapStartedLatitude, 'N', 'S')}, ${formatCoordinate(
                    event.gapStartedLongitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }
          />
          <Row
            label="End Position"
            value={
              event?.gapEndedLatitude && event?.gapEndedLongitude
                ? `${formatCoordinate(event.gapEndedLatitude, 'N', 'S')}, ${formatCoordinate(
                    event.gapEndedLongitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }
          />
        </div>
      ) : eventType === 'STS_PAIRING' ? (
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          <Row
            label="Coordinates"
            value={
              event?.stsLatitude && event?.stsLongitude
                ? `${formatCoordinate(event.stsLatitude, 'N', 'S')}, ${formatCoordinate(
                    event.stsLongitude,
                    'E',
                    'W',
                  )}`
                : '-'
            }
          />
        </div>
      ) : null}
    </div>
  );
}
