import {
  Coverage,
  CoverageNote,
} from '@/features/Fleets/components/ShowCoverage';
import ChartsDownloadDropDown from '@/shared/components/ChartsDownloadDropDown';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import LoadingTemplate from '@/shared/components/LoadingTemplate';
import { cn } from '@/shared/utils/classMerge';

export interface ChartsCardProps {
  isLoading?: boolean;
  title: string;
  hasData?: boolean;
  chart?: React.ReactNode;
  onExportImage?: () => void;
  onExportCSV?: () => void;
  className?: string;
  tabGroup?: React.ReactNode;
  subHeading?: string;
  subHeadingAction?: React.ReactNode;
  showCoverage?: boolean;
  coverage?: Coverage;
  scrollChart?: boolean;
  section?: string;
}

export default function ChartsCard({
  isLoading,
  hasData,
  title,
  chart,
  onExportImage,
  onExportCSV,
  className,
  tabGroup,
  subHeading,
  subHeadingAction,
  showCoverage = false,
  coverage,
  scrollChart = false,
  section,
}: ChartsCardProps) {
  return (
    <div
      className={cn(
        'flex h-[410px] flex-col rounded-lg bg-white p-6 dark:bg-gray-800',
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
            {title}
          </h2>
          <p className="text-xs text-gray-500">
            {subHeading}
            {subHeadingAction && (
              <>
                {' · '}
                {subHeadingAction}
              </>
            )}
            {showCoverage &&
              coverage &&
              coverage?.known !== 0 &&
              coverage?.complete !== true && (
                <>
                  {' · '}
                  <CoverageNote coverage={coverage} />
                </>
              )}
            {showCoverage && coverage && coverage?.known === 0 && (
              <>
                {' · '}
                <span
                  className={`inline-flex items-center gap-1 text-xs text-gray-500`}
                >
                  No {section} data available
                </span>
              </>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {tabGroup}
          <ChartsDownloadDropDown
            loading={isLoading}
            hasData={hasData}
            onExportImage={onExportImage}
            onExportCSV={onExportCSV}
          />
        </div>
      </div>
      <div
        className={cn(
          'relative isolate mt-4 h-full',
          scrollChart && 'overflow-y-auto',
        )}
      >
        {isLoading ? (
          <LoadingTemplate />
        ) : hasData ? (
          chart
        ) : (
          <CongestionEmptyState isFleetComposition={true} />
        )}
      </div>
    </div>
  );
}
