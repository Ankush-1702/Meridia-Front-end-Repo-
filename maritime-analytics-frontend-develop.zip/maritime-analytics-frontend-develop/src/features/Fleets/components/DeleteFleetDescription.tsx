import { Fleet } from '@/features/Fleets/types/fleetTypes';
import { toTitleCase } from '@/shared/utils/formatUtils';

const MESSAGES = [
  'The fleet definition and its vessel list are removed.',
  'Notification settings and alerts for this fleet stop immediately.',
  'Analytics and event history for this fleet are no longer accessible.',
  'The vessels themselves aren’t affected — they stay in Meridia and in any other fleets.',
];

export default function DeleteFleetDescription({ fleet }: { fleet: Fleet }) {
  return (
    <div className={`flex flex-col space-y-2 text-sm`}>
      <p className={`font-medium text-gray-900 dark:text-white`}>
        You are about to delete "<b>{fleet.name}</b>".
      </p>
      <p className={`text-xs`}>
        {toTitleCase(fleet.type)} · {fleet.vessel_count}{' '}
        {fleet.vessel_count === 1 ? 'vessel' : 'vessels'}
      </p>
      <ul className={`list-outside list-disc space-y-1 pl-4`}>
        {MESSAGES.map((message) => (
          <li key={message}>{message}</li>
        ))}
      </ul>
      <p className="text-sm font-semibold text-gray-900 dark:text-white">
        This can't be undone.
      </p>
    </div>
  );
}
