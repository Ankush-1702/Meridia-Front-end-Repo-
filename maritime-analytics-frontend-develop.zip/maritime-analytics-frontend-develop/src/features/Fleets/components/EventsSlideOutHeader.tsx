// import { isMara2Enabled } from '@/app/config/config';
import { HiX } from 'react-icons/hi';
import { LuArrowLeft } from 'react-icons/lu';
// import { MdAutoAwesome } from 'react-icons/md';
// import { useNavigate } from 'react-router';
// import { isMara2Enabled } from '@/app/config/config';
// import {
//   ASK_IQ_PATH,
//   askIqPrompts,
//   buildAskIqNavigationState,
// } from '@/features/mara2/utils/askIq';

interface EventsSlideOutHeaderProps {
  vesselName?: string;
  vesselFlagCode?: string;
  vesselImo?: string;
  onClose?: () => void;
  showBackButton?: boolean;
  onBack?: () => void;
  eventType: string;
}
export default function EventsSlideOutHeader({
  //   vesselName,
  //   vesselImo,
  onClose,
  showBackButton = false,
  onBack,
  eventType,
}: EventsSlideOutHeaderProps) {
  //   const navigate = useNavigate();

  //   const handleAskIQ = () => {
  //     if (!vesselImo || !vesselName) return;

  //     navigate(
  //       ASK_IQ_PATH,
  //       buildAskIqNavigationState(askIqPrompts.vessel(vesselName, vesselImo)),
  //     );
  //   };

  return (
    <div className="flex w-full min-w-0 items-center justify-between gap-3">
      <div className={`flex w-full items-center gap-2`}>
        {showBackButton && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Close panel"
            className="shrink-0 rounded p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <LuArrowLeft className={`text-gray-400`} size={20} />
          </button>
        )}
        <div className="flex w-48 items-center justify-start gap-3 rounded-lg px-4 py-2 text-left">
          <span className="flex min-w-0 flex-col items-start">
            <span className="max-w-full truncate text-base font-bold">
              Event Details
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {eventType}
            </span>
          </span>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-4">
        {/* {isMara2Enabled() && (
          <button
            type="button"
            onClick={handleAskIQ}
            className="flex shrink-0 items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
          >
            <MdAutoAwesome className="shrink-0 text-gray-400" />
            <span>Ask IQ</span>
          </button>
        )} */}

        <button
          type="button"
          onClick={onClose}
          aria-label="Close panel"
          className="shrink-0 rounded p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <HiX size={20} />
        </button>
      </div>
    </div>
  );
}
