import { TextInput } from 'flowbite-react';
import { useState } from 'react';

const MAX_NAME_LENGTH = 100;

interface RenameFleetContentProps {
  fleetName: string;
  name: string;
  setName: (val: string) => void;
  nameError?: string;
}

export default function RenameFleetContent({
  fleetName,
  name,
  setName,
  nameError,
}: RenameFleetContentProps) {
  const [nameTouched, setNameTouched] = useState(false);
  const showNameError = nameTouched && !!nameError;

  return (
    <div className={`flex flex-col space-y-2 text-sm`}>
      Enter a new name for {fleetName}.
      <TextInput
        className={`w-full`}
        maxLength={MAX_NAME_LENGTH}
        value={name}
        color={showNameError ? 'failure' : undefined}
        onChange={(e) => {
          setName(e.target.value);
          if (!nameTouched) setNameTouched(true);
        }}
        onBlur={() => setNameTouched(true)}
      />
      <div className={`flex w-full`}>
        {showNameError && (
          <span className={`text-xs text-red-600`}>{nameError}</span>
        )}
        <span className={`ml-auto text-right text-[10px] text-gray-500`}>
          {name.length}/{MAX_NAME_LENGTH}
        </span>
      </div>
    </div>
  );
}
