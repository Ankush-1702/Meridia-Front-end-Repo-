import { FleetVesselPopupData } from '../types/fleetTypes';
import {
  FOOTER_STYLE,
  POPUP_BASE_STYLE,
  formatCompactDate,
  row,
} from '@/shared/utils/overviewMapUtils';

// const SECTION_TITLE_STYLE =
//   'margin: 0 0 4px; padding: 0; font-size: 10px; font-weight: 600; letter-spacing: 0.05em; text-transform: uppercase; color: #9ca3af;';
const DIVIDER_STYLE =
  'margin: 8px 0; border: none; border-top: 1px solid #374151;';

export function buildFleetVesselPopupHtml(data: FleetVesselPopupData): string {
  const formattedEta = data.reportedEta
    ? formatCompactDate(data.reportedEta)
    : '--';

  const formattedTimestamp = data.timeStr
    ? formatCompactDate(data.timeStr)
    : '--';

  return `
    <div style="${POPUP_BASE_STYLE} min-width: 200px; max-width: 300px;">
      <div style="display: grid; grid-template-columns: auto 1fr; gap: 2px 12px;">
        ${row('Name', data.vesselName || 'VESSEL NAME')}
        ${row('IMO', data.imo || '9999999')}
        ${row('Vessel Type', data.vesselType || '--')}
        ${row('Vessel Class', data.vesselClass || '--')}
        ${row('Flag', data.flag || '--')}
      </div>
      <hr style="${DIVIDER_STYLE}" />
      <div style="display: grid; grid-template-columns: auto 1fr; gap: 2px 12px;">
        ${row('Speed', data.speed !== undefined ? `${data.speed.toFixed(1)} kt` : '--')}
        ${row('Course', data.course !== undefined ? `${data.course.toString().padStart(3, '0')}°` : '--')}
        ${row('Destination', data.reportedDestination || '--')}
        ${row('ETA', formattedEta, true)}
        ${row('Last Reported', formattedTimestamp, true)}
      </div>
      <p style="${FOOTER_STYLE}">Click vessel for more details</p>
    </div>
  `;
}
