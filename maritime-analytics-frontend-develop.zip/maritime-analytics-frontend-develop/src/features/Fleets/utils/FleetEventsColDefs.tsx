import { ColDef, ColGroupDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { FlatFleetEventsResponse } from '../types/fleetEventTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  getFleetEventsLabel,
} from '@/shared/utils/formatUtils';

const DASH = '-';

// Helper formatters
const fmtDash = (value?: string | null) =>
  value === null || value === undefined || value === '' ? DASH : value;
const fmtNum = (
  value: number | null | undefined,
  decimals: number,
  suffix = '',
) => (value != null ? `${value.toFixed(decimals)}${suffix}` : DASH);
const fmtBool = (value?: boolean | null) =>
  value === true ? 'Yes' : value === false ? 'No' : DASH;

export function CreateFleetEventsColDefs(
  timeZoneSetting: string,
): (ColDef<FlatFleetEventsResponse> | ColGroupDef<FlatFleetEventsResponse>)[] {
  const fmtTime = (value?: string) =>
    timeZoneSetting === 'utc'
      ? convertDateAndTimeToHumanReadableFormat(value) || DASH
      : convertUTCToLocalTime(value) || DASH;

  return [
    // ── "Overview" group: the default columns, always visible, exact order ──
    {
      headerName: 'Overview',
      children: [
        {
          headerName: `${timeZoneSetting === 'utc' ? 'TimeStamp (UTC)' : 'TimeStamp (System)'}`,
          field: 'eventTimestamp',
          sortable: true,
          width: 210,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
        {
          headerName: 'Vessel',
          field: 'vesselName',
          sortable: true,
          minWidth: 180,
          tooltipField: 'vesselName',
          cellRenderer: (params: CustomCellRendererProps) =>
            params.data ? (
              <div className="flex items-center gap-2">
                <FlagIcon flagCode={params.data.flagCode} />
                <span className="truncate">{params.value}</span>
              </div>
            ) : null,
        },
        {
          headerName: 'IMO',
          field: 'imo',
          sortable: true,
          width: 120,
          tooltipField: 'imo',
        },
        {
          headerName: 'Event',
          field: 'eventType',
          sortable: true,
          width: 100,
          tooltipValueGetter: (params: ITooltipParams) =>
            getFleetEventsLabel(params.value),
          cellRenderer: (params: CustomCellRendererProps) => (
            <StatusBadge status={params.value} entity="fleets" />
          ),
        },
        {
          headerName: 'Location',
          field: 'location',
          sortable: true,
          width: 190,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtDash(params.value),
        },
        {
          headerName: 'Country',
          field: 'country',
          sortable: true,
          width: 180,
          cellRenderer: (params: CustomCellRendererProps) =>
            !params.value || params.value === DASH ? (
              <span>{DASH}</span>
            ) : (
              <div className="flex items-center gap-2">
                <FlagIcon flagCode={params.data?.countryFlag} />
                <span className="truncate">{params.value}</span>
              </div>
            ),
          tooltipField: 'country',
        },
        {
          headerName: 'UN/LOCODE',
          field: 'unlocode',
          sortable: true,
          width: 130,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value) ?? '-'}</span>
          ),
          tooltipField: 'unlocode',
        },
        {
          headerName: 'Location Type',
          field: 'zoneType',
          sortable: true,
          width: 140,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value) ?? '-'}</span>
          ),
          tooltipField: 'zoneType',
        },
        {
          headerName: 'Speed',
          field: 'speed',
          sortable: true,
          width: 110,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 1, ' kn')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 1, ' kn'),
        },
        {
          headerName: 'Course',
          field: 'course',
          sortable: true,
          width: 110,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 0, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 0, '°'),
        },
        {
          headerName: 'Duration (hours)',
          field: 'duration',
          sortable: true,
          width: 140,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'duration',
        },
      ],
    },

    // ── Context groups (hidden by default) ──
    {
      headerName: 'Vessel identity',
      children: [
        {
          headerName: 'MMSI',
          field: 'mmsi',
          sortable: true,
          width: 130,
          hide: true,
          tooltipField: 'mmsi',
        },
        {
          headerName: 'Call Sign',
          field: 'callSign',
          sortable: true,
          width: 120,
          hide: true,
          tooltipField: 'callSign',
        },
        {
          headerName: 'Flag',
          field: 'flag',
          sortable: true,
          width: 160,
          hide: true,
          tooltipField: 'flag',
          cellRenderer: (params: CustomCellRendererProps) =>
            params.data ? (
              <div className="flex items-center gap-2">
                <FlagIcon flagCode={params.data.flagCode} />
                <span className="truncate">{params.value}</span>
              </div>
            ) : null,
        },
        {
          headerName: 'Type',
          field: 'vesselType',
          sortable: true,
          minWidth: 140,
          hide: true,
          tooltipField: 'vesselType',
        },
      ],
    },

    {
      headerName: 'Position & movement',
      children: [
        {
          headerName: 'Heading',
          field: 'heading',
          sortable: true,
          width: 120,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 0, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 0, '°'),
        },
        {
          headerName: 'Draught',
          field: 'draught',
          sortable: true,
          width: 120,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 1, ' m')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 1, ' m'),
        },
        {
          headerName: 'Navigational Status',
          field: 'navigationalStatusStatus',
          sortable: true,
          width: 200,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'navigationalStatusStatus',
        },
        {
          headerName: 'Reported Destination',
          field: 'reportedDestination',
          sortable: true,
          width: 200,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'reportedDestination',
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Reported ETA (UTC)' : 'Reported ETA (System)'}`,
          field: 'reportedEta',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
      ],
    },

    {
      headerName: 'Port State Control',
      children: [
        {
          headerName: 'Authority',
          field: 'authority',
          sortable: true,
          width: 160,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'authority',
        },
        {
          headerName: 'Inspection Type',
          field: 'inspectionType',
          sortable: true,
          width: 160,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'inspectionType',
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Inspection Date (UTC)' : 'Inspection Date (System)'}`,
          field: 'inspectionDate',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
        {
          headerName: 'Detained',
          field: 'detained',
          sortable: true,
          width: 120,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtBool(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtBool(params.value),
        },
        {
          headerName: 'Days Detained',
          field: 'daysDetained',
          sortable: true,
          width: 140,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'daysDetained',
        },
        {
          headerName: 'No. Defects',
          field: 'numberOfDefects',
          sortable: true,
          width: 130,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'numberOfDefects',
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Release Date (UTC)' : 'Release Date (System)'}`,
          field: 'releaseDate',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
      ],
    },

    {
      headerName: 'STS pairing',
      children: [
        {
          headerName: 'STS Type',
          field: 'stsType',
          sortable: true,
          width: 130,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'stsType',
        },
        {
          headerName: 'Paired Vessel',
          field: 'pairedVessel',
          sortable: true,
          minWidth: 180,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'pairedVessel',
        },
        {
          headerName: 'Paired IMO',
          field: 'pairedIMO',
          sortable: true,
          width: 130,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtDash(params.value)}</span>
          ),
          tooltipField: 'pairedIMO',
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'STS Ended (UTC)' : 'STS Ended (System)'}`,
          field: 'stsEnded',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
      ],
    },

    {
      headerName: 'AIS gap',
      children: [
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Gap Stopped (UTC)' : 'Gap Stopped (System)'}`,
          field: 'gapStopped',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Gap Resumed (UTC)' : 'Gap Resumed (System)'}`,
          field: 'gapResumed',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
        {
          headerName: 'Draught Change',
          field: 'draughtChange',
          sortable: true,
          width: 150,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{params.value != null ? `${params.value} m` : DASH}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            params.value != null ? `${params.value} m` : DASH,
        },
      ],
    },

    {
      headerName: 'Positional discrepancy',
      children: [
        {
          headerName: 'Has Ended',
          field: 'hasEnded',
          sortable: true,
          width: 120,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtBool(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtBool(params.value),
        },
        {
          headerName: 'Started Latitude',
          field: 'startedLatitude',
          sortable: true,
          width: 150,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 4, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 4, '°'),
        },
        {
          headerName: 'Started Longitude',
          field: 'startedLongitude',
          sortable: true,
          width: 160,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 4, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 4, '°'),
        },
        {
          headerName: `${timeZoneSetting === 'utc' ? 'Stopped Timestamp (UTC)' : 'Stopped Timestamp (System)'}`,
          field: 'stoppedTimestamp',
          sortable: true,
          width: 210,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtTime(params.value)}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) => fmtTime(params.value),
        },
        {
          headerName: 'Stopped Latitude',
          field: 'stoppedLatitude',
          sortable: true,
          width: 150,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 4, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 4, '°'),
        },
        {
          headerName: 'Stopped Longitude',
          field: 'stoppedLongitude',
          sortable: true,
          width: 160,
          hide: true,
          cellRenderer: (params: CustomCellRendererProps) => (
            <span>{fmtNum(params.value, 4, '°')}</span>
          ),
          tooltipValueGetter: (params: ITooltipParams) =>
            fmtNum(params.value, 4, '°'),
        },
      ],
    },
  ];
}
