export const FLEET_VESSEL_CAP = 1000;

export interface FleetFormValidation {
  isValid: boolean;
  nameError?: string;
  warningMessage: string;
}

export function validateFleetForm(
  name: string,
  vesselCount: number,
  isDuplicateName = false,
): FleetFormValidation {
  const missingName = name.trim().length === 0;
  const shortName = name.trim().length < 3;
  const noVessels = vesselCount === 0;
  const overCap = vesselCount > FLEET_VESSEL_CAP;
  const duplicateName = !missingName && !shortName && isDuplicateName;

  let warningMessage = '';
  if (missingName && noVessels) {
    warningMessage = 'Add a name and at least one vessel';
  } else if (missingName) {
    warningMessage = 'Add a name';
  } else if (duplicateName) {
    warningMessage = 'A fleet with this name already exists';
  } else if (noVessels) {
    warningMessage = 'Add at least one vessel';
  } else if (overCap) {
    warningMessage = `Remove ${vesselCount - FLEET_VESSEL_CAP} vessel${vesselCount - FLEET_VESSEL_CAP === 1 ? '' : 's'} to save — limit is ${FLEET_VESSEL_CAP}`;
  }

  return {
    isValid: !missingName && !noVessels && !overCap && !duplicateName,
    nameError: missingName
      ? 'Name is required'
      : shortName
        ? 'Name must be at least 3 characters'
        : duplicateName
          ? 'A fleet with this name already exists'
          : undefined,
    warningMessage,
  };
}
