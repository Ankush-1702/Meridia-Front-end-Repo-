import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { VesselData } from '../types/fleetTypes';
import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';
import FlagIcon from '@/shared/ui/FlagIcon';
import { relativeTime } from '@/shared/utils/formatUtils';

export function CreateFleetVesselsColDefs(): ColDef<VesselData>[] {
  const showMtiScore = hasGroupPermission('meridia-mti-tier1');
  return [
    {
      headerName: 'Vessel',
      field: 'vessel_information.name',
      sortable: true,
      tooltipField: 'vessel_information.name',
      lockVisible: true,
      initialWidth: 200,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.vessel_information.flag_code} />
          <span className="truncate">{params.value}</span>
        </div>
      ),
    },
    {
      headerName: 'IMO',
      field: 'vessel_information.imo',
      sortable: true,
      tooltipField: 'vessel_information.imo',
      lockVisible: true,
      initialWidth: 120,
    },
    {
      headerName: 'MMSI',
      field: 'vessel_information.mmsi',
      sortable: true,
      initialWidth: 120,
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? params.value
          : '-',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Type',
      field: 'vessel_information.vessel_type',
      sortable: true,
      tooltipField: 'vessel_information.vessel_type',
      lockVisible: true,
    },
    {
      headerName: 'Class',
      field: 'vessel_information.vessel_class',
      sortable: true,
      tooltipField: 'vessel_information.vessel_class',
      lockVisible: true,
    },
    {
      headerName: 'Flag',
      field: 'vessel_information.flag',
      sortable: true,
      tooltipField: 'vessel_information.flag',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.vessel_information.flag_code} />
          <span className="truncate">{params.value}</span>
        </div>
      ),
    },
    {
      headerName: 'Nav Status',
      field: 'vessel_position.navigational_status.status',
      sortable: true,
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? params.value
          : '-',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    ...(showMtiScore
      ? [
          {
            headerName: 'MTI Score',
            field: 'mti_score',
            sortable: true,
            tooltipValueGetter: (params: ITooltipParams) =>
              params.value !== null && params.value !== undefined
                ? params.value
                : '-',
            lockVisible: true,
            cellRenderer: (params: CustomCellRendererProps) => (
              <span>
                {params.value !== null && params.value !== undefined
                  ? params.value
                  : '-'}
              </span>
            ),
          } satisfies ColDef<VesselData>,
        ]
      : []),
    {
      headerName: 'Next Port',
      field: 'vessel_position.reported_destination',
      sortable: true,
      lockVisible: true,
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? params.value
          : '-',
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Last Reported',
      field: 'vessel_position.timestamp',
      sortable: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? relativeTime(params.value)
            : '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? relativeTime(params.value)
          : '-',
      lockVisible: true,
      initialWidth: 120,
    },
    {
      headerName: 'Speed',
      field: 'vessel_position.speed',
      sortable: true,
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? `${params.value.toFixed(2)} kn`
          : '-',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? `${params.value.toFixed(2)} kn`
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Course',
      field: 'vessel_position.course',
      sortable: true,
      tooltipValueGetter: (params: ITooltipParams) =>
        params.value !== null && params.value !== undefined
          ? `${params.value.toFixed(2)} °`
          : '-',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? `${params.value.toFixed(2)} °`
            : '-'}
        </span>
      ),
    },
  ];
}
