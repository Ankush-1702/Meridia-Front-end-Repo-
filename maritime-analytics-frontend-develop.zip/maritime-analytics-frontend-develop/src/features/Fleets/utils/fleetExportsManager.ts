import { IFleetExportBody } from '../types/fleetTypes';
import { triggerFleetCsvExport } from '@/features/Fleets/services/exportService';
import { pollEventsExportStatus } from '@/shared/services/exportServices/eventsExportServices';

const POLL_INTERVAL_MS = 3000;

type StatusCallback = (
  status: 'COMPLETED' | 'FAILED' | 'PROCESSING' | 'EXPIRED',
) => void;
type DownloadCallback = (url: string, fileName: string) => void;
type ErrorCallback = (error: unknown) => void;

interface ExportManagerCallbacks {
  onStatus?: StatusCallback;
  onDownloadReady?: DownloadCallback;
  onError?: ErrorCallback;
}

let intervalId: ReturnType<typeof setInterval> | null = null;
let callbacks: ExportManagerCallbacks = {};

function isPolling() {
  return intervalId !== null;
}

function stopPolling() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
}

function startPolling(jobId: string) {
  stopPolling(); // Guard: never run two intervals at once

  intervalId = setInterval(async () => {
    try {
      const res = await pollEventsExportStatus(jobId);
      const status = res.data.status;

      callbacks.onStatus?.(status);

      if (status === 'COMPLETED') {
        stopPolling();
        if (res.data.download_url) {
          callbacks.onDownloadReady?.(res.data.download_url, 'fleets-export');
        }
      } else if (status === 'FAILED') {
        stopPolling();
        callbacks.onError?.(new Error('Export job failed'));
      }
    } catch (e) {
      stopPolling();
      callbacks.onError?.(e);
    }
  }, POLL_INTERVAL_MS);
}

export const fleetExportManager = {
  isPolling,

  /** Re-attach callbacks on every mount so toasts/errors always reach the live UI */
  registerCallbacks(cbs: ExportManagerCallbacks) {
    callbacks = cbs;
  },

  async trigger(
    fleetId: string,
    body: IFleetExportBody,
    cbs: ExportManagerCallbacks,
  ) {
    if (isPolling()) return;

    callbacks = cbs;

    const res = await triggerFleetCsvExport(fleetId, body);

    startPolling(res.data.export_id);
  },

  cancel() {
    stopPolling();
  },
};
