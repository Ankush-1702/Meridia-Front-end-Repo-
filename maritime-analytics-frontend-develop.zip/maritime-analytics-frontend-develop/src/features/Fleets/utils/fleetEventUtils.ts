import {
  FleetEvents,
  FlatFleetEventsResponse,
} from '@/features/Fleets/types/fleetEventTypes';

export function flattenFleetEvent(event: FleetEvents): FlatFleetEventsResponse {
  const { event_details: details, vessel_information: vessel } = event;
  const vesselFields = {
    callSign: vessel.callsign,
    flag: vessel.flag,
    flagCode: vessel.flag_code,
    imo: vessel.imo,
    mmsi: vessel.mmsi,
    vesselName: vessel.name,
    vesselType: vessel.vessel_type,
  };

  if ('gap_started' in details) {
    const gapEnded = details.gap_ended;

    return {
      ...vesselFields,
      eventTimestamp: details.event_timestamp,
      eventType: details.event_type,
      duration: details.gap_duration_hours,
      draughtChange: details.draught_change,
      speed: details.gap_started.speed,
      course: details.gap_started.course,
      navigationalStatusStatus: gapEnded.navigational_status?.status,
      navigationalStatusCode: gapEnded.navigational_status?.code,
      gapStopped: details.gap_started.gap_started_timestamp,
      gapResumed: gapEnded.gap_ended_timestamp,
      gapStartedLatitude: details.gap_started.latitude,
      gapStartedLongitude: details.gap_started.longitude,
      gapEndedLatitude: gapEnded.latitude,
      gapEndedLongitude: gapEnded.longitude,
    };
  }

  if ('sts_location' in details) {
    return {
      ...vesselFields,
      eventTimestamp: details.event_timestamp,
      eventType: details.event_type,
      duration: details.duration_hours,
      stsType: details.sts_type,
      pairedVessel: details.paired_vessel.vessel_information.name,
      pairedIMO: details.paired_vessel.vessel_information.imo,
      pairedVesselData: details.paired_vessel,
      stsEnded: details.sts_end_timestamp,
      stsLatitude: details.sts_location.latitude,
      stsLongitude: details.sts_location.longitude,
    };
  }

  if ('start' in details) {
    return {
      ...vesselFields,
      eventTimestamp: details.event_timestamp,
      eventType: details.event_type,
      duration: details.duration_hours,
      hasEnded: details.has_ended,
      draught: details.start.draught ?? undefined,
      startedLatitude: details.start.latitude,
      startedLongitude: details.start.longitude,
      stoppedTimestamp: details.end.end_timestamp,
      stoppedLatitude: details.end.latitude,
      stoppedLongitude: details.end.longitude,
    };
  }

  if ('authority' in details) {
    return {
      ...vesselFields,
      eventTimestamp: details.event_timestamp,
      eventType: details.event_type,
      authority: details.authority,
      inspectionType: details.inspection_type,
      inspectionDate: details.inspection_timestamp,
      detained: details.detained,
      daysDetained: details.no_days_detained,
      numberOfDefects: details.no_defects,
      location: details.port_information.name,
      country: details.port_information.country,
      releaseDate: details.release_timestamp,
      countryFlag: details.port_information.country_code,
    };
  }

  return {
    ...vesselFields,
    eventTimestamp: details.event_timestamp,
    eventType: details.event_type,
    location: event.zone_information?.name,
    country: event.zone_information?.country_common_name,
    countryOfficialName: event.zone_information?.country_official_name,
    countryFlag: event.zone_information?.country_code,
    unlocode: event.zone_information?.unlocode,
    zoneType: event.zone_information?.type,
    zoneSubType: event.zone_information?.sub_type,
    zoneId: event.zone_information?.id,
    speed: details.speed,
    course: details.course,
    heading: details.heading,
    draught: details.draught,
    zoneName: event.zone_information?.name,
    navigationalStatusStatus: details.navigational_status.status,
    navigationalStatusCode: details.navigational_status.code,
    reportedDestination: details.reported_destination,
    reportedEta: details.reported_eta,
    eventLatitude: details.zone_port_event_location.latitude,
    eventLongitude: details.zone_port_event_location.longitude,
    centrePointLat: event.zone_information?.centroid.latitude,
    centrePointLng: event.zone_information?.centroid.longitude,
    zonePortEventLocationLat: details.zone_port_event_location.latitude,
    zonePortEventLocationLng: details.zone_port_event_location.longitude,
  };
}
