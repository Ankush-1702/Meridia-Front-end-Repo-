import { AgTooltipRendererResult } from 'ag-charts-enterprise';
import {
  BulkImoVerificationResponseDataFound,
  FleetCompositionItems,
  VesselData,
} from '../types/fleetTypes';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import { toCSVRow } from '@/shared/utils/formatUtils';

interface TooltipRendererResultWithSymbol extends AgTooltipRendererResult {
  symbol?: { marker: { fill?: string; stroke?: string } };
}

export const toVesselSearch = (vessel: VesselData): VesselSearch => {
  const { vessel_information: info } = vessel;

  return {
    asset_id: info.asset_id,
    callsign: info.callsign,
    flag: info.flag,
    flag_code: info.flag_code,
    imo: info.imo,
    mmsi: info.mmsi ?? null,
    name: info.name,
    vessel_type: info.vessel_type ?? '',
    vessel_status: info.vessel_status,
  };
};

export const toVesselSearchFromBulkFound = (
  vessel: BulkImoVerificationResponseDataFound,
): VesselSearch => ({
  asset_id: vessel.asset_id,
  callsign: vessel.call_sign ?? '',
  flag: vessel.flag,
  flag_code: vessel?.flag_code,
  imo: vessel.imo,
  mmsi: vessel.mmsi != null ? String(vessel.mmsi) : null,
  name: vessel.vessel_name,
  vessel_type: vessel.vessel_type,
  vessel_status: vessel.vessel_status ?? '',
});

export function formatCoordinate(
  value: number,
  positiveLabel: string,
  negativeLabel: string,
) {
  return `${Math.abs(value).toFixed(3)}°${value >= 0 ? positiveLabel : negativeLabel}`;
}

export function shareTooltip(
  total: number,
  data: FleetCompositionItems[],
  isItemSelected?: (item: FleetCompositionItems) => boolean,
  getOverrideColor?: (item: FleetCompositionItems) => string | undefined,
) {
  return (params: {
    datum?: FleetCompositionItems;
  }): TooltipRendererResultWithSymbol => {
    const d = params.datum;
    const n = d?.count ?? 0;
    const selected = d && isItemSelected ? isItemSelected(d) : true;
    const overrideColor = d ? getOverrideColor?.(d) : undefined;
    const color = d
      ? colorForItem(d, data.indexOf(d), selected, overrideColor)
      : undefined;
    return {
      title: d?.label ?? '',
      data: [
        { label: 'Vessels', value: n.toLocaleString() },
        {
          label: 'Share',
          value: `${d?.percentage}% of ${total.toLocaleString()}`,
        },
      ],
      ...(color && { symbol: { marker: { fill: color, stroke: color } } }),
    };
  };
}

export const horizontalAxis = (maxThicknessRatio = 0.3) => ({
  maxThicknessRatio,
  label: {
    formatter: ({ value }: { value: unknown }) => String(value),
  },
});

export const PROD_TYPE_COLORS: Record<string, string> = {
  'Bulk Carrier': '#F79A6E',
  'Chemical Tanker': '#22A7E0',
  Container: '#17B8A8', // teal
  'Container (FC)': '#17B8A8',
  'General Cargo': '#27BE6A',
  'Oil Tanker': '#6D5BE8',
  Tanker: '#6D5BE8',
  'LPG Carrier': '#EE3D57',
  'Liquified Gas Carrier (LNG)': '#EE3D57',
  'Specialised Carrier': '#93C83E',
  'Fish Processing': '#3B6FE0',
  'Tow Boat': '#E040E0',
};

export const colours = [
  '#F79A6E',
  '#17B8A8',
  '#6D5BE8',
  '#27BE6A',
  '#22A7E0',
  '#EE3D57',
  '#93C83E',
  '#3B6FE0',
  '#1f77b4',
  '#ff7f0e',
  '#2ca02c',
  '#d62728',
  '#9467bd',
  '#8c564b',
  '#e377c2',
  '#7f7f7f',
  '#bcbd22',
  '#17becf',
  '#f59e0b',
  '#10b981',
  '#f43f5e',
  '#6366f1',
  '#a855f7',
  '#84cc16',
  '#ec4899',
  '#0d9488',
  '#fde047',
  '#3b82f6',
  '#d946ef',
];

export const colorForIndex = (index: number) => colours[index % colours.length];

/**
 * The `countries` map (@/features/library/utils/countryMapping) stores ISO 3166
 * official long-form names, but the Fleet Composition API's flag labels use
 * common English names. For most countries the two share enough words for
 * `namesMatch` to bridge them, but for these the official name has no common
 * word with the label at all (e.g. "Korea, Republic of" vs "South Korea"), so
 * they need an explicit override.
 */
export const FLAG_NAME_OVERRIDES: Record<string, string> = {
  KOR: 'South Korea',
  PRK: 'North Korea',
  RUS: 'Russia',
  VNM: 'Vietnam',
  IRN: 'Iran',
  COD: 'Democratic Republic of the Congo',
  VEN: 'Venezuela',
  BOL: 'Bolivia',
  TZA: 'Tanzania',
  SYR: 'Syria',
  LAO: 'Laos',
  BRN: 'Brunei',
  CIV: 'Ivory Coast',
  MDA: 'Moldova',
  FSM: 'Micronesia',
  USA: 'United States Of America',
};

const normalizeToWords = (s: string): string[] =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);

/**
 * Matches a short/partial label (e.g. "South Korea") against a full name (e.g.
 * "Korea, South") regardless of word order or punctuation, since flag labels
 * from the composition API don't reliably match the `countries` map's full names.
 */
export const namesMatch = (label: string, fullName: string): boolean => {
  const labelWords = normalizeToWords(label);
  const fullNameWords = normalizeToWords(fullName);
  return (
    labelWords.length > 0 &&
    labelWords.every((word) => fullNameWords.includes(word))
  );
};

const UNKNOWN_LABEL_COLOR = '#9CA3AF';

export const colorForItem = (
  item: FleetCompositionItems,
  index: number,
  isSelected: boolean = true,
  overrideColor?: string,
) =>
  item.label.trim().toLowerCase() === 'unknown' || !isSelected
    ? UNKNOWN_LABEL_COLOR
    : (overrideColor ?? colorForIndex(index));

export function buildFleetCompositionCsv(
  title: string,
  items: FleetCompositionItems[],
): string | undefined {
  if (!items.length) return undefined;
  const headers = toCSVRow([title, 'Vessels', 'Percentage']);
  const rows = items.map((d) =>
    toCSVRow([d.label, d.count, `${d.percentage}%`]),
  );
  return [headers, ...rows].join('\n');
}
