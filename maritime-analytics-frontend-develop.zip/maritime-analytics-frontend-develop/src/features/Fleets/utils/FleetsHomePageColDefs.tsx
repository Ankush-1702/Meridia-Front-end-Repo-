import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { Fleet } from '@/features/Fleets/types/fleetTypes';
import { formatDateWithoutTime } from '@/shared/utils/formatUtils';

export const FleetHomePageColumns: ColDef<Fleet>[] = [
  {
    headerName: 'Name',
    field: 'name',
    sortable: true,
    tooltipField: 'name',
    lockVisible: true,
  },
  {
    headerName: 'Description',
    field: 'description',
    cellRenderer: (params: CustomCellRendererProps) => params.value || '-',
    sortable: true,
    tooltipValueGetter: (params: ITooltipParams) => params.value || '-',
    lockVisible: true,
  },
  {
    headerName: 'Vessels',
    field: 'vessel_count',
    sortable: true,
    tooltipField: 'name',
    lockVisible: true,
  },
  {
    headerName: 'Last modified',
    field: 'last_modified_at',
    cellRenderer: (params: CustomCellRendererProps) =>
      formatDateWithoutTime(params.value) || '-',
    sortable: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      formatDateWithoutTime(params.value) || '-',
    lockVisible: true,
  },
];
