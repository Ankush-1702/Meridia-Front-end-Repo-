import type { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { VesselData } from '../../types/fleetTypes';
import { CreateFleetVesselsColDefs } from '../FleetVesselsColDefs';
import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  hasGroupPermission: vi.fn(),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode?: string }) => flagCode ?? 'NO_FLAG',
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  relativeTime: vi.fn((v: string) => `relative:${v}`),
}));

const mockedHasGroupPermission = vi.mocked(hasGroupPermission);

function renderCell(
  renderer: (p: CustomCellRendererProps) => JSX.Element,
  value: unknown,
  data?: Partial<VesselData>,
) {
  const el = renderer({ value, data } as CustomCellRendererProps);
  return el.props.children;
}

describe('CreateFleetVesselsColDefs', () => {
  beforeEach(() => {
    mockedHasGroupPermission.mockReset();
  });

  it('excludes the MTI Score column when permission is missing', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    expect(cols.find((c) => c.field === 'mti_score')).toBeUndefined();
  });

  it('includes the MTI Score column when permission is present', () => {
    mockedHasGroupPermission.mockReturnValue(true);
    const cols = CreateFleetVesselsColDefs();
    expect(cols.find((c) => c.field === 'mti_score')).toBeDefined();
  });

  it('renders the vessel name column with flag icon and value', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find((c) => c.field === 'vessel_information.name')!;

    const children = renderCell(
      col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
      'Evergreen',
      {
        vessel_information: {
          flag_code: 'PA',
        } as VesselData['vessel_information'],
      },
    );

    expect(Array.isArray(children)).toBe(true);
    const [flagEl, nameEl] = children;
    expect(flagEl.props.flagCode).toBe('PA');
    expect(nameEl.props.children).toBe('Evergreen');
  });

  it('renders the flag column with flag icon and value', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find((c) => c.field === 'vessel_information.flag')!;

    const children = renderCell(
      col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
      'Panama',
      {
        vessel_information: {
          flag_code: 'PA',
        } as VesselData['vessel_information'],
      },
    );

    const [flagEl, valueEl] = children;
    expect(flagEl.props.flagCode).toBe('PA');
    expect(valueEl.props.children).toBe('Panama');
  });

  it('renders "-" for MTI score when value is null/undefined', () => {
    mockedHasGroupPermission.mockReturnValue(true);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find((c) => c.field === 'mti_score') as ColDef<VesselData>;

    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        null,
      ),
    ).toBe('-');
    expect(col.tooltipValueGetter?.({ value: null } as ITooltipParams)).toBe(
      '-',
    );
  });

  it('renders the MTI score value when present', () => {
    mockedHasGroupPermission.mockReturnValue(true);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find((c) => c.field === 'mti_score') as ColDef<VesselData>;

    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        '85',
      ),
    ).toBe('85');
  });

  it('renders relative time for last-reported timestamp, "-" when missing', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find(
      (c) => c.field === 'vessel_position.timestamp',
    ) as ColDef<VesselData>;

    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        '2024-01-01T00:00:00Z',
      ),
    ).toBe('relative:2024-01-01T00:00:00Z');
    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        null,
      ),
    ).toBe('-');
  });

  it('formats speed with two decimals and "kn" suffix, "-" when missing', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find(
      (c) => c.field === 'vessel_position.speed',
    ) as ColDef<VesselData>;

    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        12.3,
      ),
    ).toBe('12.30 kn');
    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        null,
      ),
    ).toBe('-');
  });

  it('formats course with two decimals and degree suffix, "-" when missing', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    const col = cols.find(
      (c) => c.field === 'vessel_position.course',
    ) as ColDef<VesselData>;

    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        45,
      ),
    ).toBe('45.00 °');
    expect(
      renderCell(
        col.cellRenderer as (p: CustomCellRendererProps) => JSX.Element,
        undefined,
      ),
    ).toBe('-');
  });

  it('returns a stable set of base column fields', () => {
    mockedHasGroupPermission.mockReturnValue(false);
    const cols = CreateFleetVesselsColDefs();
    expect(cols.map((c) => c.field)).toEqual([
      'vessel_information.name',
      'vessel_information.imo',
      'vessel_information.mmsi',
      'vessel_information.vessel_type',
      'vessel_information.vessel_class',
      'vessel_information.flag',
      'vessel_position.navigational_status.status',
      'vessel_position.reported_destination',
      'vessel_position.timestamp',
      'vessel_position.speed',
      'vessel_position.course',
    ]);
  });
});
