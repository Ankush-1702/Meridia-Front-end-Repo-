import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { fleetExportManager } from '../fleetExportsManager';
import { triggerFleetCsvExport } from '@/features/Fleets/services/exportService';
import type { IFleetExportBody } from '@/features/Fleets/types/fleetTypes';
import { pollEventsExportStatus } from '@/shared/services/exportServices/eventsExportServices';
import type { EventsExportResponse } from '@/shared/services/exportServices/exportTypes';

vi.mock('@/features/Fleets/services/exportService', () => ({
  triggerFleetCsvExport: vi.fn(),
}));

vi.mock('@/shared/services/exportServices/eventsExportServices', () => ({
  pollEventsExportStatus: vi.fn(),
}));

const mockTrigger = vi.mocked(triggerFleetCsvExport);
const mockPoll = vi.mocked(pollEventsExportStatus);

const body: IFleetExportBody = {
  filters: {
    flag_code: [],
    mti_score: [],
    vessel_class: [],
    vessel_type: [],
  },
};

function triggerResponse(exportId: string): EventsExportResponse {
  return {
    data: { export_id: exportId, status: 'PROCESSING', download_url: null },
    meta: { request_id: 'r1', request_timestamp: '2026-01-01T00:00:00Z' },
  };
}

function pollResponse(
  status: EventsExportResponse['data']['status'],
  downloadUrl: string | null = null,
): EventsExportResponse {
  return {
    data: { export_id: 'job-1', status, download_url: downloadUrl },
    meta: { request_id: 'r1', request_timestamp: '2026-01-01T00:00:00Z' },
  };
}

describe('fleetExportManager', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
    fleetExportManager.cancel();
    fleetExportManager.registerCallbacks({});
  });

  afterEach(() => {
    fleetExportManager.cancel();
    vi.useRealTimers();
  });

  describe('isPolling', () => {
    it('is false before any trigger', () => {
      expect(fleetExportManager.isPolling()).toBe(false);
    });

    it('becomes true once trigger starts the poll loop', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {});

      expect(fleetExportManager.isPolling()).toBe(true);
    });

    it('becomes false once the job completes', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('COMPLETED', 'https://download'));

      await fleetExportManager.trigger('fleet-1', body, {});
      await vi.advanceTimersByTimeAsync(3000);

      expect(fleetExportManager.isPolling()).toBe(false);
    });
  });

  describe('trigger', () => {
    it('calls triggerFleetCsvExport with the fleetId and body', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {});

      expect(mockTrigger).toHaveBeenCalledWith('fleet-1', body);
    });

    it('does nothing if a poll loop is already running', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {});
      mockTrigger.mockClear();

      await fleetExportManager.trigger('fleet-1', body, {});

      expect(mockTrigger).not.toHaveBeenCalled();
    });

    it('invokes onStatus on each poll tick', async () => {
      const onStatus = vi.fn();
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, { onStatus });
      await vi.advanceTimersByTimeAsync(3000);

      expect(onStatus).toHaveBeenCalledWith('PROCESSING');
    });

    it('keeps polling on subsequent ticks while status stays PROCESSING', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {});
      await vi.advanceTimersByTimeAsync(9000);

      expect(mockPoll).toHaveBeenCalledTimes(3);
      expect(fleetExportManager.isPolling()).toBe(true);
    });

    it('stops polling and calls onDownloadReady when COMPLETED with a download_url', async () => {
      const onStatus = vi.fn();
      const onDownloadReady = vi.fn();
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(
        pollResponse('COMPLETED', 'https://download/file.csv'),
      );

      await fleetExportManager.trigger('fleet-1', body, {
        onStatus,
        onDownloadReady,
      });
      await vi.advanceTimersByTimeAsync(3000);

      expect(onStatus).toHaveBeenCalledWith('COMPLETED');
      expect(onDownloadReady).toHaveBeenCalledWith(
        'https://download/file.csv',
        'fleets-export',
      );
      expect(fleetExportManager.isPolling()).toBe(false);
    });

    it('does not call onDownloadReady when COMPLETED has no download_url', async () => {
      const onDownloadReady = vi.fn();
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('COMPLETED', null));

      await fleetExportManager.trigger('fleet-1', body, { onDownloadReady });
      await vi.advanceTimersByTimeAsync(3000);

      expect(onDownloadReady).not.toHaveBeenCalled();
      expect(fleetExportManager.isPolling()).toBe(false);
    });

    it('stops polling and calls onError when status becomes FAILED', async () => {
      const onError = vi.fn();
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('FAILED'));

      await fleetExportManager.trigger('fleet-1', body, { onError });
      await vi.advanceTimersByTimeAsync(3000);

      expect(onError).toHaveBeenCalledWith(expect.any(Error));
      expect((onError.mock.calls[0][0] as Error).message).toBe(
        'Export job failed',
      );
      expect(fleetExportManager.isPolling()).toBe(false);
    });

    it('stops polling and calls onError when pollEventsExportStatus rejects', async () => {
      const onError = vi.fn();
      const pollError = new Error('network down');
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockRejectedValue(pollError);

      await fleetExportManager.trigger('fleet-1', body, { onError });
      await vi.advanceTimersByTimeAsync(3000);

      expect(onError).toHaveBeenCalledWith(pollError);
      expect(fleetExportManager.isPolling()).toBe(false);
    });

    it('allows a new trigger once the previous poll loop has finished', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('COMPLETED', 'https://download'));

      await fleetExportManager.trigger('fleet-1', body, {});
      await vi.advanceTimersByTimeAsync(3000);
      expect(fleetExportManager.isPolling()).toBe(false);

      mockTrigger.mockClear();
      await fleetExportManager.trigger('fleet-2', body, {});

      expect(mockTrigger).toHaveBeenCalledWith('fleet-2', body);
      expect(fleetExportManager.isPolling()).toBe(true);
    });
  });

  describe('registerCallbacks', () => {
    it('re-attaches callbacks so an in-flight poll notifies the newly registered callback', async () => {
      const staleOnStatus = vi.fn();
      const freshOnStatus = vi.fn();
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {
        onStatus: staleOnStatus,
      });
      await vi.advanceTimersByTimeAsync(3000);
      expect(staleOnStatus).toHaveBeenCalledTimes(1);

      fleetExportManager.registerCallbacks({ onStatus: freshOnStatus });
      await vi.advanceTimersByTimeAsync(3000);

      expect(freshOnStatus).toHaveBeenCalledTimes(1);
      expect(staleOnStatus).toHaveBeenCalledTimes(1);
    });
  });

  describe('cancel', () => {
    it('stops an in-progress poll loop and no further polling occurs', async () => {
      mockTrigger.mockResolvedValue(triggerResponse('job-1'));
      mockPoll.mockResolvedValue(pollResponse('PROCESSING'));

      await fleetExportManager.trigger('fleet-1', body, {});
      expect(fleetExportManager.isPolling()).toBe(true);

      fleetExportManager.cancel();

      expect(fleetExportManager.isPolling()).toBe(false);

      mockPoll.mockClear();
      await vi.advanceTimersByTimeAsync(3000);
      expect(mockPoll).not.toHaveBeenCalled();
    });
  });
});
