import { describe, expect, it } from 'vitest';
import { flattenFleetEvent } from '../fleetEventUtils';
import type { FleetEvents } from '@/features/Fleets/types/fleetEventTypes';

const vessel = {
  asset_id: 'asset-1',
  callsign: 'CALL',
  imo: 'IMO-1',
  mmsi: 'MMSI-1',
  name: 'Test Vessel',
  flag_code: 'NG',
  flag: 'Nigeria',
  vessel_type: 'Cargo',
};

function event(details: object, zone_information?: object): FleetEvents {
  return {
    event_details: details as FleetEvents['event_details'],
    vessel_information: vessel,
    zone_information: zone_information as FleetEvents['zone_information'],
  };
}

describe('flattenFleetEvent', () => {
  it('flattens AIS gap timing, movement, and endpoint details', () => {
    const row = flattenFleetEvent(
      event({
        event_id: 'gap-1',
        event_type: 'AIS_GAP',
        event_timestamp: '2026-01-01T00:00:00Z',
        gap_duration_hours: 4,
        draught_change: 1.2,
        gap_started: {
          speed: 3,
          course: 90,
          latitude: 1,
          longitude: 2,
          gap_started_timestamp: 'start',
        },
        gap_ended: {
          latitude: 4,
          longitude: 5,
          gap_ended_timestamp: 'end',
          navigational_status: { status: 'Under way', code: '0' },
        },
      }),
    );

    expect(row).toMatchObject({
      vesselName: 'Test Vessel',
      eventType: 'AIS_GAP',
      duration: 4,
      speed: 3,
      course: 90,
      gapStopped: 'start',
      gapResumed: 'end',
      gapStartedLatitude: 1,
      gapEndedLongitude: 5,
      navigationalStatusStatus: 'Under way',
    });
  });

  it('flattens STS pairing details and retains the paired vessel payload', () => {
    const paired = {
      vessel_information: { name: 'Paired Vessel', imo: 'IMO-2' },
    };
    const row = flattenFleetEvent(
      event({
        event_id: 'sts-1',
        event_type: 'STS_PAIRING',
        event_timestamp: 'now',
        sts_location: { latitude: 10, longitude: 20 },
        duration_hours: 2,
        paired_vessel: paired,
        sts_end_timestamp: 'later',
        sts_type: 'Ship-to-ship',
      }),
    );

    expect(row).toMatchObject({
      eventType: 'STS_PAIRING',
      pairedVessel: 'Paired Vessel',
      pairedIMO: 'IMO-2',
      pairedVesselData: paired,
      stsLatitude: 10,
      stsLongitude: 20,
      stsEnded: 'later',
    });
  });

  it('flattens positional discrepancy start and end data', () => {
    const row = flattenFleetEvent(
      event({
        event_id: 'position-1',
        event_type: 'POSITIONAL_DISCREPANCY',
        event_timestamp: 'start',
        has_ended: false,
        duration_hours: 3,
        start: { latitude: 11, longitude: 12, draught: null },
        end: {
          latitude: 13,
          longitude: 14,
          draught: null,
          end_timestamp: 'end',
        },
      }),
    );

    expect(row).toMatchObject({
      eventType: 'POSITIONAL_DISCREPANCY',
      hasEnded: false,
      startedLatitude: 11,
      startedLongitude: 12,
      stoppedLatitude: 13,
      stoppedTimestamp: 'end',
      draught: undefined,
    });
  });

  it('flattens port state control details', () => {
    const row = flattenFleetEvent(
      event({
        event_id: 'psc-1',
        event_type: 'PORT_STATE_CONTROL',
        event_timestamp: 'inspection',
        authority: 'Authority',
        inspection_type: 'Initial',
        inspection_timestamp: 'date',
        detained: true,
        no_days_detained: 2,
        no_defects: 4,
        port_information: {
          name: 'Port',
          country: 'Country',
          country_code: 'CCC',
        },
        release_timestamp: 'release',
      }),
    );

    expect(row).toMatchObject({
      eventType: 'PORT_STATE_CONTROL',
      authority: 'Authority',
      inspectionType: 'Initial',
      inspectionDate: 'date',
      detained: true,
      daysDetained: 2,
      numberOfDefects: 4,
      location: 'Port',
      country: 'Country',
      releaseDate: 'release',
      countryFlag: 'CCC',
    });
  });

  it('flattens zone and port events including optional zone metadata', () => {
    const row = flattenFleetEvent(
      event(
        {
          event_id: 'arrival-1',
          event_type: 'PORT_ARRIVAL',
          event_timestamp: 'arrival',
          course: 90,
          navigational_status: { status: 'Moored', code: '5' },
          reported_destination: 'Destination',
          reported_eta: 'eta',
          speed: 0,
          heading: 91,
          draught: 8,
          zone_port_event_location: { latitude: 1, longitude: 2 },
        },
        {
          name: 'Port',
          country_common_name: 'Country',
          country_official_name: 'Official Country',
          country_code: 'TC',
          unlocode: 'TST01',
          type: 'Ports',
          sub_type: 'Harbour',
          id: 'zone-1',
          centroid: { latitude: 3, longitude: 4 },
        },
      ),
    );

    expect(row).toMatchObject({
      eventType: 'PORT_ARRIVAL',
      location: 'Port',
      country: 'Country',
      countryOfficialName: 'Official Country',
      countryFlag: 'TC',
      unlocode: 'TST01',
      zoneId: 'zone-1',
      eventLatitude: 1,
      eventLongitude: 2,
      centrePointLat: 3,
      centrePointLng: 4,
      navigationalStatusStatus: 'Moored',
    });
  });
});
