import { render } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { CreateFleetEventsColDefs } from '../FleetEventsColDefs';

function column(timezone: string, field: string) {
  const groups = CreateFleetEventsColDefs(timezone);
  return groups
    .flatMap((group) => ('children' in group ? group.children : []))
    .find((item) => 'field' in item && item.field === field);
}

function textFromRenderer(field: string, value: unknown) {
  const col = column('utc', field);
  if (
    !col ||
    !('cellRenderer' in col) ||
    typeof col.cellRenderer !== 'function'
  ) {
    throw new Error(`No renderer for ${field}`);
  }
  const rendered = col.cellRenderer({ value } as never);
  const view = render(rendered as React.ReactElement);
  const text = view.container.textContent;
  view.unmount();
  return text;
}

describe('CreateFleetEventsColDefs', () => {
  it('groups overview and contextual fields and labels timestamps by timezone', () => {
    const utc = CreateFleetEventsColDefs('utc');
    expect(
      utc.map((group) => 'headerName' in group && group.headerName),
    ).toEqual([
      'Overview',
      'Vessel identity',
      'Position & movement',
      'Port State Control',
      'STS pairing',
      'AIS gap',
      'Positional discrepancy',
    ]);
    expect(column('utc', 'eventTimestamp')?.headerName).toBe('TimeStamp (UTC)');
    expect(column('system', 'eventTimestamp')?.headerName).toBe(
      'TimeStamp (System)',
    );
    expect(column('utc', 'mmsi')).toMatchObject({ hide: true });
  });

  it('formats missing values, numeric movement values, booleans, and draught change', () => {
    expect(textFromRenderer('location', null)).toBe('-');
    expect(textFromRenderer('speed', 4.26)).toBe('4.3 kn');
    expect(textFromRenderer('course', 91.4)).toBe('91°');
    expect(textFromRenderer('detained', false)).toBe('No');
    expect(textFromRenderer('draughtChange', 2)).toBe('2 m');
  });

  it('returns tooltips using the same display values as the cells', () => {
    const speed = column('utc', 'speed');
    const event = column('utc', 'eventType');
    expect(
      speed && 'tooltipValueGetter' in speed && speed.tooltipValueGetter,
    ).toBeTypeOf('function');
    expect(
      (
        speed as { tooltipValueGetter: (params: unknown) => string }
      ).tooltipValueGetter({
        value: null,
      }),
    ).toBe('-');
    expect(
      (
        event as { tooltipValueGetter: (params: unknown) => string }
      ).tooltipValueGetter({
        value: 'AIS_GAP',
      }),
    ).toBe('AIS Gap');
  });
});
