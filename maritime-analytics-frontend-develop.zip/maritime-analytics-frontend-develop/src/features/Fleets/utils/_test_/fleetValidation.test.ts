import { describe, it, expect } from 'vitest';
import { FLEET_VESSEL_CAP, validateFleetForm } from '../fleetValidation';

describe('FLEET_VESSEL_CAP', () => {
  it('is 1000', () => {
    expect(FLEET_VESSEL_CAP).toBe(1000);
  });
});

describe('validateFleetForm', () => {
  it('is invalid and warns when both name and vessels are missing', () => {
    const result = validateFleetForm('', 0);
    expect(result.isValid).toBe(false);
    expect(result.nameError).toBe('Name is required');
    expect(result.warningMessage).toBe('Add a name and at least one vessel');
  });

  it('is invalid and warns when only the name is missing', () => {
    const result = validateFleetForm('   ', 5);
    expect(result.isValid).toBe(false);
    expect(result.nameError).toBe('Name is required');
    expect(result.warningMessage).toBe('Add a name');
  });

  it('flags a name shorter than 3 characters via nameError without affecting isValid', () => {
    const result = validateFleetForm('ab', 5);
    expect(result.isValid).toBe(true);
    expect(result.nameError).toBe('Name must be at least 3 characters');
    expect(result.warningMessage).toBe('');
  });

  it('is invalid and warns when there are no vessels', () => {
    const result = validateFleetForm('Valid Name', 0);
    expect(result.isValid).toBe(false);
    expect(result.nameError).toBeUndefined();
    expect(result.warningMessage).toBe('Add at least one vessel');
  });

  it('is invalid and flags duplicate names', () => {
    const result = validateFleetForm('Valid Name', 5, true);
    expect(result.isValid).toBe(false);
    expect(result.nameError).toBe('A fleet with this name already exists');
    expect(result.warningMessage).toBe('A fleet with this name already exists');
  });

  it('does not flag a duplicate when the name is missing or too short', () => {
    const missing = validateFleetForm('', 5, true);
    expect(missing.nameError).toBe('Name is required');

    const short = validateFleetForm('ab', 5, true);
    expect(short.nameError).toBe('Name must be at least 3 characters');
  });

  it('is invalid and warns with singular vessel count when exactly one over the cap', () => {
    const result = validateFleetForm('Valid Name', FLEET_VESSEL_CAP + 1);
    expect(result.isValid).toBe(false);
    expect(result.nameError).toBeUndefined();
    expect(result.warningMessage).toBe(
      'Remove 1 vessel to save — limit is 1000',
    );
  });

  it('is invalid and warns with plural vessel count when multiple over the cap', () => {
    const result = validateFleetForm('Valid Name', FLEET_VESSEL_CAP + 5);
    expect(result.warningMessage).toBe(
      'Remove 5 vessels to save — limit is 1000',
    );
  });

  it('is valid at exactly the vessel cap', () => {
    const result = validateFleetForm('Valid Name', FLEET_VESSEL_CAP);
    expect(result.isValid).toBe(true);
    expect(result.nameError).toBeUndefined();
    expect(result.warningMessage).toBe('');
  });

  it('is valid with a well-formed name and at least one vessel', () => {
    const result = validateFleetForm('My Fleet', 3);
    expect(result).toEqual({
      isValid: true,
      nameError: undefined,
      warningMessage: '',
    });
  });

  it('trims whitespace when checking name length', () => {
    const result = validateFleetForm('  ab  ', 3);
    expect(result.nameError).toBe('Name must be at least 3 characters');
  });

  it('defaults isDuplicateName to false when omitted', () => {
    const result = validateFleetForm('My Fleet', 3);
    expect(result.isValid).toBe(true);
  });
});
