import { describe, expect, it } from 'vitest';
import {
  UNKNOWN_VESSEL_TYPE,
  buildVesselClassOptions,
  getClassNamesForVesselType,
  getVesselTypeForClass,
  resolveVesselTypeGroup,
} from '../fleetFilterUtils';
import type { VesselClassGroup } from '@/features/Fleets/types/fleetTypes';

describe('fleetFilterUtils', () => {
  it('resolves a vessel class to its parent type', () => {
    expect(getVesselTypeForClass('VLOC')).toBe('Bulk carrier');
    expect(getVesselTypeForClass('not a class')).toBeUndefined();
  });

  it('builds grouped options using backend classes and display names', () => {
    const groups: VesselClassGroup[] = [
      { vessel_type: 'Tanker', classes: ['Chemical Tanker', 'Oil Tanker'] },
      { vessel_type: 'Bulk carrier', classes: ['VLOC'] },
    ];

    expect(buildVesselClassOptions(groups)).toEqual([
      {
        value: 'Chemical Tanker',
        label: 'Chemical Tanker',
        groupings: 'Tanker',
      },
      { value: 'Oil Tanker', label: 'Oil Tanker', groupings: 'Tanker' },
      { value: 'VLOC', label: 'VLOC', groupings: 'Bulk Carrier' },
    ]);
  });

  it('resolves raw type names case-insensitively and falls back for unknown types', () => {
    expect(resolveVesselTypeGroup('bulk')).toBe('Bulk carrier');
    expect(resolveVesselTypeGroup('unmapped')).toBe(UNKNOWN_VESSEL_TYPE);
  });

  it('filters classes by type and returns unclassified values for Unknown', () => {
    const classes = ['VLOC', 'VLCC', 'Unmapped Class'];
    expect(getClassNamesForVesselType('Bulk carrier', classes)).toEqual([
      'VLOC',
    ]);
    expect(getClassNamesForVesselType(UNKNOWN_VESSEL_TYPE, classes)).toEqual([
      'Unmapped Class',
    ]);
  });
});
