import { describe, it, expect } from 'vitest';
import { FleetVesselPopupData } from '../../types/fleetTypes';
import { buildFleetVesselPopupHtml } from '../fleetMapUtils';

const basePopupData: FleetVesselPopupData = {
  vesselName: 'Evergreen',
  imo: '1234567',
  vesselType: 'Cargo',
  vesselClass: 'Panamax',
  flag: 'Panama',
  speed: 12.34,
  course: 45,
  reportedDestination: 'SGSIN',
  reportedEta: '2024-01-02T00:00:00Z',
  timeStr: '2024-01-01T12:00:00Z',
};

describe('buildFleetVesselPopupHtml', () => {
  it('includes vessel details in the rendered HTML', () => {
    const html = buildFleetVesselPopupHtml(basePopupData);
    expect(html).toContain('Evergreen');
    expect(html).toContain('1234567');
    expect(html).toContain('Cargo');
    expect(html).toContain('Panamax');
    expect(html).toContain('Panama');
    expect(html).toContain('SGSIN');
  });

  it('formats speed with one decimal and a "kt" suffix', () => {
    const html = buildFleetVesselPopupHtml(basePopupData);
    expect(html).toContain('12.3 kt');
  });

  it('formats course as a zero-padded three-digit degree value', () => {
    const html = buildFleetVesselPopupHtml({ ...basePopupData, course: 7 });
    expect(html).toContain('007°');
  });

  it('falls back to "--" for speed and course when undefined', () => {
    const html = buildFleetVesselPopupHtml({
      ...basePopupData,
      speed: undefined,
      course: undefined,
    });
    expect(html).toContain('>--<');
  });

  it('falls back to "--" for ETA and last-reported timestamp when missing', () => {
    const html = buildFleetVesselPopupHtml({
      ...basePopupData,
      reportedEta: '',
      timeStr: '',
    });
    expect(html).toContain('>--<');
  });

  it('falls back placeholders for name, IMO, type, class, flag and destination when empty', () => {
    const html = buildFleetVesselPopupHtml({
      ...basePopupData,
      vesselName: '',
      imo: '',
      vesselType: '',
      vesselClass: '',
      flag: '',
      reportedDestination: '',
    });
    expect(html).toContain('VESSEL NAME');
    expect(html).toContain('9999999');
    expect(html).toContain('>--<');
  });

  it('formats a valid ETA into a compact UTC date string', () => {
    const html = buildFleetVesselPopupHtml(basePopupData);
    expect(html).toContain('02 Jan 2024 00:00 UTC');
  });
});
