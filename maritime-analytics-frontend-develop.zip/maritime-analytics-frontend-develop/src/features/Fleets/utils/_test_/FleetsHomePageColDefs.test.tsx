import type { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi } from 'vitest';
import { FleetHomePageColumns } from '../FleetsHomePageColDefs';
import { Fleet } from '@/features/Fleets/types/fleetTypes';
import { formatDateWithoutTime } from '@/shared/utils/formatUtils';

vi.mock('@/shared/utils/formatUtils', () => ({
  formatDateWithoutTime: vi.fn((v: string) => `formatted:${v}`),
}));

const mockedFormatDateWithoutTime = vi.mocked(formatDateWithoutTime);

describe('FleetHomePageColumns', () => {
  it('defines the expected set of fields', () => {
    expect(FleetHomePageColumns.map((c) => c.field)).toEqual([
      'name',
      'description',
      'vessel_count',
      'last_modified_at',
    ]);
  });

  it('renders the description value when present', () => {
    const col = FleetHomePageColumns.find(
      (c) => c.field === 'description',
    ) as ColDef<Fleet>;
    const rendered = col.cellRenderer!({
      value: 'My description',
    } as CustomCellRendererProps);
    expect(rendered).toBe('My description');
  });

  it('falls back to "-" for an empty description', () => {
    const col = FleetHomePageColumns.find(
      (c) => c.field === 'description',
    ) as ColDef<Fleet>;
    const rendered = col.cellRenderer!({
      value: '',
    } as CustomCellRendererProps);
    expect(rendered).toBe('-');
  });

  it('falls back to "-" for an empty description tooltip', () => {
    const col = FleetHomePageColumns.find(
      (c) => c.field === 'description',
    ) as ColDef<Fleet>;
    expect(col.tooltipValueGetter?.({ value: '' } as ITooltipParams)).toBe('-');
  });

  it('formats last_modified_at using formatDateWithoutTime', () => {
    const col = FleetHomePageColumns.find(
      (c) => c.field === 'last_modified_at',
    ) as ColDef<Fleet>;
    const rendered = col.cellRenderer!({
      value: '2024-01-01T00:00:00Z',
    } as CustomCellRendererProps);
    expect(rendered).toBe('formatted:2024-01-01T00:00:00Z');
  });

  it('falls back to "-" when last_modified_at formatting yields a falsy value', () => {
    mockedFormatDateWithoutTime.mockReturnValueOnce('');
    const col = FleetHomePageColumns.find(
      (c) => c.field === 'last_modified_at',
    ) as ColDef<Fleet>;
    const rendered = col.cellRenderer!({
      value: '',
    } as CustomCellRendererProps);
    expect(rendered).toBe('-');
  });

  it('marks all columns as sortable and lockVisible', () => {
    FleetHomePageColumns.forEach((col) => {
      expect(col.sortable).toBe(true);
      expect(col.lockVisible).toBe(true);
    });
  });
});
