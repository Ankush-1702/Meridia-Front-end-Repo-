import { describe, it, expect } from 'vitest';
import { buildVesselClassOptions } from '../fleetFilterUtils';
import { VesselClassGroup } from '@/features/Fleets/types/fleetTypes';

describe('buildVesselClassOptions', () => {
  it('returns an empty array for an empty input', () => {
    expect(buildVesselClassOptions([])).toEqual([]);
  });

  it('maps a known vessel class to its vessel type grouping display name', () => {
    const groups: VesselClassGroup[] = [
      { vessel_type: 'Oil Tanker', classes: ['VLCC'] },
    ];
    const result = buildVesselClassOptions(groups);
    expect(result).toEqual([
      { value: 'VLCC', label: 'VLCC', groupings: 'Oil Tanker' },
    ]);
  });

  it('groups an unknown class under "Other"', () => {
    const groups: VesselClassGroup[] = [
      { vessel_type: 'Other', classes: ['Not A Real Class'] },
    ];
    const result = buildVesselClassOptions(groups);
    expect(result).toEqual([
      {
        value: 'Not A Real Class',
        label: 'Not A Real Class',
        groupings: 'Other',
      },
    ]);
  });

  it('maps multiple classes, preserving input order', () => {
    const groups: VesselClassGroup[] = [
      { vessel_type: 'Oil Tanker', classes: ['VLCC'] },
      { vessel_type: 'Bulk carrier', classes: ['Handysize'] },
    ];
    const result = buildVesselClassOptions(groups);
    expect(result.map((r) => r.value)).toEqual(['VLCC', 'Handysize']);
  });

  it('uses the class name for both value and label', () => {
    const groups: VesselClassGroup[] = [
      { vessel_type: 'Bulk carrier', classes: ['Panamax'] },
    ];
    const [option] = buildVesselClassOptions(groups);
    expect(option.value).toBe(option.label);
  });
});
