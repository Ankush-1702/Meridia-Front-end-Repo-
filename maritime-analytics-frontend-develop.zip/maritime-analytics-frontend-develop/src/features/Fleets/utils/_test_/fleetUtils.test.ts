import { describe, it, expect } from 'vitest';
import { VesselData } from '../../types/fleetTypes';
import { toVesselSearch, formatCoordinate } from '../fleetUtils';

const baseVessel: VesselData = {
  added_at: '2024-01-01T00:00:00Z',
  added_by: 'user-1',
  vessel_information: {
    asset_id: 'asset-1',
    callsign: 'ABC123',
    flag: 'Panama',
    flag_code: 'PA',
    imo: '1234567',
    mmsi: '987654321',
    name: 'Evergreen',
    vessel_status: 'ACTIVE',
    vessel_type: 'Cargo',
    vessel_class: 'Panamax',
    build_year: 2010,
    age: 14,
    deadweight: 50000,
  },
  vessel_position: {
    latitude: 1.3,
    longitude: 103.8,
    course: 90,
    heading: 90,
    speed: 12,
    navigational_status: { status: 'Under way', code: 0 },
    draught: 10,
    reported_destination: 'SGSIN',
    reported_eta: '2024-01-02T00:00:00Z',
    timestamp: '2024-01-01T12:00:00Z',
    source: 'AIS',
  },
};

describe('toVesselSearch', () => {
  it('maps vessel_information fields to a VesselSearch shape', () => {
    expect(toVesselSearch(baseVessel)).toEqual({
      asset_id: 'asset-1',
      callsign: 'ABC123',
      flag: 'Panama',
      flag_code: 'PA',
      imo: '1234567',
      mmsi: '987654321',
      name: 'Evergreen',
      vessel_type: 'Cargo',
      vessel_status: 'ACTIVE',
    });
  });

  it('falls back mmsi to null when null/undefined', () => {
    const vessel: VesselData = {
      ...baseVessel,
      vessel_information: {
        ...baseVessel.vessel_information,
        mmsi: undefined as unknown as string,
      },
    };
    expect(toVesselSearch(vessel).mmsi).toBeNull();
  });
});

describe('formatCoordinate', () => {
  it('formats a positive value with the positive label', () => {
    expect(formatCoordinate(1.2345, 'N', 'S')).toBe('1.234°N');
  });

  it('formats a negative value with the negative label using absolute value', () => {
    expect(formatCoordinate(-1.2345, 'N', 'S')).toBe('1.234°S');
  });

  it('treats zero as non-negative (positive label)', () => {
    expect(formatCoordinate(0, 'N', 'S')).toBe('0.000°N');
  });

  it('rounds to three decimal places', () => {
    expect(formatCoordinate(103.799999, 'E', 'W')).toBe('103.800°E');
  });
});
