import { VesselClassGroup } from '@/features/Fleets/types/fleetTypes';
import { DropdownOption } from '@/shared/components/MultiSelectDropdown';
import {
  VesselClassData,
  getDisplayName,
  vesselTypesMappings,
} from '@/shared/utils/CongestionAndTrafficUtils';

export function getVesselTypeForClass(className: string): string | undefined {
  return Object.entries(VesselClassData).find(([, classes]) =>
    classes.some((c) => c.className === className),
  )?.[0];
}

/**
 * Vessel class options are grouped by their parent vessel type using the backend's actual
 * per-fleet data (GET /v2/fleets/{fleet_id}/filters), not a static taxonomy - so groups only ever
 * contain classes the fleet's own vessels actually have, scoped to whichever type(s) are
 * currently selected (one-directional: type narrows class, never the reverse).
 */
export function buildVesselClassOptions(
  groups: VesselClassGroup[],
): DropdownOption[] {
  return groups.flatMap((group) =>
    group.classes.map((className) => ({
      value: className,
      label: className,
      groupings: getDisplayName(group.vessel_type),
    })),
  );
}

export const UNKNOWN_VESSEL_TYPE = 'Unknown';

/**
 * Resolves a raw fleet vessel_type filter value to its canonical vesselTypesMappings
 * group via a case-insensitive containment check (the mapping value is treated as the
 * combined/broader form of the raw value). Falls back to the "Unknown" sentinel group.
 */
export function resolveVesselTypeGroup(rawVesselType: string): string {
  const match = vesselTypesMappings.find((m) =>
    m.value.toLowerCase().includes(rawVesselType.toLowerCase()),
  );
  return match?.value ?? UNKNOWN_VESSEL_TYPE;
}

export function getClassNamesForVesselType(
  vesselType: string,
  vesselClasses: string[],
): string[] {
  if (vesselType === 'Unknown') {
    return vesselClasses.filter((c) => !getVesselTypeForClass(c));
  }
  return vesselClasses.filter((c) => getVesselTypeForClass(c) === vesselType);
}
