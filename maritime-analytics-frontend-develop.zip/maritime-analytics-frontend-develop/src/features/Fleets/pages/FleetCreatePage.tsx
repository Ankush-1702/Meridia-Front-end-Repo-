import { Spinner } from 'flowbite-react';
import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router';
import AddVesselsCard from '../components/AddVesselsCard';
import CreateFleetDetailsCard from '../components/CreateFleetDetailsCard';
import useBulkImports from '../hooks/useBulkImports';
import { useFleetEdit } from '../hooks/useFleetEdit';
import { useGetFleets } from '../hooks/useGetFleets';
import { useSearchVessels } from '../hooks/useSearchVessels';
import { createFleet, updateFleet } from '../services/fleetService';
import { IUpdateFleets, UnresolvedImos } from '../types/fleetTypes';
import FleetPreview from '../ui/FleetPreview';
import { toVesselSearchFromBulkFound } from '../utils/fleetUtils';
import { FLEET_VESSEL_CAP, validateFleetForm } from '../utils/fleetValidation';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useInfiniteScroll } from '@/features/library/hooks/useInfiniteScroll';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import { ConfirmationModal } from '@/shared/components/ConfirmationModal';
import { useDebounce } from '@/shared/hooks/useDebounce';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import EntityToolBar from '@/shared/ui/EntityToolbar';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';

const breadcrumbs = [
  { label: 'Library', href: '/analytics/library' },
  { label: 'Fleets', href: '/analytics/library?tab=Fleets' },
];

const TABS = ['Search', 'Bulk Import'];

export default function FleetCreatePage() {
  const navigate = useNavigate();
  const sideBarExpanded = localStorage.getItem('sidebarExpanded') === 'true';
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const cameFromFleetPage =
    (location.state as { from?: string } | null)?.from === 'fleetPage';
  const isEditing = !!id;
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [query, setQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'Search' | 'Bulk Import'>(
    'Search',
  );
  const [selectedVessels, setSelectedVessels] = useState<VesselSearch[]>([]);
  const [confirmationModalOpen, setConfrimationModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [unresolved, setUnresolved] = useState<UnresolvedImos | undefined>(
    undefined,
  );

  const onDismissUnresolvedImo = (imo: string) => {
    setUnresolved((prev) => {
      if (!prev) return prev;
      const notFound = prev.notFound.filter((i) => i.imo !== imo);
      const inValid = prev.inValid.filter((i) => i.imo !== imo);
      return notFound.length > 0 || inValid.length > 0
        ? { notFound, inValid }
        : undefined;
    });
  };

  const onDismissAllUnresolvedImos = () => {
    setUnresolved(undefined);
  };

  const debouncedQuery = useDebounce(query, 500);

  const { vessels } = useSearchVessels(debouncedQuery);
  const handleScroll = useInfiniteScroll(vessels.loadMore);
  const {
    bulkImos,
    setBulkImos,
    downloadTemplate,
    uploadImos,
    fileInputRef,
    file,
    setFile,
    handleDrop,
    handleDragOver,
    handleFile,
    vessels: verifiedVessels,
    verifying,
  } = useBulkImports();

  const handleClearQuery = () => {
    setQuery('');
    vessels.reset();
  };

  const {
    fleet,
    initialVessels,
    loading: fleetLoading,
    loadError,
  } = useFleetEdit(id);

  const { fleets } = useGetFleets('Fleets');

  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();

  useEffect(() => {
    if (fleet) {
      setName(fleet.name);
      setDescription(fleet.description ?? '');
    }
  }, [fleet]);

  useEffect(() => {
    setSelectedVessels(initialVessels);
  }, [initialVessels]);

  useEffect(() => {
    if (!verifiedVessels) return;

    const newlyFound = verifiedVessels.data.found.map(
      toVesselSearchFromBulkFound,
    );
    setSelectedVessels((prev) => {
      const existingImos = new Set(prev.map((v) => v.imo));
      const fresh = newlyFound.filter((v) => !existingImos.has(v.imo));
      return [...prev, ...fresh];
    });

    const notFound = verifiedVessels.data.not_found;
    const invalid = verifiedVessels.data.invalid;
    setUnresolved(
      notFound.length > 0 || invalid.length > 0
        ? { notFound, inValid: invalid }
        : undefined,
    );
  }, [verifiedVessels]);

  const isDuplicateName = useMemo(() => {
    const trimmedName = name.trim().toLowerCase();
    if (!trimmedName) return false;

    return (fleets ?? []).some(
      (f) => f.fleet_id !== id && f.name.trim().toLowerCase() === trimmedName,
    );
  }, [fleets, name, id]);

  const validation = validateFleetForm(
    name,
    selectedVessels.length,
    isDuplicateName,
  );

  const selectedImos = useMemo(
    () => new Set(selectedVessels.map((v) => v.imo)),
    [selectedVessels],
  );

  const initialImos = useMemo(
    () => new Set(initialVessels.map((vessel) => vessel.imo)),
    [initialVessels],
  );

  const addImo = useMemo(
    () =>
      selectedVessels
        .filter((vessel) => !initialImos.has(vessel.imo))
        .map((vessel) => vessel.imo),
    [selectedVessels, initialImos],
  );

  const removeImo = useMemo(
    () =>
      initialVessels
        .filter((vessel) => !selectedImos.has(vessel.imo))
        .map((vessel) => vessel.imo),
    [initialVessels, selectedImos],
  );

  const hasUnsavedChanges = useMemo(() => {
    if (!isEditing) return true;

    const nameChanged = name.trim() !== (fleet?.name ?? '').trim();
    const descriptionChanged =
      description.trim() !== (fleet?.description ?? '').trim();
    const vesselsChanged = addImo.length > 0 || removeImo.length > 0;

    return nameChanged || descriptionChanged || vesselsChanged;
  }, [isEditing, name, description, fleet, addImo, removeImo]);

  const onTabChange = (tab: string) => {
    setActiveTab(tab as 'Search' | 'Bulk Import');
  };

  const handleCancel = () => {
    if (isEditing || name || selectedVessels.length > 0) {
      setConfrimationModalOpen(!confirmationModalOpen);
    } else {
      navigate(`/analytics/library?tab=Fleets`);
    }
  };

  const cancelAction = () => {
    if (isEditing && id && cameFromFleetPage) {
      navigate(`/analytics/fleet/${id}`);
    } else {
      navigate(`/analytics/library?tab=Fleets`);
    }
  };

  const handleSelectVessel = (v: VesselSearch) => {
    setSelectedVessels((prev) =>
      prev.some((p) => p.imo === v.imo) ? prev : [...prev, v],
    );
  };

  const handleRemoveVessel = (v: VesselSearch) => {
    setSelectedVessels((prev) => prev.filter((p) => p.imo !== v.imo));
  };

  const handleClearAll = () => setSelectedVessels([]);

  const saveChanges = async () => {
    if (!validation.isValid) {
      showToast(
        'error',
        validation.warningMessage || 'Please fix the errors before saving',
        5000,
      );
      return;
    }

    setIsSubmitting(true);

    try {
      if (id) {
        const payload: IUpdateFleets = {
          name: name.trim(),
          // Send an empty string so an existing description can be cleared.
          description: description.trim(),
          add_imo: addImo,
          remove_imo: removeImo,
        };

        const res = await updateFleet(id, payload);

        showToast(
          'success',
          `Fleet "${res.data.name}" updated successfully`,
          5000,
        );
        navigate(
          `${isEditing && cameFromFleetPage ? `/analytics/fleet/${id}` : '/analytics/library?tab=Fleets'}`,
        );
      } else {
        const payload = {
          name: name.trim(),
          description: description.trim() || undefined,
          imo_numbers: selectedVessels.map((vessel) => vessel.imo),
        };

        const res = await createFleet(payload);

        showToast(
          'success',
          `Fleet "${res.data.fleet.name}" created successfully`,
          5000,
        );
        navigate(`/analytics/fleet/${res.data.fleet.fleet_id}`);
      }
    } catch (error) {
      await handleApiError(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isEditing && loadError && !fleet) {
    return (
      <div className={`p-6`}>
        <GenericErrorPage />
      </div>
    );
  }

  return (
    <div
      data-testid="fleet-create-page"
      className={`flex h-screen flex-col bg-gray-100 dark:bg-gray-900`}
    >
      <EntityToolBar
        title={isEditing ? `Edit ${fleet?.name ?? ''}` : 'New Fleet'}
        breadcrumbs={breadcrumbs}
        dontShowDateRange
        cancel={handleCancel}
        disabled={!validation.isValid || isSubmitting || !hasUnsavedChanges}
        saveChanges={saveChanges}
        warnings={validation.warningMessage}
        isSubmitting={isSubmitting}
      />
      {isEditing && fleetLoading ? (
        <div className="flex flex-1 items-center justify-center">
          <Spinner size="lg" light color="psgPrimary" />
        </div>
      ) : (
        <div
          className={`flex w-full ${!sideBarExpanded ? ' mx-auto max-w-[1400px]' : ''}`}
        >
          <div className={`flex w-full flex-col`}>
            <div className={`px-6 py-4`}>
              <CreateFleetDetailsCard
                name={name}
                description={description}
                setName={setName}
                setDescription={setDescription}
                nameError={validation.nameError}
              />
            </div>
            <div className={`px-6 py-4`}>
              <AddVesselsCard
                tabs={TABS}
                query={query}
                onQueryChange={setQuery}
                onClear={handleClearQuery}
                activeTab={activeTab}
                onTabChange={onTabChange}
                results={vessels.items}
                handleScroll={handleScroll}
                onSelectVessel={handleSelectVessel}
                selectedImos={selectedImos}
                isLoading={vessels.initialLoading}
                loadingMore={vessels.loadingMore}
                error={vessels.error}
                hasSearched={vessels.hasSearched}
                debouncedQuery={debouncedQuery}
                bulkImos={bulkImos}
                setBulkImos={setBulkImos}
                onUpload={uploadImos}
                onDownload={downloadTemplate}
                fileInputRef={fileInputRef}
                file={file}
                setFile={setFile}
                handleDrop={handleDrop}
                handleDragOver={handleDragOver}
                handleFile={handleFile}
                verifying={verifying}
              />
            </div>
          </div>
          <div className={`px-6 py-4`}>
            <FleetPreview
              type={`static`}
              matched={selectedVessels}
              cap={FLEET_VESSEL_CAP}
              headline={selectedVessels.length}
              limitsOn
              onRemove={handleRemoveVessel}
              onClearAll={handleClearAll}
              unresolved={unresolved}
              onDismissAllUnresolved={onDismissAllUnresolvedImos}
              onDismissUnresolved={onDismissUnresolvedImo}
            />
          </div>
        </div>
      )}
      {confirmationModalOpen && (
        <ConfirmationModal
          description={`This fleet hasn't been saved. Your name, description and the ${selectedVessels.length} vessel${selectedVessels.length === 1 ? '' : 's'} you've added will be lost.`}
          title={`Discard changes?`}
          confirmLabel={`Discard changes`}
          cancelLabel={`Keep editing`}
          onConfirm={cancelAction}
          onClose={() => setConfrimationModalOpen(!confirmationModalOpen)}
        />
      )}
    </div>
  );
}
