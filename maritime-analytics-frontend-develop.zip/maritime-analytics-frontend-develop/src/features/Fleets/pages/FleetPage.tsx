import { useCallback, useEffect, useState } from 'react';
import { FaMap } from 'react-icons/fa6';
import { FiList } from 'react-icons/fi';
// import { MdAutoAwesome } from 'react-icons/md';
import { useNavigate, useParams, useSearchParams } from 'react-router';
import DeleteFleetDescription from '../components/DeleteFleetDescription';
import { FleetKebabMenu } from '../components/FleetKebabMenu';
import { useFilters } from '../hooks/useFilters';
import { useFleetDetails } from '../hooks/useFleetDetails';
import { deleteFleet } from '../services/fleetService';
import { FleetOverviewView, VesselData } from '../types/fleetTypes';
import FleetComposition from '../ui/FleetComposition';
import FleetEventsTab from '../ui/FleetEventsTab';
import FleetOverview from '../ui/FleetOverview';
import { CreateFleetVesselsColDefs } from '../utils/FleetVesselsColDefs';
// import { isMara2Enabled } from '@/app/config/config';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';
// import {
//   ASK_IQ_PATH,
//   askIqPrompts,
//   buildAskIqNavigationState,
// } from '@/features/mara2/utils/askIq';
import { ConfirmationModal } from '@/shared/components/ConfirmationModal';
import EntityLoadingSkeleton from '@/shared/components/EntityLoadingSkeleton';
import EntityTabs from '@/shared/components/EntityTabs';
import { type TabConfig } from '@/shared/components/TabGroup';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import EntityToolBar from '@/shared/ui/EntityToolbar';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';
import { logger } from '@/shared/utils/logger';

const POLLING_INTERVAL = 5 * 60 * 1000;

const BREAD_CRUMBS = [
  { label: 'Library', href: '/analytics/library' },
  { label: 'Fleets', href: '/analytics/library?tab=Fleets' },
];

const FLEETS_TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'composition', label: 'Composition' },
  { key: 'events', label: 'Events' },
];

const VIEW_TABS: TabConfig[] = [
  {
    label: 'list',
    component: <FiList className="h-4 w-4" />,
    tooltip: 'List view',
    position: 'top',
  },
  {
    label: 'map',
    component: <FaMap className="h-4 w-4" />,
    tooltip: 'Map view',
    position: 'top',
  },
];

export default function FleetDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { fleet, loading: fleetLoading, loadError } = useFleetDetails(id);
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const [showDeleteConfirmationModal, setShowDeleteConfirmationModal] =
    useState(false);
  const {
    flags,
    vesselTypes,
    vesselClassGroups,
    mtiScores,
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    selectedMtiScores,
    handleFlagToggle,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleMtiScoreToggle,
    handleFlagSelectAll,
    handleVesselTypeSelectAll,
    handleVesselClassSelectAll,
    handleMtiScoreSelectAll,
    resetFilters,
    refresh,
    vessels,
    vesselsLoading,
    hasActiveFilters,
    activeFlags,
    activeVesselTypes,
    activeVesselClasses,
    activeMtiScores,
    filtersAppliedCount,
  } = useFilters();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') ?? 'overview';
  const setActiveTab = useCallback(
    (tab: string) => {
      setSearchParams(
        (prev) => {
          const next = new URLSearchParams(prev);
          next.set('tab', tab);
          return next;
        },
        { replace: false },
      );
    },
    [setSearchParams],
  );
  const [view, setView] = useState<FleetOverviewView>('map');
  const hasMTIScore = hasGroupPermission('meridia-mti-tier1');
  const hasPtracAccess = hasGroupPermission('auto-screening');

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [timeAgo, setTimeAgo] = useState<string>('0s');
  const [currentVessel, setCurrentVessel] = useState<VesselData | undefined>(
    undefined,
  );

  const buildColumns = useCallback(() => {
    return CreateFleetVesselsColDefs();
  }, []);

  const refreshAllData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      await refresh();
      setLastUpdated(new Date());
    } finally {
      setIsRefreshing(false);
    }
  }, [refresh]);

  useEffect(() => {
    const updateTimeAgo = () => {
      const diff = Math.floor((Date.now() - lastUpdated.getTime()) / 1000);
      if (diff < 60) {
        setTimeAgo(`${diff}s`);
      } else {
        setTimeAgo(`${Math.floor(diff / 60)}m`);
      }
    };
    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 1000);
    return () => clearInterval(interval);
  }, [lastUpdated]);

  useEffect(() => {
    const interval = setInterval(refreshAllData, POLLING_INTERVAL);
    return () => clearInterval(interval);
  }, [refreshAllData]);

  // const handleAskIQ = () => {
  //   if (!fleet?.name) return;
  //   navigate(
  //     ASK_IQ_PATH,
  //     buildAskIqNavigationState(askIqPrompts.fleet(fleet.name)),
  //   );
  // };

  const handleDeleteFleet = async () => {
    if (!id) return;
    try {
      await deleteFleet(id);
      showToast('success', 'Fleet deleted successfully', 5000);
      navigate('/analytics/library?tab=Fleets');
    } catch (e) {
      handleApiError(e);
      logger.error(e as string);
    }
  };

  if (fleetLoading) {
    return (
      <div className="h-screen p-6 dark:bg-gray-900">
        <EntityLoadingSkeleton />
      </div>
    );
  }

  if (loadError || !fleet) {
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-gray-100 dark:bg-gray-900 lg:overflow-hidden">
      <header className="sticky top-0 z-20 bg-gray-100 dark:bg-gray-900">
        <EntityToolBar
          key={`fleet Details`}
          breadcrumbs={BREAD_CRUMBS}
          title={fleet.name}
          subtitle={`${fleet.vessel_count === 1 ? `${fleet.vessel_count} vessel` : `${fleet.vessel_count} vessels`}`}
          dontShowDateRange
          renderExtraActions={
            <FleetKebabMenu
              onEdit={() =>
                navigate(`/analytics/fleet/${id}/edit`, {
                  state: { from: 'fleetPage' },
                })
              }
              onDelete={() => setShowDeleteConfirmationModal(true)}
            />
          }
        />
      </header>
      <div className="h-12 bg-gray-50">
        <EntityTabs
          tabs={FLEETS_TABS}
          activeTab={activeTab}
          onChange={setActiveTab}
          // renderActions={
          //   isMara2Enabled() && (
          //     <button
          //       onClick={handleAskIQ}
          //       className="-mt-5 flex min-w-[110px] items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
          //     >
          //       <MdAutoAwesome className="text-gray-400" />
          //       Ask IQ
          //     </button>
          //   )
          // }
        />
      </div>
      <main className="h-full min-h-0 flex-1 overflow-auto">
        <div className="h-full min-h-0">
          <div className="">
            {activeTab === 'overview' && (
              <FleetOverview
                view={view}
                buildColumns={buildColumns}
                hasMTIScore={hasMTIScore}
                hasPtracAccess={hasPtracAccess}
                viewTabs={VIEW_TABS}
                setView={setView}
                flags={flags}
                vesselTypes={vesselTypes}
                vesselClassGroups={vesselClassGroups}
                mtiScores={mtiScores}
                selectedFlags={selectedFlags}
                selectedVesselTypes={selectedVesselTypes}
                selectedVesselClasses={selectedVesselClasses}
                selectedMtiScores={selectedMtiScores}
                onFlagToggle={handleFlagToggle}
                onVesselTypeToggle={handleVesselTypeToggle}
                onVesselClassToggle={handleVesselClassToggle}
                onMtiScoreToggle={handleMtiScoreToggle}
                onFlagSelectAll={handleFlagSelectAll}
                onVesselTypeSelectAll={handleVesselTypeSelectAll}
                onVesselClassSelectAll={handleVesselClassSelectAll}
                onMtiScoreSelectAll={handleMtiScoreSelectAll}
                onResetFilters={resetFilters}
                hasActiveFilters={hasActiveFilters}
                activeFlagCodes={activeFlags}
                activeVesselTypes={activeVesselTypes}
                activeVesselClasses={activeVesselClasses}
                activeMtiScores={activeMtiScores}
                filtersAppliedCount={filtersAppliedCount}
                totalVesselCount={fleet.vessel_count}
                vessels={vessels}
                vesselsLoading={vesselsLoading}
                onRefresh={refreshAllData}
                isRefreshing={isRefreshing}
                timeAgo={timeAgo}
                currentVessel={currentVessel}
                setCurrentVessel={setCurrentVessel}
              />
            )}
          </div>
          {activeTab === 'composition' && (
            <FleetComposition
              hasMTIScore={hasMTIScore}
              hasPtracAccess={hasPtracAccess}
            />
          )}
          {activeTab === 'events' && (
            <FleetEventsTab
              fleetId={id!}
              fleetName={fleet.name}
              hasMTIScore={hasMTIScore}
              hasPtracAccess={hasPtracAccess}
            />
          )}
        </div>
      </main>
      {showDeleteConfirmationModal && (
        <ConfirmationModal
          title="Delete fleet?"
          confirmLabel="Delete fleet"
          variant="danger"
          onClose={() => setShowDeleteConfirmationModal(false)}
          onConfirm={handleDeleteFleet}
          description={<DeleteFleetDescription fleet={fleet} />}
        />
      )}
    </div>
  );
}
