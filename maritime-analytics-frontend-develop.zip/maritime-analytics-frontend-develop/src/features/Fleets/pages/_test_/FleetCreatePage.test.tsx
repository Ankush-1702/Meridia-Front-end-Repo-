import { act, fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import FleetCreatePage from '../FleetCreatePage';
import * as fleetService from '@/features/Fleets/services/fleetService';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

const mockNavigate = vi.fn();
let mockParamsId: string | undefined;
const mockLocationState: { from?: string } | null = null;

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
  useParams: () => ({ id: mockParamsId }),
  useLocation: () => ({ state: mockLocationState }),
}));

vi.mock('@/features/Fleets/services/fleetService');

const mockHandleApiError = vi.fn();
vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

const mockShowToast = vi.fn();
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

const mockUseFleetEdit = vi.fn();
vi.mock('@/features/Fleets/hooks/useFleetEdit', () => ({
  useFleetEdit: (...args: unknown[]) => mockUseFleetEdit(...args),
}));

const mockUseGetFleets = vi.fn();
vi.mock('@/features/Fleets/hooks/useGetFleets', () => ({
  useGetFleets: (...args: unknown[]) => mockUseGetFleets(...args),
}));

const mockUseSearchVessels = vi.fn();
vi.mock('@/features/Fleets/hooks/useSearchVessels', () => ({
  useSearchVessels: (...args: unknown[]) => mockUseSearchVessels(...args),
}));

vi.mock('@/shared/ui/EntityToolbar', () => ({
  default: ({
    title,
    cancel,
    saveChanges,
    disabled,
    warnings,
    isSubmitting,
  }: {
    title: string;
    cancel: () => void;
    saveChanges: () => void;
    disabled: boolean;
    warnings?: string;
    isSubmitting: boolean;
  }) => (
    <div>
      <span>{title}</span>
      {warnings && <span>{warnings}</span>}
      <button onClick={cancel}>Cancel</button>
      <button onClick={saveChanges} disabled={disabled || isSubmitting}>
        Save
      </button>
    </div>
  ),
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: () => <div>GenericErrorPage</div>,
}));

vi.mock('@/features/Fleets/components/CreateFleetDetailsCard', () => ({
  default: ({
    name,
    setName,
  }: {
    name: string;
    setName: (v: string) => void;
  }) => (
    <input
      aria-label="fleet-name"
      value={name}
      onChange={(e) => setName(e.target.value)}
    />
  ),
}));

vi.mock('@/features/Fleets/components/AddVesselsCard', () => ({
  default: ({
    onSelectVessel,
  }: {
    onSelectVessel: (v: VesselSearch) => void;
  }) => (
    <button
      onClick={() =>
        onSelectVessel({
          imo: '1234567',
          name: 'Test Vessel',
          flag: 'Norway',
          flag_code: 'NOR',
          vessel_type: 'Cargo',
        } as VesselSearch)
      }
    >
      AddVesselsCard
    </button>
  ),
}));

vi.mock('@/features/Fleets/ui/FleetPreview', () => ({
  default: ({ onClearAll }: { onClearAll: () => void }) => (
    <button onClick={onClearAll}>FleetPreview</button>
  ),
}));

vi.mock('@/shared/components/ConfirmationModal', () => ({
  ConfirmationModal: ({
    onConfirm,
    onClose,
  }: {
    onConfirm: () => void;
    onClose: () => void;
  }) => (
    <div>
      <span>ConfirmationModal</span>
      <button onClick={onConfirm}>Discard changes</button>
      <button onClick={onClose}>Keep editing</button>
    </div>
  ),
}));

function defaultVessels() {
  return {
    items: [] as VesselSearch[],
    initialLoading: false,
    loadingMore: false,
    error: null,
    loadMore: vi.fn(),
    hasMore: false,
    hasSearched: false,
    reset: vi.fn(),
  };
}

describe('FleetCreatePage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockParamsId = undefined;
    mockUseFleetEdit.mockReturnValue({
      fleet: undefined,
      initialVessels: [],
      loading: false,
      loadError: false,
    });
    mockUseGetFleets.mockReturnValue({ fleets: [], fleetsLoading: false });
    mockUseSearchVessels.mockReturnValue({ vessels: defaultVessels() });
  });

  it('shows "New Fleet" as the title when creating', () => {
    render(<FleetCreatePage />);

    expect(screen.getByText('New Fleet')).toBeInTheDocument();
  });

  it('shows "Edit <name>" as the title when editing an existing fleet', () => {
    mockParamsId = 'fleet-1';
    mockUseFleetEdit.mockReturnValue({
      fleet: { name: 'North Sea Fleet', description: 'desc' },
      initialVessels: [],
      loading: false,
      loadError: false,
    });

    render(<FleetCreatePage />);

    expect(screen.getByText('Edit North Sea Fleet')).toBeInTheDocument();
  });

  it('shows a loading spinner while editing and the fleet is loading', () => {
    mockParamsId = 'fleet-1';
    mockUseFleetEdit.mockReturnValue({
      fleet: undefined,
      initialVessels: [],
      loading: true,
      loadError: false,
    });

    const { container } = render(<FleetCreatePage />);

    expect(container.querySelector('[role="status"]')).toBeInTheDocument();
    expect(screen.queryByText('AddVesselsCard')).not.toBeInTheDocument();
  });

  it('shows the generic error page when editing fails to load the fleet', () => {
    mockParamsId = 'fleet-1';
    mockUseFleetEdit.mockReturnValue({
      fleet: undefined,
      initialVessels: [],
      loading: false,
      loadError: true,
    });

    render(<FleetCreatePage />);

    expect(screen.getByText('GenericErrorPage')).toBeInTheDocument();
  });

  it('adds a vessel via AddVesselsCard and reflects it in FleetPreview flow', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('AddVesselsCard'));

    expect(screen.getByText('FleetPreview')).toBeInTheDocument();
  });

  it('disables Save when the name is empty', () => {
    render(<FleetCreatePage />);

    expect(screen.getByText('Save')).toBeDisabled();
  });

  it('enables Save once a valid name is entered and a vessel is selected', () => {
    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'My Fleet' },
    });
    fireEvent.click(screen.getByText('AddVesselsCard'));

    expect(screen.getByText('Save')).not.toBeDisabled();
  });

  it('creates a fleet on save when not editing', async () => {
    (fleetService.createFleet as Mock).mockResolvedValue({
      data: { fleet: { name: 'My Fleet', fleet_id: 'fleet-99' } },
    });

    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'My Fleet' },
    });
    fireEvent.click(screen.getByText('AddVesselsCard'));

    await act(async () => {
      fireEvent.click(screen.getByText('Save'));
    });

    expect(fleetService.createFleet).toHaveBeenCalledWith(
      expect.objectContaining({
        name: 'My Fleet',
        imo_numbers: ['1234567'],
      }),
    );
  });

  it('navigates to the new fleet page after a successful create', async () => {
    (fleetService.createFleet as Mock).mockResolvedValue({
      data: { fleet: { name: 'My Fleet', fleet_id: 'fleet-99' } },
    });

    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'My Fleet' },
    });
    fireEvent.click(screen.getByText('AddVesselsCard'));

    await act(async () => {
      fireEvent.click(screen.getByText('Save'));
    });

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/fleet/fleet-99');
  });

  it('updates a fleet on save when editing', async () => {
    mockParamsId = 'fleet-1';
    mockUseFleetEdit.mockReturnValue({
      fleet: { name: 'North Sea Fleet', description: 'desc' },
      initialVessels: [
        {
          imo: '7654321',
          name: 'Existing Vessel',
          flag: 'Norway',
          flag_code: 'NOR',
          vessel_type: 'Cargo',
        } as VesselSearch,
      ],
      loading: false,
      loadError: false,
    });
    (fleetService.updateFleet as Mock).mockResolvedValue({
      data: { name: 'North Sea Fleet Updated' },
    });

    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'North Sea Fleet Updated' },
    });

    await act(async () => {
      fireEvent.click(screen.getByText('Save'));
    });

    expect(fleetService.updateFleet).toHaveBeenCalledWith(
      'fleet-1',
      expect.objectContaining({ name: 'North Sea Fleet Updated' }),
    );
    expect(mockNavigate).toHaveBeenCalledWith('/analytics/library?tab=Fleets');
  });

  it('calls the API error handler when save fails', async () => {
    (fleetService.createFleet as Mock).mockRejectedValue(new Error('fail'));

    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'My Fleet' },
    });
    fireEvent.click(screen.getByText('AddVesselsCard'));

    await act(async () => {
      fireEvent.click(screen.getByText('Save'));
    });

    expect(mockHandleApiError).toHaveBeenCalled();
  });

  it('shows a discard confirmation when cancelling with unsaved vessels', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('AddVesselsCard'));
    fireEvent.click(screen.getByText('Cancel'));

    expect(screen.getByText('ConfirmationModal')).toBeInTheDocument();
  });

  it('navigates away immediately when cancelling with no changes', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('Cancel'));

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/library?tab=Fleets');
    expect(screen.queryByText('ConfirmationModal')).not.toBeInTheDocument();
  });

  it('discards changes and navigates away when confirmed', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('AddVesselsCard'));
    fireEvent.click(screen.getByText('Cancel'));
    fireEvent.click(screen.getByText('Discard changes'));

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/library?tab=Fleets');
  });

  it('closes the confirmation modal without navigating when "Keep editing" is clicked', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('AddVesselsCard'));
    fireEvent.click(screen.getByText('Cancel'));
    fireEvent.click(screen.getByText('Keep editing'));

    expect(screen.queryByText('ConfirmationModal')).not.toBeInTheDocument();
    expect(mockNavigate).not.toHaveBeenCalled();
  });

  it('clears all selected vessels via FleetPreview', () => {
    render(<FleetCreatePage />);

    fireEvent.click(screen.getByText('AddVesselsCard'));
    fireEvent.click(screen.getByText('FleetPreview'));

    fireEvent.click(screen.getByText('Cancel'));
    expect(mockNavigate).toHaveBeenCalledWith('/analytics/library?tab=Fleets');
  });

  it('does not enable Save when the entered name duplicates another fleet', () => {
    mockUseGetFleets.mockReturnValue({
      fleets: [
        {
          fleet_id: 'other-fleet',
          name: 'My Fleet',
        },
      ],
      fleetsLoading: false,
    });

    render(<FleetCreatePage />);

    fireEvent.change(screen.getByLabelText('fleet-name'), {
      target: { value: 'My Fleet' },
    });
    fireEvent.click(screen.getByText('AddVesselsCard'));

    expect(screen.getByText('Save')).toBeDisabled();
  });
});
