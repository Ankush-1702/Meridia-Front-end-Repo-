import { render, screen } from '@testing-library/react';
import type { ReactElement } from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FleetDetailsPage from '../FleetPage';
import { Fleet, VesselData } from '@/features/Fleets/types/fleetTypes';
import { ToastProvider } from '@/shared/lib/PoleStarNotification';

const mockNavigate = vi.fn();
let mockParamsId: string | undefined = 'fleet-1';
let mockSearchParams = new URLSearchParams();

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
  useParams: () => ({ id: mockParamsId }),
  useSearchParams: () => [
    mockSearchParams,
    (
      updater: URLSearchParams | ((prev: URLSearchParams) => URLSearchParams),
    ) => {
      mockSearchParams =
        typeof updater === 'function' ? updater(mockSearchParams) : updater;
    },
  ],
}));

const mockUseFleetDetails = vi.fn();
vi.mock('@/features/Fleets/hooks/useFleetDetails', () => ({
  useFleetDetails: (...args: unknown[]) => mockUseFleetDetails(...args),
}));

function defaultFiltersReturn() {
  return {
    flags: [] as string[],
    vesselTypes: [] as string[],
    vesselClassGroups: [],
    vesselClasses: [] as string[],
    mtiScores: [] as string[],
    selectedFlags: {},
    selectedVesselTypes: {},
    selectedVesselClasses: {},
    selectedMtiScores: {},
    handleFlagToggle: vi.fn(),
    handleVesselTypeToggle: vi.fn(),
    handleVesselClassToggle: vi.fn(),
    handleMtiScoreToggle: vi.fn(),
    handleFlagSelectAll: vi.fn(),
    handleVesselTypeSelectAll: vi.fn(),
    handleVesselClassSelectAll: vi.fn(),
    handleMtiScoreSelectAll: vi.fn(),
    resetFilters: vi.fn(),
    refresh: vi.fn(),
    vessels: [] as VesselData[],
    vesselsLoading: false,
    hasActiveFilters: false,
    activeFlags: [],
    activeVesselTypes: [],
    activeVesselClasses: [],
    activeMtiScores: [],
    filtersAppliedCount: 0,
  };
}

const mockUseFilters = vi.fn();
vi.mock('@/features/Fleets/hooks/useFilters', () => ({
  useFilters: () => mockUseFilters(),
}));

let mockMara2Enabled = false;
const mockHasGroupPermission = vi.fn();

vi.mock('@/app/config/config', () => ({
  AG_GRID_LICENSE_KEY: '',
  MAPBOX_TOKEN: '',
  isMara2Enabled: () => mockMara2Enabled,
}));

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  hasGroupPermission: (...args: unknown[]) => mockHasGroupPermission(...args),
}));

vi.mock('@/shared/components/EntityLoadingSkeleton', () => ({
  default: () => <div>EntityLoadingSkeleton</div>,
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: () => <div>GenericErrorPage</div>,
}));

vi.mock('@/shared/ui/EntityToolbar', () => ({
  default: ({ title, subtitle }: { title: string; subtitle: string }) => (
    <div>
      <span>{title}</span>
      <span>{subtitle}</span>
    </div>
  ),
}));

vi.mock('@/shared/components/EntityTabs', () => ({
  default: ({ renderActions }: { renderActions: React.ReactNode }) => (
    <div>{renderActions}</div>
  ),
}));

vi.mock('@/features/Fleets/ui/FleetOverview', () => ({
  default: () => <div>FleetOverview</div>,
}));

vi.mock('@/features/Fleets/ui/FleetComposition', () => ({
  default: () => <div>FleetComposition</div>,
}));

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    fleet_id: 'fleet-1',
    name: 'North Sea Fleet',
    description: 'desc',
    type: 'STATIC',
    vessel_count: 5,
    created_by: 'user-1',
    created_at: '2026-01-01T00:00:00Z',
    last_modified_by: 'user-1',
    last_modified_at: '2026-01-01T00:00:00Z',
    ...overrides,
  };
}

function renderWithProviders(ui: ReactElement) {
  return render(<ToastProvider>{ui}</ToastProvider>);
}

describe('FleetDetailsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockParamsId = 'fleet-1';
    mockSearchParams = new URLSearchParams();
    mockMara2Enabled = false;
    mockHasGroupPermission.mockReturnValue(false);
    mockUseFilters.mockReturnValue(defaultFiltersReturn());
    mockUseFleetDetails.mockReturnValue({
      fleet: makeFleet(),
      loading: false,
      loadError: false,
    });
  });

  it('shows the loading skeleton while the fleet is loading', () => {
    mockUseFleetDetails.mockReturnValue({
      fleet: undefined,
      loading: true,
      loadError: false,
    });

    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('EntityLoadingSkeleton')).toBeInTheDocument();
  });

  it('shows the generic error page when the fleet fails to load', () => {
    mockUseFleetDetails.mockReturnValue({
      fleet: undefined,
      loading: false,
      loadError: true,
    });

    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('GenericErrorPage')).toBeInTheDocument();
  });

  it('shows the generic error page when the fleet is missing even without an explicit error', () => {
    mockUseFleetDetails.mockReturnValue({
      fleet: undefined,
      loading: false,
      loadError: false,
    });

    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('GenericErrorPage')).toBeInTheDocument();
  });

  it('renders the fleet name and pluralized vessel count', () => {
    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('North Sea Fleet')).toBeInTheDocument();
    expect(screen.getByText('5 vessels')).toBeInTheDocument();
  });

  it('renders the fleet name and singular vessel count', () => {
    mockUseFleetDetails.mockReturnValue({
      fleet: makeFleet({ vessel_count: 1 }),
      loading: false,
      loadError: false,
    });

    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('1 vessel')).toBeInTheDocument();
  });

  it('renders FleetOverview on the overview tab', () => {
    renderWithProviders(<FleetDetailsPage />);

    expect(screen.getByText('FleetOverview')).toBeInTheDocument();
  });

  it('does not render the Ask IQ button when mara2 is disabled', () => {
    mockMara2Enabled = false;

    renderWithProviders(<FleetDetailsPage />);

    expect(screen.queryByText('Ask IQ')).not.toBeInTheDocument();
  });

  it('checks the meridia-mti-tier1 and auto-screening permissions', () => {
    renderWithProviders(<FleetDetailsPage />);

    expect(mockHasGroupPermission).toHaveBeenCalledWith('meridia-mti-tier1');
    expect(mockHasGroupPermission).toHaveBeenCalledWith('auto-screening');
  });
});
