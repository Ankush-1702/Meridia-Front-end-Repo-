import { useMemo, useRef, useState } from 'react';
import Bars from '../components/BarChart';
import ChartsCard from '../components/ChartsCard';
import Donut from '../components/DonutChart';
import RankedRows from '../components/RankedRows';
import SubHeadingToggle, {
  SubHeadingView,
} from '../components/SubHeadingToggle';
import {
  FleetCompositionItems,
  FleetCompositionResponse,
  VesselClassGroup,
} from '../types/fleetTypes';
import {
  FLAG_NAME_OVERRIDES,
  buildFleetCompositionCsv,
  colorForItem,
  namesMatch,
} from '../utils/fleetUtils';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { countries } from '@/features/library/utils/countryMapping';
import TabGroup from '@/shared/components/TabGroup';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';
import { sanitizeFilenameSegment } from '@/shared/utils/formatUtils';

export interface FleetCompositionChartsProps {
  composition: FleetCompositionResponse | null;
  isLoading: boolean;
  activeFlags: string[];
  activeVesselClasses: string[];
  vesselClassGroups: VesselClassGroup[];
}

const SIZETAB = ['DWT', 'GT'];
const DIMENSIONSTAB = ['LOA', 'Beam', 'Draught'];

export default function FleetCompositionCharts({
  composition,
  isLoading,
  activeFlags,
  activeVesselClasses,
  vesselClassGroups,
}: FleetCompositionChartsProps) {
  const { exportToCSV } = useLibrary();
  const [sizeTab, setSizeTab] = useState<string>('GT');
  const [dimensionsTab, setDimensionsTab] = useState<string>('Draught');
  const [flagView, setFlagView] = useState<SubHeadingView>('top5');
  const [portOfRegistryView, setPortOfRegistryView] =
    useState<SubHeadingView>('top5');
  const [countryOfBuildView, setCountryOfBuildView] =
    useState<SubHeadingView>('top5');
  const [builderView, setBuilderView] = useState<SubHeadingView>('top5');

  const fleetName = composition?.fleet_information.name ?? 'fleet';
  const totalVessels = composition?.data.summary.vessels.filtered_count ?? 0;

  const vesselTypeItems = useMemo(
    () => composition?.data.type_and_class.vessel_type ?? [],
    [composition],
  );
  const vesselClassItems = composition?.data.type_and_class.vessel_class ?? [];
  const allFlagItems =
    composition?.data.registration_and_flag.vessel_flag.items ?? [];
  const flagTotalCategories =
    composition?.data.registration_and_flag.vessel_flag.total_categories ?? 0;
  const flagItems = allFlagItems.slice(0, 5);

  const selectedFlagFullNames = useMemo(
    () =>
      activeFlags.map((code) =>
        (FLAG_NAME_OVERRIDES[code] ?? countries[code] ?? code)
          .trim()
          .toLowerCase(),
      ),
    [activeFlags],
  );
  const selectedClassNames = useMemo(
    () => new Set(activeVesselClasses.map((c) => c.trim().toLowerCase())),
    [activeVesselClasses],
  );
  const isFlagSelected = (item: FleetCompositionItems) =>
    selectedFlagFullNames.some((fullName) => namesMatch(item.label, fullName));
  const isClassSelected = (item: FleetCompositionItems) =>
    selectedClassNames.has(item.label.trim().toLowerCase());

  const typeColorByType = useMemo(
    () =>
      new Map(
        vesselTypeItems.map((item, i) => [
          item.label.trim().toLowerCase(),
          colorForItem(item, i),
        ]),
      ),
    [vesselTypeItems],
  );
  const classToVesselType = useMemo(
    () =>
      new Map(
        vesselClassGroups.flatMap((g) =>
          g.classes.map(
            (c) =>
              [
                c.trim().toLowerCase(),
                g.vessel_type.trim().toLowerCase(),
              ] as const,
          ),
        ),
      ),
    [vesselClassGroups],
  );
  const getClassColor = (item: FleetCompositionItems) => {
    const type = classToVesselType.get(item.label.trim().toLowerCase());
    return type ? typeColorByType.get(type) : undefined;
  };

  const allPortOfRegistryItems =
    composition?.data.registration_and_flag.port_of_registry.items ?? [];
  const portOfRegistryTotalCategories =
    composition?.data.registration_and_flag.port_of_registry.total_categories ??
    0;
  const portOfRegistryItems = allPortOfRegistryItems.slice(0, 5);

  const allCountryOfBuildItems =
    composition?.data.build_and_origin.country_of_build.items ?? [];
  const countryOfBuildTotalCategories =
    composition?.data.build_and_origin.country_of_build.total_categories ?? 0;
  const countryOfBuildItems = allCountryOfBuildItems.slice(0, 5);

  const allBuilderItems =
    composition?.data.build_and_origin.builder.items ?? [];
  const builderTotalCategories =
    composition?.data.build_and_origin.builder.total_categories ?? 0;
  const builderItems = allBuilderItems.slice(0, 5);
  const ageProfileItems = composition?.data.build_and_origin.age_profile ?? [];
  const sizeItems =
    sizeTab === 'DWT'
      ? (composition?.data.size_and_dimensions.size.deadweight_tonnage.items ??
        [])
      : (composition?.data.size_and_dimensions.size.gross_tonnage.items ?? []);
  const dimensionsItems =
    dimensionsTab === 'LOA'
      ? (composition?.data.size_and_dimensions.dimensions.length_overall
          .items ?? [])
      : dimensionsTab === 'Beam'
        ? (composition?.data.size_and_dimensions.dimensions.beam.items ?? [])
        : (composition?.data.size_and_dimensions.dimensions.draught.items ??
          []);
  const dimensionsVesselsWithData =
    dimensionsTab === 'LOA'
      ? (composition?.data.size_and_dimensions.dimensions.length_overall
          .vessels_with_data ?? 0)
      : dimensionsTab === 'Beam'
        ? (composition?.data.size_and_dimensions.dimensions.beam
            .vessels_with_data ?? 0)
        : (composition?.data.size_and_dimensions.dimensions.draught
            .vessels_with_data ?? 0);

  const vesselTypeChartRef = useRef<PoleStarChartHandle>(null);
  const vesselClassChartRef = useRef<PoleStarChartHandle>(null);
  const flagChartRef = useRef<PoleStarChartHandle>(null);
  const portOfRegistryChartRef = useRef<PoleStarChartHandle>(null);
  const countryOfBuildChartRef = useRef<PoleStarChartHandle>(null);
  const builderChartRef = useRef<PoleStarChartHandle>(null);
  const ageProfileChartRef = useRef<PoleStarChartHandle>(null);
  const sizeChartRef = useRef<PoleStarChartHandle>(null);
  const dimensionsChartRef = useRef<PoleStarChartHandle>(null);

  const subHeadingFor = (view: SubHeadingView, totalCategories: number) =>
    view === 'top5' ? `Top 5 by vessel count` : `All ${totalCategories}`;

  const makeExporters = (
    ref: React.RefObject<PoleStarChartHandle>,
    label: string,
    items: FleetCompositionItems[],
  ) => {
    const filename = sanitizeFilenameSegment(`${fleetName}-${label}`);
    return {
      onExportImage: () => ref.current?.downloadImage(filename),
      onExportCSV: () => {
        const csv = buildFleetCompositionCsv(label, items);
        if (csv) exportToCSV(csv, filename);
      },
    };
  };

  return (
    <div className={`flex flex-col space-y-3`}>
      <div className={`flex flex-col gap-2`}>
        <p className={`text-sm font-semibold text-gray-500`}>Type and class</p>
        <div className={`flex gap-2`}>
          <ChartsCard
            className={`w-[450px]`}
            title={`Vessel type`}
            subHeading={`Share of fleet`}
            isLoading={isLoading}
            hasData={vesselTypeItems.length > 0}
            chart={
              <Donut
                ref={vesselTypeChartRef}
                data={vesselTypeItems}
                total={totalVessels}
              />
            }
            {...makeExporters(
              vesselTypeChartRef,
              'vessel-type',
              vesselTypeItems,
            )}
          />
          <ChartsCard
            className={`flex-1 `}
            title={`Class`}
            subHeading={`Size band, coloured by vessel type`}
            isLoading={isLoading}
            hasData={vesselClassItems.length > 0}
            chart={
              <Bars
                ref={vesselClassChartRef}
                horizontal
                data={vesselClassItems}
                total={totalVessels}
                isItemSelected={isClassSelected}
                getItemColor={getClassColor}
              />
            }
            {...makeExporters(vesselClassChartRef, 'class', vesselClassItems)}
          />
        </div>
      </div>
      <div className={`flex flex-col gap-2`}>
        <p className={`text-sm font-semibold text-gray-500`}>
          Registration and flag
        </p>
        <div className={`flex gap-2`}>
          <ChartsCard
            className={`flex-1`}
            title={`Flag`}
            subHeading={subHeadingFor(flagView, flagTotalCategories)}
            subHeadingAction={
              <SubHeadingToggle
                view={flagView}
                onChange={setFlagView}
                count={flagTotalCategories}
                disabled={flagTotalCategories <= 5}
              />
            }
            scrollChart={flagView === 'all'}
            isLoading={isLoading}
            hasData={flagItems.length > 0}
            chart={
              flagView === 'all' ? (
                <RankedRows items={allFlagItems} />
              ) : (
                <Bars
                  ref={flagChartRef}
                  data={flagItems}
                  total={totalVessels}
                  isItemSelected={isFlagSelected}
                />
              )
            }
            {...makeExporters(
              flagChartRef,
              'flag',
              flagView === 'all' ? allFlagItems : flagItems,
            )}
          />
          <ChartsCard
            className={`flex-1`}
            title={`Port of registry`}
            subHeading={subHeadingFor(
              portOfRegistryView,
              portOfRegistryTotalCategories,
            )}
            subHeadingAction={
              <SubHeadingToggle
                view={portOfRegistryView}
                onChange={setPortOfRegistryView}
                disabled={portOfRegistryTotalCategories <= 5}
                count={portOfRegistryTotalCategories}
              />
            }
            scrollChart={portOfRegistryView === 'all'}
            isLoading={isLoading}
            hasData={portOfRegistryItems.length > 0}
            chart={
              portOfRegistryView === 'all' ? (
                <RankedRows items={allPortOfRegistryItems} />
              ) : (
                <Bars
                  ref={portOfRegistryChartRef}
                  data={portOfRegistryItems}
                  total={totalVessels}
                />
              )
            }
            {...makeExporters(
              portOfRegistryChartRef,
              'port-of-registry',
              portOfRegistryView === 'all'
                ? allPortOfRegistryItems
                : portOfRegistryItems,
            )}
          />
        </div>
      </div>
      <div className={`flex flex-col gap-2`}>
        <p className={`text-sm font-semibold text-gray-500`}>
          Build and origin
        </p>
        <div className={`flex gap-2`}>
          <ChartsCard
            className={`flex-1`}
            title={`Country of build`}
            subHeading={subHeadingFor(
              countryOfBuildView,
              countryOfBuildTotalCategories,
            )}
            subHeadingAction={
              <SubHeadingToggle
                view={countryOfBuildView}
                onChange={setCountryOfBuildView}
                disabled={countryOfBuildTotalCategories <= 5}
                count={countryOfBuildTotalCategories}
              />
            }
            scrollChart={countryOfBuildView === 'all'}
            isLoading={isLoading}
            hasData={countryOfBuildItems.length > 0}
            chart={
              countryOfBuildView === 'all' ? (
                <RankedRows items={allCountryOfBuildItems} />
              ) : (
                <Bars
                  ref={countryOfBuildChartRef}
                  data={countryOfBuildItems}
                  total={totalVessels}
                />
              )
            }
            {...makeExporters(
              countryOfBuildChartRef,
              'country-of-build',
              countryOfBuildView === 'all'
                ? allCountryOfBuildItems
                : countryOfBuildItems,
            )}
          />
          <ChartsCard
            className={`flex-1`}
            title={`Builder`}
            subHeading={subHeadingFor(builderView, builderTotalCategories)}
            subHeadingAction={
              <SubHeadingToggle
                view={builderView}
                onChange={setBuilderView}
                disabled={builderTotalCategories <= 5}
                count={builderTotalCategories}
              />
            }
            scrollChart={builderView === 'all'}
            isLoading={isLoading}
            hasData={builderItems.length > 0}
            chart={
              builderView === 'all' ? (
                <RankedRows items={allBuilderItems} />
              ) : (
                <Bars
                  ref={builderChartRef}
                  data={builderItems}
                  total={totalVessels}
                />
              )
            }
            {...makeExporters(
              builderChartRef,
              'builder',
              builderView === 'all' ? allBuilderItems : builderItems,
            )}
          />
          <ChartsCard
            className={`flex-1`}
            title={`Age profile`}
            isLoading={isLoading}
            hasData={ageProfileItems.length > 0}
            chart={
              <Bars
                ref={ageProfileChartRef}
                data={ageProfileItems}
                total={totalVessels}
                horizontal
              />
            }
            {...makeExporters(
              ageProfileChartRef,
              'age-profile',
              ageProfileItems,
            )}
          />
        </div>
      </div>
      <div className={`flex flex-col gap-2`}>
        <p className={`text-sm font-semibold text-gray-500`}>
          Size and dimensions
        </p>
        <div className={`flex gap-2`}>
          <ChartsCard
            className={`flex-1`}
            title={`Size`}
            subHeading={`By ${sizeTab}`}
            isLoading={isLoading}
            hasData={sizeItems.length > 0}
            showCoverage={sizeTab === 'DWT'}
            coverage={{
              known:
                composition?.data.size_and_dimensions.size.deadweight_tonnage
                  .vessels_with_data ?? 0,
              total: composition?.data.summary.vessels.filtered_count ?? 0,
              complete:
                (composition?.data.summary.total_dwt.vessels_with_data ?? 0) ===
                (composition?.fleet_information.vessel_count ?? 0),
            }}
            tabGroup={
              <TabGroup
                tabs={SIZETAB}
                active={sizeTab}
                onChange={setSizeTab}
                size={`xs`}
                className={`bg-white dark:bg-gray-800`}
              />
            }
            chart={
              <Bars
                ref={sizeChartRef}
                horizontal
                data={sizeItems}
                total={totalVessels}
              />
            }
            {...makeExporters(sizeChartRef, `size-${sizeTab}`, sizeItems)}
            section={`DWT`}
          />
          <ChartsCard
            className={`flex-1`}
            title={`Dimensions`}
            subHeading={`By ${dimensionsTab}`}
            isLoading={isLoading}
            hasData={dimensionsItems.length > 0}
            showCoverage
            coverage={{
              known: dimensionsVesselsWithData,
              total: composition?.data.summary.vessels.filtered_count ?? 0,
              complete:
                dimensionsVesselsWithData ===
                (composition?.fleet_information.vessel_count ?? 0),
            }}
            tabGroup={
              <TabGroup
                tabs={DIMENSIONSTAB}
                active={dimensionsTab}
                onChange={setDimensionsTab}
                size={`xs`}
                className={`bg-white dark:bg-gray-800`}
              />
            }
            chart={
              <Bars
                ref={dimensionsChartRef}
                horizontal
                data={dimensionsItems}
                total={totalVessels}
              />
            }
            {...makeExporters(
              dimensionsChartRef,
              `dimensions-${dimensionsTab}`,
              dimensionsItems,
            )}
            section={dimensionsTab}
          />
        </div>
      </div>
    </div>
  );
}
