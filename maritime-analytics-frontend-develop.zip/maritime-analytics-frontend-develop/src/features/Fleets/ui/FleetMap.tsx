import { useMemo, useRef, useState } from 'react';
import 'mapbox-gl/dist/mapbox-gl.css';
import FleetMapLegend from '../components/FleetMapLegend';
import { useFleetMapInit } from '../hooks/useFleetMapInit';
import { useFleetVesselMarkers } from '../hooks/useFleetVesselMarkers';
import { VesselData } from '../types/fleetTypes';
import { MAPBOX_TOKEN } from '@/app/config/config';
import { useTheme } from '@/app/context/ThemeProvider';
import CustomZoomControl from '@/shared/components/CustomZoomControl';
import MapboxMissingToken from '@/shared/components/MapboxMissingToken';
import MapCoordinates from '@/shared/components/MapCoordinates';
import NauticalChartsControl from '@/shared/components/NauticalChartsControl';
import { MAP_STYLES } from '@/shared/constants/overviewMapConstants';
import { useMapCoordinates } from '@/shared/hooks/useMapCoordinates';
import { useMapStyleControl } from '@/shared/hooks/useMapStyleControl';

interface FleetMapProps {
  vessels: VesselData[];
  onVesselClick?: (vessel: VesselData) => void;
}

function buildVisibilityMap(values: string[]): Record<string, boolean> {
  return values.reduce<Record<string, boolean>>((acc, value) => {
    acc[value] = true;
    return acc;
  }, {});
}

export function FleetMap({ vessels, onVesselClick }: FleetMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  const { mapRef, mapReady, currentStyleRef } = useFleetMapInit(
    containerRef,
    isDarkMode ? MAP_STYLES.dark : MAP_STYLES.light,
  );
  const { selectedStyle, gridEnabled, setSelectedStyle, setGridEnabled } =
    useMapStyleControl(mapRef, mapReady, isDarkMode, currentStyleRef);
  const coordinates = useMapCoordinates(mapRef, mapReady);

  const [activeTab, setActiveTab] = useState<'Flag' | 'Type'>('Type');
  const [visibleTypes, setVisibleTypes] = useState<Record<string, boolean>>({});
  const [visibleFlags, setVisibleFlags] = useState<Record<string, boolean>>({});

  const types = useMemo(
    () =>
      Array.from(
        new Set(vessels.map((v) => v.vessel_information.vessel_type)),
      ).filter((type): type is string => Boolean(type)),
    [vessels],
  );
  const flags = useMemo(
    () =>
      Array.from(
        new Set(vessels.map((v) => v.vessel_information.flag_code)),
      ).filter(Boolean),
    [vessels],
  );

  const resolvedVisibleTypes = useMemo(
    () => ({ ...buildVisibilityMap(types), ...visibleTypes }),
    [types, visibleTypes],
  );
  const resolvedVisibleFlags = useMemo(
    () => ({ ...buildVisibilityMap(flags), ...visibleFlags }),
    [flags, visibleFlags],
  );

  const filteredVessels = useMemo(
    () =>
      vessels.filter(
        (v) =>
          resolvedVisibleTypes[v.vessel_information.vessel_type ?? ''] !==
            false &&
          resolvedVisibleFlags[v.vessel_information.flag_code] !== false,
      ),
    [vessels, resolvedVisibleTypes, resolvedVisibleFlags],
  );

  useFleetVesselMarkers(
    mapRef,
    mapReady,
    filteredVessels,
    onVesselClick ?? (() => {}),
  );

  return (
    <div className={`relative h-full w-full overflow-hidden`}>
      <div ref={containerRef} className="h-full w-full" />
      <div className="absolute left-4 top-2 z-20 flex items-start gap-2">
        {mapReady && (
          <FleetMapLegend
            activeTab={activeTab}
            onTabChange={setActiveTab}
            types={types}
            flags={flags}
            visibleTypes={resolvedVisibleTypes}
            visibleFlags={resolvedVisibleFlags}
            onToggleType={(type, checked) =>
              setVisibleTypes((prev) => ({ ...prev, [type]: checked }))
            }
            onToggleFlag={(flag, checked) =>
              setVisibleFlags((prev) => ({ ...prev, [flag]: checked }))
            }
          />
        )}
      </div>

      {mapReady && (
        <NauticalChartsControl
          selectedStyle={selectedStyle}
          gridEnabled={gridEnabled}
          onStyleChange={setSelectedStyle}
          onGridChange={setGridEnabled}
          position="top-right"
        />
      )}

      {mapReady && mapRef.current && (
        <CustomZoomControl map={mapRef.current} position="bottom-right" />
      )}

      {mapReady && <MapCoordinates coordinates={coordinates} />}

      {!MAPBOX_TOKEN && <MapboxMissingToken />}
    </div>
  );
}
