import { useFleetEvents } from '../hooks/useFleetEvents';
import { CreateFleetEventsColDefs } from '../utils/FleetEventsColDefs';
import FleetEventSlideOutPanel from './FleetEventSlideOutPanel';
import { FleetEventsPanel } from './FleetEventsPanel';

export interface FleetEventsTabProps {
  fleetId: string;
  fleetName: string;
  hasMTIScore?: boolean;
  hasPtracAccess?: boolean;
}

const fleetEventsTabs = [
  {
    label: 'Area Arrival',
    value: 'PORT_AREA_ARRIVAL',
    groupings: 'Port Events',
  },
  { label: 'Arrival', value: 'PORT_ARRIVAL', groupings: 'Port Events' },
  { label: 'Departure', value: 'PORT_DEPARTURE', groupings: 'Port Events' },
  {
    label: 'Area Departure',
    value: 'PORT_AREA_DEPARTURE',
    groupings: 'Port Events',
  },
  { label: 'Zone Entry', value: 'ZONE_ENTRY', groupings: 'Zone Events' },
  { label: 'Zone Exit', value: 'ZONE_EXIT', groupings: 'Zone Events' },
  { label: 'AIS Gap', value: 'AIS_GAP', groupings: 'Other Events' },
  { label: 'STS Pairing', value: 'STS_PAIRING', groupings: 'Other Events' },
  {
    label: 'Positional Discrepancy',
    value: 'POSITIONAL_DISCREPANCY',
    groupings: 'Other Events',
  },
  {
    label: 'Port State Control',
    value: 'PORT_STATE_CONTROL',
    groupings: 'Other Events',
  },
];

export default function FleetEventsTab({
  fleetId,
  fleetName,
  hasMTIScore,
  hasPtracAccess,
}: FleetEventsTabProps) {
  const {
    refresh,
    setRefresh,
    selected,
    onToggle,
    rows,
    lastUpdated,
    isLoading,
    onSelectAll,
    columnStorageKey,
    selectedRow,
    setSelectedRow,
    vessels,
  } = useFleetEvents(fleetId, fleetEventsTabs);
  return (
    <div className="h-[calc(100dvh-135px)] px-6 pt-4">
      <FleetEventsPanel
        fleetEventsTabs={fleetEventsTabs}
        fleetId={fleetId}
        fleetName={fleetName}
        storageKey={columnStorageKey}
        refresh={refresh}
        setRefresh={setRefresh}
        selected={selected}
        onToggle={onToggle}
        onSelectAll={onSelectAll}
        rows={rows}
        lastUpdated={lastUpdated}
        isLoading={isLoading}
        buildColumns={CreateFleetEventsColDefs}
        onRowClick={(row) => setSelectedRow(row)}
        renderExtras={
          <FleetEventSlideOutPanel
            currentRow={selectedRow}
            setSelectedRow={setSelectedRow}
            hasMTIScore={hasMTIScore}
            hasPtracAccess={hasPtracAccess}
            vessels={vessels}
          />
        }
      />
    </div>
  );
}
