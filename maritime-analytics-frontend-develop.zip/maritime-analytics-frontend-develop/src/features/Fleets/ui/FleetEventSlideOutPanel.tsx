import { Spinner } from 'flowbite-react';
import { FaArrowRight } from 'react-icons/fa';
import { useNavigate } from 'react-router';
import EventsSlideOutDetails from '../components/EventsSlideOutDetails';
import EventsSlideOutHeader from '../components/EventsSlideOutHeader';
import LocationSection from '../components/LocationSection';
import LocationSlideOutBody from '../components/LocationSlideOutBody';
import LocationSlideOutHeader from '../components/LocationSlideOutHeader';
import SlideOutPanelBody from '../components/SlideOutPanelBody';
import SlideOutPanelHeader from '../components/SlideOutPanelHeader';
import VesselSection from '../components/VesselSection';
import { useFleetEventSlideOut } from '../hooks/useFleetEventsSlideOut';
import { VesselData } from '../types/fleetTypes';
import { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';
import { useEscapeClose } from '@/shared/hooks/useEscapeClose';
import { useOnClickOutside } from '@/shared/hooks/useOnClickOutside';
import SideSlideOutPanel from '@/shared/ui/SideSlideOutPanel';
import { getFleetEventsLabel } from '@/shared/utils/formatUtils';
import { isValidCoordinate } from '@/shared/utils/overviewMapUtils';

function hasEventMapCoordinates(row?: FlatFleetEventsResponse): boolean {
  if (!row) return false;

  switch (row.eventType) {
    case 'AIS_GAP':
      return (
        isValidCoordinate(row.gapStartedLatitude, row.gapStartedLongitude) ||
        isValidCoordinate(row.gapEndedLatitude, row.gapEndedLongitude)
      );
    case 'STS_PAIRING':
      return isValidCoordinate(row.stsLatitude, row.stsLongitude);
    case 'POSITIONAL_DISCREPANCY':
      return (
        isValidCoordinate(row.startedLatitude, row.startedLongitude) ||
        isValidCoordinate(row.stoppedLatitude, row.stoppedLongitude)
      );
    default:
      return false;
  }
}

interface FleetEventSlideOutPanelProps {
  currentRow?: FlatFleetEventsResponse;
  setSelectedRow?: (row?: FlatFleetEventsResponse) => void;
  hasMTIScore?: boolean;
  hasPtracAccess?: boolean;
  vessels: VesselData[];
}
export default function FleetEventSlideOutPanel({
  currentRow,
  setSelectedRow,
  hasMTIScore,
  hasPtracAccess,
  vessels,
}: FleetEventSlideOutPanelProps) {
  const navigate = useNavigate();
  const {
    handleClose,
    slideOutModalRef,
    isOpen,
    viewVessel,
    viewPairedVessel,
    viewLocation,
    vessel,
    pairedVessel,
    handleBackClick,
    location,
    locationEvents,
    setViewLocation,
    setViewVessel,
    setViewPairedVessel,
    zoneBoundary,
    vesselInPortOrZone,
    isLoading,
  } = useFleetEventSlideOut(currentRow, setSelectedRow, vessels);
  const shouldShowLocationSection =
    currentRow?.eventType !== 'PORT_STATE_CONTROL' &&
    (location !== undefined || hasEventMapCoordinates(currentRow));
  useOnClickOutside(slideOutModalRef, handleClose);
  useEscapeClose(handleClose);
  return (
    <div>
      <SideSlideOutPanel
        isOpen={isOpen}
        onClose={handleClose}
        modalRef={slideOutModalRef}
        title={
          viewVessel && vessel ? (
            <SlideOutPanelHeader
              showBackButton={true}
              onBack={handleBackClick}
              onClose={handleClose}
              vesselName={vessel?.vessel_information.name ?? ''}
              vesselFlagCode={vessel?.vessel_information.flag_code ?? ''}
              vesselImo={vessel?.vessel_information.imo ?? ''}
            />
          ) : viewPairedVessel && pairedVessel ? (
            <SlideOutPanelHeader
              showBackButton={true}
              onBack={handleBackClick}
              onClose={handleClose}
              vesselName={pairedVessel?.vessel_information.name ?? ''}
              vesselFlagCode={pairedVessel?.vessel_information.flag_code ?? ''}
              vesselImo={pairedVessel?.vessel_information.imo ?? ''}
            />
          ) : viewLocation && location ? (
            <LocationSlideOutHeader
              locationInformation={location!}
              showBackButton={true}
              onBack={handleBackClick}
              onClose={handleClose}
            />
          ) : (
            <EventsSlideOutHeader
              onClose={handleClose}
              eventType={getFleetEventsLabel(currentRow?.eventType)}
            />
          )
        }
        children={
          <div className="h-full">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <Spinner size={`lg`} light color={`psgPrimary`} />
              </div>
            ) : viewLocation && location ? (
              <LocationSlideOutBody
                location={location}
                vesselsInPortOrZone={vesselInPortOrZone}
                locationEvents={locationEvents}
              />
            ) : viewPairedVessel && pairedVessel ? (
              <SlideOutPanelBody
                vesselData={pairedVessel}
                hasMTIScore={hasMTIScore}
                hasPtracAccess={hasPtracAccess}
              />
            ) : viewVessel && vessel ? (
              <SlideOutPanelBody
                vesselData={vessel}
                hasMTIScore={hasMTIScore}
                hasPtracAccess={hasPtracAccess}
              />
            ) : (
              <>
                {vessel &&
                  currentRow?.eventType &&
                  VesselSection({
                    eventType: currentRow.eventType,
                    primaryVessel: vessel,
                    setViewPrimaryVessel: setViewVessel,
                    pairedVessel: pairedVessel,
                    setViewPairedVessel: setViewPairedVessel,
                  })}
                {shouldShowLocationSection &&
                  currentRow?.eventType &&
                  LocationSection({
                    eventType: currentRow.eventType,
                    location,
                    setViewLocation: setViewLocation,
                    boundaryGeometry: zoneBoundary,
                    event: currentRow,
                    vessel,
                  })}
                {currentRow && EventsSlideOutDetails({ event: currentRow })}
              </>
            )}
          </div>
        }
        extraActions={
          ((viewVessel && vessel) ||
            (viewLocation && location) ||
            (viewPairedVessel && pairedVessel)) && (
            <div className="mt-auto border-gray-200 dark:border-gray-700">
              <button
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white py-2 text-sm font-medium text-gray-900 transition-colors hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700 dark:disabled:hover:bg-gray-800"
                onClick={() => {
                  const target =
                    viewVessel && vessel
                      ? `/analytics/vessel/${vessel.vessel_information.imo}`
                      : viewLocation && location
                        ? location.type === 'Ports'
                          ? `/analytics/port/${location.id}`
                          : `/analytics/zone/${location.id}`
                        : viewPairedVessel && pairedVessel
                          ? `/analytics/vessel/${pairedVessel.vessel_information.imo}`
                          : undefined;

                  if (target) navigate(target);
                }}
              >
                Full Details
                <FaArrowRight className={`text-gray-500`} />
              </button>
            </div>
          )
        }
      />
    </div>
  );
}
