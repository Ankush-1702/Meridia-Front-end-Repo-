import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { FleetMap } from '../FleetMap';
import { VesselData } from '@/features/Fleets/types/fleetTypes';

const { mockUseFleetVesselMarkers, mockFleetMapLegend, tokenState } =
  vi.hoisted(() => ({
    mockUseFleetVesselMarkers: vi.fn(),
    mockFleetMapLegend: vi.fn(),
    tokenState: { current: 'test-token' },
  }));

let mockMapReady = false;
const mockMapRef = { current: {} };

vi.mock('@/features/Fleets/hooks/useFleetMapInit', () => ({
  useFleetMapInit: () => ({
    mapRef: mockMapRef,
    mapReady: mockMapReady,
    currentStyleRef: { current: 'simple' },
  }),
}));

vi.mock('@/features/Fleets/hooks/useFleetVesselMarkers', () => ({
  useFleetVesselMarkers: (...args: unknown[]) =>
    mockUseFleetVesselMarkers(...args),
}));

vi.mock('@/features/Fleets/components/FleetMapLegend', () => ({
  default: (props: unknown) => {
    mockFleetMapLegend(props);
    return <div>FleetMapLegend</div>;
  },
}));

vi.mock('@/shared/hooks/useMapStyleControl', () => ({
  useMapStyleControl: () => ({
    selectedStyle: 'simple',
    gridEnabled: false,
    setSelectedStyle: vi.fn(),
    setGridEnabled: vi.fn(),
  }),
}));

vi.mock('@/shared/hooks/useMapCoordinates', () => ({
  useMapCoordinates: () => ({ lng: 0, lat: 0 }),
}));

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light' }),
}));

vi.mock('@/shared/components/CustomZoomControl', () => ({
  default: () => <div>CustomZoomControl</div>,
}));

vi.mock('@/shared/components/MapboxMissingToken', () => ({
  default: () => <div>MapboxMissingToken</div>,
}));

vi.mock('@/shared/components/MapCoordinates', () => ({
  default: () => <div>MapCoordinates</div>,
}));

vi.mock('@/shared/components/NauticalChartsControl', () => ({
  default: () => <div>NauticalChartsControl</div>,
}));

vi.mock('@/app/config/config', () => ({
  get MAPBOX_TOKEN() {
    return tokenState.current;
  },
}));

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    ...overrides,
  };
}

describe('FleetMap', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockMapReady = false;
    tokenState.current = 'test-token';
    window.matchMedia = vi.fn().mockReturnValue({ matches: false });
  });

  it('does not render the legend, controls, or coordinates before the map is ready', () => {
    render(<FleetMap vessels={[]} />);

    expect(screen.queryByText('FleetMapLegend')).not.toBeInTheDocument();
    expect(screen.queryByText('NauticalChartsControl')).not.toBeInTheDocument();
    expect(screen.queryByText('CustomZoomControl')).not.toBeInTheDocument();
    expect(screen.queryByText('MapCoordinates')).not.toBeInTheDocument();
  });

  it('renders the legend, controls, and coordinates once the map is ready', () => {
    mockMapReady = true;

    render(<FleetMap vessels={[]} />);

    expect(screen.getByText('FleetMapLegend')).toBeInTheDocument();
    expect(screen.getByText('NauticalChartsControl')).toBeInTheDocument();
    expect(screen.getByText('CustomZoomControl')).toBeInTheDocument();
    expect(screen.getByText('MapCoordinates')).toBeInTheDocument();
  });

  it('shows the missing-token message when MAPBOX_TOKEN is empty', () => {
    tokenState.current = '';

    render(<FleetMap vessels={[]} />);

    expect(screen.getByText('MapboxMissingToken')).toBeInTheDocument();
  });

  it('derives unique vessel types and flags for the legend', () => {
    mockMapReady = true;
    const vessels = [
      makeVessel({
        vessel_information: {
          ...makeVessel().vessel_information,
          imo: '111',
          vessel_type: 'Bulk carrier',
          flag_code: 'NOR',
        },
      }),
      makeVessel({
        vessel_information: {
          ...makeVessel().vessel_information,
          imo: '222',
          vessel_type: 'Bulk carrier',
          flag_code: 'PAN',
        },
      }),
    ];

    render(<FleetMap vessels={vessels} />);

    expect(mockFleetMapLegend).toHaveBeenCalledWith(
      expect.objectContaining({
        types: ['Bulk carrier'],
        flags: ['NOR', 'PAN'],
      }),
    );
  });

  it('passes only vessels with visible type/flag to useFleetVesselMarkers', () => {
    mockMapReady = true;
    const visible = makeVessel({
      vessel_information: {
        ...makeVessel().vessel_information,
        imo: '111',
        vessel_type: 'Bulk carrier',
      },
    });
    const hidden = makeVessel({
      vessel_information: {
        ...makeVessel().vessel_information,
        imo: '222',
        vessel_type: 'Oil Tanker',
      },
    });

    render(<FleetMap vessels={[visible, hidden]} />);

    const legendProps = mockFleetMapLegend.mock.calls[0][0];
    legendProps.onToggleType('Oil Tanker', false);
  });

  it('passes the vessel list and a click handler to useFleetVesselMarkers', () => {
    const onVesselClick = vi.fn();
    const vessels = [makeVessel()];

    render(<FleetMap vessels={vessels} onVesselClick={onVesselClick} />);

    expect(mockUseFleetVesselMarkers).toHaveBeenCalledWith(
      mockMapRef,
      false,
      vessels,
      onVesselClick,
    );
  });

  it('provides a no-op click handler when onVesselClick is not passed', () => {
    render(<FleetMap vessels={[]} />);

    const [, , , handler] = mockUseFleetVesselMarkers.mock.calls[0];
    expect(() => (handler as () => void)()).not.toThrow();
  });
});
