import { fireEvent, render, screen } from '@testing-library/react';
import { ColDef } from 'ag-grid-community';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FleetListView from '../FleetListView';

const { mockPoleStarEntityGrid } = vi.hoisted(() => ({
  mockPoleStarEntityGrid: vi.fn(),
}));

vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: (props: unknown) => {
    mockPoleStarEntityGrid(props);
    return <div data-testid="pole-star-grid">Grid</div>;
  },
}));

vi.mock('@/features/Fleets/hooks/useFleetExports', () => ({
  useFleetExports: () => ({
    handleExportClick: vi.fn(),
    isPolling: false,
  }),
}));

interface Row {
  name: string;
  vessel_type: string;
}

function buildColumns(): ColDef<Row>[] {
  return [{ field: 'name' }, { field: 'vessel_type' }];
}

const rows: Row[] = [
  { name: 'Test Vessel', vessel_type: 'Bulk carrier' },
  { name: 'Other Vessel', vessel_type: 'Oil Tanker' },
];

describe('FleetListView', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders the search filter and grid', () => {
    render(<FleetListView rows={rows} buildColumns={buildColumns} />);

    expect(
      screen.getByPlaceholderText('Search vessels...'),
    ).toBeInTheDocument();
    expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
  });

  it('passes all rows through to the grid when no query is set', () => {
    render(<FleetListView rows={rows} buildColumns={buildColumns} />);

    expect(mockPoleStarEntityGrid).toHaveBeenCalledWith(
      expect.objectContaining({ rows }),
    );
  });

  it('filters rows by the search query, matching underscores as spaces', () => {
    render(<FleetListView rows={rows} buildColumns={buildColumns} />);

    fireEvent.change(screen.getByPlaceholderText('Search vessels...'), {
      target: { value: 'bulk carrier' },
    });

    expect(mockPoleStarEntityGrid).toHaveBeenLastCalledWith(
      expect.objectContaining({ rows: [rows[0]] }),
    );
  });

  it('shows a loading spinner when isLoading is true', () => {
    const { container } = render(
      <FleetListView rows={rows} buildColumns={buildColumns} isLoading />,
    );

    expect(container.querySelector('[role="status"]')).toBeInTheDocument();
  });

  it('passes the built columns to the grid', () => {
    render(<FleetListView rows={rows} buildColumns={buildColumns} />);

    expect(mockPoleStarEntityGrid).toHaveBeenCalledWith(
      expect.objectContaining({ columns: buildColumns() }),
    );
  });

  it('invokes onRowClick with the clicked row data', () => {
    const onRowClick = vi.fn();
    render(
      <FleetListView
        rows={rows}
        buildColumns={buildColumns}
        onRowClick={onRowClick}
      />,
    );

    const { onRowClick: gridOnRowClick } =
      mockPoleStarEntityGrid.mock.calls[0][0];
    gridOnRowClick({ data: rows[0] });

    expect(onRowClick).toHaveBeenCalledWith(rows[0]);
  });
});
