import { render } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { FleetEventsPanel } from '../FleetEventsPanel';

const { panelProps } = vi.hoisted(() => ({
  panelProps: { current: undefined as unknown },
}));
vi.mock('@/shared/ui/NewEventsPanel', () => ({
  default: (props: unknown) => {
    panelProps.current = props;
    return <div>New Events Panel</div>;
  },
}));

describe('FleetEventsPanel', () => {
  it('adapts fleet event properties to the shared event panel contract', () => {
    const rows = [{ eventType: 'AIS_GAP' }];
    const buildColumns = vi.fn(() => []);
    const onRowClick = vi.fn();
    const extras = <div>Slide-out</div>;
    const { getByText } = render(
      <FleetEventsPanel
        fleetId="fleet-1"
        fleetName="Fleet One"
        fleetEventsTabs={[{ label: 'AIS gap', value: 'AIS_GAP' }]}
        selected={{ AIS_GAP: true }}
        onToggle={vi.fn()}
        onSelectAll={vi.fn()}
        rows={rows}
        buildColumns={buildColumns}
        storageKey="fleet-events"
        lastUpdated={new Date('2026-01-01T00:00:00Z')}
        isLoading
        refresh
        setRefresh={vi.fn()}
        onRowClick={onRowClick}
        renderExtras={extras}
      />,
    );

    expect(getByText('New Events Panel')).toBeInTheDocument();
    expect(panelProps.current).toMatchObject({
      eventsTabs: [{ label: 'AIS gap', value: 'AIS_GAP' }],
      entityId: 'fleet-1',
      entityType: 'fleet',
      columnReset: true,
      rows,
      storageKey: 'fleet-events',
      isLoading: true,
      refresh: true,
      onRowClick,
      renderExtras: extras,
    });
  });
});
