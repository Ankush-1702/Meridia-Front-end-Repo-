import { fireEvent, render, screen } from '@testing-library/react';
import type { ColDef } from 'ag-grid-community';
import { describe, expect, it, vi } from 'vitest';
import FleetListView from '../FleetListView';

const { gridProps, exportState } = vi.hoisted(() => ({
  gridProps: { current: undefined as unknown },
  exportState: { loading: false, click: vi.fn() },
}));
vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: (props: {
    rows?: unknown[];
    noRowsOverlay: () => React.ReactNode;
  }) => {
    gridProps.current = props;
    return (
      <div data-testid="grid">
        {!props.rows?.length && props.noRowsOverlay()}
      </div>
    );
  },
}));
vi.mock('@/features/Fleets/hooks/useFleetExports', () => ({
  useFleetExports: () => ({
    handleExportClick: exportState.click,
    isPolling: exportState.loading,
  }),
}));
vi.mock('@/shared/components/ChartsDownloadDropDown', () => ({
  default: (props: { loading: boolean; hasData: boolean }) => (
    <div data-testid="export-state">{`${props.loading}:${props.hasData}`}</div>
  ),
}));

interface Row {
  name: string;
  nested: { destination: string };
  tags: string[];
}
const rows: Row[] = [
  {
    name: 'Blue Star',
    nested: { destination: 'Port_Authority' },
    tags: ['Cargo'],
  },
  { name: 'Red Wave', nested: { destination: 'Open Sea' }, tags: ['Tanker'] },
];
const buildColumns = (): ColDef<Row>[] => [{ field: 'name' }];

describe('FleetListView additional behavior', () => {
  it('searches recursively through nested properties and arrays', () => {
    render(<FleetListView rows={rows} buildColumns={buildColumns} />);
    fireEvent.change(screen.getByPlaceholderText('Search vessels...'), {
      target: { value: 'port authority' },
    });
    expect(gridProps.current).toMatchObject({ rows: [rows[0]] });

    fireEvent.change(screen.getByPlaceholderText('Search vessels...'), {
      target: { value: 'tanker' },
    });
    expect(gridProps.current).toMatchObject({ rows: [rows[1]] });
  });

  it('shows singular and plural counts, filters applied text, and reset action on zero results', () => {
    const reset = vi.fn();
    const { rerender } = render(
      <FleetListView
        rows={[rows[0]]}
        totalVesselCount={1}
        filtersAppliedCount={1}
        hasActiveFilters
        onResetFilters={reset}
      />,
    );
    expect(
      screen.getByText('Showing 1 of 1 vessel · 1 filter applied'),
    ).toBeInTheDocument();

    fireEvent.change(screen.getByPlaceholderText('Search vessels...'), {
      target: { value: 'missing' },
    });
    expect(
      screen.getByText('Showing 0 of 1 vessel · 1 filter applied'),
    ).toBeInTheDocument();
    expect(
      screen.getByText('No vessels match these filters.'),
    ).toBeInTheDocument();
    fireEvent.click(
      screen.getAllByRole('button', { name: 'Reset filters' })[0],
    );
    expect(reset).toHaveBeenCalledOnce();

    rerender(
      <FleetListView
        rows={rows}
        totalVesselCount={2}
        filtersAppliedCount={2}
      />,
    );
    fireEvent.change(screen.getByPlaceholderText('Search vessels...'), {
      target: { value: '' },
    });
    expect(
      screen.getByText('Showing 2 of 2 vessels · 2 filters applied'),
    ).toBeInTheDocument();
  });

  it('shows a plain empty state without active filters and reflects export loading and data', () => {
    exportState.loading = true;
    const { rerender } = render(<FleetListView rows={[]} isLoading={false} />);
    expect(screen.getByText('No data available')).toBeInTheDocument();
    expect(screen.getByTestId('export-state')).toHaveTextContent('true:false');

    exportState.loading = false;
    rerender(<FleetListView rows={rows} isLoading />);
    expect(screen.getByTestId('export-state')).toHaveTextContent('true:true');
  });
});
