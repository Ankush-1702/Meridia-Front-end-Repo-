import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import FleetPreview, { CAP_WARN_AT } from '../FleetPreview';
import { VesselSearch } from '@/features/library/types/LibraryTypes';

function makeVessel(overrides: Partial<VesselSearch> = {}): VesselSearch {
  return {
    imo: '1234567',
    name: 'Test Vessel',
    flag: 'Norway',
    flag_code: 'NOR',
    vessel_type: 'Cargo',
    ...overrides,
  } as VesselSearch;
}

const noopHandlers = {
  onDismissUnresolved: vi.fn(),
  onDismissAllUnresolved: vi.fn(),
};

describe('FleetPreview', () => {
  it('exposes the near-cap warning threshold', () => {
    expect(CAP_WARN_AT).toBe(0.9);
  });

  it('shows an empty state for a static fleet with no vessels', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[]}
        headline={0}
        cap={100}
      />,
    );

    expect(screen.getByText('No vessels added yet')).toBeInTheDocument();
  });

  it('shows an empty state for a dynamic fleet with no matches', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="dynamic"
        matched={[]}
        headline={0}
        cap={100}
      />,
    );

    expect(
      screen.getByText('No vessels match — add a rule to start'),
    ).toBeInTheDocument();
  });

  it('renders each matched vessel', () => {
    const vessels = [makeVessel({ imo: '111' }), makeVessel({ imo: '222' })];
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={vessels}
        headline={2}
        cap={100}
      />,
    );

    expect(screen.getAllByText('Test Vessel')).toHaveLength(2);
  });

  it('shows the headline/cap counts', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[]}
        headline={50}
        cap={100}
      />,
    );

    expect(screen.getByText('50 / 100')).toBeInTheDocument();
  });

  it('shows an over-cap warning for static fleets with removal guidance', () => {
    const vessels = Array.from({ length: 5 }, (_, i) =>
      makeVessel({ imo: String(i) }),
    );
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={vessels}
        headline={105}
        cap={100}
      />,
    );

    expect(
      screen.getByText(/This fleet is over your 100-vessel limit/),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Remove 5 vessels to save it\./),
    ).toBeInTheDocument();
  });

  it('shows an over-cap warning for dynamic fleets with narrowing guidance', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="dynamic"
        matched={[]}
        headline={105}
        cap={100}
      />,
    );

    expect(
      screen.getByText(/Narrow your rules to bring it under the limit/),
    ).toBeInTheDocument();
  });

  it('does not show the over-cap warning when limitsOn is false', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[]}
        headline={105}
        cap={100}
        limitsOn={false}
      />,
    );

    expect(
      screen.queryByText(/This fleet is over your/),
    ).not.toBeInTheDocument();
  });

  it('shows the at-cap message for dynamic fleets exactly at the limit', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="dynamic"
        matched={[]}
        headline={100}
        cap={100}
      />,
    );

    expect(
      screen.getByText(/At your limit — new matching vessels/),
    ).toBeInTheDocument();
  });

  it('shows "…and N more" when matched exceeds the display cap', () => {
    const vessels = Array.from({ length: 3 }, (_, i) =>
      makeVessel({ imo: String(i) }),
    );
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={vessels}
        headline={10}
        cap={100}
      />,
    );

    expect(screen.getByText(/…and 7 more/)).toBeInTheDocument();
  });

  it('calls onRemove when a vessel remove button is clicked', () => {
    const onRemove = vi.fn();
    const vessel = makeVessel();
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[vessel]}
        headline={1}
        cap={100}
        onRemove={onRemove}
      />,
    );

    fireEvent.click(screen.getByLabelText('Remove Test Vessel'));

    expect(onRemove).toHaveBeenCalledWith(vessel);
  });

  it('calls onClearAll when "Clear fleet" is clicked from the actions menu', () => {
    const onClearAll = vi.fn();
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[makeVessel()]}
        headline={1}
        cap={100}
        onClearAll={onClearAll}
      />,
    );

    fireEvent.click(screen.getByLabelText('Vessel actions'));
    fireEvent.click(screen.getByText('Clear fleet'));

    expect(onClearAll).toHaveBeenCalledTimes(1);
  });

  it('does not show the actions menu when there are no vessels', () => {
    render(
      <FleetPreview
        {...noopHandlers}
        type="static"
        matched={[]}
        headline={0}
        cap={100}
      />,
    );

    expect(screen.queryByLabelText('Vessel actions')).not.toBeInTheDocument();
  });
});
