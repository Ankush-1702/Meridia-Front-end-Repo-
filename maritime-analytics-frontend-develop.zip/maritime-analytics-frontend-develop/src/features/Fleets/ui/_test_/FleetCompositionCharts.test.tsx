import { fireEvent, render, screen, within } from '@testing-library/react';
import { forwardRef, useImperativeHandle } from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FleetCompositionCharts from '../FleetCompositionCharts';
import {
  FleetCompositionItems,
  FleetCompositionResponse,
} from '@/features/Fleets/types/fleetTypes';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';

const { mockBars, mockDonut, mockDownloadImage, mockExportToCSV } = vi.hoisted(
  () => ({
    mockBars: vi.fn(),
    mockDonut: vi.fn(),
    mockDownloadImage: vi.fn(),
    mockExportToCSV: vi.fn(),
  }),
);

vi.mock('../../components/BarChart', () => ({
  default: forwardRef<
    PoleStarChartHandle,
    { data: FleetCompositionItems[]; total: number }
  >((props, ref) => {
    mockBars(props);
    useImperativeHandle(ref, () => ({ downloadImage: mockDownloadImage }));
    return <div>Bars:{props.data.length}</div>;
  }),
}));

vi.mock('../../components/DonutChart', () => ({
  default: forwardRef<
    PoleStarChartHandle,
    { data: FleetCompositionItems[]; total: number }
  >((props, ref) => {
    mockDonut(props);
    useImperativeHandle(ref, () => ({ downloadImage: mockDownloadImage }));
    return <div>Donut:{props.data.length}</div>;
  }),
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({ exportToCSV: mockExportToCSV }),
}));

function makeItem(
  label: string,
  count: number,
  percentage = 50,
): FleetCompositionItems {
  return { label, count, percentage };
}

function makeComposition(
  overrides: Partial<FleetCompositionResponse> = {},
): FleetCompositionResponse {
  return {
    meta: { request_id: 'r1', request_timestamp: '2026-01-01T00:00:00Z' },
    fleet_information: {
      fleet_id: 'fleet-1',
      name: 'North Sea Fleet',
      vessel_count: 10,
    },
    data: {
      summary: {
        vessels: { filtered_count: 8 },
        average_age: { unit: 'years', value: 12 },
        total_dwt: { unit: 't', value: 5000, vessels_with_data: 6 },
        flag_states_count: 3,
      },
      type_and_class: {
        vessel_type: [makeItem('Bulk carrier', 4)],
        vessel_class: [makeItem('Handysize', 4)],
      },
      registration_and_flag: {
        port_of_registry: {
          total_categories: 6,
          items: [
            makeItem('Rotterdam', 3),
            makeItem('Singapore', 2),
            makeItem('Panama', 1),
            makeItem('Oslo', 1),
            makeItem('Piraeus', 1),
            makeItem('Hamburg', 1),
          ],
        },
        vessel_flag: {
          total_categories: 6,
          items: [
            makeItem('Norway', 3),
            makeItem('Panama', 2),
            makeItem('Liberia', 1),
            makeItem('Malta', 1),
            makeItem('Cyprus', 1),
            makeItem('Greece', 1),
          ],
        },
      },
      build_and_origin: {
        country_of_build: {
          total_categories: 3,
          items: [
            makeItem('Japan', 4),
            makeItem('South Korea', 3),
            makeItem('China', 1),
          ],
        },
        builder: {
          total_categories: 2,
          items: [makeItem('Hyundai', 5), makeItem('Samsung', 3)],
        },
        age_profile: [makeItem('0-5', 2), makeItem('6-10', 6)],
      },
      size_and_dimensions: {
        size: {
          deadweight_tonnage: {
            vessels_with_data: 6,
            unit: 't',
            items: [makeItem('0-10000', 4)],
          },
          gross_tonnage: {
            vessels_with_data: 8,
            unit: 't',
            items: [makeItem('0-5000', 8)],
          },
        },
        dimensions: {
          length_overall: {
            unit: 'm',
            vessels_with_data: 5,
            items: [makeItem('100-150', 5)],
          },
          beam: {
            unit: 'm',
            vessels_with_data: 4,
            items: [makeItem('10-20', 4)],
          },
          draught: {
            unit: 'm',
            vessels_with_data: 7,
            items: [makeItem('5-10', 7)],
          },
        },
      },
    },
    ...overrides,
  };
}

const baseProps = {
  composition: makeComposition(),
  isLoading: false,
  activeFlags: [] as string[],
  activeVesselClasses: [] as string[],
  vesselClassGroups: [],
};

describe('FleetCompositionCharts', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders the vessel type donut and vessel class bar chart', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    expect(screen.getByText('Donut:1')).toBeInTheDocument();
    expect(screen.getAllByText(/Bars:/).length).toBeGreaterThan(0);
  });

  it('shows the top 5 flag items by default, capped from a larger set', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    expect(mockBars).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.arrayContaining([
          expect.objectContaining({ label: 'Norway' }),
        ]),
      }),
    );
    const flagCall = mockBars.mock.calls.find((call) =>
      call[0].data.some((d: FleetCompositionItems) => d.label === 'Norway'),
    );
    expect(flagCall?.[0].data).toHaveLength(5);
  });

  it('toggles the flag section to "all" and shows the ranked rows list with all 6 categories', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    const flagCard = screen.getByText('Flag').closest('div')!.parentElement!
      .parentElement!;
    const toggle = within(flagCard).getByText('Show all (6)');
    fireEvent.click(toggle);

    expect(within(flagCard).getByText('Show top 5')).toBeInTheDocument();
    // All 6 flag labels should now be visible via RankedRows.
    expect(screen.getByText('Greece')).toBeInTheDocument();
  });

  it('disables the flag "Show all" toggle when there are 5 or fewer categories', () => {
    const composition = makeComposition({
      data: {
        ...makeComposition().data,
        registration_and_flag: {
          port_of_registry: { total_categories: 0, items: [] },
          vessel_flag: {
            total_categories: 3,
            items: [
              makeItem('Norway', 3),
              makeItem('Panama', 2),
              makeItem('Malta', 1),
            ],
          },
        },
      },
    });
    render(<FleetCompositionCharts {...baseProps} composition={composition} />);

    const flagCard = screen.getByText('Flag').closest('div')!.parentElement!
      .parentElement!;
    const flagToggle = within(flagCard).getByText('Show all (3)');
    expect(flagToggle).toBeDisabled();
  });

  it('toggles the size tab between GT and DWT', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    // Default tab is GT.
    expect(screen.getByText('By GT')).toBeInTheDocument();
    expect(
      mockBars.mock.calls.some((call) =>
        call[0].data.some((d: FleetCompositionItems) => d.label === '0-5000'),
      ),
    ).toBe(true);

    fireEvent.click(screen.getByText('DWT'));

    expect(screen.getByText(/By DWT/)).toBeInTheDocument();
    expect(
      mockBars.mock.calls.some((call) =>
        call[0].data.some((d: FleetCompositionItems) => d.label === '0-10000'),
      ),
    ).toBe(true);
  });

  it('toggles the dimensions tab between LOA, Beam and Draught', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    expect(screen.getByText(/By Draught/)).toBeInTheDocument();

    fireEvent.click(screen.getByText('LOA'));

    expect(screen.getByText(/By LOA/)).toBeInTheDocument();
    expect(
      mockBars.mock.calls.some((call) =>
        call[0].data.some((d: FleetCompositionItems) => d.label === '100-150'),
      ),
    ).toBe(true);

    fireEvent.click(screen.getByText('Beam'));

    expect(screen.getByText(/By Beam/)).toBeInTheDocument();
  });

  it('calls exportToCSV with the built CSV when a chart CSV export is triggered', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    // Age profile chart has no toggles, so it's simplest to drive its export
    // via the ChartsCard's real ChartsDownloadDropDown kebab menu.
    const ageCard = screen.getByText('Age profile').closest('div')!
      .parentElement!.parentElement!;
    const kebab = within(ageCard).getByTitle('More options');
    fireEvent.click(kebab);

    const csvButton = screen.getByText('Export Data (CSV)');
    fireEvent.click(csvButton);

    expect(mockExportToCSV).toHaveBeenCalledWith(
      expect.stringContaining('age-profile'),
      expect.stringContaining('North-Sea-Fleet-age-profile'),
    );
  });

  it('calls the chart ref downloadImage when a chart image export is triggered', () => {
    render(<FleetCompositionCharts {...baseProps} />);

    const ageCard = screen.getByText('Age profile').closest('div')!
      .parentElement!.parentElement!;
    const kebab = within(ageCard).getByTitle('More options');
    fireEvent.click(kebab);

    const imageButton = screen.getByText('Export Image (PNG)');
    fireEvent.click(imageButton);

    expect(mockDownloadImage).toHaveBeenCalledWith(
      expect.stringContaining('North-Sea-Fleet-age-profile'),
    );
  });

  it('shows the loading state for a chart card', () => {
    render(<FleetCompositionCharts {...baseProps} isLoading />);

    // With isLoading true, chart content is replaced by the loading template
    // and Bars/Donut should not have been asked to render real content areas.
    expect(screen.queryByText('Donut:1')).not.toBeInTheDocument();
  });

  it('shows the empty state for a chart with no data', () => {
    const composition = makeComposition({
      data: {
        ...makeComposition().data,
        type_and_class: { vessel_type: [], vessel_class: [] },
      },
    });
    render(<FleetCompositionCharts {...baseProps} composition={composition} />);

    expect(screen.queryByText(/Donut:/)).not.toBeInTheDocument();
  });

  it('renders with a null composition without crashing, defaulting counts to zero', () => {
    render(<FleetCompositionCharts {...baseProps} composition={null} />);

    expect(screen.getByText('Type and class')).toBeInTheDocument();
    expect(screen.queryByText(/Donut:/)).not.toBeInTheDocument();
  });

  it('marks the active flag and vessel class items as selected in their charts', () => {
    render(
      <FleetCompositionCharts
        {...baseProps}
        activeFlags={['NOR']}
        activeVesselClasses={['Handysize']}
      />,
    );

    const classCall = mockBars.mock.calls.find((call) =>
      call[0].data.some((d: FleetCompositionItems) => d.label === 'Handysize'),
    );
    expect(classCall?.[0].isItemSelected(makeItem('Handysize', 4))).toBe(true);
    expect(classCall?.[0].isItemSelected(makeItem('Other', 1))).toBe(false);
  });
});
