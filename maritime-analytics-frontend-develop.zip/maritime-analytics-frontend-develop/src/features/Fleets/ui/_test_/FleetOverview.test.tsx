import { fireEvent, render, screen } from '@testing-library/react';
import { ColDef } from 'ag-grid-enterprise';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FleetOverview from '../FleetOverview';
import { VesselData } from '@/features/Fleets/types/fleetTypes';

const mockNavigate = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

vi.mock('@/shared/hooks/useOnClickOutside', () => ({
  useOnClickOutside: vi.fn(),
}));

vi.mock('@/shared/hooks/useEscapeClose', () => ({
  useEscapeClose: vi.fn(),
}));

const { mockMultiSelectDropdown } = vi.hoisted(() => ({
  mockMultiSelectDropdown: vi.fn(),
}));

vi.mock('@/shared/components/MultiSelectDropdown', () => ({
  default: (props: {
    title: string;
    onSelectAll: (checked: boolean) => void;
  }) => {
    mockMultiSelectDropdown(props);
    return (
      <button onClick={() => props.onSelectAll(false)}>{props.title}</button>
    );
  },
}));

vi.mock('@/shared/components/TabGroup', () => ({
  default: ({
    tabs,
    active,
    onChange,
  }: {
    tabs: { label: string }[];
    active: string;
    onChange: (tab: string) => void;
  }) => (
    <div>
      {tabs.map((tab) => (
        <button
          key={tab.label}
          aria-pressed={active === tab.label}
          onClick={() => onChange(tab.label)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  ),
}));

vi.mock('../FleetMap', () => ({
  FleetMap: ({ onVesselClick }: { onVesselClick: (v: VesselData) => void }) => (
    <button onClick={() => onVesselClick(makeVessel())}>FleetMap</button>
  ),
}));

vi.mock('../FleetListView', () => ({
  default: ({ onRowClick }: { onRowClick: (row: unknown) => void }) => (
    <button onClick={() => onRowClick(makeVessel())}>FleetListView</button>
  ),
}));

vi.mock('@/shared/ui/SideSlideOutPanel', () => ({
  default: ({
    isOpen,
    title,
    children,
    extraActions,
  }: {
    isOpen: boolean;
    title: React.ReactNode;
    children: React.ReactNode;
    extraActions: React.ReactNode;
  }) =>
    isOpen ? (
      <div>
        <div>{title}</div>
        <div>{children}</div>
        <div>{extraActions}</div>
      </div>
    ) : null,
}));

vi.mock('@/features/Fleets/components/SlideOutPanelHeader', () => ({
  default: ({ vesselName }: { vesselName: string }) => (
    <div>Header:{vesselName}</div>
  ),
}));

vi.mock('@/features/Fleets/components/SlideOutPanelBody', () => ({
  default: () => <div>SlideOutPanelBody</div>,
}));

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: {
      latitude: 52.0,
      longitude: 4.0,
      course: 90,
      heading: 90,
      speed: 12,
      navigational_status: { status: 'Under way', code: 0 },
      draught: 5,
      reported_destination: 'Rotterdam',
      reported_eta: '2026-06-15T10:00:00Z',
      timestamp: '2026-06-10T08:00:00Z',
      source: 'AIS',
    },
    ...overrides,
  };
}

function buildColumns(): ColDef[] {
  return [{ field: 'name' }];
}

const baseProps = {
  view: 'map' as const,
  buildColumns,
  hasMTIScore: false,
  hasPtracAccess: false,
  viewTabs: [{ label: 'map' }, { label: 'list' }],
  setView: vi.fn(),
  flags: ['NOR', 'PAN'],
  vesselTypes: ['Bulk carrier'],
  vesselClasses: ['Handysize'],
  mtiScores: ['LOW'],
  selectedFlags: {},
  selectedVesselTypes: {},
  selectedVesselClasses: {},
  selectedMtiScores: {},
  onFlagToggle: vi.fn(),
  onVesselTypeToggle: vi.fn(),
  onVesselClassToggle: vi.fn(),
  onMtiScoreToggle: vi.fn(),
  onFlagSelectAll: vi.fn(),
  onVesselTypeSelectAll: vi.fn(),
  onVesselClassSelectAll: vi.fn(),
  onMtiScoreSelectAll: vi.fn(),
  onResetFilters: vi.fn(),
  hasActiveFilters: false,
  activeFlagCodes: [] as string[],
  activeVesselTypes: [] as string[],
  activeVesselClasses: [] as string[],
  activeMtiScores: [] as string[],
  filtersAppliedCount: 0,
  totalVesselCount: 0,
  vessels: [] as VesselData[],
  vesselsLoading: false,
  onRefresh: vi.fn(),
  isRefreshing: false,
  timeAgo: '2 minutes',
  currentVessel: undefined as VesselData | undefined,
  setCurrentVessel: vi.fn(),
};

describe('FleetOverview', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders the FleetMap when view is "map"', () => {
    render(<FleetOverview {...baseProps} view="map" />);

    expect(screen.getByText('FleetMap')).toBeInTheDocument();
    expect(screen.queryByText('FleetListView')).not.toBeInTheDocument();
  });

  it('renders the FleetListView when view is "list"', () => {
    render(<FleetOverview {...baseProps} view="list" />);

    expect(screen.getByText('FleetListView')).toBeInTheDocument();
    expect(screen.queryByText('FleetMap')).not.toBeInTheDocument();
  });

  it('shows the "Updated X ago" text', () => {
    render(<FleetOverview {...baseProps} timeAgo="5 minutes" />);

    expect(screen.getByText(/Updated/)).toBeInTheDocument();
    expect(screen.getByText(/5 minutes/)).toBeInTheDocument();
  });

  it('calls onRefresh when Refresh is clicked', () => {
    const onRefresh = vi.fn();
    render(<FleetOverview {...baseProps} onRefresh={onRefresh} />);

    fireEvent.click(screen.getByText('Refresh'));

    expect(onRefresh).toHaveBeenCalledTimes(1);
  });

  it('disables Refresh while isRefreshing is true', () => {
    render(<FleetOverview {...baseProps} isRefreshing />);

    expect(screen.getByText('Refresh')).toBeDisabled();
  });

  it('disables Reset Filters when there are no active filters', () => {
    render(<FleetOverview {...baseProps} hasActiveFilters={false} />);

    expect(screen.getByText('Reset Filters')).toBeDisabled();
  });

  it('enables Reset Filters and calls onResetFilters when active filters exist', () => {
    const onResetFilters = vi.fn();
    render(
      <FleetOverview
        {...baseProps}
        hasActiveFilters
        onResetFilters={onResetFilters}
      />,
    );

    const resetButton = screen.getByText('Reset Filters');
    expect(resetButton).not.toBeDisabled();

    fireEvent.click(resetButton);

    expect(onResetFilters).toHaveBeenCalledTimes(1);
  });

  it('does not render the MTI Score dropdown when hasMTIScore is false', () => {
    render(<FleetOverview {...baseProps} hasMTIScore={false} />);

    expect(screen.queryByText('MTI Score')).not.toBeInTheDocument();
  });

  it('renders the MTI Score dropdown when hasMTIScore is true', () => {
    render(<FleetOverview {...baseProps} hasMTIScore />);

    expect(screen.getByText('MTI Score')).toBeInTheDocument();
  });

  it('calls onFlagSelectAll when the Vessel Flag dropdown select-all fires', () => {
    render(<FleetOverview {...baseProps} />);

    fireEvent.click(screen.getByText('Vessel Flag'));

    expect(baseProps.onFlagSelectAll).toHaveBeenCalledWith(false);
  });

  it('calls setView when a tab is clicked', () => {
    const setView = vi.fn();
    render(<FleetOverview {...baseProps} setView={setView} />);

    fireEvent.click(screen.getByText('list'));

    expect(setView).toHaveBeenCalledWith('list');
  });

  it('opens the slide-out panel with vessel details when a map vessel is clicked', () => {
    const setCurrentVessel = vi.fn();
    render(
      <FleetOverview
        {...baseProps}
        view="map"
        setCurrentVessel={setCurrentVessel}
      />,
    );

    fireEvent.click(screen.getByText('FleetMap'));

    expect(setCurrentVessel).toHaveBeenCalledWith(
      expect.objectContaining({
        vessel_information: expect.objectContaining({ name: 'Test Vessel' }),
      }),
    );
  });

  it('opens the slide-out panel with vessel details when a list row is clicked', () => {
    const setCurrentVessel = vi.fn();
    render(
      <FleetOverview
        {...baseProps}
        view="list"
        setCurrentVessel={setCurrentVessel}
      />,
    );

    fireEvent.click(screen.getByText('FleetListView'));

    expect(setCurrentVessel).toHaveBeenCalled();
  });

  it('does not render the slide-out panel when currentVessel is undefined', () => {
    render(<FleetOverview {...baseProps} currentVessel={undefined} />);

    expect(screen.queryByText('SlideOutPanelBody')).not.toBeInTheDocument();
  });

  it('renders the slide-out panel with the current vessel header and body', () => {
    render(<FleetOverview {...baseProps} currentVessel={makeVessel()} />);

    expect(screen.getByText('Header:Test Vessel')).toBeInTheDocument();
    expect(screen.getByText('SlideOutPanelBody')).toBeInTheDocument();
  });

  it('navigates to the vessel analytics page when Full Details is clicked', () => {
    render(<FleetOverview {...baseProps} currentVessel={makeVessel()} />);

    fireEvent.click(screen.getByText('Full Details'));

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/vessel/1234567');
  });
});
