import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FleetComposition from '../FleetComposition';
import {
  FleetCompositionResponse,
  VesselClassGroup,
  VesselData,
} from '@/features/Fleets/types/fleetTypes';

const mockNavigate = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

vi.mock('@/shared/hooks/useOnClickOutside', () => ({
  useOnClickOutside: vi.fn(),
}));

vi.mock('@/shared/hooks/useEscapeClose', () => ({
  useEscapeClose: vi.fn(),
}));

const mockUseComposition = vi.fn();
vi.mock('@/features/Fleets/hooks/useComposition', () => ({
  useComposition: () => mockUseComposition(),
}));

const { mockMultiSelectDropdown, mockFleetCompositionCharts } = vi.hoisted(
  () => ({
    mockMultiSelectDropdown: vi.fn(),
    mockFleetCompositionCharts: vi.fn(),
  }),
);

vi.mock('@/shared/components/MultiSelectDropdown', () => ({
  default: (props: {
    title: string;
    onSelectAll: (checked: boolean) => void;
  }) => {
    mockMultiSelectDropdown(props);
    return (
      <button onClick={() => props.onSelectAll(false)}>{props.title}</button>
    );
  },
}));

vi.mock('../FleetCompositionCharts', () => ({
  default: (props: unknown) => {
    mockFleetCompositionCharts(props);
    return <div>FleetCompositionCharts</div>;
  },
}));

vi.mock('@/shared/ui/SideSlideOutPanel', () => ({
  default: ({
    isOpen,
    title,
    children,
    extraActions,
  }: {
    isOpen: boolean;
    title: React.ReactNode;
    children: React.ReactNode;
    extraActions: React.ReactNode;
  }) =>
    isOpen ? (
      <div>
        <div>{title}</div>
        <div>{children}</div>
        <div>{extraActions}</div>
      </div>
    ) : null,
}));

vi.mock('@/features/Fleets/components/VesselsSlideOutHeader', () => ({
  default: ({
    onClose,
    totalCount,
    filteredCount,
  }: {
    onClose: () => void;
    totalCount: number;
    filteredCount: number;
  }) => (
    <div>
      VesselsHeader:{filteredCount}/{totalCount}
      <button onClick={onClose}>CloseHeader</button>
    </div>
  ),
}));

vi.mock('@/features/Fleets/components/VesselSlideOutBody', () => ({
  default: ({
    setDrillImo,
    vessels,
  }: {
    setDrillImo: (v: VesselData) => void;
    vessels: VesselData[];
  }) => (
    <button onClick={() => setDrillImo(makeVessel())}>
      VesselSlideOutBody:{vessels.length}
    </button>
  ),
}));

vi.mock('@/features/Fleets/components/SlideOutPanelHeader', () => ({
  default: ({
    vesselName,
    onBack,
    onClose,
  }: {
    vesselName: string;
    onBack?: () => void;
    onClose?: () => void;
  }) => (
    <div>
      Header:{vesselName}
      <button onClick={onBack}>Back</button>
      <button onClick={onClose}>CloseDrilledHeader</button>
    </div>
  ),
}));

vi.mock('@/features/Fleets/components/SlideOutPanelBody', () => ({
  default: () => <div>SlideOutPanelBody</div>,
}));

function makeVessel(overrides: Partial<VesselData> = {}): VesselData {
  return {
    added_at: '2026-01-01T00:00:00Z',
    added_by: 'user-1',
    vessel_information: {
      asset_id: 'a1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NOR',
      imo: '1234567',
      mmsi: '123456789',
      name: 'Test Vessel',
      vessel_status: 'ACTIVE',
      vessel_type: 'Bulk carrier',
      vessel_class: 'Handysize',
      build_year: 2010,
      age: 16,
      deadweight: 5000,
    },
    vessel_position: null,
    ...overrides,
  };
}

function makeComposition(
  overrides: Partial<FleetCompositionResponse> = {},
): FleetCompositionResponse {
  return {
    meta: { request_id: 'r1', request_timestamp: '2026-01-01T00:00:00Z' },
    fleet_information: {
      fleet_id: 'fleet-1',
      name: 'North Sea Fleet',
      vessel_count: 10,
    },
    data: {
      summary: {
        vessels: { filtered_count: 8 },
        average_age: { unit: 'years', value: 12 },
        total_dwt: { unit: 't', value: 5000, vessels_with_data: 6 },
        flag_states_count: 3,
      },
      type_and_class: { vessel_type: [], vessel_class: [] },
      registration_and_flag: {
        port_of_registry: { total_categories: 0, items: [] },
        vessel_flag: { total_categories: 0, items: [] },
      },
      build_and_origin: {
        country_of_build: { total_categories: 0, items: [] },
        builder: { total_categories: 0, items: [] },
        age_profile: [],
      },
      size_and_dimensions: {
        size: {
          deadweight_tonnage: { vessels_with_data: 0, unit: 't', items: [] },
          gross_tonnage: { vessels_with_data: 0, unit: 't', items: [] },
        },
        dimensions: {
          length_overall: { unit: 'm', vessels_with_data: 0, items: [] },
          beam: { unit: 'm', vessels_with_data: 0, items: [] },
          draught: { unit: 'm', vessels_with_data: 0, items: [] },
        },
      },
    },
    ...overrides,
  };
}

function defaultCompositionReturn(overrides: Record<string, unknown> = {}) {
  return {
    composition: makeComposition(),
    vessels: [makeVessel()],
    flags: ['NOR', 'PAN'],
    vesselTypes: ['Bulk carrier'],
    vesselClassGroups: [] as VesselClassGroup[],
    selectedFlags: {},
    selectedVesselTypes: {},
    selectedVesselClasses: {},
    activeFlags: [] as string[],
    activeVesselClasses: [] as string[],
    handleFlagToggle: vi.fn(),
    handleVesselTypeToggle: vi.fn(),
    handleVesselClassToggle: vi.fn(),
    handleFlagSelectAll: vi.fn(),
    handleVesselTypeSelectAll: vi.fn(),
    handleVesselClassSelectAll: vi.fn(),
    resetFilters: vi.fn(),
    hasActiveFilters: false,
    loading: false,
    ...overrides,
  };
}

const baseProps = {
  hasMTIScore: false,
  hasPtracAccess: false,
};

describe('FleetComposition', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockUseComposition.mockReturnValue(defaultCompositionReturn());
  });

  it('renders the filter dropdowns', () => {
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText('Vessel Flag')).toBeInTheDocument();
    expect(screen.getByText('Vessel Type')).toBeInTheDocument();
    expect(screen.getByText('Vessel Class')).toBeInTheDocument();
  });

  it('disables Reset Filters when there are no active filters', () => {
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText('Reset Filters')).toBeDisabled();
  });

  it('enables Reset Filters and calls resetFilters when active filters exist', () => {
    const resetFilters = vi.fn();
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({ hasActiveFilters: true, resetFilters }),
    );
    render(<FleetComposition {...baseProps} />);

    const resetButton = screen.getByText('Reset Filters');
    expect(resetButton).not.toBeDisabled();

    fireEvent.click(resetButton);

    expect(resetFilters).toHaveBeenCalledTimes(1);
  });

  it('calls handleFlagSelectAll when the Vessel Flag dropdown select-all fires', () => {
    const handleFlagSelectAll = vi.fn();
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({ handleFlagSelectAll }),
    );
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('Vessel Flag'));

    expect(handleFlagSelectAll).toHaveBeenCalledWith(false);
  });

  it('disables "View vessels" when there are no vessels', () => {
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({ vessels: [] }),
    );
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText(/View vessels/).closest('button')).toBeDisabled();
  });

  it('disables "View vessels" when vessels is undefined', () => {
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({ vessels: undefined }),
    );
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText(/View vessels/).closest('button')).toBeDisabled();
  });

  it('shows the filtered vessel count on the "View vessels" button', () => {
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText('View vessels (8)')).toBeInTheDocument();
  });

  it('opens the vessels slide-out panel when "View vessels" is clicked', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));

    expect(screen.getByText('VesselsHeader:8/10')).toBeInTheDocument();
    expect(screen.getByText(/VesselSlideOutBody/)).toBeInTheDocument();
  });

  it('does not render the vessels slide-out panel initially', () => {
    render(<FleetComposition {...baseProps} />);

    expect(screen.queryByText(/VesselsHeader/)).not.toBeInTheDocument();
  });

  it('opens the vessels slide-out panel when the Vessels KPI card is clicked', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('Vessels').closest('div')!);

    expect(screen.getByText(/VesselsHeader/)).toBeInTheDocument();
  });

  it('shows KPI defaults when composition is null', () => {
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({ composition: null }),
    );
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText('0 of 0')).toBeInTheDocument();
    expect(screen.getByText('0 years')).toBeInTheDocument();
    expect(screen.getByText('-')).toBeInTheDocument();
  });

  it('shows the total DWT KPI value when available', () => {
    render(<FleetComposition {...baseProps} />);

    expect(screen.getByText('5000 t')).toBeInTheDocument();
  });

  it('drills into a vessel when a row is selected in the vessel list', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));
    fireEvent.click(screen.getByText(/VesselSlideOutBody/));

    expect(screen.getByText('Header:Test Vessel')).toBeInTheDocument();
    expect(screen.getByText('SlideOutPanelBody')).toBeInTheDocument();
    expect(screen.queryByText(/VesselsHeader/)).not.toBeInTheDocument();
  });

  it('returns to the vessel list when the back button is clicked', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));
    fireEvent.click(screen.getByText(/VesselSlideOutBody/));
    fireEvent.click(screen.getByText('Back'));

    expect(screen.getByText(/VesselsHeader/)).toBeInTheDocument();
    expect(screen.queryByText('SlideOutPanelBody')).not.toBeInTheDocument();
  });

  it('navigates to the vessel analytics page when Full Details is clicked', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));
    fireEvent.click(screen.getByText(/VesselSlideOutBody/));
    fireEvent.click(screen.getByText('Full Details'));

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/vessel/1234567');
  });

  it('closes the slide-out panel from the vessel list header', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));
    fireEvent.click(screen.getByText('CloseHeader'));

    expect(screen.queryByText(/VesselsHeader/)).not.toBeInTheDocument();
  });

  it('closes the slide-out panel and clears the drilled vessel', () => {
    render(<FleetComposition {...baseProps} />);

    fireEvent.click(screen.getByText('View vessels (8)'));
    fireEvent.click(screen.getByText(/VesselSlideOutBody/));
    fireEvent.click(screen.getByText('CloseDrilledHeader'));

    expect(screen.queryByText(/VesselsHeader/)).not.toBeInTheDocument();
    expect(screen.queryByText('SlideOutPanelBody')).not.toBeInTheDocument();
  });

  it('passes composition data and active filters through to FleetCompositionCharts', () => {
    const composition = makeComposition();
    mockUseComposition.mockReturnValue(
      defaultCompositionReturn({
        composition,
        activeFlags: ['NOR'],
        activeVesselClasses: ['Handysize'],
        vesselClassGroups: [
          { vessel_type: 'Bulk carrier', classes: ['Handysize'] },
        ],
        loading: true,
      }),
    );
    render(<FleetComposition {...baseProps} />);

    expect(mockFleetCompositionCharts).toHaveBeenCalledWith(
      expect.objectContaining({
        composition,
        isLoading: true,
        activeFlags: ['NOR'],
        activeVesselClasses: ['Handysize'],
        vesselClassGroups: [
          { vessel_type: 'Bulk carrier', classes: ['Handysize'] },
        ],
      }),
    );
  });
});
