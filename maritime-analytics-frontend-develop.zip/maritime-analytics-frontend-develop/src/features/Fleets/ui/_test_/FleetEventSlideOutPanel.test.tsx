import { fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import FleetEventSlideOutPanel from '../FleetEventSlideOutPanel';
import type {
  FlatFleetEventsResponse,
  ZoneInformation,
} from '@/features/Fleets/types/fleetEventTypes';
import type { VesselData } from '@/features/Fleets/types/fleetTypes';
import type { Vessel } from '@/shared/types/entities';

const { state, navigate, locationSectionProps } = vi.hoisted(() => ({
  state: {
    isLoading: false,
    viewVessel: false,
    viewPairedVessel: false,
    viewLocation: false,
    vessel: undefined as unknown,
    pairedVessel: undefined as unknown,
    location: undefined as unknown,
    zoneBoundary: undefined as unknown,
    vesselInPortOrZone: 0,
    locationEvents: undefined as unknown,
    handleClose: vi.fn(),
    handleBackClick: vi.fn(),
    setViewLocation: vi.fn(),
    setViewVessel: vi.fn(),
    setViewPairedVessel: vi.fn(),
    slideOutModalRef: { current: null },
  },
  navigate: vi.fn(),
  locationSectionProps: { current: undefined as unknown },
}));
vi.mock('react-router', () => ({ useNavigate: () => navigate }));
vi.mock('@/features/Fleets/hooks/useFleetEventsSlideOut', () => ({
  useFleetEventSlideOut: (row?: FlatFleetEventsResponse) => ({
    ...state,
    isOpen: row !== undefined,
  }),
}));
vi.mock('@/shared/hooks/useEscapeClose', () => ({ useEscapeClose: vi.fn() }));
vi.mock('@/shared/hooks/useOnClickOutside', () => ({
  useOnClickOutside: vi.fn(),
}));
vi.mock('@/shared/ui/SideSlideOutPanel', () => ({
  default: (props: {
    isOpen: boolean;
    title: React.ReactNode;
    children: React.ReactNode;
    extraActions?: React.ReactNode;
  }) =>
    props.isOpen ? (
      <aside>
        <header>{props.title}</header>
        <main>{props.children}</main>
        {props.extraActions}
      </aside>
    ) : null,
}));
vi.mock('flowbite-react', () => ({
  Spinner: () => <span>Loading event</span>,
}));
vi.mock('@/features/Fleets/components/SlideOutPanelHeader', () => ({
  default: (props: { vesselName: string; onBack: () => void }) => (
    <div>
      Vessel header: {props.vesselName}
      <button onClick={props.onBack}>Back vessel</button>
    </div>
  ),
}));
vi.mock('@/features/Fleets/components/EventsSlideOutHeader', () => ({
  default: (props: { eventType: string }) => (
    <div>Event header: {props.eventType}</div>
  ),
}));
vi.mock('@/features/Fleets/components/LocationSlideOutHeader', () => ({
  default: () => <div>Location header</div>,
}));
vi.mock('@/features/Fleets/components/SlideOutPanelBody', () => ({
  default: () => <div>Paired vessel body</div>,
}));
vi.mock('@/features/Fleets/components/LocationSlideOutBody', () => ({
  default: () => <div>Location body</div>,
}));
vi.mock('@/features/Fleets/components/VesselSection', () => ({
  default: () => <div>Vessel section</div>,
}));
vi.mock('@/features/Fleets/components/LocationSection', () => ({
  default: (props: unknown) => {
    locationSectionProps.current = props;
    return <div>Location section</div>;
  },
}));
vi.mock('@/features/Fleets/components/EventsSlideOutDetails', () => ({
  default: ({ event }: { event: FlatFleetEventsResponse }) => (
    <div>Event details: {event.eventType}</div>
  ),
}));

const vessel = {
  name: 'Primary vessel',
  imo: 'IMO-1',
  flag: { country_code: 'NG' },
} as Vessel;
const pairedVessel = {
  vessel_information: { name: 'Paired vessel', imo: 'IMO-2', flag_code: 'GB' },
} as VesselData;
const location = {
  id: 'loc-1',
  name: 'Port',
  type: 'Ports',
} as ZoneInformation;

function makeRow(eventType: FlatFleetEventsResponse['eventType'] = 'AIS_GAP') {
  return {
    callSign: 'CALL',
    flag: 'Flag',
    flagCode: 'NG',
    imo: 'IMO-1',
    mmsi: 'MMSI-1',
    vesselName: 'Vessel',
    vesselType: 'Cargo',
    eventType,
    gapStartedLatitude: 1,
    gapStartedLongitude: 2,
  } as FlatFleetEventsResponse;
}

describe('FleetEventSlideOutPanel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    Object.assign(state, {
      isLoading: false,
      viewVessel: false,
      viewPairedVessel: false,
      viewLocation: false,
      vessel,
      pairedVessel: undefined,
      location: undefined,
      zoneBoundary: undefined,
      vesselInPortOrZone: 0,
      locationEvents: undefined,
    });
    locationSectionProps.current = undefined;
  });

  it('renders the selected event, vessel, and coordinate-backed location sections', () => {
    render(
      <FleetEventSlideOutPanel
        currentRow={makeRow()}
        hasMTIScore
        hasPtracAccess
        vessels={[]}
      />,
    );

    expect(screen.getByText('Event header: AIS Gap')).toBeInTheDocument();
    expect(screen.getByText('Vessel section')).toBeInTheDocument();
    expect(screen.getByText('Location section')).toBeInTheDocument();
    expect(screen.getByText('Event details: AIS_GAP')).toBeInTheDocument();
    expect(locationSectionProps.current).toMatchObject({ vessel });
  });

  it('shows a spinner while fetching and suppresses locations for PSC events', () => {
    state.isLoading = true;
    const { rerender } = render(
      <FleetEventSlideOutPanel
        currentRow={makeRow('PORT_STATE_CONTROL')}
        vessels={[]}
      />,
    );
    const spinner = screen.getByText('Loading event');
    expect(spinner).toBeInTheDocument();
    expect(spinner.parentElement).toHaveClass(
      'absolute',
      'inset-0',
      'flex',
      'items-center',
      'justify-center',
    );
    state.isLoading = false;
    rerender(
      <FleetEventSlideOutPanel
        currentRow={makeRow('PORT_STATE_CONTROL')}
        vessels={[]}
      />,
    );
    expect(screen.queryByText('Location section')).not.toBeInTheDocument();
    expect(
      screen.getByText('Event details: PORT_STATE_CONTROL'),
    ).toBeInTheDocument();
  });

  it('falls back to the event view when vessel data is missing during drill-down', () => {
    state.viewVessel = true;
    state.vessel = undefined;

    render(<FleetEventSlideOutPanel currentRow={makeRow()} vessels={[]} />);

    expect(screen.getByText('Event header: AIS Gap')).toBeInTheDocument();
    expect(screen.getByText('Event details: AIS_GAP')).toBeInTheDocument();
    expect(screen.queryByText(/Vessel header:/)).not.toBeInTheDocument();
  });

  it('falls back to the event view when paired vessel data is missing', () => {
    state.viewPairedVessel = true;
    state.pairedVessel = undefined;

    render(
      <FleetEventSlideOutPanel
        currentRow={makeRow('STS_PAIRING')}
        vessels={[]}
      />,
    );

    expect(screen.getByText('Event details: STS_PAIRING')).toBeInTheDocument();
    expect(screen.queryByText(/Vessel header:/)).not.toBeInTheDocument();
  });

  it('renders nested location and paired vessel views with full-detail navigation', () => {
    state.viewLocation = true;
    state.location = location;
    const { rerender } = render(
      <FleetEventSlideOutPanel
        currentRow={makeRow('PORT_ARRIVAL')}
        vessels={[]}
      />,
    );
    expect(screen.getByText('Location header')).toBeInTheDocument();
    expect(screen.getByText('Location body')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Full Details' }));
    expect(navigate).toHaveBeenCalledWith('/analytics/port/loc-1');

    state.viewLocation = false;
    state.viewPairedVessel = true;
    state.pairedVessel = pairedVessel;
    rerender(
      <FleetEventSlideOutPanel
        currentRow={makeRow('STS_PAIRING')}
        vessels={[]}
      />,
    );
    expect(
      screen.getByText('Vessel header: Paired vessel'),
    ).toBeInTheDocument();
    expect(screen.getByText('Paired vessel body')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Full Details' }));
    expect(navigate).toHaveBeenLastCalledWith('/analytics/vessel/IMO-2');
  });
});
