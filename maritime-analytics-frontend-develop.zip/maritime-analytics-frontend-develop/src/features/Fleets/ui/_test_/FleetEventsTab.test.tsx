import { fireEvent, render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import FleetEventsTab from '../FleetEventsTab';
import type { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';

const { hookArgs, tabProps, selected } = vi.hoisted(() => ({
  hookArgs: { current: undefined as unknown },
  tabProps: { current: undefined as unknown },
  selected: { current: undefined as FlatFleetEventsResponse | undefined },
}));
vi.mock('@/features/Fleets/hooks/useFleetEvents', () => ({
  useFleetEvents: (...args: unknown[]) => {
    hookArgs.current = args;
    return {
      refresh: false,
      setRefresh: vi.fn(),
      selected: { AIS_GAP: true },
      onToggle: vi.fn(),
      rows: [],
      lastUpdated: new Date('2026-01-01T00:00:00Z'),
      isLoading: false,
      onSelectAll: vi.fn(),
      columnStorageKey: 'fleet-events',
      selectedRow: selected.current,
      setSelectedRow: (row?: FlatFleetEventsResponse) => {
        selected.current = row;
      },
    };
  },
}));
vi.mock('../FleetEventsPanel', () => ({
  FleetEventsPanel: (props: {
    onRowClick: (row: FlatFleetEventsResponse) => void;
    renderExtras: React.ReactNode;
  }) => {
    tabProps.current = props;
    return (
      <div>
        <button onClick={() => props.onRowClick(row)}>Select event</button>
        {props.renderExtras}
      </div>
    );
  },
}));
vi.mock('../FleetEventSlideOutPanel', () => ({
  default: (props: {
    currentRow?: FlatFleetEventsResponse;
    hasMTIScore?: boolean;
    hasPtracAccess?: boolean;
  }) => (
    <div data-testid="slideout-props">
      {JSON.stringify({
        currentRow: props.currentRow?.eventType,
        hasMTIScore: props.hasMTIScore,
        hasPtracAccess: props.hasPtracAccess,
      })}
    </div>
  ),
}));

const row = {
  callSign: 'CALL',
  flag: 'Flag',
  flagCode: 'NG',
  imo: 'IMO-1',
  mmsi: 'MMSI-1',
  vesselName: 'Vessel',
  vesselType: 'Cargo',
  eventType: 'AIS_GAP',
} as FlatFleetEventsResponse;

describe('FleetEventsTab', () => {
  beforeEach(() => {
    selected.current = undefined;
  });

  it('loads fleet events and sends selected rows and access props to the slide-out', () => {
    const view = render(
      <FleetEventsTab
        fleetId="fleet-1"
        fleetName="Fleet One"
        hasMTIScore
        hasPtracAccess={false}
      />,
    );

    expect(hookArgs.current).toEqual([
      'fleet-1',
      expect.arrayContaining([
        expect.objectContaining({
          value: 'AIS_GAP',
          groupings: 'Other Events',
        }),
        expect.objectContaining({
          value: 'ZONE_ENTRY',
          groupings: 'Zone Events',
        }),
      ]),
    ]);
    fireEvent.click(screen.getByRole('button', { name: 'Select event' }));
    view.rerender(
      <FleetEventsTab
        fleetId="fleet-1"
        fleetName="Fleet One"
        hasMTIScore
        hasPtracAccess={false}
      />,
    );
    expect(screen.getByTestId('slideout-props')).toHaveTextContent(
      JSON.stringify({
        currentRow: 'AIS_GAP',
        hasMTIScore: true,
        hasPtracAccess: false,
      }),
    );
    expect(tabProps.current).toMatchObject({
      fleetId: 'fleet-1',
      fleetName: 'Fleet One',
      storageKey: 'fleet-events',
      onRowClick: expect.any(Function),
    });
  });
});
