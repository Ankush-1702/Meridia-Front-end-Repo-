import { ColDef } from 'ag-grid-community';
import { Spinner } from 'flowbite-react';
import { useMemo, useRef, useState } from 'react';
import { useFleetExports } from '../hooks/useFleetExports';
import { searchFieldTheme } from '@/app/config/flowbite-theme';
import ChartsDownloadDropDown from '@/shared/components/ChartsDownloadDropDown';
import Filter from '@/shared/components/Filter';
import PoleStarEntityGrid, {
  PoleStarEntityGridRef,
} from '@/shared/lib/PoleStarEntityGrid';
function matchesQuery(value: unknown, lowerQuery: string): boolean {
  if (value === null || value === undefined) return false;

  if (Array.isArray(value)) {
    return value.some((item) => matchesQuery(item, lowerQuery));
  }

  if (typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).some((nested) =>
      matchesQuery(nested, lowerQuery),
    );
  }

  return String(value).toLowerCase().replace(/_/g, ' ').includes(lowerQuery);
}

// const NEXT_PORT_FIELD = 'vessel_position.reported_destination';

interface FleetListViewProps<TEvent> {
  storageKey?: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  isPort?: boolean;
  buildColumns?: () => ColDef<TEvent>[];
  onRowClick?: (event: TEvent) => void;
  rows?: unknown[];
  flagCode?: string[];
  mtiScore?: string[];
  vesselClass?: string[];
  vesselType?: string[];
  totalVesselCount?: number;
  filtersAppliedCount?: number;
  hasActiveFilters?: boolean;
  onResetFilters?: () => void;
}

export default function FleetListView<TEvent>({
  rows,
  onRowClick,
  isLoading,
  buildColumns,
  storageKey,
  flagCode,
  mtiScore,
  vesselClass,
  vesselType,
  totalVesselCount,
  filtersAppliedCount = 0,
  hasActiveFilters,
  onResetFilters,
}: FleetListViewProps<TEvent>) {
  const gridRef = useRef<PoleStarEntityGridRef | null>(null);
  const [query, setQuery] = useState<string>('');

  const columns = useMemo(() => buildColumns?.(), [buildColumns]);

  const noRowsOverlay = useMemo(
    () => () => (
      <NoRowsOverlay
        hasActiveFilters={!!hasActiveFilters}
        onResetFilters={onResetFilters ?? (() => {})}
      />
    ),
    [hasActiveFilters, onResetFilters],
  );

  // const exportColumns = useMemo(
  //   () =>
  //     (columns ?? [])
  //       .map((col) => (col.field ? String(col.field) : undefined))
  //       .filter(
  //         (field): field is string => !!field && field !== NEXT_PORT_FIELD,
  //       ),
  //   [columns],
  // );

  const filteredRows = useMemo(() => {
    if (!query.trim()) return rows;
    const lower = query.toLowerCase().replace(/_/g, ' ');

    return rows?.filter((row) => matchesQuery(row, lower));
  }, [query, rows]);

  const { handleExportClick, isPolling } = useFleetExports(
    flagCode ?? [],
    mtiScore ?? [],
    vesselClass ?? [],
    vesselType ?? [],
  );
  const shownCount = filteredRows?.length ?? 0;
  const showingLabel =
    totalVesselCount !== undefined
      ? `Showing ${shownCount} of ${totalVesselCount} ${totalVesselCount === 1 ? 'vessel' : 'vessels'}` +
        (filtersAppliedCount > 0
          ? ` · ${filtersAppliedCount} ${filtersAppliedCount === 1 ? 'filter' : 'filters'} applied`
          : '')
      : `${shownCount} ${shownCount === 1 ? 'vessel' : 'vessels'}`;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-1 flex-col gap-1 rounded-lg bg-white dark:bg-gray-800">
        <div className="flex items-center justify-between px-3 py-3">
          <div className="flex items-center gap-3">
            <Filter
              width={`w-[300px]`}
              placeholder={'Search vessels...'}
              query={query}
              setQuery={setQuery}
              theme={searchFieldTheme}
            />
            <span className={`text-sm text-gray-500`}>{showingLabel}</span>
            {filtersAppliedCount > 0 && shownCount === 0 && onResetFilters && (
              <button
                className="cursor-pointer text-sm text-psg-orange-700 hover:underline"
                onClick={onResetFilters}
              >
                Reset filters
              </button>
            )}
          </div>
          <ChartsDownloadDropDown
            loading={isLoading || isPolling}
            hasData={!!filteredRows?.length}
            onExportCSV={handleExportClick}
            shouldShow={false}
          />
        </div>
        <div className="relative min-h-0 flex-1 overflow-auto rounded-b-lg bg-white dark:bg-gray-800">
          {isLoading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/80 dark:bg-gray-800/80">
              <div className="flex flex-col items-center gap-3">
                <Spinner size="xl" color="psgPrimary" light />
              </div>
            </div>
          )}
          <div className="h-full min-h-0">
            <PoleStarEntityGrid
              key={storageKey}
              ref={gridRef}
              roundedTop={false}
              isServerSide={false}
              rows={filteredRows}
              columns={columns!}
              pageSize={500}
              storageKey={storageKey}
              noRowsOverlay={noRowsOverlay}
              onRowClick={(row) => onRowClick?.(row.data as TEvent)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

const NoRowsOverlay = ({
  hasActiveFilters,
  onResetFilters,
}: {
  hasActiveFilters: boolean;
  onResetFilters: () => void;
}) => {
  if (!hasActiveFilters) {
    return (
      <div className="flex h-full items-center justify-center text-base text-gray-500">
        No data available
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col items-center justify-center gap-2 text-base">
      <p className="font-semibold text-gray-900 dark:text-white">
        No vessels match these filters.
      </p>
      <p className="text-sm text-gray-500">
        Try resetting or adjusting your filters.
      </p>
      <button
        className="cursor-pointer rounded-md border border-gray-200 bg-white px-2 py-1 text-sm text-gray-900 hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
        onClick={onResetFilters}
      >
        Reset filters
      </button>
    </div>
  );
};
