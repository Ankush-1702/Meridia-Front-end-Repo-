// import StatsFooter from '../components/StatsFooter';
import { Dropdown, Tooltip } from 'flowbite-react';
import { DropdownItem } from 'flowbite-react';
import { useEffect, useMemo, useState } from 'react';
import { FaEllipsisVertical, FaRegCircleQuestion } from 'react-icons/fa6';
import { LuAlertTriangle, LuX } from 'react-icons/lu';
import { UnresolvedImos } from '../types/fleetTypes';
import { menuTheme } from '@/app/config/flowbite-theme';
import UnresolvedPanel from '@/features/Fleets/components/UnresolvedPanel';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import FlagIcon from '@/shared/ui/FlagIcon';
import { cn } from '@/shared/utils/classMerge';

const LIST_CAP = 1000;
export const CAP_WARN_AT = 0.9;

export default function FleetPreview({
  type,
  matched,
  headline,
  cap,
  limitsOn = true,
  //   showUpsell,
  unresolved,
  onDismissUnresolved,
  onDismissAllUnresolved,
  onRemove,
  onClearAll,
}: {
  type: 'static' | 'dynamic';
  matched: VesselSearch[];
  headline?: number;
  /** Vessels allowed in this fleet at the current tier. */
  cap?: number;
  /** `fleet.limits` flag — off means the cap is informational only. */
  limitsOn?: boolean;
  /** Show the "Unlock" upsell badge beside the Vessels heading. */
  showUpsell?: boolean;
  unresolved?: UnresolvedImos;
  onDismissUnresolved: (imo: string) => void;
  onDismissAllUnresolved: () => void;
  onRemove?: (v: VesselSearch) => void;
  onClearAll?: () => void;
}) {
  //   const stats = useMemo(() => {
  //     if (!matched.length) return null;
  //     const avgAge = Math.round(
  //       matched.reduce((s, v) => s + (2026 - v.buildYear), 0) / matched.length,
  //     );
  //     const avgDwt = Math.round(
  //       matched.reduce((s, v) => s + v.dwt, 0) / matched.length / 1000,
  //     );
  //     const top = (key: 'flag' | 'vesselType') =>
  //       Object.entries(
  //         matched.reduce<Record<string, number>>((a, v) => {
  //           a[v[key]] = (a[v[key]] || 0) + 1;
  //           return a;
  //         }, {}),
  //       ).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '—';
  //     return { avgAge, avgDwt, topFlag: top('flag'), topType: top('vesselType') };
  //   }, [matched]);

  // Real vessels only — the rest of the headline count is summarised as "…and N more"
  // (the preview used to fabricate padded rows with synthetic IMOs).
  const rows = useMemo(() => matched.slice(0, LIST_CAP), [matched]);
  const hidden = Math.max(0, headline! - rows.length);

  const pct = Math.min(100, (headline! / cap!) * 100);
  const over = limitsOn && headline! > cap!;
  const near = limitsOn && !over && headline! >= cap! * CAP_WARN_AT;
  // Dynamic fleets keep growing after they're saved, so warn about the consequence
  // rather than implying the current count is the problem.
  const atCapDynamic = limitsOn && type === 'dynamic' && headline! >= cap!;

  // Dynamic fleets recalc as rules change — show a brief "recalculating" state.
  const [recalc, setRecalc] = useState(false);
  useEffect(() => {
    if (type !== 'dynamic') return;
    const on = setTimeout(() => setRecalc(true), 0);
    const off = setTimeout(() => setRecalc(false), 450);
    return () => {
      clearTimeout(on);
      clearTimeout(off);
    };
  }, [matched, type]);

  return (
    <aside className="sticky top-0 flex max-h-[calc(100svh-5rem)] w-[340px] shrink-0 flex-col rounded-lg bg-white dark:bg-gray-800">
      {/* Vessels header: count / capacity + actions */}
      <div className="flex min-h-[60px] shrink-0 flex-col justify-center border-b border-gray-200 px-5 py-3 dark:border-gray-700">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <p className="text-sm font-medium">Vessels</p>
            <Tooltip
              placement="bottom"
              arrow={false}
              className="max-w-xs"
              content="Live preview — updates when vessels or rules are changed."
            >
              <FaRegCircleQuestion className="size-3.5 text-gray-500" />
            </Tooltip>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className={cn(
                'text-sm tabular-nums',
                over
                  ? 'font-semibold text-red-600'
                  : near
                    ? 'font-medium text-yellow-600/70 dark:text-yellow-600'
                    : 'text-gray-600/70',
              )}
            >
              {headline?.toLocaleString()} / {cap?.toLocaleString()}
            </span>
            {/* Sits with the count — the number is the constraint. "Upgrade" (not
                "Unlock"): fleets aren't gated, this is the next tier up, matching the
                already-entitled upsell variant on the vessel sheet. */}
            {/* {showUpsell && (
              <UpsellPopover
                {...FLEET_LIMIT_UPSELL}
                label="Upgrade"
                icon={UpgradeIcon}
              />
            )} */}
            {headline! > 0 && (
              <Dropdown
                label
                inline
                arrowIcon={false}
                placement="bottom-end"
                theme={menuTheme}
                renderTrigger={() => (
                  <button
                    type="button"
                    aria-label="Vessel actions"
                    className="rounded-lg p-1 hover:bg-gray-200 dark:hover:bg-gray-700"
                  >
                    <FaEllipsisVertical className="size-4 text-gray-500" />
                  </button>
                )}
              >
                <DropdownItem
                  onClick={onClearAll}
                  className="text-red-600 hover:bg-red-600/10 focus:bg-red-600/10"
                >
                  Clear fleet
                </DropdownItem>
              </Dropdown>
            )}
          </div>
        </div>
        <div className="mt-2 h-1 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-700">
          <div
            className={cn(
              'h-full rounded-full transition-colors',
              over
                ? 'bg-red-600'
                : near
                  ? 'bg-yellow-400'
                  : 'bg-psg-orange-700',
            )}
            style={{ width: `${pct}%` }}
          />
        </div>
        {/* Over the tier's allowance — blocks Save, and offers the way out. */}
        {over && (
          <div
            role="status"
            className="mt-2.5 flex items-start gap-2.5 rounded-lg border border-yellow-200 bg-yellow-50 p-2.5 text-xs text-yellow-900 dark:border-yellow-900/40 dark:bg-yellow-900/40 dark:text-yellow-200"
          >
            <LuAlertTriangle className="mt-0.5 size-3.5 shrink-0 text-yellow-500" />
            <div className="min-w-0">
              {/* The upsell badge sits beside the Vessels heading just above, so this
                  banner carries the fix, not a second CTA. */}
              <p className="leading-snug">
                This fleet is over your {cap?.toLocaleString()}-vessel limit.{' '}
                {/* Static fleets are a list to prune; dynamic fleets are a rule to tighten. */}
                {type === 'static'
                  ? `Remove ${(headline! - cap!).toLocaleString()} vessel${headline! - cap! === 1 ? '' : 's'} to save it.`
                  : 'Narrow your rules to bring it under the limit, or upgrade.'}
              </p>
            </div>
          </div>
        )}
        {/* Dynamic fleets drift over their cap as new vessels match the rules. */}
        {atCapDynamic && !over && (
          <p className="mt-2 text-[11px] leading-snug text-gray-500">
            At your limit — new matching vessels won’t be added, and you’ll be
            notified when that happens.
          </p>
        )}
      </div>

      {/* Bulk-import failures — a partial import is never silent. */}
      {unresolved && (
        <UnresolvedPanel
          items={unresolved}
          onDismiss={onDismissUnresolved}
          onDismissAll={onDismissAllUnresolved}
        />
      )}

      <div className="min-h-0 flex-1 overflow-auto">
        {type === 'dynamic' && recalc ? (
          <div className="flex h-full flex-col items-center justify-center gap-2">
            <div className="size-6 animate-spin rounded-full border-2 border-t border-gray-200 dark:border-gray-700" />
            <span className="text-xs text-gray-500">Recalculating…</span>
          </div>
        ) : rows.length === 0 ? (
          <div className="m-5 rounded-lg  border border-gray-200 bg-white/50 px-4 py-10 text-center text-sm text-gray-500 dark:border-gray-700 dark:bg-gray-800/50">
            {type === 'static'
              ? 'No vessels added yet'
              : 'No vessels match — add a rule to start'}
          </div>
        ) : (
          <>
            {rows.map((v) => (
              <div
                key={v.imo}
                className="flex items-center gap-2.5 border-t border-gray-300 px-5 py-2 text-sm first:border-t-0 dark:border-gray-700"
              >
                <FlagIcon flagCode={v.flag_code} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium leading-tight">{v.name}</p>
                  <p className="truncate text-xs text-gray-500">
                    {v.imo} · {v.vessel_type}
                  </p>
                </div>
                <button
                  type="button"
                  aria-label={`Remove ${v.name}`}
                  onClick={() => onRemove?.(v)}
                  className="flex h-6 w-6 items-center justify-center rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  <LuX className="size-3.5" />
                </button>
              </div>
            ))}
            {hidden > 0 && (
              <p className="border-t border-gray-200 px-5 py-2 text-xs text-gray-500 dark:border-gray-700">
                …and {hidden.toLocaleString()} more
              </p>
            )}
          </>
        )}
      </div>

      {/* {stats && <StatsFooter stats={stats} />} */}
    </aside>
  );
}
