import { ColDef } from 'ag-grid-enterprise';
import { useRef } from 'react';
import { FaArrowRight } from 'react-icons/fa6';
import { LuRefreshCw } from 'react-icons/lu';
import { useNavigate } from 'react-router';
import SlideOutPanelBody from '../components/SlideOutPanelBody';
import SlideOutPanelHeader from '../components/SlideOutPanelHeader';
import { FleetOverviewView, VesselClassGroup } from '../types/fleetTypes';
import { VesselData } from '../types/fleetTypes';
import { buildVesselClassOptions } from '../utils/fleetFilterUtils';
import FleetListView from './FleetListView';
import { FleetMap } from './FleetMap';
import { countries } from '@/features/library/utils/countryMapping';
import MultiSelectDropdown from '@/shared/components/MultiSelectDropdown';
import TabGroup, { TabConfig } from '@/shared/components/TabGroup';
import { useEscapeClose } from '@/shared/hooks/useEscapeClose';
import { useOnClickOutside } from '@/shared/hooks/useOnClickOutside';
import FlagIcon from '@/shared/ui/FlagIcon';
import SideSlideOutPanel from '@/shared/ui/SideSlideOutPanel';
import { getDisplayName } from '@/shared/utils/CongestionAndTrafficUtils';

export default function FleetOverview({
  view,
  buildColumns,
  hasMTIScore,
  hasPtracAccess,
  viewTabs,
  setView,
  flags,
  vesselTypes,
  vesselClassGroups,
  mtiScores,
  selectedFlags,
  selectedVesselTypes,
  selectedVesselClasses,
  selectedMtiScores,
  onFlagToggle,
  onVesselTypeToggle,
  onVesselClassToggle,
  onMtiScoreToggle,
  onFlagSelectAll,
  onVesselTypeSelectAll,
  onVesselClassSelectAll,
  onMtiScoreSelectAll,
  onResetFilters,
  hasActiveFilters,
  activeFlagCodes,
  activeVesselTypes,
  activeVesselClasses,
  activeMtiScores,
  filtersAppliedCount,
  totalVesselCount,
  vessels,
  vesselsLoading,
  onRefresh,
  isRefreshing,
  timeAgo,
  currentVessel,
  setCurrentVessel,
}: {
  view: FleetOverviewView;
  buildColumns: () => ColDef[];
  hasMTIScore: boolean;
  hasPtracAccess: boolean;
  viewTabs: TabConfig[];
  setView: (tab: FleetOverviewView) => void;
  flags?: string[];
  vesselTypes?: string[];
  vesselClassGroups?: VesselClassGroup[];
  mtiScores?: string[];
  selectedFlags: Record<string, boolean>;
  selectedVesselTypes: Record<string, boolean>;
  selectedVesselClasses: Record<string, boolean>;
  selectedMtiScores: Record<string, boolean>;
  onFlagToggle: (value: string, checked: boolean) => void;
  onVesselTypeToggle: (value: string, checked: boolean) => void;
  onVesselClassToggle: (value: string, checked: boolean) => void;
  onMtiScoreToggle: (value: string, checked: boolean) => void;
  onFlagSelectAll: (checked: boolean) => void;
  onVesselTypeSelectAll: (checked: boolean) => void;
  onVesselClassSelectAll: (checked: boolean) => void;
  onMtiScoreSelectAll: (checked: boolean) => void;
  onResetFilters: () => void;
  hasActiveFilters: boolean;
  activeFlagCodes: string[];
  activeVesselTypes: string[];
  activeVesselClasses: string[];
  activeMtiScores: string[];
  filtersAppliedCount: number;
  totalVesselCount: number;
  vessels: VesselData[];
  vesselsLoading: boolean;
  onRefresh: () => void;
  isRefreshing: boolean;
  timeAgo: string;
  currentVessel?: VesselData;
  setCurrentVessel: (vessel: VesselData | undefined) => void;
}) {
  const navigate = useNavigate();
  const slideOutModalRef = useRef<HTMLDivElement>(null);
  const handleClose = () => {
    setCurrentVessel(undefined);
  };
  useOnClickOutside(slideOutModalRef, handleClose);
  useEscapeClose(handleClose);
  return (
    <>
      <div className={`flex h-14 items-center justify-between px-6`}>
        <div className={`flex gap-2`}>
          <MultiSelectDropdown
            title={`Vessel Flag`}
            shouldShowAll
            key={`fleet-Vessel-flag`}
            options={flags?.map((code) => ({
              value: code,
              label: countries[code] ?? code,
              icon: <FlagIcon flagCode={code} />,
            }))}
            selected={selectedFlags}
            onToggle={onFlagToggle}
            onSelectAll={onFlagSelectAll}
          />
          <MultiSelectDropdown
            title={`Vessel Type`}
            shouldShowAll
            showSearch
            key={`fleet-Vessel-type`}
            options={vesselTypes?.map((vt) => ({
              value: vt,
              label: getDisplayName(vt),
            }))}
            selected={selectedVesselTypes}
            onToggle={onVesselTypeToggle}
            onSelectAll={onVesselTypeSelectAll}
          />
          <MultiSelectDropdown
            title={`Vessel Class`}
            shouldShowAll
            showSearch
            showGroupedItems
            key={`fleet-Vessel-class`}
            options={buildVesselClassOptions(vesselClassGroups ?? [])}
            selected={selectedVesselClasses}
            onToggle={onVesselClassToggle}
            onSelectAll={onVesselClassSelectAll}
          />
          {hasMTIScore && (
            <MultiSelectDropdown
              title={`MTI Score`}
              shouldShowAll
              showSearch
              key={`fleet-Nav-status`}
              options={mtiScores?.map((score) => ({
                value: score,
                label: score,
              }))}
              selected={selectedMtiScores}
              onToggle={onMtiScoreToggle}
              onSelectAll={onMtiScoreSelectAll}
            />
          )}
          <div className="flex items-center px-4">
            <button
              className="cursor-pointer text-xs text-gray-400 enabled:text-psg-orange-700 enabled:hover:underline disabled:cursor-default"
              onClick={onResetFilters}
              disabled={!hasActiveFilters}
            >
              Reset Filters
            </button>
          </div>
        </div>
        <div className={`flex items-center gap-2`}>
          <div className="flex items-center gap-1 text-xs text-gray-400 ">
            <LuRefreshCw className="h-3 w-3 text-gray-400" />
            Updated {timeAgo} ago
            <button
              className="cursor-pointer text-gray-400 underline hover:text-gray-700"
              onClick={onRefresh}
              disabled={isRefreshing}
            >
              Refresh
            </button>
          </div>
          <TabGroup
            tabs={viewTabs}
            active={view}
            onChange={(tab) => setView(tab as FleetOverviewView)}
            size="sm"
            className={`bg-gray-100 dark:bg-gray-900`}
          />
        </div>
      </div>
      <div className="h-[calc(100dvh-152px)] w-full">
        {view === 'map' && (
          <FleetMap vessels={vessels} onVesselClick={setCurrentVessel} />
        )}
        {view === 'list' && (
          <div className={`h-full min-h-0 px-6 pb-6`}>
            <FleetListView
              buildColumns={buildColumns}
              rows={vessels}
              isLoading={vesselsLoading}
              storageKey="fleet-vessels"
              onRowClick={(row) => setCurrentVessel(row as VesselData)}
              flagCode={activeFlagCodes}
              vesselType={activeVesselTypes}
              vesselClass={activeVesselClasses}
              mtiScore={activeMtiScores}
              totalVesselCount={totalVesselCount}
              filtersAppliedCount={filtersAppliedCount}
              hasActiveFilters={hasActiveFilters}
              onResetFilters={onResetFilters}
            />
          </div>
        )}
      </div>
      <SideSlideOutPanel
        isOpen={currentVessel !== undefined}
        onClose={handleClose}
        modalRef={slideOutModalRef}
        title={
          <SlideOutPanelHeader
            vesselName={currentVessel?.vessel_information.name ?? ''}
            vesselFlagCode={currentVessel?.vessel_information.flag_code ?? ''}
            vesselImo={currentVessel?.vessel_information.imo ?? ''}
            onClose={handleClose}
          />
        }
        extraActions={
          <div className="mt-auto border-gray-200 dark:border-gray-700">
            <button
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white py-2 text-sm font-medium text-gray-900 transition-colors hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700 dark:disabled:hover:bg-gray-800"
              onClick={() =>
                navigate(
                  `/analytics/vessel/${currentVessel?.vessel_information.imo}`,
                )
              }
            >
              Full Details
              <FaArrowRight className={`text-gray-500`} />
            </button>
          </div>
        }
        children={
          <SlideOutPanelBody
            vesselData={currentVessel!}
            hasMTIScore={hasMTIScore}
            hasPtracAccess={hasPtracAccess}
          />
        }
      />
    </>
  );
}
