import { Button } from 'flowbite-react';
import { useRef, useState } from 'react';
import { FaArrowRight } from 'react-icons/fa';
import { LuArrowRight } from 'react-icons/lu';
import { useNavigate } from 'react-router';
import KpiCards from '../components/KpiCards';
import SlideOutPanelBody from '../components/SlideOutPanelBody';
import SlideOutPanelHeader from '../components/SlideOutPanelHeader';
import VesselSlideOutBody, { SortId } from '../components/VesselSlideOutBody';
import VesselsSlideOutHeader from '../components/VesselsSlideOutHeader';
import { useComposition } from '../hooks/useComposition';
import { VesselData } from '../types/fleetTypes';
import { buildVesselClassOptions } from '../utils/fleetFilterUtils';
import FleetCompositionCharts from './FleetCompositionCharts';
import { countries } from '@/features/library/utils/countryMapping';
import LoadingOverlay from '@/features/Ports/Berth/components/LoadingOverlay';
import MultiSelectDropdown from '@/shared/components/MultiSelectDropdown';
import { useEscapeClose } from '@/shared/hooks/useEscapeClose';
import { useOnClickOutside } from '@/shared/hooks/useOnClickOutside';
import FlagIcon from '@/shared/ui/FlagIcon';
import SideSlideOutPanel from '@/shared/ui/SideSlideOutPanel';
import { getDisplayName } from '@/shared/utils/CongestionAndTrafficUtils';
export interface FleetCompostitionProps {
  hasMTIScore: boolean;
  hasPtracAccess: boolean;
}

export default function FleetComposition({
  hasMTIScore,
  hasPtracAccess,
}: FleetCompostitionProps) {
  const navigate = useNavigate();
  const {
    composition,
    vessels,
    flags,
    vesselTypes,
    vesselClassGroups,
    selectedFlags,
    selectedVesselTypes,
    selectedVesselClasses,
    activeFlags,
    activeVesselClasses,
    handleFlagToggle,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleFlagSelectAll,
    handleVesselTypeSelectAll,
    handleVesselClassSelectAll,
    resetFilters,
    hasActiveFilters,
    loading,
  } = useComposition();
  const [query, setQuery] = useState<string>('');
  const [sort, setSort] = useState<SortId>('name');
  const [viewVessels, setViewVessels] = useState<boolean>(false);
  const [drillVessel, setDrillVessel] = useState<VesselData | undefined>(
    undefined,
  );
  const slideOutModalRef = useRef<HTMLDivElement>(null);
  const handleCloseSlideOutPanel = () => {
    setDrillVessel(undefined);
    setViewVessels(false);
    setQuery('');
  };
  const handleBackClick = () => {
    setDrillVessel(undefined);
  };

  useOnClickOutside(slideOutModalRef, handleCloseSlideOutPanel);
  useEscapeClose(handleCloseSlideOutPanel);

  return (
    <div className={`flex flex-col px-6`}>
      <div
        className={`sticky top-0 z-10 -mx-6 mt-1 flex h-14 items-center justify-between bg-gray-100 px-6 dark:bg-gray-900`}
      >
        <div
          className={`pointer-events-none absolute inset-x-0 top-full h-4 bg-gradient-to-b from-gray-100 to-transparent dark:from-gray-900`}
        />
        <div className={`flex gap-2`}>
          <MultiSelectDropdown
            title={`Vessel Flag`}
            shouldShowAll
            key={`fleet-Vessel-flag`}
            options={flags?.map((code) => ({
              value: code,
              label: countries[code] ?? code,
              icon: <FlagIcon flagCode={code} />,
            }))}
            selected={selectedFlags}
            onToggle={handleFlagToggle}
            onSelectAll={handleFlagSelectAll}
          />
          <MultiSelectDropdown
            title={`Vessel Type`}
            shouldShowAll
            showSearch
            key={`fleet-Vessel-type`}
            options={vesselTypes?.map((vt) => ({
              value: vt,
              label: getDisplayName(vt),
            }))}
            selected={selectedVesselTypes}
            onToggle={handleVesselTypeToggle}
            onSelectAll={handleVesselTypeSelectAll}
          />
          <MultiSelectDropdown
            title={`Vessel Class`}
            shouldShowAll
            showSearch
            showGroupedItems
            key={`fleet-Vessel-class`}
            options={buildVesselClassOptions(vesselClassGroups ?? [])}
            selected={selectedVesselClasses}
            onToggle={handleVesselClassToggle}
            onSelectAll={handleVesselClassSelectAll}
          />
          <div className="flex items-center px-1">
            <button
              className="cursor-pointer text-xs text-gray-400 enabled:text-psg-orange-700 enabled:hover:underline disabled:cursor-default"
              onClick={resetFilters}
              disabled={!hasActiveFilters}
            >
              Reset Filters
            </button>
          </div>
        </div>
        <div className={`flex items-center gap-2`}>
          <Button
            size={`sm`}
            // color={`gray`}
            className={`border border-gray-200 bg-white text-gray-900 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-white hover:dark:bg-gray-700`}
            onClick={() => setViewVessels(!viewVessels)}
            disabled={vessels?.length === 0 || !vessels}
          >
            <div className={`flex items-center gap-1`}>
              View vessels (
              {composition?.data.summary.vessels.filtered_count ?? 0})
              <LuArrowRight className={`text-gray-400`} />
            </div>
          </Button>
          {/* <Button size={`sm`} color={`gray`} disabled={true}>
            <div className={`flex items-center gap-1`}>
              <LuDownload className={`text-gray-500`} />
              Export
            </div>
          </Button> */}
        </div>
      </div>
      <div className={`mt-4 flex gap-4`}>
        <LoadingOverlay loading={loading} className="flex w-full">
          <KpiCards
            title={`Vessels`}
            value={`${composition?.data.summary.vessels?.filtered_count ?? 0} of ${composition?.fleet_information.vessel_count ?? 0}`}
            isClickable={composition?.fleet_information.vessel_count !== 0}
            handleClick={() => setViewVessels(!viewVessels)}
          />
        </LoadingOverlay>
        <LoadingOverlay loading={loading} className="flex w-full">
          <KpiCards
            title={`Average age`}
            value={`${composition?.data.summary.average_age?.value ?? 0} ${composition?.data.summary.average_age?.unit ?? `years`}`}
          />
        </LoadingOverlay>
        <LoadingOverlay loading={loading} className="flex w-full">
          <KpiCards
            title={`Total DWT`}
            value={
              composition?.data.summary.total_dwt &&
              composition.data.summary.total_dwt.value > 0
                ? `${composition.data.summary.total_dwt.value} ${composition.data.summary.total_dwt.unit}`
                : '-'
            }
            showCoverage={true}
            coverage={{
              known: composition?.data.summary.total_dwt.vessels_with_data ?? 0,
              total: composition?.data.summary.vessels.filtered_count ?? 0,
              complete:
                (composition?.data.summary.total_dwt.vessels_with_data ?? 0) ===
                (composition?.fleet_information.vessel_count ?? 0),
            }}
            section={`DWT`}
          />
        </LoadingOverlay>
        <LoadingOverlay loading={loading} className="flex w-full">
          <KpiCards
            title={`Flag states`}
            value={`${composition?.data.summary.flag_states_count ?? 0}`}
          />
        </LoadingOverlay>
      </div>
      <div className={`mt-4 pb-4`}>
        <FleetCompositionCharts
          composition={composition}
          isLoading={loading}
          activeFlags={activeFlags}
          activeVesselClasses={activeVesselClasses}
          vesselClassGroups={vesselClassGroups ?? []}
        />
      </div>
      <SideSlideOutPanel
        isOpen={viewVessels}
        onClose={handleCloseSlideOutPanel}
        modalRef={slideOutModalRef}
        title={
          !drillVessel ? (
            <VesselsSlideOutHeader
              onClose={handleCloseSlideOutPanel}
              totalCount={composition?.fleet_information.vessel_count ?? 0}
              filteredCount={
                composition?.data.summary.vessels.filtered_count ?? 0
              }
            />
          ) : (
            <SlideOutPanelHeader
              vesselName={drillVessel.vessel_information.name}
              vesselImo={drillVessel.vessel_information.imo}
              vesselFlagCode={drillVessel.vessel_information.flag_code}
              onClose={handleCloseSlideOutPanel}
              showBackButton={true}
              onBack={handleBackClick}
            />
          )
        }
        children={
          !drillVessel ? (
            <VesselSlideOutBody
              query={query}
              setDrillImo={setDrillVessel}
              setQuery={setQuery}
              sort={sort}
              setSort={setSort}
              vessels={vessels ?? []}
            />
          ) : (
            <SlideOutPanelBody
              vesselData={drillVessel!}
              hasMTIScore={hasMTIScore}
              hasPtracAccess={hasPtracAccess}
            />
          )
        }
        extraActions={
          drillVessel && (
            <div className="mt-auto border-gray-200 dark:border-gray-700">
              <button
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-gray-200 bg-white py-2 text-sm font-medium text-gray-900 transition-colors hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700 dark:disabled:hover:bg-gray-800"
                onClick={() =>
                  navigate(
                    `/analytics/vessel/${drillVessel?.vessel_information.imo}`,
                  )
                }
              >
                Full Details
                <FaArrowRight className={`text-gray-500`} />
              </button>
            </div>
          )
        }
      />
    </div>
  );
}
