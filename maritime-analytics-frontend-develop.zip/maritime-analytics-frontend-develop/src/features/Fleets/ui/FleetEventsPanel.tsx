import { ColDef } from 'ag-grid-community';
import { FlatFleetEventsResponse } from '@/features/Fleets/types/fleetEventTypes';
import NewEventsPanel from '@/shared/ui/NewEventsPanel';

interface FleetEventsPanelProps {
  fleetName?: string;
  fleetId: string;
  fleetEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  buildColumns: (timezone: string) => ColDef[];
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatFleetEventsResponse) => void;
  renderExtras?: React.ReactNode;
}
export function FleetEventsPanel({
  fleetEventsTabs,
  storageKey,
  onSelectAll,
  selected,
  onToggle,
  rows,
  refresh,
  setRefresh,
  buildColumns,
  lastUpdated,
  isLoading,
  fleetId,
  onRowClick,
  renderExtras,
}: FleetEventsPanelProps) {
  return (
    <NewEventsPanel
      eventsTabs={fleetEventsTabs}
      selected={selected}
      onToggle={onToggle}
      onSelectAll={onSelectAll}
      rows={rows}
      refresh={refresh}
      setRefresh={setRefresh}
      buildColumns={buildColumns}
      storageKey={storageKey}
      lastUpdated={lastUpdated}
      isLoading={isLoading}
      entityId={fleetId}
      entityType="fleet"
      columnReset={true}
      onRowClick={onRowClick}
      renderExtras={renderExtras}
    />
  );
}
