import { describe, it, expect } from 'vitest';
import { fleetRoutes } from '@/features/Fleets/routes/FleetRoutes';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';
import { ProtectedRoute } from '@/shared/routes/ProtectedRoutes';

describe('fleetRoutes', () => {
  it('defines three fleet routes', () => {
    expect(fleetRoutes).toHaveLength(3);
  });

  it('uses the correct path for the fleet detail route', () => {
    expect(fleetRoutes[0].path).toBe('/analytics/fleet/:id');
  });

  it('uses the correct path for the fleet edit route', () => {
    expect(fleetRoutes[1].path).toBe('/analytics/fleet/:id/edit');
  });

  it('uses the correct path for the fleet create route', () => {
    expect(fleetRoutes[2].path).toBe('/analytics/fleet/new');
  });

  it.each([0, 1, 2])(
    'wraps route %i in ProtectedRoute around a SuspenseWrapper around a lazy component',
    (index) => {
      const element = fleetRoutes[index].element;

      expect(element.type).toBe(ProtectedRoute);
      expect(element.props.group).toEqual(['fleet-management']);

      const suspenseElement = element.props.children;
      expect(suspenseElement.type).toBe(SuspenseWrapper);

      const child = suspenseElement.props.children;
      expect(child.type).toBeDefined();
      expect(child.type.$$typeof).toBe(Symbol.for('react.lazy'));
    },
  );
});
