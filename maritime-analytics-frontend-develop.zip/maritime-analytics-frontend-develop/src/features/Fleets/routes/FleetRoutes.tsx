import { lazy } from 'react';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';
import { ProtectedRoute } from '@/shared/routes/ProtectedRoutes';
const FleetPage = lazy(() => import('@/features/Fleets/pages/FleetPage'));
const FleetCreatePage = lazy(
  () => import('@/features/Fleets/pages/FleetCreatePage'),
);

export const fleetRoutes = [
  {
    path: '/analytics/fleet/:id',
    element: (
      <ProtectedRoute group={['fleet-management']}>
        <SuspenseWrapper>
          <FleetPage />
        </SuspenseWrapper>
      </ProtectedRoute>
    ),
  },
  {
    path: '/analytics/fleet/:id/edit',
    element: (
      <ProtectedRoute group={['fleet-management']}>
        <SuspenseWrapper>
          <FleetCreatePage />
        </SuspenseWrapper>
      </ProtectedRoute>
    ),
  },
  {
    path: '/analytics/fleet/new',
    element: (
      <ProtectedRoute group={['fleet-management']}>
        <SuspenseWrapper>
          <FleetCreatePage />
        </SuspenseWrapper>
      </ProtectedRoute>
    ),
  },
];
