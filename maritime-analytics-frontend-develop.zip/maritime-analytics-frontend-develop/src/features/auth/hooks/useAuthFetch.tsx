import { fetchWithAuth } from '@/features/auth/utils/authUtil';

export const useAuthFetch = () => fetchWithAuth;
