import { describe, it, expect, vi } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mock (REQUIRED for vi.mock factory) */
/* ------------------------------------------------------------------ */

const { fetchWithAuthMock } = vi.hoisted(() => ({
  fetchWithAuthMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Module mock */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: fetchWithAuthMock,
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import { useAuthFetch } from '@/features/auth/hooks/useAuthFetch';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('useAuthFetch', () => {
  it('returns fetchWithAuth function reference', () => {
    const result = useAuthFetch();

    expect(result).toBe(fetchWithAuth);
  });
});
