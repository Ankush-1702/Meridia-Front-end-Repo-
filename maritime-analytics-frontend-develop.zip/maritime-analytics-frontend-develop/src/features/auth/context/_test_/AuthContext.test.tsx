import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

import {
  ACCESS_TOKEN_KEY,
  KEEP_LOGGED_IN_KEY,
  REFRESH_TOKEN_KEY,
  USER_DETAILS_KEY,
} from '@/app/constants/constants';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const {
  signInMock,
  signOutMock,
  refreshTokenMock,
  mfaVerificationHandlerMock,
  showToastMock,
  handleApiErrorMock,
  pushUserDataToGtmMock,
} = vi.hoisted(() => ({
  signInMock: vi.fn(),
  signOutMock: vi.fn(),
  refreshTokenMock: vi.fn(),
  mfaVerificationHandlerMock: vi.fn(),
  showToastMock: vi.fn(),
  handleApiErrorMock: vi.fn(),
  pushUserDataToGtmMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/services/auth', () => ({
  signIn: signInMock,
  signOut: signOutMock,
  refreshToken: refreshTokenMock,
  mfaVerificationHandler: mfaVerificationHandlerMock,
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: showToastMock,
  }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/shared/utils/gtmUtils', () => ({
  pushUserDataToGTM: pushUserDataToGtmMock,
}));

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  parseJwt: () => ({
    'cognito:groups': ['admin'],
  }),
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import { AuthProvider, useAuth } from '@/features/auth/context/AuthContext';

/* ------------------------------------------------------------------ */
/* Test helper */
/* ------------------------------------------------------------------ */

function TestComponent() {
  const { isAuthenticated, authChecked, login, logout, mfaVerification } =
    useAuth();

  return (
    <div>
      <div>authChecked:{String(authChecked)}</div>
      <div>authenticated:{String(isAuthenticated)}</div>

      <button onClick={() => login('test@test.com', 'password')}>login</button>

      <button onClick={() => logout()}>logout</button>

      <button onClick={() => mfaVerification('123456')}>mfa</button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('AuthProvider', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    // These are called with .catch() — they must return Promises
    pushUserDataToGtmMock.mockResolvedValue(undefined);
    signOutMock.mockResolvedValue(undefined);
  });

  it('sets authChecked to true on mount', async () => {
    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    );

    await waitFor(() => {
      expect(screen.getByText('authChecked:true')).toBeInTheDocument();
    });
  });

  it('logs in successfully without MFA', async () => {
    signInMock.mockResolvedValueOnce({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
      id: '1',
      name: 'John',
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    );

    fireEvent.click(screen.getByText('login'));

    await waitFor(() => {
      expect(screen.getByText('authenticated:true')).toBeInTheDocument();
    });

    expect(localStorage.getItem(ACCESS_TOKEN_KEY)).toBe('access-token');
    expect(localStorage.getItem(REFRESH_TOKEN_KEY)).toBe('refresh-token');
  });

  it('verifies MFA successfully', async () => {
    localStorage.setItem('mfa_email', 'test@test.com');
    localStorage.setItem('mfa_session', 'session');

    mfaVerificationHandlerMock.mockResolvedValueOnce({
      access_token: 'access',
      refresh_token: 'refresh',
      id: '1',
      name: 'John',
    });

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    );

    fireEvent.click(screen.getByText('mfa'));

    await waitFor(() => {
      expect(screen.getByText('authenticated:true')).toBeInTheDocument();
    });
  });

  it('clears tokens and user data from localStorage immediately on logout (no timer race)', async () => {
    // Seed auth data as it would exist after a successful login
    localStorage.setItem(ACCESS_TOKEN_KEY, 'access-token');
    localStorage.setItem(REFRESH_TOKEN_KEY, 'refresh-token');
    localStorage.setItem(USER_DETAILS_KEY, JSON.stringify({ id: '1' }));
    localStorage.setItem(KEEP_LOGGED_IN_KEY, 'true');

    signOutMock.mockResolvedValue(undefined);

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    );

    // Trigger logout
    fireEvent.click(screen.getByText('logout'));

    // Storage must be cleared SYNCHRONOUSLY — no fake timer advance needed.
    // This is the regression guard: previously localStorage.clear() was inside
    // a 500 ms setTimeout that navigation would kill before it fired.
    expect(localStorage.getItem(ACCESS_TOKEN_KEY)).toBeNull();
    expect(localStorage.getItem(REFRESH_TOKEN_KEY)).toBeNull();
    expect(localStorage.getItem(USER_DETAILS_KEY)).toBeNull();

    // React state should also reflect the logout immediately
    await waitFor(() => {
      expect(screen.getByText('authenticated:false')).toBeInTheDocument();
    });
  });
});
