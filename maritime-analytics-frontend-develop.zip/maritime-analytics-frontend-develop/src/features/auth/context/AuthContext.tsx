import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';

import { ensureTokenRefreshed } from '../utils/authUtil';
import {
  ACCESS_TOKEN_KEY,
  KEEP_LOGGED_IN_KEY,
  REFRESH_TOKEN_KEY,
  TIME_ZONE_KEY,
  USER_DETAILS_KEY,
} from '@/app/constants/constants';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  mfaVerificationHandler,
  signIn,
  signOut,
} from '@/features/auth/services/auth';
import { parseJwt } from '@/features/auth/utils/authTokenUtils';
import { MAP_LEGEND_STORAGE_KEY } from '@/features/mara/constants';
import { UserDetails } from '@/features/mara/types';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { pushUserDataToGTM } from '@/shared/utils/gtmUtils';
import { logger } from '@/shared/utils/logger';

interface AuthContextType {
  isAuthenticated: boolean;
  authChecked: boolean;
  login: (
    username: string,
    password: string,
  ) => Promise<{ success: boolean; mfa_enabled?: boolean }>;
  logout: (silent?: boolean) => void;
  accessToken: string | null;
  user: UserDetails | null;
  userGroups: string[];
  mfaVerification: (mfa_code: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserDetails | null>(null);
  const [userGroups, setUserGroups] = useState<string[]>([]);
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout>>();

  const scheduleTokenRefresh = useCallback((token: string) => {
    const payload = parseJwt(token);
    if (!payload?.exp) return;
    const refreshAt = (payload.exp as number) * 1000 - Date.now() - 60_000;
    if (refreshAt <= 0) return;
    clearTimeout(refreshTimerRef.current);
    refreshTimerRef.current = setTimeout(async () => {
      if (localStorage.getItem(KEEP_LOGGED_IN_KEY) !== 'true') return;
      if (!localStorage.getItem(REFRESH_TOKEN_KEY)) return;
      try {
        // Use shared single-flight refresh — coordinates with fetchWithAuth
        const newToken = await ensureTokenRefreshed();
        if (!newToken) return;
        setAccessToken(newToken);
        scheduleTokenRefresh(newToken);
      } catch (err) {
        logger.error('[AuthContext] Background token refresh failed', err);
      }
    }, refreshAt);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);
    const storedUser = localStorage.getItem(USER_DETAILS_KEY);

    if (token) {
      setAccessToken(token);
      setIsAuthenticated(true);
      scheduleTokenRefresh(token);
    }

    if (storedUser) {
      const userInfo = JSON.parse(storedUser);
      setUser(userInfo);

      if (token) {
        pushUserDataToGTM(userInfo).catch((error) => {
          console.error('GTM: Failed to push user data to dataLayer:', error);
        });
      }
    }

    setAuthChecked(true);
    if (token) {
      const payload = parseJwt(token);
      setUserGroups(
        Array.isArray(payload?.['cognito:groups'])
          ? payload['cognito:groups']
          : [],
      );
    }
  }, [scheduleTokenRefresh]);

  useEffect(() => {
    if (accessToken) {
      const payload = parseJwt(accessToken);
      setUserGroups(
        Array.isArray(payload?.['cognito:groups'])
          ? payload['cognito:groups']
          : [],
      );
    } else {
      setUserGroups([]);
    }
  }, [accessToken]);

  const login = async (
    email: string,
    password: string,
  ): Promise<{ success: boolean; mfa_enabled?: boolean }> => {
    let mfa_enabled = false;
    let success = false;
    try {
      const data = await signIn(email, password);
      if ('otp_recipient' in data && 'otp_channel' in data) {
        mfa_enabled = true;
        success = true;
        const { email } = data;
        localStorage.setItem('mfa_email', email);
        return { success, mfa_enabled };
      } else {
        const { access_token, refresh_token, ...userInfo } = data;
        success = true;

        localStorage.setItem(ACCESS_TOKEN_KEY, access_token);
        localStorage.setItem(REFRESH_TOKEN_KEY, refresh_token);
        localStorage.setItem(USER_DETAILS_KEY, JSON.stringify(userInfo));
        localStorage.setItem(
          MAP_LEGEND_STORAGE_KEY,
          JSON.stringify({
            'AIS Gap End': true,
            'AIS Gap Track': true,
            'AIS Gap Start': true,
            'Port Arrival': true,
            'Port Departure': true,
            'Positional Discrepancy': true,
            'STS Pairings': true,
            Separate: false,
            Blended: true,
          }),
        );
        localStorage.setItem(TIME_ZONE_KEY, 'system');

        setAccessToken(access_token);
        setIsAuthenticated(true);
        setUser(userInfo);
        scheduleTokenRefresh(access_token);

        pushUserDataToGTM(userInfo).catch((error) => {
          console.error('GTM: Failed to push user data to dataLayer:', error);
        });

        return { success, mfa_enabled };
      }
    } catch (err) {
      handleApiError(err);
      return { success };
    }
  };

  const logout = useCallback(
    (silent = false) => {
      clearTimeout(refreshTimerRef.current);

      // Capture the refresh token BEFORE wiping storage
      const rt = localStorage.getItem(REFRESH_TOKEN_KEY) || '';

      // Clear all auth state SYNCHRONOUSLY — no timers, so navigation can
      // never race ahead of the clear and leave stale tokens in localStorage
      setIsAuthenticated(false);
      setAccessToken(null);
      setUser(null);
      localStorage.clear();
      sessionStorage.clear();

      if (!silent) showToast('info', 'Logging out...', 1500);

      // Fire-and-forget background signOut — errors are non-fatal
      signOut(rt).catch((err) => {
        logger.warn('[AuthContext] Background signOut failed', err);
      });
    },
    [showToast],
  );

  const mfaVerification = async (mfa_code: string): Promise<boolean> => {
    try {
      const session = localStorage.getItem('mfa_session');
      const email = localStorage.getItem('mfa_email');
      if (!email || !session) return false;
      const data = await mfaVerificationHandler(email, mfa_code, session!);
      localStorage.removeItem('mfa_email');
      localStorage.removeItem('mfa_session');

      const { access_token, refresh_token, ...userInfo } = data;
      localStorage.setItem(ACCESS_TOKEN_KEY, access_token);
      localStorage.setItem(REFRESH_TOKEN_KEY, refresh_token);
      localStorage.setItem(USER_DETAILS_KEY, JSON.stringify(userInfo));
      localStorage.setItem(
        MAP_LEGEND_STORAGE_KEY,
        JSON.stringify({
          'AIS Gap End': true,
          'AIS Gap Track': true,
          'AIS Gap Start': true,
          'Port Arrival': true,
          'Port Departure': true,
          'Positional Discrepancy': true,
          'STS Pairings': true,
          Separate: false,
          Blended: true,
        }),
      );
      localStorage.setItem(TIME_ZONE_KEY, 'system');

      setAccessToken(access_token);
      setIsAuthenticated(true);
      setUser(userInfo);
      scheduleTokenRefresh(access_token);

      pushUserDataToGTM(userInfo).catch((error) => {
        console.error('GTM: Failed to push user data to dataLayer:', error);
      });

      return true;
    } catch (err) {
      console.error('MFA verification failed', err);
      return false;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        authChecked,
        login,
        logout,
        accessToken,
        user,
        userGroups,
        mfaVerification,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
