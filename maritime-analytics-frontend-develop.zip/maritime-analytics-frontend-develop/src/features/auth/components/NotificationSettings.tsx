import { ToggleSwitch } from 'flowbite-react';

interface Props {
  notificationSettings: boolean;
  setNotificationSettings: (value: boolean) => void;
  isNotificationUnchanged: boolean;
  handleNotificationSettingsSave: () => void;
  handleNotificationSettingsCancel: () => void;
}

const NotificationSettings = ({
  notificationSettings,
  setNotificationSettings,
  isNotificationUnchanged,
  handleNotificationSettingsSave,
  handleNotificationSettingsCancel,
}: Props) => {
  return (
    <div className="mx-6 mt-12 rounded-lg bg-white shadow-md dark:bg-gray-800 dark:text-white">
      <div className="border-b px-8 py-6 dark:border-b-gray-700">
        <h2 className="text-lg font-semibold">Notifications</h2>
        <p className="text-sm text-gray-500">
          Control how you receive notifications in Meridia.
        </p>
      </div>

      <div className="flex flex-col gap-10 border-b p-8 dark:border-b-gray-700">
        <div className="flex gap-2">
          <ToggleSwitch
            className="flex items-start"
            checked={notificationSettings ?? true}
            onChange={(checked) => setNotificationSettings(checked)}
            sizing="sm"
            color={`psg`}
          />

          <div>
            <h3 className="text-sm font-medium text-black dark:text-white">
              Show Notification Pop-ups
            </h3>
            <p className="text-sm text-gray-500">
              Display pop-ups in the bottom-left corner when new notifications
              arrive.
            </p>
            <p className="text-sm text-gray-500">
              Notifications will still appear on the Notifications page.
            </p>
          </div>
        </div>
      </div>

      <div className="flex gap-3 px-8 py-6">
        <button
          disabled={isNotificationUnchanged}
          onClick={handleNotificationSettingsSave}
          className={`h-[37px] w-[118px] rounded-md ${
            isNotificationUnchanged
              ? 'bg-psg-orange-500 text-gray-500'
              : 'bg-psg-orange-700 text-white hover:bg-psg-orange-600'
          } px-2 py-2 text-sm`}
        >
          Save Changes
        </button>

        <button
          onClick={handleNotificationSettingsCancel}
          disabled={isNotificationUnchanged}
          className={`h-[37px] w-[71px] rounded-md border border-gray-400 text-sm ${
            isNotificationUnchanged
              ? 'bg-gray-100 text-gray-400 dark:bg-gray-700'
              : 'bg-white text-black hover:bg-gray-200 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700'
          }`}
        >
          Reset
        </button>
      </div>
    </div>
  );
};

export default NotificationSettings;
