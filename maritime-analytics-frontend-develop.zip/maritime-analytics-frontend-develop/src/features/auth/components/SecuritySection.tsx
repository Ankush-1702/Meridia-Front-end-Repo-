import ChangePasswordForm from '@/features/auth/components/ChangePasswordForm';

interface Props {
  showForm: boolean;
  setShowForm: (value: boolean) => void;
  handlePasswordReset: () => void;
}

const SecuritySection = ({
  showForm,
  setShowForm,
  handlePasswordReset,
}: Props) => {
  return (
    <div className="m-6 rounded-lg bg-white shadow-md dark:bg-gray-800 dark:text-white">
      <div className="border-b px-8 py-6 dark:border-b-gray-700">
        <h2 className="mb-2 text-lg font-semibold">Security</h2>
        <p className="text-sm text-gray-500">
          Manage your password and account security.
        </p>
      </div>

      <div className="flex flex-col gap-10 p-8">
        <div>
          <h3 className="text-sm font-medium text-black dark:text-white">
            Password Reset
          </h3>
          <p className="text-sm font-normal text-gray-500 dark:text-gray-400">
            Reset your password using the form below.
          </p>
          <div className="mt-4">
            {!showForm ? (
              <button
                className="flex items-center justify-between gap-3 rounded-md border border-gray-400 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-200 dark:text-gray-100  dark:hover:bg-gray-500"
                onClick={handlePasswordReset}
                type="button"
              >
                Reset Password
              </button>
            ) : (
              <div className="w-[500px]">
                <ChangePasswordForm setShowForm={setShowForm} />
              </div>
            )}
          </div>
        </div>
        {/* <div>
            <h3 className="text-sm font-medium text-black dark:text-white">
              Two-Factor Authentication
            </h3>
            <p className="text-sm font-normal text-gray-500 dark:text-gray-400">
              Adds an extra layer of security at login using a second step
              beyond your password.
            </p>
            <div className="mt-4">
              {!showMfa ? (
                <button
                  className="flex items-center justify-between gap-3 rounded-md border border-gray-400 px-4 py-2 text-sm font-medium text-gray-900 hover:bg-gray-200 dark:text-gray-100  dark:hover:bg-gray-500"
                  onClick={() => setShowMfa(true)}
                >
                  Set up 2FA
                </button>
              ) : (
                <MfaSettings setShowMfa={setShowMfa}/>
              )}
            </div>
          </div> */}
      </div>
    </div>
  );
};

export default SecuritySection;
