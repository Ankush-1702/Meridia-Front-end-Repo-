import { Theme } from '@/app/context/ThemeProvider';
import AccountsTabs from '@/features/auth/components/AccountsTabs';

interface GeneralSettingsProps {
  activeThemeTab: Theme;
  activeTimeZoneTab: string;
  handleThemeChange: (tab: string) => void;
  handleTimeZoneChange: (tab: string) => void;
  handleSave: () => void;
  handleCancel: () => void;
  isThemeUnchanged: boolean;
  isTzUnchanged: boolean;
}
const GeneralSettings = ({
  activeThemeTab,
  activeTimeZoneTab,
  handleThemeChange,
  handleTimeZoneChange,
  handleSave,
  handleCancel,
  isThemeUnchanged,
  isTzUnchanged,
}: GeneralSettingsProps) => {
  return (
    <div className="m-6 -mb-6 mt-[72px] rounded-lg bg-white shadow-md dark:bg-gray-800 dark:text-white">
      <div className="border-b px-8 py-6 dark:border-b-gray-700">
        <h2 className="text-lg font-semibold">General</h2>
      </div>

      <div className="flex flex-col gap-10 border-b p-8 dark:border-b-gray-700">
        {/* TIME ZONE */}
        <div>
          <h3 className="text-sm font-medium text-black dark:text-white">
            Time Zone
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Choose how dates and times are displayed throughout the application.
          </p>
          <div className="mt-4">
            <AccountsTabs
              tabs={['system', 'utc']}
              active={activeTimeZoneTab}
              onChange={handleTimeZoneChange}
            />
          </div>
        </div>

        {/* THEME */}
        <div>
          <h3 className="text-sm font-medium text-black dark:text-white">
            Theme
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Choose whether the application should match your system theme or use
            light or dark mode.
          </p>
          <div className="mt-4">
            <AccountsTabs
              tabs={['system', 'light', 'dark']}
              active={activeThemeTab}
              onChange={handleThemeChange}
            />
          </div>
        </div>
      </div>

      {/* ACTION BUTTONS */}
      <div className="flex gap-3 px-8 py-6">
        <button
          disabled={isThemeUnchanged && isTzUnchanged}
          onClick={handleSave}
          className={`h-[37px] w-[118px] rounded-md ${
            isThemeUnchanged && isTzUnchanged
              ? 'bg-psg-orange-500 text-gray-500'
              : 'bg-psg-orange-700 text-white hover:bg-psg-orange-600'
          } px-2 py-2 text-sm`}
        >
          Save Changes
        </button>

        <button
          onClick={handleCancel}
          disabled={isThemeUnchanged && isTzUnchanged}
          className={`h-[37px] w-[71px] rounded-md border border-gray-400 text-sm ${
            isThemeUnchanged && isTzUnchanged
              ? 'bg-gray-100 text-gray-400 dark:bg-gray-700'
              : 'bg-white text-black hover:bg-gray-200 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700'
          }`}
        >
          Reset
        </button>
      </div>
    </div>
  );
};

export default GeneralSettings;
