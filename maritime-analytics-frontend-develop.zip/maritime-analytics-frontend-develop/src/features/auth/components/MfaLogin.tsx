import { Button, Label, Spinner, TextInput } from 'flowbite-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router';
import { KEEP_LOGGED_IN_KEY } from '@/app/constants/constants';
import { useAuth } from '@/features/auth/context/AuthContext';
import { sendPasswordResetOtp } from '@/features/auth/services/auth';
import MeridiaLogo from '@/shared/assets/MeridiaLogo';
import { handleKeyPrevents } from '@/shared/utils/inputHandler';

interface FormValues {
  otp: string;
}

export default function MfaLogin({ keepLoggedIn }: { keepLoggedIn: boolean }) {
  const { mfaVerification } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const email = localStorage.getItem('mfa_email');
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isValid },
  } = useForm<FormValues>({
    mode: 'all',
    criteriaMode: 'all',
    shouldFocusError: true,
  });

  const handleOnSubmit = async (data: FormValues) => {
    setLoading(true);
    try {
      const res = await mfaVerification(data.otp);
      if (res) {
        localStorage.setItem(KEEP_LOGGED_IN_KEY, String(keepLoggedIn));
        navigate('/', { replace: true });
      } else {
        alert('Invalid OTP');
      }
    } catch (error) {
      console.error('Reset Password API error:', error); //check error handling
      const errorMessage = (error as Error).message;
      if (errorMessage === 'Provided OTP is invalid') {
        setError('otp', { message: 'Invalid OTP', type: 'server' });
      } else if (errorMessage === 'OTP has expired already') {
        setError('otp', { message: 'Code expired', type: 'server' });
      }
    } finally {
      setLoading(false);
    }
  };

  const sendOtp = async () => {
    try {
      await sendPasswordResetOtp(email!);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-cover bg-center dark:bg-gray-900">
      <form
        onSubmit={handleSubmit(handleOnSubmit)}
        className="w-full max-w-sm rounded bg-white bg-opacity-60 p-6 shadow dark:bg-gray-800 dark:bg-opacity-90 dark:shadow-lg"
      >
        <div className="mb-4 flex items-center justify-center gap-2 text-xl font-semibold text-gray-800 dark:text-gray-100">
          <MeridiaLogo className="h-5 w-5" />
          <span
            className="text-gray-800 dark:text-gray-100"
            style={{ fontFamily: 'Unbounded' }}
          >
            MERIDIA
          </span>
        </div>
        <div className="mb-4 flex flex-col items-center justify-center gap-2 font-semibold text-gray-800 dark:text-gray-100">
          <span className="text-lg">Verify your identity</span>
          <p className="flex flex-col gap-2 text-sm font-normal">
            Enter the code sent to your email
            <span className="text-sm font-semibold text-gray-500 dark:text-gray-500">
              The code is valid for 10 minutes
            </span>
          </p>
        </div>
        <div className="mb-2">
          <Label
            htmlFor="otp"
            value="Verification Code"
            className=""
            color={errors.otp ? 'failure' : undefined}
          />
          <TextInput
            id="otp"
            color={errors.otp ? 'failure' : undefined}
            type="text"
            {...register('otp', {
              required: 'Verification code is required.',
              pattern: {
                value: /^[0-9]{6}$/,
                message: 'Invalid OTP format',
              },
            })}
            required
            inputMode="numeric"
            maxLength={6}
            className="rounded-lg border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-900"
            onKeyDown={handleKeyPrevents}
          />
          {errors.otp ? (
            <p className="mt-4 text-sm text-red-600">
              {errors.otp.type === 'server'
                ? errors.otp.message === 'Invalid OTP'
                  ? 'Code invalid. Please try again or '
                  : 'Code expired. '
                : 'Code Invalid. Please try again or '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          ) : (
            <p className="mt-2 text-sm text-gray-500">
              Didn't receive an email or code expired?{' '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          )}
        </div>
        <Button
          type="submit"
          // color="primary"
          className="flex w-full items-center justify-center  bg-psg-orange-700 text-white enabled:hover:bg-psg-orange-600"
          disabled={loading || !isValid}
        >
          {loading ? (
            <>
              <Spinner size="sm" light color={`gray`} className="mr-2" />
              Signing in...
            </>
          ) : (
            'Sign in'
          )}
        </Button>
        <div className="mt-4 text-center">
          <a
            href="/reset-password"
            className="text-sm text-gray-500 underline hover:text-psg-orange-700"
          >
            Forgotten Password?
          </a>
        </div>
      </form>
    </div>
  );
}
