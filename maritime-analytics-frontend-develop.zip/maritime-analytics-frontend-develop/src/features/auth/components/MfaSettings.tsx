import { Label, Radio, TextInput } from 'flowbite-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { IoIosCheckmarkCircle } from 'react-icons/io';
import { handleKeyPrevents } from '@/shared/utils/inputHandler';

type MFAOptions = 'Email' | 'Authentication App';
type FormValues = {
  otp: string;
  newPassword: string;
  confirmNewPassword: string;
};
export default function MfaSettings({
  setShowMfa,
}: {
  setShowMfa: (value: boolean) => void;
}) {
  const [showMfaForm, setShowMfaForm] = useState<boolean>(false);
  const [showMFASuccessful, setShowMFASuccessful] = useState<boolean>(false);
  return (
    <div>
      {!showMFASuccessful ? (
        !showMfaForm ? (
          <MfaSettingsStep1
            setShowMfa={setShowMfa}
            setShowMfaForm={setShowMfaForm}
          />
        ) : (
          <MfaSettingsStep2EmailConfiguration
            setShowMfaForm={setShowMfaForm}
            setShowMFASuccessful={setShowMFASuccessful}
          />
        )
      ) : (
        <MfaSettingsSuccessful setShowMfa={setShowMfa} />
      )}
    </div>
  );
}

function MfaSettingsStep1({
  setShowMfa,
  setShowMfaForm,
}: {
  setShowMfa: (value: boolean) => void;
  setShowMfaForm: (value: boolean) => void;
}) {
  const [mfaOption, setMfaOption] = useState<MFAOptions>('Email');
  return (
    <div className="w-[164px]">
      <div className="text-sm font-medium text-black dark:text-white">
        <h1>Select your 2FA method.</h1>
      </div>
      <div className="mt-4 space-y-2">
        {['Email', 'Authentication App'].map((option) => (
          <Label key={option} className="flex  items-center gap-2">
            <Radio
              name="MFA"
              value={option}
              checked={mfaOption === option}
              onChange={(e) => setMfaOption(e.target.value as MFAOptions)}
              disabled={option === 'Authentication App'}
            />
            {option}
          </Label>
        ))}
      </div>
      <div className="mt-4 flex gap-3">
        <button
          onClick={() => setShowMfaForm(true)}
          className={`h-[37px] w-[118-px] rounded-md bg-primary-600 px-2 py-2 text-sm text-white hover:bg-primary-500`}
        >
          Continue
        </button>
        <button
          onClick={() => setShowMfa(false)}
          className={`h-[37px] w-[71px] rounded-md border border-gray-400 bg-white text-sm text-black hover:bg-gray-200 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700`}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}

function MfaSettingsStep2EmailConfiguration({
  setShowMfaForm,
  setShowMFASuccessful,
}: {
  setShowMfaForm: (value: boolean) => void;
  setShowMFASuccessful: (value: boolean) => void;
}) {
  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors, isValid },
  } = useForm<FormValues>({
    mode: 'all',
    criteriaMode: 'all',
    shouldFocusError: true,
  });

  const onSubmit = (data: FormValues) => {
    try {
      console.log(data);
    } catch (err) {
      console.error('Reset Password API error:', err); //check error handling
      const errorMessage = (err as Error).message;
      if (errorMessage === 'Provided OTP is invalid') {
        setError('otp', { message: 'Invalid OTP', type: 'server' });
      } else if (errorMessage === 'OTP has expired already') {
        setError('otp', { message: 'Code expired', type: 'server' });
      }
    }
  };

  const sendOtp = async () => {
    console.log('otp sent');
  };

  const handleCancel = () => {
    reset();
    setShowMfaForm(false);
  };
  return (
    <div>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="space-y-4 rounded-xl bg-white dark:bg-gray-800"
      >
        <div className="flex h-fit w-[420px] flex-col gap-1 rounded-lg bg-gray-50 p-4 text-sm dark:bg-gray-700">
          <p className="flex flex-col gap-2 font-semibold text-gray-800">
            Enter the code sent to your email address.
            <span className="font-normal text-gray-500">
              The code is valid for 10 minutes.
            </span>
          </p>
        </div>

        <div>
          <Label
            htmlFor="otp"
            value="Verification Code"
            className=""
            color={errors.otp ? 'failure' : undefined}
          />
          <TextInput
            id="otp"
            color={errors.otp ? 'failure' : undefined}
            type="number"
            {...register('otp', {
              required: 'Verification code is required.',
              pattern: {
                value: /^[0-9]{6}$/,
                message: 'Invalid OTP format',
              },
            })}
            required
            className="mt-1 h-[37px] w-[420px]"
            onKeyDown={handleKeyPrevents}
          />
          {errors.otp ? (
            <p className="mt-4 text-sm text-red-600">
              {errors.otp.type === 'server'
                ? errors.otp.message === 'Invalid OTP'
                  ? 'Code invalid. Please try again or '
                  : 'Code expired. '
                : 'Code Invalid. Please try again or '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          ) : (
            <p className="mt-2 text-sm text-gray-500">
              Didn't receive an email or code expired?{' '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          )}
        </div>
        <div className="flex gap-3 pt-2">
          <button
            className="flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500 dark:text-gray-100  dark:hover:bg-gray-500"
            onClick={() => setShowMFASuccessful(true)}
            disabled={!isValid}
          >
            Continue
          </button>
          <button
            onClick={handleCancel}
            className={`h-[37px] w-[71px] rounded-md border border-gray-400 bg-white  text-sm text-black hover:bg-gray-200 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700`}
          >
            Back
          </button>
        </div>
      </form>
    </div>
  );
}

function MfaSettingsSuccessful({
  setShowMfa,
}: {
  setShowMfa: (value: boolean) => void;
}) {
  return (
    <div className="flex w-fit flex-col gap-3">
      <div className="flex items-center justify-center gap-2">
        <IoIosCheckmarkCircle className="h-5 w-5 rounded bg-white text-green-500" />
        <p className="text-sm font-medium text-black dark:text-white">
          Two Factor authentication has been added to your account
        </p>
      </div>
      <button
        className="flex h-[37px] w-[85px] items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500 dark:text-gray-100  dark:hover:bg-gray-500"
        onClick={() => setShowMfa(false)}
      >
        Continue
      </button>
    </div>
  );
}
