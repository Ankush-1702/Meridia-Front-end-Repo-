import { Label, TextInput, Tooltip } from 'flowbite-react';
import { useForm } from 'react-hook-form';
import { FaInfoCircle } from 'react-icons/fa';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useAuth } from '@/features/auth/context/AuthContext';
import {
  resetPassword,
  sendPasswordResetOtp,
} from '@/features/auth/services/auth';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { handleKeyPrevents } from '@/shared/utils/inputHandler';

type FormValues = {
  otp: string;
  newPassword: string;
  confirmNewPassword: string;
};

interface ChangePasswordFormProps {
  setShowForm?: (value: boolean) => void;
}

const ChangePasswordForm = ({ setShowForm }: ChangePasswordFormProps) => {
  const {
    register,
    handleSubmit,
    watch,
    reset,
    setError,
    formState: { errors, isValid },
  } = useForm<FormValues>({
    mode: 'all',
    criteriaMode: 'all',
    shouldFocusError: true,
  });

  //   const [showForm, setShowForm] = useState(false);
  const { logout } = useAuth();
  const { showToast } = useToastNotification();
  const handleApiError = useApiErrorHandler();

  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const email = userProfile.email;

  const validatePassword = (password: string) =>
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\^$*.[\]{}()?"!@#%&/\\,><':;|_~`+= -])[a-zA-Z\d^$*.[\]{}()?"!@#%&/\\,><':;|_~`+= -]{8,}$/.test(
      password,
    );

  const sendOtp = async () => {
    try {
      await sendPasswordResetOtp(email);
    } catch (error) {
      handleApiError(error);
    }
  };

  const onSubmit = async (data: FormValues) => {
    const { otp, newPassword } = data;
    try {
      if (email && otp && newPassword) {
        await resetPassword(email, otp, newPassword);
        showToast(
          'success',
          'Password reset successfully. Logging you out...',
          5000,
        );
        logout();
        window.location.reload();
      }
    } catch (error) {
      console.error('Reset Password API error:', error); //check error handling
      const errorMessage = (error as Error).message;
      if (errorMessage === 'Provided OTP is invalid') {
        setError('otp', { message: 'Invalid OTP', type: 'server' });
      } else if (errorMessage === 'OTP has expired already') {
        setError('otp', { message: 'Code expired', type: 'server' });
      }
    }
  };

  const handleCancel = () => {
    setShowForm?.(false);
    reset();
  };

  return (
    <div>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="space-y-4 rounded-xl bg-white dark:bg-gray-800"
      >
        <div className="flex h-fit w-[420px] flex-col gap-1 rounded-lg bg-gray-50 p-4 text-sm dark:bg-gray-700">
          <h3 className="font-semibold">Verify your identity</h3>
          <p className="font-normal text-gray-500">
            Enter the code sent to your [2FA_METHOD], then choose a new
            password.{' '}
            <span className="font-bold text-gray-500">
              The code is valid for 10 minutes.
            </span>
          </p>
        </div>

        <div>
          <Label
            htmlFor="otp"
            value="Verification Code"
            className=""
            color={errors.otp ? 'failure' : undefined}
          />
          <TextInput
            id="otp"
            color={errors.otp ? 'failure' : undefined}
            type="number"
            {...register('otp', {
              required: 'Verification code is required.',
              pattern: {
                value: /^[0-9]{6}$/,
                message: 'Invalid OTP format',
              },
            })}
            required
            className="mt-1 h-[37px] w-[420px]"
            onKeyDown={handleKeyPrevents}
          />
          {errors.otp ? (
            <p className="mt-4 text-sm text-red-600">
              {errors.otp.type === 'server'
                ? errors.otp.message === 'Invalid OTP'
                  ? 'Code invalid. Please try again or '
                  : 'Code expired. '
                : 'Code Invalid. Please try again or '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          ) : (
            <p className="mt-2 text-sm text-gray-500">
              Didn't receive an email?{' '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          )}
        </div>

        <div className="relative w-[420px]">
          <div className="flex items-center gap-2">
            <Label
              htmlFor="newPassword"
              value="New Password"
              className=""
              color={errors.newPassword ? 'failure' : undefined}
            />
            <Tooltip
              content={
                <div className=" text-xs font-normal leading-relaxed text-white">
                  <p className="mb-0.5 font-bold">Password requirements</p>
                  <ul>
                    <li>At least 8 characters</li>
                    <li>Contains at least 1 number</li>
                    <li>Contains at least 1 special character</li>
                    <li>Contains at least 1 uppercase letter</li>
                    <li>Contains at least 1 lowercase letter</li>
                  </ul>
                </div>
              }
              placement="bottom"
              className="w-[230px]"
            >
              <FaInfoCircle className={`text-gray-400`} />
            </Tooltip>
          </div>

          <TextInput
            id="newPassword"
            type="password"
            color={errors.newPassword ? 'failure' : undefined}
            {...register('newPassword', {
              required: 'New password is required.',
              validate: (value) =>
                validatePassword(value) || 'Invalid password',
            })}
            className="mt-1 h-[37px] w-full" // Add padding-right to avoid overlap with icon
            required
          />

          {errors.newPassword?.message === 'Invalid password' && (
            <div className="mt-4 text-sm leading-snug text-red-600">
              <p className="font-normal">
                Password invalid. Password requirements:
              </p>
              <p>At least 8 characters</p>
              <p>Contains at least 1 number</p>
              <p>Contains at least 1 special character</p>
              <p>Contains at least 1 uppercase letter</p>
              <p>Contains at least 1 lowercase letter</p>
            </div>
          )}
        </div>

        <div>
          <Label
            htmlFor="confirmNewPassword"
            value="Confirm New Password"
            className=""
            color={errors.confirmNewPassword ? 'failure' : undefined}
          />
          <TextInput
            id="confirmNewPassword"
            type="password"
            color={errors.confirmNewPassword ? 'failure' : undefined}
            {...register('confirmNewPassword', {
              required: 'Please confirm your new password.',
              validate: (value) =>
                value === watch('newPassword') ||
                'This Password does not match.',
            })}
            className="mb-4 mt-1 h-[37px] w-[420px]"
          />
          {errors.confirmNewPassword && (
            <p className="text-sm text-red-600">
              {errors.confirmNewPassword.message}
            </p>
          )}
        </div>
        {/* <div className="mb-4 flex h-[53px] w-[420px] items-center justify-center gap-4 rounded-lg p-2 shadow-lg">
          <FaQuestionCircle height={'20px'} width={'20px'} color="#1C64F2" />
          <p className="text-sm text-gray-500">
            You will be logged out after changing your password
          </p>
        </div> */}
        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            className={`flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition-colors
      ${
        isValid
          ? 'bg-psg-orange-700 text-white hover:bg-psg-orange-600 dark:text-gray-100'
          : 'bg-psg-orange-500 text-gray-500'
      }`}
            disabled={!isValid}
          >
            Reset Password
          </button>

          <button
            onClick={handleCancel}
            className="h-[37px] w-[71px] rounded-md border border-gray-400 bg-white text-sm text-black transition-colors hover:bg-gray-200 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChangePasswordForm;
