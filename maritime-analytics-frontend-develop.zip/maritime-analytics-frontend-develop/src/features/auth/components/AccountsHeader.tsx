import Header from '@/shared/ui/Header';

export default function AccountsHeader({ headerText }: { headerText: string }) {
  return (
    <div className="fixed z-10 w-full bg-white dark:bg-gray-800">
      <Header headerText={headerText} />
    </div>
  );
}
