import { Spinner } from 'flowbite-react';
import { useState } from 'react';
import { HiArrowRightOnRectangle } from 'react-icons/hi2';
import { useAuth } from '@/features/auth/context/AuthContext';
import { useChatSession } from '@/features/mara/context/ChatSessionContext';
import { endSession } from '@/features/mara/services/sessionService';

export default function LogoutButton() {
  const [loading, setLoading] = useState(false);
  const { logout } = useAuth();
  const { newSessionId, userId } = useChatSession();

  const handleLogout = async () => {
    setLoading(true);
    try {
      if (!newSessionId || !userId) return;
      await endSession(newSessionId, userId);
      await logout();
      window.location.reload();
    } catch (err) {
      console.error('Logout failed', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleLogout}
      disabled={loading}
      className="flex h-[38px] w-[192px] items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
    >
      <HiArrowRightOnRectangle className="h-5 w-5 text-gray-500 dark:text-gray-400" />
      {loading ? (
        <span className="flex items-center">
          <Spinner size="sm" light color={'gray'} className="mr-2" />
          Signing out...
        </span>
      ) : (
        <span>Sign Out</span>
      )}
    </button>
  );
}
