import DataCard from '@/shared/ui/DataCard';

interface Props {
  personalInformationRows: {
    label: string;
    value: React.ReactNode;
  }[];
}
const PersonalInfoSection = ({ personalInformationRows }: Props) => {
  return (
    <div className="mx-6 mt-6 rounded-lg bg-white shadow-md dark:bg-gray-800 dark:text-white">
      <DataCard
        title="Personal"
        sections={[{ rows: personalInformationRows }]}
        subtitle="Your personal account details."
      />
    </div>
  );
};

export default PersonalInfoSection;
