import { capitalizeFirstLetter } from '@/shared/utils/formatUtils';

interface TabsProps {
  active: string;
  onChange: (tab: string) => void;
  tabs: string[];
}

export default function AccountsTabs({ tabs, active, onChange }: TabsProps) {
  return (
    <div className={`flex`}>
      {tabs.map((tab, index) => (
        <button
          key={tab}
          className={`border border-gray-200 px-4 py-2 text-sm dark:border-gray-700 ${
            active === tab
              ? 'bg-psg-orange-100 font-semibold text-psg-orange-700 dark:bg-gray-600'
              : 'bg-gray-50 text-gray-500 hover:bg-psg-orange-100 hover:text-psg-orange-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-psg-orange-700'
          } ${index === 0 ? 'rounded-l-lg' : index === tabs.length - 1 ? 'rounded-r-lg' : ''}`}
          onClick={() => onChange(tab.toLowerCase())}
        >
          {tab === 'utc'
            ? tab.toUpperCase()
            : (capitalizeFirstLetter(tab) as string)}
        </button>
      ))}
    </div>
  );
}
