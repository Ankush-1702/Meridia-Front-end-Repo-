import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mock: formatUtils */
/* ------------------------------------------------------------------ */

const { capitalizeFirstLetterMock } = vi.hoisted(() => ({
  capitalizeFirstLetterMock: vi.fn<(value: unknown) => string>(),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  capitalizeFirstLetter: capitalizeFirstLetterMock,
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import AccountsTabs from '@/features/auth/components/AccountsTabs';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('AccountsTabs', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    capitalizeFirstLetterMock.mockImplementation(
      (v) => String(v).charAt(0).toUpperCase() + String(v).slice(1),
    );
  });

  it('renders all tabs', () => {
    render(
      <AccountsTabs
        tabs={['overview', 'details', 'settings']}
        active="overview"
        onChange={vi.fn()}
      />,
    );

    expect(screen.getByText('Overview')).toBeInTheDocument();
    expect(screen.getByText('Details')).toBeInTheDocument();
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });

  it('renders UTC tab in uppercase', () => {
    render(<AccountsTabs tabs={['utc']} active="utc" onChange={vi.fn()} />);

    expect(screen.getByText('UTC')).toBeInTheDocument();
    expect(capitalizeFirstLetterMock).not.toHaveBeenCalled();
  });

  it('applies active styles to the active tab', () => {
    render(
      <AccountsTabs
        tabs={['overview', 'details']}
        active="details"
        onChange={vi.fn()}
      />,
    );

    const activeButton = screen.getByText('Details');

    expect(activeButton.className).toContain('font-semibold');
    expect(activeButton.className).toContain('text-psg-orange-700');
  });

  it('calls onChange with lowercase tab value when clicked', () => {
    const onChange = vi.fn();

    render(
      <AccountsTabs
        tabs={['Overview']}
        active="overview"
        onChange={onChange}
      />,
    );

    fireEvent.click(screen.getByText('Overview'));

    expect(onChange).toHaveBeenCalledOnce();
    expect(onChange).toHaveBeenCalledWith('overview');
  });

  it('applies rounded classes to first and last tabs', () => {
    render(
      <AccountsTabs
        tabs={['first', 'middle', 'last']}
        active="first"
        onChange={vi.fn()}
      />,
    );

    const first = screen.getByText('First');
    const middle = screen.getByText('Middle');
    const last = screen.getByText('Last');

    expect(first.className).toContain('rounded-l-lg');
    expect(middle.className).not.toContain('rounded-l-lg');
    expect(middle.className).not.toContain('rounded-r-lg');
    expect(last.className).toContain('rounded-r-lg');
  });

  it('calls capitalizeFirstLetter for non-UTC tabs', () => {
    render(
      <AccountsTabs
        tabs={['overview', 'details']}
        active="overview"
        onChange={vi.fn()}
      />,
    );

    expect(capitalizeFirstLetterMock).toHaveBeenCalledWith('overview');
    expect(capitalizeFirstLetterMock).toHaveBeenCalledWith('details');
  });
});
