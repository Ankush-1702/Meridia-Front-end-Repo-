import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks (important for Vitest) */
/* ------------------------------------------------------------------ */

const { logoutMock, endSessionMock, useChatSessionMock } = vi.hoisted(() => ({
  logoutMock: vi.fn(),
  endSessionMock: vi.fn(),
  useAuthMock: vi.fn(),
  useChatSessionMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', () => ({
  Spinner: () => <span>spinner</span>,
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => ({
    logout: logoutMock,
  }),
}));

vi.mock('@/features/mara/context/ChatSessionContext', () => ({
  useChatSession: () => useChatSessionMock(),
}));

vi.mock('@/features/mara/services/sessionService', () => ({
  endSession: endSessionMock,
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import LogoutButton from '@/features/auth/components/Logout';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('LogoutButton', () => {
  beforeEach(() => {
    vi.clearAllMocks();

    // default valid session
    useChatSessionMock.mockReturnValue({
      newSessionId: 'session-123',
      userId: 'user-456',
    });

    // mock window.location
    Object.defineProperty(window, 'location', {
      writable: true,
      value: { href: '', reload: vi.fn() },
    });
  });

  it('renders Sign Out button', () => {
    render(<LogoutButton />);

    expect(
      screen.getByRole('button', { name: /sign out/i }),
    ).toBeInTheDocument();
  });

  it('calls endSession, logout, and redirects on click', async () => {
    endSessionMock.mockResolvedValueOnce(undefined);
    logoutMock.mockResolvedValueOnce(undefined);

    render(<LogoutButton />);

    fireEvent.click(screen.getByRole('button', { name: /sign out/i }));

    // loading state
    expect(screen.getByText(/signing out/i)).toBeInTheDocument();

    await waitFor(() => {
      expect(endSessionMock).toHaveBeenCalledWith('session-123', 'user-456');
    });

    expect(logoutMock).toHaveBeenCalled();

    await waitFor(() => {
      expect(window.location.reload).toHaveBeenCalled();
    });
  });

  it('does not call endSession if session data is missing', async () => {
    useChatSessionMock.mockReturnValue({
      newSessionId: null,
      userId: null,
    });

    render(<LogoutButton />);

    fireEvent.click(screen.getByRole('button', { name: /sign out/i }));

    await waitFor(() => {
      expect(endSessionMock).not.toHaveBeenCalled();
      expect(logoutMock).not.toHaveBeenCalled();
    });
  });

  it('disables button while loading', async () => {
    // make endSession never resolve to keep loading=true
    endSessionMock.mockImplementation(() => new Promise(() => {}));

    render(<LogoutButton />);

    const button = screen.getByRole('button', {
      name: /sign out/i,
    });

    fireEvent.click(button);

    expect(button).toBeDisabled();
    expect(screen.getByText(/signing out/i)).toBeInTheDocument();
  });

  it('handles logout failure gracefully', async () => {
    endSessionMock.mockRejectedValueOnce(new Error('logout failed'));

    render(<LogoutButton />);

    fireEvent.click(screen.getByRole('button', { name: /sign out/i }));

    await waitFor(() => {
      expect(endSessionMock).toHaveBeenCalled();
    });

    // button should recover
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /sign out/i })).toBeEnabled();
    });
  });
});
