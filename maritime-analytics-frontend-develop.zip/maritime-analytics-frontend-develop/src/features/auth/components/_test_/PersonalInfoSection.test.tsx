import { render, screen } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/ui/DataCard', () => ({
  default: ({
    title,
    subtitle,
    sections,
  }: {
    title: string;
    subtitle?: string;
    sections: { rows: { label: string; value: React.ReactNode }[] }[];
  }) => (
    <div>
      <h2>{title}</h2>
      {subtitle && <p>{subtitle}</p>}

      {sections.map((section, sectionIndex) => (
        <div key={sectionIndex}>
          {section.rows.map((row, rowIndex) => (
            <div key={rowIndex}>
              <span>{row.label}</span>
              <span>{row.value}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  ),
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import PersonalInfoSection from '@/features/auth/components/PersonalInfoSection';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('PersonalInfoSection', () => {
  it('renders DataCard with title and subtitle', () => {
    render(
      <PersonalInfoSection
        personalInformationRows={[{ label: 'Name', value: 'John Doe' }]}
      />,
    );

    expect(screen.getByText('Personal')).toBeInTheDocument();
    expect(
      screen.getByText('Your personal account details.'),
    ).toBeInTheDocument();
  });

  it('renders all personal information rows', () => {
    render(
      <PersonalInfoSection
        personalInformationRows={[
          { label: 'Name', value: 'John Doe' },
          { label: 'Email', value: 'john@example.com' },
        ]}
      />,
    );

    expect(screen.getByText('Name')).toBeInTheDocument();
    expect(screen.getByText('John Doe')).toBeInTheDocument();

    expect(screen.getByText('Email')).toBeInTheDocument();
    expect(screen.getByText('john@example.com')).toBeInTheDocument();
  });

  it('renders ReactNode values correctly', () => {
    render(
      <PersonalInfoSection
        personalInformationRows={[
          {
            label: 'Status',
            value: <strong>Active</strong>,
          },
        ]}
      />,
    );

    expect(screen.getByText('Status')).toBeInTheDocument();
    expect(screen.getByText('Active')).toBeInTheDocument();
  });
});
