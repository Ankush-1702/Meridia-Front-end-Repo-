import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mock: Header */
/* ------------------------------------------------------------------ */

const { HeaderMock } = vi.hoisted(() => ({
  HeaderMock: vi.fn<(props: { headerText: string }) => JSX.Element>(),
}));

vi.mock('@/shared/ui/Header', () => ({
  default: (props: { headerText: string }) => {
    HeaderMock(props);
    return <div data-testid="header">{props.headerText}</div>;
  },
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import AccountsHeader from '@/features/auth/components/AccountsHeader';

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('AccountsHeader', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders Header with provided headerText', () => {
    render(<AccountsHeader headerText="Accounts" />);

    expect(HeaderMock).toHaveBeenCalledOnce();
    expect(HeaderMock).toHaveBeenCalledWith(
      expect.objectContaining({
        headerText: 'Accounts',
      }),
    );

    expect(screen.getByTestId('header')).toHaveTextContent('Accounts');
  });

  it('wraps Header in a fixed positioned container', () => {
    const { container } = render(<AccountsHeader headerText="Users" />);

    const wrapper = container.firstChild as HTMLElement;

    expect(wrapper).toHaveClass('fixed');
    expect(wrapper).toHaveClass('z-10');
    expect(wrapper).toHaveClass('w-full');
    expect(wrapper).toHaveClass('bg-white');
    expect(wrapper).toHaveClass('dark:bg-gray-800');
  });
});
