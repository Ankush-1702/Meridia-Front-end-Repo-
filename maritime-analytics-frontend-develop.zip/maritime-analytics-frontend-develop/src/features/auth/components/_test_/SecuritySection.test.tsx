import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

const setShowFormMock = vi.fn();
const handlePasswordResetMock = vi.fn();

vi.mock('@/features/auth/components/ChangePasswordForm', () => ({
  default: ({ setShowForm }: { setShowForm: (value: boolean) => void }) => (
    <div>
      <p>Change Password Form</p>
      <button onClick={() => setShowForm(false)}>Close Form</button>
    </div>
  ),
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import SecuritySection from '@/features/auth/components/SecuritySection';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function renderComponent(showForm = false) {
  return render(
    <SecuritySection
      showForm={showForm}
      setShowForm={setShowFormMock}
      handlePasswordReset={handlePasswordResetMock}
    />,
  );
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('SecuritySection', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders security section header and description', () => {
    renderComponent();

    expect(screen.getByText('Security')).toBeInTheDocument();
    expect(
      screen.getByText('Manage your password and account security.'),
    ).toBeInTheDocument();
  });

  it('renders password reset description', () => {
    renderComponent();

    expect(screen.getByText('Password Reset')).toBeInTheDocument();
    expect(
      screen.getByText('Reset your password using the form below.'),
    ).toBeInTheDocument();
  });

  it('shows Reset Password button when form is hidden', () => {
    renderComponent(false);

    expect(
      screen.getByRole('button', { name: /reset password/i }),
    ).toBeInTheDocument();
  });

  it('calls handlePasswordReset when Reset Password button is clicked', () => {
    renderComponent(false);

    fireEvent.click(screen.getByRole('button', { name: /reset password/i }));

    expect(handlePasswordResetMock).toHaveBeenCalledTimes(1);
  });

  it('renders ChangePasswordForm when showForm is true', () => {
    renderComponent(true);

    expect(screen.getByText('Change Password Form')).toBeInTheDocument();
  });

  it('passes setShowForm to ChangePasswordForm', () => {
    renderComponent(true);

    fireEvent.click(screen.getByText('Close Form'));

    expect(setShowFormMock).toHaveBeenCalledWith(false);
  });
});
