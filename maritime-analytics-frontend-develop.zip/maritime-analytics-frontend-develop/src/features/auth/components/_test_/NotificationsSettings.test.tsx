import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const toggleChangeMock = vi.fn();

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', async () => {
  return {
    ToggleSwitch: ({
      checked,
      onChange,
    }: {
      checked?: boolean;
      onChange?: (value: boolean) => void;
    }) => (
      <input
        type="checkbox"
        role="switch"
        checked={checked}
        onChange={(e) => onChange?.(e.target.checked)}
      />
    ),
  };
});

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import NotificationSettings from '@/features/auth/components/NotificationSettings';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function renderComponent(
  overrides?: Partial<React.ComponentProps<typeof NotificationSettings>>,
) {
  const props: React.ComponentProps<typeof NotificationSettings> = {
    notificationSettings: true,
    setNotificationSettings: toggleChangeMock,
    isNotificationUnchanged: true,
    handleNotificationSettingsSave: vi.fn(),
    handleNotificationSettingsCancel: vi.fn(),
    ...overrides,
  };

  return render(<NotificationSettings {...props} />);
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('NotificationSettings', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders notification settings UI', () => {
    renderComponent();

    expect(screen.getByText('Notifications')).toBeInTheDocument();
    expect(
      screen.getByText(/control how you receive notifications/i),
    ).toBeInTheDocument();

    expect(screen.getByText(/show notification pop-ups/i)).toBeInTheDocument();
  });

  it('renders toggle switch as checked when notifications are enabled', () => {
    renderComponent({ notificationSettings: true });

    const toggle = screen.getByRole('switch');
    expect(toggle).toBeChecked();
  });

  it('renders toggle switch as unchecked when notifications are disabled', () => {
    renderComponent({ notificationSettings: false });

    const toggle = screen.getByRole('switch');
    expect(toggle).not.toBeChecked();
  });

  it('calls setNotificationSettings when toggle is changed', () => {
    renderComponent({ notificationSettings: true });

    const toggle = screen.getByRole('switch');
    fireEvent.click(toggle);

    expect(toggleChangeMock).toHaveBeenCalledWith(false);
  });

  it('disables Save and Reset buttons when settings are unchanged', () => {
    renderComponent({ isNotificationUnchanged: true });

    expect(
      screen.getByRole('button', { name: /save changes/i }),
    ).toBeDisabled();

    expect(screen.getByRole('button', { name: /reset/i })).toBeDisabled();
  });

  it('enables Save and Reset buttons when settings have changed', () => {
    renderComponent({ isNotificationUnchanged: false });

    expect(screen.getByRole('button', { name: /save changes/i })).toBeEnabled();

    expect(screen.getByRole('button', { name: /reset/i })).toBeEnabled();
  });

  it('calls save handler when clicking Save Changes', () => {
    const saveMock = vi.fn();

    renderComponent({
      isNotificationUnchanged: false,
      handleNotificationSettingsSave: saveMock,
    });

    fireEvent.click(screen.getByRole('button', { name: /save changes/i }));

    expect(saveMock).toHaveBeenCalled();
  });

  it('calls cancel handler when clicking Reset', () => {
    const cancelMock = vi.fn();

    renderComponent({
      isNotificationUnchanged: false,
      handleNotificationSettingsCancel: cancelMock,
    });

    fireEvent.click(screen.getByRole('button', { name: /reset/i }));

    expect(cancelMock).toHaveBeenCalled();
  });
});
