import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React, { forwardRef } from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const { sendOtpMock, resetPasswordMock, showToastMock, logoutMock } =
  vi.hoisted(() => ({
    sendOtpMock: vi.fn(),
    resetPasswordMock: vi.fn(),
    showToastMock: vi.fn(),
    logoutMock: vi.fn(),
  }));

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', () => ({
  Label: ({ htmlFor, value }: { htmlFor?: string; value?: string }) => (
    <label htmlFor={htmlFor}>{value}</label>
  ),

  TextInput: forwardRef<
    HTMLInputElement,
    React.InputHTMLAttributes<HTMLInputElement>
  >((props, ref) => <input ref={ref} {...props} />),

  Tooltip: ({ children }: { children: React.ReactNode }) => (
    <span>{children}</span>
  ),
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => ({ logout: logoutMock }),
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: showToastMock }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => vi.fn(),
}));

vi.mock('@/features/auth/services/auth', () => ({
  sendPasswordResetOtp: sendOtpMock,
  resetPassword: resetPasswordMock,
}));

vi.mock('@/shared/utils/inputHandler', () => ({
  handleKeyPrevents: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import ChangePasswordForm from '@/features/auth/components/ChangePasswordForm';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function fillValidForm() {
  const otp = screen.getByLabelText('Verification Code');
  const newPassword = screen.getByLabelText('New Password');
  const confirmPassword = screen.getByLabelText('Confirm New Password');

  fireEvent.change(otp, { target: { value: '123456' } });
  fireEvent.blur(otp);

  fireEvent.change(newPassword, { target: { value: 'Valid123!' } });
  fireEvent.blur(newPassword);

  fireEvent.change(confirmPassword, { target: { value: 'Valid123!' } });
  fireEvent.blur(confirmPassword);
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('ChangePasswordForm', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.setItem('user', JSON.stringify({ email: 'test@example.com' }));
  });

  it('renders required fields', () => {
    render(<ChangePasswordForm />);

    expect(screen.getByText('Verify your identity')).toBeInTheDocument();
    expect(screen.getByLabelText('Verification Code')).toBeInTheDocument();
    expect(screen.getByLabelText('New Password')).toBeInTheDocument();
    expect(screen.getByLabelText('Confirm New Password')).toBeInTheDocument();
  });

  it('disables submit when form is invalid', () => {
    render(<ChangePasswordForm />);
    expect(screen.getByText('Reset Password')).toBeDisabled();
  });

  it('calls resetPassword, shows toast, and logs out on success', async () => {
    resetPasswordMock.mockResolvedValueOnce(undefined);

    render(<ChangePasswordForm />);

    fillValidForm();

    const submit = screen.getByText('Reset Password');

    await waitFor(() => {
      expect(submit).toBeEnabled();
    });

    fireEvent.click(submit);

    await waitFor(() => {
      expect(resetPasswordMock).toHaveBeenCalledWith(
        'test@example.com',
        '123456',
        'Valid123!',
      );
    });

    expect(showToastMock).toHaveBeenCalledWith(
      'success',
      'Password reset successfully. Logging you out...',
      5000,
    );

    expect(logoutMock).toHaveBeenCalled();
  });

  it('shows error when OTP is invalid', async () => {
    resetPasswordMock.mockRejectedValueOnce(
      new Error('Provided OTP is invalid'),
    );

    render(<ChangePasswordForm />);
    fillValidForm();

    const submit = screen.getByText('Reset Password');

    // 🔑 CRITICAL: wait for RHF validation
    await waitFor(() => {
      expect(submit).toBeEnabled();
    });

    fireEvent.click(submit);

    // ensure submit actually happened
    await waitFor(() => {
      expect(resetPasswordMock).toHaveBeenCalled();
    });

    // now the error MUST appear
    await waitFor(() => {
      expect(
        screen.getByText((content) =>
          content.toLowerCase().includes('code invalid'),
        ),
      ).toBeInTheDocument();
    });
  });

  it('calls sendPasswordResetOtp when clicking resend', async () => {
    render(<ChangePasswordForm />);

    fireEvent.click(screen.getByText(/send a new code/i));

    await waitFor(() => {
      expect(sendOtpMock).toHaveBeenCalledWith('test@example.com');
    });
  });

  it('calls setShowForm(false) on cancel', () => {
    const setShowForm = vi.fn();

    render(<ChangePasswordForm setShowForm={setShowForm} />);
    fireEvent.click(screen.getByText('Cancel'));

    expect(setShowForm).toHaveBeenCalledWith(false);
  });
});
