import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

import { Theme } from '@/app/context/ThemeProvider';
import GeneralSettings from '@/features/auth/components/GeneralSettings';

/* ------------------------------------------------------------------ */
/* Mock AccountsTabs */
/* ------------------------------------------------------------------ */

const accountsTabsMock = vi.fn();

vi.mock('@/features/auth/components/AccountsTabs', () => ({
  default: (props: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
  }) => {
    accountsTabsMock(props);
    return (
      <div>
        {props.tabs.map((tab) => (
          <button
            key={tab}
            data-testid={`tab-${tab}`}
            onClick={() => props.onChange(tab)}
          >
            {tab}
          </button>
        ))}
      </div>
    );
  },
}));

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function renderComponent(
  overrides?: Partial<React.ComponentProps<typeof GeneralSettings>>,
) {
  const defaultProps: React.ComponentProps<typeof GeneralSettings> = {
    activeThemeTab: 'system' as Theme,
    activeTimeZoneTab: 'system',
    handleThemeChange: vi.fn(),
    handleTimeZoneChange: vi.fn(),
    handleSave: vi.fn(),
    handleCancel: vi.fn(),
    isThemeUnchanged: true,
    isTzUnchanged: true,
  };

  const props = { ...defaultProps, ...overrides };

  render(<GeneralSettings {...props} />);
  return props;
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('GeneralSettings', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders section titles and descriptions', () => {
    renderComponent();

    expect(screen.getByText('General')).toBeInTheDocument();
    expect(screen.getByText('Time Zone')).toBeInTheDocument();
    expect(screen.getByText('Theme')).toBeInTheDocument();
  });

  it('renders AccountsTabs for time zone and theme', () => {
    renderComponent();

    // "system" appears twice (timezone + theme)
    expect(
      screen.getAllByRole('button', { name: 'system' }).length,
    ).toBeGreaterThan(1);

    // timezone
    expect(screen.getByRole('button', { name: 'utc' })).toBeInTheDocument();

    // theme
    expect(screen.getByRole('button', { name: 'light' })).toBeInTheDocument();

    expect(screen.getByRole('button', { name: 'dark' })).toBeInTheDocument();
  });

  it('calls handleTimeZoneChange when timezone tab is clicked', () => {
    const props = renderComponent();

    fireEvent.click(screen.getByTestId('tab-utc'));

    expect(props.handleTimeZoneChange).toHaveBeenCalledWith('utc');
  });

  it('calls handleThemeChange when theme tab is clicked', () => {
    const props = renderComponent();

    fireEvent.click(screen.getByTestId('tab-dark'));

    expect(props.handleThemeChange).toHaveBeenCalledWith('dark');
  });

  it('disables Save and Reset buttons when nothing has changed', () => {
    renderComponent({
      isThemeUnchanged: true,
      isTzUnchanged: true,
    });

    expect(screen.getByText('Save Changes')).toBeDisabled();
    expect(screen.getByText('Reset')).toBeDisabled();
  });

  it('enables Save and Reset buttons when changes exist', () => {
    renderComponent({
      isThemeUnchanged: false,
      isTzUnchanged: true,
    });

    expect(screen.getByText('Save Changes')).toBeEnabled();
    expect(screen.getByText('Reset')).toBeEnabled();
  });

  it('calls handleSave when Save Changes is clicked', () => {
    const props = renderComponent({
      isThemeUnchanged: false,
      isTzUnchanged: false,
    });

    fireEvent.click(screen.getByText('Save Changes'));

    expect(props.handleSave).toHaveBeenCalledOnce();
  });

  it('calls handleCancel when Reset is clicked', () => {
    const props = renderComponent({
      isThemeUnchanged: false,
      isTzUnchanged: false,
    });

    fireEvent.click(screen.getByText('Reset'));

    expect(props.handleCancel).toHaveBeenCalledOnce();
  });
});
