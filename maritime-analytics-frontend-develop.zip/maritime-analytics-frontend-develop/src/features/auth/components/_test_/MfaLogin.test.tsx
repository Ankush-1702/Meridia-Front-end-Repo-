import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks (Vitest requirement) */
/* ------------------------------------------------------------------ */

const { mfaVerificationMock, navigateMock, sendOtpMock } = vi.hoisted(() => ({
  mfaVerificationMock: vi.fn(),
  navigateMock: vi.fn(),
  sendOtpMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', async () => {
  const React = await import('react');

  return {
    Label: ({ htmlFor, value }: { htmlFor?: string; value?: string }) => (
      <label htmlFor={htmlFor}>{value}</label>
    ),

    TextInput: React.forwardRef<
      HTMLInputElement,
      React.InputHTMLAttributes<HTMLInputElement>
    >((props, ref) => <input ref={ref} {...props} />),

    Button: React.forwardRef<
      HTMLButtonElement,
      React.ButtonHTMLAttributes<HTMLButtonElement>
    >((props, ref) => <button ref={ref} {...props} />),

    Spinner: () => <span>spinner</span>,
  };
});

vi.mock('react-router', () => ({
  useNavigate: () => navigateMock,
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => ({
    mfaVerification: mfaVerificationMock,
  }),
}));

vi.mock('@/features/auth/services/auth', () => ({
  sendPasswordResetOtp: sendOtpMock,
}));

vi.mock('@/shared/utils/inputHandler', () => ({
  handleKeyPrevents: vi.fn(),
}));

vi.mock('@/shared/assets/MeridiaLogo', () => ({
  default: () => <svg data-logo />,
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import MfaLogin from '@/features/auth/components/MfaLogin';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function fillValidOtp() {
  const input = screen.getByLabelText('Verification Code');

  fireEvent.change(input, {
    target: { value: '123456' },
  });

  // Required for react-hook-form to mark field as touched/valid
  fireEvent.blur(input);
}

function submitForm() {
  const form = screen.getByRole('button', { name: /sign in/i }).closest('form');

  if (!form) {
    throw new Error('Form not found');
  }

  fireEvent.submit(form);
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('MfaLogin', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.setItem('mfa_email', 'test@example.com');
  });

  it('renders verification UI', () => {
    render(<MfaLogin keepLoggedIn={false} />);

    expect(screen.getByText(/verify your identity/i)).toBeInTheDocument();
    expect(screen.getByLabelText('Verification Code')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /sign in/i })).toBeDisabled();
  });

  it('enables submit button when OTP is valid', async () => {
    render(<MfaLogin keepLoggedIn={false} />);

    fillValidOtp();

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /sign in/i })).toBeEnabled();
    });
  });

  it('submits OTP and navigates on success', async () => {
    mfaVerificationMock.mockResolvedValueOnce(true);

    render(<MfaLogin keepLoggedIn={false} />);
    fillValidOtp();

    submitForm();

    await waitFor(() => {
      expect(mfaVerificationMock).toHaveBeenCalledWith('123456');
    });

    expect(navigateMock).toHaveBeenCalledWith('/', {
      replace: true,
    });
  });

  it('shows error when OTP is invalid (server error)', async () => {
    mfaVerificationMock.mockRejectedValueOnce(
      new Error('Provided OTP is invalid'),
    );

    render(<MfaLogin keepLoggedIn={false} />);
    fillValidOtp();

    submitForm();

    await waitFor(() => {
      expect(
        screen.getByText((content) =>
          content.toLowerCase().includes('code invalid'),
        ),
      ).toBeInTheDocument();
    });
  });

  it('shows expired OTP error', async () => {
    mfaVerificationMock.mockRejectedValueOnce(
      new Error('OTP has expired already'),
    );

    render(<MfaLogin keepLoggedIn={false} />);
    fillValidOtp();

    submitForm();

    await waitFor(() => {
      expect(
        screen.getByText((content) =>
          content.toLowerCase().includes('code expired'),
        ),
      ).toBeInTheDocument();
    });
  });

  it('calls resend OTP when clicking "Send a new code"', async () => {
    render(<MfaLogin keepLoggedIn={false} />);

    fireEvent.click(screen.getByText(/send a new code/i));

    await waitFor(() => {
      expect(sendOtpMock).toHaveBeenCalledWith('test@example.com');
    });
  });

  it('shows loading state while submitting', async () => {
    mfaVerificationMock.mockImplementation(() => new Promise(() => {}));

    render(<MfaLogin keepLoggedIn={false} />);
    fillValidOtp();

    submitForm();

    expect(screen.getByRole('button', { name: /sign in/i })).toBeDisabled();
  });

  it('saves keepLoggedIn to localStorage on successful MFA verification', async () => {
    mfaVerificationMock.mockResolvedValueOnce(true);

    render(<MfaLogin keepLoggedIn={true} />);
    fillValidOtp();
    submitForm();

    await waitFor(() => {
      expect(localStorage.getItem('keepLoggedIn')).toBe('true');
    });
  });
});
