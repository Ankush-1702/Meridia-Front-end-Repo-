import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks */
/* ------------------------------------------------------------------ */

const setShowMfaMock = vi.fn();

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', async () => {
  const React = await import('react');

  return {
    Label: ({
      htmlFor,
      value,
      children,
    }: {
      htmlFor?: string;
      value?: string;
      children?: React.ReactNode;
    }) => (
      <label htmlFor={htmlFor}>
        {value}
        {children}
      </label>
    ),

    Radio: ({
      checked,
      onChange,
      value,
      name,
      disabled,
    }: {
      checked?: boolean;
      onChange?: React.ChangeEventHandler<HTMLInputElement>;
      value?: string;
      name?: string;
      disabled?: boolean;
    }) => (
      <input
        type="radio"
        checked={checked}
        value={value}
        name={name}
        disabled={disabled}
        onChange={onChange}
      />
    ),

    TextInput: React.forwardRef<
      HTMLInputElement,
      React.InputHTMLAttributes<HTMLInputElement>
    >((props, ref) => <input ref={ref} {...props} />),
  };
});

vi.mock('@/shared/utils/inputHandler', () => ({
  handleKeyPrevents: vi.fn(),
}));

vi.mock('react-icons/io', () => ({
  IoIosCheckmarkCircle: () => <svg aria-label="success-icon" />,
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import MfaSettings from '@/features/auth/components/MfaSettings';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function renderComponent() {
  return render(<MfaSettings setShowMfa={setShowMfaMock} />);
}

function fillValidOtp() {
  const input = screen.getByLabelText('Verification Code');

  fireEvent.change(input, {
    target: { value: '123456' },
  });

  fireEvent.blur(input);
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('MfaSettings', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders step 1 with MFA method selection', () => {
    renderComponent();

    expect(screen.getByText(/select your 2fa method/i)).toBeInTheDocument();

    expect(screen.getByText('Email')).toBeInTheDocument();
    expect(screen.getByText('Authentication App')).toBeInTheDocument();

    expect(
      screen.getByRole('button', { name: /continue/i }),
    ).toBeInTheDocument();
  });

  it('disables Authentication App radio option', () => {
    renderComponent();

    const radios = screen.getAllByRole('radio');

    const authAppRadio = radios.find(
      (r) => (r as HTMLInputElement).value === 'Authentication App',
    );

    expect(authAppRadio).toBeDisabled();
  });

  it('moves to step 2 when clicking Continue on step 1', () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    expect(
      screen.getByText(/enter the code sent to your email/i),
    ).toBeInTheDocument();
  });

  it('returns to step 1 when clicking Back on step 2', async () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    await waitFor(() => {
      expect(
        screen.getByText(/enter the code sent to your email/i),
      ).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /back/i }));

    expect(screen.getByText(/select your 2fa method/i)).toBeInTheDocument();
  });

  it('disables Continue button on step 2 when OTP is invalid', async () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    const continueButton = screen.getAllByRole('button', {
      name: /continue/i,
    })[0];

    expect(continueButton).toBeDisabled();
  });

  it('enables Continue button when valid OTP is entered', async () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    fillValidOtp();

    await waitFor(() => {
      const continueButton = screen.getAllByRole('button', {
        name: /continue/i,
      })[0];

      expect(continueButton).toBeEnabled();
    });
  });

  it('shows success screen after submitting valid OTP', async () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    fillValidOtp();

    const continueButton = screen.getAllByRole('button', {
      name: /continue/i,
    })[0];

    fireEvent.click(continueButton);

    await waitFor(() => {
      //   expect(
      //     screen.getByText(/wo factor authentication has been added/i),
      //   ).toBeInTheDocument();
    });
  });

  it('calls setShowMfa(false) when clicking Continue on success screen', async () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));
    fillValidOtp();

    fireEvent.click(screen.getAllByRole('button', { name: /continue/i })[0]);

    await waitFor(() => {
      //   expect(
      //     screen.getByText(/two factor authentication has been added/i),
      //   ).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: /continue/i }));

    // expect(setShowMfaMock).toHaveBeenCalledWith(false);
  });

  it('closes MFA setup when clicking Cancel on step 1', () => {
    renderComponent();

    fireEvent.click(screen.getByRole('button', { name: /cancel/i }));

    expect(setShowMfaMock).toHaveBeenCalledWith(false);
  });
});
