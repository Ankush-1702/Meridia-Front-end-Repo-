import { Button, Label, TextInput, Tooltip } from 'flowbite-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { FaInfoCircle } from 'react-icons/fa';
import { useNavigate } from 'react-router';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  resetPassword,
  sendPasswordResetOtp,
} from '@/features/auth/services/auth';
import MeridiaLogo from '@/shared/assets/MeridiaLogo';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { handleKeyPrevents } from '@/shared/utils/inputHandler';

type SendOtpFormType = {
  email: string;
};

type FormValues = {
  otp: string;
  newPassword: string;
  confirmNewPassword: string;
};

function ResetPasswordForm() {
  const [isResetPassword, setIsResetPassword] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
      {!isResetPassword ? (
        <SendOtpForm
          setResetPassword={setIsResetPassword}
          setEmail={setEmail}
        />
      ) : (
        <ResetPassword email={email} setResetPassword={setIsResetPassword} />
      )}
    </div>
  );
}

export default ResetPasswordForm;

function SendOtpForm({
  setResetPassword,
  setEmail,
}: {
  setResetPassword: (val: boolean) => void;
  setEmail: (val: string) => void;
}) {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isValid },
  } = useForm<SendOtpFormType>({
    mode: 'all',
    criteriaMode: 'all',
    shouldFocusError: true,
  });

  const navigate = useNavigate();
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();

  const onSubmit = async (data: SendOtpFormType) => {
    setEmail(data.email);
    const saved = localStorage.getItem('expiryOtp');
    const TEN_MIN_MS = 10 * 60 * 1000;
    if (saved && Date.now() - Number(saved) < TEN_MIN_MS) {
      showToast('info', 'OTP already sent', 5000);
      setResetPassword(true);
      return;
    }
    try {
      await sendPasswordResetOtp(data.email);
      showToast('success', 'OTP sent successfully', 5000);
      localStorage.setItem('expiryOtp', Date.now().toString());
    } catch (error) {
      handleApiError(error);
    } finally {
      setResetPassword(true);
    }
  };

  const handleCancel = () => {
    reset();
    navigate('/login');
  };

  return (
    <form className="w-full max-w-sm rounded bg-white bg-opacity-60 p-8 shadow dark:bg-gray-800 dark:bg-opacity-90 dark:shadow-lg">
      <div className="mb-6 flex items-center justify-center gap-2 text-xl font-semibold text-gray-800 dark:text-gray-100">
        <MeridiaLogo className="h-5 w-5" />
        <span
          className="font-medium text-gray-800 dark:text-gray-100"
          style={{ fontFamily: 'Unbounded' }}
        >
          MERIDIA
        </span>
      </div>
      <div className="mb-6 flex flex-col items-center justify-center">
        <span className="text-base font-medium text-gray-800 dark:text-gray-100">
          Reset your password
        </span>
        <span className="text-sm font-normal text-gray-500">
          Please enter your email to continue
        </span>
      </div>
      <div className="mb-6 flex flex-col gap-1">
        <Label
          htmlFor="email"
          value="Email Address"
          color={errors.email ? 'failure' : 'undefined'}
          className="text-gray-800 dark:text-gray-100"
        />
        <TextInput
          id="email"
          placeholder="sofia.eriksen@mail.com"
          color={errors.email && 'failure'}
          className="rounded-lg border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-900"
          {...register('email', {
            required: 'Email is required',
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              message: 'Invalid email address',
            },
          })}
        />
        {errors.email && (
          <p className="mt-2 text-sm text-red-600 dark:text-red-500">
            {errors.email.message}
          </p>
        )}
      </div>
      <Button
        className="w-full bg-psg-orange-700 enabled:hover:bg-psg-orange-600"
        onClick={handleSubmit(onSubmit)}
        type="submit"
        // color={'primary'}
        disabled={!isValid}
      >
        Continue
      </Button>
      <button
        className="mt-4 w-full text-sm font-medium text-gray-500 hover:text-psg-orange-700 hover:underline"
        onClick={handleCancel}
        type="button"
      >
        Back to Sign in
      </button>
    </form>
  );
}

function ResetPassword({
  email,
  setResetPassword,
}: {
  email: string;
  setResetPassword: (val: boolean) => void;
}) {
  const navigate = useNavigate();
  const { showToast } = useToastNotification();
  const handleApiError = useApiErrorHandler();
  const {
    register,
    handleSubmit,
    watch,
    reset,
    setError,
    formState: { errors, isValid },
  } = useForm<FormValues>({
    mode: 'all',
    criteriaMode: 'all',
    shouldFocusError: true,
  });

  const validatePassword = (password: string) =>
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\^$*.[\]{}()?"!@#%&/\\,><':;|_~`+= -])[a-zA-Z\d^$*.[\]{}()?"!@#%&/\\,><':;|_~`+= -]{8,}$/.test(
      password,
    );

  const sendOtp = async () => {
    const saved = localStorage.getItem('expiryOtp');
    const TEN_MIN_MS = 10 * 60 * 1000;
    if (saved && Date.now() - Number(saved) < TEN_MIN_MS) {
      showToast('info', 'OTP already sent', 5000);
      return;
    }
    try {
      await sendPasswordResetOtp(email);
      showToast('success', 'OTP sent successfully', 5000);
      localStorage.setItem('expiryOtp', Date.now().toString());
    } catch (error) {
      handleApiError(error);
    }
  };

  const onSubmit = async (data: FormValues) => {
    const { otp, newPassword } = data;
    try {
      if (email && otp && newPassword) {
        await resetPassword(email, otp, newPassword);
      }
      showToast('success', 'Password reset successfully', 5000);
      navigate('/login');
      localStorage.removeItem('expiryOtp');
    } catch (error) {
      console.error('Reset Password API error:', error); //check error handling
      const errorMessage = (error as Error).message;
      if (errorMessage === 'Provided OTP is invalid') {
        setError('otp', { message: 'Invalid OTP', type: 'server' });
      } else if (errorMessage === 'OTP has expired already') {
        setError('otp', { message: 'Code expired', type: 'server' });
      }
    }
  };

  const handleCancel = () => {
    reset();
    setResetPassword(false);
    navigate('/login');
  };
  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="rounded-xl bg-white p-8 dark:bg-gray-800"
    >
      <div className="mb-6 flex items-center justify-center gap-2 text-xl font-semibold text-gray-800 dark:text-gray-100">
        <MeridiaLogo className="h-5 w-5" />
        <span
          className="font-medium text-gray-800 dark:text-gray-100"
          style={{ fontFamily: 'Unbounded' }}
        >
          MERIDIA
        </span>
      </div>
      <div className="mb-6 flex h-fit w-[420px] flex-col items-center justify-center gap-1 p-4 text-sm">
        <h3 className="text-base font-medium">Verify your identity</h3>
        <p className="text-sm font-normal text-gray-500">
          Enter the code sent to your [2FA_METHOD],
        </p>
        <p className="text-sm font-normal text-gray-500">
          then choose a new password.{' '}
        </p>
        <span className="text-sm font-bold text-gray-500">
          The code is valid for 10 minutes.
        </span>
      </div>
      <div className="mb-7 space-y-4">
        <div>
          <Label
            htmlFor="verificationCode"
            value="Verification Code"
            className=""
            color={errors.otp ? 'failure' : undefined}
          />
          <TextInput
            id="otp"
            color={errors.otp ? 'failure' : undefined}
            type="number"
            {...register('otp', {
              required: 'Verification code is required.',
              pattern: {
                value: /^[0-9]{6}$/,
                message: 'Invalid OTP format',
              },
            })}
            required
            className="mt-1 h-[37px] w-[420px]"
            onKeyDown={handleKeyPrevents}
          />
          {errors.otp ? (
            <p className="mt-4 text-sm text-red-600">
              {errors.otp.type === 'server'
                ? errors.otp.message === 'Invalid OTP'
                  ? 'Code invalid. Please try again or '
                  : 'Code expired. '
                : 'Code Invalid. Please try again or '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          ) : (
            <p className="mt-2 text-sm text-gray-500">
              Didn't receive an email?{' '}
              <button
                className="cursor-pointer text-[#1C64F2] underline"
                onClick={sendOtp}
              >
                Send a new code
              </button>
            </p>
          )}
        </div>

        <div className="relative w-[420px]">
          <div className="flex items-center gap-2">
            <Label
              htmlFor="newPassword"
              value="New Password"
              className=""
              color={errors.newPassword ? 'failure' : undefined}
            />
            <Tooltip
              content={
                <div className=" text-xs font-normal leading-relaxed text-white">
                  <p className="mb-0.5 font-bold">Password requirements</p>
                  <ul>
                    <li>At least 8 characters</li>
                    <li>Contains at least 1 number</li>
                    <li>Contains at least 1 special character</li>
                    <li>Contains at least 1 uppercase letter</li>
                    <li>Contains at least 1 lowercase letter</li>
                  </ul>
                </div>
              }
              placement="bottom"
              className="w-[230px]"
            >
              <FaInfoCircle className={`text-gray-400`} />
            </Tooltip>
          </div>

          <TextInput
            id="newPassword"
            type="password"
            color={errors.newPassword ? 'failure' : undefined}
            {...register('newPassword', {
              required: 'New password is required.',
              validate: (value) =>
                validatePassword(value) || 'Invalid password',
            })}
            className="mt-1 h-[37px] w-full" // Add padding-right to avoid overlap with icon
            required
          />

          {errors.newPassword?.message === 'Invalid password' && (
            <div className="mt-4 text-sm leading-snug text-red-600">
              <p className="font-normal">
                Password invalid. Password requirements:
              </p>
              <p>At least 8 characters</p>
              <p>Contains at least 1 number</p>
              <p>Contains at least 1 special character</p>
              <p>Contains at least 1 uppercase letter</p>
              <p>Contains at least 1 lowercase letter</p>
            </div>
          )}
        </div>

        <div>
          <Label
            htmlFor="confirmNewPassword"
            value="Confirm New Password"
            className=""
            color={errors.confirmNewPassword ? 'failure' : undefined}
          />
          <TextInput
            id="confirmNewPassword"
            type="password"
            color={errors.confirmNewPassword ? 'failure' : undefined}
            {...register('confirmNewPassword', {
              required: 'Please confirm your new password.',
              validate: (value) =>
                value === watch('newPassword') ||
                'This Password does not match.',
            })}
            className="mb-4 mt-1 h-[37px] w-[420px]"
          />
          {errors.confirmNewPassword && (
            <p className="text-sm text-red-600">
              {errors.confirmNewPassword.message}
            </p>
          )}
        </div>
      </div>
      <Button
        className="w-full bg-psg-orange-700 enabled:hover:bg-orange-600"
        onClick={handleSubmit(onSubmit)}
        type="submit"
        // color={'primary'}
        disabled={!isValid}
      >
        Continue
      </Button>
      <button
        className="mt-4 w-full text-sm font-medium text-gray-500 hover:underline"
        onClick={handleCancel}
        type="button"
      >
        Back to Sign in
      </button>
    </form>
  );
}
