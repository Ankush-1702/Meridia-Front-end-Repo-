import { Button, Checkbox, Label, Spinner, TextInput } from 'flowbite-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { KEEP_LOGGED_IN_KEY } from '@/app/constants/constants';
import MfaLogin from '@/features/auth/components/MfaLogin';
import { useAuth } from '@/features/auth/context/AuthContext';
import MeridiaLogo from '@/shared/assets/MeridiaLogo';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
export default function Login() {
  const TERMSOFUSEURL =
    'https://www.polestarglobal.com/terms-and-conditions-meridia/';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isMfaEnabled, setIsMfaEnabled] = useState(false);
  const [keepLoggedIn, setKeepLoggedIn] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();
  const { showToast } = useToastNotification();

  useEffect(() => {
    const message = sessionStorage.getItem('toastMessage');
    if (message) {
      showToast('info', message, 5000);

      sessionStorage.removeItem('toastMessage');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const success = await login(email.trim(), password);

    setLoading(false);
    if (success.success && !success.mfa_enabled) {
      localStorage.setItem(KEEP_LOGGED_IN_KEY, String(keepLoggedIn));
      navigate('/', { replace: true });
    } else if (success.mfa_enabled) {
      setIsMfaEnabled(true);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 dark:bg-gray-900">
      {!isMfaEnabled ? (
        <form
          onSubmit={handleSubmit}
          className="w-full max-w-[428px] rounded bg-white bg-opacity-60 p-8 shadow dark:bg-gray-800 dark:bg-opacity-90 dark:shadow-lg"
        >
          <div className="mb-4 flex items-center justify-center gap-2 text-xl font-semibold text-gray-800 dark:text-gray-100">
            <MeridiaLogo className="h-5 w-5" />
            <span
              className="text-gray-800 dark:text-gray-100"
              style={{ fontFamily: 'Unbounded' }}
            >
              MERIDIA
            </span>
          </div>
          <div className="mb-4">
            <Label
              htmlFor="email"
              value="Email"
              className="text-gray-800 dark:text-gray-100"
            />
            <TextInput
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="rounded-lg border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-900"
            />
          </div>
          <div className="mb-4">
            <Label
              htmlFor="password"
              value="Password"
              className="text-gray-800 dark:text-gray-100"
            />
            <TextInput
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="rounded-lg border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-900"
            />
          </div>
          <div className="mb-4 flex items-center gap-2 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <Checkbox
                color="psgLightPrimary"
                checked={keepLoggedIn}
                onChange={(e) => setKeepLoggedIn(e.target.checked)}
                id="keepLoggedIn"
                disabled={loading}
              />
              <label htmlFor="keepLoggedIn" className="cursor-pointer text-sm">
                Keep me signed in
              </label>
            </div>
          </div>
          <Button
            type="submit"
            // color="primary"
            className="flex w-full items-center justify-center bg-psg-orange-700 text-white enabled:hover:bg-psg-orange-600"
            disabled={loading || !email || !password}
          >
            {loading ? (
              <>
                <Spinner size="sm" light color={'gray'} className="mr-2" />
                Signing in...
              </>
            ) : (
              'Sign in'
            )}
          </Button>
          <div className="mt-4 text-center">
            <a
              href="/reset-password"
              className="text-sm text-gray-500 underline hover:text-psg-orange-700"
            >
              Forgotten Password?
            </a>
          </div>
          <div className="mx-auto mt-4 flex w-[318px] items-center justify-center text-[12px] text-gray-500">
            <p>
              By logging in, I agree to Meridia's{' '}
              <a
                className="cursor-pointer underline hover:text-psg-orange-700"
                href={TERMSOFUSEURL}
                target="_blank"
                rel="noopener noreferrer"
              >
                Terms and Conditions
              </a>{' '}
              and consent to the use of my data as described therein.
            </p>
          </div>
        </form>
      ) : (
        <MfaLogin keepLoggedIn={keepLoggedIn} />
      )}
    </div>
  );
}
