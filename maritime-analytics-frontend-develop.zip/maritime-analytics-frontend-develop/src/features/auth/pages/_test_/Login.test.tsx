import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ------------------------------------------------------------------ */
/* Hoisted mocks (Vitest requirement) */
/* ------------------------------------------------------------------ */

const { loginMock, navigateMock, showToastMock } = vi.hoisted(() => ({
  loginMock: vi.fn(),
  navigateMock: vi.fn(),
  showToastMock: vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* Mocks */
/* ------------------------------------------------------------------ */

vi.mock('flowbite-react', async () => {
  const React = await import('react');

  return {
    Label: ({ htmlFor, value }: { htmlFor?: string; value?: string }) => (
      <label htmlFor={htmlFor}>{value}</label>
    ),

    TextInput: React.forwardRef<
      HTMLInputElement,
      React.InputHTMLAttributes<HTMLInputElement>
    >((props, ref) => <input ref={ref} {...props} />),

    Button: React.forwardRef<
      HTMLButtonElement,
      React.ButtonHTMLAttributes<HTMLButtonElement>
    >((props, ref) => <button ref={ref} {...props} />),

    Spinner: () => <span>spinner</span>,

    Checkbox: React.forwardRef<
      HTMLInputElement,
      React.InputHTMLAttributes<HTMLInputElement>
    >((props, ref) => <input ref={ref} type="checkbox" {...props} />),
  };
});

vi.mock('react-router-dom', () => ({
  useNavigate: () => navigateMock,
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => ({
    login: loginMock,
  }),
}));

vi.mock('@/features/auth/components/MfaLogin', () => ({
  default: () => <div>MFA LOGIN</div>,
}));

vi.mock('@/shared/assets/MeridiaLogo', () => ({
  default: () => <svg data-logo />,
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: showToastMock,
  }),
}));

/* ------------------------------------------------------------------ */
/* System under test */
/* ------------------------------------------------------------------ */

import Login from '@/features/auth/pages/Login';

/* ------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------ */

function fillLoginForm() {
  fireEvent.change(screen.getByLabelText('Email'), {
    target: { value: 'test@example.com' },
  });

  fireEvent.change(screen.getByLabelText('Password'), {
    target: { value: 'password123' },
  });
}

/* ------------------------------------------------------------------ */
/* Tests */
/* ------------------------------------------------------------------ */

describe('Login', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders login form', () => {
    render(<Login />);

    expect(screen.getByText('MERIDIA')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /sign in/i }),
    ).toBeInTheDocument();
  });

  it('calls login with trimmed email and password', async () => {
    loginMock.mockResolvedValueOnce({ success: false });

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    await waitFor(() => {
      expect(loginMock).toHaveBeenCalledWith('test@example.com', 'password123');
    });
  });

  it('navigates to home on successful login without MFA', async () => {
    loginMock.mockResolvedValueOnce({
      success: true,
      mfa_enabled: false,
    });

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith('/', { replace: true });
    });
  });

  it('shows MFA login when MFA is enabled', async () => {
    loginMock.mockResolvedValueOnce({
      success: true,
      mfa_enabled: true,
    });

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    await waitFor(() => {
      expect(screen.getByText('MFA LOGIN')).toBeInTheDocument();
    });
  });

  it('shows loading state while submitting', async () => {
    loginMock.mockImplementation(() => new Promise(() => {}));

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    expect(screen.getByText(/signing in/i)).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });
  it('saves keepLoggedIn as false to localStorage on successful login when unchecked', async () => {
    loginMock.mockResolvedValueOnce({ success: true, mfa_enabled: false });

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    await waitFor(() => {
      expect(localStorage.getItem('keepLoggedIn')).toBe('false');
    });
  });

  it('saves keepLoggedIn as true to localStorage on successful login when checked', async () => {
    loginMock.mockResolvedValueOnce({ success: true, mfa_enabled: false });

    render(<Login />);
    fillLoginForm();

    fireEvent.click(screen.getByRole('checkbox'));
    fireEvent.click(screen.getByRole('button', { name: /sign in/i }));

    await waitFor(() => {
      expect(localStorage.getItem('keepLoggedIn')).toBe('true');
    });
  });
});
