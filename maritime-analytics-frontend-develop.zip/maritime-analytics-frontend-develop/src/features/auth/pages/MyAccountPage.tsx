import React, { useEffect, useRef, useState } from 'react';
import AccountsHeader from '../components/AccountsHeader';
import { TIME_ZONE_KEY } from '@/app/constants/constants';
import { Theme, useTheme } from '@/app/context/ThemeProvider';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import GeneralSettings from '@/features/auth/components/GeneralSettings';
import NotificationSettings from '@/features/auth/components/NotificationSettings';
import PersonalInfoSection from '@/features/auth/components/PersonalInfoSection';
import SecuritySection from '@/features/auth/components/SecuritySection';
import { sendPasswordResetOtp } from '@/features/auth/services/auth';
import { useNotificationsStompContext } from '@/features/Notifications/Context/NotificationsStompContext';
import { NOTIFICATIONS_SETTINGS_KEY } from '@/shared/constants/constants';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { logger } from '@/shared/utils/logger';

const MyAccountPage: React.FC = () => {
  // const navigate = useNavigate();
  const {
    theme: selectedTheme,
    setTheme: previewTheme,
    saveTheme,
  } = useTheme();
  const [activeTimeZoneTab, setActiveTimeZoneTab] = useState<string>(
    () => localStorage.getItem(TIME_ZONE_KEY) ?? 'system',
  );

  const {
    notificationSettings,
    setNotificationSettings,
    dismissAllNotifications,
  } = useNotificationsStompContext();
  const [prevSettings, setPrevSettings] = useState<boolean>(() => {
    const stored = localStorage.getItem('notificationSettings');
    return stored === null ? true : stored === 'true';
  });
  const [activeThemeTab, setActiveThemeTab] = useState<Theme>(selectedTheme);

  const initialThemeRef = useRef<Theme>(selectedTheme);
  const [initialTimeZone, setInitialTimeZone] = useState<string>(
    localStorage.getItem(TIME_ZONE_KEY) ?? 'system',
  );
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const email = userProfile.email;
  const isThemeUnchanged = activeThemeTab === selectedTheme;
  const isTzUnchanged = activeTimeZoneTab === initialTimeZone;
  const isNotificationUnchanged = notificationSettings === prevSettings;
  const [showForm, setShowForm] = useState<boolean>(false);
  const { showToast } = useToastNotification();
  // const [showMfa, setShowMfa] = useState<boolean>(false);

  const handleApiError = useApiErrorHandler();

  useEffect(() => {
    setActiveThemeTab(selectedTheme);
    initialThemeRef.current = selectedTheme;
  }, [selectedTheme]);

  useEffect(() => {
    const saved = localStorage.getItem(TIME_ZONE_KEY) ?? 'system';
    setActiveTimeZoneTab(saved);
    setInitialTimeZone(saved);
  }, []);

  const handleThemeChange = (tab: string) => {
    const newTheme = tab as Theme;
    setActiveThemeTab(newTheme);
    previewTheme(newTheme);
  };

  const handleTimeZoneChange = (tab: string) => {
    const newTimeZone = tab;
    setActiveTimeZoneTab(newTimeZone);
  };

  // Revert theme when leaving the page/component without saving
  useEffect(() => {
    return () => {
      previewTheme(initialThemeRef.current); // Revert on unmount
      setActiveTimeZoneTab(initialTimeZone);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNotificationSettingsSave = () => {
    localStorage.setItem(
      NOTIFICATIONS_SETTINGS_KEY,
      String(notificationSettings),
    );
    if (!notificationSettings) {
      dismissAllNotifications();
    }
    setPrevSettings(notificationSettings);
  };

  const handleNotificationSettingsCancel = () => {
    setNotificationSettings(prevSettings); // restore
  };

  const handleCancel = () => {
    setActiveThemeTab(initialThemeRef.current);
    previewTheme(initialThemeRef.current);
    setActiveTimeZoneTab(initialTimeZone);
  };
  const handleSave = () => {
    saveTheme(activeThemeTab);
    localStorage.setItem(TIME_ZONE_KEY, activeTimeZoneTab);
    initialThemeRef.current = activeThemeTab;
    setInitialTimeZone(activeTimeZoneTab);
  };

  const handlePasswordReset = async () => {
    const saved = localStorage.getItem('expiryOtp');
    const TEN_MIN_MS = 10 * 60 * 1000;
    if (saved && Date.now() - Number(saved) < TEN_MIN_MS) {
      showToast('info', 'OTP already sent');
      setShowForm(true);
      return;
    }
    try {
      await sendPasswordResetOtp(email);
      localStorage.setItem('expiryOtp', Date.now().toString());
      setShowForm(true);
      showToast('success', 'OTP sent successfully');
    } catch (error) {
      handleApiError(error);
    }
  };

  const user = React.useMemo(() => {
    try {
      const stored = localStorage.getItem('user');
      if (!stored) return {};
      const parsed = JSON.parse(stored);
      return {
        username: parsed.username || '',
        fullName:
          parsed.first_name && parsed.last_name
            ? `${parsed.first_name} ${parsed.last_name}`
            : '',
        email: parsed.email || '',
        role: parsed.role || '',
        accountId: parsed.account_id || '',
      };
    } catch (err) {
      logger.error('[MyAccountPage] Failed to parse stored user data', err);
      return {};
    }
  }, []);

  const personalInformationRows = [
    { label: 'Username', value: user.username },
    { label: 'Full Name', value: user.fullName },
    { label: 'Email', value: user.email },
    { label: 'Role', value: user.role },
    { label: 'Account ID', value: user.accountId },
  ];
  return (
    <div className="flex min-h-screen flex-col bg-gray-100 dark:bg-gray-900">
      <div className="bg-white dark:bg-gray-800 dark:text-white">
        <AccountsHeader headerText="My Profile" />
      </div>
      <GeneralSettings
        activeThemeTab={activeThemeTab}
        activeTimeZoneTab={activeTimeZoneTab}
        handleThemeChange={handleThemeChange}
        handleTimeZoneChange={handleTimeZoneChange}
        handleSave={handleSave}
        handleCancel={handleCancel}
        isThemeUnchanged={isThemeUnchanged}
        isTzUnchanged={isTzUnchanged}
      />
      <NotificationSettings
        notificationSettings={notificationSettings}
        setNotificationSettings={setNotificationSettings}
        isNotificationUnchanged={isNotificationUnchanged}
        handleNotificationSettingsSave={handleNotificationSettingsSave}
        handleNotificationSettingsCancel={handleNotificationSettingsCancel}
      />
      <PersonalInfoSection personalInformationRows={personalInformationRows} />
      <SecuritySection
        showForm={showForm}
        setShowForm={setShowForm}
        handlePasswordReset={handlePasswordReset}
      />
    </div>
  );
};

export default MyAccountPage;
