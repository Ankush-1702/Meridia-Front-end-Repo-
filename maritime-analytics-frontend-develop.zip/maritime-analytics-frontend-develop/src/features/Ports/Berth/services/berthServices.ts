import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  BerthApiResponse,
  BerthFilterResponse,
} from '@/features/Ports/Berth/types/berthTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export async function getBerths(
  portId: string,
  dateStart: string,
  dateEnd: string,
  offset?: number,
  berthType?: string,
  terminalName?: string,
  limit: number = 500,
): Promise<BerthApiResponse> {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
    date_start: dateStart,
    date_end: dateEnd,
    berth_type: berthType ? berthType : '',
    terminal_name: terminalName ? terminalName : '',
  });

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/berths?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berths';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  return await res.json();
}

export async function getBerthFilters(
  portId: string,
  berthTypes?: string,
  terminalName?: string,
): Promise<BerthFilterResponse> {
  const params = new URLSearchParams({
    berth_types: berthTypes ? berthTypes : '',
    terminal_names: terminalName ? terminalName : '',
  });

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/berths/filters?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berth filters';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  return await res.json();
}
