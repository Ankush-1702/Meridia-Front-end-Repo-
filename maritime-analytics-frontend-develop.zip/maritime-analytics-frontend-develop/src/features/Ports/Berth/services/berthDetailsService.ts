import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  BerthDetailsApiResponse,
  FlagResponse,
} from '@/features/Ports/Berth/types/berthDetailsTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export async function getBerthDetails(
  portId: string,
  berthId: string,
  dateStart: string,
  dateEnd: string,
  flags?: string,
  pageSize?: number,
  page?: number,
  topN?: number,
): Promise<BerthDetailsApiResponse> {
  const params = new URLSearchParams({
    date_start: dateStart,
    date_end: dateEnd,
    vessel_flag: flags ? flags : '',
    page: page ? page.toString() : '1',
    page_size: pageSize ? pageSize.toString() : '15',
    top_n: topN ? topN.toString() : '10',
  });

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/berths/${berthId}?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berth details';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  return await res.json();
}

export async function getVesselFlags(
  portId: string,
  berthId: string,
  dateStart: string,
  dateEnd: string,
): Promise<FlagResponse> {
  const params = new URLSearchParams({
    date_start: dateStart,
    date_end: dateEnd,
  });

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/berths/${berthId}/vessel-flags?${params.toString()}`;
  const res = await fetchWithAuth(url, { headers: getAuthHeaders() });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berth details';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  return await res.json();
}
