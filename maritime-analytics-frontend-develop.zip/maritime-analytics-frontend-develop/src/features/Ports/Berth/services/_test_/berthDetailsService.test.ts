import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getBerthDetails, getVesselFlags } from '../berthDetailsService';

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  LEGACY_API_GATEWAY_BASE_URL: 'https://legacy.gateway',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
}));

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => body.message?.toString() ?? 'Error',
  };
}

function errorJsonFails(
  status = 500,
  statusText = 'Server Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: () => Promise.reject(new Error('not json')),
    text: async () => 'Plain text error',
  };
}

describe('berthDetailsService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getBerthDetails', () => {
    it('fetches berth details and returns data', async () => {
      const data = { berth_details: { berth_id: 'b1' } };
      await mockFetch(okResponse(data));

      const result = await getBerthDetails(
        'port-1',
        'b1',
        '2025-01-01',
        '2025-01-31',
      );

      expect(result).toEqual(data);
    });

    it('uses default page, page_size, top_n, and vessel_flag when omitted', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/analytics/ports/id/port-1/berths/b1?');
      expect(calledUrl).toContain('page=1');
      expect(calledUrl).toContain('page_size=15');
      expect(calledUrl).toContain('top_n=10');
      expect(calledUrl).toContain('vessel_flag=');
    });

    it('reflects custom flags, pageSize, page, and topN', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerthDetails(
        'port-1',
        'b1',
        '2025-01-01',
        '2025-01-31',
        'GBR,USA',
        20,
        2,
        5,
      );

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('vessel_flag=GBR%2CUSA');
      expect(calledUrl).toContain('page_size=20');
      expect(calledUrl).toContain('page=2');
      expect(calledUrl).toContain('top_n=5');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Validation failed');
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Internal Server Error');
    });

    it('falls back to the default message when nothing else is available', async () => {
      await mockFetch(errorResponse(500, {}, ''));
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Failed to get berth details');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(
        getBerthDetails('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Plain text error');
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await getBerthDetails(
        'port-1',
        'b1',
        '2025-01-01',
        '2025-01-31',
      ).catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  describe('getVesselFlags', () => {
    it('fetches vessel flags and returns data', async () => {
      const data = { vessel_flags: [{ code: 'GBR', name: 'United Kingdom' }] };
      await mockFetch(okResponse(data));

      const result = await getVesselFlags(
        'port-1',
        'b1',
        '2025-01-01',
        '2025-01-31',
      );

      expect(result).toEqual(data);
    });

    it('calls the correct URL with the vessel-flags suffix', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain(
        '/analytics/ports/id/port-1/berths/b1/vessel-flags?',
      );
      expect(calledUrl).toContain('date_start=2025-01-01');
      expect(calledUrl).toContain('date_end=2025-01-31');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Validation failed');
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Internal Server Error');
    });

    it('falls back to the same default message as getBerthDetails', async () => {
      await mockFetch(errorResponse(500, {}, ''));
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Failed to get berth details');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(
        getVesselFlags('port-1', 'b1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Plain text error');
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await getVesselFlags(
        'port-1',
        'b1',
        '2025-01-01',
        '2025-01-31',
      ).catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });
});
