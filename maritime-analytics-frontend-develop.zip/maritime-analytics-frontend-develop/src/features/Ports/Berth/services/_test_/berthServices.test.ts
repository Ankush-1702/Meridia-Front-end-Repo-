import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getBerths, getBerthFilters } from '../berthServices';

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  LEGACY_API_GATEWAY_BASE_URL: 'https://legacy.gateway',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
}));

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => body.message?.toString() ?? 'Error',
  };
}

function errorJsonFails(
  status = 500,
  statusText = 'Server Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: () => Promise.reject(new Error('not json')),
    text: async () => 'Plain text error',
  };
}

describe('berthServices', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getBerths', () => {
    it('fetches berths and returns data', async () => {
      const data = { terminals: [] };
      await mockFetch(okResponse(data));

      const result = await getBerths('port-1', '2025-01-01', '2025-01-31');

      expect(result).toEqual(data);
    });

    it('includes default query params when optional args omitted', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerths('port-1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/analytics/ports/id/port-1/berths?');
      expect(calledUrl).toContain('limit=500');
      expect(calledUrl).toContain('offset=0');
      expect(calledUrl).toContain('date_start=2025-01-01');
      expect(calledUrl).toContain('date_end=2025-01-31');
      expect(calledUrl).toContain('berth_type=');
      expect(calledUrl).toContain('terminal_name=');
    });

    it('reflects custom offset, berthType, terminalName, and limit', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerths(
        'port-1',
        '2025-01-01',
        '2025-01-31',
        50,
        'Container',
        'Terminal A',
        100,
      );

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('offset=50');
      expect(calledUrl).toContain('berth_type=Container');
      expect(calledUrl).toContain('terminal_name=Terminal+A');
      expect(calledUrl).toContain('limit=100');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Validation failed');
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Internal Server Error');
    });

    it('falls back to the default message when nothing else is available', async () => {
      await mockFetch(errorResponse(500, {}, ''));
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Failed to get berths');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(
        getBerths('port-1', '2025-01-01', '2025-01-31'),
      ).rejects.toThrow('Plain text error');
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await getBerths('port-1', '2025-01-01', '2025-01-31').catch(
        (e) => e,
      );

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  describe('getBerthFilters', () => {
    it('fetches berth filters and returns data', async () => {
      const data = { berth_types: ['Container'], terminal_names: ['A'] };
      await mockFetch(okResponse(data));

      const result = await getBerthFilters('port-1');

      expect(result).toEqual(data);
    });

    it('includes default empty berth_types/terminal_names params', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerthFilters('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/analytics/ports/id/port-1/berths/filters?');
      expect(calledUrl).toContain('berth_types=');
      expect(calledUrl).toContain('terminal_names=');
    });

    it('reflects custom berthTypes and terminalName params', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await getBerthFilters('port-1', 'Container,Bulk', 'Terminal A');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('berth_types=Container%2CBulk');
      expect(calledUrl).toContain('terminal_names=Terminal+A');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(getBerthFilters('port-1')).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(getBerthFilters('port-1')).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(getBerthFilters('port-1')).rejects.toThrow(
        'Validation failed',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(getBerthFilters('port-1')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to the default message when nothing else is available', async () => {
      await mockFetch(errorResponse(500, {}, ''));
      await expect(getBerthFilters('port-1')).rejects.toThrow(
        'Failed to get berth filters',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(getBerthFilters('port-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await getBerthFilters('port-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });
});
