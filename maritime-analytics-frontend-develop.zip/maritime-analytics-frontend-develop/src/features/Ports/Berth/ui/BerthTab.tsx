import { PiDownloadSimple } from 'react-icons/pi';
import LoadingOverlay from '../components/LoadingOverlay';
import { useBerthExports } from '../hooks/useBerthExports';
import { createBerthColumnDefs } from '../utils/BerthColDefs';
import BerthDetails from './BerthDetails';
import { useTheme } from '@/app/context/ThemeProvider';
import BerthKpiCards from '@/features/Ports/Berth/components/BerthKpiCards';
import { useBerths } from '@/features/Ports/Berth/hooks/useBerths';
import BerthTimeRangeDropdown from '@/shared/components/CongestionTimeRangeDropdown';
import EntityActionButton from '@/shared/components/EntityActionButton';
import BerthTypeDropdown from '@/shared/components/MultiSelectDropdown';
import TerminalNameDropdown from '@/shared/components/MultiSelectDropdown';
import PoleStarEntityGrid from '@/shared/lib/PoleStarEntityGrid';
import {
  getColor,
  vesselTypesMappings,
} from '@/shared/utils/CongestionAndTrafficUtils';

export default function BerthTab() {
  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  const {
    dateRange,
    setDateRange,
    berthData,
    berthTypes,
    terminalNames,
    handleBerthTypeToggle,
    handleTerminalNameToggle,
    selectedBerthTypes,
    selectedTerminalNames,
    berthRows,
    handleBerthTypeSelectAll,
    handleTerminalNameSelectAll,
    getServerSideData,
    gridRef,
    activeBerthTypes,
    activeTerminalNames,
    resetFilters,
    loading,
    id,
    selectedBerthId,
    setSelectedBerthId,
    selectedBerthName,
    setSelectedBerthName,
    isExpanded,
    setIsExpanded,
  } = useBerths();

  const { handleExportClick, isPolling } = useBerthExports(
    id,
    dateRange.start,
    dateRange.end,
    activeBerthTypes,
    activeTerminalNames,
  );

  if (selectedBerthId) {
    return (
      <BerthDetails
        berthId={selectedBerthId}
        onBack={() => setSelectedBerthId(undefined)}
        berthName={selectedBerthName}
      />
    );
  }

  return (
    <div className="h-[calc(100dvh-135px)]">
      <div className="flex h-full min-h-0 flex-col">
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <BerthTimeRangeDropdown
              label={`Previous 7 Days`}
              key={`Berth time range dropdown`}
              onChange={setDateRange}
              presetsLocalStorageKey="berthDateRange"
              customStartLocalStorageKey="berthCustomStart"
              customEndLocalStorageKey="berthCustomEnd"
            />
            <BerthTypeDropdown
              title={`Berth Type`}
              key={`BerthType`}
              onToggle={handleBerthTypeToggle}
              options={berthTypes?.map((bt) => ({ value: bt, label: bt }))}
              selected={selectedBerthTypes}
              onSelectAll={handleBerthTypeSelectAll}
            />
            <TerminalNameDropdown
              title={`Terminal Name`}
              key={`TerminalName`}
              onToggle={handleTerminalNameToggle}
              options={terminalNames?.map((bt) => ({ value: bt, label: bt }))}
              selected={selectedTerminalNames}
              onSelectAll={handleTerminalNameSelectAll}
            />
            <div className="flex items-center px-4">
              <button
                className="cursor-pointer text-xs text-gray-400 enabled:text-psg-orange-700 enabled:hover:underline disabled:cursor-default"
                onClick={resetFilters}
                disabled={
                  activeBerthTypes.length === 0 &&
                  activeTerminalNames.length === 0
                }
              >
                Reset Filters
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6 flex gap-4">
          <LoadingOverlay loading={loading} className="flex w-full">
            <BerthKpiCards
              title={`Total Berths`}
              value={berthData?.kpi.total_berths || 0}
            />
          </LoadingOverlay>
          <LoadingOverlay loading={loading} className="flex w-full">
            <BerthKpiCards
              title={`Min Dwell Time`}
              value={berthData?.kpi.min_dwell_time || 0}
            />
          </LoadingOverlay>
          <LoadingOverlay loading={loading} className="flex w-full">
            <BerthKpiCards
              title={`Max Dwell Time`}
              value={berthData?.kpi.max_dwell_time || 0}
            />
          </LoadingOverlay>
          <LoadingOverlay loading={loading} className="flex w-full">
            <BerthKpiCards
              title={`Terminal Operators`}
              value={berthData?.kpi.terminal_operators || 0}
            />
          </LoadingOverlay>
        </div>

        <div className="mt-6 flex items-center justify-between gap-6 rounded-t-lg bg-white px-6 py-4 dark:bg-gray-800">
          <div className="flex flex-wrap gap-1.5">
            {vesselTypesMappings
              .filter((vt) =>
                berthRows.some((row) =>
                  row.vessel_types?.some(
                    (seg) =>
                      seg.ship_type_level_3.toLowerCase() ===
                      vt.value.toLowerCase(),
                  ),
                ),
              )
              .map((vt) => (
                <div key={vt.value} className="flex items-center gap-1.5">
                  <span
                    className="inline-block h-3 w-3 shrink-0 rounded-full"
                    style={{ backgroundColor: getColor(vt.value) }}
                  />
                  <span className="whitespace-nowrap text-xs text-gray-600 dark:text-gray-300">
                    {vt.displayValue}
                  </span>
                </div>
              ))}
          </div>
          <div className="flex gap-3">
            <div className="flex items-center px-4">
              <button
                className="cursor-pointer text-xs text-gray-500 hover:underline enabled:hover:text-gray-700 disabled:cursor-default enabled:dark:hover:text-gray-400"
                onClick={() => {
                  if (isExpanded) {
                    gridRef.current?.collapseAll();
                  } else {
                    gridRef.current?.expandAll();
                  }
                  setIsExpanded((prev) => !prev);
                }}
                disabled={
                  activeBerthTypes.length === 0 &&
                  activeTerminalNames.length === 0
                }
              >
                {isExpanded ? 'Collapse All' : 'Expand All'}
              </button>
            </div>
            <div
              className={`mt-5 flex items-center justify-end gap-3 transition-all ${berthRows.length === 0 || isPolling ? 'opacity-50 grayscale' : ''}`}
              style={{
                pointerEvents: berthRows.length === 0 ? 'none' : 'auto',
              }}
            >
              <EntityActionButton
                textLabel={'Export'}
                handleClick={handleExportClick}
                icon={<PiDownloadSimple className="text-gray-400" />}
              />
            </div>
          </div>
        </div>

        <div className="min-h-0 flex-1 rounded-b-lg bg-white dark:bg-gray-800">
          <div className="h-full">
            <PoleStarEntityGrid
              ref={gridRef}
              columns={createBerthColumnDefs()}
              getServerSideData={getServerSideData}
              storageKey="berth-tab"
              onRowClick={(event) => {
                const data = event.data;
                if (data?.berth_id) {
                  setSelectedBerthId(data.berth_id);
                  setSelectedBerthName(data.berth_name);
                }
              }}
              isSideBar={false}
              roundedTop={false}
              getRowStyle={(params) => ({
                cursor: 'pointer',
                ...(params.node.group
                  ? {
                      backgroundColor: isDarkMode ? '#374151' : '#f8f9fa',
                      fontWeight: 600,
                    }
                  : {
                      backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
                    }),
              })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
