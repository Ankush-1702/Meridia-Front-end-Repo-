import { useRef } from 'react';
import { IoMdArrowRoundBack } from 'react-icons/io';
import { useNavigate } from 'react-router';
import { buildDwellTimeSeriesCsv } from '../utils/getCsvContent';
import { useLibrary } from '@/features/library/context/LibraryContext';
import DwellTimeChart from '@/features/Ports/Berth/components/DwellTimeLineSeries';
import LoadingOverlay from '@/features/Ports/Berth/components/LoadingOverlay';
import BerthDetailsSkeleton from '@/features/Ports/Berth/components/LoadingSkeleton';
import VesselOccupancyTimeline from '@/features/Ports/Berth/components/VesselOccupancy';
import VesselOccupancyTimelineHeader from '@/features/Ports/Berth/components/VesselOccupancyHeader';
import { useBerthDetails } from '@/features/Ports/Berth/hooks/useBerthDetails';
import { useVesselOccupancy } from '@/features/Ports/Berth/hooks/useVesselOccupancy';
import { createBerthDetailsColumnDefs } from '@/features/Ports/Berth/utils/BerthDetailsColDefs';
import ChartsDownloadDropDown from '@/shared/components/ChartsDownloadDropDown';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import BerthDetailsTimeRangeDropdown from '@/shared/components/CongestionTimeRangeDropdown';
import FlagDropDown from '@/shared/components/MultiSelectDropdown';
import StatsSummary from '@/shared/components/StatsSummary';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';
import LibraryGrid from '@/shared/lib/PoleStarLibraryGrid';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  sanitizeFilenameSegment,
  toTitleCase,
  truncateTitle,
} from '@/shared/utils/formatUtils';

export default function BerthDetails({
  berthId,
  onBack,
  berthName,
}: {
  berthId?: string;
  onBack?: () => void;
  berthName?: string;
}) {
  const navigate = useNavigate();
  const {
    setDateRange,
    vesselFlags,
    selectedFlags,
    berthData,
    handleFlagSelectAll,
    handleFlagToggle,
    timeRange,
    hasVesselFlags,
    initialLoading,
    loading,
    hasData,
  } = useBerthDetails(berthId);
  const timeline = useVesselOccupancy(berthData);
  const { exportToCSV } = useLibrary();
  const lineChartRef = useRef<PoleStarChartHandle>(null);
  const startDate = berthData?.query.date_start;
  const endDate = berthData?.query.date_end;

  return (
    <div className="h-[calc(100dvh-164px)]">
      {/* Toolbar — always rendered */}
      <div className="flex flex-col">
        <div className="flex items-center justify-between">
          <div className="flex gap-4">
            <div
              className="flex cursor-pointer items-center justify-center gap-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
              onClick={onBack}
              tabIndex={0}
              role="button"
              onKeyDown={onBack}
            >
              <IoMdArrowRoundBack />
              Back
            </div>
            <h3 className="flex items-center justify-center font-bold">
              {berthData?.berth_details.berth_name
                ? berthData.berth_details.berth_name
                : !berthData?.berth_details.berth_name && berthName
                  ? berthName
                  : 'Unkown Berth'}
            </h3>
            <BerthDetailsTimeRangeDropdown
              label={`Previous 7 Days`}
              key={`Berth details time range dropdown`}
              onChange={setDateRange}
              presetsLocalStorageKey="berthDateRange"
              customStartLocalStorageKey="berthCustomStart"
              customEndLocalStorageKey="berthCustomEnd"
            />
            <div
              className={`${hasVesselFlags ? '' : 'opacity-50 grayscale'}`}
              style={{
                pointerEvents: hasVesselFlags ? 'auto' : 'none',
              }}
            >
              <FlagDropDown
                title={`Vessel Flag`}
                key={`flags`}
                onToggle={handleFlagToggle}
                options={vesselFlags?.vessel_flags?.map((vf) => ({
                  value: vf.code,
                  label: vf.name,
                  icon: <FlagIcon flagCode={vf.code} />,
                }))}
                selected={selectedFlags}
                onSelectAll={handleFlagSelectAll}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Content — skeleton or real data */}
      {initialLoading ? (
        <BerthDetailsSkeleton />
      ) : (
        <>
          <div className="mt-6 flex gap-4">
            <div className="relative flex h-[480px] min-w-[420px] flex-col gap-4 rounded-lg bg-white p-6 dark:bg-gray-800">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Berth Details
                </h2>
              </div>
              {berthData?.berth_details &&
              (berthData.berth_details.terminal_operator ||
                berthData.berth_details.terminal_type ||
                berthData.berth_details.berth_facility ||
                berthData.berth_details.length_m ||
                berthData.berth_details.max_loa_m ||
                berthData.berth_details.max_dwt ||
                berthData.berth_details.depth_lw_m ||
                berthData.berth_details.avg_dwell_time ||
                berthData.berth_details.median_dwell_time) ? (
                <LoadingOverlay loading={loading}>
                  <StatsSummary
                    stats={[
                      {
                        label: 'Operator',
                        value:
                          truncateTitle(
                            berthData.berth_details.terminal_operator,
                            30,
                          ) || '-',
                      },
                      {
                        label: 'Type',
                        value: berthData.berth_details.terminal_type || '-',
                      },
                      {
                        label: 'Handling',
                        value: berthData.berth_details.berth_facility || '-',
                      },
                      {
                        label: 'Length',
                        value: berthData.berth_details.length_m || '-',
                      },
                      {
                        label: 'Max LOA',
                        value: berthData.berth_details.max_loa_m || '-',
                      },
                      {
                        label: 'Max DWT',
                        value: berthData.berth_details.max_dwt || '-',
                      },
                      {
                        label: 'Depth (LW)',
                        value: berthData.berth_details.depth_lw_m || '-',
                      },
                      {
                        label: 'Dwell time at berth (avg)',
                        value: berthData.berth_details.avg_dwell_time || '-',
                      },
                      {
                        label: 'Dwell time at berth (median)',
                        value: berthData.berth_details.median_dwell_time || '-',
                      },
                    ]}
                  />
                </LoadingOverlay>
              ) : (
                <LoadingOverlay loading={loading} className="flex flex-1">
                  <CongestionEmptyState />
                </LoadingOverlay>
              )}
            </div>

            <LoadingOverlay loading={loading} className="flex flex-1">
              <div className="relative flex h-[480px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                      Dwell time at berth
                    </h2>
                    <p className="text-xs text-gray-500">
                      {berthData &&
                        toTitleCase(
                          berthData?.query.dwell_series_granularity,
                        )}{' '}
                      avg and median dwell time
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <ChartsDownloadDropDown
                      hasData={hasData}
                      loading={loading}
                      onExportCSV={() => {
                        const csv = buildDwellTimeSeriesCsv(berthData);
                        if (csv)
                          exportToCSV(
                            csv,
                            sanitizeFilenameSegment(
                              `${berthData?.berth_details.berth_name}_dwell-time-at-berth_${startDate}_${endDate}`,
                            ),
                          );
                      }}
                      onExportImage={() =>
                        lineChartRef.current?.downloadImage(
                          sanitizeFilenameSegment(
                            `${berthData?.berth_details.berth_name}_dwell-time-at-berth_${startDate}_${endDate}`,
                          ),
                        )
                      }
                      key={`DwellTimeLineSeries`}
                    />
                  </div>
                </div>
                <div className="relative mt-4 h-full">
                  {berthData && berthData.dwell_time_series ? (
                    <DwellTimeChart response={berthData} ref={lineChartRef} />
                  ) : (
                    <CongestionEmptyState />
                  )}
                </div>
              </div>
            </LoadingOverlay>
          </div>
          <div className="mt-4 pb-6">
            {!berthData && (
              <LoadingOverlay loading={loading}>
                <div className="flex h-60 items-center justify-center rounded-lg bg-white p-6 dark:bg-gray-800">
                  <CongestionEmptyState />
                </div>
              </LoadingOverlay>
            )}
            {berthData && berthData.query.view_mode === 'gantt' && (
              <LoadingOverlay loading={loading}>
                <div className="relative flex flex-col gap-6 rounded-lg bg-white p-6 dark:bg-gray-800">
                  <div className="flex flex-col">
                    <VesselOccupancyTimelineHeader
                      berthData={berthData}
                      offset={timeline.offset}
                      maxOffset={timeline.maxOffset}
                      onPrev={timeline.onPrev}
                      onNext={timeline.onNext}
                    />
                  </div>
                  <div className="">
                    <VesselOccupancyTimeline
                      occupancy={timeline.occupancy}
                      visits={timeline.visits}
                      vessels={timeline.vessels}
                      gaps={timeline.gaps}
                      dateTicks={timeline.dateTicks}
                      windowStart={timeline.windowStart}
                      windowEnd={timeline.windowEnd}
                    />
                  </div>
                </div>
              </LoadingOverlay>
            )}
            {berthData && berthData.query.view_mode === 'table' && (
              <LoadingOverlay loading={loading}>
                <div className="relative flex flex-col gap-2 rounded-lg bg-white dark:bg-gray-800">
                  <div className="flex flex-col gap-2 px-4 py-3">
                    <h2 className="text-sm font-bold">
                      Top vessels by dwell time
                    </h2>
                    <p className="text-xs text-gray-500">
                      {timeRange} - ranked by total time at berth
                    </p>
                  </div>
                  <LibraryGrid
                    rowData={
                      berthData.occupancy.top_vessels as Record<
                        string,
                        unknown
                      >[]
                    }
                    columns={createBerthDetailsColumnDefs()}
                    onRowClick={(row) => {
                      if (row.imo_number)
                        navigate(`/analytics/vessel/${row.imo_number}`);
                    }}
                    roundedTop={false}
                  />
                </div>
              </LoadingOverlay>
            )}
          </div>
        </>
      )}
    </div>
  );
}
