import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import * as useBerthDetailsModule from '../../hooks/useBerthDetails';
import * as useVesselOccupancyModule from '../../hooks/useVesselOccupancy';
import { BerthDetailsApiResponse } from '../../types/berthDetailsTypes';
import BerthDetails from '../BerthDetails';

const mockNavigate = vi.fn();
const mockExportToCSV = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

vi.mock('../../hooks/useBerthDetails');
vi.mock('../../hooks/useVesselOccupancy');

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({ exportToCSV: mockExportToCSV }),
}));

vi.mock('@/features/Ports/Berth/components/DwellTimeLineSeries', () => ({
  default: React.forwardRef(
    (
      _props: { response: BerthDetailsApiResponse },
      ref: React.Ref<{ downloadImage: (name: string) => void }>,
    ) => {
      React.useImperativeHandle(ref, () => ({
        downloadImage: vi.fn(),
      }));
      return <div>DwellTimeChart</div>;
    },
  ),
}));

vi.mock('@/features/Ports/Berth/components/LoadingOverlay', () => ({
  default: ({
    loading,
    children,
  }: {
    loading: boolean;
    children: React.ReactNode;
  }) => (
    <div>
      {loading && <span>Loading...</span>}
      {children}
    </div>
  ),
}));

vi.mock('@/features/Ports/Berth/components/LoadingSkeleton', () => ({
  default: () => <div>Berth Details Skeleton</div>,
}));

vi.mock('@/features/Ports/Berth/components/VesselOccupancy', () => ({
  default: () => <div>Vessel Occupancy Timeline</div>,
}));

vi.mock('@/features/Ports/Berth/components/VesselOccupancyHeader', () => ({
  default: () => <div>Vessel Occupancy Timeline Header</div>,
}));

vi.mock('@/shared/components/ChartsDownloadDropDown', () => ({
  default: ({
    onExportCSV,
    onExportImage,
  }: {
    onExportCSV: () => void;
    onExportImage: () => void;
  }) => (
    <div>
      <button onClick={onExportCSV}>Export CSV</button>
      <button onClick={onExportImage}>Export Image</button>
    </div>
  ),
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>Empty State</div>,
}));

vi.mock('@/shared/components/CongestionTimeRangeDropdown', () => ({
  default: () => <div>Berth Details Time Range Dropdown</div>,
}));

vi.mock('@/shared/components/MultiSelectDropdown', () => ({
  default: ({ title }: { title: string }) => <div>{title} Dropdown</div>,
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: ({
    stats,
  }: {
    stats: { label: string; value: string | number }[];
  }) => (
    <div>
      {stats.map((stat) => (
        <div key={stat.label}>
          {stat.label}: {stat.value}
        </div>
      ))}
    </div>
  ),
}));

vi.mock('@/shared/lib/PoleStarLibraryGrid', () => ({
  default: ({
    onRowClick,
  }: {
    onRowClick: (row: { imo_number?: string }) => void;
  }) => (
    <div>
      Top Vessels Library Grid
      <button onClick={() => onRowClick({ imo_number: '1234567' })}>
        Click Vessel Row
      </button>
      <button onClick={() => onRowClick({ imo_number: undefined })}>
        Click Vessel Row No Imo
      </button>
    </div>
  ),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: () => <div>Flag Icon</div>,
}));

const mockBerthData: BerthDetailsApiResponse = {
  meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
  query: {
    date_start: '2026-01-01',
    date_end: '2026-01-08',
    vessel_flags: [],
    page: 1,
    page_size: 15,
    top_n: 10,
    view_mode: 'gantt',
    dwell_series_granularity: 'daily',
  },
  berth_details: {
    berth_id: 'berth-1',
    berth_name: 'Berth One',
    berth_status: 'active',
    terminal_operator: 'Operator A',
    terminal_type: 'Container',
    berth_facility: 'General Cargo',
    length_m: 200,
    max_loa_m: 250,
    max_dwt: 50000,
    depth_lw_m: 12,
    avg_dwell_time: 5,
    median_dwell_time: 4,
  },
  dwell_time_series: [
    { period_start: '2026-01-01', avg_dwell_time: 5, median_dwell_time: 4 },
  ],
  occupancy: {
    display_date_start: '2026-01-01',
    display_date_end: '2026-01-08',
    gap_time_total: 10,
    gap_time_avg: 5,
    pagination: {
      total_days: 7,
      page: 1,
      page_size: 15,
      day_start: 0,
      day_end: 7,
    },
    visits: [],
    gaps: [],
    top_vessels: [],
  },
};

const defaultUseBerthDetailsReturn = {
  setDateRange: vi.fn(),
  vesselFlags: { vessel_flags: [{ code: 'US', name: 'United States' }] },
  selectedFlags: { US: true },
  berthData: mockBerthData,
  handleFlagSelectAll: vi.fn(),
  handleFlagToggle: vi.fn(),
  timeRange: 'Previous 7 Days',
  hasVesselFlags: true,
  initialLoading: false,
  loading: false,
  hasData: true,
};

const defaultUseVesselOccupancyReturn = {
  occupancy: mockBerthData.occupancy,
  visits: [],
  vessels: [],
  gaps: [],
  dateTicks: [],
  timelineEnd: 7,
  offset: 0,
  maxOffset: 0,
  onPrev: vi.fn(),
  onNext: vi.fn(),
  windowStart: 0,
  windowEnd: 15,
};

describe('BerthDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue(
      defaultUseBerthDetailsReturn,
    );
    (useVesselOccupancyModule.useVesselOccupancy as Mock).mockReturnValue(
      defaultUseVesselOccupancyReturn,
    );
  });

  it('renders the loading skeleton when initialLoading is true', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      initialLoading: true,
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('Berth Details Skeleton')).toBeInTheDocument();
    expect(screen.queryByText('DwellTimeChart')).not.toBeInTheDocument();
  });

  it('renders empty states when berthData is undefined', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: undefined,
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getAllByText('Empty State').length).toBeGreaterThan(0);
    expect(screen.queryByText('DwellTimeChart')).not.toBeInTheDocument();
  });

  it('renders CongestionEmptyState for berth details panel when all optional fields are falsy', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: {
        ...mockBerthData,
        berth_details: {
          ...mockBerthData.berth_details,
          terminal_operator: '',
          terminal_type: '',
          berth_facility: '',
          length_m: 0,
          max_loa_m: 0,
          max_dwt: 0,
          depth_lw_m: 0,
          avg_dwell_time: 0,
          median_dwell_time: 0,
        },
      },
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('Empty State')).toBeInTheDocument();
    expect(screen.queryByText(/Operator:/)).not.toBeInTheDocument();
  });

  it('renders StatsSummary with berth details stats when at least one field is populated', () => {
    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('Operator: Operator A')).toBeInTheDocument();
    expect(screen.getByText('Type: Container')).toBeInTheDocument();
    expect(screen.getByText('Handling: General Cargo')).toBeInTheDocument();
  });

  it('shows berthData.berth_details.berth_name as the header title when present', () => {
    render(<BerthDetails berthId="berth-1" berthName="Fallback Name" />);

    expect(screen.getByText('Berth One')).toBeInTheDocument();
    expect(screen.queryByText('Fallback Name')).not.toBeInTheDocument();
  });

  it('falls back to the berthName prop when berth_details.berth_name is absent', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: {
        ...mockBerthData,
        berth_details: { ...mockBerthData.berth_details, berth_name: '' },
      },
    });

    render(<BerthDetails berthId="berth-1" berthName="Fallback Name" />);

    expect(screen.getByText('Fallback Name')).toBeInTheDocument();
  });

  it("falls back to the literal 'Unkown Berth' string when both berth_name and berthName are absent", () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: {
        ...mockBerthData,
        berth_details: { ...mockBerthData.berth_details, berth_name: '' },
      },
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('Unkown Berth')).toBeInTheDocument();
  });

  it('calls onBack when the Back control is clicked', () => {
    const onBack = vi.fn();
    render(<BerthDetails berthId="berth-1" onBack={onBack} />);

    fireEvent.click(screen.getByText('Back'));

    expect(onBack).toHaveBeenCalled();
  });

  it('applies disabled styling to the flag dropdown when hasVesselFlags is false', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      hasVesselFlags: false,
    });

    render(<BerthDetails berthId="berth-1" />);

    const flagDropdown = screen.getByText('Vessel Flag Dropdown');
    expect(flagDropdown.closest('div')).toHaveStyle({ pointerEvents: 'none' });
  });

  it('renders the dwell time chart when berthData.dwell_time_series is present', () => {
    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('DwellTimeChart')).toBeInTheDocument();
  });

  it('renders CongestionEmptyState instead of the chart when dwell_time_series is missing', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: {
        ...mockBerthData,
        dwell_time_series:
          undefined as unknown as BerthDetailsApiResponse['dwell_time_series'],
      },
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.queryByText('DwellTimeChart')).not.toBeInTheDocument();
    expect(screen.getAllByText('Empty State').length).toBeGreaterThan(0);
  });

  it("renders the gantt timeline components when view_mode is 'gantt'", () => {
    render(<BerthDetails berthId="berth-1" />);

    expect(
      screen.getByText('Vessel Occupancy Timeline Header'),
    ).toBeInTheDocument();
    expect(screen.getByText('Vessel Occupancy Timeline')).toBeInTheDocument();
    expect(
      screen.queryByText('Top Vessels Library Grid'),
    ).not.toBeInTheDocument();
  });

  it("renders the top-vessels library grid when view_mode is 'table' and navigates on row click", () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: {
        ...mockBerthData,
        query: { ...mockBerthData.query, view_mode: 'table' },
      },
    });

    render(<BerthDetails berthId="berth-1" />);

    expect(screen.getByText('Top Vessels Library Grid')).toBeInTheDocument();
    expect(
      screen.queryByText('Vessel Occupancy Timeline'),
    ).not.toBeInTheDocument();

    fireEvent.click(screen.getByText('Click Vessel Row'));
    expect(mockNavigate).toHaveBeenCalledWith('/analytics/vessel/1234567');

    fireEvent.click(screen.getByText('Click Vessel Row No Imo'));
    expect(mockNavigate).toHaveBeenCalledTimes(1);
  });

  it('builds and exports the dwell time series CSV via the real buildDwellTimeSeriesCsv implementation', () => {
    render(<BerthDetails berthId="berth-1" />);

    fireEvent.click(screen.getByText('Export CSV'));

    expect(mockExportToCSV).toHaveBeenCalledTimes(1);
    const [csv, filename] = mockExportToCSV.mock.calls[0];
    expect(csv).toContain('Berth Name');
    expect(filename).toContain('Berth-One');
  });

  it('does not export CSV when buildDwellTimeSeriesCsv returns undefined (no berthData)', () => {
    (useBerthDetailsModule.useBerthDetails as Mock).mockReturnValue({
      ...defaultUseBerthDetailsReturn,
      berthData: undefined,
    });

    render(<BerthDetails berthId="berth-1" />);

    fireEvent.click(screen.getByText('Export CSV'));

    expect(mockExportToCSV).not.toHaveBeenCalled();
  });

  it('calls downloadImage via the chart ref when Export Image is clicked', () => {
    render(<BerthDetails berthId="berth-1" />);

    expect(() =>
      fireEvent.click(screen.getByText('Export Image')),
    ).not.toThrow();
  });
});
