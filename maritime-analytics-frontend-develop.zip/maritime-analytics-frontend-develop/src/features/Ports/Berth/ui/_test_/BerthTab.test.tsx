import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import * as useBerthExportsModule from '../../hooks/useBerthExports';
import * as useBerthsModule from '../../hooks/useBerths';
import { BerthApiResponse, BerthRow } from '../../types/berthTypes';
import BerthTab from '../BerthTab';

vi.mock('../../hooks/useBerths');
vi.mock('../../hooks/useBerthExports');

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light', toggleTheme: vi.fn() }),
}));

vi.mock('../BerthDetails', () => ({
  default: ({
    berthId,
    berthName,
    onBack,
  }: {
    berthId: string;
    berthName?: string;
    onBack: () => void;
  }) => (
    <div>
      Berth Details Stub - {berthId} - {berthName}
      <button onClick={onBack}>Back</button>
    </div>
  ),
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    textLabel,
    handleClick,
  }: {
    textLabel: string;
    handleClick: () => void;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/shared/components/CongestionTimeRangeDropdown', () => ({
  default: ({
    onChange,
  }: {
    onChange: (range: { start: string; end: string }) => void;
  }) => (
    <button
      onClick={() => onChange({ start: '2026-01-01', end: '2026-01-08' })}
    >
      Time Range Dropdown
    </button>
  ),
}));

vi.mock('@/shared/components/MultiSelectDropdown', () => ({
  default: ({
    title,
    onToggle,
    onSelectAll,
  }: {
    title: string;
    onToggle: (value: string, checked: boolean) => void;
    onSelectAll: (checked: boolean) => void;
  }) => (
    <div>
      <button onClick={() => onToggle('General', true)}>{title} Toggle</button>
      <button onClick={() => onSelectAll(true)}>{title} SelectAll</button>
    </div>
  ),
}));

vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: React.forwardRef(
    (
      props: {
        onRowClick: (event: { data?: BerthRow }) => void;
      },
      ref: React.Ref<unknown>,
    ) => {
      React.useImperativeHandle(ref, () => ({
        refresh: vi.fn(),
        expandAll: vi.fn(),
        collapseAll: vi.fn(),
      }));
      return (
        <div>
          Entity Grid
          <button
            onClick={() =>
              props.onRowClick({
                data: {
                  berth_id: 'berth-1',
                  berth_name: 'Berth One',
                } as BerthRow,
              })
            }
          >
            Click Row
          </button>
          <button onClick={() => props.onRowClick({ data: undefined })}>
            Click Row No Data
          </button>
        </div>
      );
    },
  ),
}));

const mockBerthData: BerthApiResponse = {
  meta: {
    request_id: 'req-1',
    request_timestamp: '2026-01-01T00:00:00Z',
    total_count: 1,
    limit: 500,
    offset: 0,
  },
  query: {
    date_start: '2026-01-01',
    date_end: '2026-01-08',
    terminal_type: [],
    terminal_name: [],
  },
  port_information: {
    id: 'port-1',
    name: 'Test Port',
    unlocode: 'TSTPT',
    country: 'Testland',
  },
  kpi: {
    total_berths: 12,
    min_dwell_time: 3,
    max_dwell_time: 48,
    terminal_operators: 4,
  },
  terminals: [],
};

const mockBerthRows: BerthRow[] = [
  {
    berth_id: 'berth-1',
    berth_name: 'Berth One',
    berth_status: 'active',
    berth_type: 'General',
    berth_facility: 'Container',
    length_m: 200,
    max_loa_m: 250,
    max_dwt: 50000,
    depth_lw_m: 12,
    min_dwell_time: 2,
    avg_dwell_time: 5,
    median_dwell_time: 4,
    max_dwell_time: 10,
    vessel_types: [
      { ship_type_level_3: 'Bulk carrier', visit_count: 3, proportion: 1 },
    ],
    terminal_name: 'Terminal A',
  },
];

const mockSetSelectedBerthId = vi.fn();
const mockSetSelectedBerthName = vi.fn();
const mockSetIsExpanded = vi.fn();

const defaultUseBerthsReturn = {
  dateRange: { start: '2026-01-01', end: '2026-01-08' },
  setDateRange: vi.fn(),
  berthData: mockBerthData,
  berthTypes: ['General', 'Container'],
  terminalNames: ['Terminal A', 'Terminal B'],
  handleBerthTypeToggle: vi.fn(),
  handleTerminalNameToggle: vi.fn(),
  selectedBerthTypes: { General: true },
  selectedTerminalNames: { 'Terminal A': true },
  berthRows: mockBerthRows,
  handleBerthTypeSelectAll: vi.fn(),
  handleTerminalNameSelectAll: vi.fn(),
  getServerSideData: vi.fn(),
  gridRef: { current: null },
  activeBerthTypes: ['General'],
  activeTerminalNames: ['Terminal A'],
  resetFilters: vi.fn(),
  loading: false,
  id: 'port-1',
  selectedBerthId: undefined as string | undefined,
  setSelectedBerthId: mockSetSelectedBerthId,
  selectedBerthName: undefined as string | undefined,
  setSelectedBerthName: mockSetSelectedBerthName,
  isExpanded: false,
  setIsExpanded: mockSetIsExpanded,
};

const defaultUseBerthExportsReturn = {
  handleExportClick: vi.fn(),
  isPolling: false,
};

describe('BerthTab', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    window.matchMedia = vi.fn().mockReturnValue({
      matches: false,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    });
    (useBerthsModule.useBerths as Mock).mockReturnValue(defaultUseBerthsReturn);
    (useBerthExportsModule.useBerthExports as Mock).mockReturnValue(
      defaultUseBerthExportsReturn,
    );
  });

  it('renders KPI cards with values from berthData.kpi', () => {
    render(<BerthTab />);

    expect(screen.getByText('Total Berths')).toBeInTheDocument();
    expect(screen.getByText('12')).toBeInTheDocument();
    expect(screen.getByText('Min Dwell Time')).toBeInTheDocument();
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('Max Dwell Time')).toBeInTheDocument();
    expect(screen.getByText('48')).toBeInTheDocument();
    expect(screen.getByText('Terminal Operators')).toBeInTheDocument();
    expect(screen.getByText('4')).toBeInTheDocument();
  });

  it('shows 0 fallback for KPI cards when berthData is undefined', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      berthData: undefined,
    });

    render(<BerthTab />);

    expect(screen.getAllByText('0')).toHaveLength(4);
  });

  it('shows loading overlay text when loading is true', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      loading: true,
    });

    render(<BerthTab />);

    expect(screen.getAllByText('Loading...').length).toBeGreaterThan(0);
  });

  it('disables Reset Filters button when no active filters', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      activeBerthTypes: [],
      activeTerminalNames: [],
    });

    render(<BerthTab />);

    expect(screen.getByText('Reset Filters')).toBeDisabled();
  });

  it('enables Reset Filters button when there are active filters and calls resetFilters on click', () => {
    render(<BerthTab />);

    const resetButton = screen.getByText('Reset Filters');
    expect(resetButton).not.toBeDisabled();

    fireEvent.click(resetButton);

    expect(defaultUseBerthsReturn.resetFilters).toHaveBeenCalled();
  });

  it('renders vessel type legend entries that match berthRows vessel_types', () => {
    render(<BerthTab />);

    expect(screen.getByText('Bulk Carrier')).toBeInTheDocument();
  });

  it('does not render legend entries with no matching berthRows', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      berthRows: [],
    });

    render(<BerthTab />);

    expect(screen.queryByText('Bulk Carrier')).not.toBeInTheDocument();
  });

  it('shows Expand All by default and toggles to Collapse All on click', () => {
    render(<BerthTab />);

    const expandButton = screen.getByText('Expand All');
    fireEvent.click(expandButton);

    expect(mockSetIsExpanded).toHaveBeenCalled();
  });

  it('shows Collapse All label when isExpanded is true', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      isExpanded: true,
    });

    render(<BerthTab />);

    expect(screen.getByText('Collapse All')).toBeInTheDocument();
  });

  it('disables Expand/Collapse All button when there are no active filters', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      activeBerthTypes: [],
      activeTerminalNames: [],
    });

    render(<BerthTab />);

    expect(screen.getByText('Expand All')).toBeDisabled();
  });

  it('calls handleExportClick when Export button is clicked', () => {
    render(<BerthTab />);

    fireEvent.click(screen.getByText('Export'));

    expect(defaultUseBerthExportsReturn.handleExportClick).toHaveBeenCalled();
  });

  it('sets selectedBerthId and selectedBerthName on grid row click', () => {
    render(<BerthTab />);

    fireEvent.click(screen.getByText('Click Row'));

    expect(mockSetSelectedBerthId).toHaveBeenCalledWith('berth-1');
    expect(mockSetSelectedBerthName).toHaveBeenCalledWith('Berth One');
  });

  it('does not set selected berth when row click data has no berth_id', () => {
    render(<BerthTab />);

    fireEvent.click(screen.getByText('Click Row No Data'));

    expect(mockSetSelectedBerthId).not.toHaveBeenCalled();
    expect(mockSetSelectedBerthName).not.toHaveBeenCalled();
  });

  it('calls handleBerthTypeToggle and handleTerminalNameToggle from dropdowns', () => {
    render(<BerthTab />);

    fireEvent.click(screen.getByText('Berth Type Toggle'));
    expect(defaultUseBerthsReturn.handleBerthTypeToggle).toHaveBeenCalledWith(
      'General',
      true,
    );

    fireEvent.click(screen.getByText('Terminal Name Toggle'));
    expect(
      defaultUseBerthsReturn.handleTerminalNameToggle,
    ).toHaveBeenCalledWith('General', true);
  });

  it('renders the mocked BerthDetails component when selectedBerthId is set, and onBack clears it', () => {
    (useBerthsModule.useBerths as Mock).mockReturnValue({
      ...defaultUseBerthsReturn,
      selectedBerthId: 'berth-1',
      selectedBerthName: 'Berth One',
    });

    render(<BerthTab />);

    expect(screen.getByText(/Berth Details Stub/)).toBeInTheDocument();
    expect(screen.queryByText('Entity Grid')).not.toBeInTheDocument();

    fireEvent.click(screen.getByText('Back'));

    expect(mockSetSelectedBerthId).toHaveBeenCalledWith(undefined);
  });
});
