function SkeletonBlock({ className }: { className?: string }) {
  return (
    <div
      className={`animate-pulse rounded-lg bg-gray-200 dark:bg-gray-700 ${className ?? ''}`}
    />
  );
}

export default function BerthDetailsContentSkeleton() {
  return (
    <>
      <div className="mt-6 flex gap-4">
        <div className="flex h-[480px] w-[440px] flex-col gap-4 rounded-lg bg-white p-6 dark:bg-gray-800">
          <SkeletonBlock className="h-5 w-28" />
          <div className="flex flex-col gap-3">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between gap-20">
                <SkeletonBlock className="h-8 w-full" />
              </div>
            ))}
          </div>
        </div>
        <div className="flex h-[480px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <SkeletonBlock className="h-5 w-36" />
              <SkeletonBlock className="h-4 w-52" />
            </div>
            <SkeletonBlock className="h-8 w-8 rounded-md" />
          </div>
          <SkeletonBlock className="mt-4 h-full w-full" />
        </div>
      </div>
      <div className="mt-4 pb-6">
        <div className="flex flex-col gap-6 rounded-lg bg-white p-6 dark:bg-gray-800">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <SkeletonBlock className="h-5 w-36" />
              <SkeletonBlock className="h-4 w-48" />
            </div>
            <div className="flex gap-2">
              <SkeletonBlock className="h-8 w-20 rounded-md" />
              <SkeletonBlock className="h-8 w-20 rounded-md" />
            </div>
          </div>
          <SkeletonBlock className="h-[120px] w-full" />
        </div>
      </div>
    </>
  );
}
