import { Tooltip } from 'flowbite-react';
import { useNavigate } from 'react-router';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import { getDisplayName } from '@/shared/utils/CongestionAndTrafficUtils';
import { formatUTCDate, truncateTitle } from '@/shared/utils/formatUtils';

const WINDOW_DAYS = 15;

interface VesselOccupancyTimelineProps {
  occupancy?: {
    display_date_start: string;
    display_date_end: string;
  };
  visits: unknown[];
  vessels: Array<{
    vessel_name: string;
    imo_number: string;
    vessel_flag: string;
    ship_type_level_3: string;
    arrival_time: string;
    departure_time: string;
    hours_at_berth: number;
    start: number;
    end: number;
  }>;
  gaps: Array<{
    start: number;
    end: number;
    gap_duration: number;
    raw_start_time: string;
    raw_end_time: string;
  }>;
  dateTicks: Array<{ label: string; day: number }>;
  windowStart: number;
  windowEnd: number;
}

export default function VesselOccupancyTimeline({
  occupancy,
  visits,
  vessels,
  gaps,
  dateTicks,
  windowStart,
  windowEnd,
}: VesselOccupancyTimelineProps) {
  const navigate = useNavigate();

  const toPercent = (val: number) => ((val - windowStart) / WINDOW_DAYS) * 100;

  const visibleVessels = vessels
    .filter((v) => v.end > windowStart && v.start < windowEnd)
    .map((v) => ({
      ...v,
      start: Math.max(v.start, windowStart),
      end: Math.min(v.end, windowEnd),
    }));

  const visibleGaps = gaps
    .filter((g) => g.end > windowStart && g.start < windowEnd)
    .map((g) => ({
      ...g,
      start: Math.max(g.start, windowStart),
      end: Math.min(g.end, windowEnd),
    }));

  const visibleDates = dateTicks.filter(
    (d) => d.day >= windowStart && d.day <= windowEnd,
  );

  if (!occupancy || visits.length === 0) {
    return (
      <div className="h-[180px]">
        <CongestionEmptyState />
      </div>
    );
  }

  return (
    <div className="relative ml-24 mr-4">
      <div className="relative mb-4 h-4 text-xs text-gray-400">
        {visibleDates.map((d) => (
          <span
            key={d.day}
            className="absolute whitespace-nowrap"
            style={{
              left: `${toPercent(d.day)}%`,
              transform: 'translateX(-50%)',
            }}
          >
            {d.label}
          </span>
        ))}
      </div>

      {/* Occupied row */}
      <div className="relative mb-4 flex h-10 items-center">
        <div className="absolute -left-24 w-20 pr-4 text-right text-sm text-gray-500">
          Occupied
        </div>
        <div className="relative h-full w-full">
          {visibleVessels.map((v, i) => {
            const widthPct = toPercent(v.end) - toPercent(v.start);
            return (
              <div
                key={i}
                className="absolute top-0 h-full"
                style={{
                  left: `${toPercent(v.start)}%`,
                  width: `${widthPct}%`,
                }}
              >
                <Tooltip
                  placement="top"
                  className="rounded-lg bg-gray-800 p-2 text-xs text-white"
                  theme={{ target: 'h-full w-full' }}
                  content={
                    <div className="min-w-[200px] text-xs">
                      <div
                        className="grid gap-x-3 gap-y-0.5"
                        style={{ gridTemplateColumns: 'auto 1fr' }}
                      >
                        <span className="whitespace-nowrap text-gray-400">
                          Vessel
                        </span>
                        <span className="max-w-[140px] truncate text-gray-200">
                          {v.vessel_name || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          IMO
                        </span>
                        <span className="text-gray-200">
                          {v.imo_number || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          Flag
                        </span>
                        <span className="text-gray-200">
                          {v.vessel_flag || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          Type
                        </span>
                        <span className="text-gray-200">
                          {getDisplayName(v.ship_type_level_3) || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          From
                        </span>
                        <span className="text-gray-200">
                          {formatUTCDate(v.arrival_time) || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          To
                        </span>
                        <span className="text-gray-200">
                          {formatUTCDate(v.departure_time) || 'N/A'}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          Duration
                        </span>
                        <span className="text-gray-200">
                          {v.hours_at_berth || 'N/A'}
                        </span>
                      </div>
                      <p className="mt-1 text-center italic text-gray-400">
                        Click for more vessel details
                      </p>
                    </div>
                  }
                >
                  <div
                    className="flex h-full w-full items-center justify-center truncate rounded px-2 text-xs font-medium text-white"
                    style={{
                      backgroundColor: '#d54a1a',
                      border: '1px solid rgba(255,255,255,0.1)',
                    }}
                    onClick={() => {
                      navigate(`/analytics/vessel/${v.imo_number}`);
                    }}
                    tabIndex={0}
                    role="button"
                    onKeyDown={() => {
                      navigate(`/analytics/vessel/${v.imo_number}`);
                    }}
                  >
                    {widthPct > 8 ? truncateTitle(v.vessel_name, 10) : null}
                  </div>
                </Tooltip>
              </div>
            );
          })}
        </div>
      </div>

      {/* Gap row */}
      <div className="relative flex h-10 items-center">
        <div className="absolute -left-24 w-20 pr-4 text-right text-sm text-gray-500">
          Gap
        </div>
        <div className="relative h-full w-full">
          {visibleGaps.map((g, i) => {
            const widthPct = Math.max(toPercent(g.end) - toPercent(g.start), 2);
            return (
              <div
                key={i}
                className="absolute top-1 h-8"
                style={{
                  left: `${toPercent(g.start)}%`,
                  width: `${widthPct}%`,
                }}
              >
                <Tooltip
                  placement="top"
                  className="rounded-lg bg-gray-800 p-2 text-xs text-white"
                  theme={{ target: 'h-full w-full' }}
                  content={
                    <div className="min-w-[190px] text-xs">
                      <div
                        className="grid gap-x-3 gap-y-0.5"
                        style={{ gridTemplateColumns: 'auto 1fr' }}
                      >
                        <span className="whitespace-nowrap text-gray-400">
                          From
                        </span>
                        <span className="text-gray-200">
                          {formatUTCDate(g.raw_start_time)}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          To
                        </span>
                        <span className="text-gray-200">
                          {formatUTCDate(g.raw_end_time)}
                        </span>
                        <span className="whitespace-nowrap text-gray-400">
                          Duration
                        </span>
                        <span className="text-gray-200">
                          {g.gap_duration.toFixed(1)} hrs
                        </span>
                      </div>
                    </div>
                  }
                >
                  <div
                    className="h-full w-full rounded"
                    style={{ backgroundColor: '#f88e63' }}
                  />
                </Tooltip>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
