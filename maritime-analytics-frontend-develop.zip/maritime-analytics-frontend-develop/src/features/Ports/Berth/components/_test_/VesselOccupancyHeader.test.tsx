import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import VesselOccupancyTimelineHeader from '../VesselOccupancyHeader';
import { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';

function buildBerthData(
  overrides: Partial<BerthDetailsApiResponse['occupancy']> = {},
): BerthDetailsApiResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    query: {
      date_start: '2026-01-01',
      date_end: '2026-01-15',
      vessel_flags: [],
      page: 1,
      page_size: 15,
      top_n: 10,
      view_mode: 'gantt',
      dwell_series_granularity: 'daily',
    },
    berth_details: {
      berth_id: 'b1',
      berth_name: 'Berth 1',
      berth_status: 'active',
      terminal_operator: 'Op',
      terminal_type: 'Container',
      berth_facility: 'Facility',
      length_m: 100,
      max_loa_m: 200,
      max_dwt: 300,
      depth_lw_m: 10,
      avg_dwell_time: 5,
      median_dwell_time: 4,
    },
    dwell_time_series: [],
    occupancy: {
      display_date_start: '2026-01-01T00:00:00Z',
      display_date_end: '2026-01-15T00:00:00Z',
      gap_time_total: 12.34,
      gap_time_avg: 3.21,
      pagination: {
        total_days: 14,
        page: 1,
        page_size: 15,
        day_start: 0,
        day_end: 14,
      },
      visits: [],
      gaps: [],
      top_vessels: [],
      ...overrides,
    },
  };
}

describe('VesselOccupancyTimelineHeader', () => {
  const onPrev = vi.fn();
  const onNext = vi.fn();

  it('renders empty date range and zeroed gap times when berthData is undefined', () => {
    render(
      <VesselOccupancyTimelineHeader
        berthData={undefined}
        offset={0}
        maxOffset={0}
        onPrev={onPrev}
        onNext={onNext}
      />,
    );

    expect(screen.getByText('Vessel occupancy')).toBeInTheDocument();
    expect(screen.getAllByText('0.0 hrs')).toHaveLength(2);
  });

  it('renders formatted date range and gap times when berthData is present', () => {
    render(
      <VesselOccupancyTimelineHeader
        berthData={buildBerthData()}
        offset={0}
        maxOffset={7}
        onPrev={onPrev}
        onNext={onNext}
      />,
    );

    expect(screen.getByText('12.3 hrs')).toBeInTheDocument();
    expect(screen.getByText('3.2 hrs')).toBeInTheDocument();
  });

  it('disables the Prev button when offset is 0', () => {
    render(
      <VesselOccupancyTimelineHeader
        berthData={undefined}
        offset={0}
        maxOffset={7}
        onPrev={onPrev}
        onNext={onNext}
      />,
    );

    expect(screen.getByText('← Prev')).toBeDisabled();
    expect(screen.getByText('Next →')).not.toBeDisabled();
  });

  it('disables the Next button when offset >= maxOffset', () => {
    render(
      <VesselOccupancyTimelineHeader
        berthData={undefined}
        offset={7}
        maxOffset={7}
        onPrev={onPrev}
        onNext={onNext}
      />,
    );

    expect(screen.getByText('Next →')).toBeDisabled();
    expect(screen.getByText('← Prev')).not.toBeDisabled();
  });

  it('calls onPrev and onNext when clicked', () => {
    render(
      <VesselOccupancyTimelineHeader
        berthData={undefined}
        offset={3}
        maxOffset={7}
        onPrev={onPrev}
        onNext={onNext}
      />,
    );

    fireEvent.click(screen.getByText('← Prev'));
    expect(onPrev).toHaveBeenCalled();

    fireEvent.click(screen.getByText('Next →'));
    expect(onNext).toHaveBeenCalled();
  });
});
