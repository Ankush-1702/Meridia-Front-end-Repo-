import { render, screen } from '@testing-library/react';
import { AgChartOptions } from 'ag-charts-enterprise';
import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import DwellTimeChart from '../DwellTimeLineSeries';
import * as themeModule from '@/app/context/ThemeProvider';
import { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: vi.fn(),
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>Empty State</div>,
}));

vi.mock('@/shared/lib/PoleStarCharts', () => ({
  PoleStarChart: React.forwardRef(
    (
      { options }: { options: AgChartOptions },
      ref: React.Ref<{ downloadImage: (fileName?: string) => void }>,
    ) => {
      React.useImperativeHandle(ref, () => ({
        downloadImage: vi.fn(),
      }));
      return <div data-testid="chart">{JSON.stringify(options)}</div>;
    },
  ),
}));

function buildBerthDetailsResponse(
  dwellTimeSeries: BerthDetailsApiResponse['dwell_time_series'],
): BerthDetailsApiResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    query: {
      date_start: '2026-01-01',
      date_end: '2026-01-15',
      vessel_flags: [],
      page: 1,
      page_size: 15,
      top_n: 10,
      view_mode: 'gantt',
      dwell_series_granularity: 'daily',
    },
    berth_details: {
      berth_id: 'b1',
      berth_name: 'Berth 1',
      berth_status: 'active',
      terminal_operator: 'Op',
      terminal_type: 'Container',
      berth_facility: 'Facility',
      length_m: 100,
      max_loa_m: 200,
      max_dwt: 300,
      depth_lw_m: 10,
      avg_dwell_time: 5,
      median_dwell_time: 4,
    },
    dwell_time_series: dwellTimeSeries,
    occupancy: {
      display_date_start: '2026-01-01T00:00:00Z',
      display_date_end: '2026-01-15T00:00:00Z',
      gap_time_total: 0,
      gap_time_avg: 0,
      pagination: {
        total_days: 14,
        page: 1,
        page_size: 15,
        day_start: 0,
        day_end: 14,
      },
      visits: [],
      gaps: [],
      top_vessels: [],
    },
  };
}

function buildCongestionResponse(
  dwellSeries: ICongestionResponse['dwell_series'],
): ICongestionResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '2026-01-01T00:00:00Z' },
    query: {
      date_start: '2026-01-01',
      date_end: '2026-01-15',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: null,
    totals: null,
    data: [],
    dwell_series: dwellSeries,
  };
}

describe('DwellTimeChart', () => {
  beforeEach(() => {
    (themeModule.useTheme as Mock).mockReturnValue({
      theme: 'light',
      saveTheme: vi.fn(),
    });
    window.matchMedia =
      window.matchMedia ??
      (vi.fn().mockReturnValue({
        matches: false,
      }) as unknown as typeof window.matchMedia);
    vi.spyOn(window, 'matchMedia').mockReturnValue({
      matches: false,
    } as MediaQueryList);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('renders empty state when all dwell_time_series values are zero', () => {
    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 0,
            median_dwell_time: 0,
          },
        ])}
      />,
    );

    expect(screen.getByText('Empty State')).toBeInTheDocument();
  });

  it('renders empty state when dwell_time_series is empty', () => {
    render(<DwellTimeChart response={buildBerthDetailsResponse([])} />);

    expect(screen.getByText('Empty State')).toBeInTheDocument();
  });

  it('renders the chart with normalised BerthDetailsApiResponse data', () => {
    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 5,
            median_dwell_time: 4,
          },
          {
            period_start: '2026-01-02',
            avg_dwell_time: 6,
            median_dwell_time: 5,
          },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as AgChartOptions & {
      data: { period: string; avgDwell: number; medianDwell: number }[];
    };

    expect(options.data).toEqual([
      { period: '2026-01-01', avgDwell: 5, medianDwell: 4 },
      { period: '2026-01-02', avgDwell: 6, medianDwell: 5 },
    ]);
  });

  it('renders the chart with normalised ICongestionResponse (dwell_series) data', () => {
    render(
      <DwellTimeChart
        response={buildCongestionResponse([
          { period_key: '2026-01-01', avg_dwell_time: 7, median_dwell_time: 6 },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as {
      data: { period: string; avgDwell: number; medianDwell: number }[];
    };

    expect(options.data).toEqual([
      { period: '2026-01-01', avgDwell: 7, medianDwell: 6 },
    ]);
  });

  it('enables markers when there is a single data point', () => {
    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 5,
            median_dwell_time: 4,
          },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as {
      series: { marker: { enabled: boolean; size: number } }[];
    };

    expect(options.series[0].marker.enabled).toBe(true);
    expect(options.series[0].marker.size).toBe(8);
  });

  it('disables markers when there are multiple data points', () => {
    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 5,
            median_dwell_time: 4,
          },
          {
            period_start: '2026-01-02',
            avg_dwell_time: 6,
            median_dwell_time: 5,
          },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as {
      series: { marker: { enabled: boolean; size: number } }[];
    };

    expect(options.series[0].marker.enabled).toBe(false);
    expect(options.series[0].marker.size).toBe(0);
  });

  it('uses dark-mode background when theme is dark', () => {
    (themeModule.useTheme as Mock).mockReturnValue({
      theme: 'dark',
      saveTheme: vi.fn(),
    });

    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 5,
            median_dwell_time: 4,
          },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as {
      background: { fill: string };
    };

    expect(options.background.fill).toBe('#1F2937');
  });

  it('uses dark-mode background when theme is system and OS prefers dark', () => {
    (themeModule.useTheme as Mock).mockReturnValue({
      theme: 'system',
      saveTheme: vi.fn(),
    });
    vi.spyOn(window, 'matchMedia').mockReturnValue({
      matches: true,
    } as MediaQueryList);

    render(
      <DwellTimeChart
        response={buildBerthDetailsResponse([
          {
            period_start: '2026-01-01',
            avg_dwell_time: 5,
            median_dwell_time: 4,
          },
        ])}
      />,
    );

    const chart = screen.getByTestId('chart');
    const options = JSON.parse(chart.textContent ?? '{}') as {
      background: { fill: string };
    };

    expect(options.background.fill).toBe('#1F2937');
  });
});
