import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, beforeAll } from 'vitest';
import VesselTypePill from '../VesselTypePill';
import { VesselTypes } from '@/features/Ports/Berth/types/berthTypes';

beforeAll(() => {
  Element.prototype.getBoundingClientRect = () =>
    ({
      top: 100,
      left: 50,
      width: 128,
      height: 8,
      right: 178,
      bottom: 108,
      x: 50,
      y: 100,
      toJSON: () => {},
    }) as DOMRect;
});

const segments: VesselTypes[] = [
  { ship_type_level_3: 'Bulk carrier', proportion: 0.6, visit_count: 6 },
  { ship_type_level_3: 'Oil Tanker', proportion: 0.4, visit_count: 4 },
];

describe('VesselTypePill', () => {
  it('renders an empty pill container when segments is undefined', () => {
    const { container } = render(<VesselTypePill segments={undefined} />);

    expect(container.querySelector('.rounded-full')).toBeInTheDocument();
    expect(screen.queryByText('Bulk Carrier')).not.toBeInTheDocument();
  });

  it('renders an empty pill container when segments is null', () => {
    const { container } = render(<VesselTypePill segments={null} />);

    expect(container.querySelector('.rounded-full')).toBeInTheDocument();
  });

  it('renders a segment for each vessel type', () => {
    const { container } = render(<VesselTypePill segments={segments} />);

    const pill = container.querySelector('.rounded-full');
    expect(pill?.children).toHaveLength(2);
  });

  it('does not render the tooltip before hover', () => {
    render(<VesselTypePill segments={segments} />);

    expect(screen.queryByText('Bulk Carrier')).not.toBeInTheDocument();
    expect(screen.queryByText('60%')).not.toBeInTheDocument();
  });

  it('shows a tooltip with segment details on hover and hides it on mouse leave', () => {
    const { container } = render(<VesselTypePill segments={segments} />);
    const pill = container.querySelector('.rounded-full') as HTMLElement;

    fireEvent.mouseEnter(pill);

    expect(screen.getByText('Bulk Carrier')).toBeInTheDocument();
    expect(screen.getByText('Oil Tanker')).toBeInTheDocument();
    expect(screen.getByText('60%')).toBeInTheDocument();
    expect(screen.getByText('40%')).toBeInTheDocument();

    fireEvent.mouseLeave(pill);

    expect(screen.queryByText('Bulk Carrier')).not.toBeInTheDocument();
  });
});
