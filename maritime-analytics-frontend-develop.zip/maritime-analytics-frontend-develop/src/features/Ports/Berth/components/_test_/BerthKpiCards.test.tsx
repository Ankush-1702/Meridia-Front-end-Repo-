import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import BerthKpiCards from '../BerthKpiCards';

describe('BerthKpiCards', () => {
  it('renders title and value', () => {
    render(<BerthKpiCards title="Total Berths" value={12} />);

    expect(screen.getByText('Total Berths')).toBeInTheDocument();
    expect(screen.getByText('12')).toBeInTheDocument();
  });

  it('renders a string value', () => {
    render(<BerthKpiCards title="Avg Dwell" value="3.5 hrs" />);

    expect(screen.getByText('Avg Dwell')).toBeInTheDocument();
    expect(screen.getByText('3.5 hrs')).toBeInTheDocument();
  });

  it('renders gracefully when value is undefined', () => {
    render(<BerthKpiCards title="No Data" value={undefined} />);

    expect(screen.getByText('No Data')).toBeInTheDocument();
  });
});
