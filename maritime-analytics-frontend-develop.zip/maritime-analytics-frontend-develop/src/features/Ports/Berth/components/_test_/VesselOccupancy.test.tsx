import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import VesselOccupancyTimeline from '../VesselOccupancy';

const navigateMock = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => navigateMock,
}));

vi.mock('flowbite-react', async () => {
  const actual =
    await vi.importActual<typeof import('flowbite-react')>('flowbite-react');
  return {
    ...actual,
    Tooltip: ({
      content,
      children,
    }: {
      content: React.ReactNode;
      children: React.ReactNode;
    }) => (
      <>
        {children}
        {content}
      </>
    ),
  };
});

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>Empty State</div>,
}));

const baseOccupancy = {
  display_date_start: '2026-01-01T00:00:00Z',
  display_date_end: '2026-01-15T00:00:00Z',
};

const baseVessel = {
  vessel_name: 'Test Vessel',
  imo_number: '1234567',
  vessel_flag: 'US',
  ship_type_level_3: 'Bulk carrier',
  arrival_time: '2026-01-02T00:00:00Z',
  departure_time: '2026-01-05T00:00:00Z',
  hours_at_berth: 72,
};

const baseGap = {
  gap_duration: 4.5,
  raw_start_time: '2026-01-05T00:00:00Z',
  raw_end_time: '2026-01-05T04:30:00Z',
};

describe('VesselOccupancyTimeline', () => {
  beforeEach(() => {
    navigateMock.mockClear();
  });

  it('renders empty state when occupancy is undefined', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={undefined}
        visits={[]}
        vessels={[]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getByText('Empty State')).toBeInTheDocument();
  });

  it('renders empty state when visits is empty even if occupancy is present', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[]}
        vessels={[]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getByText('Empty State')).toBeInTheDocument();
  });

  it('renders only vessels overlapping the visible window', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[
          { ...baseVessel, vessel_name: 'Inside Vessel', start: 2, end: 10 },
          {
            ...baseVessel,
            vessel_name: 'Outside Vessel',
            imo_number: '7654321',
            start: 20,
            end: 25,
          },
        ]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getByText('Inside Vessel')).toBeInTheDocument();
    expect(screen.queryByText('Outside Vessel')).not.toBeInTheDocument();
  });

  it('does not truncate/show vessel name label when the bar is too narrow', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[
          { ...baseVessel, vessel_name: 'Narrow Vessel', start: 0, end: 0.5 },
        ]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    const bar = screen.getByRole('button');
    expect(bar.textContent).toBe('');
  });

  it('navigates to vessel details on click', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[{ ...baseVessel, start: 2, end: 10 }]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    fireEvent.click(screen.getByRole('button'));
    expect(navigateMock).toHaveBeenCalledWith('/analytics/vessel/1234567');
  });

  it('navigates to vessel details on keydown', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[{ ...baseVessel, start: 2, end: 10 }]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    fireEvent.keyDown(screen.getByRole('button'));
    expect(navigateMock).toHaveBeenCalledWith('/analytics/vessel/1234567');
  });

  it('shows N/A fallbacks for falsy vessel fields in the tooltip', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[
          {
            ...baseVessel,
            vessel_flag: '',
            imo_number: '',
            start: 2,
            end: 10,
          },
        ]}
        gaps={[]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getAllByText('N/A').length).toBeGreaterThan(0);
  });

  it('renders only gaps overlapping the visible window', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[{ ...baseVessel, start: 2, end: 10 }]}
        gaps={[
          { ...baseGap, start: 5, end: 6 },
          { ...baseGap, start: 20, end: 21 },
        ]}
        dateTicks={[]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getAllByText('4.5 hrs')).toHaveLength(1);
  });

  it('renders only date ticks within the visible window', () => {
    render(
      <VesselOccupancyTimeline
        occupancy={baseOccupancy}
        visits={[{}]}
        vessels={[{ ...baseVessel, start: 2, end: 10 }]}
        gaps={[]}
        dateTicks={[
          { label: '1 Jan', day: 1 },
          { label: '20 Jan', day: 20 },
        ]}
        windowStart={0}
        windowEnd={15}
      />,
    );

    expect(screen.getByText('1 Jan')).toBeInTheDocument();
    expect(screen.queryByText('20 Jan')).not.toBeInTheDocument();
  });
});
