import { render } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import BerthDetailsContentSkeleton from '../LoadingSkeleton';

describe('BerthDetailsContentSkeleton', () => {
  it('renders without crashing', () => {
    const { container } = render(<BerthDetailsContentSkeleton />);

    expect(container.firstChild).not.toBeNull();
  });

  it('renders skeleton blocks', () => {
    const { container } = render(<BerthDetailsContentSkeleton />);

    const skeletonBlocks = container.querySelectorAll('.animate-pulse');
    expect(skeletonBlocks.length).toBeGreaterThan(0);
  });
});
