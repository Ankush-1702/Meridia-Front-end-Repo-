import { FC, useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { VesselTypes } from '@/features/Ports/Berth/types/berthTypes';
import {
  getColor,
  getDisplayName,
} from '@/shared/utils/CongestionAndTrafficUtils';

const VesselTypePill: FC<{ segments?: VesselTypes[] | null }> = ({
  segments,
}) => {
  const [hovered, setHovered] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const pillRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (hovered && pillRef.current) {
      const rect = pillRef.current.getBoundingClientRect();
      setPosition({
        top: rect.top - 8,
        left: rect.left + rect.width / 2,
      });
    }
  }, [hovered]);

  const tooltip = hovered
    ? createPortal(
        <div
          className="fixed z-[9999] -translate-x-1/2 -translate-y-full rounded-lg bg-gray-900 px-3 py-2 text-xs text-white shadow-lg"
          style={{ top: position.top, left: position.left }}
        >
          <div className="flex flex-col gap-1">
            {segments?.map((seg, i) => (
              <div
                key={seg.ship_type_level_3 + i}
                className="flex items-center gap-2"
              >
                <span
                  className="inline-block h-2 w-2 rounded-full"
                  style={{
                    backgroundColor: getColor(seg.ship_type_level_3),
                  }}
                />
                <span>{getDisplayName(seg.ship_type_level_3)}</span>
                <span className="font-semibold">
                  {(seg.proportion * 100).toFixed(0)}%
                </span>
              </div>
            ))}
          </div>
        </div>,
        document.body,
      )
    : null;

  return (
    <>
      <div
        ref={pillRef}
        className="flex h-2 w-32 overflow-hidden rounded-full"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        {segments?.map((seg, i) => (
          <div
            key={seg.ship_type_level_3 + i}
            style={{
              width: `${seg.proportion * 100}%`,
              backgroundColor: getColor(seg.ship_type_level_3),
            }}
          />
        ))}
      </div>
      {tooltip}
    </>
  );
};

export default VesselTypePill;
