import { AgCartesianChartOptions } from 'ag-charts-enterprise';
import { forwardRef, useMemo } from 'react';
import { useTheme } from '@/app/context/ThemeProvider';
import { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';
import EmptyState from '@/shared/components/CongestionEmptyState';
import {
  PoleStarChart,
  PoleStarChartHandle,
} from '@/shared/lib/PoleStarCharts';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { formatDateLabel } from '@/shared/utils/CongestionAndTrafficUtils';

// Normalised shape used internally by the chart
interface ChartPoint {
  period: string;
  avgDwell: number;
  medianDwell: number;
}

function normaliseResponse(
  response: BerthDetailsApiResponse | ICongestionResponse,
): ChartPoint[] {
  // BerthDetailsApiResponse — has dwell_time_series with numeric values
  if (
    'dwell_time_series' in response &&
    Array.isArray(response.dwell_time_series)
  ) {
    return response.dwell_time_series.map((d) => ({
      period: d.period_start,
      avgDwell: d.avg_dwell_time ?? 0,
      medianDwell: d.median_dwell_time ?? 0,
    }));
  }

  // ICongestionResponse (HistoricalResponse) — has dwell_series with string values
  if ('dwell_series' in response && Array.isArray(response.dwell_series)) {
    return response.dwell_series.map((d) => ({
      period: d.period_key,
      avgDwell: d.avg_dwell_time || 0,
      medianDwell: d.median_dwell_time || 0,
    }));
  }

  return [];
}

const DwellTimeChart = forwardRef<
  PoleStarChartHandle,
  { response: BerthDetailsApiResponse | ICongestionResponse }
>(({ response }, ref) => {
  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  // Memoize both the normalised data and the hasData check together
  const { chartData, hasData } = useMemo(() => {
    const data = normaliseResponse(response);
    return {
      chartData: data,
      hasData: data.some((d) => d.avgDwell !== 0 || d.medianDwell !== 0),
    };
  }, [response]);

  if (!hasData) return <EmptyState />;

  const textColor = isDarkMode ? '#E5E7EB' : '#111827';
  const isSinglePoint = chartData.length === 1;

  const options = {
    data: chartData,
    series: [
      {
        type: 'line',
        xKey: 'period',
        yKey: 'avgDwell',
        yName: 'Dwell time at berth (avg)',
        stroke: '#f88e63',
        marker: {
          fill: '#f88e63',
          size: isSinglePoint ? 8 : 0,
          enabled: isSinglePoint, // Fix: was always false
        },
        tooltip: {
          renderer: ({ datum }) => ({ heading: datum.period }),
        },
        interpolation: {
          type: 'smooth',
        },
      },
      {
        type: 'line',
        xKey: 'period',
        yKey: 'medianDwell',
        yName: 'Dwell time at berth (median)',
        stroke: '#f88e63',
        lineDash: [6, 4],
        marker: {
          fill: '#f88e63',
          size: isSinglePoint ? 8 : 0,
          enabled: isSinglePoint, // Fix: was always false
          lineDash: [6, 4],
        },
        tooltip: {
          renderer: ({ datum }) => ({ heading: datum.period }),
        },
        interpolation: {
          type: 'smooth',
        },
      },
    ],
    axes: {
      x: {
        type: 'category',
        position: 'bottom',
        label: {
          color: textColor,
          formatter: ({ value }: { value: string }) => formatDateLabel(value),
          autoRotate: false,
          avoidCollisions: true,
          minSpacing: 30,
        },
      },
      y: {
        type: 'number',
        position: 'left',
        label: {
          color: textColor,
          formatter: ({ value }: { value: number }) => `${value} hrs`,
        },
        gridLine: {
          style: [{ stroke: isDarkMode ? '#374151' : 'lightgray' }],
        },
      },
    },
    background: { fill: isDarkMode ? '#1F2937' : '#fff' },
    legend: {
      reverseOrder: false,
      position: 'bottom',
      item: {
        label: { color: textColor },
        showSeriesStroke: true,
        marker: { shape: 'square', size: 0 },
        line: {
          length: 30,
          strokeWidth: 2,
        },
      },
    },
  } as AgCartesianChartOptions;

  return (
    <div className="h-full w-full">
      <PoleStarChart options={options} ref={ref} />
    </div>
  );
});

export default DwellTimeChart;
