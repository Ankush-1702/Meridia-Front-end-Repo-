import { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';

function formatDateLabel(ts: number) {
  const d = new Date(ts);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

interface VesselOccupancyTimelineHeaderProps {
  berthData?: BerthDetailsApiResponse;
  offset: number;
  maxOffset: number;
  onPrev: () => void;
  onNext: () => void;
}

export default function VesselOccupancyTimelineHeader({
  berthData,
  offset,
  maxOffset,
  onPrev,
  onNext,
}: VesselOccupancyTimelineHeaderProps) {
  const occupancy = berthData?.occupancy;

  return (
    <div className="flex items-start justify-between">
      <div>
        <h2 className="text-sm font-bold">Vessel occupancy</h2>
        <p className="text-xs text-gray-500">
          {occupancy
            ? `${formatDateLabel(new Date(occupancy.display_date_start).getTime())} – ${formatDateLabel(new Date(occupancy.display_date_end).getTime())}`
            : ''}
        </p>
        <p className="mt-1 text-xs text-gray-400">
          Gap time (total):{' '}
          <span className="font-bold">
            {(occupancy?.gap_time_total ?? 0).toFixed(1)} hrs
          </span>
          <span className="ml-4">
            Gap time (avg):{' '}
            <span className="font-bold">
              {(occupancy?.gap_time_avg ?? 0).toFixed(1)} hrs
            </span>
          </span>
        </p>
      </div>
      <div className="flex gap-2">
        <button
          onClick={onPrev}
          disabled={offset === 0}
          className="rounded-lg border border-gray-200 px-4 py-1.5 text-sm hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent dark:border-gray-700 dark:hover:bg-gray-700 dark:disabled:hover:bg-transparent"
        >
          ← Prev
        </button>
        <button
          onClick={onNext}
          disabled={offset >= maxOffset}
          className="rounded-lg border border-gray-200 px-4 py-1.5 text-sm hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent dark:border-gray-700 dark:hover:bg-gray-700 dark:disabled:hover:bg-transparent"
        >
          Next →
        </button>
      </div>
    </div>
  );
}
