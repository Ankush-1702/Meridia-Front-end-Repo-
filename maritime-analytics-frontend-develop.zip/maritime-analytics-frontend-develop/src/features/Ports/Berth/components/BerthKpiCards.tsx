interface BerthKpiCardsProps {
  title: string;
  value: string | number | undefined;
}

export default function BerthKpiCards({ title, value }: BerthKpiCardsProps) {
  return (
    <div className="flex w-full items-center rounded-lg bg-white px-4 py-4 dark:bg-gray-800">
      <div className="flex flex-col gap-2">
        <p className="text-xs font-normal text-gray-500">{title}</p>
        <h3 className="text-xl font-bold">{value}</h3>
      </div>
    </div>
  );
}
