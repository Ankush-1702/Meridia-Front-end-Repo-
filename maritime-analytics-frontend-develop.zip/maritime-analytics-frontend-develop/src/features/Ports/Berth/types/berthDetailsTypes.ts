export type ViewMode = 'gantt' | 'table';
export type DwellSeriesGranularity = 'daily' | 'weekly';

interface Meta {
  request_id: string;
  request_timestamp: string;
}

interface Query {
  date_start: string;
  date_end: string;
  vessel_flags: string[];
  page: number;
  page_size: number;
  top_n: number;
  view_mode: ViewMode;
  dwell_series_granularity: DwellSeriesGranularity;
}

interface BerthDetails {
  berth_id: string;
  berth_name: string;
  berth_status: string;
  terminal_operator: string;
  terminal_type: string;
  berth_facility: string;
  length_m: number;
  max_loa_m: number;
  max_dwt: number;
  depth_lw_m: number;
  avg_dwell_time: number;
  median_dwell_time: number;
}

export interface DwellTimeSeries {
  period_start: string;
  avg_dwell_time: number;
  median_dwell_time: number;
}

interface Pagination {
  total_days: number;
  page: number;
  page_size: number;
  day_start: number;
  day_end: number;
}

export interface Visits {
  imo_number: string;
  vessel_name: string;
  ship_type_level_3: string;
  vessel_flag: string;
  vessel_flag_code: string;
  arrival_time: string;
  departure_time: string;
  hours_at_berth: number;
}

export interface Gaps {
  start_time: string;
  end_time: string;
  gap_duration: number;
}
export interface TopVessel {
  imo_number: string;
  vessel_name: string;
  ship_type_level_3: string;
  visit_count: number;
  total_dwell_time: number;
  avg_dwell_time: number;
  [key: string]: unknown;
}
interface Occupancy {
  display_date_start: string;
  display_date_end: string;
  gap_time_total: number;
  gap_time_avg: number;
  pagination: Pagination;
  visits: Visits[];
  gaps: Gaps[];
  top_vessels: TopVessel[];
}

export interface BerthDetailsApiResponse {
  meta: Meta;
  query: Query;
  berth_details: BerthDetails;
  dwell_time_series: DwellTimeSeries[];
  occupancy: Occupancy;
}

interface VesselFlag {
  code: string;
  name: string;
}

export interface FlagResponse {
  vessel_flags: VesselFlag[];
}
