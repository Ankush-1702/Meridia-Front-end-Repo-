interface Meta {
  request_id: string;
  request_timestamp: string;
  total_count: number;
  limit: number;
  offset: number;
}

interface PortInformation {
  id: string;
  name: string;
  unlocode: string;
  country: string;
}

interface Query {
  date_start: string;
  date_end: string;
  terminal_type: string[];
  terminal_name: string[];
}

export interface KPI {
  total_berths: number;
  min_dwell_time: number;
  max_dwell_time: number;
  terminal_operators: number;
}

export interface VesselTypes {
  ship_type_level_3: string;
  visit_count: number;
  proportion: number;
}

export type Berth = {
  berth_id: string;
  berth_name: string;
  berth_status: string;
  berth_type: string;
  berth_facility: string;
  length_m: number;
  max_loa_m: number;
  max_dwt: number;
  depth_lw_m: number;
  min_dwell_time: number;
  avg_dwell_time: number;
  median_dwell_time: number;
  max_dwell_time: number;
  vessel_types: VesselTypes[];
};

export interface Terminals {
  terminal_name: string;
  berths: Berth[];
}

export interface BerthApiResponse {
  meta: Meta;
  query: Query;
  port_information: PortInformation;
  kpi: KPI;
  terminals: Terminals[];
}

export interface BerthFilterResponse {
  berth_types: string[];
  terminal_names: string[];
}

export type BerthRow = Berth & { terminal_name: string };
