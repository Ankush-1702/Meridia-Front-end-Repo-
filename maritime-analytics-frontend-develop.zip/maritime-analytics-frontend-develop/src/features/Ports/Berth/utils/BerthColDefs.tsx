import { ColDef } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import VesselTypePill from '@/features/Ports/Berth/components/VesselTypePill';
import { Berth, BerthRow } from '@/features/Ports/Berth/types/berthTypes';

export function createBerthColumnDefs(): ColDef<BerthRow>[] {
  const defaultCol: Partial<ColDef<BerthRow>> = {
    sortable: false,
    flex: 1,
    lockVisible: true,
    valueFormatter: (params) =>
      params.value == null || params.value === '' ? '-' : String(params.value),
  };

  return [
    {
      field: 'terminal_name',
      rowGroup: true,
      hide: true,
      suppressColumnsToolPanel: true,
    },
    {
      headerName: 'Berth',
      field: 'berth_name',
      tooltipField: 'berth_name',
      ...defaultCol,
    },
    {
      headerName: 'Type',
      field: 'berth_type',
      tooltipField: 'berth_type',
      ...defaultCol,
    },
    {
      headerName: 'Vessel types',
      field: 'vessel_types',
      ...defaultCol,
      valueFormatter: undefined, // skip formatter — handled by cellRenderer
      cellRenderer: (
        params: CustomCellRendererProps<BerthRow, Berth['vessel_types']>,
      ) => (
        <div className="flex h-full items-center justify-center">
          {params.value && params.value.length > 0 ? (
            <VesselTypePill segments={params.value} />
          ) : (
            '-'
          )}
        </div>
      ),
    },
    {
      headerName: 'Handling',
      field: 'berth_facility',
      tooltipField: 'berth_facility',
      ...defaultCol,
    },
    {
      headerName: 'Length',
      field: 'length_m',
      tooltipField: 'length_m',
      ...defaultCol,
    },
    {
      headerName: 'Max LOA',
      field: 'max_loa_m',
      tooltipField: 'max_loa_m',
      ...defaultCol,
    },
    {
      headerName: 'Max DWT',
      field: 'max_dwt',
      tooltipField: 'max_dwt',
      ...defaultCol,
    },
    {
      headerName: 'Depth (LW)',
      field: 'depth_lw_m',
      tooltipField: 'depth_lw_m',
      ...defaultCol,
    },
    {
      headerName: 'Min dwell',
      field: 'min_dwell_time',
      tooltipField: 'min_dwell_time',
      ...defaultCol,
    },
    {
      headerName: 'Avg dwell',
      field: 'avg_dwell_time',
      tooltipField: 'avg_dwell_time',
      ...defaultCol,
    },
    {
      headerName: 'Median dwell',
      field: 'median_dwell_time',
      tooltipField: 'median_dwell_time',
      ...defaultCol,
    },
    {
      headerName: 'Max dwell',
      field: 'max_dwell_time',
      tooltipField: 'max_dwell_time',
      ...defaultCol,
    },
  ];
}
