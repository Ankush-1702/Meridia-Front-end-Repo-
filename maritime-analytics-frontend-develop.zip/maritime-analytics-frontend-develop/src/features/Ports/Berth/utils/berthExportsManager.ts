import {
  pollExportStatus,
  triggerExport,
} from '@/shared/services/exportServices/berthExportService';

const POLL_INTERVAL_MS = 3000;

type StatusCallback = (status: 'COMPLETED' | 'FAILED' | 'PROCESSING') => void;
type DownloadCallback = (url: string, fileName: string) => void;
type ErrorCallback = (error: unknown) => void;

interface ExportManagerCallbacks {
  onStatus?: StatusCallback;
  onDownloadReady?: DownloadCallback;
  onError?: ErrorCallback;
}

let intervalId: ReturnType<typeof setInterval> | null = null;
let callbacks: ExportManagerCallbacks = {};

function isPolling() {
  return intervalId !== null;
}

function stopPolling() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
}

function startPolling(jobId: string) {
  stopPolling(); // Guard: never run two intervals at once

  intervalId = setInterval(async () => {
    try {
      const res = await pollExportStatus('berths', jobId);
      const status = res.data.status;

      callbacks.onStatus?.(status);

      if (status === 'COMPLETED') {
        stopPolling();
        if (res.data.download_url) {
          callbacks.onDownloadReady?.(res.data.download_url, 'berths-export');
        }
      } else if (status === 'FAILED') {
        stopPolling();
        callbacks.onError?.(new Error('Export job failed'));
      }
    } catch (e) {
      stopPolling();
      callbacks.onError?.(e);
    }
  }, POLL_INTERVAL_MS);
}

export const berthExportManager = {
  isPolling,

  /** Re-attach callbacks on every mount so toasts/errors always reach the live UI */
  registerCallbacks(cbs: ExportManagerCallbacks) {
    callbacks = cbs;
  },

  async trigger(
    portId: string,
    dateStart: string,
    dateEnd: string,
    berthTypes: string[],
    terminalNames: string[],
    cbs: ExportManagerCallbacks,
  ) {
    if (isPolling()) return;

    callbacks = cbs;

    const res = await triggerExport(
      portId,
      'berths',
      dateStart.split('T')[0],
      dateEnd.split('T')[0],
      berthTypes.join(','),
      terminalNames.join(','),
    );

    startPolling(res.data.job_id);
  },

  cancel() {
    stopPolling();
  },
};
