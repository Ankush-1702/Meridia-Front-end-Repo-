import { describe, it, expect } from 'vitest';
import { createBerthDetailsColumnDefs } from '../BerthDetailsColDefs';

describe('createBerthDetailsColumnDefs', () => {
  const colDefs = createBerthDetailsColumnDefs();

  it('returns columns with expected field/headerName pairs', () => {
    const shape = colDefs.map((c) => ({
      field: c.field,
      headerName: c.headerName,
    }));

    expect(shape).toEqual([
      { field: 'vessel_name', headerName: 'Vessel' },
      { field: 'ship_type_level_3', headerName: 'Type' },
      { field: 'visit_count', headerName: 'Visits' },
      { field: 'total_dwell_time', headerName: 'Total Dwell' },
      { field: 'avg_dwell_time', headerName: 'Avg Dwell' },
    ]);
  });

  it('every column has sortable false, flex 1, and lockVisible true', () => {
    colDefs.forEach((c) => {
      expect(c.sortable).toBe(false);
      expect(c.flex).toBe(1);
      expect(c.lockVisible).toBe(true);
    });
  });

  it('valueFormatter returns "-" for null/undefined/empty values', () => {
    const col = colDefs[0];
    const formatter = col.valueFormatter as (params: {
      value: unknown;
    }) => string;

    expect(formatter({ value: null })).toBe('-');
    expect(formatter({ value: undefined })).toBe('-');
    expect(formatter({ value: '' })).toBe('-');
  });

  it('valueFormatter stringifies non-empty values', () => {
    const col = colDefs.find((c) => c.field === 'visit_count')!;
    const formatter = col.valueFormatter as (params: {
      value: unknown;
    }) => string;

    expect(formatter({ value: 5 })).toBe('5');
    expect(formatter({ value: 'Bulk Carrier' })).toBe('Bulk Carrier');
  });
});
