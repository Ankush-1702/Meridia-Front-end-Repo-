import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { berthExportManager } from '../berthExportsManager';
import {
  triggerExport,
  pollExportStatus,
} from '@/shared/services/exportServices/berthExportService';

vi.mock('@/shared/services/exportServices/berthExportService', () => ({
  triggerExport: vi.fn(),
  pollExportStatus: vi.fn(),
}));

const mockedTriggerExport = vi.mocked(triggerExport);
const mockedPollExportStatus = vi.mocked(pollExportStatus);

function exportResponse(
  status: 'PROCESSING' | 'COMPLETED' | 'FAILED',
  download_url: string | null = null,
) {
  return {
    data: {
      job_id: 'job-1',
      status,
      download_url,
      error_message: null,
    },
    meta: { request_id: 'r1', request_timestamp: 't1' },
  };
}

describe('berthExportManager', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    berthExportManager.registerCallbacks({});
  });

  afterEach(() => {
    berthExportManager.cancel();
    vi.useRealTimers();
  });

  it('is not polling initially', () => {
    expect(berthExportManager.isPolling()).toBe(false);
  });

  it('trigger() calls triggerExport with correct args and starts polling', async () => {
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01T00:00:00Z',
      '2025-01-31T00:00:00Z',
      ['Container', 'Bulk'],
      ['Terminal A'],
      {},
    );

    expect(mockedTriggerExport).toHaveBeenCalledWith(
      'port-1',
      'berths',
      '2025-01-01',
      '2025-01-31',
      'Container,Bulk',
      'Terminal A',
    );
    expect(berthExportManager.isPolling()).toBe(true);
  });

  it('trigger() is a no-op while already polling', async () => {
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      {},
    );
    expect(berthExportManager.isPolling()).toBe(true);

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      {},
    );

    expect(mockedTriggerExport).toHaveBeenCalledTimes(1);
  });

  it('registerCallbacks callbacks are used by poll ticks', async () => {
    const onStatus = vi.fn();
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));
    mockedPollExportStatus.mockResolvedValue(exportResponse('PROCESSING'));

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      { onStatus },
    );

    await vi.advanceTimersByTimeAsync(3000);

    expect(onStatus).toHaveBeenCalledWith('PROCESSING');
    expect(berthExportManager.isPolling()).toBe(true);

    await vi.advanceTimersByTimeAsync(3000);
    expect(onStatus).toHaveBeenCalledTimes(2);
  });

  it('COMPLETED with download_url stops polling and calls onDownloadReady', async () => {
    const onDownloadReady = vi.fn();
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));
    mockedPollExportStatus.mockResolvedValue(
      exportResponse('COMPLETED', 'https://example.com/file.csv'),
    );

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      { onDownloadReady },
    );

    await vi.advanceTimersByTimeAsync(3000);

    expect(berthExportManager.isPolling()).toBe(false);
    expect(onDownloadReady).toHaveBeenCalledWith(
      'https://example.com/file.csv',
      'berths-export',
    );

    mockedPollExportStatus.mockClear();
    await vi.advanceTimersByTimeAsync(3000);
    expect(mockedPollExportStatus).not.toHaveBeenCalled();
  });

  it('COMPLETED without download_url stops polling without calling onDownloadReady', async () => {
    const onDownloadReady = vi.fn();
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));
    mockedPollExportStatus.mockResolvedValue(exportResponse('COMPLETED', null));

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      { onDownloadReady },
    );

    await vi.advanceTimersByTimeAsync(3000);

    expect(berthExportManager.isPolling()).toBe(false);
    expect(onDownloadReady).not.toHaveBeenCalled();
  });

  it('FAILED status stops polling and calls onError', async () => {
    const onError = vi.fn();
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));
    mockedPollExportStatus.mockResolvedValue(exportResponse('FAILED'));

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      { onError },
    );

    await vi.advanceTimersByTimeAsync(3000);

    expect(berthExportManager.isPolling()).toBe(false);
    expect(onError).toHaveBeenCalledWith(new Error('Export job failed'));
  });

  it('pollExportStatus rejection stops polling and calls onError', async () => {
    const onError = vi.fn();
    const rejection = new Error('network error');
    mockedTriggerExport.mockResolvedValue(exportResponse('PROCESSING'));
    mockedPollExportStatus.mockRejectedValue(rejection);

    await berthExportManager.trigger(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      [],
      [],
      { onError },
    );

    await vi.advanceTimersByTimeAsync(3000);

    expect(berthExportManager.isPolling()).toBe(false);
    expect(onError).toHaveBeenCalledWith(rejection);
  });
});
