import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi } from 'vitest';
import type { Berth, BerthRow } from '../../types/berthTypes';

vi.mock('@/features/Ports/Berth/components/VesselTypePill', () => ({
  default: (props: { segments: unknown }) => (
    <div data-testid="pill">{JSON.stringify(props.segments)}</div>
  ),
}));

const { createBerthColumnDefs } = await import('../BerthColDefs');

describe('createBerthColumnDefs', () => {
  const colDefs = createBerthColumnDefs();

  it('includes a hidden terminal_name rowGroup column', () => {
    const terminalCol = colDefs.find((c) => c.field === 'terminal_name');
    expect(terminalCol).toMatchObject({ rowGroup: true, hide: true });
  });

  it('includes the expected named columns with correct headerName', () => {
    const shape = colDefs
      .filter((c) => c.field !== 'terminal_name')
      .map((c) => ({ field: c.field, headerName: c.headerName }));

    expect(shape).toEqual([
      { field: 'berth_name', headerName: 'Berth' },
      { field: 'berth_type', headerName: 'Type' },
      { field: 'vessel_types', headerName: 'Vessel types' },
      { field: 'berth_facility', headerName: 'Handling' },
      { field: 'length_m', headerName: 'Length' },
      { field: 'max_loa_m', headerName: 'Max LOA' },
      { field: 'max_dwt', headerName: 'Max DWT' },
      { field: 'depth_lw_m', headerName: 'Depth (LW)' },
      { field: 'min_dwell_time', headerName: 'Min dwell' },
      { field: 'avg_dwell_time', headerName: 'Avg dwell' },
      { field: 'median_dwell_time', headerName: 'Median dwell' },
      { field: 'max_dwell_time', headerName: 'Max dwell' },
    ]);
  });

  it('default valueFormatter returns dash for null/empty and stringifies otherwise', () => {
    const col = colDefs.find((c) => c.field === 'berth_name')!;
    const formatter = col.valueFormatter as (params: {
      value: unknown;
    }) => string;

    expect(formatter({ value: null })).toBe('-');
    expect(formatter({ value: '' })).toBe('-');
    expect(formatter({ value: 'Berth 1' })).toBe('Berth 1');
  });

  it('vessel_types column has no valueFormatter (handled by cellRenderer)', () => {
    const col = colDefs.find((c) => c.field === 'vessel_types')!;
    expect(col.valueFormatter).toBeUndefined();
  });

  describe('vessel_types cellRenderer', () => {
    const col = colDefs.find((c) => c.field === 'vessel_types')!;
    const cellRenderer = col.cellRenderer as (
      params: CustomCellRendererProps<BerthRow, Berth['vessel_types']>,
    ) => React.ReactNode;

    it('renders VesselTypePill when value has entries', () => {
      const segments = [
        { ship_type_level_3: 'Bulk carrier', visit_count: 1, proportion: 1 },
      ];
      const rendered = cellRenderer({
        value: segments,
      } as unknown as CustomCellRendererProps<BerthRow, Berth['vessel_types']>);

      expect(rendered).toBeTruthy();
      const el = rendered as React.ReactElement;
      expect(el.props.children.props.segments).toEqual(segments);
    });

    it('renders "-" when value is an empty array', () => {
      const rendered = cellRenderer({
        value: [],
      } as unknown as CustomCellRendererProps<BerthRow, Berth['vessel_types']>);
      const el = rendered as React.ReactElement;
      expect(el.props.children).toBe('-');
    });

    it('renders "-" when value is undefined/null', () => {
      const renderedUndefined = cellRenderer({
        value: undefined,
      } as unknown as CustomCellRendererProps<BerthRow, Berth['vessel_types']>);
      const renderedNull = cellRenderer({
        value: null,
      } as unknown as CustomCellRendererProps<BerthRow, Berth['vessel_types']>);

      expect((renderedUndefined as React.ReactElement).props.children).toBe(
        '-',
      );
      expect((renderedNull as React.ReactElement).props.children).toBe('-');
    });
  });
});
