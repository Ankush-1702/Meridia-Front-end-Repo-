import { describe, it, expect } from 'vitest';
import type { BerthDetailsApiResponse } from '../../types/berthDetailsTypes';
import type { BerthRow } from '../../types/berthTypes';
import { getCSVContent, buildDwellTimeSeriesCsv } from '../getCsvContent';

const HEADER =
  'Terminal Name,Berth,Type,Vessel types,Handling,Length,Max LOA,Max DWT,Depth (LW),Min dwell,Avg dwell,Median dwell,Max dwell';

function makeRow(overrides: Partial<BerthRow> = {}): BerthRow {
  return {
    berth_id: 'b1',
    berth_name: 'Berth 1',
    berth_status: 'ACTIVE',
    berth_type: 'Container',
    berth_facility: 'General',
    length_m: 100,
    max_loa_m: 200,
    max_dwt: 300,
    depth_lw_m: 10,
    min_dwell_time: 1,
    avg_dwell_time: 2,
    median_dwell_time: 3,
    max_dwell_time: 4,
    vessel_types: [],
    terminal_name: 'Terminal A',
    ...overrides,
  };
}

describe('getCSVContent', () => {
  it('returns header row only for an empty list', () => {
    expect(getCSVContent([])).toBe(HEADER);
    expect(getCSVContent([])).not.toContain('terminal_name');
  });

  it('builds a data row with all fields populated', () => {
    const row = makeRow();
    const csv = getCSVContent([row]);
    const lines = csv.split('\n');

    expect(lines[0]).toBe(HEADER);
    expect(lines[1]).toBe(
      'Terminal A,Berth 1,Container,-,General,100,200,300,10,1,2,3,4',
    );
  });

  it('escapes fields containing commas, quotes, or newlines', () => {
    const row = makeRow({ berth_facility: 'Oil, Gas "Prime"' });
    const csv = getCSVContent([row]);
    const dataLine = csv.split('\n')[1];

    expect(dataLine).toContain('"Oil, Gas ""Prime"""');
  });

  it('formats vessel_types as a joined display-name/percentage string', () => {
    const row = makeRow({
      vessel_types: [
        { ship_type_level_3: 'Bulk carrier', visit_count: 6, proportion: 0.6 },
        { ship_type_level_3: 'Unknown Type', visit_count: 4, proportion: 0.4 },
      ],
    });
    const csv = getCSVContent([row]);
    const dataLine = csv.split('\n')[1];

    expect(dataLine).toContain('Bulk Carrier (60%) | Unknown Type (40%)');
  });

  it('renders "-" for empty vessel_types', () => {
    const row = makeRow({ vessel_types: [] });
    const csv = getCSVContent([row]);
    const dataLine = csv.split('\n')[1];
    const fields = dataLine.split(',');

    expect(fields[3]).toBe('-');
  });

  it('renders "-" for null/empty numeric or string fields', () => {
    const row = makeRow({
      berth_facility: '',
      length_m: null as unknown as number,
    });
    const csv = getCSVContent([row]);
    const dataLine = csv.split('\n')[1];

    expect(dataLine).toContain(',-,-,');
  });
});

describe('buildDwellTimeSeriesCsv', () => {
  it('returns undefined when data is undefined', () => {
    expect(buildDwellTimeSeriesCsv(undefined)).toBeUndefined();
  });

  it('builds header + rows for populated dwell_time_series', () => {
    const data = {
      berth_details: {
        berth_name: 'Berth 1',
        terminal_type: 'Container',
        terminal_operator: 'Operator A',
      },
      dwell_time_series: [
        { period_start: '2025-01-01', avg_dwell_time: 5, median_dwell_time: 4 },
        { period_start: '2025-01-02', avg_dwell_time: 0, median_dwell_time: 0 },
      ],
    } as unknown as BerthDetailsApiResponse;

    const csv = buildDwellTimeSeriesCsv(data)!;
    const lines = csv.split('\n');

    expect(lines[0]).toBe(
      'Berth Name,Terminal type,Terminal Operator,Date,Dwell Time at berth (avg),Dwell Time at berth (median)',
    );
    expect(lines[1]).toBe('Berth 1,Container,Operator A,2025-01-01,5,4');
    // avg_dwell_time/median_dwell_time of 0 are falsy, so they fall back to '-'
    expect(lines[2]).toBe('Berth 1,Container,Operator A,2025-01-02,-,-');
  });
});
