import { ColDef } from 'ag-grid-enterprise';
import { TopVessel } from '../types/berthDetailsTypes';

export function createBerthDetailsColumnDefs(): ColDef<TopVessel>[] {
  const defaultCol: Partial<ColDef<TopVessel>> = {
    sortable: false,
    flex: 1,
    lockVisible: true,
    valueFormatter: (params) =>
      params.value == null || params.value === '' ? '-' : String(params.value),
  };

  return [
    {
      headerName: 'Vessel',
      field: 'vessel_name',
      tooltipField: 'vessel_name',
      ...defaultCol,
    },
    {
      headerName: 'Type',
      field: 'ship_type_level_3',
      tooltipField: 'ship_type_level_3',
      ...defaultCol,
    },
    {
      headerName: 'Visits',
      field: 'visit_count',
      tooltipField: 'visit_count',
      ...defaultCol,
    },
    {
      headerName: 'Total Dwell',
      field: 'total_dwell_time',
      tooltipField: 'total_dwell_time',
      ...defaultCol,
    },
    {
      headerName: 'Avg Dwell',
      field: 'avg_dwell_time',
      tooltipField: 'avg_dwell_time',
      ...defaultCol,
    },
  ];
}
