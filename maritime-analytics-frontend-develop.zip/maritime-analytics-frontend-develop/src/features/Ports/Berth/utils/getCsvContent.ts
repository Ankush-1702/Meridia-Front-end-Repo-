import { BerthDetailsApiResponse } from '../types/berthDetailsTypes';
import { BerthRow } from '@/features/Ports/Berth/types/berthTypes';
import { createBerthColumnDefs } from '@/features/Ports/Berth/utils/BerthColDefs';
import { getDisplayName } from '@/shared/utils/CongestionAndTrafficUtils'; // adjust path
import { toCSVRow } from '@/shared/utils/formatUtils';

const escapeCSV = (value: unknown): string => {
  if (value == null) return '-';
  const str = String(value).replace(/"/g, '""');
  return /[,"\n]/.test(str) ? `"${str}"` : str;
};

export const getCSVContent = (berthRows: BerthRow[]): string => {
  const colDefs = createBerthColumnDefs().filter(
    (c) => !c.hide && c.field !== 'terminal_name',
  );

  // Add Terminal Name as the first column
  const headers = [
    'Terminal Name',
    ...colDefs.map((c) => c.headerName ?? c.field ?? ''),
  ].join(',');

  const dataRows = berthRows.map((row) => {
    const terminalName = escapeCSV(row.terminal_name);

    const fields = colDefs.map((col) => {
      const field = col.field as keyof BerthRow;
      if (!field) return '-';

      // Vessel types → "Oil Tanker (60%), Container (40%)"
      if (field === 'vessel_types') {
        const segments = row.vessel_types;
        if (!segments || segments.length === 0) return '-';

        const formatted = segments
          .map(
            (seg) =>
              `${getDisplayName(seg.ship_type_level_3)} (${(seg.proportion * 100).toFixed(0)}%)`,
          )
          .join(' | ');

        return escapeCSV(formatted);
      }

      const raw = row[field];
      if (raw == null || raw === '') return '-';
      return escapeCSV(raw);
    });

    return [terminalName, ...fields].join(',');
  });

  return [headers, ...dataRows].join('\n');
};

export function buildDwellTimeSeriesCsv(data?: BerthDetailsApiResponse) {
  if (!data) return;
  const headers = toCSVRow([
    'Berth Name',
    'Terminal type',
    'Terminal Operator',
    'Date',
    'Dwell Time at berth (avg)',
    'Dwell Time at berth (median)',
  ]);

  const name = data.berth_details.berth_name;
  const terminalType = data.berth_details.terminal_type;
  const terminalOperator = data.berth_details.terminal_operator;
  const dataRows = data.dwell_time_series.map((d) => {
    return toCSVRow([
      name,
      terminalType,
      terminalOperator,
      d.period_start,
      d.avg_dwell_time || '-',
      d.median_dwell_time || '-',
    ]);
  });

  return [headers, ...dataRows].join('\n');
}
