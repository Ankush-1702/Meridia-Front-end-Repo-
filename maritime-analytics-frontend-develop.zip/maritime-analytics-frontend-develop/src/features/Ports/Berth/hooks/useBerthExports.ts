import { useCallback, useEffect, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { berthExportManager } from '@/features/Ports/Berth/utils/berthExportsManager';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';

export function useBerthExports(
  portId: string | undefined,
  dateStart: string,
  dateEnd: string,
  activeBerthTypes: string[],
  activeTerminalNames: string[],
) {
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const [isPolling, setIsPolling] = useState(berthExportManager.isPolling());

  const buildCallbacks = useCallback(
    () => ({
      onStatus: () => setIsPolling(true),
      onDownloadReady: (url: string) => {
        setIsPolling(false);
        showToast('info', 'Downloading export...', 500);
        setTimeout(() => {
          const link = document.createElement('a');
          link.href = url;
          link.download = 'berths-export.csv';
          link.click();
          showToast('success', 'CSV Exported!', 5000);
        }, 500);
      },
      onError: (e: unknown) => {
        setIsPolling(false);
        handleApiError(e);
      },
    }),
    [showToast, handleApiError],
  );

  // Re-register callbacks on every mount so the live component always receives events
  // No cleanup — intentionally do NOT stop polling on unmount
  useEffect(() => {
    berthExportManager.registerCallbacks(buildCallbacks());
  }, [buildCallbacks]);

  const handleExportClick = useCallback(async () => {
    if (!portId || !dateStart || !dateEnd || berthExportManager.isPolling())
      return;

    showToast('info', 'Exporting CSV...', 2000);
    setIsPolling(true);

    try {
      await berthExportManager.trigger(
        portId,
        dateStart,
        dateEnd,
        activeBerthTypes,
        activeTerminalNames,
        buildCallbacks(),
      );
    } catch (e) {
      setIsPolling(false);
      handleApiError(e);
    }
  }, [
    portId,
    dateStart,
    dateEnd,
    activeBerthTypes,
    activeTerminalNames,
    buildCallbacks,
    showToast,
    handleApiError,
  ]);

  return { handleExportClick, isPolling };
}
