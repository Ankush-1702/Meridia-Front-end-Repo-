import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useBerthExports } from '@/features/Ports/Berth/hooks/useBerthExports';

const handleApiErrorMock = vi.fn();
const showToastMock = vi.fn();

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: showToastMock }),
}));

vi.mock('@/features/Ports/Berth/utils/berthExportsManager', () => ({
  berthExportManager: {
    isPolling: vi.fn(() => false),
    registerCallbacks: vi.fn(),
    trigger: vi.fn(),
    cancel: vi.fn(),
  },
}));

async function getMockedManager() {
  const { berthExportManager } = await import(
    '@/features/Ports/Berth/utils/berthExportsManager'
  );
  return berthExportManager;
}

describe('useBerthExports', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('registers callbacks on mount', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);

    renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    expect(manager.registerCallbacks).toHaveBeenCalledWith(
      expect.objectContaining({
        onStatus: expect.any(Function),
        onDownloadReady: expect.any(Function),
        onError: expect.any(Function),
      }),
    );
  });

  it('initializes isPolling from the manager', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(true);

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    expect(result.current.isPolling).toBe(true);
  });

  it('handleExportClick is a no-op when required params are missing', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);

    const { result } = renderHook(() =>
      useBerthExports(undefined, '2025-01-01', '2025-01-31', [], []),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    expect(manager.trigger).not.toHaveBeenCalled();
  });

  it('handleExportClick is a no-op when the manager is already polling', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(true);

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    expect(manager.trigger).not.toHaveBeenCalled();
  });

  it('handleExportClick shows a toast, sets isPolling, and triggers the manager', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);
    vi.mocked(manager.trigger).mockResolvedValue(undefined);

    const { result } = renderHook(() =>
      useBerthExports(
        'port-1',
        '2025-01-01',
        '2025-01-31',
        ['Container'],
        ['Terminal A'],
      ),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    expect(showToastMock).toHaveBeenCalledWith(
      'info',
      'Exporting CSV...',
      2000,
    );
    expect(result.current.isPolling).toBe(true);
    expect(manager.trigger).toHaveBeenCalledWith(
      'port-1',
      '2025-01-01',
      '2025-01-31',
      ['Container'],
      ['Terminal A'],
      expect.objectContaining({
        onStatus: expect.any(Function),
        onDownloadReady: expect.any(Function),
        onError: expect.any(Function),
      }),
    );
  });

  it('handleExportClick resets isPolling and reports errors when trigger rejects', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);
    vi.mocked(manager.trigger).mockRejectedValue(new Error('trigger failed'));

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    expect(result.current.isPolling).toBe(false);
    expect(handleApiErrorMock).toHaveBeenCalled();
  });

  it('onDownloadReady callback triggers a download and success toast after the delay', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);
    vi.mocked(manager.trigger).mockResolvedValue(undefined);

    const anchor = {
      href: '',
      download: '',
      click: vi.fn(),
    } as unknown as HTMLAnchorElement;
    const realCreateElement = document.createElement.bind(document);
    const createElementSpy = vi
      .spyOn(document, 'createElement')
      .mockImplementation((tagName: string) =>
        tagName === 'a' ? anchor : realCreateElement(tagName),
      );

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    const callbacks = vi.mocked(manager.trigger).mock.calls[0][5];

    act(() => {
      callbacks.onDownloadReady?.('https://example.com/export.csv', 'name');
    });

    expect(result.current.isPolling).toBe(false);
    expect(showToastMock).toHaveBeenCalledWith(
      'info',
      'Downloading export...',
      500,
    );

    await act(async () => {
      await vi.advanceTimersByTimeAsync(500);
    });

    expect(createElementSpy).toHaveBeenCalledWith('a');
    expect(anchor.href).toBe('https://example.com/export.csv');
    expect(anchor.download).toBe('berths-export.csv');
    expect(anchor.click).toHaveBeenCalled();
    expect(showToastMock).toHaveBeenCalledWith(
      'success',
      'CSV Exported!',
      5000,
    );

    createElementSpy.mockRestore();
  });

  it('onError callback resets isPolling and reports the error', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);
    vi.mocked(manager.trigger).mockResolvedValue(undefined);

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    await act(async () => {
      await result.current.handleExportClick();
    });

    const callbacks = vi.mocked(manager.trigger).mock.calls[0][5];
    const error = new Error('poll failed');

    act(() => {
      callbacks.onError?.(error);
    });

    expect(result.current.isPolling).toBe(false);
    expect(handleApiErrorMock).toHaveBeenCalledWith(error);
  });

  it('onStatus callback sets isPolling to true', async () => {
    const manager = await getMockedManager();
    vi.mocked(manager.isPolling).mockReturnValue(false);

    const { result } = renderHook(() =>
      useBerthExports('port-1', '2025-01-01', '2025-01-31', [], []),
    );

    const registeredCallbacks = vi.mocked(manager.registerCallbacks).mock
      .calls[0][0];

    act(() => {
      registeredCallbacks.onStatus?.('PROCESSING');
    });

    expect(result.current.isPolling).toBe(true);
  });
});
