import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useBerthDetails } from '@/features/Ports/Berth/hooks/useBerthDetails';
import type {
  BerthDetailsApiResponse,
  FlagResponse,
} from '@/features/Ports/Berth/types/berthDetailsTypes';

const handleApiErrorMock = vi.fn();

vi.mock('react-router', () => ({
  useParams: () => ({ id: 'port-1' }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/features/Ports/Berth/services/berthDetailsService', () => ({
  getBerthDetails: vi.fn(),
  getVesselFlags: vi.fn(),
}));

const flagResponse: FlagResponse = {
  vessel_flags: [
    { code: 'US', name: 'United States' },
    { code: 'GB', name: 'United Kingdom' },
  ],
};

function buildBerthDetailsResponse(
  overrides: Partial<BerthDetailsApiResponse> = {},
): BerthDetailsApiResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '' },
    query: {
      date_start: '2025-01-01',
      date_end: '2025-01-31',
      vessel_flags: [],
      page: 1,
      page_size: 15,
      top_n: 10,
      view_mode: 'gantt',
      dwell_series_granularity: 'daily',
    },
    berth_details: {
      berth_id: 'b1',
      berth_name: 'Berth 1',
      berth_status: 'active',
      terminal_operator: 'Op',
      terminal_type: 'Container',
      berth_facility: 'Facility',
      length_m: 100,
      max_loa_m: 200,
      max_dwt: 50000,
      depth_lw_m: 12,
      avg_dwell_time: 10,
      median_dwell_time: 8,
    },
    dwell_time_series: [],
    occupancy: {
      display_date_start: '2025-01-01T00:00:00Z',
      display_date_end: '2025-01-31T00:00:00Z',
      gap_time_total: 0,
      gap_time_avg: 0,
      pagination: {
        total_days: 30,
        page: 1,
        page_size: 15,
        day_start: 0,
        day_end: 30,
      },
      visits: [],
      gaps: [],
      top_vessels: [],
    },
    ...overrides,
  };
}

async function getMockedService() {
  return await import('@/features/Ports/Berth/services/berthDetailsService');
}

describe('useBerthDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('does not call services when dateRange is empty', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(getVesselFlags).not.toHaveBeenCalled();
    expect(getBerthDetails).not.toHaveBeenCalled();
  });

  it('does not call services when berthId is missing', async () => {
    const { getVesselFlags } = await getMockedService();
    const { result } = renderHook(() => useBerthDetails(undefined));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01',
        end: '2025-01-31',
      });
      await vi.runAllTimersAsync();
    });

    expect(getVesselFlags).not.toHaveBeenCalled();
  });

  it('fetches vessel flags then berth details on dateRange set, and clears initialLoading', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockResolvedValue(buildBerthDetailsResponse());

    const { result } = renderHook(() => useBerthDetails('b1'));
    expect(result.current.initialLoading).toBe(true);

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(getVesselFlags).toHaveBeenCalledWith(
      'port-1',
      'b1',
      '2025-01-01',
      '2025-01-31',
    );
    expect(getBerthDetails).toHaveBeenCalledWith(
      'port-1',
      'b1',
      '2025-01-01',
      '2025-01-31',
      'US,GB',
      30,
    );
    expect(result.current.vesselFlags).toEqual(flagResponse);
    expect(result.current.selectedFlags).toEqual({ US: true, GB: true });
    expect(result.current.berthData).toEqual(buildBerthDetailsResponse());
    expect(result.current.initialLoading).toBe(false);
  });

  it('handles getVesselFlags rejection by clearing data and forcing initialLoading false', async () => {
    const { getVesselFlags } = await getMockedService();
    vi.mocked(getVesselFlags).mockRejectedValue(new Error('flags failed'));

    const { result } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
    expect(result.current.vesselFlags).toBeUndefined();
    expect(result.current.berthData).toBeUndefined();
    expect(result.current.initialLoading).toBe(false);
  });

  it('handles getBerthDetails rejection after vessel flags succeed', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockRejectedValue(new Error('details failed'));

    const { result } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
    expect(result.current.berthData).toBeUndefined();
    expect(result.current.initialLoading).toBe(false);
  });

  it('debounces handleFlagToggle and coalesces rapid calls into one fetch', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockResolvedValue(buildBerthDetailsResponse());

    const { result } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    const callsAfterInitial = vi.mocked(getBerthDetails).mock.calls.length;

    act(() => {
      result.current.handleFlagToggle('US', false);
    });
    act(() => {
      result.current.handleFlagToggle('GB', false);
    });

    expect(result.current.selectedFlags).toEqual({ US: false, GB: false });

    await act(async () => {
      await vi.advanceTimersByTimeAsync(1100);
    });

    expect(vi.mocked(getBerthDetails).mock.calls.length).toBe(
      callsAfterInitial + 1,
    );
    expect(result.current.loading).toBe(false);
  });

  it('handleFlagSelectAll toggles all flags and triggers debounced fetch', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockResolvedValue(buildBerthDetailsResponse());

    const { result } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    act(() => {
      result.current.handleFlagSelectAll(false);
    });

    expect(result.current.selectedFlags).toEqual({ US: false, GB: false });

    await act(async () => {
      await vi.advanceTimersByTimeAsync(1100);
    });

    expect(getBerthDetails).toHaveBeenLastCalledWith(
      'port-1',
      'b1',
      '2025-01-01',
      '2025-01-31',
      '',
      30,
    );
  });

  it('handleFlagSelectAll is a no-op when vesselFlags is undefined', async () => {
    const { getBerthDetails } = await getMockedService();
    const { result } = renderHook(() => useBerthDetails('b1'));

    act(() => {
      result.current.handleFlagSelectAll(true);
    });

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(getBerthDetails).not.toHaveBeenCalled();
  });

  it('hasVesselFlags reflects presence of flags', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue({ vessel_flags: [] });
    vi.mocked(getBerthDetails).mockResolvedValue(buildBerthDetailsResponse());

    const { result } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(result.current.hasVesselFlags).toBeFalsy();
  });

  it('hasData is false when all dwell values are zero and true otherwise', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockResolvedValue(
      buildBerthDetailsResponse({
        dwell_time_series: [
          {
            period_start: '2025-01-01',
            avg_dwell_time: 0,
            median_dwell_time: 0,
          },
        ],
      }),
    );

    const { result, rerender } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(result.current.hasData).toBeFalsy();
    expect(result.current.transformDwellTimeData).toEqual([
      { period: '2025-01-01', avgDwell: 0, medianDwell: 0 },
    ]);

    vi.mocked(getBerthDetails).mockResolvedValue(
      buildBerthDetailsResponse({
        dwell_time_series: [
          {
            period_start: '2025-01-02',
            avg_dwell_time: 5,
            median_dwell_time: 0,
          },
        ],
      }),
    );

    act(() => {
      result.current.handleFlagSelectAll(true);
    });

    await act(async () => {
      await vi.advanceTimersByTimeAsync(1100);
    });
    rerender();

    expect(result.current.hasData).toBeTruthy();
  });

  it('clears the pending debounce timer on unmount', async () => {
    const { getVesselFlags, getBerthDetails } = await getMockedService();
    vi.mocked(getVesselFlags).mockResolvedValue(flagResponse);
    vi.mocked(getBerthDetails).mockResolvedValue(buildBerthDetailsResponse());

    const { result, unmount } = renderHook(() => useBerthDetails('b1'));

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    const callsBeforeUnmount = vi.mocked(getBerthDetails).mock.calls.length;

    act(() => {
      result.current.handleFlagToggle('US', false);
    });

    unmount();

    await act(async () => {
      await vi.advanceTimersByTimeAsync(1100);
    });

    expect(vi.mocked(getBerthDetails).mock.calls.length).toBe(
      callsBeforeUnmount,
    );
  });
});
