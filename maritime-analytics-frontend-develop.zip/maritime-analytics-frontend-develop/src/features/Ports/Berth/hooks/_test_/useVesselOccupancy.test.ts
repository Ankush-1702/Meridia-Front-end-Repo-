import { renderHook, act } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { useVesselOccupancy } from '@/features/Ports/Berth/hooks/useVesselOccupancy';
import type { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';

function buildBerthData(
  overrides: Partial<BerthDetailsApiResponse['occupancy']> = {},
): BerthDetailsApiResponse {
  return {
    meta: { request_id: 'req-1', request_timestamp: '' },
    query: {
      date_start: '2025-01-01',
      date_end: '2025-01-31',
      vessel_flags: [],
      page: 1,
      page_size: 15,
      top_n: 10,
      view_mode: 'gantt',
      dwell_series_granularity: 'daily',
    },
    berth_details: {
      berth_id: 'b1',
      berth_name: 'Berth 1',
      berth_status: 'active',
      terminal_operator: 'Op',
      terminal_type: 'Container',
      berth_facility: 'Facility',
      length_m: 100,
      max_loa_m: 200,
      max_dwt: 50000,
      depth_lw_m: 12,
      avg_dwell_time: 10,
      median_dwell_time: 8,
    },
    dwell_time_series: [],
    occupancy: {
      display_date_start: '2025-01-01T00:00:00Z',
      display_date_end: '2025-01-31T00:00:00Z',
      gap_time_total: 0,
      gap_time_avg: 0,
      pagination: {
        total_days: 30,
        page: 1,
        page_size: 15,
        day_start: 0,
        day_end: 30,
      },
      visits: [],
      gaps: [],
      top_vessels: [],
      ...overrides,
    },
  };
}

describe('useVesselOccupancy', () => {
  it('returns empty defaults when berthData is undefined', () => {
    const { result } = renderHook(() => useVesselOccupancy(undefined));

    expect(result.current.timelineEnd).toBe(0);
    expect(result.current.vessels).toEqual([]);
    expect(result.current.gaps).toEqual([]);
    expect(result.current.dateTicks).toEqual([]);
    expect(result.current.maxOffset).toBe(0);
    expect(result.current.offset).toBe(0);
    expect(result.current.windowStart).toBe(0);
    expect(result.current.windowEnd).toBe(15);
  });

  it('maps visits into day-offset vessel entries sorted by start', () => {
    const berthData = buildBerthData({
      visits: [
        {
          imo_number: '2',
          vessel_name: 'Second',
          ship_type_level_3: 'Bulk',
          vessel_flag: 'UK',
          vessel_flag_code: 'GB',
          arrival_time: '2025-01-10T00:00:00Z',
          departure_time: '2025-01-12T00:00:00Z',
          hours_at_berth: 48,
        },
        {
          imo_number: '1',
          vessel_name: 'First',
          ship_type_level_3: 'Tanker',
          vessel_flag: 'US',
          vessel_flag_code: 'US',
          arrival_time: '2025-01-02T00:00:00Z',
          departure_time: '2025-01-04T00:00:00Z',
          hours_at_berth: 48,
        },
      ],
    });

    const { result } = renderHook(() => useVesselOccupancy(berthData));

    expect(result.current.vessels).toHaveLength(2);
    expect(result.current.vessels[0].imo_number).toBe('1');
    expect(result.current.vessels[0].start).toBe(1);
    expect(result.current.vessels[0].end).toBe(3);
    expect(result.current.vessels[1].imo_number).toBe('2');
    expect(result.current.vessels[1].start).toBe(9);
    expect(result.current.vessels[1].end).toBe(11);
    expect(result.current.timelineEnd).toBe(30);
  });

  it('fills gaps for uncovered periods around visits and merges API gaps', () => {
    const berthData = buildBerthData({
      visits: [
        {
          imo_number: '1',
          vessel_name: 'First',
          ship_type_level_3: 'Tanker',
          vessel_flag: 'US',
          vessel_flag_code: 'US',
          arrival_time: '2025-01-10T00:00:00Z',
          departure_time: '2025-01-12T00:00:00Z',
          hours_at_berth: 48,
        },
      ],
      gaps: [
        {
          start_time: '2025-01-20T00:00:00Z',
          end_time: '2025-01-21T00:00:00Z',
          gap_duration: 24,
        },
      ],
    });

    const { result } = renderHook(() => useVesselOccupancy(berthData));

    // filler gaps before first visit (0-9), between visit end (11) and API gap start (19),
    // and after API gap end (20) to total days (30), plus the API gap itself
    expect(result.current.gaps.length).toBeGreaterThanOrEqual(4);
    const sorted = result.current.gaps.map((g) => g.start);
    expect(sorted).toEqual([...sorted].sort((a, b) => a - b));
    expect(result.current.gaps[0].start).toBe(0);
    expect(result.current.gaps[0].end).toBe(9);
  });

  it('generates date ticks every 2 days across the timeline', () => {
    const berthData = buildBerthData();
    const { result } = renderHook(() => useVesselOccupancy(berthData));

    expect(result.current.dateTicks.length).toBe(16); // 0,2,...,30
    expect(result.current.dateTicks[0].day).toBe(0);
    expect(
      result.current.dateTicks[result.current.dateTicks.length - 1].day,
    ).toBe(30);
  });

  it('clamps onPrev at 0 and onNext at maxOffset', () => {
    const berthData = buildBerthData();
    const { result } = renderHook(() => useVesselOccupancy(berthData));

    expect(result.current.maxOffset).toBe(15); // 30 - WINDOW_DAYS(15)

    act(() => {
      result.current.onPrev();
    });
    expect(result.current.offset).toBe(0);

    act(() => {
      result.current.onNext();
    });
    expect(result.current.offset).toBe(7);

    act(() => {
      result.current.onNext();
    });
    expect(result.current.offset).toBe(14); // clamped to maxOffset (7+7=14 <= 15)

    act(() => {
      result.current.onPrev();
    });
    expect(result.current.offset).toBe(7);
  });

  it('does not allow onNext to advance when timelineEnd is within the window', () => {
    const berthData = buildBerthData({
      display_date_start: '2025-01-01T00:00:00Z',
      display_date_end: '2025-01-05T00:00:00Z',
      pagination: {
        total_days: 4,
        page: 1,
        page_size: 15,
        day_start: 0,
        day_end: 4,
      },
    } as never);
    const { result } = renderHook(() => useVesselOccupancy(berthData));

    expect(result.current.maxOffset).toBe(0);

    act(() => {
      result.current.onNext();
    });
    expect(result.current.offset).toBe(0);
  });

  it('resets offset to 0 when berthData changes', () => {
    const berthData = buildBerthData();
    const { result, rerender } = renderHook(
      ({ data }) => useVesselOccupancy(data),
      { initialProps: { data: berthData } },
    );

    act(() => {
      result.current.onNext();
    });
    expect(result.current.offset).toBe(7);

    const newBerthData = buildBerthData({ gap_time_total: 5 });
    rerender({ data: newBerthData });

    expect(result.current.offset).toBe(0);
  });
});
