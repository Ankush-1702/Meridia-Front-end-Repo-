import { renderHook, act } from '@testing-library/react';
import type { IServerSideGetRowsParams } from 'ag-grid-enterprise';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useBerths } from '@/features/Ports/Berth/hooks/useBerths';
import type {
  BerthApiResponse,
  BerthFilterResponse,
} from '@/features/Ports/Berth/types/berthTypes';

const handleApiErrorMock = vi.fn();

vi.mock('react-router', () => ({
  useParams: () => ({ id: 'port-1' }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/features/Ports/Berth/services/berthServices', () => ({
  getBerths: vi.fn(),
  getBerthFilters: vi.fn(),
}));

async function getMockedService() {
  return await import('@/features/Ports/Berth/services/berthServices');
}

function buildFilters(
  overrides: Partial<BerthFilterResponse> = {},
): BerthFilterResponse {
  return {
    berth_types: ['Container', 'Bulk'],
    terminal_names: ['Terminal A', 'Terminal B'],
    ...overrides,
  };
}

function buildBerthsResponse(
  overrides: Partial<BerthApiResponse> = {},
): BerthApiResponse {
  return {
    meta: {
      request_id: 'req-1',
      request_timestamp: '',
      total_count: 2,
      limit: 500,
      offset: 0,
    },
    query: {
      date_start: '2025-01-01',
      date_end: '2025-01-31',
      terminal_type: [],
      terminal_name: [],
    },
    port_information: {
      id: 'port-1',
      name: 'Port A',
      unlocode: 'AAAAA',
      country: 'GB',
    },
    kpi: {
      total_berths: 2,
      min_dwell_time: 1,
      max_dwell_time: 10,
      terminal_operators: 1,
    },
    terminals: [
      {
        terminal_name: 'Terminal A',
        berths: [
          {
            berth_id: 'b1',
            berth_name: 'Berth 1',
            berth_status: 'active',
            berth_type: 'Container',
            berth_facility: 'Facility',
            length_m: 100,
            max_loa_m: 200,
            max_dwt: 50000,
            depth_lw_m: 12,
            min_dwell_time: 1,
            avg_dwell_time: 5,
            median_dwell_time: 4,
            max_dwell_time: 10,
            vessel_types: [],
          },
        ],
      },
    ],
    ...overrides,
  };
}

function buildLevel0Params(): IServerSideGetRowsParams {
  return {
    request: { groupKeys: [], startRow: 0 },
    api: {
      setGridOption: vi.fn(),
      showNoRowsOverlay: vi.fn(),
      hideOverlay: vi.fn(),
    },
    success: vi.fn(),
    fail: vi.fn(),
  } as unknown as IServerSideGetRowsParams;
}

function buildLevel1Params(terminalName: string): IServerSideGetRowsParams {
  return {
    request: { groupKeys: [terminalName], startRow: 0 },
    api: {
      setGridOption: vi.fn(),
      showNoRowsOverlay: vi.fn(),
      hideOverlay: vi.fn(),
    },
    success: vi.fn(),
    fail: vi.fn(),
  } as unknown as IServerSideGetRowsParams;
}

describe('useBerths', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('does not fetch filters until dateRange is set', async () => {
    const { getBerthFilters } = await getMockedService();
    renderHook(() => useBerths());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(getBerthFilters).not.toHaveBeenCalled();
  });

  it('fetches filters and defaults selections to all-true once dateRange is set', async () => {
    const { getBerthFilters } = await getMockedService();
    vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

    const { result } = renderHook(() => useBerths());

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(getBerthFilters).toHaveBeenCalledWith('port-1');
    expect(result.current.berthTypes).toEqual(['Container', 'Bulk']);
    expect(result.current.terminalNames).toEqual(['Terminal A', 'Terminal B']);
    expect(result.current.selectedBerthTypes).toEqual({
      Container: true,
      Bulk: true,
    });
    expect(result.current.activeBerthTypes).toEqual(['Container', 'Bulk']);
  });

  it('handles fetchInitialFilters rejection via handleApiError', async () => {
    const { getBerthFilters } = await getMockedService();
    vi.mocked(getBerthFilters).mockRejectedValue(new Error('boom'));

    const { result } = renderHook(() => useBerths());

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
  });

  describe('getServerSideData — level 0 (terminals)', () => {
    it('fails the request when id/dateRange are missing', async () => {
      const { getBerths } = await getMockedService();
      const { result } = renderHook(() => useBerths());
      const params = buildLevel0Params();

      await act(async () => {
        await result.current.getServerSideData(params);
      });

      expect(params.fail).toHaveBeenCalled();
      expect(getBerths).not.toHaveBeenCalled();
    });

    it('fetches terminals and flattens berth rows on success', async () => {
      const { getBerthFilters, getBerths } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
      vi.mocked(getBerths).mockResolvedValue(buildBerthsResponse());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      const params = buildLevel0Params();
      await act(async () => {
        await result.current.getServerSideData(params);
      });

      expect(getBerths).toHaveBeenCalledWith(
        'port-1',
        '2025-01-01',
        '2025-01-31',
        0,
        'Container,Bulk',
        'Terminal A,Terminal B',
      );
      expect(params.success).toHaveBeenCalledWith({
        rowData: [{ terminal_name: 'Terminal A', berth_count: 1 }],
        rowCount: 1,
      });
      expect(params.api.hideOverlay).toHaveBeenCalled();
      expect(result.current.berthRows).toEqual([
        expect.objectContaining({
          berth_id: 'b1',
          terminal_name: 'Terminal A',
        }),
      ]);
      expect(result.current.berthData).toEqual(buildBerthsResponse());
    });

    it('shows no-rows overlay when there are zero terminals', async () => {
      const { getBerthFilters, getBerths } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
      vi.mocked(getBerths).mockResolvedValue(
        buildBerthsResponse({ terminals: [] }),
      );

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      const params = buildLevel0Params();
      await act(async () => {
        await result.current.getServerSideData(params);
      });

      expect(params.success).toHaveBeenCalledWith({ rowData: [], rowCount: 0 });
      expect(params.api.showNoRowsOverlay).toHaveBeenCalled();
    });

    it('handles getBerths rejection: empty success, delayed overlay, error handled', async () => {
      const { getBerthFilters, getBerths } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
      vi.mocked(getBerths).mockRejectedValue(new Error('fetch failed'));

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      const params = buildLevel0Params();
      await act(async () => {
        await result.current.getServerSideData(params);
        await vi.runAllTimersAsync();
      });

      expect(params.success).toHaveBeenCalledWith({ rowData: [], rowCount: 0 });
      expect(params.api.showNoRowsOverlay).toHaveBeenCalled();
      expect(handleApiErrorMock).toHaveBeenCalled();
      expect(result.current.berthData).toBeUndefined();
      expect(params.api.setGridOption).toHaveBeenCalledWith('loading', false);
    });
  });

  describe('getServerSideData — level 1 (berths for a terminal)', () => {
    it('fails the request when there is no cached response yet', async () => {
      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      const params = buildLevel1Params('Terminal A');
      await act(async () => {
        await result.current.getServerSideData(params);
      });

      expect(params.fail).toHaveBeenCalled();
    });

    it('returns cached berths for a matching terminal after a level-0 fetch', async () => {
      const { getBerthFilters, getBerths } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
      vi.mocked(getBerths).mockResolvedValue(buildBerthsResponse());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        await result.current.getServerSideData(buildLevel0Params());
      });

      const level1Params = buildLevel1Params('Terminal A');
      await act(async () => {
        await result.current.getServerSideData(level1Params);
      });

      expect(level1Params.success).toHaveBeenCalledWith({
        rowData: [
          expect.objectContaining({
            berth_id: 'b1',
            terminal_name: 'Terminal A',
          }),
        ],
        rowCount: 1,
      });
    });

    it('returns an empty result when the terminal name is not found in cache', async () => {
      const { getBerthFilters, getBerths } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
      vi.mocked(getBerths).mockResolvedValue(buildBerthsResponse());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        await result.current.getServerSideData(buildLevel0Params());
      });

      const level1Params = buildLevel1Params('Unknown Terminal');
      await act(async () => {
        await result.current.getServerSideData(level1Params);
      });

      expect(level1Params.success).toHaveBeenCalledWith({
        rowData: [],
        rowCount: 0,
      });
    });
  });

  describe('filter toggles', () => {
    it('handleBerthTypeToggle cross-filters terminal names and debounces refresh', async () => {
      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      vi.mocked(getBerthFilters).mockResolvedValue(
        buildFilters({ terminal_names: ['Terminal A'] }),
      );

      await act(async () => {
        await result.current.handleBerthTypeToggle('Bulk', false);
      });

      expect(result.current.selectedBerthTypes).toEqual({
        Container: true,
        Bulk: false,
      });
      expect(getBerthFilters).toHaveBeenLastCalledWith(
        'port-1',
        'Container',
        undefined,
      );
      expect(result.current.terminalNames).toEqual(['Terminal A']);

      await act(async () => {
        await vi.advanceTimersByTimeAsync(1100);
      });
    });

    it('handleBerthTypeToggle reports errors from the cross-filter fetch', async () => {
      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValueOnce(buildFilters());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      vi.mocked(getBerthFilters).mockRejectedValueOnce(
        new Error('cross-filter failed'),
      );

      await act(async () => {
        await result.current.handleBerthTypeToggle('Bulk', false);
      });

      expect(handleApiErrorMock).toHaveBeenCalled();
    });

    it('handleTerminalNameToggle cross-filters berth types', async () => {
      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());

      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      vi.mocked(getBerthFilters).mockResolvedValue(
        buildFilters({ berth_types: ['Container'] }),
      );

      await act(async () => {
        await result.current.handleTerminalNameToggle('Terminal B', false);
      });

      expect(result.current.selectedTerminalNames).toEqual({
        'Terminal A': true,
        'Terminal B': false,
      });
      expect(getBerthFilters).toHaveBeenLastCalledWith(
        'port-1',
        undefined,
        'Terminal A',
      );
      expect(result.current.berthTypes).toEqual(['Container']);
    });

    it('handleBerthTypeSelectAll sets all/none and is a no-op without berthTypes', async () => {
      const { result: emptyResult } = renderHook(() => useBerths());
      await act(async () => {
        await emptyResult.current.handleBerthTypeSelectAll(true);
      });
      expect(emptyResult.current.selectedBerthTypes).toEqual({});

      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());
      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        await result.current.handleBerthTypeSelectAll(false);
      });

      expect(result.current.selectedBerthTypes).toEqual({
        Container: false,
        Bulk: false,
      });
      expect(result.current.activeBerthTypes).toEqual([]);
    });

    it('handleTerminalNameSelectAll sets all/none and is a no-op without terminalNames', async () => {
      const { result: emptyResult } = renderHook(() => useBerths());
      await act(async () => {
        await emptyResult.current.handleTerminalNameSelectAll(true);
      });
      expect(emptyResult.current.selectedTerminalNames).toEqual({});

      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());
      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      await act(async () => {
        await result.current.handleTerminalNameSelectAll(true);
      });

      expect(result.current.selectedTerminalNames).toEqual({
        'Terminal A': true,
        'Terminal B': true,
      });
    });

    it('resetFilters clears selection maps without re-selecting all', async () => {
      const { getBerthFilters } = await getMockedService();
      vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());

      const { result } = renderHook(() => useBerths());
      await act(async () => {
        result.current.setDateRange({
          start: '2025-01-01T00:00:00Z',
          end: '2025-01-31T00:00:00Z',
        });
        await vi.runAllTimersAsync();
      });

      expect(result.current.selectedBerthTypes).toEqual({
        Container: true,
        Bulk: true,
      });

      await act(async () => {
        await result.current.resetFilters();
      });

      expect(result.current.selectedBerthTypes).toEqual({});
      expect(result.current.selectedTerminalNames).toEqual({});
      expect(result.current.berthTypes).toEqual(['Container', 'Bulk']);
    });
  });

  it('getBerthCSVContent delegates to getCSVContent with current berthRows', async () => {
    const { getBerthFilters, getBerths } = await getMockedService();
    vi.mocked(getBerthFilters).mockResolvedValue(buildFilters());
    vi.mocked(getBerths).mockResolvedValue(buildBerthsResponse());

    const { result } = renderHook(() => useBerths());

    await act(async () => {
      result.current.setDateRange({
        start: '2025-01-01T00:00:00Z',
        end: '2025-01-31T00:00:00Z',
      });
      await vi.runAllTimersAsync();
    });

    await act(async () => {
      await result.current.getServerSideData(buildLevel0Params());
    });

    const csv = result.current.getBerthCSVContent();
    expect(typeof csv).toBe('string');
    expect(csv.split('\n')[0].length).toBeGreaterThan(0);
  });
});
