import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  getBerthDetails,
  getVesselFlags,
} from '@/features/Ports/Berth/services/berthDetailsService';
import {
  BerthDetailsApiResponse,
  FlagResponse,
} from '@/features/Ports/Berth/types/berthDetailsTypes';

export function useBerthDetails(berthId?: string) {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [berthData, setBerthData] = useState<
    BerthDetailsApiResponse | undefined
  >();
  const [vesselFlags, setVesselFlags] = useState<FlagResponse | undefined>(
    undefined,
  );
  const [selectedFlags, setSelectedFlags] = useState<Record<string, boolean>>(
    {},
  );
  const [initialLoading, setInitialLoading] = useState(true);
  const [loading, setLoading] = useState(false);

  const initialLoadQueueRef = useRef(0);
  const loadQueueRef = useRef(0);

  const isInitialLoadRef = useRef(true);
  const selectedFlagsRef = useRef(selectedFlags);
  selectedFlagsRef.current = selectedFlags;

  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const timeRange = localStorage.getItem('berthDateRange');

  const getSelected = (record: Record<string, boolean>): string[] =>
    Object.entries(record)
      .filter(([, v]) => v)
      .map(([k]) => k);

  const fetchBerthDetails = useCallback(
    async (flags: Record<string, boolean>) => {
      const activeFlags = getSelected(flags);
      if (!id || !berthId || !dateRange.start || !dateRange.end) return;
      const diffDays = Math.round(
        (new Date(dateRange.end).getTime() -
          new Date(dateRange.start).getTime()) /
          86400000,
      );

      if (isInitialLoadRef.current) {
        initialLoadQueueRef.current += 1;
        setInitialLoading(true);
      } else {
        loadQueueRef.current += 1;
        setLoading(true);
      }

      try {
        const response = await getBerthDetails(
          id,
          berthId,
          dateRange.start.split('T')[0],
          dateRange.end.split('T')[0],
          activeFlags.join(','),
          diffDays,
        );
        setBerthData(response);
      } catch (error) {
        handleApiError(error);
        setBerthData(undefined);
      } finally {
        if (isInitialLoadRef.current) {
          initialLoadQueueRef.current -= 1;
          if (initialLoadQueueRef.current === 0) {
            setInitialLoading(false);
            isInitialLoadRef.current = false;
          }
        } else {
          loadQueueRef.current -= 1;
          if (loadQueueRef.current === 0) {
            setLoading(false);
          }
        }
      }
    },
    [id, berthId, dateRange, handleApiError],
  );

  const debouncedFetchBerthDetails = useCallback(
    (flags: Record<string, boolean>) => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      debounceTimerRef.current = setTimeout(() => {
        fetchBerthDetails(flags);
      }, 1100);
    },
    [fetchBerthDetails],
  );

  const fetchVesselFlags = useCallback(async () => {
    if (!id || !berthId || !dateRange.start || !dateRange.end) return;

    try {
      const response = await getVesselFlags(
        id,
        berthId,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
      );
      setVesselFlags(response);

      const allSelected: Record<string, boolean> = Object.fromEntries(
        (response?.vessel_flags ?? []).map((vf) => [vf.code, true]),
      );
      setSelectedFlags(allSelected);
      selectedFlagsRef.current = allSelected;

      await fetchBerthDetails(allSelected);
    } catch (error) {
      handleApiError(error);
      setVesselFlags(undefined);
      setBerthData(undefined);
      if (isInitialLoadRef.current) {
        initialLoadQueueRef.current = 0;
        setInitialLoading(false);
        isInitialLoadRef.current = false;
      }
    }
  }, [id, berthId, dateRange, handleApiError, fetchBerthDetails]);

  const handleFlagToggle = useCallback(
    (value: string, checked: boolean) => {
      const updated = { ...selectedFlagsRef.current, [value]: checked };
      setSelectedFlags(updated);
      selectedFlagsRef.current = updated;
      debouncedFetchBerthDetails(updated);
    },
    [debouncedFetchBerthDetails],
  );

  const handleFlagSelectAll = useCallback(
    (checked: boolean) => {
      if (!vesselFlags?.vessel_flags) return;
      const updated: Record<string, boolean> = Object.fromEntries(
        vesselFlags.vessel_flags.map((vf) => [vf.code, checked]),
      );
      setSelectedFlags(updated);
      selectedFlagsRef.current = updated;
      debouncedFetchBerthDetails(updated);
    },
    [vesselFlags, debouncedFetchBerthDetails],
  );

  useEffect(() => {
    // isInitialLoadRef.current = true;
    fetchVesselFlags();
  }, [fetchVesselFlags]);

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  const hasVesselFlags = vesselFlags && vesselFlags?.vessel_flags?.length > 0;

  const transformDwellTimeData = berthData?.dwell_time_series.map((d) => ({
    period: d.period_start,
    avgDwell: d.avg_dwell_time ?? 0,
    medianDwell: d.median_dwell_time ?? 0,
  }));

  const hasData = useMemo(
    () =>
      transformDwellTimeData?.some(
        (d) => d.avgDwell !== 0 || d.medianDwell !== 0,
      ),
    [transformDwellTimeData],
  );

  return {
    dateRange,
    setDateRange,
    berthData,
    vesselFlags,
    selectedFlags,
    handleFlagToggle,
    handleFlagSelectAll,
    timeRange,
    hasVesselFlags,
    initialLoading,
    loading,
    hasData,
    transformDwellTimeData,
  };
}
