import { useState, useMemo, useEffect } from 'react';
import { BerthDetailsApiResponse } from '@/features/Ports/Berth/types/berthDetailsTypes';

const WINDOW_DAYS = 15;
const STEP_DAYS = 7;
const MS_PER_DAY = 86400000;

export function useVesselOccupancy(berthData?: BerthDetailsApiResponse) {
  const occupancy = berthData?.occupancy;
  const visits = useMemo(() => occupancy?.visits ?? [], [occupancy]);

  const { timelineEnd, vessels, gaps, dateTicks } = useMemo(() => {
    if (!occupancy) {
      return { timelineEnd: 0, vessels: [], gaps: [], dateTicks: [] };
    }

    const start = new Date(occupancy.display_date_start).getTime();
    const end = new Date(occupancy.display_date_end).getTime();
    const totalDays = (end - start) / MS_PER_DAY;

    const mapped = visits
      .map((v) => ({
        ...v,
        start: (new Date(v.arrival_time).getTime() - start) / MS_PER_DAY,
        end: (new Date(v.departure_time).getTime() - start) / MS_PER_DAY,
      }))
      .sort((a, b) => a.start - b.start);

    // Start with API gaps
    const apiGaps = (occupancy.gaps ?? []).map((g) => ({
      start: (new Date(g.start_time).getTime() - start) / MS_PER_DAY,
      end: (new Date(g.end_time).getTime() - start) / MS_PER_DAY,
      gap_duration: g.gap_duration,
      raw_start_time: g.start_time,
      raw_end_time: g.end_time,
    }));

    // Merge visits and API gaps into occupied intervals
    const coveredIntervals = [
      ...mapped.map((v) => ({ start: v.start, end: v.end })),
      ...apiGaps.map((g) => ({ start: g.start, end: g.end })),
    ].sort((a, b) => a.start - b.start);

    // Find uncovered periods across the full timeline
    const fillerGaps: typeof apiGaps = [];
    let cursor = 0;

    for (const interval of coveredIntervals) {
      if (interval.start > cursor) {
        const gapStart = cursor;
        const gapEnd = interval.start;
        fillerGaps.push({
          start: gapStart,
          end: gapEnd,
          gap_duration: (gapEnd - gapStart) * 24,
          raw_start_time: new Date(start + gapStart * MS_PER_DAY).toISOString(),
          raw_end_time: new Date(start + gapEnd * MS_PER_DAY).toISOString(),
        });
      }
      cursor = Math.max(cursor, interval.end);
    }

    // Gap after everything until end of timeline
    if (cursor < totalDays) {
      fillerGaps.push({
        start: cursor,
        end: totalDays,
        gap_duration: (totalDays - cursor) * 24,
        raw_start_time: new Date(start + cursor * MS_PER_DAY).toISOString(),
        raw_end_time: new Date(end).toISOString(),
      });
    }

    // Combine API gaps + filler gaps
    const allGaps = [...apiGaps, ...fillerGaps].sort(
      (a, b) => a.start - b.start,
    );

    const ticks: { label: string; day: number }[] = [];
    for (let d = 0; d <= totalDays; d += 2) {
      const label = new Date(start + d * MS_PER_DAY).toLocaleDateString(
        'en-GB',
        {
          day: 'numeric',
          month: 'short',
        },
      );
      ticks.push({ label, day: d });
    }

    return {
      timelineEnd: totalDays,
      vessels: mapped,
      gaps: allGaps,
      dateTicks: ticks,
    };
  }, [occupancy, visits]);

  const maxOffset = Math.max(0, timelineEnd - WINDOW_DAYS);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    setOffset(0);
  }, [berthData]);

  const onPrev = () => setOffset(Math.max(0, offset - STEP_DAYS));
  const onNext = () => setOffset(Math.min(maxOffset, offset + STEP_DAYS));

  return {
    occupancy,
    visits,
    vessels,
    gaps,
    dateTicks,
    timelineEnd,
    offset,
    maxOffset,
    onPrev,
    onNext,
    windowStart: offset,
    windowEnd: offset + WINDOW_DAYS,
  };
}
