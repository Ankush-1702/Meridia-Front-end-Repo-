import { IServerSideGetRowsParams } from 'ag-grid-enterprise';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router';
import { getCSVContent } from '../utils/getCsvContent';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  getBerthFilters,
  getBerths,
} from '@/features/Ports/Berth/services/berthServices';
import {
  BerthApiResponse,
  BerthRow,
} from '@/features/Ports/Berth/types/berthTypes';
import { getSelected } from '@/features/Ports/utils/portUtils';
import { PoleStarEntityGridRef } from '@/shared/lib/PoleStarEntityGrid';

export function useBerths() {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const [loading, setLoading] = useState(false);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [berthData, setBerthData] = useState<BerthApiResponse | undefined>(
    undefined,
  );
  const [berthRows, setBerthRows] = useState<BerthRow[]>([]);
  const [berthTypes, setBerthTypes] = useState<string[] | undefined>(undefined);
  const [terminalNames, setTerminalNames] = useState<string[] | undefined>(
    undefined,
  );
  const [selectedBerthTypes, setSelectedBerthTypes] = useState<
    Record<string, boolean>
  >({});
  const [selectedTerminalNames, setSelectedTerminalNames] = useState<
    Record<string, boolean>
  >({});

  const [selectedBerthId, setSelectedBerthId] = useState<string | undefined>(
    undefined,
  );
  const [selectedBerthName, setSelectedBerthName] = useState<
    string | undefined
  >();

  const [isExpanded, setIsExpanded] = useState(false);

  const filtersRef = useRef({ selectedBerthTypes, selectedTerminalNames });
  filtersRef.current = { selectedBerthTypes, selectedTerminalNames };

  const cachedResponseRef = useRef<BerthApiResponse | null>(null);

  const gridRef = useRef<PoleStarEntityGridRef>(null);

  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshGrid = useCallback(() => {
    cachedResponseRef.current = null;
    gridRef.current?.refresh();
  }, []);

  const debouncedRefreshGrid = useCallback(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      refreshGrid();
    }, 1100);
  }, [refreshGrid]);

  const fetchInitialFilters = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    try {
      const response = await getBerthFilters(id);
      setBerthTypes(response.berth_types);
      setTerminalNames(response.terminal_names);

      const allBerthTypes: Record<string, boolean> = Object.fromEntries(
        (response.berth_types || []).map((v) => [v, true]),
      );
      const allTerminalNames: Record<string, boolean> = Object.fromEntries(
        (response.terminal_names || []).map((v) => [v, true]),
      );

      setSelectedBerthTypes(allBerthTypes);
      setSelectedTerminalNames(allTerminalNames);
      filtersRef.current = {
        selectedBerthTypes: allBerthTypes,
        selectedTerminalNames: allTerminalNames,
      };

      refreshGrid();
    } catch (e) {
      handleApiError(e);
    }
  }, [id, dateRange.start, dateRange.end, handleApiError, refreshGrid]);

  const getServerSideData = useCallback(
    async (params: IServerSideGetRowsParams) => {
      if (!id || !dateRange.start || !dateRange.end) {
        params.fail();
        return;
      }

      const groupKeys = params.request.groupKeys || [];

      // Level 0 — fetch from API and return terminal group rows
      if (groupKeys.length === 0) {
        params.api.setGridOption('loading', true);
        setLoading(true);
        setBerthRows([]);
        const { startRow } = params.request;

        const {
          selectedBerthTypes: currentBerthTypes,
          selectedTerminalNames: currentTerminalNames,
        } = filtersRef.current;
        const activeBerthTypes = getSelected(currentBerthTypes);
        const activeTerminalNames = getSelected(currentTerminalNames);

        try {
          const response = await getBerths(
            id,
            dateRange.start.split('T')[0],
            dateRange.end.split('T')[0],
            startRow,
            activeBerthTypes.length > 0
              ? activeBerthTypes.join(',')
              : undefined,
            activeTerminalNames.length > 0
              ? activeTerminalNames.join(',')
              : undefined,
          );

          cachedResponseRef.current = response;
          setBerthData(response);
          setIsExpanded(false);

          const allRows = response.terminals.flatMap((t) =>
            t.berths.map((b) => ({
              ...b,
              terminal_name: t.terminal_name,
            })),
          );
          setBerthRows(allRows);

          const terminalRows = response.terminals.map((t) => ({
            terminal_name: t.terminal_name,
            berth_count: t.berths.length,
          }));

          params.success({
            rowData: terminalRows,
            rowCount: terminalRows.length,
          });

          if (terminalRows.length === 0) params.api.showNoRowsOverlay();
          else params.api.hideOverlay();
        } catch (e) {
          setBerthData(undefined);
          params.success({ rowData: [], rowCount: 0 });
          setTimeout(() => {
            params.api.showNoRowsOverlay();
          }, 0);
          handleApiError(e);
        } finally {
          params.api.setGridOption('loading', false);
          setLoading(false);
        }
        return;
      }

      // Level 1 — return berths for the requested terminal from cache
      const terminalName = groupKeys[0];
      const cached = cachedResponseRef.current;

      if (!cached) {
        params.fail();
        return;
      }

      const terminal = cached.terminals.find(
        (t) => t.terminal_name === terminalName,
      );

      if (!terminal) {
        params.success({ rowData: [], rowCount: 0 });
        return;
      }

      const berths = terminal.berths.map((b) => ({
        ...b,
        terminal_name: terminal.terminal_name,
      }));

      params.success({
        rowData: berths,
        rowCount: berths.length,
      });
    },
    [id, dateRange.start, dateRange.end, handleApiError],
  );

  const handleBerthTypeToggle = useCallback(
    async (value: string, checked: boolean) => {
      const updated = { ...selectedBerthTypes, [value]: checked };
      setSelectedBerthTypes(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedBerthTypes: updated,
      };

      const activeBerthTypes = getSelected(updated);

      if (!id || !dateRange.start || !dateRange.end) return;

      // Always cross-filter: re-fetch terminal names based on current berth type selection
      try {
        const response = await getBerthFilters(
          id,
          activeBerthTypes.length > 0 ? activeBerthTypes.join(',') : undefined,
          undefined,
        );
        setTerminalNames(response.terminal_names);

        // Preserve existing selections that are still valid, select new ones by default
        const validNames = new Set(response.terminal_names || []);
        const updatedTerminals: Record<string, boolean> = {};
        for (const name of response.terminal_names || []) {
          updatedTerminals[name] =
            name in selectedTerminalNames ? selectedTerminalNames[name] : true;
        }
        // Remove selections that are no longer valid
        Object.keys(updatedTerminals).forEach((key) => {
          if (!validNames.has(key)) delete updatedTerminals[key];
        });

        setSelectedTerminalNames(updatedTerminals);
        filtersRef.current = {
          ...filtersRef.current,
          selectedTerminalNames: updatedTerminals,
        };
      } catch (e) {
        handleApiError(e);
      }

      debouncedRefreshGrid();
    },
    [
      selectedBerthTypes,
      selectedTerminalNames,
      id,
      dateRange.start,
      dateRange.end,
      handleApiError,
      debouncedRefreshGrid,
    ],
  );

  const handleTerminalNameToggle = useCallback(
    async (value: string, checked: boolean) => {
      const updated = { ...selectedTerminalNames, [value]: checked };
      setSelectedTerminalNames(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedTerminalNames: updated,
      };

      const activeTerminalNames = getSelected(updated);

      if (!id || !dateRange.start || !dateRange.end) return;

      // Always cross-filter: re-fetch berth types based on current terminal name selection
      try {
        const response = await getBerthFilters(
          id,
          undefined,
          activeTerminalNames.length > 0
            ? activeTerminalNames.join(',')
            : undefined,
        );
        setBerthTypes(response.berth_types);

        // Preserve existing selections that are still valid, select new ones by default
        const validTypes = new Set(response.berth_types || []);
        const updatedTypes: Record<string, boolean> = {};
        for (const type of response.berth_types || []) {
          updatedTypes[type] =
            type in selectedBerthTypes ? selectedBerthTypes[type] : true;
        }
        Object.keys(updatedTypes).forEach((key) => {
          if (!validTypes.has(key)) delete updatedTypes[key];
        });

        setSelectedBerthTypes(updatedTypes);
        filtersRef.current = {
          ...filtersRef.current,
          selectedBerthTypes: updatedTypes,
        };
      } catch (e) {
        handleApiError(e);
      }

      debouncedRefreshGrid();
    },
    [
      selectedTerminalNames,
      selectedBerthTypes,
      id,
      dateRange.start,
      dateRange.end,
      handleApiError,
      debouncedRefreshGrid,
    ],
  );

  const handleBerthTypeSelectAll = useCallback(
    async (checked: boolean) => {
      if (!berthTypes) return;
      const updated: Record<string, boolean> = Object.fromEntries(
        berthTypes.map((v) => [v, checked]),
      );
      setSelectedBerthTypes(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedBerthTypes: updated,
      };

      const activeBerthTypes = checked ? berthTypes : [];

      if (!id || !dateRange.start || !dateRange.end) return;

      // Always cross-filter
      try {
        const response = await getBerthFilters(
          id,
          activeBerthTypes.length > 0 ? activeBerthTypes.join(',') : undefined,
          undefined,
        );
        setTerminalNames(response.terminal_names);

        const validNames = new Set(response.terminal_names || []);
        const updatedTerminals: Record<string, boolean> = {};
        for (const name of response.terminal_names || []) {
          updatedTerminals[name] =
            name in selectedTerminalNames ? selectedTerminalNames[name] : true;
        }
        Object.keys(updatedTerminals).forEach((key) => {
          if (!validNames.has(key)) delete updatedTerminals[key];
        });

        setSelectedTerminalNames(updatedTerminals);
        filtersRef.current = {
          ...filtersRef.current,
          selectedTerminalNames: updatedTerminals,
        };
      } catch (e) {
        handleApiError(e);
      }

      debouncedRefreshGrid();
    },
    [
      berthTypes,
      selectedTerminalNames,
      id,
      dateRange.start,
      dateRange.end,
      handleApiError,
      debouncedRefreshGrid,
    ],
  );

  const handleTerminalNameSelectAll = useCallback(
    async (checked: boolean) => {
      if (!terminalNames) return;
      const updated: Record<string, boolean> = Object.fromEntries(
        terminalNames.map((v) => [v, checked]),
      );
      setSelectedTerminalNames(updated);
      filtersRef.current = {
        ...filtersRef.current,
        selectedTerminalNames: updated,
      };

      const activeTerminalNames = checked ? terminalNames : [];

      if (!id || !dateRange.start || !dateRange.end) return;

      // Always cross-filter
      try {
        const response = await getBerthFilters(
          id,
          undefined,
          activeTerminalNames.length > 0
            ? activeTerminalNames.join(',')
            : undefined,
        );
        setBerthTypes(response.berth_types);

        const validTypes = new Set(response.berth_types || []);
        const updatedTypes: Record<string, boolean> = {};
        for (const type of response.berth_types || []) {
          updatedTypes[type] =
            type in selectedBerthTypes ? selectedBerthTypes[type] : true;
        }
        Object.keys(updatedTypes).forEach((key) => {
          if (!validTypes.has(key)) delete updatedTypes[key];
        });

        setSelectedBerthTypes(updatedTypes);
        filtersRef.current = {
          ...filtersRef.current,
          selectedBerthTypes: updatedTypes,
        };
      } catch (e) {
        handleApiError(e);
      }

      debouncedRefreshGrid();
    },
    [
      terminalNames,
      selectedBerthTypes,
      id,
      dateRange.start,
      dateRange.end,
      handleApiError,
      debouncedRefreshGrid,
    ],
  );

  const resetFilters = useCallback(async () => {
    setSelectedBerthTypes({});
    setSelectedTerminalNames({});
    filtersRef.current = {
      selectedBerthTypes: {},
      selectedTerminalNames: {},
    };

    if (!id) return;
    try {
      const response = await getBerthFilters(id);
      setBerthTypes(response.berth_types);
      setTerminalNames(response.terminal_names);
    } catch (e) {
      handleApiError(e);
    }

    refreshGrid();
  }, [id, handleApiError, refreshGrid]);

  const getBerthCSVContent = useCallback((): string => {
    return getCSVContent(berthRows);
  }, [berthRows]);

  useEffect(() => {
    if (!id) return;
    fetchInitialFilters();
  }, [id, fetchInitialFilters]);

  const activeBerthTypes = getSelected(selectedBerthTypes);
  const activeTerminalNames = getSelected(selectedTerminalNames);

  return {
    dateRange,
    fetchInitialFilters,
    setDateRange,
    berthRows,
    berthData,
    handleBerthTypeToggle,
    handleTerminalNameToggle,
    berthTypes,
    terminalNames,
    selectedBerthTypes,
    selectedTerminalNames,
    handleBerthTypeSelectAll,
    handleTerminalNameSelectAll,
    getBerthCSVContent,
    getServerSideData,
    gridRef,
    activeBerthTypes,
    activeTerminalNames,
    resetFilters,
    loading,
    id,
    selectedBerthId,
    setSelectedBerthId,
    selectedBerthName,
    setSelectedBerthName,
    isExpanded,
    setIsExpanded,
  };
}
