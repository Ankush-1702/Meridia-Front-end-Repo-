import { InboundVessel } from '../types/inboundVessels';
import {
  BerthEvents,
  FlatPortEventsResponse,
  PortEvents,
  PortEventType,
} from '../types/portTypes';
import { logger } from '@/shared/utils/logger';

export const getSelected = (record: Record<string, boolean>): string[] =>
  Object.entries(record)
    .filter(([, v]) => v)
    .map(([k]) => k);

export function flattenPortEvent(event: PortEvents): FlatPortEventsResponse {
  return {
    vesselName: event?.vessel_information?.name ?? '',
    callSign: event?.vessel_information?.callsign ?? '',
    flag: event?.vessel_information?.flag ?? '',
    flagCode: event?.vessel_information?.flag_code ?? '',
    imo: event?.vessel_information?.imo ?? '',
    mmsi: event?.vessel_information?.mmsi ?? '',
    vesselType: event?.vessel_information?.vessel_type ?? '',
    berthName: '',
    berthId: '',
    portId: '',
    course: event?.event_details?.course ?? 0,
    draught: event?.event_details?.draught ?? 0,
    eventId: event?.event_details?.event_id ?? '',
    eventTimestamp: event?.event_details?.event_timestamp ?? '',
    eventType: event?.event_details?.event_type ?? '',
    heading: event?.event_details?.heading ?? 0,
    latitude: event?.event_details?.latitude ?? 0,
    longitude: event?.event_details?.longitude ?? 0,
    navigationalStatusStatus:
      event?.event_details?.navigational_status?.status ?? '',
    navigationalStatusCode:
      event?.event_details?.navigational_status?.code ?? 0,
    reportedDestination: event?.event_details?.reported_destination ?? '',
    reportedEta: event?.event_details?.reported_eta ?? '',
    speed: event?.event_details?.speed ?? 0,
  };
}

export function flattenBerthEvent(event: BerthEvents): FlatPortEventsResponse {
  return {
    ...flattenPortEvent(event),
    berthName: event?.berth_information?.name ?? '',
    berthId: event?.berth_information?.id ?? '',
    portId: event?.berth_information?.port_id ?? '',
  };
}

export function flattenInboundVessel(
  event: InboundVessel,
): FlatPortEventsResponse {
  return {
    vesselName: event?.vessel_information?.name ?? '',
    callSign: event?.vessel_information?.callsign ?? '',
    flag: event?.vessel_information?.flag ?? '',
    flagCode: event?.vessel_information?.flag_code ?? '',
    imo: event?.vessel_information?.imo ?? '',
    mmsi: event?.vessel_information?.mmsi ?? '',
    vesselType: event?.vessel_information?.vessel_type ?? '',
    berthName: '',
    berthId: '',
    portId: '',
    course: event?.latest_position?.course ?? 0,
    draught: event?.latest_position?.draught ?? 0,
    eventId: '',
    eventTimestamp: event?.latest_position?.timestamp ?? '',
    eventType: 'INBOUND' as Exclude<PortEventType, ''>,
    heading: event?.latest_position?.heading ?? 0,
    latitude: event?.latest_position?.latitude ?? 0,
    longitude: event?.latest_position?.longitude ?? 0,
    navigationalStatusStatus: String(
      event?.latest_position?.navigational_status?.status ?? '',
    ),
    navigationalStatusCode:
      event?.latest_position?.navigational_status?.code ?? 0,
    reportedDestination: event?.reported_destination?.raw ?? '',
    reportedEta: event?.reported_eta ?? '',
    speed: event?.latest_position?.speed ?? 0,
    lastUpdate: event?.latest_position?.timestamp ?? '',
  };
}

export function flattenPortEvents(
  events: PortEvents[],
): FlatPortEventsResponse[] {
  return events.flatMap((event) => {
    try {
      return [flattenPortEvent(event)];
    } catch (error) {
      logger.warn('Skipping port event that could not be flattened', {
        eventId: event?.event_details?.event_id,
        eventType: event?.event_details?.event_type,
        error,
      });
      return [];
    }
  });
}

export function flattenBerthEvents(
  events: BerthEvents[],
): FlatPortEventsResponse[] {
  return events.flatMap((event) => {
    try {
      return [flattenBerthEvent(event)];
    } catch (error) {
      logger.warn('Skipping berth event that could not be flattened', {
        eventId: event?.event_details?.event_id,
        eventType: event?.event_details?.event_type,
        error,
      });
      return [];
    }
  });
}

export function flattenInboundVessels(
  events: InboundVessel[],
): FlatPortEventsResponse[] {
  return events.flatMap((event) => {
    try {
      return [flattenInboundVessel(event)];
    } catch (error) {
      logger.warn('Skipping inbound vessel that could not be flattened', {
        imo: event?.vessel_information?.imo,
        timestamp: event?.latest_position?.timestamp,
        error,
      });
      return [];
    }
  });
}
