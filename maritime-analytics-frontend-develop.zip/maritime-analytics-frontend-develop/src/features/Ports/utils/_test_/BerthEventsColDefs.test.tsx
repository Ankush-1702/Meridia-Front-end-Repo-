import { createBerthEventsColDef } from '../BerthEventsColDefs';

describe('createBerthEventsColDef', () => {
  describe('column count and structure', () => {
    it('should return 19 column definitions', () => {
      const cols = createBerthEventsColDef('utc');
      expect(cols).toHaveLength(19);
    });

    it('should have all columns unsortable', () => {
      const cols = createBerthEventsColDef('utc');
      cols.forEach((col) => {
        expect(col.sortable).toBe(false);
      });
    });

    it('should set flex to 1 on all columns', () => {
      const cols = createBerthEventsColDef('utc');
      cols.forEach((col) => {
        expect(col.flex).toBe(1);
      });
    });
  });

  describe('visible columns', () => {
    const visibleHeaders = [
      'TimeStamp (UTC)',
      'Berth Name',
      'Event',
      'Vessel',
      'IMO',
      'Type',
      'Flag',
    ];

    it('should have the first 7 columns visible (no hide property)', () => {
      const cols = createBerthEventsColDef('utc');
      const visible = cols.filter((col) => !col.hide);
      expect(visible).toHaveLength(7);
      expect(visible.map((c) => c.headerName)).toEqual(visibleHeaders);
    });

    it('should mark visible columns as lockVisible', () => {
      const cols = createBerthEventsColDef('utc');
      const visible = cols.filter((col) => !col.hide);
      visible.forEach((col) => {
        expect(col.lockVisible).toBe(true);
      });
    });
  });

  describe('hidden columns', () => {
    const hiddenHeaders = [
      'Call Sign',
      'Course',
      'MMSI',
      'Draught',
      'Heading',
      'Latitude',
      'Longitude',
      'Navigational Status (status)',
      'Navigational Status (code)',
      'Reported Destination',
      'Reported ETA',
      'Speed',
    ];

    it('should have 12 hidden columns', () => {
      const cols = createBerthEventsColDef('utc');
      const hidden = cols.filter((col) => col.hide);
      expect(hidden).toHaveLength(12);
      expect(hidden.map((c) => c.headerName)).toEqual(hiddenHeaders);
    });
  });

  describe('timestamp header based on timezone setting', () => {
    it('should show "TimeStamp (UTC)" when timeZoneSetting is "utc"', () => {
      const cols = createBerthEventsColDef('utc');
      expect(cols[0].headerName).toBe('TimeStamp (UTC)');
    });

    it('should show "TimeStamp (System)" when timeZoneSetting is "system"', () => {
      const cols = createBerthEventsColDef('system');
      expect(cols[0].headerName).toBe('TimeStamp (System)');
    });

    it('should show "TimeStamp (System)" for any non-utc value', () => {
      const cols = createBerthEventsColDef('local');
      expect(cols[0].headerName).toBe('TimeStamp (System)');
    });
  });

  describe('field mappings', () => {
    it('should map timestamp to event_details.event_timestamp', () => {
      const cols = createBerthEventsColDef('utc');
      expect(cols[0].field).toBe('event_details.event_timestamp');
    });

    it('should map Berth Name to berth_information.name', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Berth Name');
      expect(col?.field).toBe('berth_information.name');
    });

    it('should map Event to event_details.event_type', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Event');
      expect(col?.field).toBe('event_details.event_type');
    });

    it('should map Vessel to vessel_information.name', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Vessel');
      expect(col?.field).toBe('vessel_information.name');
    });

    it('should map IMO to vessel_information.imo', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'IMO');
      expect(col?.field).toBe('vessel_information.imo');
    });

    it('should map Speed to event_details.speed', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Speed');
      expect(col?.field).toBe('event_details.speed');
    });
  });

  describe('tooltipField mappings', () => {
    it('should set tooltipField equal to field for simple columns', () => {
      const cols = createBerthEventsColDef('utc');
      const simpleColumns = cols.filter(
        (c) => c.headerName !== 'Event' && c.tooltipField,
      );
      simpleColumns.forEach((col) => {
        expect(col.tooltipField).toBe(col.field);
      });
    });

    it('should use tooltipValueGetter for Event column instead of tooltipField', () => {
      const cols = createBerthEventsColDef('utc');
      const eventCol = cols.find((c) => c.headerName === 'Event');
      expect(eventCol?.tooltipField).toBeUndefined();
      expect(eventCol?.tooltipValueGetter).toBeDefined();
    });
  });

  describe('navigational status columns', () => {
    it('should have width of 500 for both navigational status columns', () => {
      const cols = createBerthEventsColDef('utc');
      const navCols = cols.filter((c) =>
        c.headerName?.startsWith('Navigational Status'),
      );
      expect(navCols).toHaveLength(2);
      navCols.forEach((col) => {
        expect(col.width).toBe(500);
      });
    });
  });

  describe('cell renderers', () => {
    it('should have cellRenderer on timestamp column', () => {
      const cols = createBerthEventsColDef('utc');
      expect(cols[0].cellRenderer).toBeDefined();
    });

    it('should have cellRenderer on Event column', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Event');
      expect(col?.cellRenderer).toBeDefined();
    });

    it('should have cellRenderer on Vessel column', () => {
      const cols = createBerthEventsColDef('utc');
      const col = cols.find((c) => c.headerName === 'Vessel');
      expect(col?.cellRenderer).toBeDefined();
    });

    it('should have cellRenderer on hidden detail columns', () => {
      const cols = createBerthEventsColDef('utc');
      const detailHeaders = [
        'Course',
        'Draught',
        'Heading',
        'Latitude',
        'Longitude',
        'Speed',
        'Reported Destination',
        'Reported ETA',
        'Navigational Status (status)',
        'Navigational Status (code)',
      ];
      detailHeaders.forEach((header) => {
        const col = cols.find((c) => c.headerName === header);
        expect(col?.cellRenderer).toBeDefined();
      });
    });

    it('should NOT have cellRenderer on Berth Name, IMO, Type, Flag, Call Sign, MMSI', () => {
      const cols = createBerthEventsColDef('utc');
      const noRendererHeaders = [
        'Berth Name',
        'IMO',
        'Type',
        'Flag',
        'Call Sign',
        'MMSI',
      ];
      noRendererHeaders.forEach((header) => {
        const col = cols.find((c) => c.headerName === header);
        expect(col?.cellRenderer).toBeUndefined();
      });
    });
  });
});
