import { describe, it, expect } from 'vitest';
import {
  mapPortData,
  mapPortsResponse,
  extractCategories,
  getCategories,
} from '@/features/Ports/utils/wpiDataMapping';

/* ------------------------------------------------------------------ */
/* test-only helper types (NO any)                                     */
/* ------------------------------------------------------------------ */

interface ExtractedCategory {
  categoryName: string;
  items: unknown[];
}

type ExtractedCategoriesObject = Record<string, unknown[]>;

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('WPI data mappers', () => {
  it('maps basic port data into categories and summary', () => {
    const result = mapPortData({
      portName: 'Test Port',
      countryName: 'Test Country',
      portNumber: '123',
      harborSize: 'M',
    });

    expect(result.summary).toEqual({
      portName: 'Test Port',
      countryName: 'Test Country',
      portNumber: '123',
    });

    expect(result.categories['Harbor Characteristics']).toBeDefined();
  });

  it('maps value codes correctly', () => {
    const result = mapPortData({
      harborSize: 'L',
    });

    const harborCategory = result.categories['Harbor Characteristics'];
    expect(harborCategory[0].value).toBe('Large');
  });

  it('falls back to "Not Available" for null values', () => {
    const result = mapPortData({
      harborSize: null,
    });

    const harborCategory = result.categories['Harbor Characteristics'];
    expect(harborCategory[0].value).toBe('Not Available');
  });

  it('returns empty array for invalid ports response', () => {
    expect(mapPortsResponse(null)).toEqual([]);
    expect(mapPortsResponse({})).toEqual([]);
    expect(
      mapPortsResponse({ ports: 'invalid' } as unknown as Parameters<
        typeof mapPortsResponse
      >[0]),
    ).toEqual([]);
  });

  it('maps multiple ports from API response', () => {
    const result = mapPortsResponse({
      ports: [
        { portName: 'Port A', countryName: 'A', portNumber: '1' },
        { portName: 'Port B', countryName: 'B', portNumber: '2' },
      ],
    });

    expect(result).toHaveLength(2);
    expect(result[0].summary.portName).toBe('Port A');
    expect(result[1].summary.portName).toBe('Port B');
  });

  it('returns category names when extractCategories format is "names"', () => {
    const mapped = mapPortData({
      harborSize: 'M',
    });

    const result = extractCategories(mapped, 'names');

    expect(Array.isArray(result)).toBe(true);
    expect(result).toContain('Harbor Characteristics');
  });

  it('returns array format for extractCategories', () => {
    const mapped = mapPortData({
      harborSize: 'M',
      portName: 'Test Port',
    });

    const result = extractCategories(mapped, 'array');

    expect(Array.isArray(result)).toBe(true);

    if (Array.isArray(result)) {
      const categories = result as ExtractedCategory[];

      expect(categories.length).toBeGreaterThan(0);
      expect(categories[0]).toHaveProperty('categoryName');
      expect(Array.isArray(categories[0].items)).toBe(true);
    }
  });

  it('returns default object format for extractCategories', () => {
    const mapped = mapPortData({
      harborSize: 'M',
    });

    const result = extractCategories(mapped);

    expect(typeof result).toBe('object');
    expect(result).not.toBeNull();

    if (typeof result === 'object' && result !== null) {
      const categories = result as ExtractedCategoriesObject;

      expect(categories['Harbor Characteristics']).toBeDefined();
      expect(Array.isArray(categories['Harbor Characteristics'])).toBe(true);
    }
  });

  it('returns sorted category list from getCategories', () => {
    const categories = getCategories();

    expect(Array.isArray(categories)).toBe(true);
    expect(categories.length).toBeGreaterThan(0);
    expect(categories).toContain('Basic Port Information');
  });
});
