import { describe, it, expect, vi } from 'vitest';
import { createInboundVesselsColDefs } from '@/features/Ports/utils/inboundVesselsColDefs';
import {
  formatUTCDate,
  formatUTCDateTime,
} from '@/features/Ports/utils/inboundVesselsUtils';

vi.mock('@/features/Ports/utils/inboundVesselsUtils', () => ({
  formatUTCDate: vi.fn((val) => `formatted-date:${val}`),
  formatUTCDateTime: vi.fn((val) => `formatted-datetime:${val}`),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode: string }) => `FlagIcon:${flagCode}`,
}));

describe('createInboundVesselsColDefs', () => {
  const colDefs = createInboundVesselsColDefs();

  it('should return an array of column definitions', () => {
    expect(Array.isArray(colDefs)).toBe(true);
    expect(colDefs.length).toBeGreaterThan(0);
  });

  it('should have correct fields defined', () => {
    const fields = colDefs.map((col) => col.field);
    expect(fields).toContain('vesselName');
    expect(fields).toContain('imo');
    expect(fields).toContain('mmsi');
    expect(fields).toContain('vesselType');
    expect(fields).toContain('flag');
    expect(fields).toContain('latitude');
    expect(fields).toContain('longitude');
    expect(fields).toContain('speed');
    expect(fields).toContain('lastUpdate');
  });

  it('should have all columns non-sortable and non-filterable', () => {
    colDefs.forEach((col) => {
      expect(col.sortable).toBe(false);
      expect(col.filter).toBe(false);
    });
  });

  describe('vesselName column', () => {
    const vesselCol = colDefs.find((c) => c.field === 'vesselName')!;

    it('should have cellRenderer defined', () => {
      expect(vesselCol.cellRenderer).toBeDefined();
    });
  });

  describe('reportedEta column', () => {
    const etaCol = colDefs.find((c) => c.field === 'reportedEta')!;

    it('should use formatUTCDate valueFormatter', () => {
      const result =
        typeof etaCol.valueFormatter === 'function'
          ? etaCol.valueFormatter({ value: '2026-03-09' } as never)
          : etaCol.valueFormatter;
      expect(result).toBe('formatted-date:2026-03-09');
      expect(formatUTCDate).toHaveBeenCalledWith('2026-03-09');
    });
  });

  describe('lastUpdate column', () => {
    const lastUpdateCol = colDefs.find((c) => c.field === 'lastUpdate')!;

    it('should use formatUTCDateTime valueFormatter', () => {
      const result =
        typeof lastUpdateCol.valueFormatter === 'function'
          ? lastUpdateCol.valueFormatter({
              value: '2026-03-09T10:00:00Z',
            } as never)
          : lastUpdateCol.valueFormatter;
      expect(result).toBe('formatted-datetime:2026-03-09T10:00:00Z');
      expect(formatUTCDateTime).toHaveBeenCalledWith('2026-03-09T10:00:00Z');
    });

    it('should be hidden by default', () => {
      expect(lastUpdateCol.hide).toBe(true);
    });
  });

  describe('numeric columns with toFixed formatter', () => {
    const numericFields = [
      'latitude',
      'longitude',
      'course',
      'speed',
      'heading',
      'draught',
    ];

    numericFields.forEach((field) => {
      const col = colDefs.find((c) => c.field === field)!;

      it(`${field} should format number with toFixed`, () => {
        const result =
          typeof col.valueFormatter === 'function'
            ? col.valueFormatter({ value: 12.3456 } as never)
            : col.valueFormatter;
        expect(result).toMatch(/12\.34|12\.3/);
      });

      it(`${field} should return '-' for null/undefined`, () => {
        expect(
          typeof col.valueFormatter === 'function'
            ? col.valueFormatter({ value: null } as never)
            : col.valueFormatter,
        ).toBe('-');
        expect(
          typeof col.valueFormatter === 'function'
            ? col.valueFormatter({ value: undefined } as never)
            : col.valueFormatter,
        ).toBe('-');
      });
    });
  });

  describe('hidden columns', () => {
    const hiddenFields = [
      'mmsi',
      'callsign',
      'reportedDestination',
      'latitude',
      'longitude',
      'course',
      'speed',
      'heading',
      'draught',
      'navigationalStatus',
      'lastUpdate',
    ];

    hiddenFields.forEach((field) => {
      it(`${field} should be hidden by default`, () => {
        const col = colDefs.find((c) => c.field === field);
        expect(col?.hide).toBe(true);
      });
    });
  });

  describe('visible columns', () => {
    const visibleFields = [
      'vesselName',
      'imo',
      'vesselType',
      'flag',
      'reportedEta',
    ];

    visibleFields.forEach((field) => {
      it(`${field} should be visible by default`, () => {
        const col = colDefs.find((c) => c.field === field);
        expect(col?.hide).not.toBe(true);
      });
    });
  });
  describe('lockVisible columns', () => {
    const lockVisibleFields = [
      'vesselName',
      'imo',
      'vesselType',
      'flag',
      'reportedEta',
    ];

    lockVisibleFields.forEach((field) => {
      it(`${field} should have lockVisible set to true`, () => {
        const col = colDefs.find((c) => c.field === field);
        expect(col?.lockVisible).toBe(true);
      });

      it(`${field} should not be hidden by default`, () => {
        const col = colDefs.find((c) => c.field === field);
        expect(col?.hide).not.toBe(true);
      });
    });
  });
});
