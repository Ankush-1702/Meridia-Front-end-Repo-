import { describe, it, expect } from 'vitest';
import {
  getSelected,
  flattenPortEvent,
  flattenBerthEvent,
  flattenInboundVessel,
  flattenPortEvents,
  flattenBerthEvents,
  flattenInboundVessels,
} from '../portUtils';
import type { InboundVessel } from '@/features/Ports/types/inboundVessels';
import type { BerthEvents, PortEvents } from '@/features/Ports/types/portTypes';

/* ------------------------------------------------------------------ */
/* fixtures                                                            */
/* ------------------------------------------------------------------ */

const portEvent: PortEvents = {
  vessel_information: {
    asset_id: 'asset-1',
    callsign: 'ABC123',
    flag: 'Singapore',
    flag_code: 'SG',
    imo: '1234567',
    mmsi: '123456789',
    name: 'Evergreen',
    vessel_type: 'Cargo',
  },
  event_details: {
    course: 45,
    draught: 10.5,
    event_id: 'event-1',
    event_timestamp: '2024-01-01T00:00:00Z',
    event_type: 'PORT_ARRIVAL',
    heading: 90,
    latitude: 1.3,
    longitude: 103.8,
    navigational_status: {
      status: 'Under way using engine',
      code: 0,
    },
    reported_destination: 'SGSIN',
    reported_eta: '2024-01-02T00:00:00Z',
    speed: 12.5,
  },
};

const berthEvent: BerthEvents = {
  ...portEvent,
  berth_information: {
    id: 'berth-1',
    name: 'Berth A',
    port_id: 'port-1',
  },
};

const inboundVessel: InboundVessel = {
  vessel_information: {
    asset_id: 'asset-2',
    callsign: 'XYZ789',
    flag: 'Panama',
    flag_code: 'PA',
    imo: '7654321',
    mmsi: '987654321',
    name: 'Pacific Star',
    vessel_type: 'Tanker',
  },
  reported_destination: {
    id: 'dest-1',
    name: 'Singapore',
    raw: 'SGSIN',
    reported_at: '2024-01-01T00:00:00Z',
    unlocode: 'SGSIN',
  },
  reported_eta: '2024-01-03T00:00:00Z',
  latest_position: {
    latitude: 2.1,
    longitude: 104.2,
    course: 180,
    speed: 8.4,
    heading: 175,
    draught: 9.1,
    navigational_status: {
      code: 1,
      status: 5,
    },
    timestamp: '2024-01-01T12:00:00Z',
  },
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('getSelected', () => {
  it('returns keys with truthy values', () => {
    expect(
      getSelected({ ALL: true, INBOUND: false, PORT_ARRIVAL: true }),
    ).toEqual(['ALL', 'PORT_ARRIVAL']);
  });

  it('returns an empty array when nothing is selected', () => {
    expect(getSelected({ ALL: false, INBOUND: false })).toEqual([]);
  });

  it('returns an empty array for an empty record', () => {
    expect(getSelected({})).toEqual([]);
  });
});

describe('flattenPortEvent', () => {
  it('flattens a port event into a FlatPortEventsResponse', () => {
    expect(flattenPortEvent(portEvent)).toEqual({
      vesselName: 'Evergreen',
      callSign: 'ABC123',
      flag: 'Singapore',
      flagCode: 'SG',
      imo: '1234567',
      mmsi: '123456789',
      vesselType: 'Cargo',
      berthName: '',
      berthId: '',
      portId: '',
      course: 45,
      draught: 10.5,
      eventId: 'event-1',
      eventTimestamp: '2024-01-01T00:00:00Z',
      eventType: 'PORT_ARRIVAL',
      heading: 90,
      latitude: 1.3,
      longitude: 103.8,
      navigationalStatusStatus: 'Under way using engine',
      navigationalStatusCode: 0,
      reportedDestination: 'SGSIN',
      reportedEta: '2024-01-02T00:00:00Z',
      speed: 12.5,
    });
  });
});

describe('flattenBerthEvent', () => {
  it('flattens a berth event, including berth-specific fields', () => {
    const result = flattenBerthEvent(berthEvent);

    expect(result.berthName).toBe('Berth A');
    expect(result.berthId).toBe('berth-1');
    expect(result.portId).toBe('port-1');
    expect(result.vesselName).toBe('Evergreen');
    expect(result.eventType).toBe('PORT_ARRIVAL');
  });
});

describe('flattenInboundVessel', () => {
  it('flattens an inbound vessel with eventType INBOUND', () => {
    const result = flattenInboundVessel(inboundVessel);

    expect(result).toEqual({
      vesselName: 'Pacific Star',
      callSign: 'XYZ789',
      flag: 'Panama',
      flagCode: 'PA',
      imo: '7654321',
      mmsi: '987654321',
      vesselType: 'Tanker',
      berthName: '',
      berthId: '',
      portId: '',
      course: 180,
      draught: 9.1,
      eventId: '',
      eventTimestamp: '2024-01-01T12:00:00Z',
      eventType: 'INBOUND',
      lastUpdate: '2024-01-01T12:00:00Z',
      heading: 175,
      latitude: 2.1,
      longitude: 104.2,
      navigationalStatusStatus: '5',
      navigationalStatusCode: 1,
      reportedDestination: 'SGSIN',
      reportedEta: '2024-01-03T00:00:00Z',
      speed: 8.4,
    });
  });

  it('fills missing reported destination and ETA with empty strings', () => {
    const vesselWithoutDestination: InboundVessel = {
      ...inboundVessel,
      reported_destination:
        undefined as unknown as InboundVessel['reported_destination'],
      reported_eta: null,
    };

    const result = flattenInboundVessel(vesselWithoutDestination);

    expect(result.reportedDestination).toBe('');
    expect(result.reportedEta).toBe('');
  });
});

describe('flattenPortEvents', () => {
  it('maps an array of port events', () => {
    const result = flattenPortEvents([portEvent, portEvent]);
    expect(result).toHaveLength(2);
    expect(result[0].vesselName).toBe('Evergreen');
  });

  it('returns an empty array for an empty input', () => {
    expect(flattenPortEvents([])).toEqual([]);
  });

  it('fills missing event values with empty values of the matching type', () => {
    const [result] = flattenPortEvents([{} as PortEvents]);

    expect(result.vesselName).toBe('');
    expect(result.eventId).toBe('');
    expect(result.eventType).toBe('');
    expect(result.course).toBe(0);
    expect(result.navigationalStatusStatus).toBe('');
    expect(result.navigationalStatusCode).toBe(0);
  });
});

describe('flattenBerthEvents', () => {
  it('maps an array of berth events', () => {
    const result = flattenBerthEvents([berthEvent]);
    expect(result).toHaveLength(1);
    expect(result[0].berthName).toBe('Berth A');
  });

  it('returns an empty array for an empty input', () => {
    expect(flattenBerthEvents([])).toEqual([]);
  });

  it('fills missing berth values with empty strings', () => {
    const [result] = flattenBerthEvents([{} as BerthEvents]);

    expect(result.berthName).toBe('');
    expect(result.berthId).toBe('');
    expect(result.portId).toBe('');
  });
});

describe('flattenInboundVessels', () => {
  it('maps an array of inbound vessels', () => {
    const result = flattenInboundVessels([inboundVessel]);
    expect(result).toHaveLength(1);
    expect(result[0].eventType).toBe('INBOUND');
  });

  it('returns an empty array for an empty input', () => {
    expect(flattenInboundVessels([])).toEqual([]);
  });

  it('fills missing inbound values with empty values of the matching type', () => {
    const [result] = flattenInboundVessels([{} as InboundVessel]);

    expect(result.vesselName).toBe('');
    expect(result.reportedDestination).toBe('');
    expect(result.reportedEta).toBe('');
    expect(result.course).toBe(0);
    expect(result.navigationalStatusStatus).toBe('');
    expect(result.navigationalStatusCode).toBe(0);
  });
});
