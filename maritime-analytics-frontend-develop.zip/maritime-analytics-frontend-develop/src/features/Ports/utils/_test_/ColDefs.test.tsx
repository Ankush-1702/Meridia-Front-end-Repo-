import type { ColDef } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi } from 'vitest';
import { createPortEventsColDef } from '../ColDefs';
import type { PortEvents } from '@/features/Ports/types/portTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: vi.fn(
    (v: string | null) => `UTC:${v}`,
  ),
  convertUTCToLocalTime: vi.fn((v: string | null) => `LOCAL:${v}`),
  toTitleCase: vi.fn((v: string) => `Title:${v}`),
  getEventLabel: vi.fn((v: string) => `EventLabel:${v}`),
}));

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => status,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode?: string }) => flagCode ?? 'NO_FLAG',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function renderCell(
  renderer: (p: CustomCellRendererProps) => JSX.Element,
  value: unknown,
  data?: Partial<PortEvents>,
) {
  const el = renderer({
    value,
    data,
  } as CustomCellRendererProps);

  return el.props.children;
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('createPortEventsColDef', () => {
  it('returns column definitions', () => {
    const cols = createPortEventsColDef('utc');
    expect(Array.isArray(cols)).toBe(true);
    expect(cols.length).toBeGreaterThan(10);
  });

  it('renders UTC timestamp when timezone is utc', () => {
    const cols = createPortEventsColDef('utc');
    const col = cols[0] as ColDef<PortEvents>;

    const content = renderCell(col.cellRenderer!, '2024-01-01T00:00:00Z');

    expect(content).toBe('UTC:2024-01-01T00:00:00Z');
  });

  it('renders local timestamp when timezone is system', () => {
    const cols = createPortEventsColDef('system');
    const col = cols[0] as ColDef<PortEvents>;

    const content = renderCell(col.cellRenderer!, '2024-01-01T00:00:00Z');

    expect(content).toBe('LOCAL:2024-01-01T00:00:00Z');
  });

  it('formats event tooltip correctly', () => {
    const cols = createPortEventsColDef('utc');
    const eventCol = cols.find((c) => c.field === 'event_details.event_type')!;

    const tooltip = eventCol.tooltipValueGetter?.({
      value: 'PORT_AREA_ARRIVAL',
    } as never);

    expect(tooltip).toBe('EventLabel:PORT_AREA_ARRIVAL');
  });

  it('formats berth event tooltip distinctly', () => {
    const cols = createPortEventsColDef('utc');
    const eventCol = cols.find((c) => c.field === 'event_details.event_type')!;

    const tooltip = eventCol.tooltipValueGetter?.({
      value: 'BERTH_ARRIVAL',
    } as never);

    expect(tooltip).toBe('EventLabel:BERTH_ARRIVAL');
  });

  it('renders vessel name with flag', () => {
    const cols = createPortEventsColDef('utc');
    const vesselCol = cols.find((c) => c.field === 'vessel_information.name')!;

    const children = renderCell(vesselCol.cellRenderer!, 'Evergreen', {
      vessel_information: {
        name: 'Evergreen',
        flag_code: 'SG',
        asset_id: '123',
        callsign: 'ABC',
        flag: 'SG',
        imo: '1233455',
        mmsi: '123456789',
        vessel_type: 'cargo',
      },
    });

    // children is an array of React elements
    expect(Array.isArray(children)).toBe(true);
    expect(children).toHaveLength(2);

    const [flagEl, nameEl] = children;

    // FlagIcon mock returns the component itself
    expect(flagEl.props.flagCode).toBe('SG');

    // Span text
    expect(nameEl.props.children).toBe('Evergreen');
  });

  it('renders dash for empty numeric fields', () => {
    const cols = createPortEventsColDef('utc');

    const numericFields = [
      'event_details.course',
      'event_details.draught',
      'event_details.heading',
      'event_details.latitude',
      'event_details.longitude',
      'event_details.speed',
    ];

    for (const field of numericFields) {
      const col = cols.find((c) => c.field === field);
      if (!col?.cellRenderer) continue;

      const content = renderCell(col.cellRenderer, null);
      expect(content).toBe('-');
    }
  });

  it('renders dash for missing navigational status', () => {
    const cols = createPortEventsColDef('utc');

    const statusCol = cols.find(
      (c) => c.field === 'event_details.navigational_status.status',
    )!;

    const codeCol = cols.find(
      (c) => c.field === 'event_details.navigational_status.code',
    )!;

    expect(renderCell(statusCol.cellRenderer!, null)).toBe('-');
    expect(renderCell(codeCol.cellRenderer!, null)).toBe('-');
  });
});
