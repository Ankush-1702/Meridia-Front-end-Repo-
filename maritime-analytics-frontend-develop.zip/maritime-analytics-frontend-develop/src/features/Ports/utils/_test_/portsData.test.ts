import { describe, it, expect } from 'vitest';
import { getData } from '@/features/Ports/utils/portsData';

describe('getData', () => {
  it('returns an array', () => {
    const data = getData();
    expect(Array.isArray(data)).toBe(true);
  });

  it('returns 12 months of data', () => {
    const data = getData();
    expect(data).toHaveLength(12);
  });

  it('contains expected month order', () => {
    const data = getData();
    const months = data.map((d) => d.month);

    expect(months).toEqual([
      'Jan',
      'Feb',
      'March',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ]);
  });

  it('has consistent year value', () => {
    const data = getData();
    data.forEach((item) => {
      expect(item.year).toBe('2025');
    });
  });

  it('contains required numeric fields', () => {
    const data = getData();

    data.forEach((item) => {
      expect(typeof item['Oil Tanker']).toBe('number');
      expect(typeof item.cargo).toBe('number');
      expect(typeof item.other).toBe('number');
      expect(typeof item.prevYearTotal).toBe('number');
    });
  });

  it('does not return the same reference on multiple calls', () => {
    const data1 = getData();
    const data2 = getData();

    expect(data1).not.toBe(data2);
    expect(data1).toEqual(data2);
  });

  it('contains positive values only', () => {
    const data = getData();

    data.forEach((item) => {
      expect(item['Oil Tanker']).toBeGreaterThanOrEqual(0);
      expect(item.cargo).toBeGreaterThanOrEqual(0);
      expect(item.other).toBeGreaterThanOrEqual(0);
      expect(item.prevYearTotal).toBeGreaterThanOrEqual(0);
    });
  });
});
