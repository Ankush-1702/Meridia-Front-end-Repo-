import type { ColDef } from 'ag-grid-enterprise';
import type { CustomCellRendererProps } from 'ag-grid-react';
import { describe, it, expect, vi } from 'vitest';
import { CreateUnifiedPortEventsColDefs } from '../CombinedColDefs';
import type { FlatPortEventsResponse } from '@/features/Ports/types/portTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: vi.fn((v: string | null) =>
    v ? `UTC:${v}` : '',
  ),
  convertUTCToLocalTime: vi.fn((v: string | null) => (v ? `LOCAL:${v}` : '')),
  getEventLabel: vi.fn((v: string) => `EventLabel:${v}`),
}));

vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => status,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode?: string }) => flagCode ?? 'NO_FLAG',
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function renderCell(
  renderer: (p: CustomCellRendererProps) => JSX.Element,
  value: unknown,
  data?: Partial<FlatPortEventsResponse>,
) {
  const el = renderer({
    value,
    data,
  } as CustomCellRendererProps);

  return el.props.children;
}

const visibleHeaders = ['Vessel', 'IMO', 'Type', 'Flag'];

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('CreateUnifiedPortEventsColDefs', () => {
  it('returns 19 column definitions', () => {
    const cols = CreateUnifiedPortEventsColDefs('utc');
    expect(cols).toHaveLength(19);
  });

  it('has 6 visible columns (no hide property)', () => {
    const cols = CreateUnifiedPortEventsColDefs('utc');
    const visible = cols.filter((col) => !col.hide);
    expect(visible).toHaveLength(6);
    expect(visible.map((c) => c.headerName)).toEqual([
      'TimeStamp (UTC)',
      'Event',
      ...visibleHeaders,
    ]);
  });

  it('has 13 hidden columns', () => {
    const cols = CreateUnifiedPortEventsColDefs('utc');
    const hidden = cols.filter((col) => col.hide);
    expect(hidden).toHaveLength(13);
    expect(hidden.map((c) => c.headerName)).toEqual([
      'Berth',
      'Call Sign',
      'Course',
      'MMSI',
      'Draught',
      'Heading',
      'Latitude',
      'Longitude',
      'Navigational Status (status)',
      'Navigational Status (code)',
      'Reported Destination',
      'Reported ETA (UTC)',
      'Speed',
    ]);
  });

  it('uses flat field paths, not nested', () => {
    const cols = CreateUnifiedPortEventsColDefs('utc');
    const expectedFields = [
      'eventTimestamp',
      'eventType',
      'vesselName',
      'imo',
      'vesselType',
      'flag',
      'berthName',
      'callSign',
      'course',
      'mmsi',
      'draught',
      'heading',
      'latitude',
      'longitude',
      'navigationalStatusStatus',
      'navigationalStatusCode',
      'reportedDestination',
      'reportedEta',
      'speed',
    ];
    expect(cols.map((c) => c.field)).toEqual(expectedFields);
  });

  describe('timestamp header based on timezone setting', () => {
    it('shows "TimeStamp (UTC)" when timeZoneSetting is "utc"', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      expect(cols[0].headerName).toBe('TimeStamp (UTC)');
    });

    it('shows "TimeStamp (System)" when timeZoneSetting is "system"', () => {
      const cols = CreateUnifiedPortEventsColDefs('system');
      expect(cols[0].headerName).toBe('TimeStamp (System)');
    });

    it('shows "Reported ETA (UTC)" when timeZoneSetting is "utc"', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'reportedEta');
      expect(col?.headerName).toBe('Reported ETA (UTC)');
    });

    it('shows "Reported ETA (System)" when timeZoneSetting is "system"', () => {
      const cols = CreateUnifiedPortEventsColDefs('system');
      const col = cols.find((c) => c.field === 'reportedEta');
      expect(col?.headerName).toBe('Reported ETA (System)');
    });
  });

  describe('timestamp column rendering', () => {
    it('renders UTC timestamp when timezone is utc', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols[0] as ColDef<FlatPortEventsResponse>;

      const content = renderCell(col.cellRenderer!, '2024-01-01T00:00:00Z');

      expect(content).toBe('UTC:2024-01-01T00:00:00Z');
    });

    it('renders local timestamp when timezone is system', () => {
      const cols = CreateUnifiedPortEventsColDefs('system');
      const col = cols[0] as ColDef<FlatPortEventsResponse>;

      const content = renderCell(col.cellRenderer!, '2024-01-01T00:00:00Z');

      expect(content).toBe('LOCAL:2024-01-01T00:00:00Z');
    });

    it('uses tooltipValueGetter with the correct converter', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols[0] as ColDef<FlatPortEventsResponse>;
      const tooltip = col.tooltipValueGetter?.({
        value: '2024-01-01T00:00:00Z',
      } as never);
      expect(tooltip).toBe('UTC:2024-01-01T00:00:00Z');
    });
  });

  describe('eventType column', () => {
    it('renders a status badge', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'eventType')!;

      const el = col.cellRenderer!({
        value: 'PORT_ARRIVAL',
      } as CustomCellRendererProps);

      expect(el.props.status).toBe('PORT_ARRIVAL');
    });

    it('formats the tooltip via getEventLabel', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'eventType')!;

      const tooltip = col.tooltipValueGetter?.({
        value: 'BERTH_ARRIVAL',
      } as never);

      expect(tooltip).toBe('EventLabel:BERTH_ARRIVAL');
    });
  });

  describe('vesselName and flag columns render FlagIcon', () => {
    it('renders vessel name with flag icon', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'vesselName')!;

      const children = renderCell(col.cellRenderer!, 'Evergreen', {
        flagCode: 'SG',
      });

      expect(Array.isArray(children)).toBe(true);
      const [flagEl, nameEl] = children;
      expect(flagEl.props.flagCode).toBe('SG');
      expect(nameEl.props.children).toBe('Evergreen');
    });

    it('renders flag column with flag icon', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'flag')!;

      const children = renderCell(col.cellRenderer!, 'Singapore', {
        flagCode: 'SG',
      });

      expect(Array.isArray(children)).toBe(true);
      const [flagEl, nameEl] = children;
      expect(flagEl.props.flagCode).toBe('SG');
      expect(nameEl.props.children).toBe('Singapore');
    });
  });

  describe('nullable numeric/string fields render dash when missing', () => {
    it('renders dash for empty numeric fields', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const numericFields = [
        'course',
        'draught',
        'heading',
        'latitude',
        'longitude',
        'speed',
        'navigationalStatusCode',
        'berthName',
      ];

      for (const field of numericFields) {
        const col = cols.find((c) => c.field === field);
        if (!col?.cellRenderer) continue;
        const content = renderCell(col.cellRenderer, null);
        expect(content).toBe('-');
      }
    });

    it('renders dash for missing navigational status text', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'navigationalStatusStatus')!;
      expect(renderCell(col.cellRenderer!, null)).toBe('-');
    });

    it('renders dash for missing reported destination', () => {
      const cols = CreateUnifiedPortEventsColDefs('utc');
      const col = cols.find((c) => c.field === 'reportedDestination')!;
      expect(renderCell(col.cellRenderer!, null)).toBe('-');
    });
  });
});
