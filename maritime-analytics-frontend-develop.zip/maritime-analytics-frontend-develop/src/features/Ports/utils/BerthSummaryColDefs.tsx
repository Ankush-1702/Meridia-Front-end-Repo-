import { ColDef } from 'ag-grid-enterprise';
import { BerthRow } from '@/features/Ports/Berth/types/berthTypes';

export function createBerthSummaryColumnDefs(): ColDef<BerthRow>[] {
  const defaultCol: Partial<ColDef<BerthRow>> = {
    sortable: false,
    flex: 1,
    lockVisible: true,
    valueFormatter: (params) =>
      params.value == null || params.value === '' ? '-' : String(params.value),
  };

  return [
    {
      headerName: 'Berth',
      field: 'berth_name',
      tooltipField: 'berth_name',
      ...defaultCol,
    },
    {
      headerName: 'Operator',
      field: 'terminal_name',
      tooltipField: 'terminal_name',
      ...defaultCol,
    },
    {
      headerName: 'Type',
      field: 'berth_type',
      tooltipField: 'berth_type',
      ...defaultCol,
    },
    {
      headerName: 'Avg Dwell',
      field: 'avg_dwell_time',
      tooltipField: 'avg_dwell_time',
      ...defaultCol,
    },
    {
      headerName: 'Median Dwell',
      field: 'median_dwell_time',
      tooltipField: 'median_dwell_time',
      ...defaultCol,
    },
  ];
}
