import {
  buildFieldMappings,
  getCategoryOrder,
} from '@/features/Ports/config/wpiConfig/categories';
import { VALUE_CODES } from '@/features/Ports/config/wpiConfig/valueCodes';
import {
  CategoryArrayItem,
  CategoryMap,
  FieldMapping,
  MappedField,
  MappedPort,
  ValueType,
  WpiData,
} from '@/features/Ports/types/wpiMappingTypes';
import { DataSectionProps } from '@/shared/ui/DataCard';

// ---------- Generated at module load ----------
const FIELD_MAPPINGS = buildFieldMappings();
const SECTION_ORDER = getCategoryOrder();

// ---------- Value resolution ----------
function mapValue(
  value: string | number | boolean | null | undefined,
  valueType: ValueType,
): string {
  if (value === null || value === undefined || value === '') {
    return 'Not Available';
  }

  if (valueType === 'direct') {
    return String(value);
  }

  const mappingTable = VALUE_CODES[valueType];
  if (mappingTable && mappingTable[String(value)]) {
    return mappingTable[String(value)];
  }

  return String(value);
}

// ---------- Port mapping ----------
export function mapPortData(rawPortData: unknown): MappedPort {
  const rawPort =
    typeof rawPortData === 'object' && rawPortData !== null
      ? (rawPortData as Record<
          string,
          string | number | boolean | null | undefined
        >)
      : {};

  const mappedPort: MappedPort = {
    categories: {},
    summary: {
      portName: String(rawPort.portName || 'Unknown Port'),
      countryName: String(rawPort.countryName || 'Unknown Country'),
      portNumber: String(rawPort.portNumber || 'Unknown'),
    },
  };

  Object.keys(rawPort).forEach((fieldName) => {
    const fieldMapping = FIELD_MAPPINGS[fieldName];

    if (fieldMapping) {
      const mappedField: MappedField = {
        label: fieldMapping.name,
        value: mapValue(rawPort[fieldName], fieldMapping.valueType),
      };

      if (!mappedPort.categories[fieldMapping.category]) {
        mappedPort.categories[fieldMapping.category] = [];
      }

      mappedPort.categories[fieldMapping.category].push(mappedField);
    }
  });

  return mappedPort;
}

export function mapPortsResponse(
  apiResponse: Partial<WpiData> | null,
): MappedPort[] {
  if (!apiResponse || !apiResponse.ports || !Array.isArray(apiResponse.ports)) {
    return [];
  }
  return apiResponse.ports.map((port) => mapPortData(port));
}

// ---------- Category helpers ----------
export function getCategories(): string[] {
  const categories = new Set<string>();
  Object.values(FIELD_MAPPINGS).forEach((mapping) => {
    categories.add(mapping.category);
  });
  return Array.from(categories).sort();
}

export function getFieldsByCategory(
  category: string,
): (FieldMapping & { fieldName: string })[] {
  return Object.entries(FIELD_MAPPINGS)
    .filter(([, mapping]) => mapping.category === category)
    .map(([fieldName, mapping]) => ({ fieldName, ...mapping }));
}

// ---------- Extract overloads ----------
type ExtractFormat = 'object' | 'names' | 'array';

export function extractCategories(
  data: MappedPort | MappedPort[] | null | undefined,
  format: 'names',
): string[];
export function extractCategories(
  data: MappedPort | MappedPort[] | null | undefined,
  format: 'array',
): CategoryArrayItem[];
export function extractCategories(
  data: MappedPort | MappedPort[] | null | undefined,
  format?: 'object',
): CategoryMap;
export function extractCategories(
  data: MappedPort | MappedPort[] | null | undefined,
  format: ExtractFormat = 'object',
): string[] | CategoryArrayItem[] | CategoryMap {
  const arr = Array.isArray(data) ? data : [data];
  const first = arr.length > 0 ? arr[0] : null;
  const categories: CategoryMap =
    first && typeof first === 'object' && 'categories' in first
      ? first.categories
      : {};

  if (format === 'names') {
    return Object.keys(categories);
  }

  if (format === 'array') {
    return Object.entries(categories).map(([categoryName, items]) => ({
      categoryName,
      items: Array.isArray(items) ? items : items == null ? [] : [items],
    }));
  }

  return Object.keys(categories).reduce<CategoryMap>((acc, key) => {
    acc[key] = Array.isArray(categories[key])
      ? categories[key]
      : categories[key] == null
        ? []
        : [categories[key] as unknown as MappedField];
    return acc;
  }, {});
}

// ---------- Section builder (generated from config order) ----------
export function getWpiSections(wpiRows: CategoryMap): DataSectionProps[] {
  return SECTION_ORDER.map((title) => ({
    title,
    rows: wpiRows[title],
  }));
}

export { FIELD_MAPPINGS, VALUE_CODES };
