import { TimeRangeOption } from '../components/InboundTimeRangeFilter';
import { InboundVessel, InboundVesselsTableRow } from '../types/inboundVessels';
import { logger } from '@/shared/utils/logger';

/**
 * Transform API vessel data to AG-Grid table row format
 */
export const transformToTableData = (
  vessels: InboundVessel[],
): InboundVesselsTableRow[] => {
  return vessels.map((vessel) => ({
    vesselName: vessel.vessel_information.name,
    imo: vessel.vessel_information.imo,
    mmsi: vessel.vessel_information.mmsi,
    callsign: vessel.vessel_information.callsign,
    vesselType: vessel.vessel_information.vessel_type,
    flag: vessel.vessel_information.flag,
    flagCode: vessel.vessel_information.flag_code,
    reportedDestination: vessel.reported_destination.name,
    reportedEta: vessel.reported_eta || '',
    latitude: vessel.latest_position.latitude,
    longitude: vessel.latest_position.longitude,
    course: vessel.latest_position.course,
    speed: vessel.latest_position.speed,
    heading: vessel.latest_position.heading,
    draught: vessel.latest_position.draught,
    navigationalStatus: String(
      vessel.latest_position.navigational_status.status,
    ),
    lastUpdate: vessel.latest_position.timestamp,
  }));
};

/**
 * Calculate time range filter dates for future ETA ranges
 * Returns null for 'All' to indicate no time filtering
 */
export const getTimeRangeFilter = (
  range: TimeRangeOption,
): { start: string; end: string } | null => {
  const now = new Date();
  const endDate = new Date();

  switch (range) {
    case '24h':
      endDate.setHours(now.getHours() + 24);
      break;
    case '7d':
      endDate.setDate(now.getDate() + 7);
      break;
    case '30d':
      endDate.setDate(now.getDate() + 30);
      break;
    case 'All':
      // For 'All', return null to indicate no time filtering
      return null;
    default:
      endDate.setHours(now.getHours() + 24);
  }

  return {
    start: now.toISOString(),
    end: endDate.toISOString(),
  };
};

/**
 * Determine user-friendly error message from API errors
 */
export const getInboundVesselsErrorMessage = (error: unknown): string => {
  let userErrorMessage = 'Unable to load inbound vessels data';
  if (error instanceof Error) {
    if (error.message.includes('401') || error.message.includes('403')) {
      userErrorMessage = 'Access denied. Please check your permissions.';
    } else if (error.message.includes('404')) {
      userErrorMessage = 'Port data not found.';
    } else if (error.message.includes('500')) {
      userErrorMessage = 'Server error. Please try again later.';
    } else if (
      error.message.includes('timeout') ||
      error.message.includes('network')
    ) {
      userErrorMessage =
        'Network error. Please check your connection and try again.';
    }
  }
  return userErrorMessage;
};

const MONTH_NAMES = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

/**
 * Format a date string to UTC format: DD Mon YYYY HH:MM
 */
export const formatUTCDate = (value: string | null | undefined): string => {
  if (!value) return '-';
  try {
    const date = new Date(value);
    const day = date.getUTCDate().toString().padStart(2, '0');
    const month = MONTH_NAMES[date.getUTCMonth()];
    const year = date.getUTCFullYear();
    const hours = date.getUTCHours().toString().padStart(2, '0');
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    return `${day} ${month} ${year} ${hours}:${minutes}`;
  } catch (err) {
    logger.error('[inboundVesselsUtils] Failed to format UTC date', err);
    return value || '-';
  }
};

/**
 * Format a date string to UTC format with seconds: DD Mon YYYY HH:MM:SS
 */
export const formatUTCDateTime = (value: string | null | undefined): string => {
  if (!value || value === '0') return '-';
  try {
    const date = new Date(value);
    const day = date.getUTCDate().toString().padStart(2, '0');
    const month = MONTH_NAMES[date.getUTCMonth()];
    const year = date.getUTCFullYear();
    const hours = date.getUTCHours().toString().padStart(2, '0');
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const seconds = date.getUTCSeconds().toString().padStart(2, '0');
    return `${day} ${month} ${year} ${hours}:${minutes}:${seconds}`;
  } catch (err) {
    logger.error(
      '[inboundVesselsUtils] Failed to format UTC datetime with seconds',
      err,
    );
    return value || '-';
  }
};
