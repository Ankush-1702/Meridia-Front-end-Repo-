import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { BerthEvents } from '@/features/Ports/types/portTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  getEventLabel,
  // doesNotContainFilterParams,
  // textFilterParams,
} from '@/shared/utils/formatUtils';

export function createBerthEventsColDef(
  timeZoneSetting: string,
): ColDef<BerthEvents>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'TimeStamp (UTC)' : 'TimeStamp (System)'}`,
      field: 'event_details.event_timestamp',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.event_timestamp',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value)
            : convertUTCToLocalTime(params.value)}
        </span>
      ),
    },
    {
      headerName: 'Berth Name',
      field: 'berth_information.name',
      sortable: false,
      flex: 1,
      tooltipField: 'berth_information.name',
      lockVisible: true,
    },
    {
      headerName: 'Event',
      field: 'event_details.event_type',
      sortable: false,
      flex: 1,
      tooltipValueGetter: (params: ITooltipParams) =>
        getEventLabel(params.value),
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <StatusBadge status={params.value} />
      ),
    },
    {
      headerName: 'Vessel',
      field: 'vessel_information.name',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.name',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.vessel_information?.flag_code} />
          <span className="truncate">{params.value}</span>
        </div>
      ),
    },
    {
      headerName: 'IMO',
      field: 'vessel_information.imo',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.imo',
      lockVisible: true,
    },
    {
      headerName: 'Type',
      field: 'vessel_information.vessel_type',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.vessel_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: doesNotContainFilterParams,
    },
    {
      headerName: 'Flag',
      field: 'vessel_information.flag',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.flag',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
    },
    {
      headerName: 'Call Sign',
      field: 'vessel_information.callsign',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.callsign',
      hide: true,
    },
    {
      headerName: 'Course',
      field: 'event_details.course',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.course',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'MMSI',
      field: 'vessel_information.mmsi',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_information.mmsi',
      hide: true,
    },
    {
      headerName: 'Draught',
      field: 'event_details.draught',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.draught',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Heading',
      field: 'event_details.heading',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.heading',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Latitude',
      field: 'event_details.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.latitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Longitude',
      field: 'event_details.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.longitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Navigational Status (status)',
      field: 'event_details.navigational_status.status',
      sortable: false,
      flex: 1,
      width: 500,
      tooltipField: 'event_details.navigational_status.status',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Navigational Status (code)',
      field: 'event_details.navigational_status.code',
      sortable: false,
      flex: 1,
      width: 500,
      tooltipField: 'event_details.navigational_status.code',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
    {
      headerName: 'Reported Destination',
      field: 'event_details.reported_destination',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.reported_destination',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Reported ETA',
      field: 'event_details.reported_eta',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.reported_eta',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Speed',
      field: 'event_details.speed',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.speed',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {params.value !== null && params.value !== undefined
            ? params.value
            : '-'}
        </span>
      ),
    },
  ];
}
