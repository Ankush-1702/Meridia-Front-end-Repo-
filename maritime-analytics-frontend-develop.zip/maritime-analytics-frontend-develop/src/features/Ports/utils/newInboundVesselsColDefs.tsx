import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { FlatPortEventsResponse } from '@/features/Ports/types/portTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  getEventLabel,
} from '@/shared/utils/formatUtils';

export const CreateNewInboundVesselsColDefs = (
  timeZoneSetting: string,
): ColDef<FlatPortEventsResponse>[] => [
  {
    headerName: 'Event',
    field: 'eventType',
    sortable: true,
    flex: 1,
    tooltipValueGetter: (params: ITooltipParams) => getEventLabel(params.value),
    lockVisible: true,
    cellRenderer: (params: CustomCellRendererProps) => (
      <StatusBadge status={params.value} />
    ),
  },
  {
    headerName: `${timeZoneSetting === 'utc' ? 'ETA (UTC)' : 'ETA (System)'}`,
    field: 'reportedEta',
    sortable: true,
    filter: false,
    width: 160,
    lockVisible: true,
    hide: false,
    cellRenderer: (params: CustomCellRendererProps) => (
      <span>
        {timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-'}
      </span>
    ),
    tooltipValueGetter: (params: ITooltipParams) =>
      timeZoneSetting === 'utc'
        ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
        : convertUTCToLocalTime(params.value) || '-',
  },
  {
    headerName: 'Vessel',
    field: 'vesselName',
    sortable: true,
    filter: false,
    resizable: true,
    minWidth: 150,
    lockVisible: true,
    cellRenderer: (params: CustomCellRendererProps) => (
      <div className="flex w-full items-center gap-2 overflow-hidden">
        <FlagIcon flagCode={params.data.flagCode} />
        <span className="truncate font-semibold">{params.value}</span>
      </div>
    ),
    tooltipField: 'vesselName',
  },
  {
    headerName: 'IMO',
    field: 'imo',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    lockVisible: true,
    tooltipField: 'imo',
  },

  {
    headerName: 'Type',
    field: 'vesselType',
    sortable: true,
    filter: false,
    resizable: true,
    width: 140,
    lockVisible: true,
    tooltipField: 'vesselType',
  },
  {
    headerName: 'Flag',
    field: 'flag',
    sortable: true,
    flex: 1,
    tooltipField: 'flag',
    lockVisible: true,
    cellRenderer: (params: CustomCellRendererProps) => (
      <div className="flex items-center gap-2">
        <FlagIcon flagCode={params.data.flagCode} />
        <span className="truncate">{params.value}</span>
      </div>
    ),
  },
  {
    headerName: 'Reported Destination',
    field: 'reportedDestination',
    sortable: true,
    filter: false,
    resizable: true,
    width: 180,
    hide: true,
    tooltipField: 'reportedDestination',
  },
  {
    headerName: 'MMSI',
    field: 'mmsi',
    sortable: true,
    flex: 1,
    tooltipField: 'mmsi',
    hide: true,
  },
  {
    headerName: 'Call Sign',
    field: 'callSign',
    sortable: true,
    flex: 1,
    tooltipField: 'callSign',
    hide: true,
  },
  {
    headerName: 'Latitude',
    field: 'latitude',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(4) || '-',
    valueFormatter: (params) => params.value?.toFixed(4) || '-',
  },
  {
    headerName: 'Longitude',
    field: 'longitude',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(4) || '-',
    valueFormatter: (params) => params.value?.toFixed(4) || '-',
  },
  {
    headerName: 'Course (°)',
    field: 'course',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(1) || '-',
    valueFormatter: (params) => params.value?.toFixed(1) || '-',
  },
  {
    headerName: 'Speed (kts)',
    field: 'speed',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(1) || '-',
    valueFormatter: (params) => params.value?.toFixed(1) || '-',
  },
  {
    headerName: 'Heading (°)',
    field: 'heading',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(1) || '-',
    valueFormatter: (params) => params.value?.toFixed(1) || '-',
  },
  {
    headerName: 'Draught (m)',
    field: 'draught',
    sortable: true,
    filter: false,
    resizable: true,
    width: 120,
    hide: true,
    tooltipValueGetter: (params: ITooltipParams) =>
      params.value?.toFixed(1) || '-',
    valueFormatter: (params) => params.value?.toFixed(1) || '-',
  },
  {
    headerName: 'Navigational Status (status)',
    field: 'navigationalStatusStatus',
    sortable: true,
    flex: 1,
    width: 500,
    tooltipField: 'navigationalStatusStatus',
    hide: true,
    cellRenderer: (params: CustomCellRendererProps) => (
      <span>{params.value ? params.value : '-'}</span>
    ),
  },
  {
    headerName: `${timeZoneSetting === 'utc' ? 'Last Updated (UTC)' : 'Last Updated (System)'}`,
    field: 'lastUpdate',
    sortable: true,
    filter: false,
    resizable: true,
    width: 160,
    hide: true,
    cellRenderer: (params: CustomCellRendererProps) => (
      <span>
        {timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-'}
      </span>
    ),
    tooltipValueGetter: (params: ITooltipParams) =>
      timeZoneSetting === 'utc'
        ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
        : convertUTCToLocalTime(params.value) || '-',
  },
];
