import React from 'react';

import { useInboundVessels } from '../hooks/useInboundVessels';
import { InboundVesselsTableRow } from '../types/inboundVessels';
import { TimeRangeOption } from './InboundTimeRangeFilter';
import PoleStarEntityGrid from '@/shared/lib/PoleStarEntityGrid';

interface InboundVesselsProps {
  portId: string;
  timeRange?: TimeRangeOption;
  passRowsUpdate?: (rows: InboundVesselsTableRow[]) => void;
  portName?: string;
  refresh?: boolean;
}

const InboundVessels: React.FC<InboundVesselsProps> = ({
  portId,
  timeRange,
  passRowsUpdate,
  portName,
  refresh,
}) => {
  const { gridRef, columnDefs, getServerSideData, handleRowClick } =
    useInboundVessels({
      portId,
      timeRange,
      passRowsUpdate,
      portName,
      refresh,
    });

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="mt-6 min-h-0 flex-1 overflow-auto">
        <div className="h-full min-h-0">
          <PoleStarEntityGrid
            ref={gridRef}
            columns={columnDefs}
            getServerSideData={getServerSideData}
            isSideBar={true}
            onRowClick={handleRowClick}
            storageKey="Inbound vessel events"
            noRowsOverlay={`
            <div class="flex items-center justify-center h-full text-gray-500 text-base">
              No Inbound Vessels
            </div>
          `}
          />
        </div>
      </div>
    </div>
  );
};

export default InboundVessels;
