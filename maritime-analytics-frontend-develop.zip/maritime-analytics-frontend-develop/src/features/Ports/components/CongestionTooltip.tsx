import { Tooltip } from 'flowbite-react';
import { FaCircleInfo } from 'react-icons/fa6';

export default function CongestionTooltip() {
  return (
    <div className="flex items-center justify-center gap-2">
      <p className="text-xs text-gray-400">Commercial vessels only</p>
      <Tooltip
        content={`All data uses commercial vessel data only and excludes passenger, fishing and tug vessels.`}
        placement="bottom"
        className="flex h-[62px] w-[336px] items-center justify-center rounded bg-gray-800 p-2 text-sm font-medium"
      >
        <FaCircleInfo className="h-3 w-3 text-gray-400" />
      </Tooltip>
    </div>
  );
}
