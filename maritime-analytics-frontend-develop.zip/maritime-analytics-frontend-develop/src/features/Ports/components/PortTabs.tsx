import TabGroup, { type TabSize } from '@/shared/components/TabGroup';

interface Props {
  className?: string;
  tabs: string[];
  active: string;
  onChange: (tab: string) => void;
  size?: TabSize;
}
export default function PortTabs({
  active,
  className,
  onChange,
  tabs,
  size = 'md',
}: Props) {
  // Convert string tabs to TabConfig objects with specific configuration for port events
  const tabConfigs = tabs.map((tab) => ({
    label: tab,
    tooltip:
      tab === 'All' ? 'Excludes inbound vessel and berth events' : undefined,
    showIcon: tab === 'All',
  }));

  return (
    <div>
      <TabGroup
        tabs={tabConfigs}
        active={active}
        onChange={onChange}
        className={className}
        size={size}
      />
    </div>
  );
}
