import TabGroup, { type TabSize } from '@/shared/components/TabGroup';

export type TimeRangeOption = '24h' | '7d' | '30d' | 'All';

interface InboundTimeRangeFilterProps {
  selectedRange: TimeRangeOption;
  onRangeChange: (range: TimeRangeOption) => void;
  className?: string;
  size?: TabSize;
}

const timeRangeOptions: TimeRangeOption[] = ['24h', '7d', '30d', 'All'];

export default function InboundTimeRangeFilter({
  selectedRange,
  onRangeChange,
  className = '',
  size,
}: InboundTimeRangeFilterProps) {
  return (
    <div className={className}>
      <TabGroup
        tabs={timeRangeOptions}
        active={selectedRange}
        onChange={(tab) => onRangeChange(tab as TimeRangeOption)}
        size={size}
      />
    </div>
  );
}
