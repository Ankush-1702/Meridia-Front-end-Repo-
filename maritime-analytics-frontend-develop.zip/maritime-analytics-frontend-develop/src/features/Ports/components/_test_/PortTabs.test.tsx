import { render } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import PortTabs from '../PortTabs';
import { type TabSize } from '@/shared/components/TabGroup';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const tabGroupPropsSpy = vi.fn();

beforeEach(() => tabGroupPropsSpy.mockClear());

vi.mock('@/shared/components/TabGroup', () => ({
  default: (props: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
    className?: string;
    size?: TabSize;
  }) => {
    tabGroupPropsSpy(props);
    return <div>TabGroup</div>;
  },
}));

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('PortTabs', () => {
  it('passes props to TabGroup', () => {
    const onChange = vi.fn();

    render(
      <PortTabs
        tabs={['Overview', 'Events']}
        active="Overview"
        onChange={onChange}
        className="px-2"
        size="md"
      />,
    );

    expect(tabGroupPropsSpy).toHaveBeenCalledWith({
      tabs: [
        { label: 'Overview', tooltip: undefined, showIcon: false },
        { label: 'Events', tooltip: undefined, showIcon: false },
      ],
      active: 'Overview',
      onChange,
      className: 'px-2',
      size: 'md',
    });
  });

  it('adds tooltip and icon for "All" tab', () => {
    const onChange = vi.fn();

    render(
      <PortTabs
        tabs={['All', 'Arrivals', 'Departures']}
        active="All"
        onChange={onChange}
      />,
    );

    expect(tabGroupPropsSpy).toHaveBeenCalledWith({
      tabs: [
        {
          label: 'All',
          tooltip: 'Excludes inbound vessel and berth events',
          showIcon: true,
        },
        { label: 'Arrivals', tooltip: undefined, showIcon: false },
        { label: 'Departures', tooltip: undefined, showIcon: false },
      ],
      active: 'All',
      onChange,
      className: undefined,
      size: 'md',
    });
  });
});
