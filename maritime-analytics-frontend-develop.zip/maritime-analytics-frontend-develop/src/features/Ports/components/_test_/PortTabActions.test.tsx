import { fireEvent, render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import PortTabActions from '../PortTabActions';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const isMara2EnabledMock = vi.fn();

vi.mock('@/app/config/config', () => ({
  isMara2Enabled: () => isMara2EnabledMock(),
}));

vi.mock('@/features/Ports/components/CongestionTooltip', () => ({
  default: () => <div>Congestion Tooltip</div>,
}));

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('PortTabActions', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    isMara2EnabledMock.mockReturnValue(true);
  });

  it('does not render a refresh button on the events tab', () => {
    render(
      <PortTabActions
        activeTab="events"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={vi.fn()}
      />,
    );

    expect(screen.queryByText('Refresh')).not.toBeInTheDocument();
  });

  it('renders the Ask IQ button and fires onAskIQ when clicked', () => {
    const onAskIQ = vi.fn();

    render(
      <PortTabActions
        activeTab="overview"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={onAskIQ}
      />,
    );

    const askIqButton = screen.getByText('Ask IQ');
    expect(askIqButton).toBeInTheDocument();

    fireEvent.click(askIqButton);

    expect(onAskIQ).toHaveBeenCalledTimes(1);
  });

  it('does not render the Ask IQ button when mara2 is disabled', () => {
    isMara2EnabledMock.mockReturnValue(false);

    render(
      <PortTabActions
        activeTab="overview"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={vi.fn()}
      />,
    );

    expect(screen.queryByText('Ask IQ')).not.toBeInTheDocument();
  });

  it('renders CongestionTooltip on the congestion and utilisation tab', () => {
    render(
      <PortTabActions
        activeTab="congestion and utilisation"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={vi.fn()}
      />,
    );

    expect(screen.getByText('Congestion Tooltip')).toBeInTheDocument();
  });

  it('does not render CongestionTooltip on other tabs', () => {
    render(
      <PortTabActions
        activeTab="overview"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={vi.fn()}
      />,
    );

    expect(screen.queryByText('Congestion Tooltip')).not.toBeInTheDocument();
  });

  it('shows the auto-updates message on the overview tab', () => {
    render(
      <PortTabActions
        activeTab="overview"
        refresh={false}
        onRefresh={vi.fn()}
        onAskIQ={vi.fn()}
      />,
    );

    expect(
      screen.getByText('Auto-updates every 5 minutes'),
    ).toBeInTheDocument();
  });
});
