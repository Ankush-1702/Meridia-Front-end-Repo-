import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import InboundTimeRangeFilter from '@/features/Ports/components/InboundTimeRangeFilter';

vi.mock('@/shared/components/TabGroup', () => ({
  default: ({
    tabs,
    active,
    onChange,
  }: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
  }) => (
    <div data-testid="tab-group">
      {tabs.map((tab) => (
        <button
          key={tab}
          data-active={tab === active}
          onClick={() => onChange(tab)}
        >
          {tab}
        </button>
      ))}
    </div>
  ),
}));

describe('InboundTimeRangeFilter', () => {
  const mockOnRangeChange = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render all time range options', () => {
    render(
      <InboundTimeRangeFilter
        selectedRange="24h"
        onRangeChange={mockOnRangeChange}
      />,
    );

    expect(screen.getByText('24h')).toBeInTheDocument();
    expect(screen.getByText('7d')).toBeInTheDocument();
    expect(screen.getByText('30d')).toBeInTheDocument();
    expect(screen.getByText('All')).toBeInTheDocument();
  });

  it('should mark the selected range as active', () => {
    render(
      <InboundTimeRangeFilter
        selectedRange="7d"
        onRangeChange={mockOnRangeChange}
      />,
    );

    expect(screen.getByText('7d')).toHaveAttribute('data-active', 'true');
    expect(screen.getByText('24h')).toHaveAttribute('data-active', 'false');
  });

  it('should call onRangeChange when a tab is clicked', () => {
    render(
      <InboundTimeRangeFilter
        selectedRange="24h"
        onRangeChange={mockOnRangeChange}
      />,
    );

    fireEvent.click(screen.getByText('30d'));

    expect(mockOnRangeChange).toHaveBeenCalledWith('30d');
  });

  it('should apply custom className', () => {
    const { container } = render(
      <InboundTimeRangeFilter
        selectedRange="24h"
        onRangeChange={mockOnRangeChange}
        className="px-2"
      />,
    );

    expect(container.firstChild).toHaveClass('px-2');
  });
});
