import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import CongestionTooltip from '@/features/Ports/components/CongestionTooltip';

vi.mock('react-icons/fa6', () => ({
  FaCircleInfo: () => <svg data-testid="info-icon" />,
}));

describe('CongestionTooltip', () => {
  it('renders the label text', () => {
    render(<CongestionTooltip />);
    expect(screen.getByText('Commercial vessels only')).toBeTruthy();
  });

  it('renders the info icon', () => {
    render(<CongestionTooltip />);
    expect(screen.getByTestId('info-icon')).toBeTruthy();
  });

  it('shows tooltip content on hover', async () => {
    render(<CongestionTooltip />);

    fireEvent.mouseEnter(screen.getByTestId('info-icon'));

    expect(
      await screen.findByText(/All data uses commercial vessel data only/),
    ).toBeTruthy();
  });
});
