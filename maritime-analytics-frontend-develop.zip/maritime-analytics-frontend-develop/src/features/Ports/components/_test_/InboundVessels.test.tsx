import { render, screen, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { InboundVesselsApiResponse } from '../../types/inboundVessels';
import InboundVessels from '../InboundVessels';
import { ToastProvider } from '@/shared/lib/PoleStarNotification';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const mockExportToCSV = vi.fn();
const mockGetInboundVessels = vi.fn();
const mockGetInboundVesselsSimple = vi.fn();

vi.mock('../../services/inboundVesselsApi', () => ({
  getInboundVessels: (...args: unknown[]) => mockGetInboundVessels(...args),
  getInboundVesselsSimple: (...args: unknown[]) =>
    mockGetInboundVesselsSimple(...args),
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    exportToCSV: mockExportToCSV,
  }),
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    textLabel,
    handleClick,
  }: {
    textLabel: string;
    handleClick: () => void;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: vi.fn().mockImplementation(() => {
    return <div data-testid="pole-star-grid">Grid</div>;
  }),
}));

vi.mock('react-router-dom', () => ({
  useNavigate: () => vi.fn(),
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

const renderWithProviders = (component: React.ReactElement) => {
  return render(<ToastProvider>{component}</ToastProvider>);
};

const mockApiResponse: InboundVesselsApiResponse = {
  meta: {
    limit: 100,
    offset: 0,
    total_count: 2,
    request_id: 'test-request-id',
    request_timestamp: '2026-02-12T00:00:00Z',
  },
  data: [
    {
      vessel_information: {
        asset_id: 'asset-1',
        name: 'Sea Explorer',
        imo: '9234567',
        mmsi: '234567890',
        callsign: 'CALL1',
        vessel_type: 'Cargo',
        flag: 'United Kingdom',
        flag_code: 'GB',
      },
      reported_destination: {
        id: 'dest-1',
        name: 'Hamburg Port',
        raw: 'HAMBURG',
        unlocode: 'DEHAM',
        reported_at: '2026-02-11T14:30:00Z',
      },
      reported_eta: '2026-02-12T20:45:00Z',
      latest_position: {
        latitude: 53.5511,
        longitude: 9.9937,
        course: 180.0,
        speed: 12.8,
        heading: 182.3,
        draught: 14.8,
        navigational_status: {
          status: 0,
          code: 0,
        },
        timestamp: '2026-02-06T11:45:00Z',
      },
    },
    {
      vessel_information: {
        asset_id: 'asset-2',
        name: 'Ocean Carrier',
        imo: '9345678',
        mmsi: '345678901',
        callsign: 'CALL2',
        vessel_type: 'Container Ship',
        flag: 'Singapore',
        flag_code: 'SG',
      },
      reported_destination: {
        id: 'dest-2',
        name: 'Singapore Port',
        raw: 'SINGAPORE',
        unlocode: 'SGSIN',
        reported_at: '2026-02-06T09:20:00Z',
      },
      reported_eta: '2026-02-12T16:30:00Z',
      latest_position: {
        latitude: 53.6511,
        longitude: 9.8937,
        course: 45.2,
        speed: 15.2,
        heading: 47.8,
        draught: 16.5,
        navigational_status: {
          status: 0,
          code: 0,
        },
        timestamp: '2026-02-06T11:50:00Z',
      },
    },
  ],
};

const emptyApiResponse: InboundVesselsApiResponse = {
  meta: {
    limit: 100,
    offset: 0,
    total_count: 0,
    request_id: 'test-request-id',
    request_timestamp: '2026-02-12T00:00:00Z',
  },
  data: [],
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('InboundVessels', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Rendering', () => {
    it('renders grid component', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      await waitFor(() => {
        expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
      });
    });
  });

  describe('Data Fetching', () => {
    it('renders without crashing when data is fetched', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      const { container } = renderWithProviders(
        <InboundVessels portId="port-1" />,
      );

      expect(container).toBeInTheDocument();
    });

    it('accepts portId prop', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
    });

    it('accepts optional props', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(
        <InboundVessels portId="port-1" portName="Test Port" />,
      );

      expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
    });
  });

  describe('CSV Export', () => {
    it('exports CSV when export event is triggered', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      await waitFor(() => {
        expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
      });

      // Trigger the export event that the component listens for
      const exportEvent = new CustomEvent('exportInboundVessels');
      window.dispatchEvent(exportEvent);

      await waitFor(() => {
        expect(mockExportToCSV).toHaveBeenCalled();
        // expect(mockExportToCSV).toHaveBeenCalledWith(
        //   expect.any(String),
        //   'Inbound-Vessels',
        // );
      });
    });

    it('generates CSV with proper headers', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      await waitFor(() => {
        expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
      });

      const exportEvent = new CustomEvent('exportInboundVessels');
      window.dispatchEvent(exportEvent);

      await waitFor(() => {
        expect(mockExportToCSV).toHaveBeenCalled();
      });

      const csvContent = mockExportToCSV.mock.calls[0][0] as string;
      expect(csvContent).toContain('Vessel');
      expect(csvContent).toContain('IMO');
      expect(csvContent).toContain('Type');
      expect(csvContent).toContain('Flag');
    });

    it('includes vessel data in CSV', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      await waitFor(() => {
        expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
      });

      const exportEvent = new CustomEvent('exportInboundVessels');
      window.dispatchEvent(exportEvent);

      await waitFor(() => {
        expect(mockExportToCSV).toHaveBeenCalled();
      });
    });

    it('handles CSV export with empty data', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(emptyApiResponse);

      renderWithProviders(<InboundVessels portId="port-1" />);

      await waitFor(() => {
        expect(screen.getByTestId('pole-star-grid')).toBeInTheDocument();
      });

      const exportEvent = new CustomEvent('exportInboundVessels');
      window.dispatchEvent(exportEvent);

      await waitFor(() => {
        expect(mockExportToCSV).toHaveBeenCalled();
      });
    });
  });

  describe('Column Definitions', () => {
    it('renders component with column definitions', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      const { container } = renderWithProviders(
        <InboundVessels portId="port-1" />,
      );

      expect(container).toBeInTheDocument();
    });
  });

  describe('Data Formatting', () => {
    it('renders without errors when provided with complete data', async () => {
      mockGetInboundVesselsSimple.mockResolvedValue(mockApiResponse);

      const { container } = renderWithProviders(
        <InboundVessels portId="port-1" />,
      );

      expect(container).toBeInTheDocument();
    });

    it('renders without errors when provided with null ETA', async () => {
      const responseWithNullEta = {
        ...mockApiResponse,
        data: [
          {
            ...mockApiResponse.data[0],
            reported_eta: null,
          },
        ],
      };

      mockGetInboundVesselsSimple.mockResolvedValue(responseWithNullEta);

      const { container } = renderWithProviders(
        <InboundVessels portId="port-1" />,
      );

      expect(container).toBeInTheDocument();
    });

    it('renders without errors with zero numeric values', async () => {
      const responseWithNullValues = {
        ...mockApiResponse,
        data: [
          {
            ...mockApiResponse.data[0],
            latest_position: {
              ...mockApiResponse.data[0].latest_position,
              speed: 0,
              course: 0,
            },
          },
        ],
      };

      mockGetInboundVesselsSimple.mockResolvedValue(responseWithNullValues);

      const { container } = renderWithProviders(
        <InboundVessels portId="port-1" />,
      );

      expect(container).toBeInTheDocument();
    });
  });
});
