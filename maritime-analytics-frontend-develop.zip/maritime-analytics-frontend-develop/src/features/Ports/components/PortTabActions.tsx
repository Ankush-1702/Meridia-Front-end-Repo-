import { MdAutoAwesome } from 'react-icons/md';
import { isMara2Enabled } from '@/app/config/config';
import CongestionTooltip from '@/features/Ports/components/CongestionTooltip';

interface PortTabActionsProps {
  activeTab: string;
  refresh: boolean;
  onRefresh: () => void;
  onAskIQ: () => void;
}

export default function PortTabActions({
  activeTab,
  onAskIQ,
}: PortTabActionsProps) {
  return (
    <div className="flex items-center gap-2">
      {activeTab === 'congestion and utilisation' && (
        <div className="-mt-3 flex items-center justify-center">
          <CongestionTooltip />
        </div>
      )}
      {activeTab === 'overview' && (
        <div className="-mt-5 flex items-center justify-center">
          <p className="text-xs text-gray-400">Auto-updates every 5 minutes</p>
        </div>
      )}
      {isMara2Enabled() && (
        <button
          onClick={onAskIQ}
          className="-mt-5 flex min-w-[110px] items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
        >
          <MdAutoAwesome className="text-gray-400" />
          Ask IQ
        </button>
      )}
    </div>
  );
}
