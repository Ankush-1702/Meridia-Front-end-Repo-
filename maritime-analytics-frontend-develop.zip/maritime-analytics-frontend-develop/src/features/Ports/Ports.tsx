import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BerthDetails from './Berth/ui/BerthDetails';
import BerthTab from './Berth/ui/BerthTab';
import PortTabActions from './components/PortTabActions';
import { useInboundSummary } from './hooks/useInboundSummary';
import {
  ASK_IQ_PATH,
  askIqPrompts,
  buildAskIqNavigationState,
} from '@/features/mara2/utils/askIq';
import { useLivePortTraffic } from '@/features/Ports/hooks/useLivePortTraffic';
import { usePortDetails } from '@/features/Ports/hooks/usePortsDetails';
import CongestionAndUtilisation from '@/features/Ports/ui/CongestionAndUtilisation';
import PortEventsTab from '@/features/Ports/ui/PortEventsTab';
import PortOverviewTab from '@/features/Ports/ui/PortOverviewTab';
import EntityLoadingSkeleton from '@/shared/components/EntityLoadingSkeleton';
import EntityTabs from '@/shared/components/EntityTabs';
import { useOverviewData } from '@/shared/hooks/useOverviewData';
import { PortTabsOptions } from '@/shared/types/entities';
import EntityToolBar from '@/shared/ui/EntityToolbar';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';

const PORT_TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'congestion and utilisation', label: 'Congestion and Utilisation' },
  { key: 'berths', label: 'Berths' },
  { key: 'events', label: 'Events' },
  // { key: 'details', label: 'Details' },
];

const PORT_EVENT_TABS = [
  { label: 'Area Arrivals', value: 'PORT_AREA_ARRIVAL' },
  { label: 'Arrivals', value: 'PORT_ARRIVAL' },
  { label: 'Berth Arrivals', value: 'BERTH_ARRIVAL' },
  { label: 'Berth Departures', value: 'BERTH_DEPARTURE' },
  { label: 'Departures', value: 'PORT_DEPARTURE' },
  { label: 'Area Departures', value: 'PORT_AREA_DEPARTURE' },
];

const NOTIFICATION_TYPES = [
  'Area Arrivals',
  'Arrivals',
  'Departures',
  'Area Departures',
];

export default function PortDetailsPage() {
  const navigate = useNavigate();

  const {
    id,
    port,
    loading,
    error,
    refresh,
    setRefresh,
    toggleBookmarkLoading,
    addOrRemoveBookmark,
    isBookmarked,
    subscriptionData,
    manageSubscription,
    getSubscription,
    portBoundary,
  } = usePortDetails();

  const {
    isLoading,
    livePortData,
    last30DaysData,
    fetchLivePortTraffic,
    fetchLast30DaysData,
  } = useLivePortTraffic();
  const [activeTab, setActiveTab] = useState('overview');

  const [selectedBerthId, setSelectedBerthId] = useState<string | undefined>();
  const [selectedBerthName, setSelectedBerthName] = useState<
    string | undefined
  >();

  const [activePortEventTab, setActivePortEventTab] =
    useState<PortTabsOptions>('Historic');

  const handleSetActiveTab = (tab: string) => setActiveTab(tab);

  const {
    center: overviewCenter,
    positions,
    progress: overviewProgress,
    refresh: refreshOverview,
  } = useOverviewData({
    entity: port?.id ? { type: 'port', id: port.id } : undefined,
  });

  const inbound = useInboundSummary(port?.id);

  const handleAskIQ = () => {
    if (!port?.name) return;
    navigate(
      ASK_IQ_PATH,
      buildAskIqNavigationState(askIqPrompts.port(port.name)),
    );
  };

  const handleNavigateToEvents = (eventTab?: PortTabsOptions) => {
    setActiveTab('events');
    if (eventTab) {
      setActivePortEventTab(eventTab);
    }
  };
  // --- Guards ---
  if (loading) {
    return (
      <div className="h-screen p-6 dark:bg-gray-900">
        <EntityLoadingSkeleton />
      </div>
    );
  }

  if (error && !port) {
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );
  }

  if (!port) {
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );
  }

  const bookmarked = isBookmarked(port.id);

  return (
    <div className="flex h-screen flex-col bg-gray-100 dark:bg-gray-900 lg:overflow-hidden">
      <header className="sticky top-0 z-10 bg-gray-100 dark:bg-gray-900">
        <EntityToolBar
          id={id}
          breadcrumbs={[
            { label: 'Library', href: '/analytics/library' },
            { label: 'Ports', href: '/analytics/library?tab=Ports' },
          ]}
          flag={port.country_code}
          title={port.name}
          subtitle={`Port, ${port.country_common_name}`}
          buttonLabel={bookmarked ? 'Remove from Library' : 'Add to Library'}
          onToggle={() => addOrRemoveBookmark(port.id)}
          loading={toggleBookmarkLoading}
          refresh={refresh}
          setRefresh={setRefresh}
          notificationsType={NOTIFICATION_TYPES}
          subscriptionData={subscriptionData}
          manageSubscription={manageSubscription}
          isBookmarked={bookmarked}
          getSubscription={getSubscription}
          dontShowDateRange
        />

        <div className="h-12 bg-gray-50">
          <EntityTabs
            tabs={PORT_TABS}
            activeTab={activeTab}
            onChange={setActiveTab}
            renderActions={
              <PortTabActions
                activeTab={activeTab}
                refresh={refresh}
                onRefresh={() => setRefresh(true)}
                onAskIQ={handleAskIQ}
              />
            }
          />
        </div>
      </header>

      <main className="min-h-0 flex-1 overflow-auto">
        <div className="min-h-0 px-6">
          <div className="mt-4">
            {activeTab === 'overview' && (
              <PortOverviewTab
                port={port}
                positions={positions}
                overviewCenter={overviewCenter}
                overviewProgress={overviewProgress}
                inboundVessels={inbound.inboundVessels}
                inboundVesselsTotalCount={inbound.totalCount}
                isInboundVesselsLoading={inbound.isLoading}
                activeInboundVesselTimeFrame={inbound.activeTimeFrame}
                setActiveInboundVesselTimeFrame={inbound.setActiveTimeFrame}
                inboundVesselTimeFrameTabs={inbound.timeFrameTabs}
                isLoading={isLoading}
                livePortData={livePortData}
                last30DaysData={last30DaysData}
                onNavigateToEvents={handleNavigateToEvents}
                onNavigateToCongestion={() =>
                  setActiveTab('congestion and utilisation')
                }
                getInBoundVessels={inbound.fetchInboundVessels}
                portBoundary={portBoundary}
                refreshOverview={refreshOverview}
                fetchLivePortTraffic={fetchLivePortTraffic}
                fetchLast30DaysData={fetchLast30DaysData}
              />
            )}

            {activeTab === 'congestion and utilisation' && (
              <CongestionAndUtilisation
                port={port}
                setActiveTab={handleSetActiveTab}
                setSelectedBerthId={setSelectedBerthId}
                setSelectedBerthName={setSelectedBerthName}
              />
            )}

            {/* {activeTab === 'details' && (
              <PortDetailsTab
                port={port}
                wpiData={wpiData}
                onExportCSV={exportToCSV}
              />
            )} */}

            {activeTab === 'events' && (
              <PortEventsTab
                portId={id!}
                portName={port.name}
                refresh={refresh}
                setRefresh={setRefresh}
                portEventsTabs={PORT_EVENT_TABS}
                activePortEventTab={activePortEventTab}
                setActivePortEventTab={setActivePortEventTab}
              />
            )}
            {activeTab === 'berths' &&
              (selectedBerthId ? (
                <BerthDetails
                  berthId={selectedBerthId}
                  berthName={selectedBerthName}
                  onBack={() => {
                    setSelectedBerthId(undefined);
                    setSelectedBerthName(undefined);
                    setActiveTab('congestion and utilisation');
                  }}
                />
              ) : (
                <BerthTab />
              ))}
          </div>
        </div>
      </main>
    </div>
  );
}
