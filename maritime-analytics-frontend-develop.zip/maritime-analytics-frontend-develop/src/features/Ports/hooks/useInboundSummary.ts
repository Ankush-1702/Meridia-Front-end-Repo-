import { useState, useCallback, useEffect } from 'react';
import { INBOUND_VESSELS_DESTINATION_UPDATE_DAYS } from '@/app/config/config';
import { INBOUND_VESSEL_TIMEFRAME_KEY } from '@/app/constants/constants';
import { getInboundVessels } from '@/features/Ports/services/inboundVesselsApi';
import { InboundVessel } from '@/features/Ports/types/inboundVessels';
import { logger } from '@/shared/utils/logger';

export function useInboundSummary(portId: string | undefined) {
  const [inboundVessels, setInboundVessels] = useState<InboundVessel[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTimeFrame, setActiveTimeFrame] = useState(() => {
    return localStorage.getItem(INBOUND_VESSEL_TIMEFRAME_KEY) || '24h';
  });

  const timeFrameTabs = ['24h', '7d', '30d', 'All'];

  const fetchInboundVessels = useCallback(async () => {
    if (!portId) return;

    setIsLoading(true);
    try {
      const now = new Date();
      const destinationUpdateCutoff = new Date(
        now.getTime() -
          INBOUND_VESSELS_DESTINATION_UPDATE_DAYS * 24 * 60 * 60 * 1000,
      );

      let reportedETALte: string | Date;
      if (activeTimeFrame === '24h') {
        reportedETALte = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      } else if (activeTimeFrame === '7d') {
        reportedETALte = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      } else if (activeTimeFrame === '30d') {
        reportedETALte = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      } else {
        reportedETALte = '';
      }

      const response = await getInboundVessels({
        id: portId,
        id_type: 'id',
        limit: 500,
        offset: 0,
        last_destination_update_after: destinationUpdateCutoff.toISOString(),
        exclude_arrived: true,
        ...(activeTimeFrame !== 'All' && {
          reported_eta_gte: now.toISOString(),
          reported_eta_lte:
            typeof reportedETALte === 'string'
              ? reportedETALte
              : reportedETALte.toISOString(),
        }),
      });
      setInboundVessels(response.data);
      setTotalCount(response.meta.total_count);
    } catch (err) {
      logger.error('[Ports] Failed to fetch inbound vessels', err);
      setInboundVessels([]);
      setTotalCount(0);
    } finally {
      setIsLoading(false);
    }
  }, [portId, activeTimeFrame]);

  useEffect(() => {
    fetchInboundVessels();
  }, [fetchInboundVessels]);

  return {
    inboundVessels,
    totalCount,
    isLoading,
    activeTimeFrame,
    setActiveTimeFrame,
    timeFrameTabs,
    fetchInboundVessels,
  };
}
