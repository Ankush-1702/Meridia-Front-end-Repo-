import {
  ColDef,
  IServerSideGetRowsParams,
  RowClickedEvent,
} from 'ag-grid-enterprise';
import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from 'react';
import { useNavigate } from 'react-router-dom';

import { TimeRangeOption } from '../components/InboundTimeRangeFilter';
import { getInboundVessels } from '../services/inboundVesselsApi';
import { InboundVesselsTableRow } from '../types/inboundVessels';
import { createInboundVesselsColDefs } from '../utils/inboundVesselsColDefs';
import {
  transformToTableData,
  getTimeRangeFilter,
  getInboundVesselsErrorMessage,
} from '../utils/inboundVesselsUtils';
import { INBOUND_VESSELS_DESTINATION_UPDATE_DAYS } from '@/app/config/config';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { type PoleStarEntityGridRef } from '@/shared/lib/PoleStarEntityGrid';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { sanitizeFilenameSegment } from '@/shared/utils/formatUtils';

interface UseInboundVesselsOptions {
  portId: string;
  timeRange?: TimeRangeOption;
  passRowsUpdate?: (rows: InboundVesselsTableRow[]) => void;
  portName?: string;
  refresh?: boolean;
}
interface UseInboundVesselsReturn {
  gridRef: React.RefObject<PoleStarEntityGridRef>;
  columnDefs: ColDef<InboundVesselsTableRow>[];
  getServerSideData: (params: IServerSideGetRowsParams) => Promise<void>;
  handleRowClick: (event: RowClickedEvent<InboundVesselsTableRow>) => void;
}

export const useInboundVessels = ({
  portId,
  timeRange: propTimeRange,
  passRowsUpdate,
  portName,
  refresh,
}: UseInboundVesselsOptions): UseInboundVesselsReturn => {
  const navigate = useNavigate();
  const gridRef = useRef<PoleStarEntityGridRef>(null);
  const { exportToCSV } = useLibrary();
  const { showToast } = useToastNotification();
  const [rows, setRows] = useState<InboundVesselsTableRow[]>([]);
  const timeRange = propTimeRange || '24h';

  const columnDefs = useMemo(() => createInboundVesselsColDefs(), []);

  const getServerSideData = useCallback(
    async (params: IServerSideGetRowsParams) => {
      params.api.setGridOption('loading', true);
      setRows([]);
      const { startRow, endRow } = params.request;
      const pageSize = endRow! - startRow!;

      const now = new Date();
      const destinationUpdateCutoff = new Date(
        now.getTime() -
          INBOUND_VESSELS_DESTINATION_UPDATE_DAYS * 24 * 60 * 60 * 1000,
      );

      const timeRangeFilter = getTimeRangeFilter(timeRange);

      try {
        const response = await getInboundVessels({
          id: portId,
          id_type: 'id',
          limit: pageSize,
          offset: startRow!,
          last_destination_update_after: destinationUpdateCutoff.toISOString(),
          exclude_arrived: true,
          ...(timeRangeFilter && {
            reported_eta_gte: timeRangeFilter.start,
            reported_eta_lte: timeRangeFilter.end,
          }),
        });

        const transformedData = transformToTableData(response.data);
        passRowsUpdate?.(transformedData);
        setRows(transformedData);

        params.success({
          rowData: transformedData,
          rowCount: response.meta.total_count,
        });

        params.api.setGridOption('loading', false);
        if (response.meta.total_count === 0) params.api.showNoRowsOverlay();
        else params.api.hideOverlay();
      } catch (error) {
        params.api.setGridOption('loading', false);
        params.api.showNoRowsOverlay();
        params.fail();

        const userErrorMessage = getInboundVesselsErrorMessage(error);
        showToast('error', userErrorMessage, 5000);
        setRows([]);

        params.success({
          rowData: [],
          rowCount: 0,
        });

        params.api.showNoRowsOverlay();
        console.error('Error fetching inbound vessels:', error);
      }
    },
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [refresh, portId, timeRange, showToast, passRowsUpdate],
  );

  const getCSVContent = useCallback((): string => {
    const gridColDefs = gridRef.current?.getDisplayedColDefs?.();
    const displayedColDefs =
      gridColDefs && gridColDefs.length > 0 ? gridColDefs : columnDefs;

    const headers = displayedColDefs
      .map((c) => c.headerName ?? c.colId ?? c.field ?? '')
      .join(',');
    const fields = displayedColDefs.map((c) => c.field ?? '');

    const pageRows = gridRef.current?.getCurrentPageRows?.() as
      | InboundVesselsTableRow[]
      | undefined;
    const currentRows = pageRows !== undefined ? pageRows : rows;

    const dataRows = currentRows.map((row) =>
      fields
        .map((field) => {
          if (!field) return '';
          const raw = (row as unknown as Record<string, unknown>)[field];
          if (raw == null) return '';
          const str = String(raw).replace(/"/g, '""');
          return /[,"\n]/.test(str) ? `"${str}"` : str;
        })
        .join(','),
    );

    return [headers, ...dataRows].join('\n');
  }, [columnDefs, rows]);

  const handleRowClick = useCallback(
    (event: RowClickedEvent<InboundVesselsTableRow>) => {
      const rowData = event.data;
      if (rowData?.imo) {
        navigate(`/analytics/vessel/${rowData.imo}`);
      }
    },
    [navigate],
  );

  useEffect(() => {
    const handleExport = () => {
      const safePortName = sanitizeFilenameSegment(portName ?? 'Unknown');
      exportToCSV(
        getCSVContent(),
        `${safePortName}_Inbound_Vessels_${new Date().toISOString().split('T')[0]}`,
      );
    };

    window.addEventListener('exportInboundVessels', handleExport);
    return () => {
      window.removeEventListener('exportInboundVessels', handleExport);
    };
  }, [exportToCSV, getCSVContent, portName]);

  return {
    gridRef,
    columnDefs,
    getServerSideData,
    handleRowClick,
  };
};
