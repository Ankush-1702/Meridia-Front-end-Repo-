import { IServerSideGetRowsParams } from 'ag-grid-community';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router';
import { getSelected } from '../utils/portUtils';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { countries } from '@/features/library/utils/countryMapping';
import { getBerths } from '@/features/Ports/Berth/services/berthServices';
import {
  getArrivalsAndDeparturesByTotals,
  getArrivalsByVesselType,
  getArrivalsByVesselTypesAndTotals,
  getBerthTypeFilterOptions,
  getDwellTimeSeries,
  getTopVisitingVessels,
} from '@/features/Ports/services/portCongestionApi';
import { CongestionTimeRangePreset } from '@/shared/components/CongestionTimeRangeDropdown';
import { useDebouncedEffect } from '@/shared/hooks/useDebouncedEffect';
import { useTopVisitingVessels } from '@/shared/hooks/useTopVisitingVessels';
import { PoleStarEntityGridRef } from '@/shared/lib/PoleStarEntityGrid';
import {
  ICongestionResponse,
  PeriodAggregation,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import {
  buildClassEntries,
  classKey,
  getSelectedFilters,
  VesselClassData,
} from '@/shared/utils/CongestionAndTrafficUtils';

const TIME_DOMAIN_KEY_TO_VALUE: Record<string, string> = {
  Day: 'Daily',
  Week: 'Weekly',
  Month: 'Monthly',
  Quarter: 'Quarterly',
};

const TIME_DOMAIN_VALUE_TO_KEY: Record<string, string> = Object.fromEntries(
  Object.entries(TIME_DOMAIN_KEY_TO_VALUE).map(([k, v]) => [v, k]),
);

export function getEnabledTimeDomainKeys(
  startIso: string,
  endIso: string,
): string[] {
  if (!startIso || !endIso) return ['Day'];
  const start = new Date(startIso.split('T')[0]);
  const end = new Date(endIso.split('T')[0]);
  const days = Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1;
  if (days <= 7) return ['Day'];
  if (days <= 60) return ['Day', 'Week'];
  if (days <= 90) return ['Day', 'Week', 'Month'];
  return ['Day', 'Week', 'Month', 'Quarter'];
}

function clampTimeDomain(current: string, enabledKeys: string[]): string {
  const currentKey = TIME_DOMAIN_VALUE_TO_KEY[current] ?? current;
  if (enabledKeys.includes(currentKey)) return current;
  const fallbackKey = enabledKeys[0] ?? 'Day';
  return TIME_DOMAIN_KEY_TO_VALUE[fallbackKey] ?? 'Daily';
}

export function usePortCongestion() {
  const { id } = useParams<{ id: string }>();
  const handleApiError = useApiErrorHandler();
  const gridRef = useRef<PoleStarEntityGridRef>(null);
  const isFetchingBerthFilters = useRef(false);
  const isFirstDwellRender = useRef(true);
  const vesselTypesOpts = [
    {
      value: 'Bulk carrier',
      defaultChecked: true,
      displayValue: 'Bulk Carrier',
    },
    {
      value: 'Bulk/Oil carrier',
      defaultChecked: true,
      displayValue: 'Bulk/Oil Carrier',
    },
    {
      value: 'Chemical Tanker',
      defaultChecked: true,
      displayValue: 'Chemical Tanker',
    },
    {
      value: 'Container (FC)',
      defaultChecked: true,
      displayValue: 'Container (FC)',
    },
    {
      value: 'Dry Cargo Barge',
      defaultChecked: true,
      displayValue: 'Dry Cargo Barge',
    },
    {
      value: 'General cargo',
      defaultChecked: true,
      displayValue: 'General Cargo',
    },
    {
      value: 'Liquified gas carrier',
      defaultChecked: true,
      displayValue: 'Liquified Gas Carrier (LNG)',
    },
    { value: 'Oil Tanker', defaultChecked: true, displayValue: 'Oil Tanker' },
    {
      value: 'Other tanker',
      defaultChecked: true,
      displayValue: 'Other Tanker',
    },
    {
      value: 'Specialsed Carrier',
      defaultChecked: true,
      displayValue: 'Specialised Carrier',
    },
    { value: 'Tank Barge', defaultChecked: true, displayValue: 'Tank Barge' },
  ] as const;
  const arrivalsAndDeparturesTabs = ['Totals'] as const;
  const [selectedBerthTypes, setSelectedBerthTypes] = useState<
    Record<string, boolean>
  >({});
  const [dateRangeLabel, setDateRangeLabel] =
    useState<CongestionTimeRangePreset>('Previous 30 Days');
  const [berthTypes, setBerthTypes] = useState<string[] | undefined>(undefined);
  const [activeArrivalsAndDeparturesTab, setActiveArrivalsAndDeparturesTab] =
    useState('Totals');

  const [selectedVesselType, _setSelectedVesselType] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('SelectedVesselType');
    if (stored) return JSON.parse(stored);
    return vesselTypesOpts.reduce<Record<string, boolean>>((acc, v) => {
      acc[v.value] = v.defaultChecked;
      return acc;
    }, {});
  });

  const [selectedCountries, _setSelectedCountries] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('SelectedCountries');
    if (stored) return JSON.parse(stored);
    return Object.keys(countries).reduce<Record<string, boolean>>(
      (acc, code) => {
        acc[code] = true;
        return acc;
      },
      {},
    );
  });

  const [selectedVesselClass, _setSelectedVesselClass] = useState<
    Record<string, boolean>
  >(() => {
    const stored = localStorage.getItem('SelectedVesselClass');
    if (stored) return JSON.parse(stored);
    const acc: Record<string, boolean> = {};
    vesselTypesOpts.forEach(({ value, defaultChecked }) => {
      if (defaultChecked && VesselClassData[value]) {
        VesselClassData[value].forEach(({ className }) => {
          acc[classKey(value, className)] = true;
        });
      }
    });
    return acc;
  });

  const [arrivalsAndDeparturesTimeDomain, _setArrivalsAndDeparturesTimeDomain] =
    useState(() => {
      return localStorage.getItem('ArrivalsAndDeparturesTimeDomain') ?? 'Daily';
    });

  const [arrivalsTimeDomain, _setArrivalsTimeDomain] = useState(() => {
    return localStorage.getItem('ArrivalsTimeDomain') ?? 'Daily';
  });

  const [dwellSeriesTimeDomain, _setDwellSeriesTimeDomain] = useState(() => {
    return localStorage.getItem('DwellSeriesTimeDomain') ?? 'Daily';
  });

  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const [arrivalAndDeparturesByTotals, setArrivalAndDeparturesByTotals] =
    useState<ICongestionResponse | undefined>(undefined);

  const [arrivalsByVesselTypes, setArrivalsByVesselTypes] = useState<
    ICongestionResponse | undefined
  >(undefined);

  const [arrivalsByVesselTypesAndTotals, setArrivalsByVesselTypesAndTotals] =
    useState<ICongestionResponse | undefined>(undefined);

  const [dwellSeries, setDwellSeries] = useState<
    ICongestionResponse | undefined
  >(undefined);

  const [
    isArrivalsByVesselTypesAndTotalsLoading,
    setIsArrivalsByVesselTypesAndTotalsLoading,
  ] = useState(false);

  const [isArrivalsByVesselTypesLoading, setIsArrivalsByVesselTypesLoading] =
    useState(false);

  const [
    isArrivalAndDeparturesByTotalsLoading,
    setIsArrivalAndDeparturesByTotalsLoading,
  ] = useState(false);

  const [isDwellSeriesLoading, setIsDwellSeriesLoading] = useState(false);

  const timeDomainEnabledKeys = useMemo(
    () => getEnabledTimeDomainKeys(dateRange.start, dateRange.end),
    [dateRange.start, dateRange.end],
  );

  const timeDomainDays = useMemo(() => {
    if (!dateRange.start || !dateRange.end) return undefined;
    const start = new Date(dateRange.start.split('T')[0]);
    const end = new Date(dateRange.end.split('T')[0]);
    return Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1;
  }, [dateRange.start, dateRange.end]);

  useEffect(() => {
    // Don't clamp until we actually have a date range
    if (!dateRange.start || !dateRange.end) return;

    _setArrivalsAndDeparturesTimeDomain((prev) =>
      clampTimeDomain(prev, timeDomainEnabledKeys),
    );
    _setArrivalsTimeDomain((prev) =>
      clampTimeDomain(prev, timeDomainEnabledKeys),
    );
    _setDwellSeriesTimeDomain((prev) =>
      clampTimeDomain(prev, timeDomainEnabledKeys),
    );
  }, [timeDomainEnabledKeys, dateRange.start, dateRange.end]);

  const setArrivalsAndDeparturesTimeDomain = (value: string) => {
    localStorage.setItem('ArrivalsAndDeparturesTimeDomain', value);
    _setArrivalsAndDeparturesTimeDomain(value);
  };

  const setArrivalsTimeDomain = (value: string) => {
    localStorage.setItem('ArrivalsTimeDomain', value);
    _setArrivalsTimeDomain(value);
  };

  const setDwellSeriesTimeDomain = (value: string) => {
    localStorage.setItem('DwellSeriesTimeDomain', value);
    _setDwellSeriesTimeDomain(value);
  };

  const setSelectedVesselType = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedVesselType((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('SelectedVesselType', JSON.stringify(next));
      return next;
    });
  };

  const setSelectedCountries = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedCountries((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('SelectedCountries', JSON.stringify(next));
      return next;
    });
  };

  const setSelectedVesselClass = (
    value:
      | Record<string, boolean>
      | ((prev: Record<string, boolean>) => Record<string, boolean>),
  ) => {
    _setSelectedVesselClass((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('SelectedVesselClass', JSON.stringify(next));
      return next;
    });
  };

  const handleVesselTypeToggle = (label: string, checked: boolean) => {
    setSelectedVesselType((prev) => ({ ...prev, [label]: checked }));
    if (checked) {
      setSelectedVesselClass((prev) => ({
        ...prev,
        ...buildClassEntries(label),
      }));
    } else {
      setSelectedVesselClass((prev) => {
        const next = { ...prev };
        (VesselClassData[label] ?? []).forEach(({ className }) => {
          next[classKey(label, className)] = false;
        });
        return next;
      });
    }
  };

  const handleCountryToggle = (code: string, checked: boolean) => {
    setSelectedCountries((prev) => {
      let next: Record<string, boolean>;
      if (code === 'All' && checked) {
        next = Object.keys(prev).reduce<Record<string, boolean>>((acc, k) => {
          acc[k] = k === 'All';
          return acc;
        }, {});
      } else if (code !== 'All' && checked) {
        next = { ...prev, All: false, [code]: true };
      } else {
        next = { ...prev, [code]: checked };
      }
      const hasSelection = Object.entries(next).some(
        ([k, v]) => k !== 'All' && v,
      );
      if (!hasSelection) {
        next = Object.keys(next).reduce<Record<string, boolean>>((acc, k) => {
          acc[k] = k === 'All';
          return acc;
        }, {});
      }
      return next;
    });
  };

  const handleVesselClassToggle = (className: string, checked: boolean) => {
    setSelectedVesselClass((prev) => ({ ...prev, [className]: checked }));
  };

  const handleBerthTypeToggle = useCallback((value: string) => {
    setSelectedBerthTypes((prev) => ({
      ...prev,
      [value]: !prev[value],
    }));
  }, []);

  const handleBerthTypeSelectAll = useCallback(() => {
    const allSelected = berthTypes?.every((bt) => selectedBerthTypes[bt]);
    setSelectedBerthTypes(
      Object.fromEntries((berthTypes ?? []).map((bt) => [bt, !allSelected])),
    );
  }, [berthTypes, selectedBerthTypes]);

  const { flags, vesselTypes, vesselClasses } = getSelectedFilters(
    selectedCountries,
    selectedVesselType,
    selectedVesselClass,
  );

  const flagStr = flags
    .filter((c) => c !== 'All')
    .join(',')
    .toUpperCase();

  const vesselTypeStr = vesselTypes.join(',');

  const vesselClassesStr = vesselClasses.join(',');

  const {
    getServerSideData: getTopVisitingVesselsServerSideData,
    topVisitingGridRef,
    isTopVisitingVesselsLoading,
    topVisitingVesselData,
    topVisitingVesselsResponse,
  } = useTopVisitingVessels(
    id,
    dateRange,
    flagStr,
    vesselTypeStr,
    vesselClassesStr,
    getTopVisitingVessels,
  );

  const arrivalsAndDeparturesTimeDomainDisplay =
    TIME_DOMAIN_VALUE_TO_KEY[arrivalsAndDeparturesTimeDomain] ?? 'day';

  const arrivalsTimeDomainDisplay =
    TIME_DOMAIN_VALUE_TO_KEY[arrivalsTimeDomain] ?? 'day';

  const hasSelectedVesselTypes =
    Object.values(selectedVesselType).filter(Boolean).length > 0;

  const fetchArrivalsAndDeparturesByTotals = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsArrivalAndDeparturesByTotalsLoading(true);
    try {
      const response = await getArrivalsAndDeparturesByTotals(
        id,
        'NONE',
        arrivalsAndDeparturesTimeDomain.toUpperCase() as PeriodAggregation,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setArrivalAndDeparturesByTotals(response);
    } catch (error) {
      setArrivalAndDeparturesByTotals(undefined);
      handleApiError(error);
    } finally {
      setIsArrivalAndDeparturesByTotalsLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    arrivalsAndDeparturesTimeDomain,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  const fetchArrivalsByVesselType = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsArrivalsByVesselTypesLoading(true);
    try {
      const response = await getArrivalsByVesselType(
        id,
        'VESSEL_TYPE',
        arrivalsTimeDomain.toUpperCase() as PeriodAggregation,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setArrivalsByVesselTypes(response);
    } catch (error) {
      setArrivalsByVesselTypes(undefined);
      handleApiError(error);
    } finally {
      setIsArrivalsByVesselTypesLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    arrivalsTimeDomain,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  const fetchArrivalsByTotalsAndVesselType = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    setIsArrivalsByVesselTypesAndTotalsLoading(true);
    try {
      const response = await getArrivalsByVesselTypesAndTotals(
        id,
        'VESSEL_TYPE',
        'NONE',
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      setArrivalsByVesselTypesAndTotals(response);
    } catch (error) {
      setArrivalsByVesselTypesAndTotals(undefined);
      handleApiError(error);
    } finally {
      setIsArrivalsByVesselTypesAndTotalsLoading(false);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    vesselClassesStr,
    flagStr,
    vesselTypeStr,
    handleApiError,
  ]);

  const fetchDwellTimeSeries = useCallback(
    async (berthTypesOverride?: string[], timeDomainOverride?: string) => {
      if (!id || !dateRange.start || !dateRange.end) return;
      setIsDwellSeriesLoading(true);

      const activeBerthTypes =
        berthTypesOverride ?? getSelected(selectedBerthTypes);

      // ✅ Always clamp against the current date range so that if the range
      // shrinks (e.g. a full year → 7 days) the domain resets to Daily
      // even before the clamping useEffect has flushed its state update.
      const enabledKeys = getEnabledTimeDomainKeys(
        dateRange.start,
        dateRange.end,
      );
      const effectiveTimeDomain = clampTimeDomain(
        timeDomainOverride ?? dwellSeriesTimeDomain,
        enabledKeys,
      );

      try {
        const response = await getDwellTimeSeries(
          id,
          'NONE',
          effectiveTimeDomain.toUpperCase() as PeriodAggregation, // ← was dwellSeriesTimeDomain
          dateRange.start.split('T')[0],
          dateRange.end.split('T')[0],
          vesselTypeStr,
          flagStr,
          vesselClassesStr,
          activeBerthTypes.join(','),
        );
        setDwellSeries(response);
      } catch (error) {
        setDwellSeries(undefined);
        handleApiError(error);
      } finally {
        setIsDwellSeriesLoading(false);
      }
    },
    [
      id,
      dateRange.start,
      dateRange.end,
      dwellSeriesTimeDomain,
      selectedBerthTypes,
      vesselClassesStr,
      flagStr,
      vesselTypeStr,
      handleApiError,
    ],
  );

  const fetchBerthFilters = useCallback(async () => {
    if (!id || !dateRange.start || !dateRange.end) return;
    isFetchingBerthFilters.current = true;
    try {
      const response = await getBerthTypeFilterOptions(
        id,
        dateRange.start.split('T')[0],
        dateRange.end.split('T')[0],
        vesselTypeStr,
        flagStr,
        vesselClassesStr,
      );
      const berthTypeList = response.berth_types;

      const allSelected = Object.fromEntries(
        berthTypeList.map((bt) => [bt, true]),
      );
      setBerthTypes(berthTypeList);
      setSelectedBerthTypes(allSelected);

      await fetchDwellTimeSeries(berthTypeList);
    } catch (e) {
      setBerthTypes(undefined);
      handleApiError(e);
    } finally {
      // Delay clearing by slightly more than the debounce window
      // so the selectedBerthTypes debounce is suppressed
      setTimeout(() => {
        isFetchingBerthFilters.current = false;
      }, 1200);
    }
  }, [
    id,
    dateRange.start,
    dateRange.end,
    vesselTypeStr,
    flagStr,
    vesselClassesStr,
    handleApiError,
    fetchDwellTimeSeries,
  ]);

  useEffect(() => {
    fetchArrivalsAndDeparturesByTotals();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end, arrivalsAndDeparturesTimeDomain]);

  useEffect(() => {
    fetchArrivalsByVesselType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end, arrivalsTimeDomain]);

  useEffect(() => {
    fetchArrivalsByTotalsAndVesselType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end]);

  useEffect(() => {
    fetchBerthFilters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, dateRange.start, dateRange.end]);

  // Re-fetch dwell series alone when its time domain changes (berth types already known)
  useEffect(() => {
    if (isFirstDwellRender.current) {
      isFirstDwellRender.current = false;
      return;
    }
    if (isFetchingBerthFilters.current) return;
    fetchDwellTimeSeries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dwellSeriesTimeDomain]);

  // Debounced fetch when filters change
  useDebouncedEffect(
    () => {
      fetchArrivalsAndDeparturesByTotals();
      fetchArrivalsByVesselType();
      fetchArrivalsByTotalsAndVesselType();
      fetchDwellTimeSeries();
    },
    [vesselTypeStr, flagStr, vesselClassesStr],
    1100,
  );
  useDebouncedEffect(
    () => {
      if (isFetchingBerthFilters.current) return;
      fetchDwellTimeSeries();
    },
    [selectedBerthTypes],
    1100,
  );

  const getServerSideData = useCallback(
    async (params: IServerSideGetRowsParams) => {
      if (!id || !dateRange.start || !dateRange.end) return;
      params.api.setGridOption('loading', true);
      const { startRow } = params.request;
      try {
        const response = await getBerths(
          id,
          dateRange.start.split('T')[0],
          dateRange.end.split('T')[0],
          startRow,
        );
        const flatRows = response.terminals.flatMap((terminal) =>
          terminal.berths.map((berth) => ({
            ...berth,
            terminal_name: terminal.terminal_name,
          })),
        );
        params.success({
          rowData: flatRows,
          rowCount: response.meta.total_count,
        });
        if (response.meta.total_count === 0) params.api.showNoRowsOverlay();
        else params.api.hideOverlay();
      } catch (e) {
        params.success({ rowData: [], rowCount: 0 });
        setTimeout(() => {
          params.api.showNoRowsOverlay();
        }, 0);
        handleApiError(e);
      } finally {
        params.api.setGridOption('loading', false);
      }
    },
    [id, dateRange.start, dateRange.end, handleApiError],
  );

  return {
    vesselTypesOpts,
    arrivalsAndDeparturesTabs,
    activeArrivalsAndDeparturesTab,
    setActiveArrivalsAndDeparturesTab,
    selectedVesselType,
    handleVesselTypeToggle,
    selectedCountries,
    handleCountryToggle,
    selectedVesselClass,
    handleVesselClassToggle,
    hasSelectedVesselTypes,
    arrivalsAndDeparturesTimeDomain,
    setArrivalsAndDeparturesTimeDomain,
    arrivalsTimeDomain,
    setArrivalsTimeDomain,
    dateRange,
    setDateRange,
    timeDomainDays,
    timeDomainEnabledKeys,
    arrivalAndDeparturesByTotals,
    arrivalsByVesselTypes,
    arrivalsByVesselTypesAndTotals,
    fetchArrivalsAndDeparturesByTotals,
    fetchArrivalsByTotalsAndVesselType,
    fetchArrivalsByVesselType,
    fetchDwellTimeSeries,
    fetchBerthFilters,
    arrivalsAndDeparturesTimeDomainDisplay,
    arrivalsTimeDomainDisplay,
    isArrivalAndDeparturesByTotalsLoading,
    isArrivalsByVesselTypesLoading,
    isArrivalsByVesselTypesAndTotalsLoading,
    gridRef,
    getServerSideData,
    dwellSeriesTimeDomain,
    setDwellSeriesTimeDomain,
    berthTypes,
    selectedBerthTypes,
    handleBerthTypeToggle,
    handleBerthTypeSelectAll,
    dwellSeries,
    isDwellSeriesLoading,
    getTopVisitingVesselsServerSideData,
    topVisitingGridRef,
    isTopVisitingVesselsLoading,
    topVisitingVesselData,
    setDateRangeLabel,
    dateRangeLabel,
    topVisitingVesselsResponse,
  };
}
