// features/Ports/hooks/usePortDetails.ts
import { useCallback, useEffect, useRef, useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { toggleBookmark } from '@/features/library/services/libraryApi';
import {
  createPortSubscription,
  fetchPortBoundary,
  fetchPortDetails,
  fetchPortSubscriptions,
  updatePortSubscription,
} from '@/features/Ports/services/portServices';
import { SEVERITY_KEY_BY_LABEL } from '@/shared/components/ScreeningSettings';
import { useEntityDetails } from '@/shared/hooks/useEntityDetails';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { Port } from '@/shared/types/entities';
import {
  ISubscription,
  ScheduleType,
  SeverityFilter,
  SubscriptionResponseDataType,
} from '@/shared/types/subscriptionTypes';
import { localToUtc } from '@/shared/utils/formatUtils';

export function usePortDetails() {
  const {
    id,
    entity,
    loading,
    error,
    refresh,
    setRefresh,
    dateRange,
    setDateRange,
  } = useEntityDetails<Port>(fetchPortDetails);

  const { bookmarks, fetchSavedEntities } = useLibrary();
  const handleApiError = useApiErrorHandler();
  const [toggleBookmarkLoading, setToggleBookmarkLoading] = useState(false);
  const [portBoundary, setPortBoundary] = useState<
    Omit<Port, 'centroid'> | undefined
  >(undefined);
  const { showToast } = useToastNotification();
  const [subscriptionData, setSubscriptionData] =
    useState<SubscriptionResponseDataType>();

  const pendingBodyRef = useRef<ISubscription | null>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const subscriptionId =
    bookmarks.find((bookmark) => bookmark.entityRefId === id)?.subscription
      .subscription_id || '';

  const isBookmarked = (refId: string | undefined) =>
    bookmarks?.some(
      (bm) =>
        bm.entityRefId === refId && bm.entityType.toLowerCase() === 'port',
    );

  const addOrRemoveBookmark = async (refId: string) => {
    setToggleBookmarkLoading(true);
    try {
      const method = isBookmarked(refId) ? 'remove' : 'add';
      await toggleBookmark(method, {
        id: refId,
        type: 'port',
      });
      showToast(
        'success',
        `${entity?.name} ${isBookmarked(refId) ? 'removed from' : 'added to'} bookmarks`,
        5000,
      );
      fetchSavedEntities();
    } catch (err) {
      handleApiError(err);
    } finally {
      setToggleBookmarkLoading(false);
    }
  };

  const getPortBoundary = useCallback(async () => {
    if (!id) return;
    setPortBoundary(undefined);
    try {
      const response = await fetchPortBoundary(id);
      setPortBoundary(response);
    } catch (err) {
      handleApiError(err);
      setPortBoundary(undefined);
    }
  }, [id, handleApiError]);

  useEffect(() => {
    getPortBoundary();
  }, [getPortBoundary]);

  const getSubscription = useCallback(async () => {
    if (!subscriptionId) {
      return setSubscriptionData({
        subscription_exists: false,
        subscription_id: null,
        name: null,
        active: false,
        notify_on: {
          PORT_AREA_DEPARTURE: false,
          PORT_AREA_ARRIVAL: false,
          PORT_ARRIVAL: false,
          PORT_DEPARTURE: false,
        },
        vessel_screening: {
          active: false,
          severity_filter: [],
        },
        email_settings: {
          email_enabled: false,
          scheduler: {
            schedule_type: 1,
            at_time: localToUtc('08:00'),
          },
        },
      });
    }
    try {
      const data = await fetchPortSubscriptions(subscriptionId);
      setSubscriptionData(data);
    } catch (err) {
      handleApiError(err);
    }
  }, [subscriptionId, handleApiError]);

  useEffect(() => {
    getSubscription();
  }, [getSubscription]);

  useEffect(() => {
    fetchSavedEntities();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subscriptionData?.active]);

  const manageSubscription = async (checked: boolean, label: string) => {
    try {
      // Create new subscription if none exists
      if (!subscriptionData?.subscription_exists) {
        const body: ISubscription = {
          entity_ref_id: entity?.id,
          entity_type: 'PORT',
          name: entity?.name,
          active: checked,
          notify_on: {
            PORT_ARRIVAL: checked,
            PORT_DEPARTURE: checked,
            PORT_AREA_DEPARTURE: checked,
            PORT_AREA_ARRIVAL: checked,
          },
          vessel_screening: { active: false, severity_filter: [] },
          email_settings: {
            email_enabled: false,
            scheduler: { schedule_type: 1, at_time: localToUtc('08:00') },
          },
        };
        const data = await createPortSubscription(body);
        setSubscriptionData(data);
        return;
      }

      // Base body from current subscription
      const baseBody = (): ISubscription => {
        const source = pendingBodyRef.current ?? subscriptionData;
        return {
          entity_ref_id: entity?.id,
          entity_type: 'PORT',
          name: entity?.name,
          active: source.active,
          notify_on: { ...source.notify_on },
          vessel_screening: { ...source.vessel_screening },
          email_settings: {
            email_enabled: source.email_settings.email_enabled,
            scheduler: { ...source.email_settings.scheduler },
          },
        };
      };

      let body: ISubscription;

      // Handle prefixed labels first
      if (label.startsWith('Frequency:')) {
        const scheduleType = parseInt(label.split(':')[1]) as ScheduleType;
        body = baseBody();
        body.email_settings.scheduler.schedule_type = scheduleType;
      } else if (label.startsWith('SendAt:')) {
        const newTime = label.split(':').slice(1).join(':');
        body = baseBody();
        body.email_settings.scheduler.at_time = newTime;
      } else if (['Critical', 'OK', 'Warning', 'Unscored'].includes(label)) {
        const severityKey = SEVERITY_KEY_BY_LABEL[label] as SeverityFilter;
        const source = pendingBodyRef.current ?? subscriptionData;
        const currentFilters = source.vessel_screening.severity_filter ?? [];
        const newFilters = checked
          ? [...currentFilters, severityKey]
          : currentFilters.filter((f) => f !== severityKey);

        body = baseBody();
        body.vessel_screening = {
          active: newFilters.length > 0,
          severity_filter: newFilters,
        };
      } else {
        // Handle static labels with switch
        switch (label) {
          case 'Live Notifications':
            body = {
              ...baseBody(),
              active: checked,
              notify_on: {
                PORT_ARRIVAL: checked,
                PORT_DEPARTURE: checked,
                PORT_AREA_DEPARTURE: checked,
                PORT_AREA_ARRIVAL: checked,
              },
              vessel_screening: { active: false, severity_filter: [] },
              email_settings: {
                email_enabled: false,
                scheduler: { schedule_type: 1, at_time: localToUtc('08:00') },
              },
            };
            break;

          case 'Auto-Screen Vessels':
            body = baseBody();
            body.vessel_screening = {
              active: checked,
              severity_filter: checked
                ? ['CRITICAL', 'OK', 'UNSCORED', 'WARNING']
                : [],
            };
            break;

          case 'Area Arrivals':
            body = baseBody();
            body.notify_on.PORT_AREA_ARRIVAL = checked;
            if (!checked) {
              body.vessel_screening = { active: false, severity_filter: [] };
            }
            break;

          case 'Area Departures':
            body = baseBody();
            body.notify_on.PORT_AREA_DEPARTURE = checked;
            break;

          case 'Arrivals':
            body = baseBody();
            body.notify_on.PORT_ARRIVAL = checked;
            break;

          case 'Departures':
            body = baseBody();
            body.notify_on.PORT_DEPARTURE = checked;
            break;

          case 'Email Notifications':
            body = baseBody();
            body.email_settings.email_enabled = checked;
            break;

          case 'Timing':
            body = baseBody();
            body.email_settings.scheduler.schedule_type = checked ? 0 : 1;
            break;

          default:
            return;
        }
      }

      pendingBodyRef.current = body;

      // Clear existing timer
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }

      debounceTimerRef.current = setTimeout(async () => {
        const finalBody = pendingBodyRef.current;
        if (!finalBody) return;

        pendingBodyRef.current = null;

        try {
          const data = await updatePortSubscription(finalBody, subscriptionId);
          setSubscriptionData(data);
        } catch (err) {
          handleApiError(err);
        }
      }, 900);
    } catch (err) {
      handleApiError(err);
    }
  };

  return {
    id,
    port: entity,
    loading,
    error,
    refresh,
    setRefresh,
    dateRange,
    setDateRange,
    toggleBookmarkLoading,
    isBookmarked,
    addOrRemoveBookmark,
    subscriptionData,
    manageSubscription,
    getSubscription,
    portBoundary,
  };
}
