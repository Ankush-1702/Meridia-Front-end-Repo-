import { useCallback, useMemo, useState } from 'react';
import { useParams } from 'react-router';
import {
  getArrivalsAndDeparturesByTotals,
  getLivePortCongestionData,
} from '../services/portCongestionApi';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  ICongestionResponse,
  ILiveDataResponse,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { endOfUtcDay, startOfUtcDay } from '@/shared/utils/formatUtils';

// const VALID_VESSEL_TYPES = [
//   'Bulk carrier',
//   'Bulk/Oil carrier',
//   'Chemical Tanker',
//   'Container (FC)',
//   'Dry Cargo Barge',
//   'General cargo',
//   'Liquified gas carrier',
//   'Oil Tanker',
//   'Other tanker',
//   'Specialsed Carrier',
//   'Tank Barge',
// ];

// const VALID_VESSEL_TYPES_LOWER = VALID_VESSEL_TYPES.map((v) => v.toLowerCase());

export function useLivePortTraffic() {
  const { id } = useParams<{ id: string }>();
  const [livePortData, setLivePortData] = useState<
    ILiveDataResponse | undefined
  >(undefined);
  const [last30DaysData, setLast30DaysData] = useState<
    ICongestionResponse | undefined
  >(undefined);
  const [loadingCount, setLoadingCount] = useState(0);
  const { startDate, endDate } = useMemo(() => {
    const nowUtc = new Date();
    const toIsoSec = (d: Date) => d.toISOString().slice(0, 19) + 'Z';

    const e = new Date(nowUtc);
    e.setUTCDate(e.getUTCDate() - 1);
    const end = endOfUtcDay(e);
    const s = new Date(e);
    s.setUTCDate(s.getUTCDate() - 29);
    const start = startOfUtcDay(s);

    return {
      startDate: toIsoSec(start).split('T')[0],
      endDate: toIsoSec(end).split('T')[0],
    };
  }, []);

  const handleApiError = useApiErrorHandler();

  const fetchLivePortTraffic = useCallback(async () => {
    setLoadingCount((c) => c + 1);
    try {
      const data = await getLivePortCongestionData(id!);
      setLivePortData(data);
    } catch (error) {
      handleApiError(error);
      setLivePortData(undefined);
    } finally {
      setLoadingCount((c) => c - 1);
    }
  }, [id, handleApiError]);

  const fetchLast30DaysData = useCallback(async () => {
    setLoadingCount((c) => c + 1);
    try {
      const data = await getArrivalsAndDeparturesByTotals(
        id!,
        'NONE',
        'DAILY',
        startDate,
        endDate,
      );
      setLast30DaysData(data);
    } catch (error) {
      handleApiError(error);
      setLast30DaysData(undefined);
    } finally {
      setLoadingCount((c) => c - 1);
    }
  }, [id, handleApiError, startDate, endDate]);

  const isLoading = loadingCount > 0;

  return {
    livePortData,
    isLoading,
    last30DaysData,
    fetchLast30DaysData,
    fetchLivePortTraffic,
  };
}
