import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import * as useApiErrorHandlerModule from '@/app/hooks/useApiErrorHandler';
import {
  usePortCongestion,
  getEnabledTimeDomainKeys,
} from '@/features/Ports/hooks/usePortCongestion';
import * as portCongestionApi from '@/features/Ports/services/portCongestionApi';
import * as useTopVisitingVesselsModule from '@/shared/hooks/useTopVisitingVessels';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import * as CongestionUtils from '@/shared/utils/CongestionAndTrafficUtils';

vi.mock('react-router', () => ({
  useParams: () => ({ id: 'test-port-123' }),
}));

vi.mock('../../services/portCongestionApi');

vi.mock('@/app/hooks/useApiErrorHandler');

vi.mock('@/shared/hooks/useTopVisitingVessels', () => ({
  useTopVisitingVessels: vi.fn(() => ({
    topVisitingGridRef: { current: null },
    getServerSideData: vi.fn(),
    isTopVisitingVesselsLoading: false,
    topVisitingVesselData: undefined,
  })),
}));

vi.mock('@/features/Ports/Berth/services/berthServices', () => ({
  getBerths: vi.fn().mockResolvedValue({
    terminals: [],
    meta: { total_count: 0 },
  }),
}));

vi.mock('../useDebouncedEffect', () => ({
  useDebouncedEffect: vi.fn(),
}));

vi.mock('@/features/library/utils/countryMapping', () => ({
  countries: {
    All: 'All Countries',
    US: 'United States',
    GB: 'United Kingdom',
  },
}));

const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: vi.fn((key: string) => store[key] || null),
    setItem: vi.fn((key: string, value: string) => {
      store[key] = value;
    }),
    clear: vi.fn(() => {
      store = {};
    }),
    removeItem: vi.fn((key: string) => {
      delete store[key];
    }),
  };
})();

Object.defineProperty(window, 'localStorage', { value: localStorageMock });

describe('usePortCongestion', () => {
  const mockHandleApiError = vi.fn();

  const mockCongestionResponse: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: {
      id: 'test-port-123',
      name: 'Test Port',
      unlocode: 'TSTPT',
      country_common_name: 'Test Country',
    },
    totals: {
      arrivals: 300,
      departures: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', arrivals: 10, departures: 8 }],
      },
    ],
  };

  beforeEach(() => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    localStorageMock.clear();
    (useApiErrorHandlerModule.useApiErrorHandler as Mock).mockReturnValue(
      mockHandleApiError,
    );
    (
      portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
    ).mockResolvedValue(mockCongestionResponse);
    (portCongestionApi.getArrivalsByVesselType as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    (
      portCongestionApi.getArrivalsByVesselTypesAndTotals as Mock
    ).mockResolvedValue(mockCongestionResponse);
    (portCongestionApi.getBerthTypeFilterOptions as Mock).mockResolvedValue({
      berth_types: [],
    });
    (portCongestionApi.getDwellTimeSeries as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    (portCongestionApi.getTopVisitingVessels as Mock).mockResolvedValue(
      mockCongestionResponse,
    );
    vi.spyOn(CongestionUtils, 'getSelectedFilters').mockReturnValue({
      flags: ['All'],
      vesselTypes: ['Bulk carrier'],
      vesselClasses: ['Handysize'],
      gtRange: { max: Infinity, min: 0 },
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
    vi.useRealTimers();
  });

  describe('getEnabledTimeDomainKeys', () => {
    it('should return ["Day"] for empty dates', () => {
      expect(getEnabledTimeDomainKeys('', '')).toEqual(['Day']);
    });

    it('should return ["Day"] for 7 days or less', () => {
      expect(getEnabledTimeDomainKeys('2026-03-01', '2026-03-07')).toEqual([
        'Day',
      ]);
    });

    it('should return ["Day", "Week"] for 8-60 days', () => {
      expect(getEnabledTimeDomainKeys('2026-01-01', '2026-02-15')).toEqual([
        'Day',
        'Week',
      ]);
    });

    it('should return ["Day", "Week", "Month"] for 61-90 days', () => {
      expect(getEnabledTimeDomainKeys('2026-01-01', '2026-03-15')).toEqual([
        'Day',
        'Week',
        'Month',
      ]);
    });

    it('should return all options for more than 90 days', () => {
      expect(getEnabledTimeDomainKeys('2025-01-01', '2026-03-09')).toEqual([
        'Day',
        'Week',
        'Month',
        'Quarter',
      ]);
    });
  });

  describe('initialization', () => {
    it('should initialize with default values', async () => {
      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.activeArrivalsAndDeparturesTab).toBe('Totals');
      expect(result.current.arrivalsAndDeparturesTimeDomain).toBe('Daily');
      expect(result.current.arrivalsTimeDomain).toBe('Daily');
      expect(result.current.dateRange).toEqual({ start: '', end: '' });
      expect(result.current.vesselTypesOpts).toHaveLength(11);
    });

    it('should load vessel types from localStorage', async () => {
      const storedVesselTypes = { 'Bulk carrier': true, 'Oil Tanker': false };
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'SelectedVesselType')
          return JSON.stringify(storedVesselTypes);
        return null;
      });

      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.selectedVesselType).toEqual(storedVesselTypes);
    });

    it('should load countries from localStorage', async () => {
      const storedCountries = { All: false, US: true };
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'SelectedCountries') return JSON.stringify(storedCountries);
        return null;
      });

      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.selectedCountries).toEqual(storedCountries);
    });

    it('should load time domain from localStorage', async () => {
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'ArrivalsAndDeparturesTimeDomain') return 'Weekly';
        if (key === 'ArrivalsTimeDomain') return 'Monthly';
        return null;
      });

      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.arrivalsAndDeparturesTimeDomain).toBe('Weekly');
      expect(result.current.arrivalsTimeDomain).toBe('Monthly');
    });
  });

  describe('setters', () => {
    it('should update activeArrivalsAndDeparturesTab', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setActiveArrivalsAndDeparturesTab('Totals');
      });

      expect(result.current.activeArrivalsAndDeparturesTab).toBe('Totals');
    });

    it('should update arrivalsAndDeparturesTimeDomain and persist to localStorage', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setArrivalsAndDeparturesTimeDomain('Weekly');
      });

      expect(result.current.arrivalsAndDeparturesTimeDomain).toBe('Weekly');
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'ArrivalsAndDeparturesTimeDomain',
        'Weekly',
      );
    });

    it('should update arrivalsTimeDomain and persist to localStorage', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setArrivalsTimeDomain('Monthly');
      });

      expect(result.current.arrivalsTimeDomain).toBe('Monthly');
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'ArrivalsTimeDomain',
        'Monthly',
      );
    });

    it('should update dateRange', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      expect(result.current.dateRange).toEqual({
        start: '2026-01-01',
        end: '2026-03-01',
      });
    });
  });

  describe('handleVesselTypeToggle', () => {
    it('should toggle vessel type and persist to localStorage', async () => {
      vi.spyOn(CongestionUtils, 'buildClassEntries').mockReturnValue({
        'Oil Tanker::VLCC': true,
      });

      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.handleVesselTypeToggle('Oil Tanker', true);
      });

      expect(result.current.selectedVesselType['Oil Tanker']).toBe(true);
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'SelectedVesselType',
        expect.any(String),
      );
    });

    it('should disable vessel classes when vessel type is unchecked', async () => {
      vi.spyOn(CongestionUtils, 'VesselClassData', 'get').mockReturnValue({
        'Oil Tanker': [{ className: 'VLCC', gtRange: '200000-320000' }],
      });
      vi.spyOn(CongestionUtils, 'classKey').mockImplementation(
        (type, className) => `${type}::${className}`,
      );

      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.handleVesselTypeToggle('Oil Tanker', false);
      });

      expect(result.current.selectedVesselType['Oil Tanker']).toBe(false);
    });
  });

  describe('handleCountryToggle', () => {
    it('should select All and deselect others when All is checked', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.handleCountryToggle('All', true);
      });

      expect(result.current.selectedCountries['All']).toBe(true);
    });

    it('should deselect All when specific country is selected', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.handleCountryToggle('US', true);
      });

      expect(result.current.selectedCountries['All']).toBe(false);
      expect(result.current.selectedCountries['US']).toBe(true);
    });

    it('should revert to All when no countries are selected', async () => {
      const { result } = renderHook(() => usePortCongestion());

      // Deselect all non-All countries
      act(() => {
        result.current.handleCountryToggle('US', false);
      });

      act(() => {
        result.current.handleCountryToggle('GB', false);
      });

      expect(result.current.selectedCountries['All']).toBe(true);
      expect(result.current.selectedCountries['US']).toBe(false);
      expect(result.current.selectedCountries['GB']).toBe(false);
    });
  });

  describe('handleVesselClassToggle', () => {
    it('should toggle vessel class and persist to localStorage', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.handleVesselClassToggle('Bulk carrier::Handysize', true);
      });

      expect(
        result.current.selectedVesselClass['Bulk carrier::Handysize'],
      ).toBe(true);
      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'SelectedVesselClass',
        expect.any(String),
      );
    });
  });

  describe('API fetching', () => {
    it('should fetch arrivals and departures by totals when dateRange is set', async () => {
      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        portCongestionApi.getArrivalsAndDeparturesByTotals,
      ).toHaveBeenCalled();
    });

    it('should not fetch when dateRange is empty', async () => {
      renderHook(() => usePortCongestion());

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        portCongestionApi.getArrivalsAndDeparturesByTotals,
      ).not.toHaveBeenCalled();
    });

    it('should handle API error for arrivals and departures', async () => {
      const testError = new Error('API Error');
      (
        portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
      ).mockRejectedValue(testError);

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.arrivalAndDeparturesByTotals).toBeUndefined();
    });

    it('should handle API error for arrivals by vessel type', async () => {
      const testError = new Error('Vessel Type API Error');
      (portCongestionApi.getArrivalsByVesselType as Mock).mockRejectedValue(
        testError,
      );

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.arrivalsByVesselTypes).toBeUndefined();
    });

    it('should handle API error for arrivals by vessel types and totals', async () => {
      const testError = new Error('Totals API Error');
      (
        portCongestionApi.getArrivalsByVesselTypesAndTotals as Mock
      ).mockRejectedValue(testError);

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(mockHandleApiError).toHaveBeenCalledWith(testError);
      expect(result.current.arrivalsByVesselTypesAndTotals).toBeUndefined();
    });

    it('should set loading states during fetch', async () => {
      let resolveArrivals: (value: ICongestionResponse) => void;
      (
        portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
      ).mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveArrivals = resolve;
          }),
      );

      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.isArrivalAndDeparturesByTotalsLoading).toBe(true);

      await act(async () => {
        resolveArrivals!(mockCongestionResponse);
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.isArrivalAndDeparturesByTotalsLoading).toBe(false);
    });
  });

  describe('computed values', () => {
    it('should compute timeDomainDays correctly', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-03-01', end: '2026-03-10' });
      });

      expect(result.current.timeDomainDays).toBe(10);
    });

    it('should return undefined for timeDomainDays when no date range', async () => {
      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.timeDomainDays).toBeUndefined();
    });

    it('should compute hasSelectedVesselTypes correctly', async () => {
      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.hasSelectedVesselTypes).toBe(true);
    });

    it('should compute time domain display values', async () => {
      const { result } = renderHook(() => usePortCongestion());

      expect(result.current.arrivalsAndDeparturesTimeDomainDisplay).toBe(
        'Week',
      );
      expect(result.current.arrivalsTimeDomainDisplay).toBe('Month');
    });
  });

  describe('fetch functions', () => {
    it('should call fetchArrivalsAndDeparturesByTotals', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchArrivalsAndDeparturesByTotals();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        portCongestionApi.getArrivalsAndDeparturesByTotals,
      ).toHaveBeenCalledWith(
        'test-port-123',
        'NONE',
        'WEEKLY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });

    it('should call fetchArrivalsByVesselType', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchArrivalsByVesselType();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(portCongestionApi.getArrivalsByVesselType).toHaveBeenCalledWith(
        'test-port-123',
        'VESSEL_TYPE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });

    it('should call fetchArrivalsByTotalsAndVesselType', async () => {
      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
      });

      await act(async () => {
        await result.current.fetchArrivalsByTotalsAndVesselType();
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        portCongestionApi.getArrivalsByVesselTypesAndTotals,
      ).toHaveBeenCalledWith(
        'test-port-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        '',
        'Handysize',
      );
    });
  });

  describe('time domain clamping', () => {
    it('should clamp time domain when date range changes', async () => {
      localStorageMock.getItem.mockImplementation((key: string) => {
        if (key === 'ArrivalsAndDeparturesTimeDomain') return 'Quarterly';
        if (key === 'ArrivalsTimeDomain') return 'Quarterly';
        return null;
      });

      const { result } = renderHook(() => usePortCongestion());

      act(() => {
        result.current.setDateRange({ start: '2026-03-01', end: '2026-03-07' });
      });

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.arrivalsAndDeparturesTimeDomain).toBe('Daily');
      expect(result.current.arrivalsTimeDomain).toBe('Daily');
    });
  });

  describe('top visiting vessels integration', () => {
    it('should expose topVisitingGridRef from useTopVisitingVessels', () => {
      const { result } = renderHook(() => usePortCongestion());
      expect(result.current.topVisitingGridRef).toBeDefined();
    });

    it('should expose getTopVisitingVesselsServerSideData from useTopVisitingVessels', () => {
      const { result } = renderHook(() => usePortCongestion());
      expect(result.current.getTopVisitingVesselsServerSideData).toBeDefined();
    });

    it('should expose isTopVisitingVesselsLoading from useTopVisitingVessels', () => {
      const { result } = renderHook(() => usePortCongestion());
      expect(result.current.isTopVisitingVesselsLoading).toBe(false);
    });

    it('should expose topVisitingVesselData from useTopVisitingVessels', () => {
      const { result } = renderHook(() => usePortCongestion());
      expect(result.current.topVisitingVesselData).toBeUndefined();
    });

    it('should pass id, dateRange, flagStr, vesselTypeStr, vesselClassesStr and fetchFn to useTopVisitingVessels', () => {
      renderHook(() => usePortCongestion());

      expect(
        useTopVisitingVesselsModule.useTopVisitingVessels,
      ).toHaveBeenCalledWith(
        'test-port-123',
        { start: '', end: '' },
        expect.any(String),
        expect.any(String),
        expect.any(String),
        expect.any(Function),
      );
    });
  });

  describe('fetchBerthFilters', () => {
    it('should call getBerthTypeFilterOptions when dateRange is set', async () => {
      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(portCongestionApi.getBerthTypeFilterOptions).toHaveBeenCalledWith(
        'test-port-123',
        '2026-01-01',
        '2026-03-01',
        expect.any(String),
        expect.any(String),
        expect.any(String),
      );
    });

    it('should not call getBerthTypeFilterOptions when dateRange is empty', async () => {
      renderHook(() => usePortCongestion());

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(
        portCongestionApi.getBerthTypeFilterOptions,
      ).not.toHaveBeenCalled();
    });

    it('should set berthTypes after successful fetch', async () => {
      (portCongestionApi.getBerthTypeFilterOptions as Mock).mockResolvedValue({
        berth_types: ['General', 'Container'],
      });

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.berthTypes).toEqual(['General', 'Container']);
    });

    it('should set berthTypes to undefined on error', async () => {
      (portCongestionApi.getBerthTypeFilterOptions as Mock).mockRejectedValue(
        new Error('fetch failed'),
      );

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.berthTypes).toBeUndefined();
      expect(mockHandleApiError).toHaveBeenCalled();
    });
  });

  describe('fetchDwellTimeSeries', () => {
    it('should call getDwellTimeSeries when dateRange is set', async () => {
      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(portCongestionApi.getDwellTimeSeries).toHaveBeenCalled();
    });

    it('should not call getDwellTimeSeries when dateRange is empty', async () => {
      renderHook(() => usePortCongestion());

      await act(async () => {
        await vi.runOnlyPendingTimersAsync();
      });

      expect(portCongestionApi.getDwellTimeSeries).not.toHaveBeenCalled();
    });

    it('should set dwellSeries after successful fetch', async () => {
      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.dwellSeries).toEqual(mockCongestionResponse);
    });

    it('should set dwellSeries to undefined on error', async () => {
      (portCongestionApi.getDwellTimeSeries as Mock).mockRejectedValue(
        new Error('dwell fetch failed'),
      );

      const { result } = renderHook(() => usePortCongestion());

      await act(async () => {
        result.current.setDateRange({ start: '2026-01-01', end: '2026-03-01' });
        await vi.runOnlyPendingTimersAsync();
      });

      expect(result.current.dwellSeries).toBeUndefined();
    });
  });
});
