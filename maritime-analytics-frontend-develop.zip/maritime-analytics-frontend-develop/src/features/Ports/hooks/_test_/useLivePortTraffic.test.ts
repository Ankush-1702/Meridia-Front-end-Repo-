import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import * as useApiErrorHandlerModule from '@/app/hooks/useApiErrorHandler';
import { useLivePortTraffic } from '@/features/Ports/hooks/useLivePortTraffic';
import * as portCongestionApi from '@/features/Ports/services/portCongestionApi';
import {
  ICongestionResponse,
  ILiveDataResponse,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

vi.mock('react-router', () => ({
  useParams: () => ({ id: 'test-port-123' }),
}));

vi.mock('@/features/Ports/services/portCongestionApi');

vi.mock('@/app/hooks/useApiErrorHandler');

vi.mock('@/shared/utils/formatUtils', () => ({
  startOfUtcDay: (d: Date) => {
    const result = new Date(d);
    result.setUTCHours(0, 0, 0, 0);
    return result;
  },
  endOfUtcDay: (d: Date) => {
    const result = new Date(d);
    result.setUTCHours(23, 59, 59, 999);
    return result;
  },
  clampEnd: (d: Date) => d,
}));

describe('useLivePortTraffic', () => {
  const mockHandleApiError = vi.fn();

  const mockLiveData: ILiveDataResponse = {
    meta: {
      timestamp_start: '2026-03-09T00:00:00Z',
      timestamp_end: '2026-03-09T10:00:00Z',
      request_id: 'req-live-123',
    },
    location_information: {
      id: 'test-port-123',
      name: 'Test Port',
      unlocode: 'TSTPT',
      country_common_name: 'Test Country',
    },
    totals: {
      arrivals: 15,
      departures: 12,
      vessels_per_day: 27,
      max_vessels_per_day: 35,
      by_vessel_type: [
        { group_by_key: 'Bulk carrier', arrivals: 10, departures: 8 },
        { group_by_key: 'Oil Tanker', arrivals: 5, departures: 4 },
      ],
    },
    data: [
      {
        period_key: '2026-03-09',
        items: [{ group_by_key: 'Bulk carrier', arrivals: 10, departures: 8 }],
      },
    ],
  };

  const mockCongestionData: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-congestion-456',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: {
      id: 'test-port-123',
      name: 'Test Port',
      unlocode: 'TSTPT',
      country_common_name: 'Test Country',
    },
    totals: {
      arrivals: 300,
      departures: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', arrivals: 10, departures: 8 }],
      },
    ],
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useApiErrorHandlerModule.useApiErrorHandler as Mock).mockReturnValue(
      mockHandleApiError,
    );
    (portCongestionApi.getLivePortCongestionData as Mock).mockResolvedValue(
      mockLiveData,
    );
    (
      portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
    ).mockResolvedValue(mockCongestionData);
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it('should initialize with undefined data and not loading', () => {
    const { result } = renderHook(() => useLivePortTraffic());

    expect(result.current.livePortData).toBeUndefined();
    expect(result.current.last30DaysData).toBeUndefined();
    expect(result.current.isLoading).toBe(false);
  });

  it('should fetch live port data when fetchLivePortTraffic is called', async () => {
    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await result.current.fetchLivePortTraffic();
    });

    expect(portCongestionApi.getLivePortCongestionData).toHaveBeenCalledWith(
      'test-port-123',
    );
    expect(result.current.livePortData).toEqual(mockLiveData);
    expect(result.current.isLoading).toBe(false);
  });

  it('should fetch last 30 days data when fetchLast30DaysData is called', async () => {
    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await result.current.fetchLast30DaysData();
    });

    expect(
      portCongestionApi.getArrivalsAndDeparturesByTotals,
    ).toHaveBeenCalledWith(
      'test-port-123',
      'NONE',
      'DAILY',
      expect.any(String),
      expect.any(String),
    );
    expect(result.current.last30DaysData).toEqual(mockCongestionData);
    expect(result.current.isLoading).toBe(false);
  });

  it('should show loading state while fetching data', async () => {
    let resolveLive: (value: ILiveDataResponse) => void;
    let resolveCongestion: (value: ICongestionResponse) => void;

    (portCongestionApi.getLivePortCongestionData as Mock).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveLive = resolve;
        }),
    );
    (
      portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
    ).mockImplementation(
      () =>
        new Promise((resolve) => {
          resolveCongestion = resolve;
        }),
    );

    const { result } = renderHook(() => useLivePortTraffic());

    // Start the fetch
    act(() => {
      result.current.fetchLivePortTraffic();
      result.current.fetchLast30DaysData();
    });

    // Wait for loading state to be true
    await waitFor(() => {
      expect(result.current.isLoading).toBe(true);
    });

    await act(async () => {
      resolveLive!(mockLiveData);
      resolveCongestion!(mockCongestionData);
    });

    expect(result.current.isLoading).toBe(false);
  });

  it('should handle API error for live port data', async () => {
    const testError = new Error('API Error');
    (portCongestionApi.getLivePortCongestionData as Mock).mockRejectedValue(
      testError,
    );

    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await result.current.fetchLivePortTraffic();
    });

    expect(mockHandleApiError).toHaveBeenCalledWith(testError);
    expect(result.current.livePortData).toBeUndefined();
    expect(result.current.isLoading).toBe(false);
  });

  it('should handle API error for last 30 days data', async () => {
    const testError = new Error('Congestion API Error');
    (
      portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
    ).mockRejectedValue(testError);

    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await result.current.fetchLast30DaysData();
    });

    expect(mockHandleApiError).toHaveBeenCalledWith(testError);
    expect(result.current.last30DaysData).toBeUndefined();
    expect(result.current.isLoading).toBe(false);
  });

  it('should return correct data structure', () => {
    const { result } = renderHook(() => useLivePortTraffic());

    expect(result.current).toHaveProperty('livePortData');
    expect(result.current).toHaveProperty('isLoading');
    expect(result.current).toHaveProperty('last30DaysData');
    expect(result.current).toHaveProperty('fetchLivePortTraffic');
    expect(result.current).toHaveProperty('fetchLast30DaysData');
  });

  it('should handle both API calls failing simultaneously', async () => {
    const liveError = new Error('Live API Error');
    const congestionError = new Error('Congestion API Error');

    (portCongestionApi.getLivePortCongestionData as Mock).mockRejectedValue(
      liveError,
    );
    (
      portCongestionApi.getArrivalsAndDeparturesByTotals as Mock
    ).mockRejectedValue(congestionError);

    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await Promise.all([
        result.current.fetchLivePortTraffic(),
        result.current.fetchLast30DaysData(),
      ]);
    });

    expect(mockHandleApiError).toHaveBeenCalledWith(liveError);
    expect(mockHandleApiError).toHaveBeenCalledWith(congestionError);
    expect(result.current.livePortData).toBeUndefined();
    expect(result.current.last30DaysData).toBeUndefined();
  });

  it('should handle empty by_vessel_type array', async () => {
    const liveDataWithEmptyTypes: ILiveDataResponse = {
      ...mockLiveData,
      totals: {
        ...mockLiveData.totals!,
        by_vessel_type: [],
      },
    };

    (portCongestionApi.getLivePortCongestionData as Mock).mockResolvedValue(
      liveDataWithEmptyTypes,
    );

    const { result } = renderHook(() => useLivePortTraffic());

    await act(async () => {
      await result.current.fetchLivePortTraffic();
    });

    expect(result.current.livePortData?.totals?.by_vessel_type).toEqual([]);
  });
});
