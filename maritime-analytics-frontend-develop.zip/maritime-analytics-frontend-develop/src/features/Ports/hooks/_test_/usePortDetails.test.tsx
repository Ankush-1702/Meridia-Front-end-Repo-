import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { usePortDetails } from '@/features/Ports/hooks/usePortsDetails';
import type { Port } from '@/shared/types/entities';
import type { SubscriptionResponseDataType } from '@/shared/types/subscriptionTypes';

/* ------------------------------------------------------------------ */
/* shared spies                                                        */
/* ------------------------------------------------------------------ */

const fetchSavedEntitiesMock = vi.fn();
const showToastMock = vi.fn();
const handleApiErrorMock = vi.fn();

/* ------------------------------------------------------------------ */
/* base mocks                                                          */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/hooks/useEntityDetails', () => ({
  useEntityDetails: () => ({
    id: 'port-1',
    entity: { id: 'port-1', name: 'Test Port' } as Port,
    wpiData: null,
    loading: false,
    error: null,
    refresh: false,
    setRefresh: vi.fn(),
    dateRange: null,
    setDateRange: vi.fn(),
  }),
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: showToastMock,
  }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => handleApiErrorMock,
}));

vi.mock('@/features/library/services/libraryApi', () => ({
  toggleBookmark: vi.fn(),
}));

vi.mock('@/features/Ports/services/portServices', () => ({
  fetchPortDetails: vi.fn(),
  fetchPortSubscriptions: vi.fn(),
  createPortSubscription: vi.fn(),
  updatePortSubscription: vi.fn(),
}));

vi.mock('@/shared/utils/formatUtils', () => ({
  localToUtc: (time: string) => time,
  utcToLocal: (time: string) => time,
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

const existingSubscription: SubscriptionResponseDataType = {
  subscription_exists: true,
  subscription_id: 'sub-1',
  name: 'Test Port',
  active: true,
  notify_on: {
    PORT_ARRIVAL: true,
    PORT_DEPARTURE: false,
    PORT_AREA_DEPARTURE: false,
    PORT_AREA_ARRIVAL: false,
  },
  vessel_screening: {
    active: false,
    severity_filter: [],
  },
  email_settings: {
    email_enabled: false,
    scheduler: {
      schedule_type: 1,
      at_time: '08:00',
    },
  },
};

async function mockLibrary(bookmarked: boolean) {
  const lib = await import('@/features/library/context/LibraryContext');

  vi.spyOn(lib, 'useLibrary').mockReturnValue({
    bookmarks: bookmarked
      ? [
          {
            entityRefId: 'port-1',
            entityType: 'PORT',
            createdTimestamp: '',
            subscription: {
              active: true,
              name: null,
              notify_on: {
                PORT_AREA_ARRIVAL: false,
                PORT_AREA_DEPARTURE: false,
                PORT_ARRIVAL: false,
                PORT_DEPARTURE: false,
              },
              vessel_screening: {
                active: false,
                severity_filter: [],
              },
              subscription_exists: true,
              subscription_id: 'sub-1',
            },
          },
        ]
      : [],
    fetchSavedEntities: fetchSavedEntitiesMock,
    setBookmarks: vi.fn(),
    activeTab: '',
    setActiveTab: vi.fn(),
    exportToCSV: vi.fn(),
    totalCount: 0,
    activeTabCount: 0,
    setActiveTabCount: vi.fn(),
    loading: false,
    setLoading: vi.fn(),
  });
}

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('usePortDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('initializes with empty subscription', async () => {
    await mockLibrary(false);
    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData).toMatchObject({
      subscription_exists: false,
      active: false,
    });
  });

  it('adds a bookmark', async () => {
    await mockLibrary(false);
    const { toggleBookmark } = await import(
      '@/features/library/services/libraryApi'
    );

    vi.mocked(toggleBookmark).mockResolvedValue({
      subscription: {
        ...existingSubscription,
        subscription_id: 'sub-1',
      },
      createdTimestamp: '',
      entityRefId: 'port-1',
      entityType: 'PORT',
    });

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('port-1');
    });

    expect(toggleBookmark).toHaveBeenCalledWith('add', {
      id: 'port-1',
      type: 'port',
    });
  });

  it('removes a bookmark', async () => {
    await mockLibrary(true);
    const { toggleBookmark } = await import(
      '@/features/library/services/libraryApi'
    );

    vi.mocked(toggleBookmark).mockResolvedValue({
      subscription: {
        ...existingSubscription,
        subscription_id: 'sub-1',
      },
      createdTimestamp: '',
      entityRefId: 'port-1',
      entityType: 'PORT',
    });

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('port-1');
    });

    expect(toggleBookmark).toHaveBeenCalledWith('remove', {
      id: 'port-1',
      type: 'port',
    });
  });

  it('updates auto-screen vessels', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue({
      ...existingSubscription,
      vessel_screening: {
        active: true,
        severity_filter: ['CRITICAL', 'OK', 'UNSCORED', 'WARNING'],
      },
    });

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Auto-Screen Vessels');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        vessel_screening: {
          active: true,
          severity_filter: ['CRITICAL', 'OK', 'UNSCORED', 'WARNING'],
        },
      }),
      'sub-1',
    );
  });

  it('updates severity filter', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue({
      ...existingSubscription,
      vessel_screening: { active: true, severity_filter: ['CRITICAL'] },
    });
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Warning');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        vessel_screening: {
          active: true,
          severity_filter: ['CRITICAL', 'WARNING'],
        },
      }),
      'sub-1',
    );
  });

  it('updates email notifications', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue({
      ...existingSubscription,
      email_settings: {
        email_enabled: true,
        scheduler: { schedule_type: 1, at_time: '08:00' },
      },
    });

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Email Notifications');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          email_enabled: true,
        }),
      }),
      'sub-1',
    );
  });

  it('updates timing to immediately', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Timing');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            schedule_type: 0,
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('updates frequency', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Frequency:24');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            schedule_type: 24,
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('updates send at time', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'SendAt:14:30');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        email_settings: expect.objectContaining({
          scheduler: expect.objectContaining({
            at_time: '14:30',
          }),
        }),
      }),
      'sub-1',
    );
  });

  it('updates arrivals notifications', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Arrivals');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        notify_on: expect.objectContaining({
          PORT_ARRIVAL: true,
        }),
      }),
      'sub-1',
    );
  });

  it('updates departures notifications', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions, updatePortSubscription } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockResolvedValue(existingSubscription);
    vi.mocked(updatePortSubscription).mockResolvedValue(existingSubscription);

    const { result } = renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(result.current.subscriptionData?.subscription_exists).toBe(true);

    await act(async () => {
      result.current.manageSubscription(true, 'Departures');
      await vi.runAllTimersAsync();
    });

    expect(updatePortSubscription).toHaveBeenCalledWith(
      expect.objectContaining({
        notify_on: expect.objectContaining({
          PORT_DEPARTURE: true,
        }),
      }),
      'sub-1',
    );
  });

  it('handles subscription fetch error', async () => {
    await mockLibrary(true);
    const { fetchPortSubscriptions } = await import(
      '@/features/Ports/services/portServices'
    );

    vi.mocked(fetchPortSubscriptions).mockRejectedValue(new Error('fail'));

    renderHook(() => usePortDetails());

    await act(async () => {
      await vi.runAllTimersAsync();
    });

    expect(handleApiErrorMock).toHaveBeenCalled();
  });
});
