// Navigational Status interface (matches API schema)
export interface NavigationalStatus {
  code: number;
  status: number;
}

// Latest Position interface (matches API schema)
export interface LatestPosition {
  latitude: number;
  longitude: number;
  course: number;
  speed: number;
  heading: number;
  draught: number;
  navigational_status: NavigationalStatus;
  timestamp: string;
}

// Reported Destination interface (matches API schema)
export interface ReportedDestination {
  id: string;
  name: string;
  raw: string;
  reported_at: string;
  unlocode: string;
}

// Vessel Information interface (matches API schema)
export interface VesselInformation {
  asset_id: string;
  callsign: string;
  flag: string;
  flag_code: string;
  imo: string;
  mmsi: string;
  name: string;
  vessel_type: string;
}

// Individual Inbound Vessel interface (matches API schema)
export interface InboundVessel {
  vessel_information: VesselInformation;
  reported_destination: ReportedDestination;
  reported_eta: string | null;
  latest_position: LatestPosition;
}

// API Metadata interface (matches API schema)
export interface InboundVesselsApiMeta {
  limit: number;
  offset: number;
  total_count: number;
  request_id: string;
  request_timestamp: string;
}

// API Response interface
export interface InboundVesselsApiResponse {
  meta: InboundVesselsApiMeta;
  data: InboundVessel[];
}

// Table Row interface for AG-Grid
export interface InboundVesselsTableRow {
  vesselName: string;
  imo: string;
  mmsi: string;
  callsign: string;
  vesselType: string;
  flag: string;
  flagCode: string;
  reportedDestination: string;
  reportedEta: string;
  latitude: number;
  longitude: number;
  course: number;
  speed: number;
  heading: number;
  draught: number;
  navigationalStatus: string;
  lastUpdate: string;
}
