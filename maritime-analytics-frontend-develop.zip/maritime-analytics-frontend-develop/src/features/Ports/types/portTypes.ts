export type PortEventType =
  | ''
  | 'PORT_ARRIVAL'
  | 'PORT_DEPARTURE'
  | 'PORT_AREA_ARRIVAL'
  | 'PORT_AREA_DEPARTURE'
  | 'BERTH_ARRIVAL'
  | 'BERTH_DEPARTURE'
  | 'INBOUND';

export interface PortEvents {
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
  event_details: {
    course: number;
    draught: number;
    event_id: string;
    event_timestamp: string;
    event_type: Exclude<PortEventType, ''>;
    heading: number;
    latitude: number;
    longitude: number;
    navigational_status: {
      status: string;
      code: number;
    };
    reported_destination: string;
    reported_eta: string;
    speed: number;
  };
}

interface BerthInformation {
  id: string;
  name: string;
  port_id: string;
}

export interface BerthEvents extends PortEvents {
  berth_information: BerthInformation;
}

export interface BerthFilters {
  berth_types: string[];
}

export interface FlatPortEventsResponse {
  vesselName?: string;
  callSign?: string;
  flag?: string;
  flagCode?: string;
  imo?: string;
  mmsi?: string;
  vesselType?: string;
  berthName?: string;
  berthId?: string;
  portId?: string;
  course?: number;
  draught?: number;
  eventId?: string;
  eventTimestamp?: string;
  eventType?: PortEventType;
  heading?: number;
  latitude?: number;
  longitude?: number;
  navigationalStatusStatus?: string;
  navigationalStatusCode?: number;
  reportedDestination?: string;
  reportedEta?: string;
  speed?: number;
  lastUpdate?: string;
}
