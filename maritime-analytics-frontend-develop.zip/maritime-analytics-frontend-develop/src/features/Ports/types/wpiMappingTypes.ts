export interface WpiData {
  ports: unknown[];
}

export type ValueType =
  | 'direct'
  | 'common'
  | 'harborSize'
  | 'harborType'
  | 'harborUse'
  | 'shelter'
  | 'repairCode'
  | 'dryDockRailway'
  | 'ukcMgmtSystem';

export interface FieldMapping {
  name: string;
  description: string;
  category: string;
  valueType: ValueType;
}

export interface MappedField {
  label: string;
  value: string;
}

export type CategoryMap = Record<string, MappedField[]>;

export interface MappedPort {
  categories: CategoryMap;
  summary: {
    portName: string;
    countryName: string;
    portNumber: string;
  };
}

export interface CategoryArrayItem {
  categoryName: string;
  items: MappedField[];
}
