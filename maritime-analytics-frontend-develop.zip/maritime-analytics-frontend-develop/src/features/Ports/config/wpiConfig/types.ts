import type { ValueType } from '@/features/Ports/types/wpiMappingTypes';

export interface FieldDef {
  name: string;
  description: string;
  valueType: ValueType;
}

/**
 * Each category module exports a record keyed by API field name.
 * The category is derived from the module, not repeated per field.
 */
export type CategoryFieldDefs = Record<string, FieldDef>;
