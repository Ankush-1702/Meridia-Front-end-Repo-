import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Services';

export const fields: CategoryFieldDefs = {
  srLongshore: {
    name: 'Services - Longshoremen',
    description:
      'Indicates whether longshoremen services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srElectrical: {
    name: 'Services - Electricity',
    description:
      'Indicates whether electricity services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srSteam: {
    name: 'Services - Steam',
    description:
      'Indicates whether steam services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srNavigEquip: {
    name: 'Services - Navigation Equipment',
    description:
      'Indicates whether navigation equipment services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srElectRepair: {
    name: 'Services - Electrical Repair',
    description:
      'Indicates whether electrical repair services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srIceBreaking: {
    name: 'Services - Ice Breaking',
    description:
      'Indicates whether ice breaking services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  srDiving: {
    name: 'Services - Diving',
    description:
      'Indicates whether diving services are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
