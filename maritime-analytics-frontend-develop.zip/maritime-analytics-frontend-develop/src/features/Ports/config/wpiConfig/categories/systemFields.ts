import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'System Fields';

export const fields: CategoryFieldDefs = {
  globalId: {
    name: 'Global ID',
    description: 'System-generated unique identifier',
    valueType: 'direct',
  },
};
