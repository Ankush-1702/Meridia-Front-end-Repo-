import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Navigation and Publications';

export const fields: CategoryFieldDefs = {
  publicationNumber: {
    name: 'Sailing Direction or Publication',
    description:
      'The publication number and title of the NGA Sailing Directions, describing the port or area in which the port is located.',
    valueType: 'direct',
  },
  chartNumber: {
    name: 'Standard Nautical Chart',
    description:
      'The number of the best-scale chart issued by NGA is listed with no prefix.',
    valueType: 'direct',
  },
  navArea: {
    name: 'NAVAREA',
    description:
      'The corresponding NAVAREA, as defined in relevant IMO and IHO documentation, is given.',
    valueType: 'direct',
  },
  dnc: {
    name: 'Digital Nautical Chart',
    description: 'NGA Digital Nautical Chart library numbers are given.',
    valueType: 'direct',
  },
  s57Enc: {
    name: 'S-57 Electronic Navigational Chart',
    description:
      'The number/name of the appropriate electronic navigational chart in the S-57 format is given.',
    valueType: 'direct',
  },
  s101Enc: {
    name: 'S-101 Electronic Navigational Chart',
    description:
      'The number/name of the appropriate electronic navigational chart in the S-101 format is given.',
    valueType: 'direct',
  },
  dodWaterBody: {
    name: 'World Water Body',
    description:
      'The relevant body of water, as defined by the United States Department of Defense.',
    valueType: 'direct',
  },
  s121WaterBody: {
    name: 'IHO S-130 Sea Area',
    description:
      'The number/name of the appropriate water area in the S-130 format is given.',
    valueType: 'direct',
  },
};
