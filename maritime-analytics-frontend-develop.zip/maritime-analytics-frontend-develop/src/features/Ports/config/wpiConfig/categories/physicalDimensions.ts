import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Physical Dimensions';

export const fields: CategoryFieldDefs = {
  overheadLimits: {
    name: 'Overhead Limits',
    description:
      'This entry is shown only to indicate that bridge and overhead power cables exist. It is advisable to refer to the chart for particulars. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  entranceWidth: {
    name: 'Entrance Width (m)',
    description:
      'The maximum width of the entrance is given, where restrictions exist.',
    valueType: 'direct',
  },
  chDepth: {
    name: 'Channel Depth (m)',
    description:
      'The controlling depth of the principal or deepest channel at chart datum is given.',
    valueType: 'direct',
  },
  anDepth: {
    name: 'Anchorage Depth (m)',
    description:
      'The depth in the anchorage is the least depth in the best or principal anchorage.',
    valueType: 'direct',
  },
  cpDepth: {
    name: 'Cargo Pier Depth (m)',
    description:
      'The greatest depth at chart datum alongside the respective wharf/pier is given.',
    valueType: 'direct',
  },
  otDepth: {
    name: 'Oil Terminal Depth (m)',
    description: 'The greatest depth at chart datum will be shown.',
    valueType: 'direct',
  },
  lngTerminalDepth: {
    name: 'Liquified Natural Gas Terminal Depth (m)',
    description: 'The greatest depth at chart datum will be shown.',
    valueType: 'direct',
  },
  tide: {
    name: 'Tidal Range (m)',
    description: 'The mean range in meters is given for all ports.',
    valueType: 'direct',
  },
};
