import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Entrance Restrictions';

export const fields: CategoryFieldDefs = {
  erTide: {
    name: 'Entrance Restriction - Tide',
    description:
      'Natural factor restricting the entrance of vessels -- Tide. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  erSwell: {
    name: 'Entrance Restriction - Heavy Swell',
    description:
      'Natural factor restricting the entrance of vessels -- Heavy Swell. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  erIce: {
    name: 'Entrance Restriction - Ice',
    description:
      'Natural factor restricting the entrance of vessels -- Ice. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  erOther: {
    name: 'Entrance Restriction - Other',
    description:
      'Natural factor restricting the entrance of vessels -- Other. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
