import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Quarantine';

export const fields: CategoryFieldDefs = {
  qtPratique: {
    name: 'Quarantine - Pratique',
    description:
      'Indicates whether pratique will apply to vessels arriving in the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  qtSanitation: {
    name: 'Quarantine - Sanitation',
    description:
      'Indicates whether sanitation will apply to vessels arriving in the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  qtOther: {
    name: 'Quarantine - Other',
    description:
      'Indicates whether other restrictions will apply to vessels arriving in the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
