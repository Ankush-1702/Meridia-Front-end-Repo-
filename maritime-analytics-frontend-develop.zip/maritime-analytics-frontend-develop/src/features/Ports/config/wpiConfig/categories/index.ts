import * as basicPortInfo from '@/features/Ports/config/wpiConfig/categories/basicPortInfo';
import * as communications from '@/features/Ports/config/wpiConfig/categories/communications';
import * as cranes from '@/features/Ports/config/wpiConfig/categories/cranes';
import * as entranceRestrictions from '@/features/Ports/config/wpiConfig/categories/entranceRestrictions';
import * as entryRequirements from '@/features/Ports/config/wpiConfig/categories/entryRequirements';
import * as facilitiesCargoTypes from '@/features/Ports/config/wpiConfig/categories/facilitiesCargoTypes';
import * as facilitiesMoorings from '@/features/Ports/config/wpiConfig/categories/facilitiesMoorings';
import * as geographicInfo from '@/features/Ports/config/wpiConfig/categories/geographicInfo';
import * as harborCharacteristics from '@/features/Ports/config/wpiConfig/categories/harbourCharacteristics';
import * as liftingCapacity from '@/features/Ports/config/wpiConfig/categories/liftingCapacity';
import * as navigationPublications from '@/features/Ports/config/wpiConfig/categories/navigationPublications';
import * as physicalDimensions from '@/features/Ports/config/wpiConfig/categories/physicalDimensions';
import * as pilotageServices from '@/features/Ports/config/wpiConfig/categories/pilotageServices';
import * as portOperations from '@/features/Ports/config/wpiConfig/categories/portOperations';
import * as portServices from '@/features/Ports/config/wpiConfig/categories/portServices';
import * as quarantine from '@/features/Ports/config/wpiConfig/categories/quarantine';
import * as repairFacilities from '@/features/Ports/config/wpiConfig/categories/repairFacilities';
import * as services from '@/features/Ports/config/wpiConfig/categories/services';
import * as supplies from '@/features/Ports/config/wpiConfig/categories/supplies';
import * as systemFields from '@/features/Ports/config/wpiConfig/categories/systemFields';
import * as tugServices from '@/features/Ports/config/wpiConfig/categories/tugServices';
import * as vesselLimitations from '@/features/Ports/config/wpiConfig/categories/vesselLimitations';
import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';
import { FieldMapping } from '@/features/Ports/types/wpiMappingTypes';

interface CategoryModule {
  CATEGORY: string;
  fields: CategoryFieldDefs;
}

/**
 * Ordered list of all category modules.
 * This order drives both FIELD_MAPPINGS generation and getWpiSections output.
 */
export const CATEGORY_MODULES: CategoryModule[] = [
  basicPortInfo,
  geographicInfo,
  harborCharacteristics,
  entranceRestrictions,
  physicalDimensions,
  vesselLimitations,
  portOperations,
  entryRequirements,
  pilotageServices,
  tugServices,
  quarantine,
  communications,
  facilitiesMoorings,
  facilitiesCargoTypes,
  portServices,
  cranes,
  liftingCapacity,
  services,
  supplies,
  repairFacilities,
  navigationPublications,
  systemFields,
];

/**
 * Generate the flat FIELD_MAPPINGS record from all category modules.
 */
export function buildFieldMappings(): Record<string, FieldMapping> {
  const mappings: Record<string, FieldMapping> = {};

  for (const mod of CATEGORY_MODULES) {
    for (const [fieldName, def] of Object.entries(mod.fields)) {
      mappings[fieldName] = {
        name: def.name,
        description: def.description,
        category: mod.CATEGORY,
        valueType: def.valueType,
      };
    }
  }

  return mappings;
}

/**
 * Get the ordered list of category names.
 */
export function getCategoryOrder(): string[] {
  return CATEGORY_MODULES.map((mod) => mod.CATEGORY);
}
