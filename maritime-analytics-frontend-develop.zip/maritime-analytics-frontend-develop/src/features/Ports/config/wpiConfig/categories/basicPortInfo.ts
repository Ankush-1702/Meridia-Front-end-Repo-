import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Basic Port Information';

export const fields: CategoryFieldDefs = {
  portNumber: {
    name: 'WPI Number',
    description:
      'Each port and place contained in this dataset is given a unique number by the publisher. WPI numbers remain consistent between updates and are also referenced in NGA Sailing Directions.',
    valueType: 'direct',
  },
  portName: {
    name: 'Main Port Name',
    description:
      'Main Port Name, with no diacritical marks. In general, port names listed are approved by the U.S. Board on Geographic Names.',
    valueType: 'direct',
  },
  regionNumber: {
    name: 'Region Number',
    description: 'Region identifier',
    valueType: 'direct',
  },
  regionName: {
    name: 'Region Name',
    description:
      'Region Names, as given in the 2019 edition of the World Port Index, are included.',
    valueType: 'direct',
  },
  countryCode: {
    name: 'Country Code',
    description:
      "Country name according to U.S. Government's Geopolitical Entities, Names, and Codes (GENC) standard.",
    valueType: 'direct',
  },
  countryName: {
    name: 'Country Name',
    description: 'Full country name',
    valueType: 'direct',
  },
  alternateName: {
    name: 'Alternate Port Name',
    description:
      'Alternate, conventional, or familiar names may be included here.',
    valueType: 'direct',
  },
  unloCode: {
    name: 'UN/LOCODE',
    description:
      'Given in accordance with the United Nations Code for Trade and Transport Locations.',
    valueType: 'direct',
  },
};
