import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Tug Services';

export const fields: CategoryFieldDefs = {
  tugsSalvage: {
    name: 'Tugs - Salvage',
    description:
      'Indicates whether tugs are available for salvage assistance. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  tugsAssist: {
    name: 'Tugs - Assistance',
    description:
      'Indicates whether tugs are available for docking or anchorage assistance. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
