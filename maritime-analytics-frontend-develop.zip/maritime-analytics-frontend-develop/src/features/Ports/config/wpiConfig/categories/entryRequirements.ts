import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Entry Requirements';

export const fields: CategoryFieldDefs = {
  firstPortOfEntry: {
    name: 'First Port of Entry',
    description:
      'A port where a vessel may enter and clear foreign goods and personnel through Customs and Immigration. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  usRep: {
    name: 'US Representative',
    description:
      'Indicates whether the United States maintains civilian/military representation in that port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
