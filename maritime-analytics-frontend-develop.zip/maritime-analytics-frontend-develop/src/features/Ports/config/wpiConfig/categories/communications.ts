import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Communications';

export const fields: CategoryFieldDefs = {
  cmTelephone: {
    name: 'Communications - Telephone',
    description:
      'Indicates whether telephone communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cmTelegraph: {
    name: 'Communications - Telefax',
    description:
      'Indicates whether telefax communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cmRadio: {
    name: 'Communications - Radio',
    description:
      'Indicates whether radio communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cmRadioTel: {
    name: 'Communications - Radiotelephone',
    description:
      'Indicates whether radiotelephone communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cmAir: {
    name: 'Communications - Airport',
    description:
      'Indicates whether airport communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cmRail: {
    name: 'Communications - Rail',
    description:
      'Indicates whether rail communications are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  searchAndRescue: {
    name: 'Search and Rescue',
    description:
      'Indicates whether there are Search and Rescue facilities in the port or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
