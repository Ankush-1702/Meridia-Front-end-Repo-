import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Pilotage Services';

export const fields: CategoryFieldDefs = {
  ptCompulsory: {
    name: 'Pilotage - Compulsory',
    description:
      'The necessity or availability of taking a pilot is given. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  ptAvailable: {
    name: 'Pilotage - Available',
    description:
      'The necessity or availability of taking a pilot is given. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  ptLocalAssist: {
    name: 'Pilotage - Local Assistance',
    description:
      'The availability of local assistance, as opposed to official pilotage, is given. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  ptAdvisable: {
    name: 'Pilotage - Advisable',
    description:
      'The necessity or availability of taking a pilot, even though not compulsory, is given. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
