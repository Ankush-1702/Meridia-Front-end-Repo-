import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Port Services';

export const fields: CategoryFieldDefs = {
  medFacilities: {
    name: 'Medical Facilities',
    description:
      'Indicates that there are some form of medical facilities in the port that will accommodate seamen. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  garbageDisposal: {
    name: 'Garbage Disposal',
    description:
      'Indicates whether garbage can be disposed of at the pier or by lighters at the anchorage or mooring. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cht: {
    name: 'Chemical Holding Tank Disposal',
    description:
      'Indicates whether Chemical Holding Tanks (black water) can be discharged at the pier or at the anchorage. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  degauss: {
    name: 'Degaussing',
    description:
      'Indicates whether degaussing facilities are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  dirtyBallast: {
    name: 'Dirty Ballast Disposal',
    description:
      'Pertains to a port that has sufficient facilities for receiving oily and/or chemically contaminated dirty ballast. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
