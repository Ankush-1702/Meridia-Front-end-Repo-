import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Harbor Characteristics';

export const fields: CategoryFieldDefs = {
  harborSize: {
    name: 'Harbor Size',
    description:
      'The classification of harbor size -- Large, Medium, Small, or Very Small -- is based on several applicable factors, including area, facilities, and wharf space.',
    valueType: 'harborSize',
  },
  harborType: {
    name: 'Harbor Type',
    description:
      'The term "harbor" is used for the principal water area of the port. Harbors are classified as: Coastal (Natural), Coastal (Breakwater), Coastal (Tide Gates), River (Natural), River (Basin), River (Tide Gates), Canal or Lake, or Open Roadstead.',
    valueType: 'harborType',
  },
  harborUse: {
    name: 'Harbor Use',
    description:
      'Harbor use is classified as Fishing, Military, Cargo, Ferry, or Unknown.',
    valueType: 'harborUse',
  },
  shelter: {
    name: 'Shelter Afforded',
    description:
      'The shelter afforded from wind, sea, and swell refers to the area where normal port operations are conducted, usually the wharf area. Values: Excellent, Good, Fair, Poor, or None.',
    valueType: 'shelter',
  },
};
