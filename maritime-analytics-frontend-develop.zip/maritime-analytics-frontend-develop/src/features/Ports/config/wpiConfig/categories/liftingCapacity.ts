import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Lifting Capacity';

export const fields: CategoryFieldDefs = {
  lifts100: {
    name: 'Lifts - 100+ Tons',
    description:
      'Indicates the lifting power in tons of the available cranes. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  lifts50: {
    name: 'Lifts - 50-100 Tons',
    description:
      'Indicates the lifting power in tons of the available cranes. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  lifts25: {
    name: 'Lifts - 25-49 Tons',
    description:
      'Indicates the lifting power in tons of the available cranes. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  lifts0: {
    name: 'Lifts - 0-24 Tons',
    description:
      'Indicates the lifting power in tons of the available cranes. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
