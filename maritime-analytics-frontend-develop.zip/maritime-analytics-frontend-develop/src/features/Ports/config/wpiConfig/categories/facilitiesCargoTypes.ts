import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Facilities - Cargo Types';

export const fields: CategoryFieldDefs = {
  loSolidBulk: {
    name: 'Facilities - Solid Bulk',
    description:
      'Indicates whether solid bulk facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loLiquidBulk: {
    name: 'Facilities - Liquid Bulk',
    description:
      'Indicates whether liquid bulk facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loContainer: {
    name: 'Facilities - Container',
    description:
      'Indicates whether container facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loBreakBulk: {
    name: 'Facilities - Breakbulk',
    description:
      'Indicates whether breakbulk facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loOilTerm: {
    name: 'Facilities - Oil Terminal',
    description:
      'Indicates whether oil terminal facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loLongTerm: {
    name: 'Facilities - LNG Terminal',
    description:
      'Indicates whether LNG terminal facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loOther: {
    name: 'Facilities - Other',
    description:
      'Indicates whether other facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
