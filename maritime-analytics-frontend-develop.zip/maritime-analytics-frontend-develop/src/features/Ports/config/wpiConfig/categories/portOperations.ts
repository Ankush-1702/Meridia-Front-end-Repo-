import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Port Operations';

export const fields: CategoryFieldDefs = {
  goodHoldingGround: {
    name: 'Good Holding Ground',
    description:
      'This is indicated only where actual anchorage conditions have been reported. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  turningArea: {
    name: 'Turning Area',
    description:
      'An indication that a turning basin or other water area for turning vessels is available in the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  ukcMgmtSystem: {
    name: 'Underkeel Clearance Management System',
    description:
      'Indicates whether an Underkeel Clearance Management System is in place in the port or its approaches. Values are Static, Dynamic, None, or Unknown.',
    valueType: 'ukcMgmtSystem',
  },
  portSecurity: {
    name: 'Port Security',
    description:
      'Indicates whether International Ship and Port Facility Security (ISPS) safety regulations will apply in the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  etaMessage: {
    name: 'Estimated Time of Arrival Message',
    description:
      'Indicates whether an ETA message is required for that port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  tss: {
    name: 'Traffic Separation Scheme',
    description:
      'Indicates if a Traffic Separation Scheme is established in the approach to the port.',
    valueType: 'common',
  },
  vts: {
    name: 'Vessel Traffic Service',
    description:
      'Indicates that a Vessel Traffic Service is established in the approach to the port. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
