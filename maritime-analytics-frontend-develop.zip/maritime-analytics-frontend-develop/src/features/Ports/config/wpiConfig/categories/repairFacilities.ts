import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Repair Facilities';

export const fields: CategoryFieldDefs = {
  repairCode: {
    name: 'Repairs',
    description:
      'Repairs that can be made to ocean-going vessels are classified as Major (A), Moderate (B), Limited (C), Emergency Only (D), None (N), or Unknown (U).',
    valueType: 'repairCode',
  },
  drydock: {
    name: 'Dry Dock',
    description:
      'The general size and type of the largest underwater repair facilities in the port are Small (S), Medium (M), or Large (L).',
    valueType: 'dryDockRailway',
  },
  railway: {
    name: 'Railway',
    description:
      'The general size and type of the largest underwater repair facilities in the port are Small (S), Medium (M), or Large (L).',
    valueType: 'dryDockRailway',
  },
};
