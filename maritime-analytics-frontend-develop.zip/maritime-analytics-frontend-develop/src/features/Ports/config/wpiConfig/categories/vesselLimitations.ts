import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Vessel Limitations';

export const fields: CategoryFieldDefs = {
  maxVesselLength: {
    name: 'Maximum Vessel Length (m)',
    description:
      'The maximum length that can be accommodated in the port is given.',
    valueType: 'direct',
  },
  maxVesselBeam: {
    name: 'Maximum Vessel Beam (m)',
    description:
      'The maximum beam that can be accommodated in the port is given.',
    valueType: 'direct',
  },
  maxVesselDraft: {
    name: 'Maximum Vessel Draft (m)',
    description:
      'The maximum draft that can be accommodated in the port is given.',
    valueType: 'direct',
  },
  offMaxVesselLength: {
    name: 'Offshore Maximum Vessel Length (m)',
    description:
      'The maximum length that can be accommodated offshore is given.',
    valueType: 'direct',
  },
  offMaxVesselBeam: {
    name: 'Offshore Maximum Vessel Beam (m)',
    description: 'The maximum beam that can be accommodated offshore is given.',
    valueType: 'direct',
  },
  offMaxVesselDraft: {
    name: 'Offshore Maximum Vessel Draft (m)',
    description:
      'The maximum draft that can be accommodated offshore is given.',
    valueType: 'direct',
  },
};
