import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Cranes';

export const fields: CategoryFieldDefs = {
  crFixed: {
    name: 'Cranes - Fixed',
    description:
      'Indicates whether fixed cranes are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  crMobile: {
    name: 'Cranes - Mobile',
    description:
      'Indicates whether mobile cranes are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  crFloating: {
    name: 'Cranes - Floating',
    description:
      'Indicates whether floating cranes are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  cranesContainer: {
    name: 'Cranes - Container',
    description:
      'Indicates whether container cranes are available. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
