import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Supplies';

export const fields: CategoryFieldDefs = {
  suProvisions: {
    name: 'Supplies - Provisions',
    description:
      'The availability of provisions is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suWater: {
    name: 'Supplies - Potable Water',
    description:
      'The availability of water is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suFuel: {
    name: 'Supplies - Fuel Oil',
    description:
      'The availability of fuel oil is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suDiesel: {
    name: 'Supplies - Diesel Oil',
    description:
      'The availability of diesel oil is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suAviationFuel: {
    name: 'Supplies - Aviation Fuel',
    description:
      'The availability of aviation fuel is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suDeck: {
    name: 'Supplies - Deck',
    description:
      'The availability of deck supplies is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  suEngine: {
    name: 'Supplies - Engine',
    description:
      'The availability of engine supplies is listed. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
