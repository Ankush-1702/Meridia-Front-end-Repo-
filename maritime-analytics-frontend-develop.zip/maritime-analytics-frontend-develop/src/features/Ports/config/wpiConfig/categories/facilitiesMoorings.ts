import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Facilities - Moorings';

export const fields: CategoryFieldDefs = {
  loWharves: {
    name: 'Facilities - Wharves',
    description:
      'Indicates whether wharf facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loAnchor: {
    name: 'Facilities - Anchorage',
    description:
      'Indicates whether anchorage facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loDangCargo: {
    name: 'Facilities - Dangerous Cargo Anchorage',
    description:
      'Indicates whether dangerous cargo anchorage facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loMedMoor: {
    name: 'Facilities - Med Mooring',
    description:
      'Indicates whether med mooring facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loBeachMoor: {
    name: 'Facilities - Beach Mooring',
    description:
      'Indicates whether beach mooring facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loIceMoor: {
    name: 'Facilities - Ice Mooring',
    description:
      'Indicates whether ice mooring facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
  loRoro: {
    name: 'Facilities - RoRo',
    description:
      'Indicates whether ro-ro facilities are available in the port and/or nearby area. Values are Yes, No, or Unknown.',
    valueType: 'common',
  },
};
