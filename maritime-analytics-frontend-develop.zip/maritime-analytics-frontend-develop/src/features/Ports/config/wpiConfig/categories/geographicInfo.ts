import { CategoryFieldDefs } from '@/features/Ports/config/wpiConfig/types';

export const CATEGORY = 'Geographic Information';

export const fields: CategoryFieldDefs = {
  latitude: {
    name: 'Latitude',
    description: 'Latitude of the port is given.',
    valueType: 'direct',
  },
  longitude: {
    name: 'Longitude',
    description: 'Longitude of the port is given.',
    valueType: 'direct',
  },
  ycoord: {
    name: 'Latitude (Decimal)',
    description: 'Decimal degree latitude',
    valueType: 'direct',
  },
  xcoord: {
    name: 'Longitude (Decimal)',
    description: 'Decimal degree longitude',
    valueType: 'direct',
  },
};
