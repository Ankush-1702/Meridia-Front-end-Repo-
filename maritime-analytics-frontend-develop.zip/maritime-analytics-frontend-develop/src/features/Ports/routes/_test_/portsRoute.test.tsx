import { describe, it, expect } from 'vitest';
import { portRoutes } from '@/features/Ports/routes/portsRoute';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

describe('portRoutes', () => {
  it('defines the port details route', () => {
    expect(portRoutes).toHaveLength(1);
  });

  it('uses the correct path', () => {
    expect(portRoutes[0].path).toBe('/analytics/port/:id');
  });

  it('wraps PortDetailsPage in SuspenseWrapper', () => {
    const element = portRoutes[0].element;

    expect(element.type).toBe(SuspenseWrapper);

    const child = element.props.children;
    expect(child.type).toBeDefined();
    expect(child.type.$$typeof).toBe(Symbol.for('react.lazy'));
  });
});
