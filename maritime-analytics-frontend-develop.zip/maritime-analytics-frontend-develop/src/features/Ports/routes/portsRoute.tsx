import { lazy } from 'react';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';
const PortDetailsPage = lazy(() => import('@/features/Ports/Ports'));

export const portRoutes = [
  {
    path: '/analytics/port/:id',
    element: (
      <SuspenseWrapper>
        <PortDetailsPage />
      </SuspenseWrapper>
    ),
  },
];
