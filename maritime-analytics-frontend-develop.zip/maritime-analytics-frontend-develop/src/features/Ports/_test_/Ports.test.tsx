import { describe, it, expect, vi, beforeEach } from 'vitest';
import PortDetailsPage from '../Ports';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { usePortDetails } from '@/features/Ports/hooks/usePortsDetails';
import type { Port } from '@/shared/types/entities';
import { renderWithRouter, screen, fireEvent } from '@/test-utils';
import '@/test-setup'; // Import test setup for window.matchMedia mock

// Mock ThemeProvider
vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light', saveTheme: vi.fn() }),
}));

// Mock config
vi.mock('@/app/config/config', () => ({
  isMara2Enabled: () => false,
  INBOUND_VESSELS_DESTINATION_UPDATE_DAYS: 7,
  API_GATEWAY_BASE_URL: undefined,
  AG_GRID_LICENSE_KEY: undefined,
}));

/* ------------------------------------------------------------------ */
/* HOOK MOCKS (HOIST SAFE)                                             */
/* ------------------------------------------------------------------ */

vi.mock('@/features/Ports/hooks/usePortsDetails', () => ({
  usePortDetails: vi.fn(),
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: vi.fn(),
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: vi.fn(() => ({
    accessToken: 'mock-token',
    user: { user_id: 'test-user' },
    isAuthenticated: true,
  })),
}));

vi.mock('@/shared/hooks/useOverviewData', () => ({
  useOverviewData: () => ({
    center: null,
    positions: [],
    loading: false,
    progress: null,
    refresh: vi.fn(),
  }),
}));

vi.mock('@/features/Ports/hooks/useLivePortTraffic', () => ({
  useLivePortTraffic: () => ({
    isLoading: false,
    livePortData: undefined,
    last30DaysData: undefined,
    fetchLivePortTraffic: vi.fn().mockResolvedValue(undefined),
    fetchLast30DaysData: vi.fn().mockResolvedValue(undefined),
  }),
}));

vi.mock('@/features/Ports/services/inboundVesselsApi', () => ({
  getInboundVessels: vi.fn(() =>
    Promise.resolve({ data: [], meta: { total_count: 0 } }),
  ),
}));

vi.mock('@/features/Ports/utils/wpiDataMapping', () => ({
  extractCategories: vi.fn(() => []),
  getWpiSections: vi.fn(() => []),
  mapPortsResponse: vi.fn(() => ({})),
}));

/* ------------------------------------------------------------------ */
/* COMPONENT MOCKS                                                     */
/* ------------------------------------------------------------------ */

vi.mock('@/shared/components/EntityLoadingSkeleton', () => ({
  default: () => <div>Loading Skeleton</div>,
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: () => <div>Error Page</div>,
}));

vi.mock('@/shared/ui/EntityToolbar', () => ({
  default: ({ title }: { title: string }) => <div>{title}</div>,
}));

vi.mock('@/shared/components/EntityTabs', () => ({
  default: ({
    tabs,
    onChange,
    renderActions,
  }: {
    tabs: { key: string; label: string }[];
    onChange: (key: string) => void;
    renderActions?: React.ReactNode;
  }) => (
    <div>
      {tabs.map((t) => (
        <button key={t.key} onClick={() => onChange(t.key)}>
          {t.label}
        </button>
      ))}
      {renderActions}
    </div>
  ),
}));

vi.mock('@/features/Ports/ui/PortEventsTab', () => ({
  default: () => <div>Port Events Panel</div>,
}));

vi.mock('@/shared/components/OverviewMap', () => ({
  default: () => <div>Overview Map</div>,
}));

vi.mock('@/shared/components/OverviewCharts', () => ({
  default: () => <div>Overview Charts</div>,
}));

vi.mock('@/features/Ports/ui/CongestionAndUtilisation', () => ({
  default: () => <div>Congestion And Utilisation</div>,
}));

vi.mock('@/shared/ui/EntityDetailsPanel', () => ({
  EntityDetailsPanel: ({ title }: { title: string }) => <div>{title}</div>,
}));

vi.mock('@/shared/components/VesselLoadingProgress', () => ({
  default: () => <div>Vessel Loading Progress</div>,
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    textLabel,
    handleClick,
  }: {
    textLabel: string;
    handleClick: () => void;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/features/Ports/components/CongestionTooltip', () => ({
  default: () => <div>Congestion Tooltip</div>,
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: () => <div>Stats Summary</div>,
}));

vi.mock('@/shared/components/VesselListItem', () => ({
  default: () => <div>Vessel List Item</div>,
}));

vi.mock('@/shared/components/VesselSummarySection', () => ({
  default: ({
    title,
    children,
  }: {
    title: string;
    children?: React.ReactNode;
  }) => (
    <div>
      <div>{title}</div>
      {children}
    </div>
  ),
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>CongestionEmptyState</div>,
}));

vi.mock('@/shared/components/LoadingTemplate', () => ({
  default: () => <div>LoadingTemplate</div>,
}));

/* ------------------------------------------------------------------ */
/* IMPORT MOCKED HOOKS                                                 */
/* ------------------------------------------------------------------ */

const usePortDetailsMock = vi.mocked(usePortDetails);
const useLibraryMock = vi.mocked(useLibrary);

/* ------------------------------------------------------------------ */
/* DEFAULT STATE                                                       */
/* ------------------------------------------------------------------ */

const basePort: Port = {
  id: 'port-1',
  name: 'Test Port',
  country_code: 'SG',
  country_common_name: 'Singapore',
  centroid: { latitude: 1.3, longitude: 103.8 },
} as Port;

function mockBaseState(
  overrides?: Partial<ReturnType<typeof usePortDetailsMock>>,
) {
  usePortDetailsMock.mockReturnValue({
    id: 'port-1',
    port: basePort,
    loading: false,
    error: null,
    refresh: false,
    setRefresh: vi.fn(),
    dateRange: { start: '2024-01-01', end: '2024-01-31' },
    setDateRange: vi.fn(),
    toggleBookmarkLoading: false,
    addOrRemoveBookmark: vi.fn(),
    isBookmarked: vi.fn(() => false),
    subscriptionData: undefined,
    manageSubscription: vi.fn(),
    getSubscription: vi.fn(),
    portBoundary: undefined,
    ...overrides,
  });
}

/* ------------------------------------------------------------------ */
/* TESTS                                                              */
/* ------------------------------------------------------------------ */

describe('PortDetailsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();

    useLibraryMock.mockReturnValue({
      exportToCSV: vi.fn(),
      bookmarks: [],
      setBookmarks: function (): void {
        throw new Error('Function not implemented.');
      },
      activeTab: '',
      setActiveTab: function (): void {
        throw new Error('Function not implemented.');
      },
      totalCount: 0,
      activeTabCount: 0,
      setActiveTabCount: function (): void {
        throw new Error('Function not implemented.');
      },
      fetchSavedEntities: function (): void {
        throw new Error('Function not implemented.');
      },
      loading: false,
      setLoading: function (): void {
        throw new Error('Function not implemented.');
      },
    });

    mockBaseState();
  });

  it('renders loading state', () => {
    mockBaseState({ loading: true, port: null });

    renderWithRouter(<PortDetailsPage />);

    expect(screen.getByText('Loading Skeleton')).toBeInTheDocument();
  });

  it('renders error state when error and port is missing', () => {
    mockBaseState({ error: 'fail', port: null });

    renderWithRouter(<PortDetailsPage />);

    expect(screen.getByText('Error Page')).toBeInTheDocument();
  });

  it('renders error state when port is null without error', () => {
    mockBaseState({ port: null });

    renderWithRouter(<PortDetailsPage />);

    expect(screen.getByText('Error Page')).toBeInTheDocument();
  });

  it('does not render error state when error exists but port is present', () => {
    mockBaseState({ error: 'some-error' });

    renderWithRouter(<PortDetailsPage />);

    expect(screen.queryByText('Error Page')).not.toBeInTheDocument();
    expect(screen.getByText('Test Port')).toBeInTheDocument();
  });

  it('renders overview tab by default', () => {
    renderWithRouter(<PortDetailsPage />);

    expect(screen.getByText('Overview Map')).toBeInTheDocument();
    expect(screen.getByText('Overview Charts')).toBeInTheDocument();
  });

  it('shows auto-update message on overview tab', () => {
    renderWithRouter(<PortDetailsPage />);

    expect(
      screen.getByText('Auto-updates every 5 minutes'),
    ).toBeInTheDocument();
  });

  it('switches to events tab', () => {
    renderWithRouter(<PortDetailsPage />);

    fireEvent.click(screen.getByText('Events'));

    expect(screen.getByText('Port Events Panel')).toBeInTheDocument();
  });

  it('switches to congestion and utilisation tab', () => {
    renderWithRouter(<PortDetailsPage />);

    fireEvent.click(screen.getByText('Congestion and Utilisation'));

    expect(screen.getByText('Congestion And Utilisation')).toBeInTheDocument();
  });

  it('shows congestion tooltip on congestion tab', () => {
    renderWithRouter(<PortDetailsPage />);

    fireEvent.click(screen.getByText('Congestion and Utilisation'));

    expect(screen.getByText('Congestion Tooltip')).toBeInTheDocument();
  });

  // it('switches to details tab', () => {
  //   renderWithRouter(<PortDetailsPage />);

  //   fireEvent.click(screen.getByText('Details'));

  //   expect(screen.getAllByText('Test Port').length).toBeGreaterThan(1);
  // });

  it('calls bookmark toggle', () => {
    const toggleMock = vi.fn();
    mockBaseState({ addOrRemoveBookmark: toggleMock });

    renderWithRouter(<PortDetailsPage />);

    toggleMock('port-1');

    expect(toggleMock).toHaveBeenCalledWith('port-1');
  });
});
