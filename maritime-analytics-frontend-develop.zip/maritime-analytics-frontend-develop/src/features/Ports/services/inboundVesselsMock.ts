import {
  InboundVesselsApiResponse,
  InboundVessel,
} from '../types/inboundVessels';

const mockInboundVessels: InboundVessel[] = [
  {
    reported_destination: {
      id: '21636a5a-1546-435d-824a-15dcaa375798',
      name: 'US NYC',
      raw: '',
      unlocode: 'USNYC',
      reported_at: '1970-01-01T00:00:00Z',
    },
    reported_eta: '1970-01-21T11:47:29.845Z',
    latest_position: {
      course: 224.5,
      draught: 12.3,
      latitude: 42.12,
      longitude: -72.76,
      navigational_status: {
        code: 0,
        status: 0,
      },
      speed: 11.5,
      timestamp: '0',
      heading: 224.5,
    },
    vessel_information: {
      asset_id: '6126dc34-34fd-47b1-931c-dc732d6a89e6',
      callsign: 'IJKL9012',
      imo: '8693982',
      mmsi: '123456789',
      name: 'Sea Explorer',
      flag_code: 'GB',
      flag: 'United Kingdom',
      vessel_type: 'Fishing Vessel',
    },
  },
  {
    reported_destination: {
      id: '31636a5a-1546-435d-824a-15dcaa375799',
      name: 'Balboa Port',
      raw: 'BALBOA',
      unlocode: 'PABAL',
      reported_at: '2026-02-05T14:30:00Z',
    },
    reported_eta: '2026-02-07T08:15:00Z',
    latest_position: {
      course: 180.0,
      draught: 14.8,
      latitude: 26.0658,
      longitude: 50.5483,
      navigational_status: {
        status: 0,
        code: 0,
      },
      speed: 12.8,
      timestamp: '2026-02-06T11:45:00Z',
      heading: 182.3,
    },
    vessel_information: {
      asset_id: '7126dc34-34fd-47b1-931c-dc732d6a89e7',
      callsign: 'MNOP3456',
      imo: '9234567',
      mmsi: '234567890',
      name: 'Ocean Carrier',
      flag_code: 'PA',
      flag: 'Panama',
      vessel_type: 'Cargo',
    },
  },
  {
    reported_destination: {
      id: '41636a5a-1546-435d-824a-15dcaa375800',
      name: 'Singapore Port',
      raw: 'SINGAPORE',
      unlocode: 'SGSIN',
      reported_at: '2026-02-06T09:20:00Z',
    },
    reported_eta: '2026-02-08T16:30:00Z',
    latest_position: {
      course: 45.2,
      draught: 16.5,
      latitude: 25.2048,
      longitude: 55.2708,
      navigational_status: {
        status: 0,
        code: 0,
      },
      speed: 15.2,
      timestamp: '2026-02-06T11:50:00Z',
      heading: 47.8,
    },
    vessel_information: {
      asset_id: '8126dc34-34fd-47b1-931c-dc732d6a89e8',
      callsign: 'QRST7890',
      imo: '9345678',
      mmsi: '345678901',
      name: 'Maritime Express',
      flag_code: 'SG',
      flag: 'Singapore',
      vessel_type: 'Container Ship',
    },
  },
  {
    reported_destination: {
      id: '51636a5a-1546-435d-824a-15dcaa375801',
      name: 'Rotterdam Port',
      raw: 'ROTTERDAM',
      unlocode: 'NLRTM',
      reported_at: '2026-02-06T07:15:00Z',
    },
    reported_eta: '2026-02-09T12:00:00Z',
    latest_position: {
      course: 315.7,
      draught: 18.2,
      latitude: 51.9225,
      longitude: 4.4792,
      navigational_status: {
        status: 0,
        code: 0,
      },
      speed: 18.5,
      timestamp: '2026-02-06T11:55:00Z',
      heading: 318.1,
    },
    vessel_information: {
      asset_id: '9126dc34-34fd-47b1-931c-dc732d6a89e9',
      callsign: 'UVWX1234',
      imo: '9456789',
      mmsi: '456789012',
      name: 'Atlantic Voyager',
      flag_code: 'NL',
      flag: 'Netherlands',
      vessel_type: 'Tanker',
    },
  },
  {
    reported_destination: {
      id: '61636a5a-1546-435d-824a-15dcaa375802',
      name: 'Hamburg Port',
      raw: 'HAMBURG',
      unlocode: 'DEHAM',
      reported_at: '2026-02-06T06:45:00Z',
    },
    reported_eta: '2026-02-10T09:30:00Z',
    latest_position: {
      course: 90.0,
      draught: 13.7,
      latitude: 53.5511,
      longitude: 9.9937,
      navigational_status: {
        code: 1,
        status: 1,
      },
      speed: 0.0,
      timestamp: '2026-02-06T12:00:00Z',
      heading: 92.5,
    },
    vessel_information: {
      asset_id: '0126dc34-34fd-47b1-931c-dc732d6a89f0',
      callsign: 'YZAB5678',
      imo: '9567890',
      mmsi: '567890123',
      name: 'Northern Star',
      flag_code: 'DE',
      flag: 'Germany',
      vessel_type: 'Bulk Carrier',
    },
  },
];

export const getInboundVesselsMock = async (
  _portId: string,
  limit: number = 100,
  offset: number = 0,
): Promise<InboundVesselsApiResponse> => {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  const startIndex = offset;
  const endIndex = Math.min(startIndex + limit, mockInboundVessels.length);
  const paginatedData = mockInboundVessels.slice(startIndex, endIndex);

  return {
    meta: {
      limit,
      offset,
      total_count: mockInboundVessels.length,
      request_id: `mock-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      request_timestamp: new Date().toISOString(),
    },
    data: paginatedData,
  };
};
