import { InboundVesselsApiResponse } from '../types/inboundVessels';
import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

// API configuration
const API_BASE_URL = `${API_GATEWAY_BASE_URL}/zone-port-insights/v1`;

// API query parameters interface
export interface InboundVesselsApiParams {
  id: string;
  id_type: 'id' | 'unlocode';
  flag_code_excl?: string;
  flag_code_incl?: string;
  offset?: number;
  reported_eta_gte?: string;
  reported_eta_lte?: string;
  vessel_type_excl?: string[];
  vessel_type_incl?: string[];
  last_destination_update_after?: string;
  limit?: number;
  exclude_arrived?: boolean;
}

/**
 * Fetch inbound vessels data from the real API endpoint
 * @param params API parameters including port/zone ID and filters
 * @returns Promise<InboundVesselsApiResponse>
 */
export async function getInboundVessels(
  params: InboundVesselsApiParams,
): Promise<InboundVesselsApiResponse> {
  const { id, id_type, ...queryParams } = params;

  // Build query string
  const searchParams = new URLSearchParams();
  Object.entries(queryParams).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      if (Array.isArray(value)) {
        value.forEach((item) => searchParams.append(key, item));
      } else {
        searchParams.append(key, String(value));
      }
    }
  });

  const url = `${API_BASE_URL}/inbound-vessels/${id_type}/${id}?${searchParams.toString()}`;

  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to fetch inbound vessels');
  }

  const data: InboundVesselsApiResponse = await res.json();
  return data;
}

/**
 * Convenience function for fetching inbound vessels with common defaults
 * @param portId Port identifier (UUID or UNLOCODE)
 * @param idType Type of identifier ('id' or 'unlocode')
 * @param limit Maximum number of results (default: 100)
 * @param offset Number of results to skip (default: 0)
 * @returns Promise<InboundVesselsApiResponse>
 */
export async function getInboundVesselsSimple(
  portId: string,
  idType: 'id' | 'unlocode' = 'id',
  limit: number = 100,
  offset: number = 0,
): Promise<InboundVesselsApiResponse> {
  return getInboundVessels({
    id: portId,
    id_type: idType,
    limit,
    offset,
  });
}
