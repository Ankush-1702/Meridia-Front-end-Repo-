import { BerthFilters } from '../types/portTypes';
import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  GroupBy,
  ICongestionResponse,
  ILiveDataResponse,
  PeriodAggregation,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export const getArrivalsAndDeparturesByTotals = async (
  portId: string,
  groupBy: GroupBy = 'NONE',
  periodAggregation: PeriodAggregation,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
    is_commercial: 'true',
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/arrivals-departures?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get Total Arrivals and Departures';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
};

export const getArrivalsByVesselType = async (
  portId: string,
  groupBy: GroupBy = 'VESSEL_TYPE',
  periodAggregation: PeriodAggregation,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
    is_commercial: 'true',
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/arrivals-departures?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get Arrivals by vessel type';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
};

export const getArrivalsByVesselTypesAndTotals = async (
  portId: string,
  groupBy: GroupBy = 'VESSEL_TYPE',
  periodAggregation: PeriodAggregation = 'NONE',
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<ICongestionResponse> => {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
    is_commercial: 'true',
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/arrivals-departures?${params.toString()}`,
    {
      headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get Arrivals by totals and vessel types';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
};

export const getLivePortCongestionData = async (
  portId: string,
): Promise<ILiveDataResponse> => {
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/live-traffic`,
    {
      headers: getAuthHeaders(),
    },
  );
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get live port congestion data';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
};

export async function getBerthTypeFilterOptions(
  portId: string,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
): Promise<BerthFilters> {
  const params = new URLSearchParams({
    date_start: dateStart,
    date_end: dateEnd,
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/dwell-filters?${params.toString()}`;

  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berth type filter options';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return data;
}

export async function getDwellTimeSeries(
  portId: string,
  groupBy: GroupBy = 'NONE',
  periodAggregation: PeriodAggregation,
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
  berthTypes?: string,
): Promise<ICongestionResponse> {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
    is_commercial: 'true',
  });

  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  if (berthTypes) params.append('berth_type', berthTypes);

  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/arrivals-departures?${params.toString()}`;
  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get dwell series';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
}

export async function getTopVisitingVessels(
  portId: string,
  groupBy: GroupBy = 'NONE',
  periodAggregation: PeriodAggregation = 'NONE',
  dateStart: string,
  dateEnd: string,
  vesselTypes?: string,
  flagCodes?: string,
  vesselClasses?: string,
  topVisitorSort: 'ASC' | 'DESC' = 'DESC',
  topVisitorsLimit: number = 50,
): Promise<ICongestionResponse> {
  const params = new URLSearchParams({
    group_by: groupBy,
    period_aggregation: periodAggregation,
    date_start: dateStart,
    date_end: dateEnd,
    is_commercial: 'true',
  });
  if (vesselTypes) params.append('vessel_types', vesselTypes);
  if (flagCodes) params.append('flag_codes', flagCodes);
  if (vesselClasses) params.append('vessel_class', vesselClasses);
  params.append('top_visitors_sort', topVisitorSort);
  params.append('top_visitors_limit', topVisitorsLimit.toString());
  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/analytics/ports/id/${portId}/arrivals-departures?${params.toString()}`;
  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get top visiting vessels';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return {
    ...data,
    location_information: data.port_information,
  };
}
