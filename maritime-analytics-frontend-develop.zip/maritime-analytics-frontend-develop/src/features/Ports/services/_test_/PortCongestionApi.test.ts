import { describe, it, expect, vi, beforeEach, Mock } from 'vitest';
import * as authUtil from '@/features/auth/utils/authUtil';
import {
  getArrivalsAndDeparturesByTotals,
  getArrivalsByVesselType,
  getArrivalsByVesselTypesAndTotals,
  getBerthTypeFilterOptions,
  getDwellTimeSeries,
  getLivePortCongestionData,
  getTopVisitingVessels,
} from '@/features/Ports/services/portCongestionApi';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import * as authHeaders from '@/shared/utils/authHeaders';

vi.mock('@/features/auth/utils/authUtil');
vi.mock('@/shared/utils/authHeaders');
vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.test.com',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
  API_BASE_URL: 'https://test-api.com',
}));

describe('portCongestionApi', () => {
  const mockAuthHeaders = { Authorization: 'Bearer test-token' };

  const locationInfo = {
    id: 'test-port-123',
    name: 'Test Port',
    unlocode: 'TSTPT',
    country_common_name: 'Test Country',
  };

  // Response for getArrivalsAndDeparturesByTotals (returns location_information directly)
  const mockCongestionResponse: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: locationInfo,
    totals: {
      arrivals: 300,
      departures: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', arrivals: 10, departures: 8 }],
      },
    ],
  };

  // Raw API response for endpoints that use port_information (before mapping)
  const mockRawApiResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-02-08',
      date_end: '2026-03-09',
      group_by: 'VESSEL_TYPE',
      period_aggregation: 'DAILY',
    },
    port_information: locationInfo,
    totals: {
      arrivals: 300,
      departures: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', arrivals: 10, departures: 8 }],
      },
    ],
  };

  // Raw API response for live-traffic endpoint (uses port_information)
  const mockRawLiveApiResponse = {
    meta: {
      timestamp_start: '2026-03-09T00:00:00Z',
      timestamp_end: '2026-03-09T10:00:00Z',
      request_id: 'req-live-123',
    },
    port_information: locationInfo,
    totals: {
      arrivals: 15,
      departures: 12,
      vessels_per_day: 27,
      max_vessels_per_day: 35,
      by_vessel_type: [{ group_by_key: 'Cargo', arrivals: 10, departures: 8 }],
    },
    data: [
      {
        period_key: '2026-03-09',
        items: [{ group_by_key: 'Cargo', arrivals: 10, departures: 8 }],
      },
    ],
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (authHeaders.getAuthHeaders as Mock).mockReturnValue(mockAuthHeaders);
  });

  describe('getArrivalsAndDeparturesByTotals', () => {
    it('should fetch arrivals and departures with required parameters', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getArrivalsAndDeparturesByTotals(
        'port-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/arrivals-departures?group_by=NONE&period_aggregation=DAILY&date_start=2026-01-01&date_end=2026-03-01&is_commercial=true',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawApiResponse.totals);
      expect(result.data).toEqual(mockRawApiResponse.data);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockCongestionResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getArrivalsAndDeparturesByTotals(
        'port-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier,Oil Tanker',
        'US,GB',
        'Handysize,Panamax',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier%2COil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US%2CGB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize%2CPanamax'),
        expect.anything(),
      );
    });

    it('should throw error with message when response is not ok', async () => {
      const errorBody = { message: 'Port not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Port not found');
    });

    it('should throw error with error field when message is not present', async () => {
      const errorBody = { error: 'Invalid request' };
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Invalid request');
    });

    it('should throw error with detail field when message and error are not present', async () => {
      const errorBody = { detail: 'Detailed error message' };
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Detailed error message');
    });

    it('should throw error with statusText when no error fields are present', async () => {
      const errorBody = {};
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Internal Server Error');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('JSON parse error')),
        text: vi.fn().mockResolvedValue('Plain text error'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Plain text error');
    });

    it('should include status and body in thrown error', async () => {
      const errorBody = { message: 'Port not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getArrivalsAndDeparturesByTotals(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  describe('getArrivalsByVesselType', () => {
    it('should fetch arrivals by vessel type and map port_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getArrivalsByVesselType(
        'port-123',
        'VESSEL_TYPE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/arrivals-departures?group_by=VESSEL_TYPE&period_aggregation=DAILY&date_start=2026-01-01&date_end=2026-03-01&is_commercial=true',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawApiResponse.totals);
      expect(result.data).toEqual(mockRawApiResponse.data);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getArrivalsByVesselType(
        'port-123',
        'VESSEL_TYPE',
        'WEEKLY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        'US',
        'Handysize',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize'),
        expect.anything(),
      );
    });

    it('should throw error when response is not ok', async () => {
      const errorBody = { message: 'Unauthorized' };
      const mockResponse = {
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsByVesselType(
          'port-123',
          'VESSEL_TYPE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Unauthorized');
    });

    it('should handle json parse failure', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Server Error',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Server error text'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsByVesselType(
          'port-123',
          'VESSEL_TYPE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Server error text');
    });

    it('should include status and body in thrown error', async () => {
      const errorBody = { message: 'Unauthorized' };
      const mockResponse = {
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getArrivalsByVesselType(
          'port-123',
          'VESSEL_TYPE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(401);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  describe('getArrivalsByVesselTypesAndTotals', () => {
    it('should fetch arrivals by vessel types and totals and map port_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getArrivalsByVesselTypesAndTotals(
        'port-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/arrivals-departures?group_by=VESSEL_TYPE&period_aggregation=NONE&date_start=2026-01-01&date_end=2026-03-01&is_commercial=true',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawApiResponse.totals);
      expect(result.data).toEqual(mockRawApiResponse.data);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getArrivalsByVesselTypesAndTotals(
        'port-123',
        'VESSEL_TYPE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Oil Tanker',
        'GB',
        'VLCC',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Oil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=GB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=VLCC'),
        expect.anything(),
      );
    });

    it('should throw error when response is not ok', async () => {
      const errorBody = { detail: 'Rate limit exceeded' };
      const mockResponse = {
        ok: false,
        status: 429,
        statusText: 'Too Many Requests',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsByVesselTypesAndTotals(
          'port-123',
          'VESSEL_TYPE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Rate limit exceeded');
    });

    it('should handle json parse failure', async () => {
      const mockResponse = {
        ok: false,
        status: 502,
        statusText: 'Bad Gateway',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Gateway timeout'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getArrivalsByVesselTypesAndTotals(
          'port-123',
          'VESSEL_TYPE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Gateway timeout');
    });

    it('should include status and body in thrown error', async () => {
      const errorBody = { detail: 'Rate limit exceeded' };
      const mockResponse = {
        ok: false,
        status: 429,
        statusText: 'Too Many Requests',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getArrivalsByVesselTypesAndTotals(
          'port-123',
          'VESSEL_TYPE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(429);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  describe('getLivePortCongestionData', () => {
    it('should fetch live port congestion data and map port_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawLiveApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getLivePortCongestionData('port-123');

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/live-traffic',
        {
          headers: mockAuthHeaders,
        },
      );
      expect(result.location_information).toEqual(locationInfo);
      expect(result.totals).toEqual(mockRawLiveApiResponse.totals);
      expect(result.data).toEqual(mockRawLiveApiResponse.data);
    });

    it('should throw error with message when response is not ok', async () => {
      const errorBody = { message: 'Port not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLivePortCongestionData('port-123')).rejects.toThrow(
        'Port not found',
      );
    });

    it('should throw error with error field', async () => {
      const errorBody = { error: 'Service unavailable' };
      const mockResponse = {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLivePortCongestionData('port-123')).rejects.toThrow(
        'Service unavailable',
      );
    });

    it('should throw error with detail field', async () => {
      const errorBody = { detail: 'Authentication required' };
      const mockResponse = {
        ok: false,
        status: 401,
        statusText: 'Unauthorized',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLivePortCongestionData('port-123')).rejects.toThrow(
        'Authentication required',
      );
    });

    it('should throw error with statusText when no error fields', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLivePortCongestionData('port-123')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('JSON parse error')),
        text: vi.fn().mockResolvedValue('Raw error text'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(getLivePortCongestionData('port-123')).rejects.toThrow(
        'Raw error text',
      );
    });

    it('should include status and body in thrown error', async () => {
      const errorBody = { message: 'Port not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getLivePortCongestionData('port-123');
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });

    it('should handle null port_information in response', async () => {
      const responseWithNulls = {
        meta: {
          timestamp_start: '2026-03-09T00:00:00Z',
          timestamp_end: '2026-03-09T10:00:00Z',
          request_id: 'req-123',
        },
        port_information: null,
        totals: null,
        data: [],
      };
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(responseWithNulls),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getLivePortCongestionData('port-123');

      expect(result.location_information).toBeNull();
      expect(result.totals).toBeNull();
    });
  });

  /* ---- getBerthTypeFilterOptions ---- */
  describe('getBerthTypeFilterOptions', () => {
    const mockBerthFilters = {
      berth_types: ['General', 'Container', 'Liquid'],
    };

    it('should fetch berth type filters with required parameters', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockBerthFilters),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getBerthTypeFilterOptions(
        'port-123',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/dwell-filters?date_start=2026-01-01&date_end=2026-03-01',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result).toEqual(mockBerthFilters);
    });

    it('should include optional parameters when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockBerthFilters),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getBerthTypeFilterOptions(
        'port-123',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        'US',
        'Handysize',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize'),
        expect.anything(),
      );
    });

    it('should not include optional params when they are falsy', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockBerthFilters),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01');

      const calledUrl = (authUtil.fetchWithAuth as Mock).mock
        .calls[0][0] as string;
      expect(calledUrl).not.toContain('vessel_types');
      expect(calledUrl).not.toContain('flag_codes');
      expect(calledUrl).not.toContain('vessel_class');
    });

    it('should throw error with message field', async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue({ message: 'Port not found' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01'),
      ).rejects.toThrow('Port not found');
    });

    it('should throw error with error field when message absent', async () => {
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue({ error: 'Invalid params' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01'),
      ).rejects.toThrow('Invalid params');
    });

    it('should throw error with detail field when others absent', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({ detail: 'Detailed error' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01'),
      ).rejects.toThrow('Detailed error');
    });

    it('should throw error with statusText when no error fields', async () => {
      const mockResponse = {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01'),
      ).rejects.toThrow('Service Unavailable');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Server Error',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Plain error text'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01'),
      ).rejects.toThrow('Plain error text');
    });

    it('should attach status and body to thrown error', async () => {
      const errorBody = { message: 'Not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getBerthTypeFilterOptions('port-123', '2026-01-01', '2026-03-01');
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  /* ---- getDwellTimeSeries ---- */
  describe('getDwellTimeSeries', () => {
    it('should fetch dwell time series and map port_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getDwellTimeSeries(
        'port-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        'https://api.test.com/maritime-analytics/v1/analytics/ports/id/port-123/arrivals-departures?group_by=NONE&period_aggregation=DAILY&date_start=2026-01-01&date_end=2026-03-01&is_commercial=true',
        {
          headers: { ...mockAuthHeaders, 'Content-Type': 'application/json' },
        },
      );
      expect(result.location_information).toEqual(locationInfo);
    });

    it('should include berth_type param when provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getDwellTimeSeries(
        'port-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
        undefined,
        undefined,
        undefined,
        'General,Container',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('berth_type=General%2CContainer'),
        expect.anything(),
      );
    });

    it('should not include berth_type param when not provided', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getDwellTimeSeries(
        'port-123',
        'NONE',
        'DAILY',
        '2026-01-01',
        '2026-03-01',
      );

      const calledUrl = (authUtil.fetchWithAuth as Mock).mock
        .calls[0][0] as string;
      expect(calledUrl).not.toContain('berth_type');
    });

    it('should include optional vessel/flag/class params', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockRawApiResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getDwellTimeSeries(
        'port-123',
        'NONE',
        'WEEKLY',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier',
        'US',
        'Handysize',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize'),
        expect.anything(),
      );
    });

    it('should throw error with message field', async () => {
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue({ message: 'Invalid date range' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getDwellTimeSeries(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Invalid date range');
    });

    it('should throw error with detail field', async () => {
      const mockResponse = {
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: vi.fn().mockResolvedValue({ detail: 'Access denied' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getDwellTimeSeries(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Access denied');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 502,
        statusText: 'Bad Gateway',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Gateway error'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getDwellTimeSeries(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Gateway error');
    });

    it('should attach status and body to thrown error', async () => {
      const errorBody = { message: 'Failed to get dwell series' };
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getDwellTimeSeries(
          'port-123',
          'NONE',
          'DAILY',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(500);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });

  /* ---- getTopVisitingVessels ---- */
  describe('getTopVisitingVessels', () => {
    const mockTopVisitorsResponse = {
      ...mockRawApiResponse,
      top_visitors: [
        {
          rank: 1,
          vessel_name: 'VESSEL ONE',
          imo_number: '1234567',
          flag_code: 'US',
          flag_name: 'United States',
          ship_type_level_3: 'Bulk carrier',
          visit_count: 15,
        },
      ],
    };

    it('should fetch top visiting vessels and map port_information to location_information', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      const result = await getTopVisitingVessels(
        'port-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining(
          '/analytics/ports/id/port-123/arrivals-departures',
        ),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('group_by=NONE'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('period_aggregation=NONE'),
        expect.anything(),
      );
      expect(result.location_information).toEqual(locationInfo);
    });

    it('should include top_visitors_sort param', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'port-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        undefined,
        undefined,
        undefined,
        'ASC',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('top_visitors_sort=ASC'),
        expect.anything(),
      );
    });

    it('should default top_visitors_sort to DESC', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'port-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('top_visitors_sort=DESC'),
        expect.anything(),
      );
    });

    it('should include top_visitors_limit param', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'port-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        undefined,
        undefined,
        undefined,
        'DESC',
        25,
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('top_visitors_limit=25'),
        expect.anything(),
      );
    });

    it('should include optional vessel/flag/class params', async () => {
      const mockResponse = {
        ok: true,
        json: vi.fn().mockResolvedValue(mockTopVisitorsResponse),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await getTopVisitingVessels(
        'port-123',
        'NONE',
        'NONE',
        '2026-01-01',
        '2026-03-01',
        'Bulk carrier,Oil Tanker',
        'US,GB',
        'Handysize,VLCC',
      );

      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_types=Bulk+carrier%2COil+Tanker'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('flag_codes=US%2CGB'),
        expect.anything(),
      );
      expect(authUtil.fetchWithAuth).toHaveBeenCalledWith(
        expect.stringContaining('vessel_class=Handysize%2CVLCC'),
        expect.anything(),
      );
    });

    it('should throw error with message field', async () => {
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue({ message: 'Port not found' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Port not found');
    });

    it('should throw error with error field when message absent', async () => {
      const mockResponse = {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: vi.fn().mockResolvedValue({ error: 'Bad request' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Bad request');
    });

    it('should throw error with detail field when others absent', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockResolvedValue({ detail: 'Server detail error' }),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Server detail error');
    });

    it('should throw with statusText when no error fields', async () => {
      const mockResponse = {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        json: vi.fn().mockResolvedValue({}),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Service Unavailable');
    });

    it('should handle json parse failure and use text response', async () => {
      const mockResponse = {
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: vi.fn().mockRejectedValue(new Error('Parse error')),
        text: vi.fn().mockResolvedValue('Raw error'),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      await expect(
        getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        ),
      ).rejects.toThrow('Raw error');
    });

    it('should attach status and body to thrown error', async () => {
      const errorBody = { message: 'Port not found' };
      const mockResponse = {
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: vi.fn().mockResolvedValue(errorBody),
      };
      (authUtil.fetchWithAuth as Mock).mockResolvedValue(mockResponse);

      try {
        await getTopVisitingVessels(
          'port-123',
          'NONE',
          'NONE',
          '2026-01-01',
          '2026-03-01',
        );
      } catch (error) {
        const typedError = error as Error & { status: number; body: unknown };
        expect(typedError.status).toBe(404);
        expect(typedError.body).toEqual(errorBody);
      }
    });
  });
});
