import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  fetchPortDetails,
  fetchPortBoundary,
  fetchPortEvents,
  fetchBerthEvents,
  fetchPortSubscriptions,
  createPortSubscription,
  updatePortSubscription,
} from '../portServices';
import type {
  ISubscription,
  ScheduleType,
  SubscriptionResponseDataType,
} from '@/shared/types/subscriptionTypes';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: vi.fn(),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.gateway',
  MARITIME_ANALYTICS_API_PATH: '/maritime-analytics/v1',
}));

/* ------------------------------------------------------------------ */
/* types                                                              */
/* ------------------------------------------------------------------ */

interface MockFetchResponse {
  ok: boolean;
  status: number;
  statusText: string;
  json: () => Promise<unknown>;
  text: () => Promise<string>;
}

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

function mockUser() {
  localStorage.setItem('user', JSON.stringify({ user_id: 'user-1' }));
}

async function getFetchWithAuth() {
  const { fetchWithAuth } = await import('@/features/auth/utils/authUtil');
  return vi.mocked(fetchWithAuth);
}

async function mockFetch(response: MockFetchResponse) {
  const fetch = await getFetchWithAuth();
  fetch.mockResolvedValue(response as unknown as Response);
}

function okResponse(data: unknown): MockFetchResponse {
  return {
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
    text: async () => '',
  };
}

function errorResponse(
  status: number,
  body: Record<string, unknown>,
  statusText = 'Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: async () => body,
    text: async () => body.message?.toString() ?? 'Error',
  };
}

function errorJsonFails(
  status = 500,
  statusText = 'Server Error',
): MockFetchResponse {
  return {
    ok: false,
    status,
    statusText,
    json: () => Promise.reject(new Error('not json')),
    text: async () => 'Plain text error',
  };
}

/* ------------------------------------------------------------------ */
/* shared subscription fixture                                        */
/* ------------------------------------------------------------------ */

const baseSubscription: SubscriptionResponseDataType = {
  subscription_exists: true,
  subscription_id: 'sub-1',
  name: 'Port',
  active: true,
  notify_on: {
    PORT_ARRIVAL: true,
    PORT_DEPARTURE: false,
    PORT_AREA_ARRIVAL: false,
    PORT_AREA_DEPARTURE: false,
  },
  vessel_screening: { active: false, severity_filter: [] },
  email_settings: {
    email_enabled: false,
    scheduler: { schedule_type: 1 as ScheduleType, at_time: '08:00' },
  },
};

const baseSubscriptionBody: ISubscription = {
  entity_ref_id: 'port-1',
  entity_type: 'PORT',
  name: 'Port',
  active: true,
  notify_on: {
    PORT_ARRIVAL: true,
    PORT_DEPARTURE: true,
    PORT_AREA_ARRIVAL: true,
    PORT_AREA_DEPARTURE: true,
  },
  vessel_screening: { active: false, severity_filter: [] },
  email_settings: {
    email_enabled: false,
    scheduler: { schedule_type: 1 as ScheduleType, at_time: '08:00' },
  },
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('portServices', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    mockUser();
  });

  /* ---------------------------------------------------------------- */
  /* fetchPortDetails                                                 */
  /* ---------------------------------------------------------------- */

  describe('fetchPortDetails', () => {
    it('fetches port details and returns data', async () => {
      await mockFetch(okResponse({ data: { id: 'port-1', name: 'Port A' } }));

      const result = await fetchPortDetails('port-1');

      expect(result).toEqual({ id: 'port-1', name: 'Port A' });
    });

    it('calls the correct URL with user_id', async () => {
      await mockFetch(okResponse({ data: {} }));
      const fetch = await getFetchWithAuth();

      await fetchPortDetails('port-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/zone-port-insights/v1/zones/port-1?user_id=user-1',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Not Found' }));
      await expect(fetchPortDetails('port-1')).rejects.toThrow('Not Found');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad port id' }));
      await expect(fetchPortDetails('port-1')).rejects.toThrow('Bad port id');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(fetchPortDetails('port-1')).rejects.toThrow(
        'Validation failed',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(fetchPortDetails('port-1')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(fetchPortDetails('port-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await fetchPortDetails('port-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchPortBoundary                                                */
  /* ---------------------------------------------------------------- */

  describe('fetchPortBoundary', () => {
    it('fetches port boundary and returns data', async () => {
      const boundary = { id: 'port-1', name: 'Port A', geometry: 'abc' };
      await mockFetch(okResponse(boundary));

      const result = await fetchPortBoundary('port-1');

      expect(result).toEqual(boundary);
    });

    it('calls the correct URL', async () => {
      await mockFetch(okResponse({}));
      const fetch = await getFetchWithAuth();

      await fetchPortBoundary('port-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/zones/port-1',
        expect.objectContaining({
          headers: expect.objectContaining({ Authorization: 'Bearer token' }),
        }),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(404, { message: 'Boundary not found' }));
      await expect(fetchPortBoundary('port-1')).rejects.toThrow(
        'Boundary not found',
      );
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Invalid id' }));
      await expect(fetchPortBoundary('port-1')).rejects.toThrow('Invalid id');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Unprocessable' }));
      await expect(fetchPortBoundary('port-1')).rejects.toThrow(
        'Unprocessable',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(fetchPortBoundary('port-1')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(fetchPortBoundary('port-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await fetchPortBoundary('port-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchPortEvents                                                  */
  /* ---------------------------------------------------------------- */

  describe('fetchPortEvents', () => {
    it('fetches port events and returns data', async () => {
      await mockFetch(
        okResponse({
          data: { events: [{ id: 'e1' }] },
          meta: { total_count: 1 },
        }),
      );

      const result = await fetchPortEvents('port-1');

      expect(result).toEqual({ data: [{ id: 'e1' }], totalCount: 1 });
    });

    it('uses zone-and-port-traffic endpoint', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchPortEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/zone-and-port-traffic/id/port-1');
    });

    it('includes default query params in the URL', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchPortEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('limit=500');
      expect(calledUrl).toContain('offset=0');
      expect(calledUrl).toContain('flatten_json=true');
      expect(calledUrl).toContain('all_data=true');
      expect(calledUrl).toContain('excl_port_information=true');
      expect(calledUrl).toContain('excl_event_details=true');
    });

    it('appends timestamp_start and timestamp_end when provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchPortEvents('port-1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('timestamp_start=2025-01-01');
      expect(calledUrl).toContain('timestamp_end=2025-01-31');
    });

    it('does not append timestamp params when not provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchPortEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).not.toContain('timestamp_start');
      expect(calledUrl).not.toContain('timestamp_end');
    });

    it('uses custom limit and offset when provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchPortEvents('port-1', undefined, undefined, 50, 100);

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('offset=50');
      expect(calledUrl).toContain('limit=100');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(500, { message: 'Server Error' }));
      await expect(fetchPortEvents('port-1')).rejects.toThrow('Server Error');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(fetchPortEvents('port-1')).rejects.toThrow('Bad request');
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(errorResponse(422, { detail: 'Validation failed' }));
      await expect(fetchPortEvents('port-1')).rejects.toThrow(
        'Validation failed',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(fetchPortEvents('port-1')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(fetchPortEvents('port-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(422, { message: 'Unprocessable' }));

      const err = await fetchPortEvents('port-1').catch((e) => e);

      expect(err.status).toBe(422);
      expect(err.body).toEqual({ message: 'Unprocessable' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchBerthEvents                                                 */
  /* ---------------------------------------------------------------- */

  describe('fetchBerthEvents', () => {
    it('fetches berth events and returns data', async () => {
      await mockFetch(
        okResponse({
          data: { events: [{ id: 'b1' }] },
          meta: { total_count: 1 },
        }),
      );

      const result = await fetchBerthEvents('port-1');

      expect(result).toEqual({ data: [{ id: 'b1' }], totalCount: 1 });
    });

    it('uses port-berth-traffic endpoint', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchBerthEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('/port-berth-traffic/id/port-1');
    });

    it('includes default query params in the URL', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchBerthEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('limit=500');
      expect(calledUrl).toContain('offset=0');
      expect(calledUrl).toContain('flatten_json=true');
      expect(calledUrl).toContain('all_data=true');
      expect(calledUrl).toContain('excl_port_information=true');
      expect(calledUrl).toContain('excl_event_details=true');
    });

    it('appends timestamp_start and timestamp_end when provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchBerthEvents('port-1', '2025-01-01', '2025-01-31');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('timestamp_start=2025-01-01');
      expect(calledUrl).toContain('timestamp_end=2025-01-31');
    });

    it('does not append timestamp params when not provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchBerthEvents('port-1');

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).not.toContain('timestamp_start');
      expect(calledUrl).not.toContain('timestamp_end');
    });

    it('uses custom limit and offset when provided', async () => {
      await mockFetch(
        okResponse({ data: { events: [] }, meta: { total_count: 0 } }),
      );
      const fetch = await getFetchWithAuth();

      await fetchBerthEvents('port-1', undefined, undefined, 50, 100);

      const calledUrl = fetch.mock.calls[0][0] as string;
      expect(calledUrl).toContain('offset=50');
      expect(calledUrl).toContain('limit=100');
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(500, { message: 'Berth Error' }));
      await expect(fetchBerthEvents('port-1')).rejects.toThrow('Berth Error');
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad berth request' }));
      await expect(fetchBerthEvents('port-1')).rejects.toThrow(
        'Bad berth request',
      );
    });

    it('throws with message from errBody.detail when message and error are absent', async () => {
      await mockFetch(
        errorResponse(422, { detail: 'Berth validation failed' }),
      );
      await expect(fetchBerthEvents('port-1')).rejects.toThrow(
        'Berth validation failed',
      );
    });

    it('throws with statusText when body has no message fields', async () => {
      await mockFetch(errorResponse(500, {}, 'Internal Server Error'));
      await expect(fetchBerthEvents('port-1')).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(fetchBerthEvents('port-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(422, { message: 'Unprocessable' }));

      const err = await fetchBerthEvents('port-1').catch((e) => e);

      expect(err.status).toBe(422);
      expect(err.body).toEqual({ message: 'Unprocessable' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* fetchPortSubscriptions                                           */
  /* ---------------------------------------------------------------- */

  describe('fetchPortSubscriptions', () => {
    it('fetches and returns subscription data', async () => {
      await mockFetch(okResponse(baseSubscription));

      const result = await fetchPortSubscriptions('sub-1');

      expect(result).toEqual(baseSubscription);
    });

    it('calls the correct URL with user_id and subscription_id', async () => {
      await mockFetch(okResponse(baseSubscription));
      const fetch = await getFetchWithAuth();

      await fetchPortSubscriptions('sub-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions/sub-1',
        expect.anything(),
      );
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));
      await expect(fetchPortSubscriptions('sub-1')).rejects.toThrow(
        'Forbidden',
      );
    });

    it('throws with message from errBody.error when message is absent', async () => {
      await mockFetch(errorResponse(400, { error: 'Bad request' }));
      await expect(fetchPortSubscriptions('sub-1')).rejects.toThrow(
        'Bad request',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(fetchPortSubscriptions('sub-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(403, { message: 'Forbidden' }));

      const err = await fetchPortSubscriptions('sub-1').catch((e) => e);

      expect(err.status).toBe(403);
      expect(err.body).toEqual({ message: 'Forbidden' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* createPortSubscription                                           */
  /* ---------------------------------------------------------------- */

  describe('createPortSubscription', () => {
    it('creates and returns subscription', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));

      const result = await createPortSubscription(baseSubscriptionBody);

      expect(result).toEqual({ subscription_exists: true });
    });

    it('calls POST to the correct URL', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));
      const fetch = await getFetchWithAuth();

      await createPortSubscription(baseSubscriptionBody);

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions',
        expect.objectContaining({ method: 'POST' }),
      );
    });

    it('serialises the body as JSON', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));
      const fetch = await getFetchWithAuth();

      await createPortSubscription(baseSubscriptionBody);

      const options = fetch.mock.calls[0][1] as RequestInit;
      expect(options.body).toBe(JSON.stringify(baseSubscriptionBody));
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Create failed' }));
      await expect(
        createPortSubscription(baseSubscriptionBody),
      ).rejects.toThrow('Create failed');
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(
        createPortSubscription(baseSubscriptionBody),
      ).rejects.toThrow('Plain text error');
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(400, { message: 'Create failed' }));

      const err = await createPortSubscription(baseSubscriptionBody).catch(
        (e) => e,
      );

      expect(err.status).toBe(400);
      expect(err.body).toEqual({ message: 'Create failed' });
    });
  });

  /* ---------------------------------------------------------------- */
  /* updatePortSubscription                                           */
  /* ---------------------------------------------------------------- */

  describe('updatePortSubscription', () => {
    const updateBody: ISubscription = {
      ...baseSubscriptionBody,
      active: false,
    };

    it('updates and returns subscription', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));

      const result = await updatePortSubscription(updateBody, 'sub-1');

      expect(result).toEqual({ subscription_exists: true });
    });

    it('calls PUT to the correct URL with subscription_id', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));
      const fetch = await getFetchWithAuth();

      await updatePortSubscription(updateBody, 'sub-1');

      expect(fetch).toHaveBeenCalledWith(
        'https://api.gateway/maritime-analytics/v1/users/user-1/zone-port-subscriptions/sub-1',
        expect.objectContaining({ method: 'PUT' }),
      );
    });

    it('serialises the body as JSON', async () => {
      await mockFetch(okResponse({ subscription_exists: true }));
      const fetch = await getFetchWithAuth();

      await updatePortSubscription(updateBody, 'sub-1');

      const options = fetch.mock.calls[0][1] as RequestInit;
      expect(options.body).toBe(JSON.stringify(updateBody));
    });

    it('throws with message from errBody.message', async () => {
      await mockFetch(errorResponse(400, { message: 'Update failed' }));
      await expect(updatePortSubscription(updateBody, 'sub-1')).rejects.toThrow(
        'Update failed',
      );
    });

    it('falls back to text when error body json() fails', async () => {
      await mockFetch(errorJsonFails());
      await expect(updatePortSubscription(updateBody, 'sub-1')).rejects.toThrow(
        'Plain text error',
      );
    });

    it('attaches status and body to the thrown error', async () => {
      await mockFetch(errorResponse(500, { message: 'Update failed' }));

      const err = await updatePortSubscription(updateBody, 'sub-1').catch(
        (e) => e,
      );

      expect(err.status).toBe(500);
      expect(err.body).toEqual({ message: 'Update failed' });
    });
  });
});
