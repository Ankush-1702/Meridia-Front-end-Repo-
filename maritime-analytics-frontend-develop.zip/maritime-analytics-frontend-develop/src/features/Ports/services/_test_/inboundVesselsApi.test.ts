import { describe, it, expect, vi, beforeEach } from 'vitest';
import { InboundVesselsApiResponse } from '../../types/inboundVessels';
import {
  getInboundVessels,
  getInboundVesselsSimple,
  InboundVesselsApiParams,
} from '../inboundVesselsApi';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const mockFetchWithAuth = vi.fn();
const mockGetAuthHeaders = vi.fn();

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: (...args: unknown[]) => mockFetchWithAuth(...args),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => mockGetAuthHeaders(),
}));

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

const mockSuccessResponse: InboundVesselsApiResponse = {
  meta: {
    limit: 100,
    offset: 0,
    total_count: 2,
    request_id: 'test-request-123',
    request_timestamp: '2026-02-12T10:00:00Z',
  },
  data: [
    {
      vessel_information: {
        asset_id: 'asset-1',
        name: 'Test Vessel 1',
        imo: '9234567',
        mmsi: '234567890',
        callsign: 'TEST1',
        vessel_type: 'Cargo',
        flag: 'United Kingdom',
        flag_code: 'GB',
      },
      reported_destination: {
        id: 'dest-1',
        name: 'Hamburg Port',
        raw: 'HAMBURG',
        unlocode: 'DEHAM',
        reported_at: '2026-02-11T14:30:00Z',
      },
      reported_eta: '2026-02-12T20:45:00Z',
      latest_position: {
        latitude: 53.5511,
        longitude: 9.9937,
        course: 180.0,
        speed: 12.8,
        heading: 182.3,
        draught: 14.8,
        navigational_status: {
          status: 0,
          code: 0,
        },
        timestamp: '2026-02-06T11:45:00Z',
      },
    },
    {
      vessel_information: {
        asset_id: 'asset-2',
        name: 'Test Vessel 2',
        imo: '9345678',
        mmsi: '345678901',
        callsign: 'TEST2',
        vessel_type: 'Container Ship',
        flag: 'Singapore',
        flag_code: 'SG',
      },
      reported_destination: {
        id: 'dest-2',
        name: 'Singapore Port',
        raw: 'SINGAPORE',
        unlocode: 'SGSIN',
        reported_at: '2026-02-06T09:20:00Z',
      },
      reported_eta: '2026-02-12T16:30:00Z',
      latest_position: {
        latitude: 53.6511,
        longitude: 9.8937,
        course: 45.2,
        speed: 15.2,
        heading: 47.8,
        draught: 16.5,
        navigational_status: {
          status: 0,
          code: 0,
        },
        timestamp: '2026-02-06T11:50:00Z',
      },
    },
  ],
};

const mockFetchSuccess = (data: InboundVesselsApiResponse) => {
  mockFetchWithAuth.mockResolvedValueOnce({
    ok: true,
    status: 200,
    statusText: 'OK',
    json: async () => data,
  });
};

const mockFetchError = (
  status: number,
  statusText: string,
  errorBody?: Record<string, string>,
) => {
  mockFetchWithAuth.mockResolvedValueOnce({
    ok: false,
    status,
    statusText,
    json: async () => errorBody || { error: statusText },
  });
};

const mockFetchNetworkError = () => {
  mockFetchWithAuth.mockRejectedValueOnce(new Error('Network error'));
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('inboundVesselsApi', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetAuthHeaders.mockReturnValue({
      Authorization: 'Bearer test-token',
    });
  });

  describe('getInboundVessels', () => {
    it('fetches inbound vessels successfully with ID', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      const result = await getInboundVessels(params);

      expect(result).toEqual(mockSuccessResponse);
      expect(mockFetchWithAuth).toHaveBeenCalledTimes(1);
    });

    it('fetches inbound vessels successfully with UNLOCODE', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'DEHAM',
        id_type: 'unlocode',
      };

      const result = await getInboundVessels(params);

      expect(result).toEqual(mockSuccessResponse);
      expect(mockFetchWithAuth).toHaveBeenCalledTimes(1);
    });

    it('calls fetchWithAuth with auth headers from getAuthHeaders', async () => {
      mockGetAuthHeaders.mockReturnValue({
        Authorization: 'Bearer my-auth-token',
      });
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await getInboundVessels(params);

      expect(mockFetchWithAuth).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer my-auth-token',
            'Content-Type': 'application/json',
          }),
        }),
      );
    });

    it('includes Content-Type header', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await getInboundVessels(params);

      expect(mockFetchWithAuth).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
        }),
      );
    });

    it('builds correct URL with ID type', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('/inbound-vessels/id/port-123');
    });

    it('builds correct URL with UNLOCODE type', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'DEHAM',
        id_type: 'unlocode',
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('/inbound-vessels/unlocode/DEHAM');
    });

    it('includes query parameters in URL', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
        limit: 50,
        offset: 10,
        flag_code_incl: 'GB',
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('limit=50');
      expect(callUrl).toContain('offset=10');
      expect(callUrl).toContain('flag_code_incl=GB');
    });

    it('handles array parameters correctly', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
        vessel_type_incl: ['Cargo', 'Tanker'],
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('vessel_type_incl=Cargo');
      expect(callUrl).toContain('vessel_type_incl=Tanker');
    });

    it('omits undefined and null parameters', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
        limit: undefined,
        offset: undefined,
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).not.toContain('limit=');
      expect(callUrl).not.toContain('offset=');
    });

    it('includes date range parameters', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
        reported_eta_gte: '2026-02-01T00:00:00Z',
        reported_eta_lte: '2026-02-28T23:59:59Z',
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('reported_eta_gte=');
      expect(callUrl).toContain('reported_eta_lte=');
    });

    it('handles 404 error with parsed error body', async () => {
      mockFetchError(404, 'Not Found', { message: 'Port not found' });

      const params: InboundVesselsApiParams = {
        id: 'invalid-port',
        id_type: 'id',
      };

      await expect(getInboundVessels(params)).rejects.toThrow('Port not found');
    });

    it('handles 401 unauthorized error', async () => {
      mockFetchError(401, 'Unauthorized', { error: 'Unauthorized' });

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await expect(getInboundVessels(params)).rejects.toThrow('Unauthorized');
    });

    it('handles 500 server error', async () => {
      mockFetchError(500, 'Internal Server Error', {
        detail: 'Server failure',
      });

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await expect(getInboundVessels(params)).rejects.toThrow('Server failure');
    });

    it('falls back to statusText when error body has no message', async () => {
      mockFetchError(500, 'Internal Server Error', {});

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await expect(getInboundVessels(params)).rejects.toThrow(
        'Internal Server Error',
      );
    });

    it('handles network error', async () => {
      mockFetchNetworkError();

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await expect(getInboundVessels(params)).rejects.toThrow('Network error');
    });

    it('attaches status and body to error on non-ok response', async () => {
      mockFetchError(403, 'Forbidden', { error: 'Access denied' });

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      try {
        await getInboundVessels(params);
        expect.unreachable('Should have thrown');
      } catch (err) {
        const error = err as Error & { status: number; body: unknown };
        expect(error.status).toBe(403);
        expect(error.body).toEqual({ error: 'Access denied' });
      }
    });
  });

  describe('getInboundVesselsSimple', () => {
    it('calls getInboundVessels with correct default params', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const result = await getInboundVesselsSimple('port-123', 'id', 100, 0);

      expect(result).toEqual(mockSuccessResponse);
      expect(mockFetchWithAuth).toHaveBeenCalledTimes(1);
    });

    it('uses default idType of "id"', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123');

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('/inbound-vessels/id/port-123');
    });

    it('uses default limit of 100', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123', 'id');

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('limit=100');
    });

    it('uses default offset of 0', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123', 'id', 100);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('offset=0');
    });

    it('accepts custom limit', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123', 'id', 50, 0);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('limit=50');
    });

    it('accepts custom offset', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123', 'id', 100, 25);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('offset=25');
    });

    it('accepts unlocode as idType', async () => {
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('DEHAM', 'unlocode', 100, 0);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('/inbound-vessels/unlocode/DEHAM');
    });

    it('uses auth headers from getAuthHeaders', async () => {
      mockGetAuthHeaders.mockReturnValue({
        Authorization: 'Bearer my-token',
      });
      mockFetchSuccess(mockSuccessResponse);

      await getInboundVesselsSimple('port-123', 'id', 100, 0);

      expect(mockFetchWithAuth).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer my-token',
          }),
        }),
      );
    });

    it('handles API errors', async () => {
      mockFetchError(404, 'Not Found', { message: 'Port not found' });

      await expect(
        getInboundVesselsSimple('invalid-port', 'id', 100, 0),
      ).rejects.toThrow('Port not found');
    });
  });

  describe('API_BASE_URL', () => {
    it('uses correct API base URL', async () => {
      mockFetchSuccess(mockSuccessResponse);

      const params: InboundVesselsApiParams = {
        id: 'port-123',
        id_type: 'id',
      };

      await getInboundVessels(params);

      const callUrl = mockFetchWithAuth.mock.calls[0][0];
      expect(callUrl).toContain('/zone-port-insights/v1');
    });
  });
});
