import {
  API_GATEWAY_BASE_URL,
  MARITIME_ANALYTICS_API_PATH,
} from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { BerthEvents, PortEvents } from '@/features/Ports/types/portTypes';
import { Port } from '@/shared/types/entities';
import {
  ISubscription,
  SubscriptionResponseDataType,
} from '@/shared/types/subscriptionTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export async function fetchPortDetails(id: string): Promise<Port> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const url = `${API_GATEWAY_BASE_URL}/zone-port-insights/v1/zones/${id}?user_id=${encodeURIComponent(user_id)}`;
  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to get port details');
  }
  const data = await res.json();
  return data.data;
}

export async function fetchPortBoundary(
  id: string,
): Promise<Omit<Port, 'centroid'>> {
  const url = `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/zones/${id}`;
  const res = await fetchWithAuth(url, {
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get port boundary';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  const data = await res.json();
  return data;
}

export async function fetchPortEvents(
  id: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit: number = 500,
) {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
    flatten_json: 'true',
    all_data: 'true',
    excl_port_information: 'true',
    excl_event_details: 'true',
  });
  if (timestamp_start) params.append('timestamp_start', timestamp_start);
  if (timestamp_end) params.append('timestamp_end', timestamp_end);

  const endpoint = `${API_GATEWAY_BASE_URL}/zone-port-insights/v1/zone-and-port-traffic/id/${id}`;

  const res = await fetchWithAuth(`${endpoint}?${params.toString()}`, {
    headers: getAuthHeaders(),
  });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get port events';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  const response = await res.json();
  const data: PortEvents[] = response.data.events;
  const totalCount = response.meta.total_count;
  return { data, totalCount };
}

export async function fetchBerthEvents(
  id: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit: number = 500,
) {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
    flatten_json: 'true',
    all_data: 'true',
    excl_port_information: 'true',
    excl_event_details: 'true',
  });
  if (timestamp_start) params.append('timestamp_start', timestamp_start);
  if (timestamp_end) params.append('timestamp_end', timestamp_end);

  const endpoint = `${API_GATEWAY_BASE_URL}/zone-port-insights/v1/port-berth-traffic/id/${id}`;

  const res = await fetchWithAuth(`${endpoint}?${params.toString()}`, {
    headers: getAuthHeaders(),
  });

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to get berth events';
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }

  const response = await res.json();
  const data: BerthEvents[] = response.data.events;
  const totalCount = response.meta.total_count;
  return { data, totalCount };
}

export async function fetchPortSubscriptions(
  subscriptionId: string,
): Promise<SubscriptionResponseDataType> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/zone-port-subscriptions/${subscriptionId}`,
    {
      headers: getAuthHeaders(),
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to get subscription data');
  }
  const response = await res.json();
  return response;
}

export async function createPortSubscription(
  body: ISubscription,
): Promise<SubscriptionResponseDataType> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/zone-port-subscriptions`,
    {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to create subscription');
  }
  const response = await res.json();
  return response;
}

export async function updatePortSubscription(
  body: ISubscription,
  subscriptionId: string,
): Promise<SubscriptionResponseDataType> {
  const userProfile = JSON.parse(localStorage.getItem('user') || '{}');
  const user_id = userProfile?.user_id;
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}${MARITIME_ANALYTICS_API_PATH}/users/${user_id}/zone-port-subscriptions/${subscriptionId}`,
    {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to update subscription');
  }
  const response = await res.json();
  return response;
}
