import { PiDownloadSimple } from 'react-icons/pi';
import { WpiData } from '@/features/Ports/types/wpiMappingTypes';
import {
  extractCategories,
  getWpiSections,
  mapPortsResponse,
} from '@/features/Ports/utils/wpiDataMapping';
import EntityActionButton from '@/shared/components/EntityActionButton';
import type { Port } from '@/shared/types/entities';
import { DataSectionProps } from '@/shared/ui/DataCard';
import { EntityDetailsPanel } from '@/shared/ui/EntityDetailsPanel';

interface PortDetailsTabProps {
  port: Port;
  wpiData: WpiData | undefined;
  onExportCSV: (content: string, filename: string) => void;
}

export default function PortDetailsTab({
  port,
  wpiData,
  onExportCSV,
}: PortDetailsTabProps) {
  const processedWpiInfo = wpiData && mapPortsResponse(wpiData);
  const wpiRows = extractCategories(processedWpiInfo, 'object');
  const wpiSections: DataSectionProps[] = getWpiSections(wpiRows);

  const hasWpiData = wpiData && wpiData.ports.length > 0;

  const portRows = [
    { label: 'Name', value: port?.name ?? '-' },
    { label: 'Type', value: port?.type ?? '-' },
    { label: 'Sub Type', value: port?.sub_type ?? '-' },
    { label: 'Country', value: port?.country_common_name ?? '-' },
    {
      label: 'UNLOCODE',
      value: port?.unlocode ?? port?.['unlocode '] ?? '-',
    },
    {
      label: 'WPI Number',
      value:
        port?.wpi_number === 'null' || port?.wpi_number == null
          ? '-'
          : port?.wpi_number,
    },
    {
      label: 'Sub Division',
      value: port?.sub_division_name
        ? `${port.sub_division_name} (${port.sub_division_code})`
        : '-',
    },
  ];

  const handleExport = () => {
    const rows = [...wpiSections.flatMap((s) => s.rows)];
    const headers = rows.map((r) => r.label).join(',');
    const values = rows.map((r) => JSON.stringify(r.value ?? '')).join(',');
    onExportCSV(`${headers}\n${values}`, 'Port-Details');
  };

  return (
    <>
      {hasWpiData && (
        <div className="mt-9 flex justify-end">
          <EntityActionButton
            textLabel="Export"
            handleClick={handleExport}
            icon={<PiDownloadSimple className="text-gray-400" />}
          />
        </div>
      )}

      {!hasWpiData && (
        <EntityDetailsPanel
          title={port.name}
          type="port"
          unlocode={port.unlocode || port['unlocode ']}
          sections={[{ rows: portRows }]}
          flag={port.country_code}
        />
      )}

      {hasWpiData && (
        <div className="mb-6 mt-6 columns-1 gap-4 bg-gray-100 dark:bg-gray-900 sm:columns-2 lg:columns-3">
          {wpiSections.map((section) => (
            <div key={section.title} className="mb-4 break-inside-avoid">
              <EntityDetailsPanel
                title={section.title}
                sections={[section]}
                className="w-full"
                type="wpiPort"
                flag={port.country_code}
              />
            </div>
          ))}
        </div>
      )}
    </>
  );
}
