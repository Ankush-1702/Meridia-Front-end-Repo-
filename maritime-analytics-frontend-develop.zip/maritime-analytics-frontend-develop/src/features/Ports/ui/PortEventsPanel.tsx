import { ColDef } from 'ag-grid-community';
import { FlatPortEventsResponse } from '@/features/Ports/types/portTypes';
import {
  InboundTimeRangeOptions,
  PortTabsOptions,
} from '@/shared/types/entities';
import NewEventsPanel from '@/shared/ui/NewEventsPanel';

interface PortEventsPanelProps {
  portName?: string;
  portId: string;
  portEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  buildColumns: (timezone: string) => ColDef[];
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatPortEventsResponse) => void;
  portTabOptions?: string[];
  inboundTimeRangeTabs?: string[];
  activePortEventTab?: PortTabsOptions;
  activeInboundTimeFrame?: string;
  handleActivePortEventTabChange?: (tab: PortTabsOptions) => void;
  handleInboundTimeFrameChange?: (timeFrame: InboundTimeRangeOptions) => void;
}

export function PortEventsPanel({
  portEventsTabs,
  storageKey,
  onSelectAll,
  selected,
  onToggle,
  rows,
  refresh,
  setRefresh,
  buildColumns,
  lastUpdated,
  isLoading,
  onRowClick,
  portId,
  portTabOptions,
  inboundTimeRangeTabs,
  activeInboundTimeFrame,
  activePortEventTab,
  handleActivePortEventTabChange,
  handleInboundTimeFrameChange,
}: PortEventsPanelProps) {
  return (
    <NewEventsPanel
      eventsTabs={portEventsTabs}
      selected={selected}
      onToggle={onToggle}
      onSelectAll={onSelectAll}
      rows={rows}
      refresh={refresh}
      setRefresh={setRefresh}
      buildColumns={buildColumns}
      storageKey={storageKey}
      lastUpdated={lastUpdated}
      isLoading={isLoading}
      onRowClick={onRowClick}
      entityType="port"
      entityId={portId}
      isPort={true}
      activeInboundTimeFrame={activeInboundTimeFrame}
      activePortEventTab={activePortEventTab}
      portTabOptions={portTabOptions}
      inboundTimeRangeTabs={inboundTimeRangeTabs}
      handleActivePortEventTabChange={handleActivePortEventTabChange}
      handleInboundTimeFrameChange={handleInboundTimeFrameChange}
    />
  );
}
