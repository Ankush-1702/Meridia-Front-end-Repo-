import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import * as usePortCongestionModule from '@/features/Ports/hooks/usePortCongestion';
import CongestionAndUtilisation from '@/features/Ports/ui/CongestionAndUtilisation';
import { Port } from '@/shared/types/entities';
import { ICongestionResponse } from '@/shared/types/ZoneTrafficAndPortCongestionTypes';

vi.mock('react-router', () => ({
  useNavigate: () => vi.fn(),
}));

vi.mock('@/features/Ports/hooks/usePortCongestion');

// Fix: BarSeriesChart receives ref={barChartRef} — must use forwardRef
vi.mock('@/shared/components/BarSeriesChart', () => ({
  default: React.forwardRef(
    (
      { response }: { response: ICongestionResponse },
      _ref: React.LegacyRef<HTMLDivElement>,
    ) => (
      <div ref={_ref}>BarSeriesChart - {response.data.length} data points</div>
    ),
  ),
}));

vi.mock('@/shared/components/ChartsDownloadDropDown', () => ({
  default: () => <div>Download Dropdown</div>,
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    exportToCSV: vi.fn(),
  }),
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>Empty State</div>,
}));

vi.mock('@/shared/components/CongestionTimeRangeDropdown', () => ({
  default: ({
    onChange,
  }: {
    onChange: (range: { start: string; end: string }) => void;
  }) => (
    <button
      onClick={() => onChange({ start: '2026-01-01', end: '2026-03-01' })}
    >
      Time Range Dropdown
    </button>
  ),
}));

vi.mock('@/shared/components/CountryDrowdown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (country: string, checked: boolean) => void;
  }) => <button onClick={() => onToggle('US', true)}>Country Dropdown</button>,
}));

// Fix: DonutChart receives ref={donutChartRef} — must use forwardRef
vi.mock('@/shared/components/DonutChart', () => ({
  default: React.forwardRef(
    (
      { response }: { response: ICongestionResponse },
      _ref: React.LegacyRef<HTMLDivElement>,
    ) => (
      <div ref={_ref}>DonutChart - {response.data[0]?.items.length} items</div>
    ),
  ),
}));

// Fix: LineSeriesChart receives ref={lineChartRef} — must use forwardRef
vi.mock('@/shared/components/LineSeriesChart', () => ({
  default: React.forwardRef(
    (
      { response }: { response: ICongestionResponse },
      _ref: React.LegacyRef<HTMLDivElement>,
    ) => (
      <div ref={_ref}>LineSeriesChart - {response.data.length} data points</div>
    ),
  ),
}));

vi.mock('@/shared/components/LoadingTemplate', () => ({
  default: () => <div>Loading...</div>,
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: ({ stats }: { stats: { label: string; value: number }[] }) => (
    <div>
      {stats.map((stat) => (
        <div key={stat.label}>
          {stat.label}: {stat.value}
        </div>
      ))}
    </div>
  ),
}));

vi.mock('@/shared/components/TimeDomainDropDown', () => ({
  default: ({
    onChange,
    value,
  }: {
    onChange: (opt: { value: string }) => void;
    value: string;
  }) => (
    <button onClick={() => onChange({ value: 'Weekly' })}>
      Time Domain: {value}
    </button>
  ),
}));

vi.mock('@/shared/components/VesselClassDropDown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (key: string, checked: boolean) => void;
  }) => (
    <button onClick={() => onToggle('Bulk carrier::Handysize', true)}>
      Vessel Class Dropdown
    </button>
  ),
}));

vi.mock('@/shared/components/VesselTypesDropDown', () => ({
  default: ({
    onToggle,
  }: {
    onToggle: (type: string, checked: boolean) => void;
  }) => (
    <button onClick={() => onToggle('Bulk carrier', true)}>
      Vessel Types Dropdown
    </button>
  ),
}));

vi.mock('@/features/library/utils/countryMapping', () => ({
  countries: { All: 'All Countries', US: 'United States' },
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: ({
    textLabel,
    handleClick,
  }: {
    textLabel: string;
    handleClick: () => void;
  }) => <button onClick={handleClick}>{textLabel}</button>,
}));

vi.mock('@/shared/components/TabGroup', () => ({
  default: ({
    tabs,
    active,
    onChange,
  }: {
    tabs: string[];
    active: string;
    onChange: (tab: string) => void;
  }) => (
    <div>
      {tabs.map((tab) => (
        <button
          key={tab}
          onClick={() => onChange(tab)}
          style={{ fontWeight: active === tab ? 'bold' : 'normal' }}
        >
          {tab}
        </button>
      ))}
    </div>
  ),
}));

vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light', toggleTheme: vi.fn() }),
}));

// Fix: PoleStarEntityGrid receives ref={gridRef} — must use forwardRef
vi.mock('@/shared/lib/PoleStarEntityGrid', () => ({
  default: React.forwardRef(
    (_props: Record<string, unknown>, ref: React.Ref<unknown>) => {
      React.useImperativeHandle(ref, () => ({
        refresh: vi.fn(),
        expandAll: vi.fn(),
        collapseAll: vi.fn(),
        api: undefined,
        getDisplayedColumns: vi.fn().mockReturnValue([]),
        getDisplayedColDefs: vi.fn().mockReturnValue([]),
        getDisplayedRows: vi.fn().mockReturnValue([]),
        getCurrentPageRows: vi.fn().mockReturnValue([]),
      }));
      return <div>Entity Grid</div>;
    },
  ),
}));

vi.mock('@/features/Ports/utils/BerthSummaryColDefs', () => ({
  createBerthSummaryColumnDefs: vi.fn(() => []),
}));

// Fix: DwellTimeChart receives ref={dwellSeriesRef} — must use forwardRef
vi.mock('@/features/Ports/ui/Berth/components/DwellTimeLineSeries', () => ({
  default: React.forwardRef(
    (_props: Record<string, unknown>, _ref: React.Ref<HTMLDivElement>) => (
      <div ref={_ref}>DwellTimeChart</div>
    ),
  ),
}));

// BerthTypeDropdown (MultiSelectDropdown) — no ref, plain mock is fine
vi.mock('@/shared/components/MultiSelectDropdown', () => ({
  default: () => <div>Berth Type Dropdown</div>,
}));

describe('CongestionAndUtilisation', () => {
  const mockCongestionResponse: ICongestionResponse = {
    meta: {
      request_timestamp: '2026-03-08T00:00:00Z',
      request_id: 'req-123',
    },
    query: {
      date_start: '2026-01-01',
      date_end: '2026-03-01',
      group_by: 'NONE',
      period_aggregation: 'DAILY',
    },
    location_information: {
      id: 'port-123',
      name: 'Test Port',
      unlocode: 'TSTPT',
      country_common_name: 'Test Country',
    },
    totals: {
      arrivals: 300,
      departures: 280,
      vessels_per_day: 20,
      max_vessels_per_day: 45,
    },
    data: [
      {
        period_key: '2026-03-08',
        items: [{ group_by_key: 'NONE', arrivals: 10, departures: 8 }],
      },
    ],
  };

  const mockFetchArrivalsAndDeparturesByTotals = vi
    .fn()
    .mockResolvedValue(undefined);
  const mockFetchArrivalsByTotalsAndVesselType = vi
    .fn()
    .mockResolvedValue(undefined);
  const mockFetchArrivalsByVesselType = vi.fn().mockResolvedValue(undefined);
  const mockSetActiveArrivalsAndDeparturesTab = vi.fn();
  const mockSetArrivalsAndDeparturesTimeDomain = vi.fn();
  const mockSetArrivalsTimeDomain = vi.fn();
  const mockSetDateRange = vi.fn();
  const mockHandleVesselTypeToggle = vi.fn();
  const mockHandleVesselClassToggle = vi.fn();
  const mockHandleCountryToggle = vi.fn();
  const mockFetchBerthFilters = vi.fn().mockResolvedValue(undefined);
  const mockFetchDwellTimeSeries = vi.fn().mockResolvedValue(undefined);
  const mockSetDwellSeriesTimeDomain = vi.fn();

  const mockPort: Port = {
    id: 'port-123',
    name: 'Test Port',
    centroid: {
      longitude: 0,
      latitude: 0,
    },
    country_official_name: '',
    country_code: '',
    description: '',
    sub_type: '',
    type: '',
    unlocode: '',
    'unlocode ': '',
    country_common_name: '',
    sub_division_code: '',
    sub_division_name: '',
    wpi_number: undefined,
  };

  const defaultHookReturn = {
    activeArrivalsAndDeparturesTab: 'Totals',
    setActiveArrivalsAndDeparturesTab: mockSetActiveArrivalsAndDeparturesTab,
    arrivalsAndDeparturesTabs: ['Totals', 'Hourly Averages'],
    vesselTypesOpts: [
      {
        value: 'Bulk carrier',
        defaultChecked: true,
        displayValue: 'Bulk Carrier',
      },
    ],
    selectedVesselType: { 'Bulk carrier': true },
    selectedVesselClass: { 'Bulk carrier::Handysize': true },
    selectedCountries: { All: true },
    hasSelectedVesselTypes: true,
    handleVesselTypeToggle: mockHandleVesselTypeToggle,
    handleVesselClassToggle: mockHandleVesselClassToggle,
    handleCountryToggle: mockHandleCountryToggle,
    setArrivalsAndDeparturesTimeDomain: mockSetArrivalsAndDeparturesTimeDomain,
    arrivalsAndDeparturesTimeDomain: 'Daily',
    arrivalsTimeDomain: 'Daily',
    setArrivalsTimeDomain: mockSetArrivalsTimeDomain,
    setDateRange: mockSetDateRange,
    arrivalAndDeparturesByTotals: mockCongestionResponse,
    arrivalsByVesselTypesAndTotals: mockCongestionResponse,
    arrivalsByVesselTypes: mockCongestionResponse,
    fetchArrivalsAndDeparturesByTotals: mockFetchArrivalsAndDeparturesByTotals,
    fetchArrivalsByTotalsAndVesselType: mockFetchArrivalsByTotalsAndVesselType,
    fetchArrivalsByVesselType: mockFetchArrivalsByVesselType,
    timeDomainDays: 60,
    arrivalsAndDeparturesTimeDomainDisplay: 'Day',
    arrivalsTimeDomainDisplay: 'Day',
    isArrivalAndDeparturesByTotalsLoading: false,
    isArrivalsByVesselTypesLoading: false,
    isArrivalsByVesselTypesAndTotalsLoading: false,
    gridRef: { current: null },
    getServerSideData: vi.fn(),
    fetchBerthFilters: mockFetchBerthFilters,
    fetchDwellTimeSeries: mockFetchDwellTimeSeries,
    dwellSeriesTimeDomain: 'Daily',
    setDwellSeriesTimeDomain: mockSetDwellSeriesTimeDomain,
    berthTypes: ['General', 'Container'],
    selectedBerthTypes: { General: true, Container: true },
    handleBerthTypeToggle: vi.fn(),
    handleBerthTypeSelectAll: vi.fn(),
    dwellSeries: mockCongestionResponse,
    isDwellSeriesLoading: false,
    topVisitingGridRef: { current: null },
    getTopVisitingVesselsServerSideData: vi.fn(),
    topVisitingVesselData: [
      {
        vessel_name: 'TEST VESSEL',
        imo_number: '1234567',
        flag_code: 'US',
        flag_name: 'United States',
        ship_type_level_3: 'Bulk carrier',
        visit_count: 5,
      },
    ],
    isTopVisitingVesselsLoading: false,
    dateRangeLabel: 'Previous 30 Days',
    setDateRangeLabel: vi.fn(),
  };

  const mockSetActiveTab = vi.fn();
  const mockSetSelectedBerthId = vi.fn();
  const mockSetSelectedBerthName = vi.fn();

  const defaultProps = {
    port: mockPort,
    setActiveTab: mockSetActiveTab,
    setSelectedBerthId: mockSetSelectedBerthId,
    setSelectedBerthName: mockSetSelectedBerthName,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue(
      defaultHookReturn,
    );
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('rendering', () => {
    it('should render all dropdowns', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Time Range Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Country Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Vessel Types Dropdown')).toBeInTheDocument();
      expect(screen.getByText('Vessel Class Dropdown')).toBeInTheDocument();
    });

    it('should render refresh button', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Refresh')).toBeInTheDocument();
    });

    it('should render stats summary when data is available', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Arrivals: 300')).toBeInTheDocument();
      expect(screen.getByText('Departures: 280')).toBeInTheDocument();
      expect(
        screen.getByText('Unique Arrivals per Day (avg): 20'),
      ).toBeInTheDocument();
      expect(
        screen.getByText('Unique Arrivals per Day (max): 45'),
      ).toBeInTheDocument();
    });

    it('should render charts when data is available', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(
        screen.getByText('LineSeriesChart - 1 data points'),
      ).toBeInTheDocument();
      expect(screen.getByText('DonutChart - 1 items')).toBeInTheDocument();
      expect(
        screen.getByText('BarSeriesChart - 1 data points'),
      ).toBeInTheDocument();
    });

    it('should render section headings', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Arrivals and Departures')).toBeInTheDocument();
      expect(screen.getAllByText('Arrivals')).toHaveLength(2);
    });
  });

  describe('loading states', () => {
    it('should show loading template when arrivals and departures by totals is loading', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        isArrivalAndDeparturesByTotalsLoading: true,
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should show loading template when arrivals by vessel types is loading', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        isArrivalsByVesselTypesLoading: true,
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should show loading template when arrivals by vessel types and totals is loading', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        isArrivalsByVesselTypesAndTotalsLoading: true,
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Loading...')).toHaveLength(2);
    });
  });

  describe('empty states', () => {
    it('should show empty state when arrivals and departures data is empty', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        arrivalAndDeparturesByTotals: { ...mockCongestionResponse, data: [] },
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when arrivals and departures totals are zero', () => {
      const zeroTotals = {
        arrivals: 0,
        departures: 0,
        vessels_per_day: 0,
        max_vessels_per_day: 0,
      };

      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        arrivalAndDeparturesByTotals: {
          ...mockCongestionResponse,
          data: [],
          totals: zeroTotals,
        },
        arrivalsByVesselTypesAndTotals: {
          ...mockCongestionResponse,
          data: [{ period_key: '2026-03-08', items: [] }],
          totals: zeroTotals,
        },
        arrivalsByVesselTypes: {
          ...mockCongestionResponse,
          data: [],
          totals: zeroTotals,
        },
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when arrivals by vessel types data is empty', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        arrivalsByVesselTypes: { ...mockCongestionResponse, data: [] },
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when arrivals by vessel types and totals items are empty', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        arrivalsByVesselTypesAndTotals: {
          ...mockCongestionResponse,
          data: [{ period_key: '2026-03-08', items: [] }],
        },
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Empty State').length).toBeGreaterThanOrEqual(
        1,
      );
    });

    it('should show empty state when data is undefined', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        arrivalAndDeparturesByTotals: undefined,
        arrivalsByVesselTypesAndTotals: undefined,
        arrivalsByVesselTypes: undefined,
        dwellSeries: undefined,
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getAllByText('Empty State').length).toBe(5);
    });
  });

  describe('interactions', () => {
    it('should call setDateRange when time range dropdown changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      fireEvent.click(screen.getByText('Time Range Dropdown'));

      expect(mockSetDateRange).toHaveBeenCalledWith({
        start: '2026-01-01',
        end: '2026-03-01',
      });
    });

    it('should call handleCountryToggle when country dropdown changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      fireEvent.click(screen.getByText('Country Dropdown'));

      expect(mockHandleCountryToggle).toHaveBeenCalledWith('US', true);
    });

    it('should call handleVesselTypeToggle when vessel types dropdown changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      fireEvent.click(screen.getByText('Vessel Types Dropdown'));

      expect(mockHandleVesselTypeToggle).toHaveBeenCalledWith(
        'Bulk carrier',
        true,
      );
    });

    it('should call handleVesselClassToggle when vessel class dropdown changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      fireEvent.click(screen.getByText('Vessel Class Dropdown'));

      expect(mockHandleVesselClassToggle).toHaveBeenCalledWith(
        'Bulk carrier::Handysize',
        true,
      );
    });

    it('should call setArrivalsAndDeparturesTimeDomain when time domain dropdown changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      fireEvent.click(timeDomainButtons[0]);

      expect(mockSetArrivalsAndDeparturesTimeDomain).toHaveBeenCalledWith(
        'Weekly',
      );
    });

    it('should call all fetch functions when refresh button is clicked', async () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      fireEvent.click(screen.getByText('Refresh'));

      await waitFor(() => {
        expect(mockFetchArrivalsAndDeparturesByTotals).toHaveBeenCalled();
        expect(mockFetchArrivalsByTotalsAndVesselType).toHaveBeenCalled();
        expect(mockFetchArrivalsByVesselType).toHaveBeenCalled();
        expect(mockFetchBerthFilters).toHaveBeenCalled();
      });
    });
  });

  describe('conditional rendering', () => {
    it('should disable vessel class dropdown when no vessel types are selected', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        hasSelectedVesselTypes: false,
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      const vesselClassButton = screen.getByText('Vessel Class Dropdown');
      expect(vesselClassButton.closest('div')).toHaveStyle({
        pointerEvents: 'none',
      });
    });

    it('should show time domain dropdown only for Totals tab', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      expect(timeDomainButtons).toHaveLength(3);
    });

    it('should hide time domain dropdown for Hourly Averages tab', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        activeArrivalsAndDeparturesTab: 'Hourly Averages',
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      expect(timeDomainButtons).toHaveLength(2);
    });

    it('should show correct subtitle for Hourly Averages tab', () => {
      (usePortCongestionModule.usePortCongestion as Mock).mockReturnValue({
        ...defaultHookReturn,
        activeArrivalsAndDeparturesTab: 'Hourly Averages',
      });

      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(
        screen.getByText('Average per hour of the day'),
      ).toBeInTheDocument();
    });

    it('should show correct subtitle for Totals tab', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('Totals per Day')).toBeInTheDocument();
    });
  });

  describe('arrivals section', () => {
    it('should render arrivals donut chart section heading', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('By Vessel Type, Totals')).toBeInTheDocument();
    });

    it('should render arrivals bar chart section heading with time domain', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      expect(screen.getByText('By Vessel Type, Per Day')).toBeInTheDocument();
    });

    it('should call setArrivalsTimeDomain when arrivals time domain changes', () => {
      render(<CongestionAndUtilisation {...defaultProps} />);

      const timeDomainButtons = screen.getAllByText(/Time Domain:/);
      fireEvent.click(timeDomainButtons[1]);

      expect(mockSetArrivalsTimeDomain).toHaveBeenCalledWith('Weekly');
    });
  });
});
