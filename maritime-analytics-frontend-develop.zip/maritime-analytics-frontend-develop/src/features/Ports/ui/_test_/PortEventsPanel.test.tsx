import { render } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { PortEventsPanel } from '@/features/Ports/ui/PortEventsPanel';

/* ------------------------------------------------------------------ */
/* typed NewEventsPanel mock                                           */
/* ------------------------------------------------------------------ */

interface NewEventsPanelProps {
  eventsTabs: { label: string; value: string }[];
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  buildColumns: (timezone: string) => unknown[];
  storageKey?: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: unknown) => void;
}

let capturedProps: NewEventsPanelProps | undefined;

vi.mock('@/shared/ui/NewEventsPanel', () => ({
  default: (props: NewEventsPanelProps) => {
    capturedProps = props;
    return <div data-testid="new-events-panel" />;
  },
}));

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('PortEventsPanel', () => {
  const buildColumns = vi.fn(() => [{ headerName: 'Col' }]);
  const onToggle = vi.fn();
  const onSelectAll = vi.fn();
  const setRefresh = vi.fn();
  const onRowClick = vi.fn();
  const lastUpdated = new Date('2024-01-01T00:00:00Z');

  const defaultProps = {
    portId: 'port-1',
    portEventsTabs: [
      { label: 'All', value: 'ALL' },
      { label: 'Inbound', value: 'INBOUND' },
    ],
    selected: { ALL: true, INBOUND: false },
    onToggle,
    onSelectAll,
    rows: [{ id: 'e1' }],
    refresh: false,
    setRefresh,
    buildColumns,
    storageKey: 'port-events-storage-key',
    lastUpdated,
    isLoading: false,
    onRowClick,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    capturedProps = undefined;
  });

  it('renders NewEventsPanel', () => {
    const { getByTestId } = render(<PortEventsPanel {...defaultProps} />);
    expect(getByTestId('new-events-panel')).toBeTruthy();
  });

  it('forwards eventsTabs from portEventsTabs', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.eventsTabs).toEqual(defaultProps.portEventsTabs);
  });

  it('forwards selected, onToggle, and onSelectAll', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.selected).toEqual(defaultProps.selected);
    expect(capturedProps?.onToggle).toBe(onToggle);
    expect(capturedProps?.onSelectAll).toBe(onSelectAll);
  });

  it('forwards rows, refresh, and setRefresh', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.rows).toEqual(defaultProps.rows);
    expect(capturedProps?.refresh).toBe(false);
    expect(capturedProps?.setRefresh).toBe(setRefresh);
  });

  it('forwards buildColumns and storageKey', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.buildColumns).toBe(buildColumns);
    expect(capturedProps?.storageKey).toBe('port-events-storage-key');
  });

  it('forwards lastUpdated and isLoading', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.lastUpdated).toBe(lastUpdated);
    expect(capturedProps?.isLoading).toBe(false);
  });

  it('forwards onRowClick', () => {
    render(<PortEventsPanel {...defaultProps} />);
    expect(capturedProps?.onRowClick).toBe(onRowClick);
  });
});
