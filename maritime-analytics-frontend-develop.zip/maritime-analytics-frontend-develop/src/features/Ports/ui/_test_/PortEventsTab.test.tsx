import { act, render, screen, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { InboundVessel } from '@/features/Ports/types/inboundVessels';
import type { FlatPortEventsResponse } from '@/features/Ports/types/portTypes';
import type { PortEvents, BerthEvents } from '@/features/Ports/types/portTypes';
import PortEventsTab from '@/features/Ports/ui/PortEventsTab';
import { PortTabsOptions } from '@/shared/types/entities';

/* ------------------------------------------------------------------ */
/* mocks                                                              */
/* ------------------------------------------------------------------ */

const navigateMock = vi.fn();

vi.mock('react-router', () => ({
  useNavigate: () => navigateMock,
}));

const getInboundVesselsMock = vi.fn();
const fetchBerthEventsMock = vi.fn();
const fetchPortEventsMock = vi.fn();

vi.mock('@/features/Ports/services/inboundVesselsApi', () => ({
  getInboundVessels: (...args: unknown[]) => getInboundVesselsMock(...args),
}));

vi.mock('@/features/Ports/services/portServices', () => ({
  fetchBerthEvents: (...args: unknown[]) => fetchBerthEventsMock(...args),
  fetchPortEvents: (...args: unknown[]) => fetchPortEventsMock(...args),
}));

vi.mock('@/features/Ports/utils/CombinedColDefs', () => ({
  CreateUnifiedPortEventsColDefs: vi.fn(() => []),
}));

vi.mock('@/features/Ports/utils/newInboundVesselsColDefs', () => ({
  CreateNewInboundVesselsColDefs: vi.fn(() => []),
}));

vi.mock('@/shared/utils/logger', () => ({
  logger: { error: vi.fn(), info: vi.fn(), warn: vi.fn() },
}));

interface CapturedPortEventsPanelProps {
  portName?: string;
  portId: string;
  portEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: FlatPortEventsResponse[];
  buildColumns: unknown;
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatPortEventsResponse) => void;
  portTabOptions?: string[];
  inboundTimeRangeTabs?: string[];
  activePortEventTab?: PortTabsOptions;
  activeInboundTimeFrame?: string;
  handleActivePortEventTabChange?: (tab: string) => void;
  handleInboundTimeFrameChange?: (timeFrame: string) => void;
}

let capturedProps: CapturedPortEventsPanelProps | undefined;

vi.mock('@/features/Ports/ui/PortEventsPanel', () => ({
  PortEventsPanel: (props: CapturedPortEventsPanelProps) => {
    capturedProps = props;
    return <div>PortEventsPanel</div>;
  },
}));

/* ------------------------------------------------------------------ */
/* fixtures                                                           */
/* ------------------------------------------------------------------ */

const portEventsTabs = [
  { label: 'Area Arrivals', value: 'PORT_AREA_ARRIVAL' },
  { label: 'Arrivals', value: 'PORT_ARRIVAL' },
  { label: 'Berth Arrivals', value: 'BERTH_ARRIVAL' },
  { label: 'Berth Departures', value: 'BERTH_DEPARTURE' },
  { label: 'Departures', value: 'PORT_DEPARTURE' },
  { label: 'Area Departures', value: 'PORT_AREA_DEPARTURE' },
];

function buildPortEvent(overrides: Partial<PortEvents> = {}): PortEvents {
  return {
    vessel_information: {
      asset_id: 'asset-1',
      callsign: 'CALL1',
      flag: 'Norway',
      flag_code: 'NO',
      imo: '1234567',
      mmsi: '987654321',
      name: 'Test Vessel',
      vessel_type: 'Cargo',
    },
    event_details: {
      course: 90,
      draught: 5.5,
      event_id: 'event-1',
      event_timestamp: '2023-01-01T00:00:00Z',
      event_type: 'PORT_ARRIVAL',
      heading: 180,
      latitude: 10.1,
      longitude: 20.2,
      navigational_status: { status: 'Under way', code: 0 },
      reported_destination: 'Rotterdam',
      reported_eta: '2023-01-02T00:00:00Z',
      speed: 12.5,
    },
    ...overrides,
  } as PortEvents;
}

function buildBerthEvent(overrides: Partial<BerthEvents> = {}): BerthEvents {
  return {
    ...buildPortEvent(),
    berth_information: { id: 'berth-1', name: 'Berth A', port_id: 'port-1' },
    event_details: {
      ...buildPortEvent().event_details,
      event_type: 'BERTH_ARRIVAL',
      ...overrides.event_details,
    },
    ...overrides,
  } as BerthEvents;
}

function buildInboundVessel(
  overrides: Partial<InboundVessel> = {},
): InboundVessel {
  return {
    vessel_information: {
      asset_id: 'asset-2',
      callsign: 'CALL2',
      flag: 'Panama',
      flag_code: 'PA',
      imo: '7654321',
      mmsi: '123456789',
      name: 'Inbound Vessel',
      vessel_type: 'Tanker',
    },
    reported_destination: {
      id: 'dest-1',
      name: 'Singapore',
      raw: 'SGSIN',
      reported_at: '2023-01-01T00:00:00Z',
      unlocode: 'SGSIN',
    },
    reported_eta: '2023-01-04T00:00:00Z',
    latest_position: {
      latitude: 3.1,
      longitude: 101.2,
      course: 90,
      speed: 10,
      heading: 90,
      draught: 8,
      navigational_status: { code: 0, status: 0 },
      timestamp: '2023-01-01T06:00:00Z',
    },
    ...overrides,
  } as InboundVessel;
}

const defaultProps = {
  portId: 'port-1',
  portName: 'Test Port',
  refresh: false,
  setRefresh: vi.fn(),
  portEventsTabs,
  activePortEventTab: 'Historic' as PortTabsOptions,
  setActivePortEventTab: vi.fn(),
};

/* ------------------------------------------------------------------ */
/* tests                                                              */
/* ------------------------------------------------------------------ */

describe('PortEventsTab', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    capturedProps = undefined;

    getInboundVesselsMock.mockResolvedValue({
      data: [
        buildInboundVessel({
          reported_eta: '2023-01-01T03:00:00Z',
          latest_position: {
            ...buildInboundVessel().latest_position,
            timestamp: '2023-01-01T03:00:00Z',
          },
        }),
      ],
      meta: { total_count: 1 },
    });

    fetchBerthEventsMock.mockResolvedValue({
      data: [
        buildBerthEvent({
          event_details: {
            ...buildPortEvent().event_details,
            event_id: 'berth-event-1',
            event_timestamp: '2023-01-01T02:00:00Z',
            event_type: 'BERTH_ARRIVAL',
          },
        }),
      ],
      totalCount: 1,
    });

    fetchPortEventsMock.mockResolvedValue({
      data: [
        buildPortEvent({
          event_details: {
            ...buildPortEvent().event_details,
            event_id: 'port-event-1',
            event_timestamp: '2023-01-01T01:00:00Z',
            event_type: 'PORT_ARRIVAL',
          },
        }),
      ],
      totalCount: 1,
    });
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('fetches berth events and port events in parallel on mount for Historic tab', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => {
      expect(fetchBerthEventsMock).toHaveBeenCalledTimes(1);
      expect(fetchPortEventsMock).toHaveBeenCalledTimes(1);
    });

    expect(getInboundVesselsMock).not.toHaveBeenCalled();

    const [portId, start, end, offset, limit] =
      fetchPortEventsMock.mock.calls[0];
    expect(portId).toBe('port-1');
    expect(offset).toBe(0);
    expect(limit).toBe(500);
    expect(new Date(end).getTime() - new Date(start).getTime()).toBeCloseTo(
      24 * 60 * 60 * 1000 * 90,
      -6,
    );
  });

  it('fetches inbound vessels when activePortEventTab is "Inbound Vessels"', async () => {
    render(
      <PortEventsTab {...defaultProps} activePortEventTab="Inbound Vessels" />,
    );

    await waitFor(() => {
      expect(getInboundVesselsMock).toHaveBeenCalledTimes(1);
    });

    expect(fetchBerthEventsMock).not.toHaveBeenCalled();
    expect(fetchPortEventsMock).not.toHaveBeenCalled();

    expect(getInboundVesselsMock).toHaveBeenCalledWith(
      expect.objectContaining({
        id: 'port-1',
        id_type: 'id',
        limit: 500,
        offset: 0,
        exclude_arrived: true,
      }),
    );
  });

  it('merges and sorts combined rows by timestamp descending for Historic tab', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    expect(capturedProps?.rows.map((r) => r.eventId)).toEqual([
      'berth-event-1',
      'port-event-1',
    ]);
  });

  it('sorts inbound vessels by reportedEta descending', async () => {
    getInboundVesselsMock.mockResolvedValue({
      data: [
        buildInboundVessel({ reported_eta: '2023-01-05T00:00:00Z' }),
        buildInboundVessel({ reported_eta: '2023-01-03T00:00:00Z' }),
      ],
      meta: { total_count: 2 },
    });

    render(
      <PortEventsTab {...defaultProps} activePortEventTab="Inbound Vessels" />,
    );

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    expect(capturedProps).toBeDefined();

    const etas = capturedProps!.rows
      .map((r) => r.reportedEta)
      .filter((eta): eta is string => eta !== undefined);

    expect(etas).toHaveLength(2);
    expect(new Date(etas[0]).getTime()).toBeGreaterThan(
      new Date(etas[1]).getTime(),
    );
  });

  it('handles partial failures via Promise.allSettled gracefully', async () => {
    fetchBerthEventsMock.mockRejectedValue(new Error('berth events failed'));

    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(1));

    expect(capturedProps?.rows.some((r) => r.eventId === 'berth-event-1')).toBe(
      false,
    );
  });

  it('polls for new events every 5 minutes', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });

    render(<PortEventsTab {...defaultProps} />);

    await vi.waitFor(() =>
      expect(fetchPortEventsMock).toHaveBeenCalledTimes(1),
    );

    await act(async () => {
      vi.advanceTimersByTime(5 * 60 * 1000);
    });

    await vi.waitFor(() =>
      expect(fetchPortEventsMock).toHaveBeenCalledTimes(2),
    );
  });

  it('manually refreshes when refresh becomes true', async () => {
    const { rerender } = render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(fetchPortEventsMock).toHaveBeenCalledTimes(1));

    rerender(<PortEventsTab {...defaultProps} refresh={true} />);

    await waitFor(() => expect(fetchPortEventsMock).toHaveBeenCalledTimes(2));
    expect(defaultProps.setRefresh).toHaveBeenCalledWith(false);
  });

  it('filters cached rows client-side based on selected event types', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    await act(async () => {
      capturedProps?.onToggle('BERTH_ARRIVAL', false);
    });

    await waitFor(() => {
      const eventTypes = capturedProps?.rows.map((r) => r.eventType);
      expect(eventTypes).not.toContain('BERTH_ARRIVAL');
    });
  });

  it('updates selection state via onSelectAll', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    await act(async () => {
      capturedProps?.onSelectAll(false);
    });

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(0));
  });

  it('navigates to the vessel page using the flat imo field on row click', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps?.rows).toHaveLength(2));

    capturedProps?.onRowClick?.(capturedProps.rows[0]);

    expect(navigateMock).toHaveBeenCalledWith(
      `/analytics/vessel/${capturedProps?.rows[0].imo}`,
    );
  });

  it('renders PortEventsPanel with the expected wiring props for Historic tab', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps).toBeDefined());

    expect(screen.getByText('PortEventsPanel')).toBeInTheDocument();
    expect(capturedProps?.portId).toBe('port-1');
    expect(capturedProps?.portName).toBe('Test Port');
    expect(capturedProps?.portEventsTabs).toEqual(portEventsTabs);
    expect(capturedProps?.storageKey).toBe('port-events');
    expect(capturedProps?.activePortEventTab).toBe('Historic');
    expect(capturedProps?.portTabOptions).toEqual([
      'Historic',
      'Inbound Vessels',
    ]);
    expect(capturedProps?.inboundTimeRangeTabs).toEqual([
      '24h',
      '7d',
      '30d',
      'All',
    ]);
  });

  it('renders PortEventsPanel with Inbound Vessels tab selected', async () => {
    render(
      <PortEventsTab {...defaultProps} activePortEventTab="Inbound Vessels" />,
    );

    await waitFor(() => expect(capturedProps).toBeDefined());

    expect(capturedProps?.activePortEventTab).toBe('Inbound Vessels');
    expect(capturedProps?.portEventsTabs).toEqual([
      { label: 'Inbound Vessels', value: 'INBOUND' },
    ]);
    expect(capturedProps?.storageKey).toBe('inbound-vessels');
  });

  it('calls handleActivePortEventTabChange when tab changes', async () => {
    render(<PortEventsTab {...defaultProps} />);

    await waitFor(() => expect(capturedProps).toBeDefined());

    capturedProps?.handleActivePortEventTabChange?.('Inbound Vessels');

    expect(defaultProps.setActivePortEventTab).toHaveBeenCalledWith(
      'Inbound Vessels',
    );
  });

  it('changes inbound time frame via handleInboundTimeFrameChange', async () => {
    render(
      <PortEventsTab {...defaultProps} activePortEventTab="Inbound Vessels" />,
    );

    await waitFor(() => expect(capturedProps).toBeDefined());

    expect(capturedProps?.activeInboundTimeFrame).toBe('24h');

    await act(async () => {
      capturedProps?.handleInboundTimeFrameChange?.('7d');
    });

    await waitFor(() => {
      expect(getInboundVesselsMock).toHaveBeenCalledWith(
        expect.objectContaining({
          reported_eta_gte: expect.any(String),
          reported_eta_lte: expect.any(String),
        }),
      );
    });
  });

  it('does not include reported_eta filters when activeInboundTimeFrame is "All"', async () => {
    render(
      <PortEventsTab {...defaultProps} activePortEventTab="Inbound Vessels" />,
    );

    await waitFor(() => expect(capturedProps).toBeDefined());

    await act(async () => {
      capturedProps?.handleInboundTimeFrameChange?.('All');
    });

    await waitFor(() => {
      const lastCall =
        getInboundVesselsMock.mock.calls[
          getInboundVesselsMock.mock.calls.length - 1
        ][0];
      expect(lastCall.reported_eta_gte).toBeUndefined();
      expect(lastCall.reported_eta_lte).toBeUndefined();
    });
  });
});
