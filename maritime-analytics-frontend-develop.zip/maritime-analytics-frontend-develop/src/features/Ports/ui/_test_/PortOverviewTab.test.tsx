import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import PortOverviewTab from '../PortOverviewTab';
import type { Port } from '@/shared/types/entities';

/* ---------------- prop-capturing OverviewMap mock ---------------- */

const { capturedOverviewMapProps } = vi.hoisted(() => {
  const capturedOverviewMapProps = {
    current: undefined as Record<string, unknown> | undefined,
  };
  return { capturedOverviewMapProps };
});

vi.mock('@/shared/components/OverviewMap', () => ({
  default: (props: Record<string, unknown>) => {
    capturedOverviewMapProps.current = props;
    return <div data-testid="overview-map">Map</div>;
  },
}));

vi.mock('@/shared/utils/overviewMapUtils', () => ({
  decryptGeometry: (g: unknown) => g,
}));

vi.mock('@/shared/utils/logger', () => ({
  logger: {
    error: vi.fn(),
    warn: vi.fn(),
    info: vi.fn(),
    debug: vi.fn(),
  },
}));

/* ---------------- sub-component mocks ---------------- */

vi.mock('@/shared/components/VesselSummarySection', () => ({
  default: ({
    title,
    count,
    isEmpty,
    emptyMessage,
    onToggle,
    children,
  }: {
    title: string;
    count?: number;
    isEmpty?: boolean;
    emptyMessage?: string;
    onToggle?: () => void;
    children?: React.ReactNode;
  }) => (
    <div>
      <button type="button" onClick={onToggle}>
        {title}
      </button>
      <span>{count}</span>
      {isEmpty ? <span>{emptyMessage}</span> : null}
      {children}
    </div>
  ),
}));

vi.mock('@/shared/components/VesselListItem', () => ({
  default: () => <div>VesselListItem</div>,
}));

vi.mock('@/shared/components/OverviewCharts', () => ({
  default: () => <div>OverviewCharts</div>,
}));

vi.mock('@/shared/components/StatsSummary', () => ({
  default: () => <div>StatsSummary</div>,
}));

vi.mock('@/shared/components/CongestionEmptyState', () => ({
  default: () => <div>CongestionEmptyState</div>,
}));

vi.mock('@/shared/components/LoadingTemplate', () => ({
  default: () => <div>LoadingTemplate</div>,
}));

vi.mock('@/shared/components/VesselLoadingProgress', () => ({
  default: () => <div>VesselLoadingProgress</div>,
}));

vi.mock('@/features/Ports/components/CongestionTooltip', () => ({
  default: () => <div>CongestionTooltip</div>,
}));

/* ---------------- fixtures ---------------- */

const basePort: Port = {
  id: 'port-1',
  name: 'Test Port',
  type: 'Port',
  sub_type: 'Commercial',
  centroid: { latitude: 1.3, longitude: 103.8 },
  country_official_name: 'Singapore',
  country_code: 'SG',
  country_common_name: 'Singapore',
  description: '',
  unlocode: 'SGSIN',
  'unlocode ': '',
  sub_division_code: '',
  sub_division_name: '',
  wpi_number: null,
};

const defaultProps = {
  port: basePort,
  positions: [],
  overviewCenter: undefined,
  overviewProgress: null,
  inboundVessels: [],
  inboundVesselsTotalCount: 0,
  isInboundVesselsLoading: false,
  activeInboundVesselTimeFrame: '24h',
  setActiveInboundVesselTimeFrame: vi.fn(),
  inboundVesselTimeFrameTabs: ['24h', '48h', '72h'],
  isLoading: false,
  livePortData: undefined,
  last30DaysData: undefined,
  onNavigateToEvents: vi.fn(),
  onNavigateToCongestion: vi.fn(),
  portBoundary: undefined,
  getInBoundVessels: vi.fn(),
  refreshOverview: vi.fn(),
  fetchLivePortTraffic: vi.fn(),
  fetchLast30DaysData: vi.fn(),
};

/* ---------------- tests ---------------- */

describe('PortOverviewTab', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    capturedOverviewMapProps.current = undefined;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('rendering', () => {
    it('renders the OverviewMap', () => {
      render(<PortOverviewTab {...defaultProps} />);

      expect(screen.getByTestId('overview-map')).toBeInTheDocument();
    });

    it('renders VesselLoadingProgress when progress is incomplete', () => {
      render(
        <PortOverviewTab
          {...defaultProps}
          overviewProgress={{
            current: 1,
            total: 5,
            isComplete: false,
            vesselsLoaded: 1,
            totalVessels: 5,
            percentage: 20,
            estimatedTimeRemaining: 3,
          }}
        />,
      );

      expect(screen.getByText('VesselLoadingProgress')).toBeInTheDocument();
    });

    it('does not render VesselLoadingProgress when progress is null', () => {
      render(<PortOverviewTab {...defaultProps} />);

      expect(
        screen.queryByText('VesselLoadingProgress'),
      ).not.toBeInTheDocument();
    });

    it('does not render VesselLoadingProgress when progress is complete', () => {
      render(
        <PortOverviewTab
          {...defaultProps}
          overviewProgress={{
            current: 1,
            total: 5,
            isComplete: true,
            vesselsLoaded: 5,
            totalVessels: 5,
            percentage: 100,
            estimatedTimeRemaining: 0,
          }}
        />,
      );

      expect(
        screen.queryByText('VesselLoadingProgress'),
      ).not.toBeInTheDocument();
    });

    it('prefers overview total vessel count over mapped positions length', () => {
      render(
        <PortOverviewTab
          {...defaultProps}
          overviewProgress={{
            current: 1,
            total: 3,
            isComplete: false,
            vesselsLoaded: 0,
            totalVessels: 3,
            percentage: 33,
            estimatedTimeRemaining: 2,
          }}
        />,
      );

      expect(
        screen.getByRole('button', { name: 'Vessels In Port' }),
      ).toBeInTheDocument();
      expect(screen.getByText('3')).toBeInTheDocument();
    });

    it('shows a no-mappable-vessels empty state when count is non-zero but positions are empty', () => {
      render(
        <PortOverviewTab
          {...defaultProps}
          overviewProgress={{
            current: 1,
            total: 2,
            isComplete: false,
            vesselsLoaded: 0,
            totalVessels: 2,
            percentage: 50,
            estimatedTimeRemaining: 1,
          }}
        />,
      );

      fireEvent.click(screen.getByRole('button', { name: 'Vessels In Port' }));

      expect(
        screen.getByRole('button', { name: 'In Port' }),
      ).toBeInTheDocument();
      expect(
        screen.getByText('No mappable vessels currently in port'),
      ).toBeInTheDocument();
    });
  });

  describe('boundaryGeometry prop', () => {
    it('passes undefined boundaryGeometry to OverviewMap when port has no geometry', () => {
      render(<PortOverviewTab {...defaultProps} portBoundary={undefined} />);

      expect(
        capturedOverviewMapProps.current?.boundaryGeometry,
      ).toBeUndefined();
    });

    it('passes port geometry as boundaryGeometry to OverviewMap', () => {
      const geom =
        '{"type":"Polygon","coordinates":[[[0,0],[1,0],[1,1],[0,0]]]}';

      render(
        <PortOverviewTab
          {...defaultProps}
          portBoundary={{ ...basePort, geometry: geom }}
        />,
      );

      expect(capturedOverviewMapProps.current?.boundaryGeometry).toBe(geom);
    });

    it('uses port centroid as map center when overviewCenter is undefined', () => {
      render(<PortOverviewTab {...defaultProps} />);

      expect(capturedOverviewMapProps.current?.center).toEqual({
        latitude: 1.3,
        longitude: 103.8,
      });
    });

    it('prefers overviewCenter over port centroid when provided', () => {
      render(
        <PortOverviewTab
          {...defaultProps}
          overviewCenter={{ latitude: 5, longitude: 10 }}
        />,
      );

      expect(capturedOverviewMapProps.current?.center).toEqual({
        latitude: 5,
        longitude: 10,
      });
    });
  });

  describe('data fetching', () => {
    it('calls all fetch functions on mount', async () => {
      const getInBoundVessels = vi.fn().mockResolvedValue(undefined);
      const fetchLivePortTraffic = vi.fn().mockResolvedValue(undefined);
      const fetchLast30DaysData = vi.fn().mockResolvedValue(undefined);
      const refreshOverview = vi.fn().mockResolvedValue(undefined);

      render(
        <PortOverviewTab
          {...defaultProps}
          getInBoundVessels={getInBoundVessels}
          fetchLivePortTraffic={fetchLivePortTraffic}
          fetchLast30DaysData={fetchLast30DaysData}
          refreshOverview={refreshOverview}
        />,
      );

      // Wait for promises to resolve
      await Promise.resolve();
      await Promise.resolve();

      expect(getInBoundVessels).toHaveBeenCalled();
      expect(fetchLivePortTraffic).toHaveBeenCalled();
      expect(fetchLast30DaysData).toHaveBeenCalled();
      expect(refreshOverview).toHaveBeenCalled();
    });

    it('calls refresh when refresh button is clicked', async () => {
      const getInBoundVessels = vi.fn().mockResolvedValue(undefined);
      const fetchLivePortTraffic = vi.fn().mockResolvedValue(undefined);
      const fetchLast30DaysData = vi.fn().mockResolvedValue(undefined);
      const refreshOverview = vi.fn().mockResolvedValue(undefined);

      render(
        <PortOverviewTab
          {...defaultProps}
          getInBoundVessels={getInBoundVessels}
          fetchLivePortTraffic={fetchLivePortTraffic}
          fetchLast30DaysData={fetchLast30DaysData}
          refreshOverview={refreshOverview}
        />,
      );

      // Wait for initial mount
      await Promise.resolve();
      await Promise.resolve();

      // Click refresh
      const refreshButton = screen.getByRole('button', { name: /refresh/i });
      fireEvent.click(refreshButton);

      // Wait for the refresh promises
      await Promise.resolve();
      await Promise.resolve();

      // Should be called at least twice (once on mount, once on click)
      expect(getInBoundVessels).toHaveBeenCalled();
      expect(fetchLivePortTraffic).toHaveBeenCalled();
      expect(fetchLast30DaysData).toHaveBeenCalled();
      expect(refreshOverview).toHaveBeenCalled();
    });
  });
});
