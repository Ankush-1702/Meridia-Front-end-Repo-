import { useCallback, useEffect, useMemo, useState } from 'react';
import { LuRefreshCw } from 'react-icons/lu';
import CongestionTooltip from '@/features/Ports/components/CongestionTooltip';
import { InboundVessel } from '@/features/Ports/types/inboundVessels';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import LoadingTemplate from '@/shared/components/LoadingTemplate';
import OverviewCharts from '@/shared/components/OverviewCharts';
import OverviewMap from '@/shared/components/OverviewMap';
import StatsSummary from '@/shared/components/StatsSummary';
import VesselListItem from '@/shared/components/VesselListItem';
import VesselLoadingProgress from '@/shared/components/VesselLoadingProgress';
import VesselSummarySection from '@/shared/components/VesselSummarySection';
import type { ProgressInfo } from '@/shared/hooks/useOverviewData';
import type {
  OverviewCenter,
  OverviewPosition,
} from '@/shared/services/overview/types';
import type { Port, PortTabsOptions } from '@/shared/types/entities';
import {
  ICongestionResponse,
  ILiveDataResponse,
} from '@/shared/types/ZoneTrafficAndPortCongestionTypes';
import { logger } from '@/shared/utils/logger';
import { decryptGeometry } from '@/shared/utils/overviewMapUtils';

interface PortOverviewTabProps {
  port: Port;
  positions: OverviewPosition[];
  overviewCenter: OverviewCenter | undefined;
  overviewProgress: ProgressInfo | null;
  inboundVessels: InboundVessel[];
  inboundVesselsTotalCount: number;
  isInboundVesselsLoading: boolean;
  activeInboundVesselTimeFrame: string;
  setActiveInboundVesselTimeFrame: (val: string) => void;
  inboundVesselTimeFrameTabs: string[];
  isLoading: boolean;
  livePortData: ILiveDataResponse | undefined;
  last30DaysData: ICongestionResponse | undefined;
  onNavigateToEvents: (tab: PortTabsOptions) => void;
  onNavigateToCongestion: () => void;
  portBoundary: Omit<Port, 'centroid'> | undefined;
  getInBoundVessels: () => Promise<void>;
  refreshOverview: () => Promise<void>;
  fetchLivePortTraffic: () => Promise<void>;
  fetchLast30DaysData: () => Promise<void>;
}

const POLLING_INTERVAL = 5 * 60 * 1000;

export default function PortOverviewTab({
  port,
  positions,
  overviewCenter,
  overviewProgress,
  inboundVessels,
  inboundVesselsTotalCount,
  isInboundVesselsLoading,
  activeInboundVesselTimeFrame,
  setActiveInboundVesselTimeFrame,
  inboundVesselTimeFrameTabs,
  isLoading,
  livePortData,
  last30DaysData,
  onNavigateToEvents,
  onNavigateToCongestion,
  portBoundary,
  getInBoundVessels,
  refreshOverview,
  fetchLivePortTraffic,
  fetchLast30DaysData,
}: PortOverviewTabProps) {
  const [timeAgo, setTimeAgo] = useState<string>('0s');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [vesselsInPortExpanded, setVesselsInPortExpanded] = useState(false);
  const [vesselsInboundExpanded, setVesselsInboundExpanded] = useState(false);
  const vesselsInPortCount = overviewProgress?.totalVessels ?? positions.length;
  const boundaryGeometry = useMemo(
    () => decryptGeometry(portBoundary?.geometry),
    [portBoundary?.geometry],
  );

  const refreshAllData = useCallback(async () => {
    if (!port.id) return;
    setIsRefreshing(true);
    try {
      const results = await Promise.allSettled([
        getInBoundVessels(),
        fetchLivePortTraffic(),
        fetchLast30DaysData(),
        refreshOverview(),
      ]);
      results.forEach((result, index) => {
        if (result.status === 'rejected') {
          const names = [
            'getInBoundVessels',
            'fetchLivePortTraffic',
            'fetchLast30DaysData',
            'refreshOverview',
          ];
          logger.error(`${names[index]} failed:`, result.reason);
        }
      });
      setLastUpdated(new Date());
    } finally {
      setIsRefreshing(false);
    }
  }, [
    port.id,
    getInBoundVessels,
    fetchLivePortTraffic,
    fetchLast30DaysData,
    refreshOverview,
  ]);

  // Time ago updater
  useEffect(() => {
    const updateTimeAgo = () => {
      if (!lastUpdated) {
        setTimeAgo('0s');
        return;
      }

      const now = new Date();
      const diff = Math.floor((now.getTime() - lastUpdated.getTime()) / 1000);

      if (diff < 60) {
        setTimeAgo(`${diff}s`);
      } else {
        const minutes = Math.floor(diff / 60);
        setTimeAgo(`${minutes}m`);
      }
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 1000);

    return () => clearInterval(interval);
  }, [lastUpdated]);

  // Initial load
  useEffect(() => {
    if (port.id) {
      refreshAllData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [port.id]);

  // Polling interval
  useEffect(() => {
    const interval = setInterval(refreshAllData, POLLING_INTERVAL);

    return () => clearInterval(interval);
  }, [refreshAllData]);

  return (
    <div className="flex flex-col gap-4">
      {overviewProgress &&
        !overviewProgress.isComplete &&
        overviewProgress.totalVessels > 0 && (
          <VesselLoadingProgress progress={overviewProgress} />
        )}
      <div className="flex items-center justify-end gap-2 text-xs text-gray-400 ">
        <LuRefreshCw className="h-3 w-3 text-gray-400" />
        Updated {timeAgo} ago
        <button
          className="cursor-pointer text-gray-400 underline hover:text-gray-700"
          onClick={refreshAllData}
          disabled={isRefreshing}
        >
          Refresh
        </button>
      </div>

      <div className="flex gap-4">
        {/* Vessel Summary Sections */}
        <div className="w-[420px] space-y-2">
          {vesselsInPortExpanded ? (
            <VesselsInPortSection
              positions={positions}
              count={vesselsInPortCount}
              isExpanded
              onToggle={() => setVesselsInPortExpanded(false)}
              onViewAll={() => onNavigateToEvents('Historic')}
              showAll
            />
          ) : vesselsInboundExpanded ? (
            <VesselsInboundSection
              inboundVessels={inboundVessels}
              totalCount={inboundVesselsTotalCount}
              isExpanded
              onToggle={() => setVesselsInboundExpanded(false)}
              onViewAll={() => onNavigateToEvents('Inbound Vessels')}
              showHeaderButton
              timeFrameTabs={inboundVesselTimeFrameTabs}
              activeTimeFrame={activeInboundVesselTimeFrame}
              setActiveTimeFrame={setActiveInboundVesselTimeFrame}
              isLoading={isInboundVesselsLoading}
            />
          ) : (
            <>
              <VesselsInPortSection
                positions={positions}
                count={vesselsInPortCount}
                isExpanded={false}
                onToggle={() => setVesselsInPortExpanded(true)}
                onViewAll={() => onNavigateToEvents('Historic')}
                showAll={false}
              />
              <VesselsInboundSection
                inboundVessels={inboundVessels}
                totalCount={inboundVesselsTotalCount}
                isExpanded={false}
                onToggle={() => setVesselsInboundExpanded(true)}
                onViewAll={() => onNavigateToEvents('Inbound Vessels')}
                showHeaderButton={false}
                timeFrameTabs={inboundVesselTimeFrameTabs}
                activeTimeFrame={activeInboundVesselTimeFrame}
                setActiveTimeFrame={setActiveInboundVesselTimeFrame}
                isLoading={isInboundVesselsLoading}
              />
            </>
          )}

          {!vesselsInPortExpanded && !vesselsInboundExpanded && (
            <PerformanceCard
              isLoading={isLoading || isRefreshing}
              last30DaysData={last30DaysData}
              onViewCongestion={onNavigateToCongestion}
            />
          )}
        </div>

        {/* Map */}
        <div className="flex-1">
          <OverviewMap
            center={
              overviewCenter || {
                longitude: port.centroid.longitude,
                latitude: port.centroid.latitude,
              }
            }
            label={port.name}
            heightClassName="h-[480px]"
            positions={positions}
            inboundVessels={inboundVessels}
            boundaryGeometry={boundaryGeometry}
          />
        </div>
      </div>

      <OverviewCharts
        isLoading={isLoading || isRefreshing}
        liveCongestionData={livePortData}
        inLabel="Arrivals"
        outLabel="Departures"
        tooltip={<CongestionTooltip />}
      />
    </div>
  );
}

/* ---- Internal sub-components ---- */

function VesselsInPortSection({
  positions,
  count,
  isExpanded,
  onToggle,
  onViewAll,
  showAll,
}: {
  positions: OverviewPosition[];
  count: number;
  isExpanded: boolean;
  onToggle: () => void;
  onViewAll: () => void;
  showAll: boolean;
}) {
  const displayPositions = showAll ? positions : positions.slice(0, 5);
  const title = isExpanded ? 'In Port' : 'Vessels In Port';
  const isEmpty = displayPositions.length === 0;
  const emptyMessage =
    count === 0
      ? 'No vessels currently in port'
      : 'No mappable vessels currently in port';

  return (
    <VesselSummarySection
      title={title}
      count={count}
      isExpanded={isExpanded}
      onToggle={onToggle}
      isEmpty={isEmpty}
      emptyMessage={emptyMessage}
      viewAllLabel="View all"
      onViewAll={onViewAll}
    >
      {displayPositions.map((vessel) => (
        <VesselListItem
          key={vessel.id || vessel.imo}
          vesselName={vessel.name || 'Unknown Vessel'}
          vesselType={vessel.vesselType || 'Unknown'}
          imo={vessel.imo || ''}
          flag={vessel.flag || ''}
          timestamp={vessel.timestampUtc || ''}
          timestampLabel="ATA"
        />
      ))}
    </VesselSummarySection>
  );
}

function VesselsInboundSection({
  inboundVessels,
  totalCount,
  isExpanded,
  onToggle,
  onViewAll,
  showHeaderButton,
  timeFrameTabs,
  activeTimeFrame,
  setActiveTimeFrame,
  isLoading,
}: {
  inboundVessels: InboundVessel[];
  totalCount: number;
  isExpanded: boolean;
  onToggle: () => void;
  onViewAll: () => void;
  showHeaderButton: boolean;
  timeFrameTabs: string[];
  activeTimeFrame: string;
  setActiveTimeFrame: (val: string) => void;
  isLoading: boolean;
}) {
  const title = isExpanded
    ? 'Inbound'
    : `Vessels Inbound (${activeTimeFrame !== 'All' ? `next ${activeTimeFrame}` : activeTimeFrame})`;

  return (
    <VesselSummarySection
      title={title}
      count={inboundVessels.length}
      totalCount={totalCount}
      isExpanded={isExpanded}
      onToggle={onToggle}
      isEmpty={inboundVessels.length === 0}
      emptyMessage="No inbound vessels"
      viewAllLabel="View all Events"
      onViewAll={onViewAll}
      showHeaderButton={showHeaderButton}
      inboundVesselsTimeFrameTabs={timeFrameTabs}
      activeInboundTimeFrameTab={activeTimeFrame}
      setActiveInboundTimeFrameTab={setActiveTimeFrame}
      isLoading={isLoading}
    >
      {inboundVessels.map((vessel) => (
        <VesselListItem
          key={vessel.vessel_information.imo}
          vesselName={vessel.vessel_information.name || 'Unknown Vessel'}
          vesselType={vessel.vessel_information.vessel_type || 'Unknown'}
          imo={vessel.vessel_information.imo || ''}
          flag={vessel.vessel_information.flag_code || ''}
          timestamp={vessel.reported_eta || ''}
          timestampLabel="ETA"
        />
      ))}
    </VesselSummarySection>
  );
}

function PerformanceCard({
  isLoading,
  last30DaysData,
  onViewCongestion,
}: {
  isLoading: boolean;
  last30DaysData: ICongestionResponse | undefined;
  onViewCongestion: () => void;
}) {
  const hasData =
    !!last30DaysData?.totals &&
    (last30DaysData.totals.max_vessels_per_day > 0 ||
      last30DaysData.totals.vessels_per_day > 0 ||
      (last30DaysData.totals.avg_dwell_time ?? 0) > 0 ||
      (last30DaysData.totals.median_dwell_time ?? 0) > 0);

  return (
    <div className="relative flex h-[280px] w-[420px] flex-col gap-4 rounded-lg bg-white p-4 dark:bg-gray-800">
      <h3 className="text-xs">Performance (Previous 30 days)</h3>
      <div className="h-[166px]">
        {isLoading ? (
          <LoadingTemplate />
        ) : hasData ? (
          <StatsSummary
            stats={[
              {
                label: 'Unique Arrivals per Day (avg)',
                value: last30DaysData.totals?.vessels_per_day ?? 0,
              },
              {
                label: 'Unique Arrivals per Day (max)',
                value: last30DaysData.totals?.max_vessels_per_day ?? 0,
              },
              {
                label: 'Dwell time at berth (avg)',
                value: `${last30DaysData.totals!.avg_dwell_time ?? 0} hrs`,
              },
              {
                label: 'Dwell time at berth (median)',
                value: `${last30DaysData.totals?.median_dwell_time ?? 0} hrs`,
              },
            ]}
          />
        ) : (
          <CongestionEmptyState />
        )}
      </div>
      <button
        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-700"
        onClick={onViewCongestion}
      >
        View congestion and utilisation analytics
      </button>
    </div>
  );
}
