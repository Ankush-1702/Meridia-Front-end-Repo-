import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { INBOUND_VESSELS_DESTINATION_UPDATE_DAYS } from '@/app/config/config';
import { getInboundVessels } from '@/features/Ports/services/inboundVesselsApi';
import {
  fetchBerthEvents,
  fetchPortEvents,
} from '@/features/Ports/services/portServices';
import { FlatPortEventsResponse } from '@/features/Ports/types/portTypes';
import { PortEventsPanel } from '@/features/Ports/ui/PortEventsPanel';
import { CreateUnifiedPortEventsColDefs } from '@/features/Ports/utils/CombinedColDefs';
import { CreateNewInboundVesselsColDefs } from '@/features/Ports/utils/newInboundVesselsColDefs';
import {
  flattenBerthEvents,
  flattenInboundVessels,
  flattenPortEvents,
} from '@/features/Ports/utils/portUtils';
import {
  InboundTimeRangeOptions,
  PortTabsOptions,
} from '@/shared/types/entities';
import { clampEnd } from '@/shared/utils/formatUtils';
import { logger } from '@/shared/utils/logger';

interface PortEventsTabProps {
  portId: string;
  portName: string;
  refresh: boolean;
  setRefresh: (val: boolean) => void;
  portEventsTabs: { label: string; value: string }[];
  activePortEventTab: PortTabsOptions;
  setActivePortEventTab: (tab: PortTabsOptions) => void;
}

const PORT_TAB_OPTIONS = ['Historic', 'Inbound Vessels'];

const INBOUND_TIME_RANGE_TABS = ['24h', '7d', '30d', 'All'];

const portEventsCache = new Map<string, FlatPortEventsResponse[]>();

const INBOUND_VESSELS_TAB = [
  {
    label: 'Inbound Vessels',
    value: 'INBOUND',
  },
];
export default function PortEventsTab({
  portId,
  portName,
  refresh,
  setRefresh,
  portEventsTabs,
  activePortEventTab,
  setActivePortEventTab,
}: PortEventsTabProps) {
  const navigate = useNavigate();
  const [rows, setRows] = useState<FlatPortEventsResponse[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const initialSelected = portEventsTabs.reduce<Record<string, boolean>>(
    (acc, tab) => ({ ...acc, [tab.value]: true }),
    {},
  );

  const [activeInboundTimeFrame, setActiveInboundTimeFrame] =
    useState<InboundTimeRangeOptions>('24h');

  const columnStorageKey = `port-events`;
  const inboundStorageKey = `inbound-vessels`;
  const [selected, setSelected] =
    useState<Record<string, boolean>>(initialSelected);

  const onToggle = useCallback((value: string, checked: boolean) => {
    setSelected((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const onSelectAll = useCallback(
    (checked: boolean) => {
      setSelected(
        portEventsTabs.reduce<Record<string, boolean>>(
          (acc, tab) => ({ ...acc, [tab.value]: checked }),
          {},
        ),
      );
    },
    [portEventsTabs],
  );

  const selectedValues = useMemo(
    () => Object.keys(selected).filter((key) => selected[key]),
    [selected],
  );

  const selectedValuesRef = useRef(selectedValues);

  const handleActivePortEventTabChange = (tab: PortTabsOptions) => {
    setActivePortEventTab(tab);
  };

  const handleInboundTimeFrameChange = (timeFrame: InboundTimeRangeOptions) => {
    setActiveInboundTimeFrame(timeFrame);
  };

  const buildColumns = useCallback(
    (timezone: string) => {
      return activePortEventTab === 'Historic'
        ? CreateUnifiedPortEventsColDefs(timezone)
        : CreateNewInboundVesselsColDefs(timezone);
    },
    [activePortEventTab],
  );

  useEffect(() => {
    selectedValuesRef.current = selectedValues;
  }, [selectedValues]);

  const getPortEvents = useCallback(async () => {
    if (!portId) return;
    setIsLoading(true);
    try {
      if (activePortEventTab === 'Historic') {
        const now = new Date();
        const timeStampStart =
          new Date(now.getTime() - 24 * 60 * 60 * 1000 * 90)
            .toISOString()
            .split('.')[0] + 'Z';
        const timeStampEnd =
          clampEnd(now, 60, new Date()).toISOString().split('.')[0] + 'Z';
        const [berthEvents, portEvents] = await Promise.allSettled([
          fetchBerthEvents(portId, timeStampStart, timeStampEnd, 0, 500),
          fetchPortEvents(portId, timeStampStart, timeStampEnd, 0, 500),
        ]);

        const berth =
          berthEvents.status === 'fulfilled'
            ? flattenBerthEvents(berthEvents.value.data)
            : [];
        const port =
          portEvents.status === 'fulfilled'
            ? flattenPortEvents(portEvents.value.data)
            : [];
        if (berthEvents.status === 'rejected')
          logger.error('Berth events failed:', berthEvents.reason);
        if (portEvents.status === 'rejected')
          logger.error('Port events failed:', portEvents.reason);

        const combined = [...berth, ...port].sort((a, b) => {
          const dateA = a.eventTimestamp
            ? new Date(a.eventTimestamp).getTime()
            : 0;
          const dateB = b.eventTimestamp
            ? new Date(b.eventTimestamp).getTime()
            : 0;
          return dateB - dateA;
        });

        portEventsCache.set(portId, combined);

        const currentSelectedValues = selectedValuesRef.current;
        const filtered = combined
          .filter(
            (row) =>
              row.eventType && currentSelectedValues.includes(row.eventType),
          )
          .slice(0, 500);

        setRows(filtered);
        setLastUpdated(new Date());
      } else {
        const now = new Date();
        const destinationUpdateCutoff = new Date(
          now.getTime() -
            INBOUND_VESSELS_DESTINATION_UPDATE_DAYS * 24 * 60 * 60 * 1000,
        );

        let reportedETALte: string | Date;
        if (activeInboundTimeFrame === '24h') {
          reportedETALte = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        } else if (activeInboundTimeFrame === '7d') {
          reportedETALte = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        } else if (activeInboundTimeFrame === '30d') {
          reportedETALte = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
        } else {
          reportedETALte = '';
        }

        const response = await getInboundVessels({
          id: portId,
          id_type: 'id',
          limit: 500,
          offset: 0,
          last_destination_update_after: destinationUpdateCutoff.toISOString(),
          exclude_arrived: true,
          ...(activeInboundTimeFrame !== 'All' && {
            reported_eta_gte: now.toISOString(),
            reported_eta_lte:
              typeof reportedETALte === 'string'
                ? reportedETALte
                : reportedETALte.toISOString(),
          }),
        });
        const flattenedInboundEvents = flattenInboundVessels(response.data);
        const inbound = flattenedInboundEvents
          .sort((a, b) => {
            const dateA = a.reportedEta ? new Date(a.reportedEta).getTime() : 0;
            const dateB = b.reportedEta ? new Date(b.reportedEta).getTime() : 0;
            return dateB - dateA;
          })
          .slice(0, 500);
        setRows(inbound);
        setLastUpdated(new Date());
      }
    } catch {
      setRows([]);
    } finally {
      setIsLoading(false);
      setRefresh(false);
    }
  }, [portId, setRefresh, activePortEventTab, activeInboundTimeFrame]);

  useEffect(() => {
    getPortEvents();
  }, [getPortEvents]);

  useEffect(() => {
    const interval = setInterval(
      () => {
        getPortEvents();
      },
      5 * 60 * 1000,
    );

    return () => clearInterval(interval);
  }, [getPortEvents]);

  // Manual refresh trigger
  useEffect(() => {
    if (refresh) {
      getPortEvents();
    }
  }, [refresh, getPortEvents]);

  useEffect(() => {
    const cached = portEventsCache.get(portId);
    if (cached) {
      const filtered = cached
        .filter(
          (row) => row.eventType && selectedValues.includes(row.eventType),
        )
        .slice(0, 500);
      setRows(filtered);
    }
  }, [selectedValues, portId]);

  return (
    <div className="h-[calc(100dvh-135px)]">
      <PortEventsPanel
        key={activePortEventTab}
        refresh={refresh}
        portName={portName}
        portId={portId}
        portEventsTabs={
          activePortEventTab === 'Historic'
            ? portEventsTabs
            : INBOUND_VESSELS_TAB
        }
        setRefresh={setRefresh}
        selected={selected}
        onToggle={onToggle}
        onSelectAll={onSelectAll}
        rows={rows}
        buildColumns={buildColumns}
        storageKey={
          activePortEventTab === 'Historic'
            ? columnStorageKey
            : inboundStorageKey
        }
        lastUpdated={lastUpdated}
        isLoading={isLoading}
        onRowClick={(ev) => navigate(`/analytics/vessel/${ev.imo}`)}
        activeInboundTimeFrame={activeInboundTimeFrame}
        activePortEventTab={activePortEventTab}
        portTabOptions={PORT_TAB_OPTIONS}
        inboundTimeRangeTabs={INBOUND_TIME_RANGE_TABS}
        handleActivePortEventTabChange={handleActivePortEventTabChange}
        handleInboundTimeFrameChange={handleInboundTimeFrameChange}
      />
    </div>
  );
}
