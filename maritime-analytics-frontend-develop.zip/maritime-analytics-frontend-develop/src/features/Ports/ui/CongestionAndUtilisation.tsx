import { Tooltip } from 'flowbite-react';
import { useRef, useState } from 'react';
import { FaCircleInfo } from 'react-icons/fa6';
import { LuRefreshCw } from 'react-icons/lu';
import { useNavigate } from 'react-router';
import DwellTimeChart from '../Berth/components/DwellTimeLineSeries';
import { usePortCongestion } from '../hooks/usePortCongestion';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { countries } from '@/features/library/utils/countryMapping';
import { createBerthSummaryColumnDefs } from '@/features/Ports/utils/BerthSummaryColDefs';
import BarSeriesChart from '@/shared/components/BarSeriesChart';
import ChartsDownloadDropDown from '@/shared/components/ChartsDownloadDropDown';
import CongestionEmptyState from '@/shared/components/CongestionEmptyState';
import CongestionTimeRangeDropdown, {
  CongestionTimeRangePreset,
} from '@/shared/components/CongestionTimeRangeDropdown';
import CountryDropDown from '@/shared/components/CountryDrowdown';
import DonutChart from '@/shared/components/DonutChart';
import EntityActionButton from '@/shared/components/EntityActionButton';
import LineSeriesChart from '@/shared/components/LineSeriesChart';
import LoadingTemplate from '@/shared/components/LoadingTemplate';
import BerthTypeDropdown from '@/shared/components/MultiSelectDropdown';
import StatsSummary from '@/shared/components/StatsSummary';
import TimeDomainDropDown from '@/shared/components/TimeDomainDropDown';
import VesselClassDropDown from '@/shared/components/VesselClassDropDown';
import VesselTypesDropDown from '@/shared/components/VesselTypesDropDown';
import { PoleStarChartHandle } from '@/shared/lib/PoleStarCharts';
import PoleStarEntityGrid from '@/shared/lib/PoleStarEntityGrid';
import { Port } from '@/shared/types/entities';
import { getMovementValues } from '@/shared/utils/CongestionAndTrafficUtils';
import {
  buildBarSeriesCSV,
  buildDonutCSV,
  buildDwellSeriesCsv,
  buildKeyMetricsCsv,
  buildLineSeriesCSV,
  buildTopVisitingVesselsCsv,
} from '@/shared/utils/exportChartsCsv';
import { sanitizeFilenameSegment } from '@/shared/utils/formatUtils';
import { createTopVisitingVesselsColDef } from '@/shared/utils/TopVisitingVesselsColDefs';

export default function CongestionAndUtilisation({
  port,
  setActiveTab,
  setSelectedBerthId,
  setSelectedBerthName,
  initialLabel,
}: {
  port: Port;
  setActiveTab: (tab: string) => void;
  setSelectedBerthId: (id: string | undefined) => void;
  setSelectedBerthName: (name: string | undefined) => void;
  initialLabel?: CongestionTimeRangePreset;
}) {
  const {
    activeArrivalsAndDeparturesTab,
    // setActiveArrivalsAndDeparturesTab,
    // arrivalsAndDeparturesTabs,
    vesselTypesOpts,
    selectedVesselType,
    selectedVesselClass,
    selectedCountries,
    hasSelectedVesselTypes,
    handleVesselTypeToggle,
    handleVesselClassToggle,
    handleCountryToggle,
    setArrivalsAndDeparturesTimeDomain,
    arrivalsAndDeparturesTimeDomain,
    arrivalsTimeDomain,
    setArrivalsTimeDomain,
    setDateRange,
    arrivalAndDeparturesByTotals,
    arrivalsByVesselTypesAndTotals,
    arrivalsByVesselTypes,
    fetchArrivalsAndDeparturesByTotals,
    fetchArrivalsByTotalsAndVesselType,
    fetchArrivalsByVesselType,
    timeDomainDays,
    arrivalsAndDeparturesTimeDomainDisplay,
    arrivalsTimeDomainDisplay,
    isArrivalAndDeparturesByTotalsLoading,
    isArrivalsByVesselTypesLoading,
    isArrivalsByVesselTypesAndTotalsLoading,
    gridRef,
    getServerSideData,
    dwellSeriesTimeDomain,
    setDwellSeriesTimeDomain,
    berthTypes,
    selectedBerthTypes,
    handleBerthTypeToggle,
    handleBerthTypeSelectAll,
    fetchBerthFilters,
    dwellSeries,
    isDwellSeriesLoading,
    topVisitingGridRef,
    getTopVisitingVesselsServerSideData,
    topVisitingVesselData,
    isTopVisitingVesselsLoading,
    setDateRangeLabel,
    topVisitingVesselsResponse,
  } = usePortCongestion();

  const { exportToCSV } = useLibrary();
  const navigate = useNavigate();

  const lineChartRef = useRef<PoleStarChartHandle>(null);
  const donutChartRef = useRef<PoleStarChartHandle>(null);
  const barChartRef = useRef<PoleStarChartHandle>(null);
  const dwellSeriesRef = useRef<PoleStarChartHandle>(null);

  const [refresh, setRefresh] = useState(false);

  const totals = arrivalsByVesselTypesAndTotals?.totals;
  const movement = totals ? getMovementValues(totals) : null;

  const startDates =
    arrivalAndDeparturesByTotals?.query.date_start.split('T')[0] ||
    arrivalsByVesselTypes?.query.date_start.split('T')[0] ||
    arrivalsByVesselTypesAndTotals?.query.date_start.split('T')[0] ||
    topVisitingVesselsResponse?.query.date_start.split('T')[0];

  const endDates =
    arrivalAndDeparturesByTotals?.query.date_end.split('T')[0] ||
    arrivalsByVesselTypes?.query.date_end.split('T')[0] ||
    arrivalsByVesselTypesAndTotals?.query.date_end.split('T')[0] ||
    topVisitingVesselsResponse?.query.date_end.split('T')[0];

  return (
    <div className="">
      <div className="flex flex-col">
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <CongestionTimeRangeDropdown
              key={`ports congestion time range drop down`}
              onChange={setDateRange}
              label={initialLabel}
              onLabelChange={setDateRangeLabel}
            />
            <CountryDropDown
              selected={selectedCountries}
              countriesOpts={countries}
              onToggle={handleCountryToggle}
              key={`ports vessel flags`}
            />
            <VesselTypesDropDown
              onToggle={handleVesselTypeToggle}
              vesselTypesOpts={
                vesselTypesOpts as unknown as {
                  value: string;
                  defaultChecked: boolean;
                  displayValue: string;
                }[]
              }
              selected={selectedVesselType}
              key={`ports vessel types`}
            />
            <div
              className={`${hasSelectedVesselTypes ? '' : 'opacity-50 grayscale'}`}
              style={{
                pointerEvents: hasSelectedVesselTypes ? 'auto' : 'none',
              }}
            >
              <VesselClassDropDown
                selectedVesselTypes={selectedVesselType}
                selected={selectedVesselClass}
                onToggle={handleVesselClassToggle}
                vesselTypeOrder={vesselTypesOpts}
              />
            </div>
          </div>
          <div className="mt-[18px] flex gap-2">
            <EntityActionButton
              icon={<LuRefreshCw className="text-gray-400" />}
              textLabel="Refresh"
              handleClick={async () => {
                setRefresh(true);
                await Promise.all([
                  fetchArrivalsAndDeparturesByTotals(),
                  fetchArrivalsByTotalsAndVesselType(),
                  fetchArrivalsByVesselType(),
                  fetchBerthFilters(),
                  gridRef.current?.refresh(),
                  topVisitingGridRef.current?.refresh(),
                ]);
                setRefresh(false);
              }}
              refresh={refresh}
            />
            {/* <EntityActionButton
            icon={<PiDownloadSimple className="text-gray-400" />}
            textLabel="Export"
            handleClick={() => {}}
          /> */}
          </div>
        </div>
        <div className="mt-4 flex gap-4">
          <div className="relative flex h-[410px] w-[360px] flex-col gap-4 rounded-lg bg-white p-4 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                Key Metrics
              </h2>
              <ChartsDownloadDropDown
                loading={isArrivalsByVesselTypesAndTotalsLoading}
                hasData={
                  !!(
                    movement &&
                    (movement.inflow > 0 ||
                      movement.outflow > 0 ||
                      totals!.max_vessels_per_day > 0 ||
                      totals!.vessels_per_day > 0 ||
                      (totals!.avg_dwell_time ?? 0) > 0 ||
                      (totals!.median_dwell_time ?? 0) > 0)
                  )
                }
                shouldShow={false}
                onExportCSV={() => {
                  const csv = buildKeyMetricsCsv(
                    arrivalsByVesselTypesAndTotals,
                  );
                  if (csv)
                    exportToCSV(
                      csv,
                      sanitizeFilenameSegment(
                        `${port.name}-key-metrics-${startDates}-${endDates}`,
                      ),
                    );
                }}
              />
            </div>
            {isArrivalsByVesselTypesAndTotalsLoading ? (
              <LoadingTemplate />
            ) : movement &&
              (movement.inflow > 0 ||
                movement.outflow > 0 ||
                totals!.max_vessels_per_day > 0 ||
                totals!.vessels_per_day > 0 ||
                (totals!.avg_dwell_time ?? 0) > 0 ||
                (totals!.median_dwell_time ?? 0) > 0) ? (
              <StatsSummary
                stats={[
                  {
                    label: 'Arrivals',
                    value: movement.inflow,
                  },
                  {
                    label: 'Departures',
                    value: movement.outflow,
                  },
                  {
                    label: 'Unique Arrivals per Day (avg)',
                    value: totals?.vessels_per_day,
                  },
                  {
                    label: 'Unique Arrivals per Day (max)',
                    value: totals?.max_vessels_per_day,
                  },
                  {
                    label: 'Dwell time at berth (avg)',
                    value: `${totals!.avg_dwell_time ?? 0} hrs`,
                  },
                  {
                    label: 'Dwell time at berth (median)',
                    value: `${totals?.median_dwell_time ?? 0} hrs`,
                  },
                ]}
              />
            ) : (
              <CongestionEmptyState />
            )}
          </div>
          <div className="flex h-[410px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Arrivals and Departures
                </h2>
                <p className="text-xs text-gray-500">
                  {activeArrivalsAndDeparturesTab === 'Hourly Averages'
                    ? 'Average per hour of the day'
                    : `Totals per ${arrivalsAndDeparturesTimeDomainDisplay}`}
                </p>
              </div>
              <div className="flex gap-2">
                {activeArrivalsAndDeparturesTab === 'Totals' && (
                  <TimeDomainDropDown
                    // paddingYaxis="py-3"
                    key={`Arrivals and Departures`}
                    onChange={(opt) =>
                      setArrivalsAndDeparturesTimeDomain(opt.value)
                    }
                    days={timeDomainDays}
                    value={arrivalsAndDeparturesTimeDomain}
                    isLoading={isArrivalAndDeparturesByTotalsLoading}
                  />
                )}
                {/* <div style={{ pointerEvents: 'none', opacity: 0.7 }}>
                <TabGroup
                  tabs={[...arrivalsAndDeparturesTabs]}
                  active={activeArrivalsAndDeparturesTab}
                  onChange={(tab: string) =>
                    setActiveArrivalsAndDeparturesTab(tab)
                  }
                  className="bg-white dark:bg-gray-800"
                />
              </div> */}
                <ChartsDownloadDropDown
                  loading={isArrivalAndDeparturesByTotalsLoading}
                  hasData={
                    !!arrivalAndDeparturesByTotals &&
                    arrivalAndDeparturesByTotals.data.length > 0
                  }
                  onExportImage={() =>
                    lineChartRef.current?.downloadImage(
                      sanitizeFilenameSegment(
                        `${port.name}-congestion-arrivals-and-departures-per-${arrivalsAndDeparturesTimeDomainDisplay}-${startDates}-${endDates}`,
                      ),
                    )
                  }
                  onExportCSV={() => {
                    const csv = buildLineSeriesCSV(
                      arrivalAndDeparturesByTotals,
                    );
                    if (csv)
                      exportToCSV(
                        csv,
                        sanitizeFilenameSegment(
                          `${port.name}-congestion-arrivals-and-departures-per-${arrivalsAndDeparturesTimeDomainDisplay}-${startDates}-${endDates}`,
                        ),
                      );
                  }}
                />
              </div>
            </div>
            <div className="relative mt-4 h-full">
              {isArrivalAndDeparturesByTotalsLoading ? (
                <LoadingTemplate />
              ) : arrivalAndDeparturesByTotals &&
                arrivalAndDeparturesByTotals.data.length > 0 ? (
                <LineSeriesChart
                  response={arrivalAndDeparturesByTotals}
                  ref={lineChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
        </div>
        <div className="mt-4 flex gap-4 pb-6">
          <div className="flex h-[410px] w-[360px] flex-col rounded-lg bg-white p-4 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Arrivals
                </h2>
                <p className="text-xs text-gray-500">By Vessel Type, Totals</p>
              </div>
              <ChartsDownloadDropDown
                loading={isArrivalsByVesselTypesAndTotalsLoading}
                hasData={
                  !!arrivalsByVesselTypesAndTotals &&
                  arrivalsByVesselTypesAndTotals.data[0]?.items?.length > 0
                }
                onExportImage={() =>
                  donutChartRef.current?.downloadImage(
                    sanitizeFilenameSegment(
                      `${port.name}-congestion-arrivals-by-vessel-type-totals-${startDates}-${endDates}`,
                    ),
                  )
                }
                onExportCSV={() => {
                  const csv = buildDonutCSV(arrivalsByVesselTypesAndTotals);
                  if (csv)
                    exportToCSV(
                      csv,
                      sanitizeFilenameSegment(
                        `${port.name}-congestion-arrivals-by-vessel-type-totals-${startDates}-${endDates}`,
                      ),
                    );
                }}
              />
            </div>
            <div className="relative mt-4 h-full">
              {isArrivalsByVesselTypesAndTotalsLoading ? (
                <LoadingTemplate />
              ) : arrivalsByVesselTypesAndTotals &&
                arrivalsByVesselTypesAndTotals.data[0]?.items?.length > 0 ? (
                <DonutChart
                  response={arrivalsByVesselTypesAndTotals}
                  ref={donutChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
          <div className="flex h-[410px] flex-1 flex-col rounded-lg bg-white p-6 dark:bg-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                  Arrivals
                </h2>
                <p className="text-xs text-gray-500">
                  By Vessel Type, Per {arrivalsTimeDomainDisplay}
                </p>
              </div>
              <div className="flex gap-2">
                <TimeDomainDropDown
                  key={`Arrivals`}
                  onChange={(opt) => setArrivalsTimeDomain(opt.value)}
                  days={timeDomainDays}
                  value={arrivalsTimeDomain}
                  isLoading={isArrivalsByVesselTypesLoading}
                />
                <ChartsDownloadDropDown
                  loading={isArrivalsByVesselTypesLoading}
                  hasData={
                    !!arrivalsByVesselTypes &&
                    arrivalsByVesselTypes.data.length > 0
                  }
                  onExportImage={() =>
                    barChartRef.current?.downloadImage(
                      sanitizeFilenameSegment(
                        `${port.name}-congestion-arrivals-by-vessel-type-per-${arrivalsTimeDomainDisplay}-${startDates}-${endDates}`,
                      ),
                    )
                  }
                  onExportCSV={() => {
                    const csv = buildBarSeriesCSV(arrivalsByVesselTypes);
                    if (csv)
                      exportToCSV(
                        csv,
                        sanitizeFilenameSegment(
                          `${port.name}-congestion-arrivals-by-vessel-type-per-${arrivalsTimeDomainDisplay}-${startDates}-${endDates}`,
                        ),
                      );
                  }}
                />
              </div>
            </div>
            <div className="relative mt-4 h-full">
              {isArrivalsByVesselTypesLoading ? (
                <LoadingTemplate />
              ) : arrivalsByVesselTypes &&
                arrivalsByVesselTypes.data.length > 0 ? (
                <BarSeriesChart
                  response={arrivalsByVesselTypes}
                  ref={barChartRef}
                />
              ) : (
                <CongestionEmptyState />
              )}
            </div>
          </div>
        </div>
        <div className="mb-6 flex h-[600px] flex-col gap-1 rounded-lg bg-white dark:bg-gray-800">
          <div className="flex items-center justify-between gap-1 px-6 py-4">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                Top Visiting Vessels{' '}
                {topVisitingVesselData &&
                  topVisitingVesselData.length > 0 &&
                  `(${topVisitingVesselData.length})`}
              </h2>
              <Tooltip
                content={`Showing repeat visiting vessels only. Single visit vessels are excluded.`}
                className="w-64 rounded text-xs"
                arrow={false}
                placement="bottom-start"
              >
                <FaCircleInfo className="h-3 w-3 text-gray-400" />
              </Tooltip>
            </div>
            <ChartsDownloadDropDown
              loading={isTopVisitingVesselsLoading}
              hasData={
                !!topVisitingVesselData && topVisitingVesselData.length > 0
              }
              shouldShow={false}
              onExportCSV={() => {
                const csv = buildTopVisitingVesselsCsv(topVisitingVesselData);
                if (csv)
                  exportToCSV(
                    csv,
                    sanitizeFilenameSegment(
                      `${port.name}-top-visiting-vessels-${startDates}-${endDates}`,
                    ),
                  );
              }}
            />
          </div>
          <div className="min-h-0 flex-1 rounded-b-lg bg-white dark:bg-gray-800">
            <div className="h-full">
              <PoleStarEntityGrid
                ref={topVisitingGridRef}
                columns={createTopVisitingVesselsColDef()}
                getServerSideData={getTopVisitingVesselsServerSideData}
                storageKey="port-top-visiting-vessels"
                onRowClick={(event) => {
                  const data = event.data;
                  if (!data?.imo_number) return;
                  navigate(`/analytics/vessel/${data.imo_number}`);
                }}
                isSideBar={false}
                roundedTop={false}
                noRowsOverlay={`
            <div class="flex items-center justify-center h-full text-gray-500 text-base">
              No recurring vessels found for the selected period
            </div>
          `}
                pageSize={20}
              />
            </div>
          </div>
        </div>
        <div className="mb-6 flex h-[410px] flex-col gap-1 rounded-lg bg-white p-6 dark:bg-gray-800">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
                Dwell time at berth
              </h2>
              <p className="text-xs text-gray-500">
                {dwellSeriesTimeDomain} avg and median dwell time
              </p>
            </div>
            <div className="flex gap-2">
              <div
                className={`${berthTypes && berthTypes.length > 0 ? '' : 'opacity-50 grayscale'}`}
                aria-disabled={!(berthTypes && berthTypes.length > 0)}
                ref={(node) => {
                  if (!node) return;
                  if (berthTypes && berthTypes.length > 0) {
                    node.removeAttribute('inert');
                  } else {
                    node.setAttribute('inert', '');
                  }
                }}
              >
                <BerthTypeDropdown
                  align="end"
                  width={280}
                  title={`Berth Type`}
                  key={`BerthType`}
                  onToggle={handleBerthTypeToggle}
                  options={berthTypes?.map((bt) => ({ value: bt, label: bt }))}
                  selected={selectedBerthTypes}
                  onSelectAll={handleBerthTypeSelectAll}
                />
              </div>
              <TimeDomainDropDown
                key={`Dwell time at berth`}
                onChange={(opt) => setDwellSeriesTimeDomain(opt.value)}
                days={timeDomainDays}
                value={dwellSeriesTimeDomain}
                isLoading={isArrivalAndDeparturesByTotalsLoading}
              />
              <ChartsDownloadDropDown
                loading={isDwellSeriesLoading}
                hasData={
                  !!dwellSeries &&
                  dwellSeries.dwell_series &&
                  dwellSeries.dwell_series.length > 0
                }
                onExportImage={() =>
                  dwellSeriesRef.current?.downloadImage(
                    sanitizeFilenameSegment(
                      `${port.name}_congestion_dwell_time_at_berth${dwellSeriesTimeDomain.toLowerCase()}-${startDates}-${endDates}`,
                    ),
                  )
                }
                onExportCSV={() => {
                  const csv = buildDwellSeriesCsv(dwellSeries);
                  if (csv)
                    exportToCSV(
                      csv,
                      sanitizeFilenameSegment(
                        `${port.name}_congestion_dwell_time_at_berth${dwellSeriesTimeDomain.toLowerCase()}-${startDates}-${endDates}`,
                      ),
                    );
                }}
              />
            </div>
          </div>
          <div className="relative mt-4 h-full">
            {isDwellSeriesLoading ? (
              <LoadingTemplate />
            ) : dwellSeries &&
              dwellSeries.dwell_series &&
              dwellSeries.dwell_series.length > 0 ? (
              <DwellTimeChart response={dwellSeries} ref={dwellSeriesRef} />
            ) : (
              <CongestionEmptyState />
            )}
          </div>
        </div>
        <div className="mb-6 flex h-[600px] flex-col gap-1 rounded-lg bg-white dark:bg-gray-800">
          <div className="flex flex-col gap-1 p-6">
            <h2 className="text-sm font-semibold text-gray-800 dark:text-white">
              Berth Summary
            </h2>
            <p className="text-xs text-gray-500">
              All berths — click any row for full detail
            </p>
          </div>
          <div className="min-h-0 flex-1 rounded-b-lg bg-white dark:bg-gray-800">
            <div className="h-full">
              <PoleStarEntityGrid
                ref={gridRef}
                columns={createBerthSummaryColumnDefs()}
                getServerSideData={getServerSideData}
                storageKey="berth-summary-tab"
                onRowClick={(event) => {
                  const data = event.data;
                  if (data?.berth_id) {
                    setSelectedBerthId(data.berth_id);
                    setSelectedBerthName(data.berth_name);
                    setActiveTab('berths');
                  }
                }}
                isSideBar={false}
                roundedTop={false}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
