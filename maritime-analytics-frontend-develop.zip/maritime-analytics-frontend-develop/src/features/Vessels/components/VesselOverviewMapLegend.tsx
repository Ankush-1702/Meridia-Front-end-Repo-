import { Checkbox, Tooltip } from 'flowbite-react';
import { useMemo, useState } from 'react';
import { FaExclamationTriangle } from 'react-icons/fa';
import {
  FaAnchor,
  FaChevronDown,
  FaChevronUp,
  FaClipboard,
  FaLink,
  FaVectorSquare,
} from 'react-icons/fa6';
import { PiWifiSlashBold } from 'react-icons/pi';
import { useShallow } from 'zustand/react/shallow';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  getEventLegendKey,
  LEGEND_EVENT_KEYS,
  LEGEND_EVENT_META,
  LegendEventKey,
  PositionSource,
} from '@/features/Vessels/types/vesselActivityTypes';
import {
  TRACK_COLOR_LEGEND,
  TrackColorMode,
} from '@/features/Vessels/utils/replayPositionUtils';

const LEGEND_ICONS: Record<LegendEventKey, React.ReactNode> = {
  port_arrival: <FaAnchor size={10} />,
  port_departure: <FaAnchor size={10} />,
  zone_entry: <FaVectorSquare size={10} />,
  zone_exit: <FaVectorSquare size={10} />,
  ais_gap: <PiWifiSlashBold size={10} />,
  sts: <FaLink size={10} />,
  discrepancy: <FaExclamationTriangle size={10} />,
  psc: <FaClipboard size={10} />,
};

// const POSITION_OPTIONS: { value: PositionSource; label: string }[] = [
//   { value: 'blended', label: 'Blended' },
//   { value: 'ais', label: 'AIS' },
//   { value: 'lrit', label: 'LRIT' },
//   { value: 'none', label: 'None' },
// ];

const TRACK_TABS: {
  value: TrackColorMode | 'draught';
  label: string;
  disabled: boolean;
}[] = [
  { value: 'nav_status', label: 'Nav', disabled: false },
  { value: 'speed', label: 'Speed', disabled: false },
  { value: 'draught', label: 'Draught', disabled: true },
];

function TrackLine({ color, dashed }: { color: string; dashed: boolean }) {
  return (
    <svg width="32" height="8" viewBox="0 0 32 8" className="shrink-0">
      {dashed ? (
        <line
          x1="0"
          y1="4"
          x2="32"
          y2="4"
          stroke={color}
          strokeWidth="2"
          strokeDasharray="4 3"
          strokeLinecap="round"
        />
      ) : (
        <line
          x1="0"
          y1="4"
          x2="32"
          y2="4"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      )}
    </svg>
  );
}

interface Props {
  events: ActivityEvent[];
  colorMode: TrackColorMode;
  onColorModeChange: (mode: TrackColorMode) => void;
  positionSource: PositionSource;
  onPositionSourceChange: (src: PositionSource) => void;
}

export default function VesselOverviewMapLegend({
  events,
  colorMode,
  onColorModeChange,
  // positionSource,
  // onPositionSourceChange,
}: Props) {
  const [open, setOpen] = useState(false);

  const { filters, toggleFilter, setFilters } = useVesselActivityStore(
    useShallow((s) => ({
      filters: s.filters,
      toggleFilter: s.toggleFilter,
      setFilters: s.setFilters,
    })),
  );

  const eventCounts = useMemo(() => {
    const counts = {} as Record<LegendEventKey, number>;
    for (const key of LEGEND_EVENT_KEYS) counts[key] = 0;
    for (const e of events) counts[getEventLegendKey(e)] += 1;
    return counts;
  }, [events]);

  const keysWithEvents = LEGEND_EVENT_KEYS.filter(
    (key) => eventCounts[key] > 0,
  );

  const allChecked =
    keysWithEvents.length > 0 && keysWithEvents.every((key) => filters[key]);

  function toggleAll() {
    if (allChecked) {
      setFilters(
        keysWithEvents.reduce((acc, key) => ({ ...acc, [key]: false }), {
          ...filters,
        }),
      );
    } else {
      setFilters(
        keysWithEvents.reduce((acc, key) => ({ ...acc, [key]: true }), {
          ...filters,
        }),
      );
    }
  }

  return (
    <div
      className={`select-none overflow-hidden rounded-lg bg-white shadow-2xl transition-all duration-200 dark:bg-gray-800 ${
        open ? 'w-[240px]' : 'w-[150px]'
      }`}
    >
      {/* Header */}
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex w-full cursor-pointer items-center justify-between px-4 py-2.5 transition-colors hover:bg-gray-50 dark:hover:bg-gray-700"
      >
        <span className="text-xs font-semibold text-gray-900 dark:text-white">
          Legend
        </span>
        {open ? (
          <FaChevronUp size={10} className="text-gray-400" />
        ) : (
          <FaChevronDown size={10} className="text-gray-400" />
        )}
      </button>

      {open && (
        <div className="px-4 pb-4">
          <div className="-mx-4 mb-3 border-t border-gray-200 dark:border-gray-700" />

          {/* EVENTS */}
          <p className="mb-2 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
            Events
          </p>
          <Tooltip
            content={`Show / Hide All `}
            placement="right"
            className="whitespace-nowrap rounded text-xs"
            arrow={false}
          >
            <label
              htmlFor="legend-toggle-all"
              className="mb-2 flex cursor-pointer items-center gap-2"
            >
              <Checkbox
                id="legend-toggle-all"
                checked={allChecked}
                onChange={toggleAll}
                color="psgLightPrimary"
              />
              <span className="text-xs text-gray-700 dark:text-gray-300">
                Show / Hide All
              </span>
            </label>
          </Tooltip>

          <div className="space-y-1.5">
            {LEGEND_EVENT_KEYS.map((key) => {
              const meta = LEGEND_EVENT_META[key];
              const count = eventCounts[key];
              const hasEvents = count > 0;
              return (
                <Tooltip
                  key={key}
                  content={
                    hasEvents
                      ? `${meta.label}`
                      : `${meta.label} events not available`
                  }
                  placement="right"
                  className="whitespace-nowrap rounded text-xs"
                  arrow={false}
                >
                  <label
                    htmlFor={`legend-event-${key}`}
                    className={`flex items-center gap-2 ${
                      hasEvents
                        ? 'cursor-pointer'
                        : 'pointer-events-none opacity-40'
                    }`}
                  >
                    <Checkbox
                      id={`legend-event-${key}`}
                      checked={hasEvents && filters[key]}
                      onChange={() => toggleFilter(key)}
                      disabled={!hasEvents}
                      color="psgLightPrimary"
                    />
                    <div
                      className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white"
                      style={{ background: meta.color }}
                    >
                      {LEGEND_ICONS[key]}
                    </div>
                    <span className="flex-1 text-xs text-gray-700 dark:text-gray-300">
                      {meta.label}
                    </span>
                  </label>
                </Tooltip>
              );
            })}
          </div>

          {/* POSITIONS
          <div className="mb-3 mt-4" />
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
            Positions
          </p>
          <div className="flex overflow-hidden rounded border border-gray-200 dark:border-gray-700">
            {POSITION_OPTIONS.map(({ value, label }) => {
              const disabled = value !== 'ais';
              const active = positionSource === value;
              return (
                <button
                  key={value}
                  onClick={() => !disabled && onPositionSourceChange(value)}
                  disabled={disabled}
                  title={disabled ? 'Coming soon' : undefined}
                  className={`flex-1 py-1 text-[10px] font-medium transition-colors ${
                    disabled
                      ? 'cursor-not-allowed bg-gray-100/40 text-gray-400 opacity-50 dark:bg-gray-700/40 dark:text-gray-500'
                      : active
                        ? 'bg-psg-orange-800 text-white'
                        : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div> */}

          {/* TRACK */}
          <div className="mb-3 mt-4" />
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-gray-400">
            Track
          </p>
          <div className="mb-3 flex overflow-hidden rounded border border-gray-200 dark:border-gray-700">
            {TRACK_TABS.map(({ value, label, disabled }) => {
              const active = !disabled && colorMode === value;
              return (
                <button
                  key={value}
                  onClick={() =>
                    !disabled && onColorModeChange(value as TrackColorMode)
                  }
                  disabled={disabled}
                  title={disabled ? 'Coming soon' : undefined}
                  className={`flex-1 py-1 text-[10px] font-medium transition-colors ${
                    disabled
                      ? 'cursor-not-allowed bg-gray-100/40 text-gray-400 opacity-50 dark:bg-gray-700/40 dark:text-gray-500'
                      : active
                        ? 'bg-psg-orange-800 text-white'
                        : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          <div className="space-y-2">
            {TRACK_COLOR_LEGEND[colorMode].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-2">
                <TrackLine color={color} dashed={false} />
                <span className="text-xs text-gray-600 dark:text-gray-300">
                  {label}
                </span>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <TrackLine color="#6b7280" dashed={true} />
              <span className="text-xs text-gray-600 dark:text-gray-300">
                AIS Gap
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
