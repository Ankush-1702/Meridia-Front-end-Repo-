import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import VesselTabs from '@/features/Vessels/components/VesselTabs';

interface TabGroupProps {
  tabs: string[];
  active: string;
  onChange: (tab: string) => void;
  className?: string;
}

vi.mock('@/shared/components/TabGroup', () => {
  return {
    default: ({ tabs, active, onChange, className }: TabGroupProps) => (
      <div className={className}>
        {tabs.map((tab) => (
          <button
            key={tab}
            aria-pressed={tab === active}
            onClick={() => onChange(tab)}
          >
            {tab}
          </button>
        ))}
      </div>
    ),
  };
});

describe('VesselTabs', () => {
  const tabs = ['Overview', 'Details', 'History'];
  const activeTab = 'Details';

  it('renders all tabs', () => {
    render(<VesselTabs tabs={tabs} active={activeTab} onChange={vi.fn()} />);

    for (const tab of tabs) {
      expect(screen.getByText(tab)).toBeInTheDocument();
    }
  });

  it('marks the active tab correctly', () => {
    render(<VesselTabs tabs={tabs} active={activeTab} onChange={vi.fn()} />);

    const activeButton = screen.getByText(activeTab);
    expect(activeButton).toHaveAttribute('aria-pressed', 'true');
  });

  it('calls onChange with the correct tab when clicked', () => {
    const onChange = vi.fn();

    render(<VesselTabs tabs={tabs} active={activeTab} onChange={onChange} />);

    fireEvent.click(screen.getByText('Overview'));

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith('Overview');
  });

  it('passes className to TabGroup', () => {
    render(
      <VesselTabs
        tabs={tabs}
        active={activeTab}
        onChange={vi.fn()}
        className="px-2"
      />,
    );

    const container = screen.getByText('Overview').parentElement;
    expect(container).toHaveClass('px-2');
  });
});
