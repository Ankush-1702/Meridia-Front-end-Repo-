import { GanttGroupMode } from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  ActivityEventCategory,
  ActivityFilters,
  categoryEnabled,
  CATEGORY_META,
  getEventLegendKey,
  LEGEND_EVENT_META,
} from '@/features/Vessels/types/vesselActivityTypes';

// ── Layout constants ──────────────────────────────────────────────────────────

export const SIDEBAR_W = 180;
export const GROUP_HEADER_H = 24;
export const LANE_ROW_H = 32;
export const HEADER_H = 40;
export const TICK_W = 3;
export const MIN_BAR_PX = 4;
export const REPLAY_FUTURE_BAR_OPACITY = 0.25;

// ── Category + port-type ordering ────────────────────────────────────────────

export const CATEGORY_ORDER: ActivityEventCategory[] = [
  'port',
  'zone',
  'ais_gap',
  'sts',
  'discrepancy',
  'psc',
];

export type PortTypeKey = 'port-area' | 'port' | 'berth';
export const PORT_TYPE_ORDER: PortTypeKey[] = ['port-area', 'port', 'berth'];
export const PORT_GROUP_LABELS: Record<PortTypeKey, string> = {
  'port-area': 'PORT AREA',
  port: 'PORT',
  berth: 'BERTH',
};
export const PORT_TYPE_LABELS: Record<PortTypeKey, string> = {
  'port-area': 'Port Area',
  port: 'Port',
  berth: 'Berth',
};

export function getPortTypeKey(subType: string): PortTypeKey {
  if (subType.includes('PORT_AREA')) return 'port-area';
  if (subType.includes('BERTH')) return 'berth';
  return 'port';
}

// ── Row / Bar types ───────────────────────────────────────────────────────────

export interface Row {
  id: string;
  label: string;
  category: ActivityEventCategory;
  isGroupHeader: boolean;
  isIndented: boolean;
  height: number;
}

export interface Bar {
  eventId: string;
  rowId: string;
  label: string;
  locationLabel: string;
  startMs: number;
  endMs: number | null;
  color: string;
  event: ActivityEvent;
}

export type BarReplayState = 'future' | 'active' | 'ended' | 'normal';

export function getBarReplayState(
  startMs: number,
  endMs: number | null,
  cursorMs: number,
): BarReplayState {
  if (startMs > cursorMs) return 'future';
  if (endMs !== null && endMs <= cursorMs) return 'ended';
  return 'active';
}

// ── Span-event builder ────────────────────────────────────────────────────────

export function buildSpanEvents(
  sourceEvents: ActivityEvent[],
): ActivityEvent[] {
  const sorted = [...sourceEvents].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime(),
  );
  const usedIds = new Set<string>();
  const spans: ActivityEvent[] = [];
  const open = new Map<string, ActivityEvent[]>();

  function keyFor(ev: ActivityEvent) {
    const portType =
      ev.category === 'port' ? getPortTypeKey(ev.subType) : 'n/a';
    return `${ev.category}::${ev.label}::${portType}`;
  }

  function isStartEvent(ev: ActivityEvent) {
    const t = ev.subType.toUpperCase();
    return t.includes('ARRIVAL') || t.includes('ENTRY');
  }

  function isEndEvent(ev: ActivityEvent) {
    const t = ev.subType.toUpperCase();
    return t.includes('DEPARTURE') || t.includes('EXIT');
  }

  for (const ev of sorted) {
    if (ev.endTime) continue;
    if (ev.category !== 'port' && ev.category !== 'zone') continue;

    const key = keyFor(ev);
    if (isStartEvent(ev)) {
      const stack = open.get(key) ?? [];
      stack.push(ev);
      open.set(key, stack);
      continue;
    }

    if (isEndEvent(ev)) {
      const stack = open.get(key);
      const start = stack?.pop();
      if (!start) {
        usedIds.add(ev.id);
        continue;
      }
      usedIds.add(start.id);
      usedIds.add(ev.id);
      spans.push({
        ...start,
        id: `${start.id}::${ev.id}`,
        endTime: ev.startTime,
      });
    }
  }

  const untouched = sourceEvents.filter((ev) => !usedIds.has(ev.id));
  return [...untouched, ...spans].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime(),
  );
}

// ── Duration formatters ───────────────────────────────────────────────────────

export function formatDuration(ms: number): string {
  const mins = Math.round(ms / 60000);
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

export function formatDurationShort(ms: number): string {
  const mins = Math.round(ms / 60_000);
  if (mins < 60) return `${mins}m`;
  const h = mins / 60;
  if (h < 24) return `${h.toFixed(1)}h`;
  return `${(h / 24).toFixed(1)}d`;
}

// ── Row + bar builder ─────────────────────────────────────────────────────────

export function buildRowsAndBars(
  events: ActivityEvent[],
  filters: ActivityFilters,
  mode: GanttGroupMode,
): { rows: Row[]; bars: Bar[]; minMs: number; maxMs: number } {
  const rows: Row[] = [];
  const bars: Bar[] = [];
  let minMs = Infinity;
  let maxMs = -Infinity;

  function processEvent(ev: ActivityEvent, rowId: string): void {
    const startMs = new Date(ev.startTime).getTime();
    if (isNaN(startMs)) return;
    const rawEndMs = ev.endTime ? new Date(ev.endTime).getTime() : null;
    const validRawEnd = rawEndMs && !isNaN(rawEndMs) ? rawEndMs : null;

    minMs = Math.min(minMs, startMs);
    maxMs = Math.max(maxMs, validRawEnd ?? startMs);

    const durMs = validRawEnd ? validRawEnd - startMs : 0;
    const isPoint = validRawEnd === null || durMs < 60_000;

    bars.push({
      eventId: ev.id,
      rowId,
      label: ev.label || ev.subType,
      locationLabel: ev.label,
      startMs,
      endMs: isPoint ? null : validRawEnd,
      color: LEGEND_EVENT_META[getEventLegendKey(ev)].color,
      event: ev,
    });
  }

  if (mode === 'by-event-type') {
    for (const category of CATEGORY_ORDER) {
      if (!categoryEnabled(filters, category)) continue;
      const catEvents = events.filter(
        (e) => e.category === category && filters[getEventLegendKey(e)],
      );
      if (catEvents.length === 0) continue;

      if (category === 'port') {
        const groups = new Map<PortTypeKey, Map<string, true>>();
        PORT_TYPE_ORDER.forEach((k) => groups.set(k, new Map()));

        for (const ev of catEvents) {
          const ptk = getPortTypeKey(ev.subType);
          groups.get(ptk)!.set(ev.label, true);
        }

        for (const ptk of PORT_TYPE_ORDER) {
          const locations = groups.get(ptk)!;
          if (locations.size === 0) continue;

          rows.push({
            id: `group::${ptk}`,
            label: PORT_GROUP_LABELS[ptk],
            category: 'port',
            isGroupHeader: true,
            isIndented: false,
            height: GROUP_HEADER_H,
          });

          for (const loc of locations.keys()) {
            rows.push({
              id: `${ptk}::${loc}`,
              label: loc,
              category: 'port',
              isGroupHeader: false,
              isIndented: true,
              height: LANE_ROW_H,
            });
          }
        }

        for (const ev of catEvents) {
          processEvent(ev, `${getPortTypeKey(ev.subType)}::${ev.label}`);
        }
      } else if (category === 'zone') {
        const locations = new Map<string, true>();
        for (const ev of catEvents) locations.set(ev.label, true);

        rows.push({
          id: 'group::zone',
          label: 'ZONE EVENTS',
          category: 'zone',
          isGroupHeader: true,
          isIndented: false,
          height: GROUP_HEADER_H,
        });

        for (const loc of locations.keys()) {
          rows.push({
            id: `zone::${loc}`,
            label: loc,
            category: 'zone',
            isGroupHeader: false,
            isIndented: true,
            height: LANE_ROW_H,
          });
        }

        for (const ev of catEvents) {
          processEvent(ev, `zone::${ev.label}`);
        }
      } else {
        rows.push({
          id: `cat::${category}`,
          label: CATEGORY_META[category].label.toUpperCase(),
          category,
          isGroupHeader: false,
          isIndented: false,
          height: LANE_ROW_H,
        });

        for (const ev of catEvents) {
          processEvent(ev, `cat::${category}`);
        }
      }
    }
  } else {
    const portByLoc = new Map<string, Set<PortTypeKey>>();
    const zoneByLoc = new Map<string, true>();

    for (const ev of events) {
      if (!filters[getEventLegendKey(ev)]) continue;
      if (ev.category === 'port') {
        if (!portByLoc.has(ev.label)) portByLoc.set(ev.label, new Set());
        portByLoc.get(ev.label)!.add(getPortTypeKey(ev.subType));
      } else if (ev.category === 'zone') {
        zoneByLoc.set(ev.label, true);
      }
    }

    for (const [loc, ptks] of portByLoc) {
      rows.push({
        id: `loc-group::${loc}`,
        label: loc.toUpperCase(),
        category: 'port',
        isGroupHeader: true,
        isIndented: false,
        height: GROUP_HEADER_H,
      });

      for (const ptk of PORT_TYPE_ORDER) {
        if (!ptks.has(ptk)) continue;
        rows.push({
          id: `${loc}::${ptk}`,
          label: PORT_TYPE_LABELS[ptk],
          category: 'port',
          isGroupHeader: false,
          isIndented: true,
          height: LANE_ROW_H,
        });
      }
    }

    for (const ev of events.filter(
      (e) => e.category === 'port' && filters[getEventLegendKey(e)],
    )) {
      processEvent(ev, `${ev.label}::${getPortTypeKey(ev.subType)}`);
    }

    if (zoneByLoc.size > 0) {
      for (const loc of zoneByLoc.keys()) {
        rows.push({
          id: `zone-group::${loc}`,
          label: loc.toUpperCase(),
          category: 'zone',
          isGroupHeader: true,
          isIndented: false,
          height: GROUP_HEADER_H,
        });
        rows.push({
          id: `${loc}::zone`,
          label: 'Zone',
          category: 'zone',
          isGroupHeader: false,
          isIndented: true,
          height: LANE_ROW_H,
        });
      }

      for (const ev of events.filter(
        (e) => e.category === 'zone' && filters[getEventLegendKey(e)],
      )) {
        processEvent(ev, `${ev.label}::zone`);
      }
    }

    for (const category of [
      'ais_gap',
      'sts',
      'discrepancy',
      'psc',
    ] as ActivityEventCategory[]) {
      if (!categoryEnabled(filters, category)) continue;
      const catEvents = events.filter((e) => e.category === category);
      if (catEvents.length === 0) continue;

      rows.push({
        id: `cat::${category}`,
        label: CATEGORY_META[category].label.toUpperCase(),
        category,
        isGroupHeader: false,
        isIndented: false,
        height: LANE_ROW_H,
      });

      for (const ev of catEvents) {
        processEvent(ev, `cat::${category}`);
      }
    }
  }

  return { rows, bars, minMs, maxMs };
}

// ── Tick generator ────────────────────────────────────────────────────────────

export function getTicks(
  startMs: number,
  endMs: number,
  width: number,
): { ms: number; label: string }[] {
  const spanMs = endMs - startMs;
  if (spanMs <= 0 || width <= 0) return [];

  const approxCount = Math.max(3, Math.floor(width / 110));

  const DAY = 86_400_000;
  const HOUR = 3_600_000;

  // Shared formatter for day-level ticks — always includes year
  const fmtDay = (d: Date) =>
    d.toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC',
    }); // e.g. "05 Jun 2026"

  const candidates: {
    approxMs: number;
    snap: (ms: number) => number;
    advance: (ms: number) => number;
    fmt: (d: Date) => string;
  }[] = [
    {
      approxMs: 60_000,
      snap: (ms) => Math.ceil(ms / 60_000) * 60_000,
      advance: (ms) => ms + 60_000,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 5 * 60_000,
      snap: (ms) => Math.ceil(ms / (5 * 60_000)) * (5 * 60_000),
      advance: (ms) => ms + 5 * 60_000,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 15 * 60_000,
      snap: (ms) => Math.ceil(ms / (15 * 60_000)) * (15 * 60_000),
      advance: (ms) => ms + 15 * 60_000,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 30 * 60_000,
      snap: (ms) => Math.ceil(ms / (30 * 60_000)) * (30 * 60_000),
      advance: (ms) => ms + 30 * 60_000,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: HOUR,
      snap: (ms) => Math.ceil(ms / HOUR) * HOUR,
      advance: (ms) => ms + HOUR,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 3 * HOUR,
      snap: (ms) => Math.ceil(ms / (3 * HOUR)) * (3 * HOUR),
      advance: (ms) => ms + 3 * HOUR,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 6 * HOUR,
      snap: (ms) => Math.ceil(ms / (6 * HOUR)) * (6 * HOUR),
      advance: (ms) => ms + 6 * HOUR,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: 12 * HOUR,
      snap: (ms) => Math.ceil(ms / (12 * HOUR)) * (12 * HOUR),
      advance: (ms) => ms + 12 * HOUR,
      fmt: (d) => d.toISOString().slice(11, 16),
    },
    {
      approxMs: DAY,
      snap: (ms) => Math.ceil(ms / DAY) * DAY,
      advance: (ms) => ms + DAY,
      fmt: fmtDay,
    },
    {
      approxMs: 3 * DAY,
      snap: (ms) => Math.ceil(ms / (3 * DAY)) * (3 * DAY),
      advance: (ms) => ms + 3 * DAY,
      fmt: fmtDay,
    },
    {
      approxMs: 7 * DAY,
      snap: (ms) => Math.ceil(ms / (7 * DAY)) * (7 * DAY),
      advance: (ms) => ms + 7 * DAY,
      fmt: fmtDay,
    },
    {
      approxMs: 14 * DAY,
      snap: (ms) => Math.ceil(ms / (14 * DAY)) * (14 * DAY),
      advance: (ms) => ms + 14 * DAY,
      fmt: fmtDay,
    },
    // Calendar months — already include year via toLocaleString
    {
      approxMs: 30 * DAY,
      snap: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
      },
      advance: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
      },
      fmt: (d) =>
        d.toLocaleString('en-GB', {
          month: 'short',
          year: 'numeric',
          timeZone: 'UTC',
        }),
    },
    {
      approxMs: 60 * DAY,
      snap: (ms) => {
        const d = new Date(ms);
        const snappedMonth = Math.floor(d.getUTCMonth() / 2) * 2;
        return Date.UTC(d.getUTCFullYear(), snappedMonth, 1);
      },
      advance: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 2, 1);
      },
      fmt: (d) =>
        d.toLocaleString('en-GB', {
          month: 'short',
          year: 'numeric',
          timeZone: 'UTC',
        }),
    },
    {
      approxMs: 91 * DAY, // quarter
      snap: (ms) => {
        const d = new Date(ms);
        const snappedMonth = Math.floor(d.getUTCMonth() / 3) * 3;
        return Date.UTC(d.getUTCFullYear(), snappedMonth, 1);
      },
      advance: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 3, 1);
      },
      fmt: (d) => {
        const q = Math.floor(d.getUTCMonth() / 3) + 1;
        return `Q${q} ${d.getUTCFullYear()}`;
      },
    },
    {
      approxMs: 182 * DAY, // half-year
      snap: (ms) => {
        const d = new Date(ms);
        const snappedMonth = Math.floor(d.getUTCMonth() / 6) * 6;
        return Date.UTC(d.getUTCFullYear(), snappedMonth, 1);
      },
      advance: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 6, 1);
      },
      fmt: (d) =>
        d.toLocaleString('en-GB', {
          month: 'short',
          year: 'numeric',
          timeZone: 'UTC',
        }),
    },
    {
      approxMs: 365 * DAY,
      snap: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear(), 0, 1);
      },
      advance: (ms) => {
        const d = new Date(ms);
        return Date.UTC(d.getUTCFullYear() + 1, 0, 1);
      },
      fmt: (d) => String(d.getUTCFullYear()),
    },
  ]; // Pick the finest candidate that produces <= approxCount ticks

  const rawStep = spanMs / approxCount;
  const chosen =
    candidates.find((c) => c.approxMs >= rawStep) ??
    candidates[candidates.length - 1];

  const ticks: { ms: number; label: string }[] = [];
  let ms = chosen.snap(startMs); // snap may land before startMs for calendar-month snapping — advance once if so
  if (ms < startMs) ms = chosen.advance(ms);

  while (ms <= endMs) {
    ticks.push({ ms, label: chosen.fmt(new Date(ms)) });
    ms = chosen.advance(ms);
    if (ticks.length > 500) break; // safety
  }
  return ticks;
}
