import { Button, Datepicker, Tooltip } from 'flowbite-react';
import { useEffect, useState } from 'react';
import { FaAnchor, FaCalendarDays, FaShip } from 'react-icons/fa6';
import { HiChevronDown, HiChevronUp } from 'react-icons/hi';
import { LuLayoutList, LuMaximize2, LuMinimize2 } from 'react-icons/lu';
import { useLatestVesselPosition } from '@/features/Vessels/hooks/useLatestVesselPosition';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  PREV_DAYS_OPTIONS,
  PrevDays,
  ToolbarDateState,
} from '@/features/Vessels/types/toolbarTypes';
import { fmtEta } from '@/features/Vessels/utils/vesselActivityFormatters';
import { PopOverPanel } from '@/shared/components/PopOverPanel';
import { usePopOver } from '@/shared/hooks/usePopOver';
import { DateRange } from '@/shared/types/entities';

function buildPrevDaysRange(days: PrevDays): DateRange {
  const now = new Date();
  const end = new Date(now.getTime() - 30_000);
  const start = new Date(now);
  start.setUTCDate(start.getUTCDate() - (days - 1));
  start.setUTCHours(0, 0, 0, 0);
  const fmt = (d: Date) => d.toISOString().replace(/\.\d{3}Z$/, 'Z');
  return { start: fmt(start), end: fmt(end) };
}

function buildCustomRange(startStr: string, endStr: string): DateRange {
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const start = `${startStr}T00:00:00Z`;
  let end: string;
  if (endStr >= todayStr) {
    const clamped = new Date(now.getTime() - 60_000);
    end = clamped.toISOString().replace(/\.\d{3}Z$/, 'Z');
  } else {
    end = `${endStr}T23:59:59Z`;
  }
  return { start, end };
}

function stripTime(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}
function addTwoYears(date: Date): Date {
  const r = new Date(date);
  r.setFullYear(r.getFullYear() + 2);
  return r;
}
function subtractTwoYears(date: Date): Date {
  const r = new Date(date);
  r.setFullYear(r.getFullYear() - 2);
  return r;
}
function earlierDate(a: Date, b: Date): Date {
  return a < b ? a : b;
}
function isWithinTwoYears(start: Date, end: Date): boolean {
  return stripTime(end) <= addTwoYears(stripTime(start));
}

interface Props {
  onDateRangeChange: (range: DateRange) => void;
  dateState: ToolbarDateState;
  onDateStateChange: (state: ToolbarDateState) => void;
  refresh?: boolean;
  setRefresh?: (v: boolean) => void;
  sidebarOpen?: boolean;
  onToggleSidebar?: () => void;
  imo?: string;
  isInFocusMode?: boolean;
  onToggleFocusMode?: () => void;
}

export default function VesselActivityToolbar({
  onDateRangeChange,
  dateState,
  onDateStateChange,
  refresh,
  setRefresh,
  sidebarOpen,
  onToggleSidebar,
  imo,
  isInFocusMode,
  onToggleFocusMode,
}: Props) {
  const {
    prevDays: toolbarPrevDays,
    isCustom: toolbarIsCustom,
    customStart: toolbarCustomStart,
    customEnd: toolbarCustomEnd,
  } = dateState;

  const timelinePanelOpen = useVesselActivityStore((s) => s.timelinePanelOpen);
  const setTimelinePanelOpen = useVesselActivityStore(
    (s) => s.setTimelinePanelOpen,
  );
  const { position: latestPos } = useLatestVesselPosition(imo ?? '');
  const destination = latestPos?.destination?.trim() || null;
  const destinationTooltip = latestPos?.destinationTooltip ?? destination;
  const eta = fmtEta(latestPos?.eta);

  const [showCustomInputs, setShowCustomInputs] = useState(false);
  const [tempStart, setTempStart] = useState('');
  const [tempEnd, setTempEnd] = useState('');
  const { ref, open, toggle, close } = usePopOver<HTMLDivElement>();

  useEffect(() => {
    if (!toolbarIsCustom) {
      onDateRangeChange(buildPrevDaysRange(toolbarPrevDays));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toolbarPrevDays]);

  useEffect(() => {
    if (!open) setShowCustomInputs(false);
  }, [open]);

  useEffect(() => {
    if (!refresh) return;
    if (toolbarIsCustom && toolbarCustomStart && toolbarCustomEnd) {
      onDateRangeChange(buildCustomRange(toolbarCustomStart, toolbarCustomEnd));
    } else {
      onDateRangeChange(buildPrevDaysRange(toolbarPrevDays));
    }
    setRefresh?.(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refresh]);

  function handlePresetSelect(days: PrevDays) {
    onDateStateChange({ ...dateState, prevDays: days, isCustom: false });
    setShowCustomInputs(false);
    onDateRangeChange(buildPrevDaysRange(days));
    close();
  }

  const today = stripTime(new Date());
  const twoYearsAgo = subtractTwoYears(today);
  const parsedStart = tempStart ? stripTime(new Date(tempStart)) : null;
  const parsedEnd = tempEnd ? stripTime(new Date(tempEnd)) : null;

  const startMinDate = twoYearsAgo;
  const startMaxDate = parsedEnd ? earlierDate(today, parsedEnd) : today;
  const endMinDate =
    parsedStart && parsedStart > twoYearsAgo ? parsedStart : twoYearsAgo;
  const endMaxDate = today;

  const isCustomRangeValid =
    !!parsedStart &&
    !!parsedEnd &&
    parsedStart >= twoYearsAgo &&
    parsedEnd <= today &&
    parsedEnd >= parsedStart &&
    isWithinTwoYears(parsedStart, parsedEnd);

  function handleCustomApply() {
    if (!isCustomRangeValid) return;
    onDateStateChange({
      ...dateState,
      isCustom: true,
      customStart: tempStart,
      customEnd: tempEnd,
    });
    setShowCustomInputs(false);
    close();
    onDateRangeChange(buildCustomRange(tempStart, tempEnd));
  }

  const buttonLabel = toolbarIsCustom
    ? 'Custom range'
    : `Previous ${toolbarPrevDays} days`;

  return (
    <div className="flex h-10 shrink-0 items-center gap-2 border-b border-gray-200 bg-white px-3 dark:border-gray-700 dark:bg-gray-800">
      {/* Sidebar toggle */}
      {onToggleSidebar && (
        <Tooltip
          content={`${sidebarOpen ? 'Hide Vessel Details' : 'Show Vessel Details'}`}
          placement={`top`}
          className="z-50 whitespace-nowrap rounded text-xs"
          arrow={false}
        >
          <button
            onClick={onToggleSidebar}
            aria-label={
              sidebarOpen ? 'Hide Vessel Details' : 'Show Vessel Details'
            }
            className={`flex h-7 w-7 items-center justify-center rounded transition-colors ${sidebarOpen ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white' : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'}`}
          >
            <FaShip className="h-4 w-4" />
          </button>
        </Tooltip>
      )}

      {/* Date range dropdown */}
      <div className="relative" ref={ref}>
        <button
          onClick={toggle}
          className="flex h-7 cursor-pointer items-center gap-1.5 rounded-md border border-gray-300 bg-white px-2.5 text-xs text-black transition-colors hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
          aria-expanded={open}
          aria-haspopup="menu"
        >
          <FaCalendarDays className="h-3 w-3 shrink-0 text-gray-500 dark:text-gray-400" />
          <span>{buttonLabel}</span>
          {!open ? (
            <HiChevronDown size={18} className="text-gray-400" />
          ) : (
            <HiChevronUp size={18} className="text-gray-400" />
          )}
        </button>

        {open && (
          <PopOverPanel align="start" width={320}>
            <div className="px-1.5 py-1.5">
              {PREV_DAYS_OPTIONS.map((days) => (
                <button
                  key={days}
                  onClick={() => handlePresetSelect(days)}
                  className={`w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 ${
                    !toolbarIsCustom && days === toolbarPrevDays
                      ? 'bg-gray-100 dark:bg-gray-700'
                      : ''
                  }`}
                >
                  Previous {days} days
                </button>
              ))}

              <button
                type="button"
                onClick={() => setShowCustomInputs((v) => !v)}
                aria-expanded={showCustomInputs}
                className={`w-full cursor-pointer rounded-md px-2 py-1.5 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 ${
                  toolbarIsCustom ? 'bg-gray-100 dark:bg-gray-700' : ''
                }`}
              >
                Custom range...
              </button>

              {showCustomInputs && (
                <div className="mt-3 space-y-3 px-1 pb-2">
                  <div className="flex items-center justify-center gap-1">
                    <div
                      className={`relative flex ${tempStart ? 'gap-1' : ''}`}
                    >
                      <Datepicker
                        placeholder="Start date"
                        value={tempStart}
                        maxDate={startMaxDate}
                        minDate={startMinDate}
                        showClearButton={false}
                        onSelectedDateChanged={(date) => {
                          setTempStart(
                            new Date(
                              date.getTime() - date.getTimezoneOffset() * 60000,
                            )
                              .toISOString()
                              .split('T')[0],
                          );
                        }}
                      />
                      {tempStart && (
                        <button
                          onClick={() => setTempStart('')}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          aria-label="Clear start date"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                    <div className={`relative flex ${tempEnd ? 'gap-1' : ''}`}>
                      <Datepicker
                        placeholder="End date"
                        value={tempEnd}
                        maxDate={endMaxDate}
                        minDate={endMinDate}
                        showClearButton={false}
                        onSelectedDateChanged={(date) => {
                          setTempEnd(
                            new Date(
                              date.getTime() - date.getTimezoneOffset() * 60000,
                            )
                              .toISOString()
                              .split('T')[0],
                          );
                        }}
                        theme={{
                          popup: {
                            root: {
                              base: 'absolute right-0 top-full mt-2 z-50 block',
                            },
                          },
                        }}
                      />
                      {tempEnd && (
                        <button
                          onClick={() => setTempEnd('')}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          aria-label="Clear end date"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </div>
                  {parsedStart && parsedEnd && !isCustomRangeValid && (
                    <p className="flex items-center justify-center text-center text-sm text-red-500">
                      Date range cannot exceed two years from current date.
                    </p>
                  )}
                  <Button
                    color="primary"
                    className="flex w-full items-center justify-center bg-psg-orange-700 text-white hover:bg-psg-orange-600 dark:bg-psg-orange-700 dark:hover:bg-psg-orange-800"
                    disabled={!isCustomRangeValid}
                    onClick={handleCustomApply}
                  >
                    Apply
                  </Button>
                </div>
              )}
            </div>
          </PopOverPanel>
        )}
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Next port chip */}
      {(destination || eta) && (
        <div className="hidden items-center gap-1.5 text-xs lg:flex">
          <FaAnchor className="h-3 w-3 shrink-0 text-gray-400 dark:text-gray-500" />
          {destination && (
            <Tooltip
              content={destinationTooltip}
              placement="bottom"
              className="max-w-fit whitespace-nowrap rounded text-xs"
              arrow={false}
            >
              <span className="max-w-28 truncate font-medium text-gray-900 dark:text-gray-100">
                {destination}
              </span>
            </Tooltip>
          )}
          {destination && eta && (
            <span className="text-gray-400 dark:text-gray-500">·</span>
          )}
          {eta && (
            <span className="whitespace-nowrap text-gray-500 dark:text-gray-400">
              ETA {eta}
            </span>
          )}
        </div>
      )}

      {/* Focus mode toggle */}
      {onToggleFocusMode && (
        <Tooltip
          content={`${isInFocusMode ? 'Exit focus mode' : 'Enter focus mode'}`}
          placement={`top`}
          className="whitespace-nowrap rounded text-xs"
          arrow={false}
        >
          <button
            type="button"
            onClick={onToggleFocusMode}
            className={`flex h-7 w-7 items-center justify-center rounded transition-colors ${
              isInFocusMode
                ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white'
                : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
            }`}
            aria-label={isInFocusMode ? 'Exit focus mode' : 'Enter focus mode'}
          >
            {isInFocusMode ? (
              <LuMinimize2 className="h-4 w-4" />
            ) : (
              <LuMaximize2 className="h-4 w-4" />
            )}
          </button>
        </Tooltip>
      )}

      {/* Show/Hide Event Timeline */}
      <Tooltip
        content={`${timelinePanelOpen ? 'Hide Event Timeline' : 'Show Event Timeline'}`}
        placement={`top`}
        className="whitespace-nowrap rounded text-xs"
        arrow={false}
      >
        <button
          onClick={() => setTimelinePanelOpen(!timelinePanelOpen)}
          className={`flex h-7 w-7 items-center justify-center rounded transition-colors ${
            timelinePanelOpen
              ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white'
              : 'text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700'
          }`}
          aria-label={`${timelinePanelOpen ? 'Hide Event Timeline' : 'Show Event Timeline'}`}
        >
          <LuLayoutList className="h-4 w-4" />
        </button>
      </Tooltip>
    </div>
  );
}
