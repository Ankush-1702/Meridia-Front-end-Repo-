import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import {
  fetchVesselAISGaps,
  fetchVesselPortCalls,
  fetchVesselPortStateControl,
  fetchVesselPositionalDiscrepancies,
  fetchVesselSTSPairings,
  fetchVesselZoneEvents,
} from '@/features/Vessels/services/vesselServices';
import { FlatVesselEventsResponse } from '@/features/Vessels/types/vesselTypes';
import { VesselEventsPanel } from '@/features/Vessels/ui/VesselEventsPanel';
import { CreateUnifiedVesselEventsColDefs } from '@/features/Vessels/utils/ColDefs/UnifiedEventsColDefs';
import {
  flattenAISGaps,
  flattenPortCalls,
  flattenPortStateControls,
  flattenPositionalDiscrepancies,
  flattenSTSEvents,
  flattenZoneEvents,
  TAB_EVENT_TYPES,
} from '@/features/Vessels/utils/vesselUtils';
import { clampEnd } from '@/shared/utils/formatUtils';
import { logger } from '@/shared/utils/logger';

interface VesselEventsTabProps {
  vesselId: string;
  vesselName: string;
  refresh: boolean;
  setRefresh: (val: boolean) => void;
  vesselEventsTabs: { label: string; value: string }[];
}

const vesselEventsCache = new Map<string, FlatVesselEventsResponse[]>();
export default function VesselEventsTab({
  vesselId,
  vesselName,
  refresh,
  setRefresh,
  vesselEventsTabs,
}: VesselEventsTabProps) {
  const navigate = useNavigate();
  const [rows, setRows] = useState<FlatVesselEventsResponse[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const initialSelected = vesselEventsTabs.reduce<Record<string, boolean>>(
    (acc, tab) => ({ ...acc, [tab.value]: true }),
    {},
  );

  const columnStorageKey = `vessel-events`;
  const [selected, setSelected] =
    useState<Record<string, boolean>>(initialSelected);

  const onToggle = useCallback((value: string, checked: boolean) => {
    setSelected((prev) => ({ ...prev, [value]: checked }));
  }, []);

  const onSelectAll = useCallback(
    (checked: boolean) => {
      setSelected(
        vesselEventsTabs.reduce<Record<string, boolean>>(
          (acc, tab) => ({ ...acc, [tab.value]: checked }),
          {},
        ),
      );
    },
    [vesselEventsTabs],
  );

  const selectedValues = useMemo(
    () => Object.keys(selected).filter((key) => selected[key]),
    [selected],
  );

  const allowedEventTypes = useMemo(
    () => selectedValues.flatMap((tab) => TAB_EVENT_TYPES[tab] ?? tab),
    [selectedValues],
  );

  const allowedEventTypesRef = useRef(allowedEventTypes);

  useEffect(() => {
    allowedEventTypesRef.current = allowedEventTypes;
  }, [allowedEventTypes]);

  const getVesselEvents = useCallback(async () => {
    if (!vesselId) return;

    setIsLoading(true);

    const now = new Date();
    const timeStampStart =
      new Date(now.getTime() - 24 * 60 * 60 * 1000 * 90)
        .toISOString()
        .split('.')[0] + 'Z';
    const timeStampEnd =
      clampEnd(now, 60, new Date()).toISOString().split('.')[0] + 'Z';
    try {
      const [
        portCalls,
        zoneEvents,
        aisGaps,
        portStateControl,
        stsPairings,
        positionalDiscrepancies,
      ] = await Promise.allSettled([
        fetchVesselPortCalls(vesselId, timeStampStart, timeStampEnd, 0, 500),
        fetchVesselZoneEvents(vesselId, timeStampStart, timeStampEnd, 0, 500),
        fetchVesselAISGaps(vesselId, timeStampStart, timeStampEnd, 0, 500),
        fetchVesselPortStateControl(
          vesselId,
          timeStampStart,
          timeStampEnd,
          0,
          500,
        ),
        fetchVesselSTSPairings(vesselId, timeStampStart, timeStampEnd, 0, 500),
        fetchVesselPositionalDiscrepancies(
          vesselId,
          timeStampStart,
          timeStampEnd,
          0,
          500,
        ),
      ]);

      const port =
        portCalls.status === 'fulfilled'
          ? flattenPortCalls(portCalls.value.data)
          : [];

      const zone =
        zoneEvents.status === 'fulfilled'
          ? flattenZoneEvents(zoneEvents.value.data)
          : [];

      const ais =
        aisGaps.status === 'fulfilled'
          ? flattenAISGaps(aisGaps.value.data)
          : [];

      const psc =
        portStateControl.status === 'fulfilled'
          ? flattenPortStateControls(portStateControl.value.data)
          : [];

      const sts =
        stsPairings.status === 'fulfilled'
          ? flattenSTSEvents(stsPairings.value.data)
          : [];

      const pd =
        positionalDiscrepancies.status === 'fulfilled'
          ? flattenPositionalDiscrepancies(positionalDiscrepancies.value.data)
          : [];

      if (portCalls.status === 'rejected') {
        logger.error('Failed to fetch port calls', portCalls.reason);
      }
      if (zoneEvents.status === 'rejected') {
        logger.error('Failed to fetch zone events', zoneEvents.reason);
      }
      if (aisGaps.status === 'rejected') {
        logger.error('Failed to fetch ais gaps', aisGaps.reason);
      }
      if (portStateControl.status === 'rejected') {
        logger.error(
          'Failed to fetch port state control',
          portStateControl.reason,
        );
      }
      if (stsPairings.status === 'rejected') {
        logger.error('Failed to fetch sts pairings', stsPairings.reason);
      }
      if (positionalDiscrepancies.status === 'rejected') {
        logger.error(
          'Failed to fetch positional discrepancies',
          positionalDiscrepancies.reason,
        );
      }

      const combined = [...port, ...zone, ...ais, ...psc, ...sts, ...pd].sort(
        (a, b) => {
          const dateA = a.eventTimestamp
            ? new Date(a.eventTimestamp).getTime()
            : 0;
          const dateB = b.eventTimestamp
            ? new Date(b.eventTimestamp).getTime()
            : 0;
          return dateB - dateA;
        },
      );

      vesselEventsCache.set(vesselId, combined);

      const currentAllowedEventTypes = allowedEventTypesRef.current;
      const filtered = combined
        .filter(
          (row) =>
            row.eventType && currentAllowedEventTypes.includes(row.eventType),
        )
        .slice(0, 500);

      setRows(filtered);
      setLastUpdated(new Date());
    } catch {
      setRows([]);
    } finally {
      setIsLoading(false);
      setRefresh(false);
    }
  }, [vesselId, setRefresh]);

  useEffect(() => {
    getVesselEvents();
  }, [getVesselEvents]);

  useEffect(() => {
    const interval = setInterval(
      () => {
        getVesselEvents();
      },
      5 * 60 * 1000,
    );

    return () => clearInterval(interval);
  }, [getVesselEvents]);

  // Manual refresh trigger
  useEffect(() => {
    if (refresh) {
      getVesselEvents();
    }
  }, [refresh, getVesselEvents]);

  useEffect(() => {
    const cached = vesselEventsCache.get(vesselId);
    if (cached) {
      const filtered = cached
        .filter(
          (row) => row.eventType && allowedEventTypes.includes(row.eventType),
        )
        .slice(0, 500);

      setRows(filtered);
    }
  }, [allowedEventTypes, vesselId]);

  return (
    <div className="h-[calc(100dvh-135px)]">
      <VesselEventsPanel
        refresh={refresh}
        vesselName={vesselName}
        vesselId={vesselId}
        vesselEventsTabs={vesselEventsTabs}
        setRefresh={setRefresh}
        selected={selected}
        onToggle={onToggle}
        onSelectAll={onSelectAll}
        rows={rows}
        buildColumns={CreateUnifiedVesselEventsColDefs}
        storageKey={columnStorageKey}
        lastUpdated={lastUpdated}
        isLoading={isLoading}
        onRowClick={(ev) => {
          if (ev.zoneId) {
            navigate(
              `/analytics/${ev.eventType === 'ZONE_ENTRY' || ev.eventType === 'ZONE_EXIT' ? 'zone' : 'port'}/${ev.zoneId}`,
            );
          }
        }}
      />
    </div>
  );
}
