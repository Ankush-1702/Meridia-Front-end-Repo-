import { render, screen, fireEvent, within } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { DEFAULT_TOOLBAR_DATE_STATE } from '@/features/Vessels/types/toolbarTypes';
import type { ActivityFilters } from '@/features/Vessels/types/vesselActivityTypes';
import VesselActivityToolbar from '@/features/Vessels/ui/VesselActivityToolbar';

/* ─── mocks ──────────────────────────────────────────────────────────────────── */

vi.mock('@/features/Vessels/hooks/useLatestVesselPosition', () => ({
  useLatestVesselPosition: () => ({ position: null }),
}));

const mockToggleFilter = vi.fn();
const mockSetTimelinePanelOpen = vi.fn();

let mockStoreState: {
  filters: ActivityFilters;
  toggleFilter: typeof mockToggleFilter;
  timelinePanelOpen: boolean;
  setTimelinePanelOpen: typeof mockSetTimelinePanelOpen;
};

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: (selector: (s: typeof mockStoreState) => unknown) =>
    selector(mockStoreState),
}));

let mockPopOverOpen = false;
let mockPopOverClose = vi.fn();
let mockPopOverToggle = vi.fn();

vi.mock('@/shared/hooks/usePopOver', () => ({
  usePopOver: () => ({
    ref: { current: null },
    open: mockPopOverOpen,
    toggle: mockPopOverToggle,
    close: mockPopOverClose,
  }),
}));

vi.mock('@/shared/components/PopOverPanel', () => ({
  PopOverPanel: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="popover-panel">{children}</div>
  ),
}));

vi.mock('flowbite-react', () => ({
  Button: ({
    children,
    disabled,
    onClick,
  }: {
    children: React.ReactNode;
    disabled?: boolean;
    onClick?: () => void;
  }) => (
    <button disabled={disabled} onClick={onClick}>
      {children}
    </button>
  ),
  Datepicker: ({
    placeholder,
    onSelectedDateChanged,
  }: {
    placeholder?: string;
    onSelectedDateChanged?: (d: Date) => void;
  }) => (
    <input
      type="text"
      placeholder={placeholder}
      data-testid={`datepicker-${placeholder?.toLowerCase().replace(/\s+/g, '-')}`}
      onChange={(e) => {
        const d = new Date(e.target.value);
        if (!isNaN(d.getTime())) onSelectedDateChanged?.(d);
      }}
    />
  ),
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

/* ─── store factory ──────────────────────────────────────────────────────────── */

const DEFAULT_FILTERS: ActivityFilters = {
  port_arrival: true,
  port_departure: true,
  zone_entry: true,
  zone_exit: true,
  ais_gap: true,
  sts: true,
  discrepancy: true,
  psc: true,
};

function setupStore(
  overrides: {
    timelinePanelOpen?: boolean;
    filters?: ActivityFilters;
  } = {},
) {
  mockStoreState = {
    filters: overrides.filters ?? DEFAULT_FILTERS,
    toggleFilter: mockToggleFilter,
    timelinePanelOpen: overrides.timelinePanelOpen ?? false,
    setTimelinePanelOpen: mockSetTimelinePanelOpen,
  };
}

/* ─── default props ──────────────────────────────────────────────────────────── */

const defaultProps = {
  onDateRangeChange: vi.fn(),
  dateState: DEFAULT_TOOLBAR_DATE_STATE,
  onDateStateChange: vi.fn(),
};

/* ─── setup ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  mockPopOverOpen = false;
  mockPopOverClose = vi.fn();
  mockPopOverToggle = vi.fn();
  setupStore();
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('VesselActivityToolbar', () => {
  /* ── date range label ── */

  it('renders date range button with default label "Previous 30 days"', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    expect(screen.getByText('Previous 30 days')).toBeInTheDocument();
  });

  it('renders "Custom range" label when dateState.isCustom is true', () => {
    render(
      <VesselActivityToolbar
        {...defaultProps}
        dateState={{ ...DEFAULT_TOOLBAR_DATE_STATE, isCustom: true }}
      />,
    );
    expect(screen.getByText('Custom range')).toBeInTheDocument();
  });

  /* ── sidebar toggle ── */

  it('sidebar toggle button calls onToggleSidebar when clicked', () => {
    const onToggleSidebar = vi.fn();
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleSidebar={onToggleSidebar}
        sidebarOpen={false}
      />,
    );
    // Button uses aria-label, not title
    fireEvent.click(
      screen.getByRole('button', { name: 'Show Vessel Details' }),
    );
    expect(onToggleSidebar).toHaveBeenCalledTimes(1);
  });

  it('sidebar toggle aria-label reflects sidebarOpen=true', () => {
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleSidebar={vi.fn()}
        sidebarOpen={true}
      />,
    );
    expect(
      screen.getByRole('button', { name: 'Hide Vessel Details' }),
    ).toBeInTheDocument();
  });

  it('sidebar toggle aria-label reflects sidebarOpen=false', () => {
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleSidebar={vi.fn()}
        sidebarOpen={false}
      />,
    );
    expect(
      screen.getByRole('button', { name: 'Show Vessel Details' }),
    ).toBeInTheDocument();
  });

  it('does not render sidebar toggle when onToggleSidebar is not provided', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    expect(
      screen.queryByRole('button', { name: /vessel details/i }),
    ).not.toBeInTheDocument();
  });

  /* ── focus mode toggle ── */

  it('renders focus mode button when onToggleFocusMode is provided', () => {
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleFocusMode={vi.fn()}
        isInFocusMode={false}
      />,
    );
    expect(
      screen.getByRole('button', { name: 'Enter focus mode' }),
    ).toBeInTheDocument();
  });

  it('focus mode button shows exit label when isInFocusMode=true', () => {
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleFocusMode={vi.fn()}
        isInFocusMode={true}
      />,
    );
    expect(
      screen.getByRole('button', { name: 'Exit focus mode' }),
    ).toBeInTheDocument();
  });

  it('focus mode button calls onToggleFocusMode when clicked', () => {
    const onToggleFocusMode = vi.fn();
    render(
      <VesselActivityToolbar
        {...defaultProps}
        onToggleFocusMode={onToggleFocusMode}
        isInFocusMode={false}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: 'Enter focus mode' }));
    expect(onToggleFocusMode).toHaveBeenCalledTimes(1);
  });

  it('does not render focus mode button when onToggleFocusMode is not provided', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    expect(
      screen.queryByRole('button', { name: /focus mode/i }),
    ).not.toBeInTheDocument();
  });

  /* ── timeline toggle ── */

  it('timeline toggle button is rendered', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    // aria-label is now present on the timeline button
    expect(
      screen.getByRole('button', { name: 'Show Event Timeline' }),
    ).toBeInTheDocument();
  });

  it('timeline toggle aria-label reflects open state', () => {
    setupStore({ timelinePanelOpen: true });
    render(<VesselActivityToolbar {...defaultProps} />);
    expect(
      screen.getByRole('button', { name: 'Hide Event Timeline' }),
    ).toBeInTheDocument();
  });

  it('timeline toggle calls setTimelinePanelOpen(true) when panel is closed', () => {
    setupStore({ timelinePanelOpen: false });
    render(<VesselActivityToolbar {...defaultProps} />);
    fireEvent.click(
      screen.getByRole('button', { name: 'Show Event Timeline' }),
    );
    expect(mockSetTimelinePanelOpen).toHaveBeenCalledWith(true);
  });

  it('timeline toggle calls setTimelinePanelOpen(false) when panel is open', () => {
    setupStore({ timelinePanelOpen: true });
    render(<VesselActivityToolbar {...defaultProps} />);
    fireEvent.click(
      screen.getByRole('button', { name: 'Hide Event Timeline' }),
    );
    expect(mockSetTimelinePanelOpen).toHaveBeenCalledWith(false);
  });

  /* ── next port chip ── */

  it('does not render next port chip when position is null', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    expect(screen.queryByText(/ETA/i)).not.toBeInTheDocument();
  });
});

/* ─── popover / date picker ──────────────────────────────────────────────────── */

describe('VesselActivityToolbar — popover open', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockPopOverOpen = true;
    mockPopOverClose = vi.fn();
    mockPopOverToggle = vi.fn();
    setupStore();
  });

  afterEach(() => {
    mockPopOverOpen = false;
  });

  it('renders preset buttons inside the popover panel', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');
    for (const days of [7, 14, 30, 90]) {
      expect(
        within(panel).getByText(`Previous ${days} days`),
      ).toBeInTheDocument();
    }
  });

  it('renders "Custom range..." button inside the popover panel', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');
    expect(within(panel).getByText('Custom range...')).toBeInTheDocument();
  });

  it('"Custom range..." button toggles custom input section', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    expect(
      screen.queryByTestId('datepicker-start-date'),
    ).not.toBeInTheDocument();

    fireEvent.click(within(panel).getByText('Custom range...'));

    expect(screen.getByTestId('datepicker-start-date')).toBeInTheDocument();
    expect(screen.getByTestId('datepicker-end-date')).toBeInTheDocument();
  });

  it('Apply button is disabled when no dates are selected', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    fireEvent.click(within(panel).getByText('Custom range...'));

    expect(screen.getByRole('button', { name: /apply/i })).toBeDisabled();
  });

  it('Apply button is disabled when only start date is set', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    fireEvent.click(within(panel).getByText('Custom range...'));
    fireEvent.change(screen.getByTestId('datepicker-start-date'), {
      target: { value: '2025-01-01' },
    });

    expect(screen.getByRole('button', { name: /apply/i })).toBeDisabled();
  });

  it('Apply button is disabled when only end date is set', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    fireEvent.click(within(panel).getByText('Custom range...'));
    fireEvent.change(screen.getByTestId('datepicker-end-date'), {
      target: { value: '2025-06-01' },
    });

    expect(screen.getByRole('button', { name: /apply/i })).toBeDisabled();
  });

  it('Apply button is enabled when start <= end within two years', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    fireEvent.click(within(panel).getByText('Custom range...'));
    fireEvent.change(screen.getByTestId('datepicker-start-date'), {
      target: { value: '2025-01-01' },
    });
    fireEvent.change(screen.getByTestId('datepicker-end-date'), {
      target: { value: '2025-06-01' },
    });

    expect(screen.getByRole('button', { name: /apply/i })).not.toBeDisabled();
  });

  it('Apply button calls onDateRangeChange and onDateStateChange on valid submit', () => {
    const onDateRangeChange = vi.fn();
    const onDateStateChange = vi.fn();

    render(
      <VesselActivityToolbar
        {...defaultProps}
        onDateRangeChange={onDateRangeChange}
        onDateStateChange={onDateStateChange}
      />,
    );
    // Clear the mount useEffect call before interacting
    onDateRangeChange.mockClear();

    const panel = screen.getByTestId('popover-panel');
    fireEvent.click(within(panel).getByText('Custom range...'));
    fireEvent.change(screen.getByTestId('datepicker-start-date'), {
      target: { value: '2025-01-01' },
    });
    fireEvent.change(screen.getByTestId('datepicker-end-date'), {
      target: { value: '2025-06-01' },
    });
    fireEvent.click(screen.getByRole('button', { name: /apply/i }));

    expect(onDateRangeChange).toHaveBeenCalledTimes(1);
    const range = onDateRangeChange.mock.calls.at(-1)![0] as {
      start: string;
      end: string;
    };
    expect(range).toHaveProperty('start');
    expect(range).toHaveProperty('end');
    expect(range.start).toContain('2025-01-01');

    expect(onDateStateChange).toHaveBeenCalledWith(
      expect.objectContaining({ isCustom: true }),
    );
  });

  it('shows validation message when date range exceeds two years', () => {
    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');

    fireEvent.click(within(panel).getByText('Custom range...'));
    fireEvent.change(screen.getByTestId('datepicker-start-date'), {
      target: { value: '2024-06-10' },
    });
    fireEvent.change(screen.getByTestId('datepicker-end-date'), {
      target: { value: '2026-06-11' },
    });

    expect(
      screen.getByText(/date range cannot exceed two years/i),
    ).toBeInTheDocument();
  });
});

/* ─── preset selection ───────────────────────────────────────────────────────── */

describe('VesselActivityToolbar — preset selection', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockPopOverOpen = true;
    mockPopOverClose = vi.fn();
    mockPopOverToggle = vi.fn();
    setupStore();
  });

  afterEach(() => {
    mockPopOverOpen = false;
  });

  it.each([7, 14, 30, 90] as const)(
    'clicking "Previous %d days" calls onDateRangeChange with start/end',
    (days) => {
      const onDateRangeChange = vi.fn();
      render(
        <VesselActivityToolbar
          {...defaultProps}
          onDateRangeChange={onDateRangeChange}
        />,
      );

      const panel = screen.getByTestId('popover-panel');
      fireEvent.click(within(panel).getByText(`Previous ${days} days`));

      // Called at least twice: once on mount (useEffect) + once on click
      expect(onDateRangeChange).toHaveBeenCalled();
      const range = onDateRangeChange.mock.calls.at(-1)![0] as {
        start: string;
        end: string;
      };
      expect(range).toHaveProperty('start');
      expect(range).toHaveProperty('end');
    },
  );

  it.each([7, 14, 30, 90] as const)(
    'clicking "Previous %d days" calls onDateStateChange with isCustom: false',
    (days) => {
      const onDateStateChange = vi.fn();
      render(
        <VesselActivityToolbar
          {...defaultProps}
          onDateStateChange={onDateStateChange}
        />,
      );

      const panel = screen.getByTestId('popover-panel');
      fireEvent.click(within(panel).getByText(`Previous ${days} days`));

      expect(onDateStateChange).toHaveBeenCalledWith(
        expect.objectContaining({ prevDays: days, isCustom: false }),
      );
    },
  );

  it('clicking a preset closes the popover', () => {
    const close = vi.fn();
    mockPopOverClose = close;

    render(<VesselActivityToolbar {...defaultProps} />);
    const panel = screen.getByTestId('popover-panel');
    fireEvent.click(within(panel).getByText('Previous 7 days'));

    expect(close).toHaveBeenCalledTimes(1);
  });
});
