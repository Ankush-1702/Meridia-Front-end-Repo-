import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { VesselSearch } from '@/features/library/types/LibraryTypes';
import VesselSwitcher from '@/features/Vessels/ui/VesselSwitcher';
import type { Vessel } from '@/shared/types/entities';

/* ─── mocks ──────────────────────────────────────────────────────────────────── */

const mockNavigate = vi.fn();

vi.mock('react-router-dom', async (importOriginal) => {
  const original = await importOriginal<typeof import('react-router-dom')>();
  return {
    ...original,
    useNavigate: () => mockNavigate,
  };
});

const mockFetchBookmarks = vi.fn();
const mockVesselSearch = vi.fn();

vi.mock('@/features/library/services/libraryApi', () => ({
  fetchBookmarks: (...args: unknown[]) => mockFetchBookmarks(...args),
  vesselSearch: (...args: unknown[]) => mockVesselSearch(...args),
}));

const mockAddRecentVessel = vi.fn();
const mockGetRecentVessels = vi.fn();

vi.mock('@/features/Vessels/utils/recentVessels', () => ({
  addRecentVessel: (...args: unknown[]) => mockAddRecentVessel(...args),
  getRecentVessels: () => mockGetRecentVessels(),
}));

const mockResetActivityState = vi.fn();

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: Object.assign(vi.fn(), {
    getState: () => ({ resetActivityState: mockResetActivityState }),
  }),
}));

// useEscapeClose — call the callback when Escape is pressed
vi.mock('@/shared/hooks/useEscapeClose', () => ({
  useEscapeClose: (cb: () => void) => {
    // Register a global keydown listener to simulate the hook's behaviour
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') cb();
    };
    document.addEventListener('keydown', handler);
    // The hook would clean up on unmount — we can't do that here, but tests
    // that depend on this will call fireEvent.keyDown directly anyway.
    return handler;
  },
}));

// useDebounce — default passthrough; individual tests override via vi.useFakeTimers
vi.mock('@/shared/hooks/useDebounce', () => ({
  useDebounce: <T,>(value: T) => value,
}));

// Flowbite Spinner
vi.mock('flowbite-react', () => ({
  Spinner: () => <span data-testid="spinner" />,
}));

/* ─── test fixtures ──────────────────────────────────────────────────────────── */

function makeVessel(overrides: Partial<Vessel> = {}): Vessel {
  return {
    imo: '1234567',
    name: 'MV Test Vessel',
    mmsi: '123456789',
    type: 'Tanker',
    flag: { name: 'Norway', country_code: 'NOR', effective_date: null },
    draught: 10,
    asset_id: 'asset-1',
    callsign: null,
    ownership: {
      operator: '',
      registered_owner: '',
      technical_manager: '',
      ship_manager: '',
      group_beneficial_owner: '',
    },
    build_year: 2010,
    deadweight: 50000,
    dimensions: { length: 200, breadth: 30 },
    ...overrides,
  } as Vessel;
}

function makeVesselSearch(overrides: Partial<VesselSearch> = {}): VesselSearch {
  return {
    asset_id: 'asset-2',
    callsign: '',
    flag: 'Norway',
    flag_code: 'NO',
    imo: '9876543',
    mmsi: null,
    name: 'MV Search Result',
    vessel_type: 'Tanker',
    vessel_status: 'Active',
    ...overrides,
  };
}

/* ─── render helper ──────────────────────────────────────────────────────────── */

function renderSwitcher(vessel: Vessel = makeVessel()) {
  return render(
    <MemoryRouter>
      <VesselSwitcher vessel={vessel} />
    </MemoryRouter>,
  );
}

/* ─── setup ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  mockGetRecentVessels.mockReturnValue([]);
  mockFetchBookmarks.mockResolvedValue({ data: [] });
  mockVesselSearch.mockResolvedValue({ data: [] });
});

afterEach(() => {
  vi.useRealTimers();
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('VesselSwitcher', () => {
  it('renders vessel name button', () => {
    renderSwitcher();
    expect(screen.getByText('MV Test Vessel')).toBeInTheDocument();
  });

  it('opens dropdown on click', async () => {
    mockGetRecentVessels.mockReturnValue([]);
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() => {
      // The dropdown renders a search input
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument();
    });
  });

  it('closes dropdown when trigger is clicked again while open', async () => {
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument(),
    );

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.queryByPlaceholderText('Search vessels…'),
      ).not.toBeInTheDocument(),
    );
  });

  it('closes on Escape key via useEscapeClose hook', async () => {
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument(),
    );

    fireEvent.keyDown(document, { key: 'Escape' });

    await waitFor(() =>
      expect(
        screen.queryByPlaceholderText('Search vessels…'),
      ).not.toBeInTheDocument(),
    );
  });

  it('closes on Escape key inside the search input', async () => {
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument(),
    );

    const input = screen.getByPlaceholderText('Search vessels…');
    fireEvent.keyDown(input, { key: 'Escape' });

    await waitFor(() =>
      expect(
        screen.queryByPlaceholderText('Search vessels…'),
      ).not.toBeInTheDocument(),
    );
  });

  it('shows Recent tab by default when opened', async () => {
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() => expect(screen.getByText('Recent')).toBeInTheDocument());

    expect(screen.getByText('Library')).toBeInTheDocument();

    // The Recent tab should be the one that is "active" (has underline styling)
    // We confirm by checking the placeholder which changes based on active tab
    expect(screen.getByPlaceholderText('Search vessels…')).toBeInTheDocument();
  });

  it('Library tab click triggers saved vessels fetch (fetchBookmarks called)', async () => {
    mockFetchBookmarks.mockResolvedValue({ data: [] });

    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(screen.getByText('Library')).toBeInTheDocument(),
    );

    fireEvent.mouseDown(screen.getByText('Library'));

    await waitFor(() =>
      expect(mockFetchBookmarks).toHaveBeenCalledWith(500, 0),
    );
  });

  it('does not re-fetch saved vessels if already fetched (Library tab clicked twice)', async () => {
    mockFetchBookmarks.mockResolvedValue({ data: [] });

    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));
    await waitFor(() =>
      expect(screen.getByText('Library')).toBeInTheDocument(),
    );

    // First Library click
    fireEvent.mouseDown(screen.getByText('Library'));
    await waitFor(() => expect(mockFetchBookmarks).toHaveBeenCalledTimes(1));

    // Switch back to Recent
    fireEvent.mouseDown(screen.getByText('Recent'));

    // Second Library click — should not call fetchBookmarks again
    fireEvent.mouseDown(screen.getByText('Library'));

    // Give a tick for any async operations
    await act(async () => {
      await Promise.resolve();
    });

    expect(mockFetchBookmarks).toHaveBeenCalledTimes(1);
  });

  it('search fires when input is >= 2 chars and does not fire for < 2 chars', async () => {
    renderSwitcher();
    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument(),
    );

    const input = screen.getByPlaceholderText('Search vessels…');

    // 1 char — below threshold, should not trigger search
    fireEvent.change(input, { target: { value: 'M' } });
    expect(mockVesselSearch).not.toHaveBeenCalled();

    // 2 chars — at threshold, should trigger search (debounce is passthrough in tests)
    fireEvent.change(input, { target: { value: 'MV' } });
    await waitFor(() =>
      expect(mockVesselSearch).toHaveBeenCalledWith(
        'MV',
        'nameOrImo',
        expect.anything(),
        20,
        0,
      ),
    );
  });

  it('selecting a vessel calls navigate and addRecentVessel', async () => {
    const vesselResult = makeVesselSearch({ imo: '9999999', name: 'MV Found' });

    // Seed recent list with one result
    mockGetRecentVessels.mockReturnValue([vesselResult]);

    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(screen.getByText('MV Found')).toBeInTheDocument(),
    );

    // VesselOption uses onMouseDown
    fireEvent.mouseDown(screen.getByText('MV Found'));

    expect(mockAddRecentVessel).toHaveBeenCalledWith(vesselResult);
    expect(mockResetActivityState).toHaveBeenCalled();
    expect(mockNavigate).toHaveBeenCalledWith('/analytics/vessel/9999999');
  });

  it('shows empty recent message when no recent vessels', async () => {
    mockGetRecentVessels.mockReturnValue([]);
    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(
        screen.getByPlaceholderText('Search vessels…'),
      ).toBeInTheDocument(),
    );

    // Dropdown is open; no vessel list items visible under Recent tab
    expect(screen.queryByText('MV Search Result')).not.toBeInTheDocument();
  });

  it('renders recent vessels when getRecentVessels returns data', async () => {
    const recentVessel = makeVesselSearch({
      imo: '1111111',
      name: 'MV Recent Ship',
    });
    mockGetRecentVessels.mockReturnValue([recentVessel]);

    renderSwitcher();

    fireEvent.click(screen.getByText('MV Test Vessel'));

    await waitFor(() =>
      expect(screen.getByText('MV Recent Ship')).toBeInTheDocument(),
    );
  });
});
