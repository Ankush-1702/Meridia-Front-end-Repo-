import { render, screen, fireEvent, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { usePtracScreening } from '@/features/Vessels/hooks/usePtracScreening';
import PtracScreeningSection from '@/features/Vessels/ui/PtracScreeningSection';

vi.mock('@/features/Vessels/hooks/usePtracScreening', () => ({
  usePtracScreening: vi.fn(),
}));

const mockedUsePtracScreening = vi.mocked(usePtracScreening);

beforeEach(() => {
  vi.clearAllMocks();
});

afterEach(() => {
  vi.useRealTimers();
});

describe('PtracScreeningSection', () => {
  it('shows the locked state when the user lacks access', () => {
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: false,
      error: null,
      startedAt: null,
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={false} />);

    expect(screen.getByText('Unlock PurpleTRAC Screening')).toBeInTheDocument();
    expect(mockedUsePtracScreening).toHaveBeenCalledWith('');
  });

  it('shows the loading state instead of a bare success card when status is not yet known', () => {
    // Mirrors the brief window before the hook's effect has started a
    // session (or reused a shared one): loading hasn't flipped to true
    // yet, but there's no result and no error either.
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: false,
      error: null,
      startedAt: null,
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(screen.getByRole('status')).toBeInTheDocument();
    expect(screen.queryByText('Overall')).not.toBeInTheDocument();
    expect(
      screen.queryByText('Get the full breakdown'),
    ).not.toBeInTheDocument();
  });

  it('shows "Screening in progress..." shortly after starting', () => {
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: true,
      error: null,
      startedAt: Date.now(),
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(screen.getByRole('status')).toBeInTheDocument();
    expect(screen.getByText('Screening in progress...')).toBeInTheDocument();
    expect(
      screen.getByRole('link', { name: /More about PurpleTRAC/i }),
    ).toBeInTheDocument();
    expect(mockedUsePtracScreening).toHaveBeenCalledWith('1234567');
  });

  it('rotates through PurpleTRAC-related loading messages while waiting', () => {
    vi.useFakeTimers();
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: true,
      error: null,
      startedAt: Date.now(),
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(screen.getByText('Screening in progress...')).toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(2_500);
    });
    expect(
      screen.getByText('Checking sanctions watchlists...'),
    ).toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(2_500);
    });
    expect(
      screen.getByText('Reviewing port state control history...'),
    ).toBeInTheDocument();
  });

  it('shows the long-wait message once 7 seconds have elapsed', () => {
    vi.useFakeTimers();
    const startedAt = Date.now();
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: true,
      error: null,
      startedAt,
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(
      screen.queryByText(/You can leave this page/),
    ).not.toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(7_000);
    });

    expect(
      screen.getByText('You can leave this page - results will be saved.'),
    ).toBeInTheDocument();
  });

  it('shows the long-wait message immediately if reopened after 7 seconds have already passed', () => {
    const startedAt = Date.now() - 8_000;
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: true,
      error: null,
      startedAt,
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(
      screen.getByText('You can leave this page - results will be saved.'),
    ).toBeInTheDocument();
  });

  it('shows an error state with a retry action when the screening fails', () => {
    const retry = vi.fn();
    mockedUsePtracScreening.mockReturnValue({
      status: null,
      loading: false,
      error: new Error('boom'),
      startedAt: null,
      retry,
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(
      screen.getByText('PurpleTRAC screening is temporarily unavailable.'),
    ).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Retry' }));
    expect(retry).toHaveBeenCalled();
  });

  it('shows the overall status once the screening result is available', () => {
    mockedUsePtracScreening.mockReturnValue({
      status: 'OK',
      loading: false,
      error: null,
      startedAt: null,
      retry: vi.fn(),
    });

    render(<PtracScreeningSection imo="1234567" hasAccess={true} />);

    expect(screen.getByText('Overall')).toBeInTheDocument();
    expect(screen.getByText('Ok')).toBeInTheDocument();
    expect(screen.getByText('Get the full breakdown')).toBeInTheDocument();
  });
});
