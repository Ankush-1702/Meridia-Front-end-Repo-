import { render, waitFor, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import VesselEventsTab from '@/features/Vessels/ui/VesselEventsTab';

/* ---------------- mocks ---------------- */

const mockNavigate = vi.fn();
vi.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

const mockFetchVesselPortCalls = vi.fn();
const mockFetchVesselZoneEvents = vi.fn();
const mockFetchVesselAISGaps = vi.fn();
const mockFetchVesselSTSPairings = vi.fn();
const mockFetchVesselPositionalDiscrepancies = vi.fn();
const mockFetchVesselPortStateControl = vi.fn();

vi.mock('@/features/Vessels/services/vesselServices', () => ({
  fetchVesselPortCalls: (...args: unknown[]) =>
    mockFetchVesselPortCalls(...args),
  fetchVesselZoneEvents: (...args: unknown[]) =>
    mockFetchVesselZoneEvents(...args),
  fetchVesselAISGaps: (...args: unknown[]) => mockFetchVesselAISGaps(...args),
  fetchVesselSTSPairings: (...args: unknown[]) =>
    mockFetchVesselSTSPairings(...args),
  fetchVesselPositionalDiscrepancies: (...args: unknown[]) =>
    mockFetchVesselPositionalDiscrepancies(...args),
  fetchVesselPortStateControl: (...args: unknown[]) =>
    mockFetchVesselPortStateControl(...args),
}));

const mockVesselEventsPanel = vi.fn();
vi.mock('@/features/Vessels/ui/VesselEventsPanel', () => ({
  VesselEventsPanel: (props: Record<string, unknown>) => {
    mockVesselEventsPanel(props);
    return <div>VesselEventsPanel</div>;
  },
}));

vi.mock('@/shared/utils/logger', () => ({
  logger: { error: vi.fn(), warn: vi.fn(), info: vi.fn() },
}));

/* ---------------- helpers ---------------- */

const vesselEventsTabs = [
  { label: 'Port Call', value: 'PORT_CALLS' },
  { label: 'Zone Events', value: 'ZONE_EVENTS' },
  { label: 'AIS Gap', value: 'AIS_GAPS' },
  { label: 'STS Pairing', value: 'STS_PAIRINGS' },
  { label: 'Positional Discrepancy', value: 'POSITIONAL_DISCREPANCIES' },
  { label: 'Port State Control', value: 'PORT_STATE_CONTROL' },
];

function emptyResult() {
  return { data: [], totalCount: 0 };
}

function portCallEvent(overrides: Record<string, unknown> = {}) {
  return {
    imo: '123',
    name: 'Vessel A',
    event_details: {
      event_type: 'PORT_ARRIVAL',
      event_timestamp: '2024-01-02T00:00:00Z',
    },
    zone_information: { id: 'port-1', unlocode: 'NOOSL' },
    ...overrides,
  };
}

function zoneEvent(overrides: Record<string, unknown> = {}) {
  return {
    imo: '123',
    name: 'Vessel A',
    event_details: {
      event_type: 'ZONE_ENTRY',
      event_timestamp: '2024-01-03T00:00:00Z',
    },
    zone_information: { id: 'zone-1', unlocode: '' },
    ...overrides,
  };
}

function defaultProps(overrides: Record<string, unknown> = {}) {
  return {
    vesselId: 'vessel-1',
    vesselName: 'Test Vessel',
    refresh: false,
    setRefresh: vi.fn(),
    dateRange: { start: '2024-01-01', end: '2024-01-31' },
    onDateRangeChange: vi.fn(),
    activeEventsTab: 'PORT_CALLS',
    setActiveEventsTab: vi.fn(),
    vesselEventsTabs,
    ...overrides,
  };
}

/* ---------------- setup ---------------- */

beforeEach(() => {
  vi.clearAllMocks();

  mockFetchVesselPortCalls.mockResolvedValue(emptyResult());
  mockFetchVesselZoneEvents.mockResolvedValue(emptyResult());
  mockFetchVesselAISGaps.mockResolvedValue(emptyResult());
  mockFetchVesselSTSPairings.mockResolvedValue(emptyResult());
  mockFetchVesselPositionalDiscrepancies.mockResolvedValue(emptyResult());
  mockFetchVesselPortStateControl.mockResolvedValue(emptyResult());
});

afterEach(() => {
  vi.useRealTimers();
});

/* ---------------- tests ---------------- */

describe('VesselEventsTab', () => {
  it('fetches all 6 event categories in parallel on mount', async () => {
    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => {
      expect(mockFetchVesselPortCalls).toHaveBeenCalledTimes(1);
    });

    expect(mockFetchVesselZoneEvents).toHaveBeenCalledTimes(1);
    expect(mockFetchVesselAISGaps).toHaveBeenCalledTimes(1);
    expect(mockFetchVesselSTSPairings).toHaveBeenCalledTimes(1);
    expect(mockFetchVesselPositionalDiscrepancies).toHaveBeenCalledTimes(1);
    expect(mockFetchVesselPortStateControl).toHaveBeenCalledTimes(1);

    expect(mockFetchVesselPortCalls).toHaveBeenCalledWith(
      'vessel-1',
      expect.any(String),
      expect.any(String),
      0,
      500,
    );
  });

  it('merges successful results and still renders when some categories fail', async () => {
    mockFetchVesselPortCalls.mockResolvedValueOnce({
      data: [portCallEvent()],
      totalCount: 1,
    });
    mockFetchVesselZoneEvents.mockRejectedValueOnce(new Error('zone failed'));

    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => {
      const lastCall =
        mockVesselEventsPanel.mock.calls[
          mockVesselEventsPanel.mock.calls.length - 1
        ][0];
      expect(lastCall.rows.length).toBeGreaterThan(0);
    });

    const logger = (await import('@/shared/utils/logger')).logger;
    expect(logger.error).toHaveBeenCalledWith(
      'Failed to fetch zone events',
      expect.any(Error),
    );
  });

  it('filters cached rows by TAB_EVENT_TYPES when the tab selection changes', async () => {
    mockFetchVesselPortCalls.mockResolvedValueOnce({
      data: [portCallEvent()],
      totalCount: 1,
    });
    mockFetchVesselZoneEvents.mockResolvedValueOnce({
      data: [zoneEvent()],
      totalCount: 1,
    });

    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => {
      const lastCall =
        mockVesselEventsPanel.mock.calls[
          mockVesselEventsPanel.mock.calls.length - 1
        ][0];
      expect(lastCall.rows.length).toBeGreaterThan(0);
    });

    // Grab onToggle from the latest render and deselect PORT_CALLS
    const lastProps =
      mockVesselEventsPanel.mock.calls[
        mockVesselEventsPanel.mock.calls.length - 1
      ][0];

    act(() => {
      lastProps.onToggle('PORT_CALLS', false);
    });

    await waitFor(() => {
      const latest =
        mockVesselEventsPanel.mock.calls[
          mockVesselEventsPanel.mock.calls.length - 1
        ][0];
      const eventTypes = latest.rows.map(
        (r: { eventType: string }) => r.eventType,
      );
      expect(eventTypes).not.toContain('PORT_ARRIVAL');
      expect(eventTypes).toContain('ZONE_ENTRY');
    });
  });

  it('re-fetches when refresh becomes true and resets refresh afterward', async () => {
    const setRefresh = vi.fn();
    const { rerender } = render(
      <VesselEventsTab {...defaultProps({ refresh: false, setRefresh })} />,
    );

    await waitFor(() => {
      expect(mockFetchVesselPortCalls).toHaveBeenCalledTimes(1);
    });

    rerender(
      <VesselEventsTab {...defaultProps({ refresh: true, setRefresh })} />,
    );

    await waitFor(() => {
      expect(mockFetchVesselPortCalls).toHaveBeenCalledTimes(2);
    });

    await waitFor(() => {
      expect(setRefresh).toHaveBeenCalledWith(false);
    });
  });

  it('auto-refreshes every 5 minutes', async () => {
    vi.useFakeTimers();

    render(<VesselEventsTab {...defaultProps()} />);

    await act(async () => {
      await Promise.resolve();
    });
    expect(mockFetchVesselPortCalls).toHaveBeenCalledTimes(1);

    await act(async () => {
      await vi.advanceTimersByTimeAsync(5 * 60 * 1000);
    });

    expect(mockFetchVesselPortCalls).toHaveBeenCalledTimes(2);
  });

  it('navigates to the zone analytics route for zone events on row click', async () => {
    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => expect(mockVesselEventsPanel).toHaveBeenCalled());

    const { onRowClick } =
      mockVesselEventsPanel.mock.calls[
        mockVesselEventsPanel.mock.calls.length - 1
      ][0];

    onRowClick({ zoneId: 'zone-1', eventType: 'ZONE_ENTRY' });

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/zone/zone-1');
  });

  it('navigates to the port analytics route for port events on row click', async () => {
    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => expect(mockVesselEventsPanel).toHaveBeenCalled());

    const { onRowClick } =
      mockVesselEventsPanel.mock.calls[
        mockVesselEventsPanel.mock.calls.length - 1
      ][0];

    onRowClick({ zoneId: 'port-1', eventType: 'PORT_ARRIVAL' });

    expect(mockNavigate).toHaveBeenCalledWith('/analytics/port/port-1');
  });

  it('does not navigate when the row has no zoneId', async () => {
    render(<VesselEventsTab {...defaultProps()} />);

    await waitFor(() => expect(mockVesselEventsPanel).toHaveBeenCalled());

    const { onRowClick } =
      mockVesselEventsPanel.mock.calls[
        mockVesselEventsPanel.mock.calls.length - 1
      ][0];

    onRowClick({ eventType: 'PORT_ARRIVAL' });

    expect(mockNavigate).not.toHaveBeenCalled();
  });
});
