import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { ActivityEvent } from '@/features/Vessels/types/vesselActivityTypes';

/* ─── mocks (before component import) ───────────────────────────────────────── */

const mockSetReplayAnnouncedEvent = vi.fn();
const mockSetReplayCountdownPaused = vi.fn();

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: vi.fn((selector: (s: unknown) => unknown) =>
    mockStoreSelector(selector),
  ),
}));

vi.mock('flowbite-react', () => ({
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock('@/features/Vessels/utils/vesselActivityFormatters', () => ({
  fmtEventType: (subType: string) =>
    subType.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
  fmtHHMM: (iso: string) => {
    const d = new Date(iso);
    return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
  },
}));

/* ─── component import (after mocks) ────────────────────────────────────────── */

import ReplayEventOverlay from '@/features/Vessels/ui/ReplayEventOverlay';

/* ─── store state ────────────────────────────────────────────────────────────── */

interface MockStoreState {
  replayAnnouncedEvent: ActivityEvent[] | null;
  replayCountdownPaused: boolean;
  setReplayAnnouncedEvent: typeof mockSetReplayAnnouncedEvent;
  setReplayCountdownPaused: typeof mockSetReplayCountdownPaused;
}

let _mockState: MockStoreState = {
  replayAnnouncedEvent: null,
  replayCountdownPaused: false,
  setReplayAnnouncedEvent: mockSetReplayAnnouncedEvent,
  setReplayCountdownPaused: mockSetReplayCountdownPaused,
};

function mockStoreSelector(selector: (s: MockStoreState) => unknown): unknown {
  return selector(_mockState);
}

function setupStore(overrides: Partial<MockStoreState> = {}) {
  _mockState = {
    replayAnnouncedEvent: null,
    replayCountdownPaused: false,
    setReplayAnnouncedEvent: mockSetReplayAnnouncedEvent,
    setReplayCountdownPaused: mockSetReplayCountdownPaused,
    ...overrides,
  };
}

/* ─── event factory ──────────────────────────────────────────────────────────── */

function buildEvent(overrides: Partial<ActivityEvent> = {}): ActivityEvent {
  return {
    id: 'evt-001',
    category: 'port',
    subType: 'port_call',
    startTime: '2024-01-15T10:30:00Z',
    endTime: null,
    latitude: 51.9,
    longitude: 4.5,
    label: 'Rotterdam',
    raw: null,
    ...overrides,
  };
}

/* ─── setup ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  setupStore();
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('ReplayEventOverlay', () => {
  it('renders nothing when replayAnnouncedEvent is null', () => {
    setupStore({ replayAnnouncedEvent: null });
    const { container } = render(<ReplayEventOverlay />);
    expect(container.firstChild).toBeNull();
  });

  it('renders nothing when replayAnnouncedEvent is empty array', () => {
    setupStore({ replayAnnouncedEvent: [] });
    const { container } = render(<ReplayEventOverlay />);
    expect(container.firstChild).toBeNull();
  });

  it('renders event card when replayAnnouncedEvent has one event', () => {
    const event = buildEvent({ id: 'evt-001', label: 'Rotterdam' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    expect(screen.getAllByText('Rotterdam').length).toBeGreaterThan(0);
  });

  it('shows single event subType as header label (formatted)', () => {
    const event = buildEvent({ subType: 'port_call' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    // fmtEventType('port_call') -> 'Port Call'
    expect(screen.getAllByText('Port Call').length).toBeGreaterThan(0);
  });

  it('shows category label in header when subType is empty', () => {
    const event = buildEvent({ subType: '' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    // CATEGORY_META['port'].label = 'Port' — appears in header and event row
    expect(screen.getAllByText('Port').length).toBeGreaterThan(0);
  });

  it('shows "{N} events" as header label when multiple events', () => {
    const events = [
      buildEvent({ id: 'evt-001' }),
      buildEvent({ id: 'evt-002', category: 'zone', label: 'Strait' }),
    ];
    setupStore({ replayAnnouncedEvent: events });

    render(<ReplayEventOverlay />);

    expect(screen.getByText('2 events')).toBeInTheDocument();
  });

  it('dismiss button calls setReplayAnnouncedEvent(null)', () => {
    const event = buildEvent();
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    fireEvent.click(screen.getByRole('button', { name: 'Dismiss' }));
    expect(mockSetReplayAnnouncedEvent).toHaveBeenCalledWith(null);
  });

  it('pause button calls setReplayCountdownPaused(true) when not paused', () => {
    const event = buildEvent();
    setupStore({
      replayAnnouncedEvent: [event],
      replayCountdownPaused: false,
    });

    render(<ReplayEventOverlay />);

    fireEvent.click(screen.getByRole('button', { name: 'Pause countdown' }));
    expect(mockSetReplayCountdownPaused).toHaveBeenCalledWith(true);
  });

  it('resume button calls setReplayCountdownPaused(false) when already paused', () => {
    const event = buildEvent();
    setupStore({
      replayAnnouncedEvent: [event],
      replayCountdownPaused: true,
    });

    render(<ReplayEventOverlay />);

    fireEvent.click(screen.getByRole('button', { name: 'Resume countdown' }));
    expect(mockSetReplayCountdownPaused).toHaveBeenCalledWith(false);
  });

  it('event rows show UTC time (HH:MM format)', () => {
    const event = buildEvent({ startTime: '2024-01-15T10:30:00Z' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    // fmtHHMM mock returns "10:30"
    expect(screen.getByText('10:30')).toBeInTheDocument();
  });

  it('event rows show event label', () => {
    const event = buildEvent({ label: 'Port of Rotterdam' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    // Label appears in both the header subtext and the event row
    expect(screen.getAllByText('Port of Rotterdam').length).toBeGreaterThan(0);
  });

  it('countdown bar container exists in DOM', () => {
    const event = buildEvent();
    setupStore({ replayAnnouncedEvent: [event] });

    const { container } = render(<ReplayEventOverlay />);

    // The countdown bar wrapper has class h-1
    const countdownWrapper = container.querySelector('.h-1');
    expect(countdownWrapper).toBeInTheDocument();
  });

  it('shows group subtext (event label) for single event', () => {
    const event = buildEvent({ label: 'Rotterdam' });
    setupStore({ replayAnnouncedEvent: [event] });

    render(<ReplayEventOverlay />);

    // The subtext span renders the label below the header
    const allRotterdams = screen.getAllByText('Rotterdam');
    // Should appear at least twice: once in header subtext, once in event row
    expect(allRotterdams.length).toBeGreaterThanOrEqual(2);
  });
});
