import { render } from '@testing-library/react';
import { ColDef } from 'ag-grid-enterprise';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { FlatVesselEventsResponse } from '@/features/Vessels/types/vesselTypes';
import { VesselEventsPanel } from '@/features/Vessels/ui/VesselEventsPanel';

/* ---------------- mocks ---------------- */

const mockNewEventsPanel = vi.fn();

vi.mock('@/shared/ui/NewEventsPanel', () => ({
  default: (props: Record<string, unknown>) => {
    mockNewEventsPanel(props);
    return <div>NewEventsPanel</div>;
  },
}));

/* ---------------- setup ---------------- */

beforeEach(() => {
  vi.clearAllMocks();
});

/* ---------------- tests ---------------- */

describe('VesselEventsPanel', () => {
  const cols: ColDef[] = [{ field: 'eventTimestamp' }];
  const buildColumns = vi.fn().mockReturnValue(cols);
  const onToggle = vi.fn();
  const onSelectAll = vi.fn();
  const setRefresh = vi.fn();
  const onRowClick = vi.fn();
  const lastUpdated = new Date('2024-01-01T00:00:00Z');

  const baseProps = {
    vesselName: 'Test Vessel',
    vesselId: 'vessel-1',
    vesselEventsTabs: [
      { label: 'Port Call', value: 'PORT_CALLS' },
      { label: 'Zone Events', value: 'ZONE_EVENTS' },
    ],
    refresh: false,
    setRefresh,
    selected: { PORT_CALLS: true, ZONE_EVENTS: false },
    onToggle,
    onSelectAll,
    rows: [{ eventType: 'PORT_ARRIVAL' }] as FlatVesselEventsResponse[],
    buildColumns,
    storageKey: 'vessel-events',
    lastUpdated,
    isLoading: false,
    onRowClick,
  };

  it('forwards all props to NewEventsPanel', () => {
    render(<VesselEventsPanel {...baseProps} />);

    expect(mockNewEventsPanel).toHaveBeenCalledTimes(1);
    const props = mockNewEventsPanel.mock.calls[0][0];

    expect(props.eventsTabs).toEqual(baseProps.vesselEventsTabs);
    expect(props.selected).toEqual(baseProps.selected);
    expect(props.onToggle).toBe(onToggle);
    expect(props.onSelectAll).toBe(onSelectAll);
    expect(props.rows).toEqual(baseProps.rows);
    expect(props.refresh).toBe(false);
    expect(props.setRefresh).toBe(setRefresh);
    expect(props.buildColumns).toBe(buildColumns);
    expect(props.storageKey).toBe('vessel-events');
    expect(props.lastUpdated).toBe(lastUpdated);
    expect(props.isLoading).toBe(false);
    expect(props.onRowClick).toBe(onRowClick);
  });

  it('invokes buildColumns via NewEventsPanel prop', () => {
    render(<VesselEventsPanel {...baseProps} />);

    const props = mockNewEventsPanel.mock.calls[0][0];
    expect(props.buildColumns('utc')).toBe(cols);
    expect(buildColumns).toHaveBeenCalledWith('utc');
  });
});
