import { describe, it, expect } from 'vitest';
import type { ActivityEvent } from '@/features/Vessels/types/vesselActivityTypes';
import {
  buildRowsAndBars,
  buildSpanEvents,
  formatDuration,
  formatDurationShort,
  getBarReplayState,
  getTicks,
  CATEGORY_ORDER,
  SIDEBAR_W,
  LANE_ROW_H,
  GROUP_HEADER_H,
} from '@/features/Vessels/ui/ganttTimelineHelpers';

/**
 * VesselGanttTimeline is a heavy canvas-like component — rendering it in jsdom
 * produces no meaningful assertions. These tests cover the pure helper functions
 * that drive all Gantt layout, bar placement, and row grouping.
 */

function makeEvent(overrides: Partial<ActivityEvent> = {}): ActivityEvent {
  return {
    id: 'evt-1',
    category: 'port',
    subType: 'PORT_ARRIVAL',
    startTime: '2024-01-10T08:00:00Z',
    endTime: '2024-01-11T10:00:00Z',
    latitude: 51.9,
    longitude: 4.5,
    label: 'Rotterdam',
    raw: null,
    ...overrides,
  };
}

const ALL_FILTERS = {
  port_arrival: true,
  port_departure: true,
  zone_entry: true,
  zone_exit: true,
  ais_gap: true,
  sts: true,
  discrepancy: true,
  psc: true,
};

describe('ganttTimelineHelpers', () => {
  describe('formatDuration', () => {
    it('formats minutes only', () => {
      expect(formatDuration(30 * 60_000)).toBe('30m');
    });
    it('formats hours only', () => {
      expect(formatDuration(2 * 3600_000)).toBe('2h');
    });
    it('formats hours and minutes', () => {
      expect(formatDuration(2 * 3600_000 + 15 * 60_000)).toBe('2h 15m');
    });
    it('returns "0m" for sub-minute durations (rounds down to 0 minutes)', () => {
      expect(formatDuration(10_000)).toBe('0m');
    });
  });

  describe('formatDurationShort', () => {
    it('formats short minutes', () => {
      expect(formatDurationShort(45 * 60_000)).toBe('45m');
    });
    it('formats hours with decimal', () => {
      expect(formatDurationShort(2.5 * 3600_000)).toBe('2.5h');
    });
    it('formats days with decimal', () => {
      expect(formatDurationShort(36 * 3600_000)).toBe('1.5d');
    });
  });

  describe('getBarReplayState', () => {
    const cursor = new Date('2024-01-10T12:00:00Z').getTime();
    it('returns "future" when bar starts after cursor', () => {
      expect(getBarReplayState(cursor + 3600_000, null, cursor)).toBe('future');
    });
    it('returns "ended" when bar ends before cursor', () => {
      expect(
        getBarReplayState(cursor - 7200_000, cursor - 3600_000, cursor),
      ).toBe('ended');
    });
    it('returns "active" when cursor is within bar', () => {
      expect(
        getBarReplayState(cursor - 3600_000, cursor + 3600_000, cursor),
      ).toBe('active');
    });
  });

  describe('CATEGORY_ORDER', () => {
    it('contains all six event categories in expected order', () => {
      expect(CATEGORY_ORDER).toEqual([
        'port',
        'zone',
        'ais_gap',
        'sts',
        'discrepancy',
        'psc',
      ]);
    });
  });

  describe('constants', () => {
    it('SIDEBAR_W, LANE_ROW_H, GROUP_HEADER_H are positive numbers', () => {
      expect(SIDEBAR_W).toBeGreaterThan(0);
      expect(LANE_ROW_H).toBeGreaterThan(0);
      expect(GROUP_HEADER_H).toBeGreaterThan(0);
    });
  });

  describe('buildSpanEvents', () => {
    it('returns events unchanged when no paired arrival/departure exist', () => {
      const events = [makeEvent({ subType: 'PORT_CALL' })];
      const result = buildSpanEvents(events);
      expect(result).toHaveLength(1);
    });

    it('pairs PORT_ARRIVAL with PORT_DEPARTURE into a span', () => {
      const events = [
        makeEvent({
          id: 'a',
          subType: 'PORT_ARRIVAL',
          startTime: '2024-01-10T08:00:00Z',
          endTime: null,
          label: 'Rotterdam',
        }),
        makeEvent({
          id: 'b',
          subType: 'PORT_DEPARTURE',
          startTime: '2024-01-11T10:00:00Z',
          endTime: null,
          label: 'Rotterdam',
        }),
      ];
      const result = buildSpanEvents(events);
      expect(result).toHaveLength(1);
      expect(result[0].endTime).toBe('2024-01-11T10:00:00Z');
    });
  });

  describe('buildRowsAndBars', () => {
    it('returns empty rows and bars for no events', () => {
      const { rows, bars } = buildRowsAndBars([], ALL_FILTERS, 'by-event-type');
      expect(rows).toHaveLength(0);
      expect(bars).toHaveLength(0);
    });

    it('creates a row and bar for a port event in by-event-type mode', () => {
      const events = [makeEvent({ endTime: '2024-01-11T10:00:00Z' })];
      const { rows, bars } = buildRowsAndBars(
        events,
        ALL_FILTERS,
        'by-event-type',
      );
      expect(rows.length).toBeGreaterThan(0);
      expect(bars).toHaveLength(1);
    });

    it('skips categories when filter is false', () => {
      const events = [makeEvent()];
      const { bars } = buildRowsAndBars(
        events,
        { ...ALL_FILTERS, port_arrival: false, port_departure: false },
        'by-event-type',
      );
      expect(bars).toHaveLength(0);
    });

    it('groups by location in by-location mode', () => {
      const events = [
        makeEvent({ label: 'Rotterdam', endTime: '2024-01-11T10:00:00Z' }),
      ];
      const { rows } = buildRowsAndBars(events, ALL_FILTERS, 'by-location');
      const groupHeader = rows.find((r) => r.isGroupHeader);
      expect(groupHeader?.label).toBe('ROTTERDAM');
    });
  });

  describe('getTicks', () => {
    it('returns tick objects with ms and label', () => {
      const start = new Date('2024-01-01').getTime();
      const end = new Date('2024-01-08').getTime();
      const ticks = getTicks(start, end, 800);
      expect(ticks.length).toBeGreaterThan(0);
      expect(ticks[0]).toHaveProperty('ms');
      expect(ticks[0]).toHaveProperty('label');
    });
  });
});
