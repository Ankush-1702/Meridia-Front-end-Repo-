import { describe, it, expect } from 'vitest';
import {
  buildVesselMarkerHTML,
  buildPositionPopupHTML,
  buildMarkerHTML,
  createMarkerEl,
  updateMarkerEl,
  CATEGORY_ICON_PATHS,
  GAP_LAYER_ID,
  GAP_SOURCE_ID,
} from '@/features/Vessels/ui/vesselActivityMapUtils';

/**
 * VesselActivityMap is a Mapbox GL component — rendering it in jsdom is expensive
 * (1.5 MB mapbox-gl transform) and does not add meaningful coverage beyond what
 * the component's pure utility functions already cover.
 * These tests verify the utility layer that drives all map markers and popups.
 */
describe('vesselActivityMapUtils', () => {
  describe('buildVesselMarkerHTML', () => {
    it('returns an HTML string containing an SVG', () => {
      const html = buildVesselMarkerHTML(45);
      expect(html).toContain('<svg');
      expect(html).toContain('rotate(45deg)');
      expect(html).toContain('#ec6436');
    });

    it('applies 0 degree bearing correctly', () => {
      const html = buildVesselMarkerHTML(0);
      expect(html).toContain('rotate(0deg)');
    });
  });

  describe('buildPositionPopupHTML', () => {
    it('includes status when provided', () => {
      const html = buildPositionPopupHTML({
        timestamp: '2024-01-01T12:00:00Z',
        status: 'Under Way',
        speed: 5,
        course: 90,
        heading: 92,
      });
      expect(html).toContain('Under Way');
    });

    it('shows "Unknown status" when status is null', () => {
      const html = buildPositionPopupHTML({
        timestamp: '2024-01-01T12:00:00Z',
        status: null,
        speed: null,
        course: null,
        heading: null,
      });
      expect(html).toContain('Unknown status');
    });

    it('includes speed, course, heading rows when present', () => {
      const html = buildPositionPopupHTML({
        timestamp: '2024-01-01T00:00:00Z',
        status: null,
        speed: 12,
        course: 180,
        heading: 182,
      });
      expect(html).toContain('12 kn');
      expect(html).toContain('180°');
      expect(html).toContain('182°');
    });
  });

  describe('buildMarkerHTML', () => {
    it('returns highlighted HTML with larger outer ring when isHighlighted=true', () => {
      const html = buildMarkerHTML('port', '#0d9488', true);
      expect(html).toContain('42px');
    });

    it('returns normal-size HTML when isHighlighted=false', () => {
      const html = buildMarkerHTML('zone', '#2563eb', false);
      expect(html).toContain('22px');
    });

    it('uses fill="none" for psc icon (stroke-only)', () => {
      const html = buildMarkerHTML('psc', '#d97706', false);
      expect(html).toContain('fill="none"');
    });
  });

  describe('createMarkerEl', () => {
    it('creates a div with event-marker class', () => {
      const el = createMarkerEl('port', '#0d9488', false);
      expect(el.className).toContain('event-marker');
    });

    it('stores category and color as data attributes', () => {
      const el = createMarkerEl('ais_gap', '#ea580c', false);
      expect(el.dataset.category).toBe('ais_gap');
      expect(el.dataset.color).toBe('#ea580c');
    });
  });

  describe('updateMarkerEl', () => {
    it('updates the innerHTML of an existing marker element', () => {
      const el = createMarkerEl('port', '#0d9488', false);
      const htmlBefore = el.innerHTML;
      updateMarkerEl(el, true);
      expect(el.innerHTML).not.toBe(htmlBefore);
      expect(el.innerHTML).toContain('42px');
    });
  });

  describe('CATEGORY_ICON_PATHS', () => {
    it('has an entry for all six event categories', () => {
      const categories = [
        'port',
        'zone',
        'ais_gap',
        'sts',
        'discrepancy',
        'psc',
      ];
      categories.forEach((cat) => {
        expect(CATEGORY_ICON_PATHS).toHaveProperty(cat);
      });
    });
  });

  describe('constants', () => {
    it('GAP_LAYER_ID and GAP_SOURCE_ID are defined', () => {
      expect(typeof GAP_LAYER_ID).toBe('string');
      expect(typeof GAP_SOURCE_ID).toBe('string');
    });
  });
});
