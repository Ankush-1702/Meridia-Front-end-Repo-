import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { ActivityEvent } from '@/features/Vessels/types/vesselActivityTypes';

/* ─── store mock (must be before component import) ───────────────────────────── */

const mockSetHighlightedEventId = vi.fn();
const mockSetTimelinePanelOpen = vi.fn();
const mockStoreSelector = vi.fn();

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: (selector: (s: unknown) => unknown) =>
    mockStoreSelector(selector),
}));

vi.mock('flowbite-react', () => ({
  Spinner: () => <div data-testid="spinner" />,
  TextInput: ({
    value,
    onChange,
    placeholder,
  }: {
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    placeholder?: string;
  }) => (
    <input
      data-testid="search-input"
      value={value}
      onChange={onChange}
      placeholder={placeholder}
    />
  ),
  // Tooltip must be mocked so it doesn't try to resolve flowbite internals.
  // Render children transparently so surrounding tests are unaffected.
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock('@/features/Vessels/utils/vesselActivityFormatters', () => ({
  fmtDuration: (ms: number) => `${Math.round(ms / 60000)}m`,
  fmtEventType: (subType: string) =>
    subType.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
}));

/* ─── component import (after mocks) ────────────────────────────────────────── */

import VesselEventTimeline from '@/features/Vessels/ui/VesselEventTimeline';

/* ─── store state factory ────────────────────────────────────────────────────── */

interface StoreSlice {
  filters: Record<string, boolean>;
  replayAt: Date | null;
  highlightedEventId: string | null;
  setHighlightedEventId: typeof mockSetHighlightedEventId;
  setTimelinePanelOpen: typeof mockSetTimelinePanelOpen;
}

function buildStoreSlice(overrides: Partial<StoreSlice> = {}): StoreSlice {
  return {
    filters: {
      port_arrival: true,
      port_departure: true,
      zone_entry: true,
      zone_exit: true,
      ais_gap: true,
      sts: true,
      discrepancy: true,
      psc: true,
    },
    replayAt: null,
    highlightedEventId: null,
    setHighlightedEventId: mockSetHighlightedEventId,
    setTimelinePanelOpen: mockSetTimelinePanelOpen,
    ...overrides,
  };
}

function setupStore(state: StoreSlice) {
  mockStoreSelector.mockImplementation((selector: (s: StoreSlice) => unknown) =>
    selector(state),
  );
}

/* ─── event factory ──────────────────────────────────────────────────────────── */

function buildEvent(overrides: Partial<ActivityEvent> = {}): ActivityEvent {
  return {
    id: 'evt-001',
    category: 'port',
    subType: 'PORT_ARRIVAL',
    startTime: '2024-01-15T10:00:00Z',
    endTime: '2024-01-16T08:00:00Z',
    latitude: 51.9,
    longitude: 4.5,
    label: 'Rotterdam',
    raw: null,
    ...overrides,
  };
}

/* ─── setup ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  setupStore(buildStoreSlice());
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('VesselEventTimeline', () => {
  /* ── header ── */

  it('renders "Events Timeline" header', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);
    expect(screen.getByText('Events Timeline')).toBeInTheDocument();
  });

  /* ── loading state ── */

  it('shows spinner when loading is true', () => {
    render(<VesselEventTimeline events={[]} loading={true} />);
    expect(screen.getByTestId('spinner')).toBeInTheDocument();
  });

  it('does not show spinner when loading is false', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);
    expect(screen.queryByTestId('spinner')).not.toBeInTheDocument();
  });

  /* ── event count badge ── */

  it('shows event count badge when events are present', () => {
    const events = [
      buildEvent({ id: 'evt-001' }),
      buildEvent({ id: 'evt-002', label: 'Hamburg' }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);
    const badges = document.querySelectorAll('span.tabular-nums');
    const badgeTexts = Array.from(badges).map((b) => b.textContent);
    expect(badgeTexts).toContain('2');
  });

  it('does not show count badge when loading is true', () => {
    const events = [buildEvent()];
    render(<VesselEventTimeline events={events} loading={true} />);
    expect(screen.queryByText('1')).not.toBeInTheDocument();
  });

  /* ── search ── */

  it('renders search input', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);
    expect(screen.getByTestId('search-input')).toBeInTheDocument();
  });

  it('filters events by label search term', () => {
    const events = [
      buildEvent({ id: 'evt-001', label: 'Rotterdam' }),
      buildEvent({ id: 'evt-002', label: 'Hamburg' }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    fireEvent.change(screen.getByTestId('search-input'), {
      target: { value: 'Rotterdam' },
    });

    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
    expect(screen.queryByText('Hamburg')).not.toBeInTheDocument();
  });

  it('filters events by subType search term', () => {
    const events = [
      buildEvent({
        id: 'evt-001',
        subType: 'PORT_ARRIVAL',
        label: 'Rotterdam',
      }),
      buildEvent({
        id: 'evt-002',
        subType: 'PORT_DEPARTURE',
        label: 'Hamburg',
      }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    fireEvent.change(screen.getByTestId('search-input'), {
      target: { value: 'PORT DEPARTURE' },
    });

    // fmtEventType('ais_gap') === 'Ais Gap'
    expect(screen.getByText('PORT DEPARTURE')).toBeInTheDocument();
    expect(screen.queryByText('Port Call')).not.toBeInTheDocument();
  });

  it('shows "No matching events" when search has no results', () => {
    const events = [buildEvent({ label: 'Rotterdam' })];
    render(<VesselEventTimeline events={events} loading={false} />);

    fireEvent.change(screen.getByTestId('search-input'), {
      target: { value: 'XYZ_NO_MATCH' },
    });

    expect(screen.getByText('No matching events')).toBeInTheDocument();
  });

  it('shows "No events in selected range" when empty with no search', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);
    expect(screen.getByText('No events in selected range')).toBeInTheDocument();
  });

  /* ── header controls ── */

  it('close button calls setTimelinePanelOpen(false)', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);
    fireEvent.click(
      screen.getByRole('button', { name: 'Hide event timeline' }),
    );
    expect(mockSetTimelinePanelOpen).toHaveBeenCalledWith(false);
  });

  it('sort button toggles aria-label from "Switch to oldest first" to "Switch to newest first"', () => {
    render(<VesselEventTimeline events={[]} loading={false} />);

    const sortBtn = screen.getByRole('button', {
      name: 'Switch to oldest first',
    });
    expect(sortBtn).toBeInTheDocument();

    fireEvent.click(sortBtn);

    expect(
      screen.getByRole('button', { name: 'Switch to newest first' }),
    ).toBeInTheDocument();
  });

  /* ── day-group collapse / expand ── */

  it('day header button is rendered with aria-expanded="true" by default', () => {
    const events = [buildEvent()];
    render(<VesselEventTimeline events={events} loading={false} />);

    const dayBtn = screen.getByRole('button', { name: /Jan 2024/i });
    expect(dayBtn).toHaveAttribute('aria-expanded', 'true');
  });

  it('clicking a day header collapses its events', () => {
    const events = [buildEvent({ id: 'evt-001', label: 'Rotterdam' })];
    render(<VesselEventTimeline events={events} loading={false} />);

    expect(screen.getByText('Rotterdam')).toBeInTheDocument();

    const dayBtn = screen.getByRole('button', { name: /Jan 2024/i });
    fireEvent.click(dayBtn);

    expect(screen.queryByText('Rotterdam')).not.toBeInTheDocument();
    expect(dayBtn).toHaveAttribute('aria-expanded', 'false');
  });

  it('clicking a collapsed day header expands its events again', () => {
    const events = [buildEvent({ id: 'evt-001', label: 'Rotterdam' })];
    render(<VesselEventTimeline events={events} loading={false} />);

    const dayBtn = screen.getByRole('button', { name: /Jan 2024/i });

    // collapse
    fireEvent.click(dayBtn);
    expect(screen.queryByText('Rotterdam')).not.toBeInTheDocument();

    // expand
    fireEvent.click(dayBtn);
    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
    expect(dayBtn).toHaveAttribute('aria-expanded', 'true');
  });

  it('"Collapse all days" button collapses every day group', () => {
    const events = [
      buildEvent({
        id: 'evt-001',
        startTime: '2024-01-15T10:00:00Z',
        label: 'Rotterdam',
      }),
      buildEvent({
        id: 'evt-002',
        startTime: '2024-01-16T12:00:00Z',
        label: 'Hamburg',
      }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    // Both labels visible before collapse
    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
    expect(screen.getByText('Hamburg')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Collapse all days' }));

    expect(screen.queryByText('Rotterdam')).not.toBeInTheDocument();
    expect(screen.queryByText('Hamburg')).not.toBeInTheDocument();
  });

  it('"Expand all days" button re-shows events after all are collapsed', () => {
    const events = [
      buildEvent({
        id: 'evt-001',
        startTime: '2024-01-15T10:00:00Z',
        label: 'Rotterdam',
      }),
      buildEvent({
        id: 'evt-002',
        startTime: '2024-01-16T12:00:00Z',
        label: 'Hamburg',
      }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    // collapse all
    fireEvent.click(screen.getByRole('button', { name: 'Collapse all days' }));
    expect(screen.queryByText('Rotterdam')).not.toBeInTheDocument();

    // expand all
    fireEvent.click(screen.getByRole('button', { name: 'Expand all days' }));
    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
    expect(screen.getByText('Hamburg')).toBeInTheDocument();
  });

  /* ── event rows ── */

  it('event rows render with category label (fmtEventType of subType)', () => {
    const events = [buildEvent({ subType: 'PORT_ARRIVAL', id: 'evt-001' })];
    render(<VesselEventTimeline events={events} loading={false} />);
    expect(screen.getByText('PORT ARRIVAL')).toBeInTheDocument();
  });

  it('event row renders label text', () => {
    const events = [buildEvent({ label: 'Rotterdam', id: 'evt-001' })];
    render(<VesselEventTimeline events={events} loading={false} />);
    expect(screen.getAllByText('Rotterdam').length).toBeGreaterThan(0);
  });

  it('clicking an event calls setHighlightedEventId with the event id', () => {
    const events = [buildEvent({ id: 'evt-001', label: 'Rotterdam' })];
    render(<VesselEventTimeline events={events} loading={false} />);

    const allRoleButtons = document.querySelectorAll('[role="button"]');
    expect(allRoleButtons.length).toBeGreaterThan(0);
    fireEvent.click(allRoleButtons[allRoleButtons.length - 1]);

    expect(mockSetHighlightedEventId).toHaveBeenCalledWith('evt-001');
  });

  it('clicking a highlighted event calls setHighlightedEventId with null', () => {
    const events = [buildEvent({ id: 'evt-highlighted' })];
    setupStore(buildStoreSlice({ highlightedEventId: 'evt-highlighted' }));
    render(<VesselEventTimeline events={events} loading={false} />);

    const allRoleButtons = document.querySelectorAll('[role="button"]');
    expect(allRoleButtons.length).toBeGreaterThan(0);
    fireEvent.click(allRoleButtons[allRoleButtons.length - 1]);

    expect(mockSetHighlightedEventId).toHaveBeenCalledWith(null);
  });

  it('pressing Enter on an event row triggers highlight', () => {
    const events = [buildEvent({ id: 'evt-001' })];
    render(<VesselEventTimeline events={events} loading={false} />);

    const allRoleButtons = document.querySelectorAll('[role="button"]');
    fireEvent.keyDown(allRoleButtons[allRoleButtons.length - 1], {
      key: 'Enter',
    });

    expect(mockSetHighlightedEventId).toHaveBeenCalledWith('evt-001');
  });

  /* ── category filter ── */

  it('events filtered by category filters (zone_entry=false hides zone events)', () => {
    const events = [
      buildEvent({
        id: 'evt-port',
        category: 'port',
        subType: 'PORT_ARRIVAL',
        label: 'Rotterdam',
      }),
      buildEvent({
        id: 'evt-zone',
        category: 'zone',
        subType: 'ZONE_ENTRY',
        label: 'Strait of Malacca',
      }),
    ];
    setupStore(
      buildStoreSlice({
        filters: {
          port_arrival: true,
          port_departure: true,
          zone_entry: false,
          zone_exit: false,
          ais_gap: true,
          sts: true,
          discrepancy: true,
          psc: true,
        },
      }),
    );
    render(<VesselEventTimeline events={events} loading={false} />);

    expect(screen.getByText('Rotterdam')).toBeInTheDocument();
    expect(screen.queryByText('Strait of Malacca')).not.toBeInTheDocument();
  });

  /* ── replay mode ── */

  it('shows replay message when replayAt is set and all events are future', () => {
    // Event starts after replayAt, so it will be dimmed and excluded
    const futureEvent = buildEvent({
      id: 'evt-future',
      startTime: '2024-06-01T10:00:00Z',
    });
    setupStore(buildStoreSlice({ replayAt: new Date('2024-01-01T00:00:00Z') }));
    render(<VesselEventTimeline events={[futureEvent]} loading={false} />);

    expect(screen.getByText(/replay active/i)).toBeInTheDocument();
  });

  it('shows replay split count badge when some events are hidden by replay', () => {
    const events = [
      buildEvent({ id: 'evt-past', startTime: '2024-01-10T10:00:00Z' }),
      buildEvent({ id: 'evt-future', startTime: '2024-06-01T10:00:00Z' }),
    ];
    setupStore(buildStoreSlice({ replayAt: new Date('2024-02-01T00:00:00Z') }));
    render(<VesselEventTimeline events={events} loading={false} />);

    // Badge should show "1 / 2"
    const badges = document.querySelectorAll('span.tabular-nums');
    const badgeTexts = Array.from(badges).map((b) => b.textContent);
    expect(badgeTexts).toContain('1 / 2');
  });

  /* ── gap label ── */

  it('renders a gap label between events more than 1 minute apart', () => {
    const events = [
      buildEvent({ id: 'evt-001', startTime: '2024-01-15T10:00:00Z' }),
      buildEvent({ id: 'evt-002', startTime: '2024-01-15T12:00:00Z' }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    // fmtDuration(7200000ms) = '120m'
    expect(screen.getByText('120m')).toBeInTheDocument();
  });

  it('does not render a gap label between events less than 1 minute apart', () => {
    const events = [
      buildEvent({ id: 'evt-001', startTime: '2024-01-15T10:00:00Z' }),
      buildEvent({ id: 'evt-002', startTime: '2024-01-15T10:00:30Z' }),
    ];
    render(<VesselEventTimeline events={events} loading={false} />);

    // fmtDuration would give '0m' but the label should not render at all
    expect(screen.queryByText('0m')).not.toBeInTheDocument();
  });
});
