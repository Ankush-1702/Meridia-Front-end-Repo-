import { render, screen, fireEvent } from '@testing-library/react';
import { useState } from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';
import { useLatestVesselPosition } from '@/features/Vessels/hooks/useLatestVesselPosition';
import VesselActivitySidebar from '@/features/Vessels/ui/VesselActivitySidebar';
import type { Vessel } from '@/shared/types/entities';

/* ─── mocks ──────────────────────────────────────────────────────────────────── */

vi.mock('@/features/Vessels/hooks/useLatestVesselPosition', () => ({
  useLatestVesselPosition: vi.fn(() => ({
    position: null,
    loading: false,
    error: null,
  })),
}));

vi.mock('@/features/Vessels/ui/VesselSwitcher', () => ({
  default: ({ vessel }: { vessel: Vessel }) => (
    <span data-testid="vessel-switcher">{vessel.name}</span>
  ),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode: string }) => (
    <span data-testid="flag-icon">{flagCode}</span>
  ),
}));

// Tooltip is used extensively in the component — render children transparently
// so button accessible names and row text remain queryable in tests.
vi.mock('flowbite-react', () => ({
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock('@/features/Vessels/utils/vesselActivityFormatters', () => ({
  fmtEta: (eta: string | null | undefined) => (eta ? `ETA: ${eta}` : null),
}));

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  hasGroupPermission: vi.fn(() => false),
}));

vi.mock('@/features/Vessels/ui/MTIScoreSection', () => ({
  default: ({ imo, hasAccess }: { imo: string; hasAccess: boolean }) => (
    <div data-testid="mti-score-section">
      MTI Score Section (IMO: {imo}, hasAccess: {hasAccess ? 'true' : 'false'})
    </div>
  ),
}));

vi.mock('@/features/Vessels/ui/PtracScreeningSection', () => ({
  default: ({ imo, hasAccess }: { imo: string; hasAccess: boolean }) => (
    <div data-testid="ptrac-screening-section">
      PurpleTRAC Screening Section (IMO: {imo}, hasAccess:{' '}
      {hasAccess ? 'true' : 'false'})
    </div>
  ),
}));

/* ─── test fixtures ──────────────────────────────────────────────────────────── */

function buildVessel(overrides: Partial<Vessel> = {}): Vessel {
  return {
    imo: '9876543',
    name: 'MV Test Vessel',
    type: 'Bulk Carrier',
    mmsi: '123456789',
    flag: {
      name: 'Panama',
      country_code: 'PAN',
      effective_date: null,
    },
    draught: 12.5,
    asset_id: 'asset-001',
    callsign: 'TESTVSL',
    ownership: {
      operator: 'Test Co',
      registered_owner: 'Test Owner',
      technical_manager: 'Test TM',
      ship_manager: 'Test SM',
      group_beneficial_owner: 'Test GBO',
    },
    build_year: 2010,
    deadweight: 75000,
    dimensions: { length: 225, breadth: 32 },
    ship_status: 'Active',
    shipbuilder: 'Test Shipbuilder',
    displacement: 90000,
    gross_tonnage: 42000,
    country_of_build: { country_code: 'KOR', country_name: 'South Korea' },
    port_of_registry: 'Panama City',
    classification_society: "Lloyd's Register",
    ...overrides,
  };
}

/**
 * Wraps VesselActivitySidebar with its own accordion state,
 * mirroring the Vessels.tsx usage.
 */
function ControlledSidebar(
  props: Omit<
    React.ComponentProps<typeof VesselActivitySidebar>,
    'openSection' | 'onToggleSection'
  >,
) {
  const [openSection, setOpenSection] = useState<string | null>(null);
  return (
    <VesselActivitySidebar
      {...props}
      openSection={openSection}
      onToggleSection={(id) =>
        setOpenSection((prev) => (prev === id ? null : id))
      }
    />
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(useLatestVesselPosition).mockReturnValue({
    position: null,
    loading: false,
    error: null,
  });
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('VesselActivitySidebar', () => {
  /* ── header ── */

  it('renders vessel name via VesselSwitcher', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByTestId('vessel-switcher')).toHaveTextContent(
      'MV Test Vessel',
    );
  });

  it('renders flag icon with vessel flag code', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByTestId('flag-icon')).toHaveTextContent('PAN');
  });

  /* ── identity rows ── */

  it('renders IMO row with correct value', () => {
    const vessel = buildVessel({ imo: '9876543' });
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByText('IMO')).toBeInTheDocument();
    expect(screen.getByText('9876543')).toBeInTheDocument();
  });

  it('renders Type row with vessel type', () => {
    const vessel = buildVessel({ type: 'Bulk Carrier' });
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByText('Type')).toBeInTheDocument();
    expect(screen.getByText('Bulk Carrier')).toBeInTheDocument();
  });

  it('renders Flag row with flag name and code', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByText('Flag')).toBeInTheDocument();
    expect(screen.getByText('Panama (PAN)')).toBeInTheDocument();
  });

  it('renders "Flag since" row when effective_date is set', () => {
    const vessel = buildVessel({
      flag: {
        name: 'Panama',
        country_code: 'PAN',
        effective_date: '2015-01-01',
      },
    });
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByText('Flag since')).toBeInTheDocument();
  });

  it('does not render "Flag since" row when effective_date is null', () => {
    const vessel = buildVessel({
      flag: { name: 'Panama', country_code: 'PAN', effective_date: null },
    });
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.queryByText('Flag since')).not.toBeInTheDocument();
  });

  it('renders dash for missing row values', () => {
    const vessel = buildVessel({ callsign: undefined });
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    // Callsign row should show "-"
    expect(screen.getByText('Callsign')).toBeInTheDocument();
    // There may be multiple "-" on page; just assert at least one exists
    expect(screen.getAllByText('-').length).toBeGreaterThan(0);
  });

  /* ── accordion: all sections present ── */

  it.each(['Next Port', 'Dimensions', 'Registry', 'Ownership'])(
    'renders "%s" section button',
    (sectionLabel) => {
      const vessel = buildVessel();
      render(
        <VesselActivitySidebar
          vessel={vessel}
          openSection={null}
          onToggleSection={vi.fn()}
        />,
      );
      expect(
        screen.getByRole('button', { name: new RegExp(sectionLabel, 'i') }),
      ).toBeInTheDocument();
    },
  );

  /* ── accordion: Dimensions ── */

  it('"Dimensions" section is collapsed by default', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.queryByText('LOA')).not.toBeInTheDocument();
  });

  it('"Dimensions" section expands on click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Dimensions/i }));
    expect(screen.getByText('LOA')).toBeInTheDocument();
    expect(screen.getByText('Beam')).toBeInTheDocument();
    expect(screen.getByText('Gross tonnage')).toBeInTheDocument();
  });

  it('"Dimensions" section collapses on second click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    const btn = screen.getByRole('button', { name: /Dimensions/i });
    fireEvent.click(btn);
    expect(screen.getByText('LOA')).toBeInTheDocument();

    fireEvent.click(btn);
    expect(screen.queryByText('LOA')).not.toBeInTheDocument();
  });

  it('"Dimensions" rows reflect vessel data', () => {
    const vessel = buildVessel({
      dimensions: { length: 225, breadth: 32 },
      gross_tonnage: 42000,
    });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Dimensions/i }));
    expect(screen.getByText('225 m')).toBeInTheDocument();
    expect(screen.getByText('32 m')).toBeInTheDocument();
  });

  /* ── accordion: Registry ── */

  it('"Registry" section expands and shows build year', () => {
    const vessel = buildVessel({ build_year: 2010 });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Registry/i }));
    expect(screen.getByText('Built')).toBeInTheDocument();
    expect(screen.getByText('2010')).toBeInTheDocument();
  });

  it('"Registry" section shows shipbuilder and classification', () => {
    const vessel = buildVessel({
      shipbuilder: 'Test Shipbuilder',
      classification_society: "Lloyd's Register",
    });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Registry/i }));
    expect(screen.getByText('Shipbuilder')).toBeInTheDocument();
    expect(screen.getByText('Classification')).toBeInTheDocument();
  });

  /* ── accordion: Ownership ── */

  it('"Ownership" section expands and shows operator', () => {
    const vessel = buildVessel({
      ownership: {
        ...buildVessel().ownership!,
        operator: 'Test Co',
      },
    });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Ownership/i }));
    expect(screen.getByText('Operator')).toBeInTheDocument();
    expect(screen.getByText('Test Co')).toBeInTheDocument();
  });

  it('"Ownership" section shows all ownership rows', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Ownership/i }));
    expect(screen.getByText('Registered owner')).toBeInTheDocument();
    expect(screen.getByText('Technical manager')).toBeInTheDocument();
    expect(screen.getByText('Ship manager')).toBeInTheDocument();
    expect(screen.getByText('Group beneficial owner')).toBeInTheDocument();
  });

  /* ── accordion: Next Port ── */

  it('"Next Port" section is always rendered', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(
      screen.getByRole('button', { name: /Next Port/i }),
    ).toBeInTheDocument();
  });

  it('"Next Port" section shows Destination and ETA rows when expanded', () => {
    const vessel = buildVessel();
    vi.mocked(useLatestVesselPosition).mockReturnValue({
      position: {
        eta: '2024-06-15T08:00:00Z',
        destination: 'ROTTERDAM',
        latitude: 51.9,
        longitude: 4.5,
        speed: 12,
        heading: 90,
        timestamp: '2024-06-10T12:00:00Z',
      },
      loading: false,
      error: null,
    });

    render(<ControlledSidebar vessel={vessel} />);
    fireEvent.click(screen.getByRole('button', { name: /Next Port/i }));

    expect(screen.getByText('Destination')).toBeInTheDocument();
    expect(screen.getByText('ETA')).toBeInTheDocument();
    expect(screen.getByText('ROTTERDAM')).toBeInTheDocument();
  });

  it('"Next Port" renders even when position has no destination or eta', () => {
    const vessel = buildVessel();
    vi.mocked(useLatestVesselPosition).mockReturnValue({
      position: {
        eta: null,
        destination: '',
        latitude: 51.9,
        longitude: 4.5,
        speed: 12,
        heading: 90,
        timestamp: '2024-06-10T12:00:00Z',
      },
      loading: false,
      error: null,
    });

    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(
      screen.getByRole('button', { name: /Next Port/i }),
    ).toBeInTheDocument();
  });

  /* ── accordion: MTI Score ── */

  it('renders "MTI score" section button', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(
      screen.getByRole('button', { name: /MTI score/i }),
    ).toBeInTheDocument();
  });

  it('"MTI score" section is collapsed by default', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.queryByTestId('mti-score-section')).not.toBeInTheDocument();
  });

  it('"MTI score" section expands on click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /MTI score/i }));
    expect(screen.getByTestId('mti-score-section')).toBeInTheDocument();
  });

  it('"MTI score" section collapses on second click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    const btn = screen.getByRole('button', { name: /MTI score/i });
    fireEvent.click(btn);
    expect(screen.getByTestId('mti-score-section')).toBeInTheDocument();

    fireEvent.click(btn);
    expect(screen.queryByTestId('mti-score-section')).not.toBeInTheDocument();
  });

  it('"MTI score" section passes correct imo to MTIScoreSection', () => {
    const vessel = buildVessel({ imo: '1234567' });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /MTI score/i }));
    expect(screen.getByTestId('mti-score-section')).toHaveTextContent(
      'IMO: 1234567',
    );
  });

  it('"MTI score" section shows hasAccess=false when user lacks permission', () => {
    const vessel = buildVessel();
    vi.mocked(hasGroupPermission).mockReturnValue(false);
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /MTI score/i }));
    expect(screen.getByTestId('mti-score-section')).toHaveTextContent(
      'hasAccess: false',
    );
  });

  it('"MTI score" section shows hasAccess=true when user has permission', () => {
    const vessel = buildVessel();
    vi.mocked(hasGroupPermission).mockReturnValue(true);
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /MTI score/i }));
    expect(screen.getByTestId('mti-score-section')).toHaveTextContent(
      'hasAccess: true',
    );
  });

  /* ── accordion: PurpleTRAC screening ── */

  it('renders "PurpleTRAC screening" section button', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(
      screen.getByRole('button', { name: /PurpleTRAC screening/i }),
    ).toBeInTheDocument();
  });

  it('"PurpleTRAC screening" section is collapsed by default', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={vi.fn()}
      />,
    );
    expect(
      screen.queryByTestId('ptrac-screening-section'),
    ).not.toBeInTheDocument();
  });

  it('"PurpleTRAC screening" section expands on click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(
      screen.getByRole('button', { name: /PurpleTRAC screening/i }),
    );
    expect(screen.getByTestId('ptrac-screening-section')).toBeInTheDocument();
  });

  it('"PurpleTRAC screening" section collapses on second click', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    const btn = screen.getByRole('button', { name: /PurpleTRAC screening/i });
    fireEvent.click(btn);
    expect(screen.getByTestId('ptrac-screening-section')).toBeInTheDocument();

    fireEvent.click(btn);
    expect(
      screen.queryByTestId('ptrac-screening-section'),
    ).not.toBeInTheDocument();
  });

  it('"PurpleTRAC screening" section passes correct imo to PtracScreeningSection', () => {
    const vessel = buildVessel({ imo: '1234567' });
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(
      screen.getByRole('button', { name: /PurpleTRAC screening/i }),
    );
    expect(screen.getByTestId('ptrac-screening-section')).toHaveTextContent(
      'IMO: 1234567',
    );
  });

  it('"PurpleTRAC screening" section shows hasAccess=false when user lacks permission', () => {
    const vessel = buildVessel();
    vi.mocked(hasGroupPermission).mockReturnValue(false);
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(
      screen.getByRole('button', { name: /PurpleTRAC screening/i }),
    );
    expect(screen.getByTestId('ptrac-screening-section')).toHaveTextContent(
      'hasAccess: false',
    );
  });

  it('"PurpleTRAC screening" section shows hasAccess=true when user has permission', () => {
    const vessel = buildVessel();
    vi.mocked(hasGroupPermission).mockReturnValue(true);
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(
      screen.getByRole('button', { name: /PurpleTRAC screening/i }),
    );
    expect(screen.getByTestId('ptrac-screening-section')).toHaveTextContent(
      'hasAccess: true',
    );
  });

  /* ── accordion: mutual exclusion ── */

  it('only one section is open at a time (opening another closes the first)', () => {
    const vessel = buildVessel();
    render(<ControlledSidebar vessel={vessel} />);

    fireEvent.click(screen.getByRole('button', { name: /Dimensions/i }));
    expect(screen.getByText('LOA')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /Registry/i }));
    expect(screen.queryByText('LOA')).not.toBeInTheDocument();
    expect(screen.getByText('Built')).toBeInTheDocument();
  });

  /* ── controlled openSection prop ── */

  it('respects openSection prop — renders section content when pre-opened', () => {
    const vessel = buildVessel();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection="dimensions"
        onToggleSection={vi.fn()}
      />,
    );
    expect(screen.getByText('LOA')).toBeInTheDocument();
  });

  it('calls onToggleSection with the section id when a section header is clicked', () => {
    const vessel = buildVessel();
    const onToggleSection = vi.fn();
    render(
      <VesselActivitySidebar
        vessel={vessel}
        openSection={null}
        onToggleSection={onToggleSection}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: /Dimensions/i }));
    expect(onToggleSection).toHaveBeenCalledWith('dimensions');
  });
});
