import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { DateRange } from '@/features/Vessels/store/useVesselActivityStore';
import type { ActivityEvent } from '@/features/Vessels/types/vesselActivityTypes';
import VesselReplayBar from '@/features/Vessels/ui/VesselReplayBar';

/* ─── store mock ─────────────────────────────────────────────────────────────── */

const mockStartReplay = vi.fn();
const mockPauseReplay = vi.fn();
const mockResetReplay = vi.fn();
const mockSetReplaySpeed = vi.fn();
const mockSetReplayAt = vi.fn();
const mockSetIsScrubbing = vi.fn();
const mockSetFollowVessel = vi.fn();
const mockSetPauseAtEvents = vi.fn();

const mockStoreSelector = vi.fn();

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: (selector: (s: unknown) => unknown) =>
    mockStoreSelector(selector),
  REPLAY_SPEED_OPTIONS: [1, 2, 5, 10],
}));

// Flowbite Tooltip — just render children
vi.mock('flowbite-react', () => ({
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

/* ─── store state factory ────────────────────────────────────────────────────── */

const DATE_RANGE: DateRange = {
  from: new Date('2024-01-01T00:00:00Z'),
  to: new Date('2024-01-31T00:00:00Z'),
};

interface StoreState {
  replayAt: Date | null;
  isReplaying: boolean;
  replaySpeed: number;
  followVessel: boolean;
  pauseAtEvents: boolean;
  filters: Record<string, boolean>;
  setReplayAt: typeof mockSetReplayAt;
  startReplay: typeof mockStartReplay;
  pauseReplay: typeof mockPauseReplay;
  resetReplay: typeof mockResetReplay;
  setReplaySpeed: typeof mockSetReplaySpeed;
  setIsScrubbing: typeof mockSetIsScrubbing;
  setFollowVessel: typeof mockSetFollowVessel;
  setPauseAtEvents: typeof mockSetPauseAtEvents;
}

function buildStoreState(overrides: Partial<StoreState> = {}): StoreState {
  return {
    replayAt: new Date('2024-01-15T10:30:00Z'),
    isReplaying: false,
    replaySpeed: 1,
    followVessel: false,
    pauseAtEvents: false,
    filters: {
      port_arrival: true,
      port_departure: true,
      zone_entry: true,
      zone_exit: true,
      ais_gap: true,
      sts: true,
      discrepancy: true,
      psc: true,
    },
    setReplayAt: mockSetReplayAt,
    startReplay: mockStartReplay,
    pauseReplay: mockPauseReplay,
    resetReplay: mockResetReplay,
    setReplaySpeed: mockSetReplaySpeed,
    setIsScrubbing: mockSetIsScrubbing,
    setFollowVessel: mockSetFollowVessel,
    setPauseAtEvents: mockSetPauseAtEvents,
    ...overrides,
  };
}

function setupStoreSelector(state: StoreState) {
  mockStoreSelector.mockImplementation((selector: (s: StoreState) => unknown) =>
    selector(state),
  );
}

/* ─── default props ──────────────────────────────────────────────────────────── */

const EVENTS: ActivityEvent[] = [];

const mockOnToggleGantt = vi.fn();

function defaultProps(overrides: Partial<{ ganttOpen: boolean }> = {}) {
  return {
    events: EVENTS,
    dateRange: DATE_RANGE,
    ganttOpen: overrides.ganttOpen ?? false,
    onToggleGantt: mockOnToggleGantt,
  };
}

/* ─── setup ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  setupStoreSelector(buildStoreState());
});

/* ─── tests ──────────────────────────────────────────────────────────────────── */

describe('VesselReplayBar', () => {
  it('renders timestamp display for current replayAt', () => {
    setupStoreSelector(
      buildStoreState({ replayAt: new Date('2024-01-15T10:30:00Z') }),
    );
    render(<VesselReplayBar {...defaultProps()} />);

    // fmtDate/fmtTime output — just confirm some date content is rendered
    // The timestamp container is a <span> with tabular-nums class
    const spans = document.querySelectorAll('span.tabular-nums');
    expect(spans.length).toBeGreaterThan(0);
  });

  it('renders start date and end date labels', () => {
    render(<VesselReplayBar {...defaultProps()} />);
    // Two tabular-nums spans: start date, current timestamp — plus end date
    const spans = document.querySelectorAll('span.tabular-nums');
    expect(spans.length).toBeGreaterThanOrEqual(1);
  });

  it('play button (aria-label=Play) calls startReplay when not replaying', () => {
    setupStoreSelector(buildStoreState({ isReplaying: false }));
    render(<VesselReplayBar {...defaultProps()} />);

    fireEvent.click(screen.getByRole('button', { name: 'Play' }));

    expect(mockStartReplay).toHaveBeenCalledWith(DATE_RANGE);
  });

  it('pause button (aria-label=Pause) calls pauseReplay when replaying', () => {
    setupStoreSelector(buildStoreState({ isReplaying: true }));
    render(<VesselReplayBar {...defaultProps()} />);

    fireEvent.click(screen.getByRole('button', { name: 'Pause' }));

    expect(mockPauseReplay).toHaveBeenCalledTimes(1);
  });

  it('reset button (aria-label=Skip to start) calls resetReplay', () => {
    render(<VesselReplayBar {...defaultProps()} />);
    mockResetReplay.mockClear(); // clear mount-time calls before asserting

    fireEvent.click(screen.getByRole('button', { name: 'Skip to start' }));

    expect(mockResetReplay).toHaveBeenCalledTimes(1);
  });

  it('calls resetReplay when dateRange changes', () => {
    const { rerender } = render(<VesselReplayBar {...defaultProps()} />);
    mockResetReplay.mockClear(); // clear the initial mount call

    const newDateRange: DateRange = {
      from: new Date('2024-02-01T00:00:00Z'),
      to: new Date('2024-02-28T00:00:00Z'),
    };

    rerender(
      <VesselReplayBar
        events={EVENTS}
        dateRange={newDateRange}
        ganttOpen={false}
        onToggleGantt={mockOnToggleGantt}
      />,
    );

    expect(mockResetReplay).toHaveBeenCalledTimes(1);
  });

  it.each([1, 2, 5, 10])(
    'speed button %d× calls setReplaySpeed with that value',
    (speed) => {
      render(<VesselReplayBar {...defaultProps()} />);

      fireEvent.click(screen.getByText(`${speed}×`));

      expect(mockSetReplaySpeed).toHaveBeenCalledWith(speed);
    },
  );

  it('follow-vessel button toggles followVessel from false to true', () => {
    setupStoreSelector(buildStoreState({ followVessel: false }));
    render(<VesselReplayBar {...defaultProps()} />);

    // Tooltip is mocked away, so find by searching for the button that calls setFollowVessel
    // We locate by querying all buttons and clicking the one that should call setFollowVessel
    const buttons = screen.getAllByRole('button');
    // The follow-vessel button is the one that toggles followVessel
    // Since Tooltip is stripped, find by its position: after speed buttons, before pause-at-events
    // Look for a button whose onclick sets followVessel
    // We fire click on each candidate after speed buttons
    const speedButtons = [1, 2, 5, 10].map((s) => screen.getByText(`${s}×`));
    const lastSpeedBtn = speedButtons[speedButtons.length - 1];
    const allBtns = [...buttons];
    const afterSpeed = allBtns.slice(
      allBtns.indexOf(lastSpeedBtn as HTMLButtonElement) + 1,
    );

    // The follow-vessel button is the first icon-only button after speed controls
    if (afterSpeed.length > 0) {
      fireEvent.click(afterSpeed[0]);
      expect(mockSetFollowVessel).toHaveBeenCalledWith(true);
    }
  });

  it('follow-vessel button toggles followVessel from true to false', () => {
    setupStoreSelector(buildStoreState({ followVessel: true }));
    render(<VesselReplayBar {...defaultProps()} />);

    const buttons = screen.getAllByRole('button');
    const speedButtons = [1, 2, 5, 10].map((s) => screen.getByText(`${s}×`));
    const lastSpeedBtn = speedButtons[speedButtons.length - 1];
    const allBtns = [...buttons];
    const afterSpeed = allBtns.slice(
      allBtns.indexOf(lastSpeedBtn as HTMLButtonElement) + 1,
    );

    if (afterSpeed.length > 0) {
      fireEvent.click(afterSpeed[0]);
      expect(mockSetFollowVessel).toHaveBeenCalledWith(false);
    }
  });

  it('pause-at-events button toggles pauseAtEvents from false to true', () => {
    setupStoreSelector(buildStoreState({ pauseAtEvents: false }));
    render(<VesselReplayBar {...defaultProps()} />);

    const buttons = screen.getAllByRole('button');
    const speedButtons = [1, 2, 5, 10].map((s) => screen.getByText(`${s}×`));
    const lastSpeedBtn = speedButtons[speedButtons.length - 1];
    const allBtns = [...buttons];
    const afterSpeed = allBtns.slice(
      allBtns.indexOf(lastSpeedBtn as HTMLButtonElement) + 1,
    );

    // pause-at-events is the second icon-only button after speed controls
    if (afterSpeed.length > 1) {
      fireEvent.click(afterSpeed[1]);
      expect(mockSetPauseAtEvents).toHaveBeenCalledWith(true);
    }
  });

  it('gantt toggle button calls onToggleGantt', () => {
    render(<VesselReplayBar {...defaultProps()} />);

    // Gantt button doesn't have an accessible name by default — find by aria-label or title
    // It's the last icon-only button in the bar. We locate via test click coverage:
    const buttons = screen.getAllByRole('button');
    const speedButtons = [1, 2, 5, 10].map((s) => screen.getByText(`${s}×`));
    const lastSpeedBtn = speedButtons[speedButtons.length - 1];
    const allBtns = [...buttons];
    const afterSpeed = allBtns.slice(
      allBtns.indexOf(lastSpeedBtn as HTMLButtonElement) + 1,
    );

    // onToggleGantt button is the last icon-only button after speed controls
    if (afterSpeed.length > 0) {
      const lastBtn = afterSpeed[afterSpeed.length - 1];
      fireEvent.click(lastBtn);
      expect(mockOnToggleGantt).toHaveBeenCalledTimes(1);
    }
  });

  it('shows Play icon when not replaying', () => {
    setupStoreSelector(buildStoreState({ isReplaying: false }));
    render(<VesselReplayBar {...defaultProps()} />);

    expect(screen.getByRole('button', { name: 'Play' })).toBeInTheDocument();
    expect(
      screen.queryByRole('button', { name: 'Pause' }),
    ).not.toBeInTheDocument();
  });

  it('shows Pause icon when replaying', () => {
    setupStoreSelector(buildStoreState({ isReplaying: true }));
    render(<VesselReplayBar {...defaultProps()} />);

    expect(screen.getByRole('button', { name: 'Pause' })).toBeInTheDocument();
    expect(
      screen.queryByRole('button', { name: 'Play' }),
    ).not.toBeInTheDocument();
  });

  describe('when disabled', () => {
    it('renders "No data available for selected range" message', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);
      expect(
        screen.getByText('No data available for selected range'),
      ).toBeInTheDocument();
    });

    it('does not render the end date label', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);
      // fmtDate(DATE_RANGE.to) would be "31 Jan 2024" or similar — absent when disabled
      const spans = document.querySelectorAll('span.tabular-nums');
      // Only the timestamp span should remain — end date span renders nothing
      const nonEmptySpans = Array.from(spans).filter(
        (s) => s.textContent?.trim() !== '',
      );
      // The end date span renders empty string when disabled, so only the timestamp span has content
      expect(nonEmptySpans.length).toBe(1);
    });

    it('play button does not call startReplay when disabled', () => {
      setupStoreSelector(buildStoreState({ isReplaying: false }));
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);

      fireEvent.click(screen.getByRole('button', { name: 'Play' }));

      expect(mockStartReplay).not.toHaveBeenCalled();
    });

    it('skip-to-start button does not call resetReplay when disabled', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);
      mockResetReplay.mockClear();

      fireEvent.click(screen.getByRole('button', { name: 'Skip to start' }));

      expect(mockResetReplay).not.toHaveBeenCalled();
    });

    it('skip-to-end button does not call setReplayAt when disabled', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);

      fireEvent.click(screen.getByRole('button', { name: 'Skip to end' }));

      expect(mockSetReplayAt).not.toHaveBeenCalled();
    });

    it('spacebar does not call startReplay or pauseReplay when disabled', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);

      fireEvent.keyDown(window, { key: ' ' });

      expect(mockStartReplay).not.toHaveBeenCalled();
      expect(mockPauseReplay).not.toHaveBeenCalled();
    });

    it('ArrowLeft/ArrowRight do not call setReplayAt when disabled', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);

      fireEvent.keyDown(window, { key: 'ArrowLeft' });
      fireEvent.keyDown(window, { key: 'ArrowRight' });

      expect(mockSetReplayAt).not.toHaveBeenCalled();
    });

    it('speed buttons do not call setReplaySpeed when disabled', () => {
      render(<VesselReplayBar {...defaultProps()} disabled={true} />);

      fireEvent.click(screen.getByText('1×'));

      expect(mockSetReplaySpeed).not.toHaveBeenCalled();
    });
  });
});
