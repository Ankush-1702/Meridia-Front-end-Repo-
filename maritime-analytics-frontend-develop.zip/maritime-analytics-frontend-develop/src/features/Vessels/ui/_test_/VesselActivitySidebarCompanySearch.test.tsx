import { fireEvent, render, screen } from '@testing-library/react';
import { useState } from 'react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import VesselActivitySidebar from '@/features/Vessels/ui/VesselActivitySidebar';
import type { Vessel } from '@/shared/types/entities';

const { companySearchButtonMock } = vi.hoisted(() => ({
  companySearchButtonMock: vi.fn(),
}));

vi.mock('@/features/company-search', () => ({
  CompanySearchButton: (props: {
    companyName: string;
    companyRole: string;
    vesselName?: string;
    imo?: string;
    variant?: 'full' | 'icon';
  }) => {
    companySearchButtonMock(props);
    return (
      <button
        type="button"
        aria-label={`Search ${props.companyRole} ${props.companyName}`}
      />
    );
  },
}));

vi.mock('@/features/Vessels/hooks/useLatestVesselPosition', () => ({
  useLatestVesselPosition: () => ({
    position: null,
    loading: false,
    error: null,
  }),
}));

vi.mock('@/features/Vessels/ui/VesselSwitcher', () => ({
  default: ({ vessel }: { vessel: Vessel }) => <span>{vessel.name}</span>,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: () => null,
}));

vi.mock('flowbite-react', () => ({
  Tooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

vi.mock('@/features/auth/utils/authTokenUtils', () => ({
  hasGroupPermission: () => false,
}));

vi.mock('@/features/Vessels/ui/MTIScoreSection', () => ({
  default: () => null,
}));

vi.mock('@/features/Vessels/ui/PtracScreeningSection', () => ({
  default: () => null,
}));

function buildVessel(): Vessel {
  return {
    imo: '9169055',
    name: 'MSC ADRIANA II',
    type: 'Container Ship',
    mmsi: '636018321',
    flag: {
      name: 'Liberia',
      country_code: 'LBR',
      effective_date: null,
    },
    draught: 11.2,
    asset_id: 'asset-001',
    callsign: 'D5PE9',
    ownership: {
      operator: 'MSC Mediterranean Shipping Co',
      registered_owner: 'Adriana Oceanway Ltd',
      technical_manager: 'MSC Shipmanagement Ltd',
      ship_manager: 'MSC Shipmanagement Ltd',
      group_beneficial_owner: 'MSC Mediterranean Shipping Co',
    },
    build_year: 1998,
    deadweight: 50000,
    dimensions: { length: 216, breadth: 32 },
    ship_status: 'In Service/Commission',
    shipbuilder: 'HDW',
    displacement: 60000,
    gross_tonnage: 25000,
    country_of_build: { country_code: 'DEU', country_name: 'Germany' },
    port_of_registry: 'Monrovia',
    classification_society: 'DNV',
  };
}

function ControlledSidebar({ vessel }: { vessel: Vessel }) {
  const [openSection, setOpenSection] = useState<string | null>(null);
  return (
    <VesselActivitySidebar
      vessel={vessel}
      openSection={openSection}
      onToggleSection={(id) =>
        setOpenSection((prev) => (prev === id ? null : id))
      }
    />
  );
}

describe('VesselActivitySidebar company search ownership rows', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders company search controls for every ownership company row', () => {
    render(<ControlledSidebar vessel={buildVessel()} />);

    fireEvent.click(screen.getByRole('button', { name: /Ownership/i }));

    expect(companySearchButtonMock).toHaveBeenCalledWith(
      expect.objectContaining({
        companyName: 'MSC Mediterranean Shipping Co',
        companyRole: 'Operator',
      }),
    );
    expect(companySearchButtonMock).toHaveBeenCalledWith(
      expect.objectContaining({
        companyName: 'Adriana Oceanway Ltd',
        companyRole: 'Registered Owner',
      }),
    );
    expect(companySearchButtonMock).toHaveBeenCalledWith(
      expect.objectContaining({
        companyName: 'MSC Shipmanagement Ltd',
        companyRole: 'Technical Manager',
      }),
    );
    expect(companySearchButtonMock).toHaveBeenCalledWith(
      expect.objectContaining({
        companyName: 'MSC Shipmanagement Ltd',
        companyRole: 'Ship Manager',
      }),
    );
    expect(companySearchButtonMock).toHaveBeenCalledWith(
      expect.objectContaining({
        companyName: 'MSC Mediterranean Shipping Co',
        companyRole: 'Group Beneficial Owner',
      }),
    );
  });
});
