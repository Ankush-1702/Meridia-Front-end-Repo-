import { Spinner } from 'flowbite-react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { useCallback, useEffect, useRef, useState } from 'react';
import { IoIosCheckmarkCircleOutline } from 'react-icons/io';
import { useTheme } from '@/app/context/ThemeProvider';
import VesselOverviewMapLegend from '@/features/Vessels/components/VesselOverviewMapLegend';
import { VesselActivityResult } from '@/features/Vessels/hooks/useVesselActivity';
import { useVesselTrack } from '@/features/Vessels/hooks/useVesselTrack';
import {
  DateRange,
  useVesselActivityStore,
} from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  getEventLegendKey,
  LEGEND_EVENT_META,
  PositionSource,
} from '@/features/Vessels/types/vesselActivityTypes';
import { flattenedVesselAISGaps } from '@/features/Vessels/types/vesselTypes';
import ReplayEventOverlay from '@/features/Vessels/ui/ReplayEventOverlay';
import {
  applyGapLines,
  buildPopupHTML,
  buildPositionPopupHTML,
  createMarkerEl,
  createPositionArrowEl,
  GapFeatureCollection,
  updateMarkerEl,
} from '@/features/Vessels/ui/vesselActivityMapUtils';
import { mercatorInterpolate } from '@/features/Vessels/utils/mercatorInterpolate';
import {
  buildTrackGeoJSON,
  EMPTY_GEOJSON,
  findTrackSplitIndex,
  getTrackColor,
  TrackColorMode,
} from '@/features/Vessels/utils/replayPositionUtils';
import CustomZoomControl from '@/shared/components/CustomZoomControl';
import MapCoordinates from '@/shared/components/MapCoordinates';
import NauticalChartsControl from '@/shared/components/NauticalChartsControl';
import { MAP_STYLES } from '@/shared/constants/overviewMapConstants';
import { useMapCoordinates } from '@/shared/hooks/useMapCoordinates';
import { useMapInit } from '@/shared/hooks/useMapInit';
import { useMapStyleControl } from '@/shared/hooks/useMapStyleControl';

// ─── Source / layer name constants ───────────────────────────────────────────
//
// TRACK_VESSEL_SOURCE is the KEY architectural decision in this file.
//
// Previously the past-track LineStrings and the replay vessel Point lived in
// two separate GeoJSON sources.  Mapbox processes each source independently in
// its web-worker, converting geographic coordinates to tile-space integers in
// separate quantisation passes.  Even a single ULP difference between the two
// passes produces a visible sub-pixel offset at max zoom, because one tile
// pixel can be < 4 cm at zoom 22.
//
// By placing both the track lines AND the vessel point in the same source they
// are quantised together in one worker pass, guaranteeing they share identical
// tile-space coordinates and therefore render with zero relative offset at any
// zoom level.
const TRACK_VESSEL_SOURCE = 'track-vessel-source'; // combined: past-track lines + vessel point
const TRACK_FUTURE_SOURCE = 'vessel-track-future';
const TRACK_PAST_LAYER = 'vessel-track-past-line';
const TRACK_FUTURE_LAYER = 'vessel-track-future-line';
const VESSEL_REPLAY_LAYER = 'vessel-replay-layer';
const VESSEL_ICON_ID = 'vessel-replay-icon';

const REPLAY_GHOST_OPACITY = 0.25;
const FOLLOW_ZOOM = 11;

// ─── Vessel icon sprite ───────────────────────────────────────────────────────
// Canvas-rendered vessel silhouette pointing north (bearing 0).
// The hull's geographic reference point sits at the exact pixel centre of the
// canvas so that icon-rotate always spins around the correct map coordinate.
// pixelRatio:2 means the 44-px canvas is displayed as a crisp 22-px icon.
function createVesselIconImage(size = 44): ImageData {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context is not available');
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 2;

  ctx.beginPath();
  ctx.moveTo(cx, cy - r); // bow tip (north)
  ctx.lineTo(cx + r * 0.5, cy + r * 0.65); // starboard quarter
  ctx.lineTo(cx, cy + r * 0.35); // stern notch
  ctx.lineTo(cx - r * 0.5, cy + r * 0.65); // port quarter
  ctx.closePath();

  ctx.fillStyle = '#FF6B35';
  ctx.fill();
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 2;
  ctx.stroke();

  return ctx.getImageData(0, 0, size, size);
}

interface Props {
  activityData: VesselActivityResult;
  imo: string;
  dateRange: DateRange;
}

export default function VesselActivityMap({
  activityData,
  imo,
  dateRange,
}: Props) {
  const { events, loading } = activityData;
  const { filters, highlightedEventId } = useVesselActivityStore();
  const { theme: themeMode } = useTheme();
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDarkMode =
    themeMode === 'dark' || (themeMode === 'system' && prefersDark);

  const containerRef = useRef<HTMLDivElement>(null);
  const markerMapRef = useRef<Map<string, mapboxgl.Marker>>(new Map());
  const markerElMapRef = useRef<Map<string, HTMLElement>>(new Map());
  const hoverPopupRef = useRef<{ id: string; popup: mapboxgl.Popup } | null>(
    null,
  );
  const pinnedPopupRef = useRef<{ id: string; popup: mapboxgl.Popup } | null>(
    null,
  );
  const gapGeoJSONRef = useRef<GapFeatureCollection>({
    type: 'FeatureCollection',
    features: [],
  });

  const positionMarkersRef = useRef<
    Array<{
      marker: mapboxgl.Marker;
      popup: mapboxgl.Popup;
      el: HTMLElement;
      idx: number;
    }>
  >([]);
  const hoverPosRef = useRef<{ idx: number; popup: mapboxgl.Popup } | null>(
    null,
  );
  const pinnedPosRef = useRef<{ idx: number; popup: mapboxgl.Popup } | null>(
    null,
  );

  // ── Shared state for the combined TRACK_VESSEL_SOURCE ──────────────────
  // pastTrackFeaturesRef  — LineString features for the past track segment.
  //                         Updated every ~500 ms by updateSplit.
  // vesselFeatureRef      — The single Point feature for the replay vessel.
  //                         Updated every ~50 ms by the vessel tick.
  //
  // getCombinedData() merges both into a single FeatureCollection that is
  // written to TRACK_VESSEL_SOURCE.  Because the merge is always done from
  // the same two refs before calling setData(), the source always contains a
  // consistent snapshot with no race between two independent setData calls.
  const pastTrackFeaturesRef = useRef<GeoJSON.Feature[]>([]);
  const vesselFeatureRef = useRef<GeoJSON.Feature | null>(null);

  // Cached past-track GeoJSON for future-source setData (unchanged from before)
  const trackDataRef = useRef<{
    past: Parameters<mapboxgl.GeoJSONSource['setData']>[0];
    future: Parameters<mapboxgl.GeoJSONSource['setData']>[0];
  } | null>(null);

  const [colorMode, setColorMode] = useState<TrackColorMode>('nav_status');
  const [positionSource, setPositionSource] = useState<PositionSource>('ais');
  const [statusVisible, setStatusVisible] = useState(true);
  const [statusFading, setStatusFading] = useState(false);

  const { positions, posArrays } = useVesselTrack(
    imo,
    dateRange.from,
    dateRange.to,
  );

  // Keep a ref so vessel tick can read the latest positions without being in
  // the dependency array (avoids restarting the 50-ms interval on every render)
  const positionsRef = useRef(positions);
  positionsRef.current = positions;

  const { mapRef, mapReady, currentStyleRef } = useMapInit(
    containerRef,
    { latitude: 20, longitude: 0 },
    2,
    isDarkMode ? MAP_STYLES.dark : MAP_STYLES.light,
  );

  const { selectedStyle, setSelectedStyle, gridEnabled, setGridEnabled } =
    useMapStyleControl(mapRef, mapReady, isDarkMode, currentStyleRef);

  const coordinates = useMapCoordinates(mapRef, mapReady);

  // ── Helpers that both effects share ──────────────────────────────────────
  const getCombinedData = useCallback((): GeoJSON.FeatureCollection => {
    return {
      type: 'FeatureCollection',
      features: [
        ...pastTrackFeaturesRef.current,
        ...(vesselFeatureRef.current ? [vesselFeatureRef.current] : []),
      ],
    };
  }, []);

  // ── Status fade ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (loading) {
      setStatusVisible(true);
      setStatusFading(false);
      return;
    }
    setStatusFading(true);
    const t = setTimeout(() => setStatusVisible(false), 5000);
    return () => clearTimeout(t);
  }, [loading]);

  // ── Resize observer ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(() => {
      mapRef.current?.resize();
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [mapRef]);

  // ── Re-apply gap lines after style reload ─────────────────────────────────
  useEffect(() => {
    if (!mapReady || !mapRef.current) return;
    const map = mapRef.current;
    const onStyleLoad = () => applyGapLines(map, gapGeoJSONRef.current);
    map.on('style.load', onStyleLoad);
    return () => {
      map.off('style.load', onStyleLoad);
    };
  }, [mapReady, mapRef]);

  // ── Track layer visibility (position source toggle) ───────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    function applyVisibility() {
      const visibility = positionSource === 'ais' ? 'visible' : 'none';
      if (map!.getLayer(TRACK_PAST_LAYER))
        map!.setLayoutProperty(TRACK_PAST_LAYER, 'visibility', visibility);
      if (map!.getLayer(TRACK_FUTURE_LAYER))
        map!.setLayoutProperty(TRACK_FUTURE_LAYER, 'visibility', visibility);
    }

    applyVisibility();
    const onStyleLoad = () => setTimeout(applyVisibility, 0);
    map.on('style.load', onStyleLoad);
    return () => {
      map.off('style.load', onStyleLoad);
    };
  }, [positionSource, mapReady, mapRef]);

  // ── Combined source + layer setup ─────────────────────────────────────────
  // Sets up:
  //   TRACK_VESSEL_SOURCE  → FeatureCollection (past-track LineStrings + vessel Point)
  //   TRACK_FUTURE_SOURCE  → FeatureCollection (future/ghost track LineStrings)
  //   TRACK_PAST_LAYER     → line layer   — filter: LineString features
  //   TRACK_FUTURE_LAYER   → line layer   — future source (unchanged)
  //   VESSEL_REPLAY_LAYER  → symbol layer — filter: Point features with featureType='vessel'
  //
  // Re-runs after every style reload (theme switch) to re-register layers/image.
  useEffect(() => {
    if (!mapReady || !mapRef.current) return;
    const map = mapRef.current;

    function setup() {
      // ── Vessel icon sprite ──────────────────────────────────────────────
      if (!map.hasImage(VESSEL_ICON_ID)) {
        map.addImage(VESSEL_ICON_ID, createVesselIconImage(44), {
          pixelRatio: 2,
        });
      }

      // ── Combined source (past track + vessel) ───────────────────────────
      if (!map.getSource(TRACK_VESSEL_SOURCE)) {
        map.addSource(TRACK_VESSEL_SOURCE, {
          type: 'geojson',
          data: { type: 'FeatureCollection', features: [] },
        });
      }

      // Past track line layer — only consumes LineString features
      if (!map.getLayer(TRACK_PAST_LAYER)) {
        map.addLayer({
          id: TRACK_PAST_LAYER,
          type: 'line',
          source: TRACK_VESSEL_SOURCE,
          filter: ['==', ['geometry-type'], 'LineString'],
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': ['coalesce', ['get', 'color'], '#2B969C'],
            'line-width': 2,
            'line-opacity': 0.8,
            'line-emissive-strength': 1,
          },
        });
      }

      // Vessel symbol layer — only consumes Point features tagged featureType='vessel'
      if (!map.getLayer(VESSEL_REPLAY_LAYER)) {
        map.addLayer({
          id: VESSEL_REPLAY_LAYER,
          type: 'symbol',
          source: TRACK_VESSEL_SOURCE,
          filter: ['==', ['get', 'featureType'], 'vessel'],
          layout: {
            'icon-image': VESSEL_ICON_ID,
            // icon-rotate is resolved in the same WebGL draw call as the track
            // line, sharing the exact same tile coordinate space — this is what
            // guarantees pixel-perfect on-track alignment at every zoom level.
            'icon-rotate': ['get', 'bearing'],
            'icon-rotation-alignment': 'map',
            'icon-allow-overlap': true,
            'icon-ignore-placement': true,
            'icon-size': 1,
          },
        });
      }

      // ── Future / ghost track source (separate — doesn't need to align) ──
      if (!map.getSource(TRACK_FUTURE_SOURCE)) {
        map.addSource(TRACK_FUTURE_SOURCE, {
          type: 'geojson',
          data: EMPTY_GEOJSON,
        });
      }
      if (!map.getLayer(TRACK_FUTURE_LAYER)) {
        map.addLayer({
          id: TRACK_FUTURE_LAYER,
          type: 'line',
          source: TRACK_FUTURE_SOURCE,
          layout: { 'line-cap': 'round', 'line-join': 'round' },
          paint: {
            'line-color': ['coalesce', ['get', 'color'], '#2B969C'],
            'line-width': 2,
            'line-opacity': REPLAY_GHOST_OPACITY,
            'line-emissive-strength': 1,
          },
        });
      }

      // Restore data after style reload wipes sources
      if (pastTrackFeaturesRef.current.length > 0 || vesselFeatureRef.current) {
        (map.getSource(TRACK_VESSEL_SOURCE) as mapboxgl.GeoJSONSource)?.setData(
          getCombinedData(),
        );
      }
      if (trackDataRef.current) {
        (map.getSource(TRACK_FUTURE_SOURCE) as mapboxgl.GeoJSONSource)?.setData(
          trackDataRef.current.future,
        );
      }
    }

    setup();
    const onStyleLoad = () => setup();
    map.on('style.load', onStyleLoad);
    return () => {
      map.off('style.load', onStyleLoad);
    };
  }, [mapReady, mapRef, getCombinedData]);

  // ── Position arrow markers (one per AIS point) ────────────────────────────
  useEffect(() => {
    if (!mapReady || positions.length === 0) return;
    const map = mapRef.current;
    if (!map) return;

    positionMarkersRef.current.forEach(({ marker, popup }) => {
      popup.remove();
      marker.remove();
    });
    positionMarkersRef.current = [];
    hoverPosRef.current = null;
    pinnedPosRef.current = null;

    positions.forEach((pos, i) => {
      const color = getTrackColor(pos.speed, pos.status, colorMode);
      const bearing = posArrays.cogs[i] ?? 0;
      const el = createPositionArrowEl(bearing, color);

      const popup = new mapboxgl.Popup({
        offset: 8,
        closeButton: false,
        closeOnClick: false,
        maxWidth: '220px',
        className: 'vessel-activity-popup',
      }).setHTML(buildPositionPopupHTML(pos));

      const marker = new mapboxgl.Marker({ element: el, anchor: 'center' })
        .setLngLat([pos.longitude, pos.latitude])
        .addTo(map);

      el.addEventListener('mouseenter', () => {
        if (pinnedPosRef.current?.idx === i) return;
        hoverPosRef.current?.popup.remove();
        popup.setLngLat([pos.longitude, pos.latitude]).addTo(map);
        hoverPosRef.current = { idx: i, popup };
      });
      el.addEventListener('mouseleave', () => {
        if (pinnedPosRef.current?.idx === i) return;
        popup.remove();
        if (hoverPosRef.current?.idx === i) hoverPosRef.current = null;
      });
      el.addEventListener('click', () => {
        const isPinned = pinnedPosRef.current?.idx === i;
        if (isPinned) {
          popup.remove();
          pinnedPosRef.current = null;
        } else {
          pinnedPosRef.current?.popup.remove();
          hoverPosRef.current?.popup.remove();
          hoverPosRef.current = null;
          pinnedPosRef.current = { idx: i, popup };
          if (!popup.isOpen())
            popup.setLngLat([pos.longitude, pos.latitude]).addTo(map);
        }
      });

      positionMarkersRef.current.push({ marker, popup, el, idx: i });
    });

    return () => {
      positionMarkersRef.current.forEach(({ marker, popup }) => {
        popup.remove();
        marker.remove();
      });
      positionMarkersRef.current = [];
    };
  }, [mapReady, mapRef, positions, posArrays, colorMode]);

  // ── Past/future split update (2 Hz) ──────────────────────────────────────
  useEffect(() => {
    if (!mapReady || positions.length < 2) return;

    let idlePainted = false;

    function updateSplit() {
      const map = mapRef.current;
      if (!map) return;
      const { replayAt } = useVesselActivityStore.getState();

      const trackVesselSrc = map.getSource(TRACK_VESSEL_SOURCE) as
        | mapboxgl.GeoJSONSource
        | undefined;
      const futureSrc = map.getSource(TRACK_FUTURE_SOURCE) as
        | mapboxgl.GeoJSONSource
        | undefined;
      if (!trackVesselSrc || !futureSrc) return;

      let splitIdx = positions.length - 1;

      if (replayAt === null) {
        if (idlePainted) return;

        const pastGeoJSON = buildTrackGeoJSON(
          positions,
          0,
          positions.length - 1,
          colorMode,
        ) as GeoJSON.FeatureCollection;

        // Store LineString features in the shared ref so the vessel tick
        // can merge them with the vessel Point without an extra setData call.
        pastTrackFeaturesRef.current = pastGeoJSON.features;

        trackDataRef.current = {
          past: pastGeoJSON,
          future: EMPTY_GEOJSON as Parameters<typeof futureSrc.setData>[0],
        };

        // Write both track lines + current vessel position in one call
        trackVesselSrc.setData(getCombinedData());
        futureSrc.setData(trackDataRef.current.future);
        idlePainted = true;
      } else {
        idlePainted = false;
        splitIdx = findTrackSplitIndex(
          posArrays.timestampMs,
          replayAt.getTime(),
        );

        const pastGeoJSON = buildTrackGeoJSON(
          positions,
          0,
          Math.max(0, splitIdx),
          colorMode,
        ) as GeoJSON.FeatureCollection;
        const futureGeoJSON = buildTrackGeoJSON(
          positions,
          Math.max(0, splitIdx),
          positions.length - 1,
          colorMode,
        ) as GeoJSON.FeatureCollection;

        pastTrackFeaturesRef.current = pastGeoJSON.features;

        trackDataRef.current = {
          past: pastGeoJSON,
          future: futureGeoJSON,
        };

        trackVesselSrc.setData(getCombinedData());
        futureSrc.setData(futureGeoJSON);
      }

      // Ghost out future position markers
      positionMarkersRef.current.forEach(({ el, idx }) => {
        const isPast = replayAt === null || idx <= splitIdx;
        el.style.opacity = isPast ? '1' : String(REPLAY_GHOST_OPACITY);
        el.style.pointerEvents = isPast ? 'auto' : 'none';
      });
    }

    updateSplit();
    const id = setInterval(updateSplit, 500);
    return () => clearInterval(id);
  }, [mapReady, mapRef, positions, posArrays, colorMode, getCombinedData]);

  // ── Replay vessel position (20 Hz) ───────────────────────────────────────
  //
  // This tick drives the vessel Point feature inside TRACK_VESSEL_SOURCE.
  //
  // Position accuracy — WHY Mercator interpolation:
  //   Mapbox renders each line segment as a straight line in Web Mercator
  //   (tile) space.  The mathematically correct point ON that rendered
  //   segment at fraction t is therefore the Mercator-space linear
  //   interpolation of the two endpoint coordinates, not the arithmetic
  //   midpoint of their latitudes.  mercatorInterpolate() replicates this
  //   exactly, guaranteeing the vessel icon sits on the rendered line even
  //   for long AIS segments at maximum zoom.
  //
  // Source alignment — WHY single source:
  //   The vessel Point is merged into the same FeatureCollection as the
  //   track LineStrings before every setData() call.  Mapbox therefore
  //   quantises all features to tile-space integers in one worker pass,
  //   eliminating any rounding difference that would arise from two
  //   independent sources being quantised separately.
  //
  // Bearing — snapped to nearest past AIS checkpoint via posArrays.cogs so
  //   the vessel only rotates when the replay cursor crosses a real AIS
  //   position, not continuously.

  // ── Replay vessel position (20 Hz) ───────────────────────────────────────
  const lastTickTsRef = useRef<number | null>(null);
  useEffect(() => {
    if (!mapReady || posArrays.timestampMs.length === 0) return;

    function getTrackVesselSource(): mapboxgl.GeoJSONSource | undefined {
      return mapRef.current?.getSource(TRACK_VESSEL_SOURCE) as
        | mapboxgl.GeoJSONSource
        | undefined;
    }

    const vesselSentinel: GeoJSON.Feature<GeoJSON.Point> = {
      type: 'Feature',
      properties: { featureType: 'vessel', bearing: 0 },
      geometry: { type: 'Point', coordinates: [0, 0] },
    };

    const combinedFCRef = {
      current: {
        type: 'FeatureCollection' as const,
        features: [...pastTrackFeaturesRef.current] as GeoJSON.Feature[],
      },
    };

    let sentinelAttached = false;
    let lastSplitIdx = -1;

    function rebuildFeatures(includeVessel: boolean) {
      combinedFCRef.current.features = [
        ...pastTrackFeaturesRef.current,
        ...(includeVessel ? [vesselSentinel] : []),
      ];
      sentinelAttached = includeVessel;
    }

    function tick() {
      const src = getTrackVesselSource();
      if (!src) return;

      const { replayAt } = useVesselActivityStore.getState();

      if (!replayAt) {
        if (lastTickTsRef.current !== null) {
          lastTickTsRef.current = null;
          vesselFeatureRef.current = null;
          rebuildFeatures(false);
          src.setData(combinedFCRef.current);
        }
        return;
      }

      const ts = replayAt.getTime();
      if (ts === lastTickTsRef.current) return;
      lastTickTsRef.current = ts;

      const snapIdx = findTrackSplitIndex(posArrays.timestampMs, ts);
      const i0 = Math.max(
        0,
        Math.min(snapIdx, positionsRef.current.length - 1),
      );
      const i1 = Math.min(i0 + 1, positionsRef.current.length - 1);
      const p0 = positionsRef.current[i0];
      const p1 = positionsRef.current[i1];

      let longitude: number;
      let latitude: number;

      if (
        i0 === i1 ||
        posArrays.timestampMs[i0] === posArrays.timestampMs[i1]
      ) {
        longitude = p0.longitude;
        latitude = p0.latitude;
      } else {
        const t0 = posArrays.timestampMs[i0];
        const t1 = posArrays.timestampMs[i1];
        const t = Math.max(0, Math.min(1, (ts - t0) / (t1 - t0)));
        [longitude, latitude] = mercatorInterpolate(
          p0.longitude,
          p0.latitude,
          p1.longitude,
          p1.latitude,
          t,
        );
      }

      const bearing = posArrays.cogs[i0] ?? 0;

      if (snapIdx !== lastSplitIdx || !sentinelAttached) {
        lastSplitIdx = snapIdx;
        const pastGeoJSON = buildTrackGeoJSON(
          positionsRef.current,
          0,
          Math.max(0, snapIdx),
          colorMode,
        ) as GeoJSON.FeatureCollection;
        const futureGeoJSON = buildTrackGeoJSON(
          positionsRef.current,
          Math.max(0, snapIdx),
          positionsRef.current.length - 1,
          colorMode,
        ) as GeoJSON.FeatureCollection;

        pastTrackFeaturesRef.current = pastGeoJSON.features;
        trackDataRef.current = { past: pastGeoJSON, future: futureGeoJSON };

        // Push the new future segment immediately — no waiting for 500 ms tick
        const futureSrc = mapRef.current?.getSource(TRACK_FUTURE_SOURCE) as
          | mapboxgl.GeoJSONSource
          | undefined;
        futureSrc?.setData(futureGeoJSON);

        // Sync position-arrow opacity with the new split boundary
        positionMarkersRef.current.forEach(({ el, idx }) => {
          const isPast = idx <= snapIdx;
          el.style.opacity = isPast ? '1' : String(REPLAY_GHOST_OPACITY);
          el.style.pointerEvents = isPast ? 'auto' : 'none';
        });
        // ── END CHANGE ────────────────────────────────────────────────────

        rebuildFeatures(true);
      }

      vesselSentinel.geometry.coordinates[0] = longitude;
      vesselSentinel.geometry.coordinates[1] = latitude;
      (vesselSentinel.properties as { bearing: number }).bearing = bearing;

      vesselFeatureRef.current = vesselSentinel;

      src.setData(combinedFCRef.current);
    }

    tick();
    const id = setInterval(tick, 50);
    return () => {
      clearInterval(id);
      lastTickTsRef.current = null;
      vesselFeatureRef.current = null;
      rebuildFeatures(false);
      const src = getTrackVesselSource();
      if (src) src.setData(combinedFCRef.current);
    };
  }, [mapReady, mapRef, posArrays, colorMode]);

  // ── Follow vessel (4 Hz) ──────────────────────────────────────────────────
  useEffect(() => {
    if (!mapReady || posArrays.timestampMs.length === 0) return;
    let wasFollowing = false;

    const id = setInterval(() => {
      const { followVessel, replayAt, isReplaying } =
        useVesselActivityStore.getState();
      const map = mapRef.current;
      if (!map || !followVessel || !isReplaying || !replayAt) {
        wasFollowing = false;
        return;
      }

      const ts = replayAt.getTime();
      const snapIdx = findTrackSplitIndex(posArrays.timestampMs, ts);
      const i0 = Math.max(
        0,
        Math.min(snapIdx, positionsRef.current.length - 1),
      );
      const i1 = Math.min(i0 + 1, positionsRef.current.length - 1);
      const p0 = positionsRef.current[i0];
      const p1 = positionsRef.current[i1];

      let longitude: number;
      let latitude: number;

      if (
        i0 === i1 ||
        posArrays.timestampMs[i0] === posArrays.timestampMs[i1]
      ) {
        longitude = p0.longitude;
        latitude = p0.latitude;
      } else {
        const t0 = posArrays.timestampMs[i0];
        const t1 = posArrays.timestampMs[i1];
        const t = Math.max(0, Math.min(1, (ts - t0) / (t1 - t0)));
        [longitude, latitude] = mercatorInterpolate(
          p0.longitude,
          p0.latitude,
          p1.longitude,
          p1.latitude,
          t,
        );
      }

      if (!wasFollowing) {
        map.flyTo({
          center: [longitude, latitude],
          zoom: FOLLOW_ZOOM,
          duration: 800,
        });
        wasFollowing = true;
      } else {
        map.panTo([longitude, latitude], { animate: true, duration: 200 });
      }
    }, 250);

    return () => clearInterval(id);
  }, [mapReady, mapRef, posArrays]);

  // ── Event markers + gap lines ─────────────────────────────────────────────
  useEffect(() => {
    if (!mapReady || !mapRef.current) return;
    const map = mapRef.current;

    markerMapRef.current.forEach((m) => m.remove());
    markerMapRef.current.clear();
    markerElMapRef.current.clear();

    const gapFeatures: GapFeatureCollection['features'] = [];
    if (filters.ais_gap) {
      events
        .filter((e) => e.category === 'ais_gap')
        .forEach((ev) => {
          const gap = ev.raw as flattenedVesselAISGaps;
          if (
            gap?.stopped?.latitude != null &&
            gap?.stopped?.longitude != null &&
            gap?.resumed?.latitude != null &&
            gap?.resumed?.longitude != null
          ) {
            gapFeatures.push({
              type: 'Feature',
              properties: { id: ev.id },
              geometry: {
                type: 'LineString',
                coordinates: [
                  [gap.stopped.longitude, gap.stopped.latitude],
                  [gap.resumed.longitude, gap.resumed.latitude],
                ],
              },
            });
          }
        });
    }
    const gapGeoJSON: GapFeatureCollection = {
      type: 'FeatureCollection',
      features: gapFeatures,
    };
    gapGeoJSONRef.current = gapGeoJSON;
    applyGapLines(map, gapGeoJSON);

    const visibleEvents = events.filter(
      (e) =>
        filters[getEventLegendKey(e)] &&
        e.latitude != null &&
        e.longitude != null,
    );

    hoverPopupRef.current?.popup.remove();
    hoverPopupRef.current = null;
    pinnedPopupRef.current?.popup.remove();
    pinnedPopupRef.current = null;

    if (visibleEvents.length === 0) return;

    const bounds = new mapboxgl.LngLatBounds();

    visibleEvents.forEach((event: ActivityEvent) => {
      const color = LEGEND_EVENT_META[getEventLegendKey(event)].color;
      const isHighlighted = highlightedEventId === event.id;
      const el = createMarkerEl(event.category, color, isHighlighted);

      const popup = new mapboxgl.Popup({
        offset: 14,
        closeButton: false,
        closeOnClick: false,
        maxWidth: '260px',
        className: 'vessel-activity-popup',
      }).setHTML(buildPopupHTML(event, color));

      const marker = new mapboxgl.Marker({ element: el, anchor: 'center' })
        .setLngLat([event.longitude!, event.latitude!])
        .addTo(map);

      el.addEventListener('mouseenter', () => {
        if (pinnedPopupRef.current?.id === event.id) return;
        hoverPopupRef.current?.popup.remove();
        popup.setLngLat([event.longitude!, event.latitude!]).addTo(map);
        hoverPopupRef.current = { id: event.id, popup };
      });
      el.addEventListener('mouseleave', () => {
        if (pinnedPopupRef.current?.id === event.id) return;
        popup.remove();
        if (hoverPopupRef.current?.id === event.id)
          hoverPopupRef.current = null;
      });
      el.addEventListener('click', () => {
        const store = useVesselActivityStore.getState();
        const isCurrentlyPinned = pinnedPopupRef.current?.id === event.id;
        if (isCurrentlyPinned) {
          popup.remove();
          pinnedPopupRef.current = null;
          hoverPopupRef.current = null;
          store.setHighlightedEventId(null);
        } else {
          pinnedPopupRef.current?.popup.remove();
          hoverPopupRef.current?.popup.remove();
          hoverPopupRef.current = null;
          pinnedPopupRef.current = { id: event.id, popup };
          store.setHighlightedEventId(event.id);
          if (!popup.isOpen())
            popup.setLngLat([event.longitude!, event.latitude!]).addTo(map);
        }
      });

      markerMapRef.current.set(event.id, marker);
      markerElMapRef.current.set(event.id, el);
      bounds.extend([event.longitude!, event.latitude!]);
    });

    if (!bounds.isEmpty()) {
      map.fitBounds(bounds, { padding: 80, maxZoom: 8, duration: 600 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [events, filters, mapReady, mapRef]);

  // ── Highlight sync (in-place, no marker rebuild) ──────────────────────────
  useEffect(() => {
    markerElMapRef.current.forEach((el, id) => {
      updateMarkerEl(el, highlightedEventId === id);
    });
    if (!highlightedEventId && pinnedPopupRef.current) {
      pinnedPopupRef.current.popup.remove();
      pinnedPopupRef.current = null;
    }
  }, [highlightedEventId]);

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div
        ref={containerRef}
        className="h-full w-full"
        style={{ minHeight: '200px' }}
      />

      <div className="absolute left-2 top-2 z-20 flex items-start gap-2">
        <VesselOverviewMapLegend
          events={events}
          colorMode={colorMode}
          onColorModeChange={setColorMode}
          positionSource={positionSource}
          onPositionSourceChange={setPositionSource}
        />
        {statusVisible && (
          <div
            className={`flex items-center gap-2 rounded-lg bg-white px-4 py-2.5 shadow-2xl transition-opacity duration-[5000ms] dark:bg-gray-800 ${
              statusFading ? 'opacity-0' : 'opacity-100'
            }`}
          >
            <div className="flex h-4 w-4 flex-shrink-0 items-center justify-center">
              {loading ? (
                <Spinner size="xs" color="gray" light />
              ) : (
                <IoIosCheckmarkCircleOutline className="h-4 w-4 text-green-500" />
              )}
            </div>
            <span className="text-xs text-gray-700 dark:text-gray-300">
              {loading ? 'Loading' : 'Loaded'}
            </span>
          </div>
        )}
        <ReplayEventOverlay />
      </div>

      <NauticalChartsControl
        selectedStyle={selectedStyle}
        gridEnabled={gridEnabled}
        onStyleChange={setSelectedStyle}
        onGridChange={setGridEnabled}
        position="top-right"
        className="z-[1000]"
      />

      <div className="absolute bottom-8 right-3 z-20">
        <CustomZoomControl map={mapRef.current} inline />
      </div>

      <MapCoordinates coordinates={coordinates} />
    </div>
  );
}
