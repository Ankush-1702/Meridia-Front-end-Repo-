import { Tooltip } from 'flowbite-react';
import {
  LuAnchor,
  LuChevronDown,
  LuChevronRight,
  LuHelpCircle,
  // LuGauge,
  LuRuler,
  LuScrollText,
  // LuShield,
  LuUsers,
} from 'react-icons/lu';
import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';
import { CompanySearchButton } from '@/features/company-search';
import { useLatestVesselPosition } from '@/features/Vessels/hooks/useLatestVesselPosition';
import MTIScoreSection from '@/features/Vessels/ui/MTIScoreSection';
import PtracScreeningSection from '@/features/Vessels/ui/PtracScreeningSection';
import VesselSwitcher from '@/features/Vessels/ui/VesselSwitcher';
import { fmtEta } from '@/features/Vessels/utils/vesselActivityFormatters';
import { Vessel } from '@/shared/types/entities';
import FlagIcon from '@/shared/ui/FlagIcon';
import { truncateTitle } from '@/shared/utils/formatUtils';

interface Props {
  vessel: Vessel;
  openSection: string | null;
  onToggleSection: (id: string) => void;
}

function Row({
  label,
  value,
  tooltip,
}: {
  label: string;
  value: string | number | null | undefined;
  tooltip?: string | null | undefined;
}) {
  const str = value != null && value !== '' ? String(value) : '-';
  const tooltipContent =
    tooltip != null && tooltip !== '' ? String(tooltip) : str;
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-gray-200 pb-2 pt-1 last:border-b-0 dark:border-gray-700">
      <span className="shrink-0 text-xs text-gray-500 dark:text-gray-400">
        {label}
      </span>
      <Tooltip
        content={tooltipContent}
        placement={`bottom`}
        className="max-w-fit whitespace-nowrap rounded text-xs"
        arrow={false}
      >
        <span className="min-w-0 cursor-default text-right text-xs text-gray-900 dark:text-gray-100">
          {truncateTitle(str)}
        </span>
      </Tooltip>
    </div>
  );
}

// Stacked layout (label above, name below, full width) - company names are
// long and wrap poorly in the same-row Row layout used elsewhere in the sidebar.
function OwnershipRow({
  label,
  value,
  companyRole,
  vesselName,
  imo,
}: {
  label: string;
  value: string | null | undefined;
  companyRole?: string;
  vesselName?: string;
  imo?: string;
}) {
  const str = value != null && value !== '' ? String(value) : '-';
  return (
    <div className="border-b border-gray-100 py-2 last:border-b-0 dark:border-gray-700">
      <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
      <div className="mt-0.5 flex items-center justify-between gap-2">
        <span className="min-w-0 flex-1 break-words text-xs font-medium leading-snug text-gray-900 dark:text-gray-100">
          {str}
        </span>
        {value && companyRole && (
          <CompanySearchButton
            variant="icon"
            companyName={value}
            companyRole={companyRole}
            vesselName={vesselName}
            imo={imo}
          />
        )}
      </div>
    </div>
  );
}

function Section({
  sectionId,
  icon,
  label,
  summary,
  children,
  isOpen,
  onToggle,
  bottomBorder = false,
  infoTooltip,
}: {
  sectionId: string;
  icon: React.ReactNode;
  label: string;
  summary?: React.ReactNode;
  children: React.ReactNode;
  isOpen: boolean;
  onToggle: (id: string) => void;
  bottomBorder?: boolean;
  infoTooltip?: string;
}) {
  return (
    <div
      className={`border-t border-gray-200 pt-1 dark:border-gray-700 ${bottomBorder ? 'border-b border-gray-200 pb-1 dark:border-gray-700' : ''}`}
    >
      <button
        onClick={() => onToggle(sectionId)}
        className="flex w-full cursor-pointer items-center gap-1.5 rounded px-1 py-1.5 text-left transition-colors hover:bg-gray-100/50 dark:hover:bg-gray-700/50"
      >
        <Tooltip
          content={label}
          placement="bottom"
          className="whitespace-nowrap rounded text-xs"
          theme={{ target: 'flex items-center gap-1.5' }}
          arrow={false}
        >
          <span className="shrink-0 text-gray-500 dark:text-gray-400">
            {icon}
          </span>
          <span className="shrink-0 text-xs font-semibold text-gray-700 dark:text-gray-300">
            {label}
          </span>
        </Tooltip>

        {!isOpen && infoTooltip && (
          <Tooltip
            content={infoTooltip}
            placement="bottom"
            className="w-60 rounded text-xs"
            arrow={false}
          >
            <LuHelpCircle
              className="h-3 w-3 shrink-0 text-gray-400 dark:text-gray-500"
              onClick={(e) => e.stopPropagation()}
              onMouseDown={(e) => e.stopPropagation()}
            />
          </Tooltip>
        )}

        {/* Summary takes remaining space, right-aligned */}
        <span className="ml-4 min-w-0 flex-1 overflow-hidden text-ellipsis whitespace-nowrap text-right text-[10px] text-gray-400/60 dark:text-gray-500/60">
          {!isOpen ? summary : null}
        </span>

        {isOpen ? (
          <Tooltip
            content="Collapse"
            placement="bottom"
            className="whitespace-nowrap rounded text-xs"
            arrow={false}
          >
            <LuChevronDown className="h-3 w-3 shrink-0 text-gray-400 dark:text-gray-500" />
          </Tooltip>
        ) : (
          <Tooltip
            content="Expand"
            placement="bottom"
            className="whitespace-nowrap rounded text-xs"
            arrow={false}
          >
            <LuChevronRight className="h-3 w-3 shrink-0 text-gray-400 dark:text-gray-500" />
          </Tooltip>
        )}
      </button>
      {isOpen && <div>{children}</div>}
    </div>
  );
}

export default function VesselActivitySidebar({
  vessel,
  openSection,
  onToggleSection,
}: Props) {
  const { position: latestPos } = useLatestVesselPosition(vessel.imo);

  const flagSummary =
    vessel.flag.name && vessel.flag.country_code
      ? `${vessel.flag.name} (${vessel.flag.country_code})`
      : vessel.flag.name || vessel.flag.country_code || '';

  const dimensionsSummary = [
    vessel.dimensions?.length ? `${vessel.dimensions.length} m` : null,
    vessel.gross_tonnage
      ? `${Math.round(vessel.gross_tonnage / 1000)}K GT`
      : null,
  ]
    .filter(Boolean)
    .join(' · ');

  const registrySummary = [vessel.build_year, vessel.shipbuilder]
    .filter(Boolean)
    .join(' · ');

  const ownershipSummary =
    vessel.ownership?.operator || vessel.ownership?.registered_owner;

  return (
    <aside className="relative flex h-full w-[320px] shrink-0 flex-col border-r border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-900">
      {/* Header */}
      <div className="flex h-12 items-center gap-2 px-4">
        <FlagIcon flagCode={vessel.flag.country_code} />
        <VesselSwitcher vessel={vessel} />
      </div>

      {/* All content in px-4 space-y-1 container - matches prototype exactly */}
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-4">
        {/* Identity rows */}
        <div>
          <Row label="Type" value={vessel.type} />
          <Row label="IMO" value={vessel.imo} />
          <Row label="MMSI" value={vessel.mmsi} />
          <Row label="Flag" value={flagSummary} />
          {vessel.flag.effective_date && (
            <Row label="Flag since" value={vessel.flag.effective_date} />
          )}
          <Row label="Callsign" value={vessel.callsign} />
          <Row label="Status" value={vessel.ship_status} />
        </div>

        {/* Accordion sections */}
        <div className="space-y-1">
          {(() => {
            const destination = latestPos?.destination?.trim() || null;
            const etaFormatted = fmtEta(latestPos?.eta);
            const nextPortSummary = destination ?? etaFormatted ?? undefined;
            return (
              <Section
                sectionId="next-port"
                icon={<LuAnchor className="h-3 w-3" />}
                label="Next Port"
                summary={nextPortSummary}
                isOpen={openSection === 'next-port'}
                onToggle={onToggleSection}
              >
                <Row
                  label="Destination"
                  value={destination}
                  tooltip={latestPos?.destinationTooltip}
                />
                <Row label="ETA" value={etaFormatted} />
              </Section>
            );
          })()}

          <Section
            sectionId="ptrac-screening"
            icon={<span className="h-3 w-3" />}
            label="PurpleTRAC screening"
            isOpen={openSection === 'ptrac-screening'}
            onToggle={onToggleSection}
            infoTooltip="Sanctions and compliance screening for this vessel against global watchlists - powered by PurpleTRAC."
          >
            <PtracScreeningSection
              imo={vessel.imo}
              hasAccess={hasGroupPermission('auto-screening')}
            />
          </Section>

          <Section
            sectionId="mti-score"
            icon={<span className="h-3 w-3" />}
            label="MTI score"
            isOpen={openSection === 'mti-score'}
            onToggle={onToggleSection}
            infoTooltip="A 0-5 score of how transparent and compliant this vessel's operations are - the higher the score, the lower the risk. Powered by the Maritime Transparency Index (MTI)."
          >
            <MTIScoreSection
              imo={vessel.imo}
              hasAccess={hasGroupPermission('meridia-mti-tier1')}
            />
          </Section>

          <Section
            sectionId="dimensions"
            icon={<LuRuler className="h-3 w-3" />}
            label="Dimensions"
            summary={dimensionsSummary || undefined}
            isOpen={openSection === 'dimensions'}
            onToggle={onToggleSection}
          >
            <Row
              label="LOA"
              value={
                vessel.dimensions?.length
                  ? `${vessel.dimensions.length} m`
                  : null
              }
            />
            <Row
              label="Beam"
              value={
                vessel.dimensions?.breadth
                  ? `${vessel.dimensions.breadth} m`
                  : null
              }
            />
            <Row
              label="Draught"
              value={vessel.draught ? `${vessel.draught} m` : null}
            />
            <Row
              label="Gross tonnage"
              value={vessel.gross_tonnage?.toLocaleString()}
            />
            <Row
              label="Deadweight"
              value={vessel.deadweight?.toLocaleString()}
            />
            <Row
              label="Displacement"
              value={vessel.displacement?.toLocaleString()}
            />
            <Row
              label="Service speed"
              value={vessel.speed != null ? `${vessel.speed} kn` : null}
            />
          </Section>

          <Section
            sectionId="registry"
            icon={<LuScrollText className="h-3 w-3" />}
            label="Registry"
            summary={registrySummary || undefined}
            isOpen={openSection === 'registry'}
            onToggle={onToggleSection}
          >
            <Row label="Built" value={vessel.build_year} />
            <Row label="Shipbuilder" value={vessel.shipbuilder} />
            <Row
              label="Country of build"
              value={vessel.country_of_build?.country_name}
            />
            <Row label="Hull type" value={vessel.hull_type} />
            <Row label="Port of registry" value={vessel.port_of_registry} />
            <Row label="Classification" value={vessel.classification_society} />
            <Row label="P&I Club" value={vessel.pandi_club} />
            <Row label="DOC company" value={vessel.doc_company} />
          </Section>

          <Section
            sectionId="ownership"
            icon={<LuUsers className="h-3 w-3" />}
            label="Ownership"
            summary={ownershipSummary || undefined}
            isOpen={openSection === 'ownership'}
            onToggle={onToggleSection}
          >
            <OwnershipRow
              label="Operator"
              value={vessel.ownership?.operator}
              companyRole="Operator"
              vesselName={vessel.name}
              imo={vessel.imo}
            />
            <OwnershipRow
              label="Registered owner"
              value={vessel.ownership?.registered_owner}
              companyRole="Registered Owner"
              vesselName={vessel.name}
              imo={vessel.imo}
            />
            <OwnershipRow
              label="Technical manager"
              value={vessel.ownership?.technical_manager}
              companyRole="Technical Manager"
              vesselName={vessel.name}
              imo={vessel.imo}
            />
            <OwnershipRow
              label="Ship manager"
              value={vessel.ownership?.ship_manager}
              companyRole="Ship Manager"
              vesselName={vessel.name}
              imo={vessel.imo}
            />
            <OwnershipRow
              label="Group beneficial owner"
              value={vessel.ownership?.group_beneficial_owner}
              companyRole="Group Beneficial Owner"
              vesselName={vessel.name}
              imo={vessel.imo}
            />
          </Section>

          {/* <Section
            sectionId="risk"
            icon={<LuShield className="h-3 w-3" />}
            label="Risk"
            isOpen={openSection === 'risk'}
            onToggle={onToggleSection}
          >
            <p className="py-1 text-xs italic text-gray-400 dark:text-gray-500">
              Coming soon to Meridia
            </p>
          </Section>

          <Section
            sectionId="transparency"
            icon={<LuGauge className="h-3 w-3" />}
            label="Transparency"
            isOpen={openSection === 'transparency'}
            onToggle={onToggleSection}
            bottomBorder
          >
            <p className="py-1 text-xs italic text-gray-400 dark:text-gray-500">
              Coming soon to Meridia
            </p>
          </Section> */}
        </div>
      </div>
    </aside>
  );
}
