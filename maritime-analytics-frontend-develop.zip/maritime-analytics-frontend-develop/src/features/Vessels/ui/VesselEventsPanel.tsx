import { ColDef } from 'ag-grid-enterprise';
import { FlatVesselEventsResponse } from '@/features/Vessels/types/vesselTypes';
import NewEventsPanel from '@/shared/ui/NewEventsPanel';

interface VesselEventsPanelProps {
  vesselName?: string;
  vesselId: string;
  vesselEventsTabs: { label: string; value: string }[];
  refresh?: boolean;
  setRefresh?: (refresh: boolean) => void;
  selected: Record<string, boolean>;
  onToggle: (value: string, checked: boolean) => void;
  onSelectAll: (checked: boolean) => void;
  rows: unknown[];
  buildColumns: (timezone: string) => ColDef[];
  storageKey: string;
  lastUpdated?: Date;
  isLoading?: boolean;
  onRowClick?: (row: FlatVesselEventsResponse) => void;
  dateRange?: { start: string; end: string };
  setDateRange?: (range: { start: string; end: string }) => void;
}

export function VesselEventsPanel({
  vesselEventsTabs,
  storageKey,
  onSelectAll,
  selected,
  onToggle,
  rows,
  refresh,
  setRefresh,
  buildColumns,
  lastUpdated,
  isLoading,
  onRowClick,
  vesselId,
}: VesselEventsPanelProps) {
  return (
    <NewEventsPanel
      eventsTabs={vesselEventsTabs}
      selected={selected}
      onToggle={onToggle}
      onSelectAll={onSelectAll}
      rows={rows}
      refresh={refresh}
      setRefresh={setRefresh}
      buildColumns={buildColumns}
      storageKey={storageKey}
      lastUpdated={lastUpdated}
      isLoading={isLoading}
      onRowClick={onRowClick}
      entityType="vessel"
      entityId={vesselId}
      columnReset={true}
    />
  );
}
