import { Tooltip } from 'flowbite-react';
import { useEffect } from 'react';
import {
  LuCalendarClock,
  LuGanttChartSquare,
  LuLocateFixed,
  LuPlay,
  LuPause,
  LuSkipBack,
  LuSkipForward,
} from 'react-icons/lu';
import {
  useVesselActivityStore,
  DateRange,
  REPLAY_SPEED_OPTIONS,
} from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  getEventLegendKey,
  LEGEND_EVENT_META,
} from '@/features/Vessels/types/vesselActivityTypes';
import {
  fmtDate,
  fmtTime,
} from '@/features/Vessels/utils/vesselActivityFormatters';

interface Props {
  events: ActivityEvent[];
  dateRange: DateRange;
  ganttOpen: boolean;
  onToggleGantt: () => void;
  disabled?: boolean;
}

const STEP_FRACTION = 1 / 200;
const SLIDER_MAX = 1_000_000;

export default function VesselReplayBar({
  events,
  dateRange,
  ganttOpen,
  onToggleGantt,
  disabled = false,
}: Props) {
  const replayAt = useVesselActivityStore((s) => s.replayAt);
  const isReplaying = useVesselActivityStore((s) => s.isReplaying);
  const replaySpeed = useVesselActivityStore((s) => s.replaySpeed);
  const setReplayAt = useVesselActivityStore((s) => s.setReplayAt);
  const startReplay = useVesselActivityStore((s) => s.startReplay);
  const pauseReplay = useVesselActivityStore((s) => s.pauseReplay);
  const resetReplay = useVesselActivityStore((s) => s.resetReplay);
  const setReplaySpeed = useVesselActivityStore((s) => s.setReplaySpeed);
  const setIsScrubbing = useVesselActivityStore((s) => s.setIsScrubbing);
  const followVessel = useVesselActivityStore((s) => s.followVessel);
  const setFollowVessel = useVesselActivityStore((s) => s.setFollowVessel);
  const pauseAtEvents = useVesselActivityStore((s) => s.pauseAtEvents);
  const setPauseAtEvents = useVesselActivityStore((s) => s.setPauseAtEvents);
  const filters = useVesselActivityStore((s) => s.filters);

  // Keyboard shortcuts read fresh store state on each key press.
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (disabled) return;
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable
      ) {
        return;
      }

      const state = useVesselActivityStore.getState();
      const fromMs = dateRange.from.getTime();
      const toMs = dateRange.to.getTime();
      const rangeMs = toMs - fromMs;

      switch (e.key) {
        case ' ':
          e.preventDefault();
          if (state.isReplaying) {
            state.pauseReplay();
          } else {
            state.startReplay(dateRange);
          }
          break;

        case 'ArrowLeft':
        case 'ArrowRight': {
          e.preventDefault();
          const dir = e.key === 'ArrowLeft' ? -1 : 1;
          const current = state.replayAt ?? dateRange.from;
          const newMs = Math.min(
            Math.max(current.getTime() + rangeMs * STEP_FRACTION * dir, fromMs),
            toMs,
          );
          state.setReplayAt(new Date(newMs));
          break;
        }

        case 'Home':
          e.preventDefault();
          state.setReplayAt(dateRange.from);
          break;

        case 'End':
          e.preventDefault();
          state.setReplayAt(dateRange.to);
          break;

        case 'Escape':
          if (state.replayAt !== null) {
            e.preventDefault();
            state.resetReplay();
          }
          break;
      }
    }

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [dateRange, disabled]);

  // Clear scrubbing state on pointer up
  useEffect(() => {
    const onPointerUp = () => {
      setIsScrubbing(false);
    };
    window.addEventListener('pointerup', onPointerUp);
    return () => window.removeEventListener('pointerup', onPointerUp);
  }, [setIsScrubbing]);

  const fromMs = dateRange.from.getTime();
  const toMs = dateRange.to.getTime();
  const rangeMs = toMs - fromMs;

  const displayAt = replayAt ?? dateRange.from;
  const sliderValue =
    rangeMs > 0
      ? Math.round(((displayAt.getTime() - fromMs) / rangeMs) * SLIDER_MAX)
      : 0;
  const progressPct = `${(sliderValue / SLIDER_MAX) * 100}%`;

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const frac = Number(e.target.value) / SLIDER_MAX;
    const ms = Math.min(Math.max(fromMs + frac * rangeMs, fromMs), toMs);
    setReplayAt(new Date(ms));
  };

  const handlePlayPause = () => {
    if (isReplaying) {
      pauseReplay();
    } else {
      if (!replayAt) {
        setReplayAt(dateRange.from);
      }
      startReplay(dateRange);
    }
  };

  useEffect(() => {
    resetReplay();
  }, [dateRange.from, dateRange.to, resetReplay]);

  return (
    <div
      aria-disabled={disabled}
      onClickCapture={(e) => {
        if (!disabled) return;
        e.preventDefault();
        e.stopPropagation();
      }}
      className={`flex h-10 shrink-0 items-center gap-2 border-t border-gray-200 bg-white px-3 dark:border-gray-700 dark:bg-gray-800 ${disabled ? 'pointer-events-none opacity-40' : ''}`}
    >
      {/* Transport controls */}
      <div className="flex shrink-0 items-center gap-0.5">
        <Tooltip
          content="Skip to start"
          className="z-50 whitespace-nowrap rounded text-xs"
        >
          <button
            type="button"
            aria-label="Skip to start"
            onClick={resetReplay}
            className="flex h-7 w-7 items-center justify-center rounded text-gray-400/40 transition-colors hover:text-gray-500 dark:hover:text-gray-300"
          >
            <LuSkipBack className="h-3.5 w-3.5" />
          </button>
        </Tooltip>

        <Tooltip
          content={isReplaying ? 'Pause' : 'Play'}
          className="z-50 whitespace-nowrap rounded text-xs"
        >
          <div className="relative">
            {isReplaying && (
              <span className="pointer-events-none absolute inset-0 animate-ping rounded-full bg-psg-orange-800 opacity-30" />
            )}
            <button
              type="button"
              aria-label={isReplaying ? 'Pause' : 'Play'}
              onClick={handlePlayPause}
              className="relative flex h-7 w-7 items-center justify-center rounded-full bg-psg-orange-800 text-white transition-colors hover:bg-psg-orange-700"
            >
              {isReplaying ? (
                <LuPause className="h-4 w-4" />
              ) : (
                <LuPlay className="h-4 w-4" />
              )}
            </button>
          </div>
        </Tooltip>

        <Tooltip
          content="Skip to end"
          className="z-50 whitespace-nowrap rounded text-xs"
        >
          <button
            type="button"
            aria-label="Skip to end"
            onClick={() => {
              setReplayAt(dateRange.to);
              if (isReplaying) pauseReplay();
            }}
            className="flex h-7 w-7 items-center justify-center rounded text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
          >
            <LuSkipForward className="h-3.5 w-3.5" />
          </button>
        </Tooltip>
      </div>

      {/* Current timestamp */}
      <span className="shrink-0 text-xs tabular-nums text-gray-700 dark:text-gray-300">
        {!disabled
          ? `${fmtDate(displayAt)} ${fmtTime(displayAt)}`
          : `No data available for selected range`}
      </span>

      {/* Scrubber */}
      <div className="relative flex min-w-0 flex-1 items-center">
        <input
          type="range"
          min={0}
          max={SLIDER_MAX}
          value={sliderValue}
          onChange={handleSliderChange}
          onPointerDown={() => {
            if (isReplaying) pauseReplay();
            setIsScrubbing(true);
          }}
          disabled={disabled}
          onPointerUp={() => setIsScrubbing(false)}
          style={{ '--scrubber-pct': progressPct } as React.CSSProperties}
          className="replay-scrubber h-1.5 w-full cursor-pointer appearance-none rounded-full"
        />
        {/* Event tick marks */}
        {rangeMs > 0 && (
          <div
            className="pointer-events-none absolute inset-0 z-10"
            aria-hidden
          >
            {events
              .filter((ev) => filters[getEventLegendKey(ev)])
              .map((ev) => {
                const evMs = new Date(ev.startTime).getTime();
                const pct = ((evMs - fromMs) / rangeMs) * 100;
                if (pct < 0 || pct > 100) return null;
                const isPast = evMs <= displayAt.getTime();
                return (
                  <div
                    key={ev.id}
                    className="absolute rounded-sm"
                    style={{
                      left: `calc(${pct / 100} * (100% - 12px) + 6px)`,
                      top: '50%',
                      width: '2px',
                      height: isPast ? '8px' : '6px',
                      transform: 'translateX(-50%) translateY(-50%)',
                      backgroundColor:
                        LEGEND_EVENT_META[getEventLegendKey(ev)].color,
                      opacity: isPast ? 1 : 0.5,
                    }}
                  />
                );
              })}
          </div>
        )}
      </div>

      {/* End date */}
      <span className="shrink-0 text-xs tabular-nums text-gray-500 dark:text-gray-400">
        {!disabled && fmtDate(dateRange.to)}
      </span>

      {/* Speed selector */}
      <div className="flex shrink-0 overflow-hidden rounded-lg border border-gray-200 bg-white text-xs dark:border-gray-700 dark:bg-gray-800">
        {REPLAY_SPEED_OPTIONS.map((s) => (
          <button
            key={s}
            onClick={() => setReplaySpeed(s)}
            className={`px-2 py-1 transition-colors ${
              replaySpeed === s
                ? 'bg-psg-orange-800 text-white'
                : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'
            }`}
          >
            {s}×
          </button>
        ))}
      </div>

      <Tooltip
        content={followVessel ? 'Stop following vessel' : 'Follow vessel'}
      >
        <button
          type="button"
          onClick={() => setFollowVessel(!followVessel)}
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded transition-colors ${
            followVessel
              ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white'
              : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'
          }`}
        >
          <LuLocateFixed className="h-4 w-4" />
        </button>
      </Tooltip>

      <Tooltip
        content={pauseAtEvents ? "Don't pause at events" : 'Pause at events'}
      >
        <button
          type="button"
          onClick={() => setPauseAtEvents(!pauseAtEvents)}
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded transition-colors ${
            pauseAtEvents
              ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white'
              : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'
          }`}
        >
          <LuCalendarClock className="h-4 w-4" />
        </button>
      </Tooltip>

      {/* Detailed timeline toggle (rightmost, prototype order) */}
      <Tooltip
        content={
          ganttOpen ? 'Hide detailed timeline' : 'Show detailed timeline'
        }
      >
        <button
          onClick={onToggleGantt}
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded transition-colors ${
            ganttOpen
              ? 'bg-gray-200 text-gray-900 dark:bg-gray-600 dark:text-white'
              : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'
          }`}
        >
          <LuGanttChartSquare className="h-4 w-4" />
        </button>
      </Tooltip>
    </div>
  );
}
