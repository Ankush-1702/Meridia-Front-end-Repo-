import { FC } from 'react';
import { FaGauge } from 'react-icons/fa6';
import { LuArrowUpRight } from 'react-icons/lu';
import { MTI_INFO_URL } from '@/app/config/externalLinks';
import { useMTIScore } from '@/features/Vessels/hooks/useMTIScore';
import { Gauge } from '@/shared/ui/Gauge';

interface MTIScoreSectionProps {
  imo: string;
  hasAccess: boolean;
}

const MTIScoreSection: FC<MTIScoreSectionProps> = ({ imo, hasAccess }) => {
  const { score, loading, error, retry } = useMTIScore(hasAccess ? imo : '');

  if (!hasAccess) {
    return (
      <div className="mt-1 rounded-lg border border-gray-200 px-3 pb-2.5 pt-3 text-center dark:border-gray-700">
        <div className="flex justify-center">
          <FaGauge className="size-5 text-gray-600 dark:text-gray-400" />
        </div>
        <p className="mt-2 text-[13px] font-semibold text-gray-900 dark:text-gray-50">
          Unlock MTI Score
        </p>
        <p className="mt-1 text-[11px] leading-snug text-gray-700 dark:text-gray-300">
          A credit score for the seas — benchmark this vessel and prioritise
          your exposure at a glance.
        </p>
        <p className="mt-2.5 text-[11px] font-semibold text-gray-600 dark:text-gray-400">
          Available on request.
        </p>
        <div className="-mx-3 mt-2.5 h-px bg-gray-200 dark:bg-gray-700" />
        <div className="flex justify-center pt-2">
          <a
            href={MTI_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-4 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about MTI
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="rounded-lg border border-gray-200 px-3 pb-1.5 pt-3 dark:border-gray-700">
        <div className="h-20 animate-pulse rounded bg-gray-100 dark:bg-gray-900" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-2">
        <div className="rounded-lg px-3 py-2 text-center">
          <p className="text-[11px] leading-snug text-gray-600 dark:text-gray-400">
            MTI score is temporarily unavailable.
          </p>
        </div>
        <div className="space-y-2 pt-1">
          <button
            onClick={retry}
            className="flex w-full items-center justify-center rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            Retry
          </button>
          <a
            href={MTI_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about MTI
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  if (score == null || score === 'unscored') {
    return (
      <div className="space-y-2">
        <div className="rounded-lg px-3 py-2 text-center">
          <span className="inline-flex items-center rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600 dark:bg-gray-800 dark:text-gray-400">
            Unscored
          </span>
          <p className="mt-2 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
            No MTI score is available for this vessel yet.
          </p>
          <p className="mt-1 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
            Scores appear once there is enough activity data to assess it.
          </p>
        </div>
        <div className="mt-2.5 h-px bg-gray-200 dark:bg-gray-700" />
        <div className="pt-1">
          <a
            href={MTI_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about MTI
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2 px-2 pb-3 pt-0.5">
      <div className="flex justify-center rounded-lg px-3 py-2">
        <Gauge value={score} min={0} max={5} />
      </div>

      <div className="rounded-lg border border-gray-200 px-3 pb-1.5 pt-3 dark:border-gray-700">
        <p className="text-[11px] font-semibold text-gray-900 dark:text-gray-50">
          See what's behind the score
        </p>
        <p className="mt-1 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
          See the full score profile across vessel, voyage, reporting and
          sanctions — and how this vessel ranks against its class and the global
          fleet.
        </p>

        <p className="mt-2.5 text-[11px] font-semibold text-gray-600 dark:text-gray-400">
          Available on request.
        </p>
        <div className="-mx-3 mt-2.5 h-px bg-gray-200 dark:bg-gray-700" />
        <div className="pt-2">
          <a
            href={MTI_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about MTI
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default MTIScoreSection;
