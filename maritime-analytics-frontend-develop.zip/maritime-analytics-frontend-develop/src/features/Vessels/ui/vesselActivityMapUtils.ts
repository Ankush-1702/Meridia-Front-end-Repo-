import type { GeoJSONSourceSpecification, Map as MapboxMap } from 'mapbox-gl';
import {
  ActivityEvent,
  ActivityEventCategory,
  CATEGORY_META,
} from '@/features/Vessels/types/vesselActivityTypes';
import { fmtUtc } from '@/features/Vessels/utils/vesselActivityFormatters';
import { truncateTitle } from '@/shared/utils/formatUtils';

// ── Vessel position marker ────────────────────────────────────────────────────

export function buildVesselMarkerHTML(bearing: number): string {
  return `<div style="width:22px;height:22px;display:flex;align-items:center;justify-content:center;">
    <svg width="14" height="14" viewBox="0 0 10 10"
      style="transform:rotate(${bearing}deg);transform-origin:center;display:block;">
      <path d="M5 0 L10 10 L5 7 L0 10 Z" fill="#ec6436" stroke="white" stroke-width="1" stroke-linejoin="round"/>
    </svg>
  </div>`;
}

export function createPositionArrowEl(
  bearing: number,
  color: string,
): HTMLElement {
  const el = document.createElement('div');
  el.className = 'ais-pos-arrow';
  el.style.cssText = 'width:10px;height:10px;cursor:pointer;';
  el.innerHTML = `<div style="width:10px;height:10px;"><svg width="10" height="10" viewBox="0 0 10 10" style="transform:rotate(${bearing}deg);transform-origin:center;display:block;"><path d="M5 0 L10 10 L5 7 L0 10 Z" fill="${color}" stroke="rgba(255,255,255,0.55)" stroke-width="0.8" stroke-linejoin="round"/></svg></div>`;
  return el;
}

export function buildPositionPopupHTML(pos: {
  timestamp: string;
  status: string | null;
  speed: number | null;
  course: number | null;
  heading: number | null;
}): string {
  const rows = [
    pos.speed != null
      ? `<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#6b7280;">Speed</span><span style="color:#111827;">${pos.speed} kn</span></div>`
      : '',
    pos.course != null
      ? `<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#6b7280;">Course</span><span style="color:#111827;">${pos.course}°</span></div>`
      : '',
    pos.heading != null
      ? `<div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#6b7280;">Heading</span><span style="color:#111827;">${pos.heading}°</span></div>`
      : '',
  ]
    .filter(Boolean)
    .join('');
  return `<div style="padding:10px 12px;min-width:190px;font-family:inherit;font-size:11px;line-height:1.5;"><div style="border-bottom:1px solid #e5e7eb;padding-bottom:8px;margin-bottom:8px;"><div style="font-weight:500;color:#111827;">${pos.status ?? 'Unknown status'}</div><div style="font-size:10px;color:#6b7280;margin-top:2px;">${fmtUtc(pos.timestamp)}</div></div><div style="display:flex;flex-direction:column;gap:4px;">${rows}</div></div>`;
}

// ── Event markers ─────────────────────────────────────────────────────────────

type IconConfig = { d: string; viewBox: string; fill: boolean };

export const CATEGORY_ICON_PATHS: Record<ActivityEventCategory, IconConfig> = {
  port: {
    d: 'M12.971 352h32.394C67.172 454.735 181.944 512 288 512c106.229 0 220.853-57.38 242.635-160h32.394c10.691 0 16.045-12.926 8.485-20.485l-67.029-67.029c-4.686-4.686-12.284-4.686-16.971 0l-67.029 67.029c-7.56 7.56-2.206 20.485 8.485 20.485h35.146c-20.29 54.317-84.963 86.588-144.117 94.015V256h52c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-52v-5.47c37.281-13.178 63.995-48.725 64-90.518C384.005 43.772 341.605.738 289.37.01 235.723-.739 192 42.525 192 96c0 41.798 26.716 77.35 64 90.53V192h-52c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h52v190.015c-58.936-7.399-123.82-39.679-144.117-94.015h35.146c10.691 0 16.045-12.926 8.485-20.485l-67.029-67.029c-4.686-4.686-12.284-4.686-16.971 0L4.485 331.515C-3.074 339.074 2.28 352 12.971 352zM288 64c17.645 0 32 14.355 32 32s-14.355 32-32 32-32-14.355-32-32 14.355-32 32-32z',
    viewBox: '0 0 576 512',
    fill: true,
  },
  zone: {
    d: 'M368 80h32v32H368V80zM352 32c-17.7 0-32 14.3-32 32H128c0-17.7-14.3-32-32-32H32C14.3 32 0 46.3 0 64v64c0 17.7 14.3 32 32 32V352c-17.7 0-32 14.3-32 32v64c0 17.7 14.3 32 32 32H96c17.7 0 32-14.3 32-32H320c0 17.7 14.3 32 32 32h64c17.7 0 32-14.3 32-32V384c0-17.7-14.3-32-32-32V160c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32H352zM96 160c17.7 0 32-14.3 32-32H320c0 17.7 14.3 32 32 32V352c-17.7 0-32 14.3-32 32H128c0-17.7-14.3-32-32-32V160zM48 400H80v32H48V400zm320 32V400h32v32H368zM48 112V80H80v32H48z',
    viewBox: '0 0 448 512',
    fill: true,
  },
  ais_gap: {
    d: 'M216.88,207.93a12,12,0,1,1-17.76,16.14L147.78,167.6a56.06,56.06,0,0,0-52.71,7.1,12,12,0,0,1-14.14-19.4,79.35,79.35,0,0,1,41.92-15.12L103.51,118.9a104.18,104.18,0,0,0-40.06,19.55,12,12,0,0,1-14.9-18.81A128.46,128.46,0,0,1,85.61,99.21l-17.31-19a151.14,151.14,0,0,0-36.68,22.28A12,12,0,1,1,16.39,83.91a175.52,175.52,0,0,1,35-22.38L39.12,48.07A12,12,0,1,1,56.88,31.93ZM128,188a16,16,0,1,0,16,16A16,16,0,0,0,128,188Zm64.55-49.55a12,12,0,0,0,14.9-18.81A127.27,127.27,0,0,0,170,99.05a12,12,0,0,0-7.87,22.67A103.62,103.62,0,0,1,192.55,138.45Zm47.06-54.54A176.33,176.33,0,0,0,128,44c-3.94,0-7.93.13-11.86.39a12,12,0,1,0,1.59,24c3.4-.23,6.86-.34,10.27-.34a152.24,152.24,0,0,1,96.38,34.46,12,12,0,1,0,15.23-18.55Z',
    viewBox: '0 0 256 256',
    fill: true,
  },
  sts: {
    d: 'M326.612 185.391c59.747 59.809 58.927 155.698.36 214.59-.11.12-.24.25-.36.37l-67.2 67.2c-59.27 59.27-155.699 59.262-214.96 0-59.27-59.26-59.27-155.7 0-214.96l37.106-37.106c9.84-9.84 26.786-3.3 27.294 10.606.648 17.722 3.826 35.527 9.69 52.721 1.986 5.822.567 12.262-3.783 16.612l-13.087 13.087c-28.026 28.026-28.905 73.66-1.155 101.96 28.024 28.579 74.086 28.749 102.325.51l67.2-67.19c28.191-28.191 28.073-73.757 0-101.83-3.701-3.694-7.429-6.564-10.341-8.569a16.037 16.037 0 0 1-6.947-12.606c-.396-10.567 3.348-21.456 11.698-29.806l21.054-21.055c5.521-5.521 14.182-6.199 20.584-1.731a152.482 152.482 0 0 1 20.522 17.197zM467.547 44.449c-59.261-59.262-155.69-59.27-214.96 0l-67.2 67.2c-.12.12-.25.25-.36.37-58.566 58.892-59.387 154.781.36 214.59a152.454 152.454 0 0 0 20.521 17.196c6.402 4.468 15.064 3.789 20.584-1.731l21.054-21.055c8.35-8.35 12.094-19.239 11.698-29.806a16.037 16.037 0 0 0-6.947-12.606c-2.912-2.005-6.64-4.875-10.341-8.569-28.073-28.073-28.191-73.639 0-101.83l67.2-67.19c28.239-28.239 74.3-28.069 102.325.51 27.75 28.3 26.872 73.934-1.155 101.96l-13.087 13.087c-4.35 4.35-5.769 10.79-3.783 16.612 5.864 17.194 9.042 34.999 9.69 52.721.509 13.906 17.454 20.446 27.294 10.606l37.106-37.106c59.271-59.259 59.271-155.699.001-214.959z',
    viewBox: '0 0 512 512',
    fill: true,
  },
  discrepancy: {
    d: 'M569.517 440.013C587.975 472.007 564.806 512 527.94 512H48.054c-36.937 0-59.999-40.055-41.577-71.987L246.423 23.985c18.467-32.009 64.72-31.951 83.154 0l239.94 416.028zM288 354c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z',
    viewBox: '0 0 576 512',
    fill: true,
  },
  psc: {
    d: 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1zm-11 6 2 2 4-4',
    viewBox: '0 0 24 24',
    fill: false,
  },
};

function fmtDur(ms: number): string {
  const mins = Math.round(ms / 60_000);
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

export function buildMarkerHTML(
  category: ActivityEventCategory,
  color: string,
  isHighlighted: boolean,
): string {
  const cfg = CATEGORY_ICON_PATHS[category];
  const svgAttrs = cfg.fill
    ? `fill="white" stroke="none"`
    : `fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"`;
  if (isHighlighted) {
    const outer = 42;
    const inner = 26;
    const svgSize = Math.round(inner * 0.52);
    return `<div style="width:${outer}px;height:${outer}px;border-radius:50%;background:${color}30;border:2px solid ${color};display:flex;align-items:center;justify-content:center;"><div style="width:${inner}px;height:${inner}px;background:${color};border-radius:50%;border:1.5px solid rgba(255,255,255,0.9);box-shadow:0 2px 6px rgba(0,0,0,0.4);display:flex;align-items:center;justify-content:center;"><svg width="${svgSize}" height="${svgSize}" viewBox="${cfg.viewBox}" ${svgAttrs}><path d="${cfg.d}"/></svg></div></div>`;
  }
  const size = 22;
  const svgSize = Math.round(size * 0.55);
  return `<div style="width:${size}px;height:${size}px;background:${color};border-radius:50%;border:1px solid rgba(255,255,255,0.85);box-shadow:0 2px 4px rgba(0,0,0,0.25);display:flex;align-items:center;justify-content:center;"><svg width="${svgSize}" height="${svgSize}" viewBox="${cfg.viewBox}" ${svgAttrs}><path d="${cfg.d}"/></svg></div>`;
}

export function createMarkerEl(
  category: ActivityEventCategory,
  color: string,
  isHighlighted: boolean,
): HTMLElement {
  const el = document.createElement('div');
  el.style.cssText = 'cursor:pointer;';
  el.className = 'event-marker';
  el.dataset.category = category;
  el.dataset.color = color;
  el.innerHTML = buildMarkerHTML(category, color, isHighlighted);
  return el;
}

export function updateMarkerEl(el: HTMLElement, isHighlighted: boolean): void {
  const category = el.dataset.category as ActivityEventCategory;
  const color = el.dataset.color!;
  el.innerHTML = buildMarkerHTML(category, color, isHighlighted);
}

export function buildPopupHTML(event: ActivityEvent, color: string): string {
  const label = CATEGORY_META[event.category].label;
  const startMs = new Date(event.startTime).getTime();
  const endMs = event.endTime ? new Date(event.endTime).getTime() : null;
  const durMs = endMs ? endMs - startMs : 0;
  const subTypeFmt = event.subType
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());

  const endRow = event.endTime
    ? `<div style="display:flex;justify-content:space-between;gap:12px;"><span style="color:#6b7280;">Ended</span><span style="color:#111827;">${fmtUtc(event.endTime)}</span></div>`
    : '';
  const durRow =
    durMs > 60_000
      ? `<div style="display:flex;justify-content:space-between;gap:12px;"><span style="color:#6b7280;">Duration</span><span style="color:#111827;">${fmtDur(durMs)}</span></div>`
      : '';

  const detailBlock =
    event.category !== 'ais_gap'
      ? `<div style="margin-bottom:8px;">
    <div style="font-weight:500;color:#111827;">${truncateTitle(event.label, 30)}</div>
    ${subTypeFmt ? `<div style="font-size:10px;color:#6b7280;margin-top:2px;">${subTypeFmt}</div>` : ''}
  </div>`
      : '';
  const borderTop =
    event.category !== 'ais_gap'
      ? 'border-top:1px solid #e5e7eb;padding-top:8px;'
      : '';

  return `<div style="padding:10px 12px;min-width:200px;font-family:inherit;font-size:11px;line-height:1.5;">
  <div style="display:flex;align-items:center;gap:6px;border-bottom:1px solid #e5e7eb;padding-bottom:8px;margin-bottom:8px;">
    <div style="width:8px;height:8px;border-radius:50%;background:${color};flex-shrink:0;"></div>
    <span style="font-weight:600;color:#111827;">${label} Event</span>
  </div>
  ${detailBlock}<div style="${borderTop}display:flex;flex-direction:column;gap:4px;">
    <div style="display:flex;justify-content:space-between;gap:12px;"><span style="color:#6b7280;">Started</span><span style="color:#111827;">${fmtUtc(event.startTime)}</span></div>
    ${endRow}${durRow}
  </div>
</div>`;
}

// ── AIS gap lines ─────────────────────────────────────────────────────────────

export const GAP_LAYER_ID = 'ais-gap-lines';
export const GAP_SOURCE_ID = 'ais-gap-lines';

export type GapFeatureCollection = {
  type: 'FeatureCollection';
  features: Array<{
    type: 'Feature';
    properties: { id: string };
    geometry: { type: 'LineString'; coordinates: number[][] };
  }>;
};

export function applyGapLines(
  map: MapboxMap,
  geoJSON: GapFeatureCollection,
): void {
  if (map.getLayer(GAP_LAYER_ID)) map.removeLayer(GAP_LAYER_ID);
  if (map.getSource(GAP_SOURCE_ID)) map.removeSource(GAP_SOURCE_ID);
  if (geoJSON.features.length === 0) return;

  map.addSource(GAP_SOURCE_ID, {
    type: 'geojson',
    data: geoJSON as GeoJSONSourceSpecification['data'],
  });
  map.addLayer({
    id: GAP_LAYER_ID,
    type: 'line',
    source: GAP_SOURCE_ID,
    paint: {
      'line-color': CATEGORY_META.ais_gap.color,
      'line-width': 1.5,
      'line-dasharray': [6, 6],
      'line-opacity': 0.75,
      'line-emissive-strength': 1,
    },
  });
}
