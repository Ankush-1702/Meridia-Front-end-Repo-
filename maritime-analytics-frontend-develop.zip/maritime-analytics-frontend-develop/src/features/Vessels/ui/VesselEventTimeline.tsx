import { Spinner, TextInput, Tooltip } from 'flowbite-react';
import { useMemo, useRef, useState } from 'react';
import { FaAnchor, FaExclamationTriangle, FaLink } from 'react-icons/fa';
import { FaVectorSquare } from 'react-icons/fa6';
import {
  LuArrowDownNarrowWide,
  LuArrowUpNarrowWide,
  LuChevronRight,
  LuChevronsDownUp,
  LuChevronsUpDown,
  LuSearch,
  LuShieldCheck,
  LuX,
} from 'react-icons/lu';
import { PiWifiSlashBold } from 'react-icons/pi';
import { useShallow } from 'zustand/react/shallow';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  ActivityEventCategory,
  getEventLegendKey,
  LEGEND_EVENT_META,
} from '@/features/Vessels/types/vesselActivityTypes';
import {
  fmtDuration,
  fmtEventType,
} from '@/features/Vessels/utils/vesselActivityFormatters';
import { truncateTitle } from '@/shared/utils/formatUtils';

interface Props {
  events: ActivityEvent[];
  loading: boolean;
}

const CATEGORY_ICONS: Record<ActivityEventCategory, React.ReactNode> = {
  port: <FaAnchor className="h-2.5 w-2.5" />,
  zone: <FaVectorSquare className="h-2.5 w-2.5" />,
  ais_gap: <PiWifiSlashBold className="h-2.5 w-2.5" />,
  sts: <FaLink className="h-2.5 w-2.5" />,
  discrepancy: <FaExclamationTriangle className="h-2.5 w-2.5" />,
  psc: <LuShieldCheck className="h-2.5 w-2.5" />,
};

type EventVisibility = 'visible' | 'dimmed';

function computeEventVisibility(
  events: ActivityEvent[],
  replayAt: Date | null,
): Map<string, EventVisibility> {
  const map = new Map<string, EventVisibility>();
  if (replayAt === null) {
    events.forEach((ev) => map.set(ev.id, 'visible'));
    return map;
  }
  const cursorMs = replayAt.getTime();
  events.forEach((ev) => {
    const startMs = new Date(ev.startTime).getTime();
    map.set(ev.id, startMs <= cursorMs ? 'visible' : 'dimmed');
  });
  return map;
}

function groupByDay(events: ActivityEvent[]): Map<string, ActivityEvent[]> {
  const map = new Map<string, ActivityEvent[]>();
  events.forEach((e) => {
    if (!e.startTime) return;
    const day = new Date(e.startTime).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      timeZone: 'UTC',
    });
    const existing = map.get(day);
    if (existing) existing.push(e);
    else map.set(day, [e]);
  });
  return map;
}

function formatUtcTime(isoStr: string): string {
  return (
    new Date(isoStr).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'UTC',
    }) + ' UTC'
  );
}

export default function VesselEventTimeline({ events, loading }: Props) {
  const {
    filters,
    replayAt,
    highlightedEventId,
    setHighlightedEventId,
    setTimelinePanelOpen,
  } = useVesselActivityStore(
    useShallow((s) => ({
      filters: s.filters,
      replayAt: s.replayAt,
      highlightedEventId: s.highlightedEventId,
      setHighlightedEventId: s.setHighlightedEventId,
      setTimelinePanelOpen: s.setTimelinePanelOpen,
    })),
  );

  const [search, setSearch] = useState('');
  const [collapsedDays, setCollapsedDays] = useState<Set<string>>(new Set());
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const listRef = useRef<HTMLDivElement>(null);

  const visibleEvents = useMemo(
    () => events.filter((e) => filters[getEventLegendKey(e)]),
    [events, filters],
  );

  const filteredEvents = useMemo(
    () =>
      search.trim()
        ? visibleEvents.filter(
            (e) =>
              e.label.toLowerCase().includes(search.toLowerCase()) ||
              fmtEventType(e.subType)
                .toLowerCase()
                .includes(search.toLowerCase()),
          )
        : visibleEvents,
    [search, visibleEvents],
  );

  const sortedEvents = useMemo(
    () =>
      sortOrder === 'newest' ? filteredEvents : [...filteredEvents].reverse(),
    [filteredEvents, sortOrder],
  );

  const visibilityMap = useMemo(
    () => computeEventVisibility(sortedEvents, replayAt),
    [sortedEvents, replayAt],
  );

  const replayFilteredEvents = useMemo(
    () =>
      replayAt === null
        ? sortedEvents
        : sortedEvents.filter((ev) => visibilityMap.get(ev.id) !== 'dimmed'),
    [replayAt, sortedEvents, visibilityMap],
  );

  const grouped = useMemo(
    () => groupByDay(replayFilteredEvents),
    [replayFilteredEvents],
  );

  function toggleDay(day: string) {
    setCollapsedDays((prev) => {
      const next = new Set(prev);
      if (next.has(day)) next.delete(day);
      else next.add(day);
      return next;
    });
  }

  const allCollapsed = grouped.size > 0 && collapsedDays.size === grouped.size;

  function toggleAllDays() {
    if (allCollapsed) setCollapsedDays(new Set());
    else setCollapsedDays(new Set(Array.from(grouped.keys())));
  }

  return (
    <aside className="flex w-80 shrink-0 flex-col overflow-hidden border-l border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
      <div className="flex h-10 shrink-0 items-center border-b border-gray-200 px-3 dark:border-gray-700">
        <div className="flex flex-1 items-center gap-2">
          <span className="text-sm font-semibold text-gray-900 dark:text-white">
            Events Timeline
          </span>
          {!loading && filteredEvents.length > 0 && (
            <span className="inline-flex h-5 items-center rounded-full bg-gray-100 px-1.5 py-0 text-[10px] font-medium tabular-nums text-gray-500 dark:bg-gray-700 dark:text-gray-400">
              {replayAt !== null &&
              replayFilteredEvents.length < filteredEvents.length
                ? `${replayFilteredEvents.length} / ${filteredEvents.length}`
                : filteredEvents.length}
            </span>
          )}
        </div>
        <Tooltip
          content={`${sortOrder === 'newest' ? 'Oldest first' : 'Newest first'}`}
          placement={`bottom`}
          className="whitespace-nowrap rounded text-xs"
          arrow={false}
        >
          <button
            onClick={() =>
              setSortOrder((s) => (s === 'newest' ? 'oldest' : 'newest'))
            }
            className="flex h-7 w-7 shrink-0 cursor-pointer items-center justify-center rounded text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
            aria-label={
              sortOrder === 'newest'
                ? 'Switch to oldest first'
                : 'Switch to newest first'
            }
          >
            {sortOrder === 'newest' ? (
              <LuArrowUpNarrowWide className="h-3.5 w-3.5" />
            ) : (
              <LuArrowDownNarrowWide className="h-3.5 w-3.5" />
            )}
          </button>
        </Tooltip>
        <Tooltip
          content={`Hide Event Timeline`}
          placement={`bottom`}
          className="whitespace-nowrap rounded text-xs"
          arrow={false}
        >
          <button
            onClick={() => setTimelinePanelOpen(false)}
            className="ml-1 flex h-7 w-7 shrink-0 cursor-pointer items-center justify-center rounded text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
            aria-label="Hide event timeline"
          >
            <LuX className="h-4 w-4" />
          </button>
        </Tooltip>
      </div>

      <div className="flex shrink-0 items-center border-b border-gray-200 dark:border-gray-700">
        <TextInput
          icon={LuSearch}
          type="text"
          placeholder="Search events..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          sizing="sm"
          style={{ borderRadius: 0 }}
          theme={{
            field: {
              base: 'relative flex-1',
              input: {
                base: 'block w-full disabled:cursor-not-allowed disabled:opacity-50 rounded-none outline-none',
                sizes: { sm: 'h-8 py-0 pr-2 text-xs' },
                colors: {
                  gray: 'border-0 bg-gray-50 text-gray-900 placeholder:text-gray-400 focus:ring-0 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400',
                },
                withIcon: { on: 'pl-8' },
              },
              icon: {
                base: 'pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3',
                svg: 'h-3 w-3 text-gray-400 dark:text-gray-500',
              },
            },
          }}
          className="flex-1"
        />
        <div className="shrink-0 border-l border-gray-200 dark:border-gray-700">
          <button
            onClick={toggleAllDays}
            aria-label={allCollapsed ? 'Expand all days' : 'Collapse all days'}
            className="flex h-8 w-8 cursor-pointer items-center justify-center text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
          >
            {allCollapsed ? (
              <Tooltip
                content={`Expand`}
                placement={`top`}
                className="whitespace-nowrap rounded text-xs"
                arrow={false}
              >
                <LuChevronsUpDown className="h-3.5 w-3.5" />
              </Tooltip>
            ) : (
              <Tooltip
                content={`Collapse`}
                placement={`top`}
                className="whitespace-nowrap rounded text-xs"
                arrow={false}
              >
                <LuChevronsDownUp className="h-3.5 w-3.5" />
              </Tooltip>
            )}
          </button>
        </div>
      </div>

      <div ref={listRef} className="flex-1 overflow-y-auto overflow-x-hidden">
        {loading && (
          <div className="flex h-full justify-center px-3 py-4">
            <Spinner size="sm" color="psgPrimary" light />
          </div>
        )}

        {!loading && filteredEvents.length === 0 && (
          <div className="px-3 py-4 text-center text-xs text-gray-400 dark:text-gray-500">
            {search ? 'No matching events' : 'No events in selected range'}
          </div>
        )}

        {!loading &&
          replayAt !== null &&
          filteredEvents.length > 0 &&
          replayFilteredEvents.length === 0 && (
            <div className="px-3 py-6 text-center text-xs text-gray-400 dark:text-gray-500">
              Replay active. Events will appear here as they occur.
            </div>
          )}

        {!loading &&
          Array.from(grouped.entries()).map(([day, dayEvents]) => {
            const collapsed = collapsedDays.has(day);
            return (
              <div key={day}>
                <button
                  onClick={() => toggleDay(day)}
                  aria-expanded={!collapsed}
                  className="sticky top-0 z-20 flex w-full cursor-pointer items-center gap-2 bg-white px-4 py-2.5 text-left transition-colors hover:bg-gray-50 dark:bg-gray-800 dark:hover:bg-gray-700/50"
                >
                  <span className="shrink-0 text-xs font-semibold text-gray-800 dark:text-gray-200">
                    {day}
                  </span>
                  <div className="mx-1 h-px flex-1 bg-gray-200 dark:bg-gray-600" />
                  <span className="inline-flex h-4 items-center rounded-full bg-gray-100 px-1.5 py-0 text-[10px] font-medium tabular-nums text-gray-500 dark:bg-gray-700 dark:text-gray-400">
                    {dayEvents.length}
                  </span>
                  <Tooltip
                    content={`${collapsed ? 'Expand' : 'Collapse'}`}
                    placement={collapsed ? 'right' : 'bottom'}
                    className="whitespace-nowrap rounded text-xs"
                    arrow={false}
                  >
                    <LuChevronRight
                      className={`h-3 w-3 shrink-0 text-gray-400 transition-transform dark:text-gray-500${collapsed ? '' : ' rotate-90'}`}
                      aria-hidden="true"
                    />
                  </Tooltip>
                </button>

                {!collapsed &&
                  dayEvents.map((event, idx) => {
                    const legendMeta =
                      LEGEND_EVENT_META[getEventLegendKey(event)];
                    const nextEvent = dayEvents[idx + 1];
                    const gapMs = nextEvent
                      ? Math.abs(
                          new Date(event.startTime).getTime() -
                            new Date(nextEvent.startTime).getTime(),
                        )
                      : 0;
                    const gapLabel = gapMs > 60000 ? fmtDuration(gapMs) : '';
                    const isHighlighted = highlightedEventId === event.id;

                    return (
                      <div key={event.id}>
                        <div className="relative border-b border-gray-100 dark:border-gray-700/50">
                          <div
                            role="button"
                            tabIndex={0}
                            className={`relative flex items-center gap-2.5 px-3 py-2 transition-colors ${
                              isHighlighted
                                ? 'bg-gray-100/80 dark:bg-gray-700/40'
                                : 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/30'
                            }`}
                            style={
                              isHighlighted
                                ? {
                                    borderLeft: `2px solid ${legendMeta.color}`,
                                    paddingLeft: '10px',
                                  }
                                : undefined
                            }
                            onClick={() =>
                              setHighlightedEventId(
                                highlightedEventId === event.id
                                  ? null
                                  : event.id,
                              )
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                setHighlightedEventId(
                                  highlightedEventId === event.id
                                    ? null
                                    : event.id,
                                );
                              }
                            }}
                          >
                            <div
                              className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white"
                              style={{ backgroundColor: legendMeta.color }}
                            >
                              {CATEGORY_ICONS[event.category]}
                            </div>

                            <div className="min-w-0 flex-1">
                              <Tooltip
                                content={event.label}
                                placement={`bottom`}
                                className="rounded text-xs"
                                arrow={false}
                              >
                                <p className="text-xs font-medium leading-tight text-gray-800 dark:text-gray-100">
                                  {fmtEventType(event.subType)}
                                </p>
                                {event.label && (
                                  <p className="text-[10px] leading-tight text-gray-400 dark:text-gray-500">
                                    {truncateTitle(event.label, 30)}
                                  </p>
                                )}
                              </Tooltip>
                            </div>

                            <span className="shrink-0 text-[10px] tabular-nums text-gray-400 dark:text-gray-500">
                              {formatUtcTime(event.startTime)}
                            </span>
                          </div>
                        </div>

                        {gapLabel && (
                          <div className="flex items-center gap-2 border-b border-gray-100 bg-gray-50 px-3 py-1 dark:border-gray-700/50 dark:bg-gray-700/30">
                            <span className="shrink-0 text-[10px] tabular-nums text-gray-300 dark:text-gray-600">
                              {gapLabel}
                            </span>
                            <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700" />
                          </div>
                        )}
                      </div>
                    );
                  })}
              </div>
            );
          })}
      </div>
    </aside>
  );
}
