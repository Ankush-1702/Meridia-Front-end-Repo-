import { Tooltip } from 'flowbite-react';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  ActivityEventCategory,
  CATEGORY_META,
  getEventLegendKey,
  LEGEND_EVENT_META,
} from '@/features/Vessels/types/vesselActivityTypes';
import { CATEGORY_ICON_PATHS } from '@/features/Vessels/ui/vesselActivityMapUtils';
import {
  fmtEventType,
  fmtHHMM,
} from '@/features/Vessels/utils/vesselActivityFormatters';

const PAUSE_DURATION_MS = 4500;

function CategoryIcon({
  category,
  color,
  withRing = false,
}: {
  category: ActivityEventCategory;
  color: string;
  withRing?: boolean;
}) {
  const cfg = CATEGORY_ICON_PATHS[category];
  const svgProps = cfg.fill
    ? { fill: 'white', stroke: 'none' }
    : {
        fill: 'none',
        stroke: 'white',
        strokeWidth: 2.2,
        strokeLinecap: 'round' as const,
        strokeLinejoin: 'round' as const,
      };
  const svgSize = Math.round(20 * 0.44); // ~9px for 20px circle

  return (
    <div
      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full${withRing ? ' ring-1 ring-white dark:ring-gray-800' : ''}`}
      style={{ background: color }}
    >
      <svg width={svgSize} height={svgSize} viewBox={cfg.viewBox} {...svgProps}>
        <path d={cfg.d} />
      </svg>
    </div>
  );
}

function EventRow({ event }: { event: ActivityEvent }) {
  const color = LEGEND_EVENT_META[getEventLegendKey(event)].color;
  const label = event.subType
    ? fmtEventType(event.subType)
    : CATEGORY_META[event.category].label;
  const timeStr = fmtHHMM(event.startTime);

  return (
    <div className="flex items-center gap-2.5 px-3 py-2">
      <CategoryIcon category={event.category} color={color} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-medium leading-tight text-gray-900 dark:text-gray-100">
          {label}
        </p>
        <p className="truncate text-[10px] leading-tight text-gray-500 dark:text-gray-400">
          {event.label}
        </p>
      </div>
      <span className="shrink-0 text-[10px] tabular-nums text-gray-500 dark:text-gray-400">
        {timeStr}
      </span>
    </div>
  );
}

export default function ReplayEventOverlay() {
  const replayAnnouncedEvent = useVesselActivityStore(
    (s) => s.replayAnnouncedEvent,
  );
  const replayCountdownPaused = useVesselActivityStore(
    (s) => s.replayCountdownPaused,
  );
  const setReplayAnnouncedEvent = useVesselActivityStore(
    (s) => s.setReplayAnnouncedEvent,
  );
  const setReplayCountdownPaused = useVesselActivityStore(
    (s) => s.setReplayCountdownPaused,
  );

  if (!replayAnnouncedEvent || replayAnnouncedEvent.length === 0) return null;

  const legendKeys = [
    ...new Set(replayAnnouncedEvent.map((e) => getEventLegendKey(e))),
  ];
  const headerLabel =
    replayAnnouncedEvent.length === 1
      ? fmtEventType(replayAnnouncedEvent[0].subType) ||
        LEGEND_EVENT_META[getEventLegendKey(replayAnnouncedEvent[0])].label
      : `${replayAnnouncedEvent.length} events`;
  const groupSubtext =
    replayAnnouncedEvent.length === 1 ? replayAnnouncedEvent[0].label : null;

  // Sort events by startTime ascending
  const sorted = [...replayAnnouncedEvent].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime(),
  );

  return (
    <div
      className="pointer-events-auto absolute left-[105%] top-0 z-[1000] w-80 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-2xl dark:border-gray-700 dark:bg-gray-800"
      style={{
        animation: 'replay-overlay-in 0.35s cubic-bezier(0.16,1,0.3,1)',
      }}
    >
      {/* Countdown bar */}
      <div className="h-1 overflow-hidden bg-gray-200 dark:bg-gray-700">
        <div
          className="h-full bg-psg-orange-800"
          style={{
            animation: `replay-countdown ${PAUSE_DURATION_MS}ms linear forwards`,
            animationPlayState: replayCountdownPaused ? 'paused' : 'running',
          }}
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 bg-white px-3 py-2 dark:border-gray-700 dark:bg-gray-800">
        <div className="flex min-w-0 items-center gap-2">
          {/* Category icon stack — ring is on the circle itself so -space-x-1 works correctly */}
          <div className="flex shrink-0 -space-x-1">
            {legendKeys.slice(0, 3).map((key) => {
              const ev = replayAnnouncedEvent.find(
                (e) => getEventLegendKey(e) === key,
              )!;
              return (
                <CategoryIcon
                  key={key}
                  category={ev.category}
                  color={LEGEND_EVENT_META[key].color}
                  withRing
                />
              );
            })}
          </div>
          <div className="min-w-0">
            <span className="block truncate text-sm font-bold leading-none text-gray-700 dark:text-gray-200">
              {headerLabel}
            </span>
            {groupSubtext && (
              <span className="text-[10px] leading-none text-gray-500 dark:text-gray-400">
                {groupSubtext}
              </span>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex shrink-0 items-center gap-1">
          <Tooltip
            content={
              replayCountdownPaused ? 'Resume countdown' : 'Pause countdown'
            }
          >
            <button
              onClick={() => setReplayCountdownPaused(!replayCountdownPaused)}
              className="rounded-md p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
              aria-label={
                replayCountdownPaused ? 'Resume countdown' : 'Pause countdown'
              }
            >
              {replayCountdownPaused ? (
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M8 5v14l11-7z" />
                </svg>
              ) : (
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
                </svg>
              )}
            </button>
          </Tooltip>
          <Tooltip content="Dismiss">
            <button
              onClick={() => setReplayAnnouncedEvent(null)}
              className="rounded-md p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-700 dark:hover:text-gray-200"
              aria-label="Dismiss"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>
          </Tooltip>
        </div>
      </div>

      {/* Event list */}
      <div className="max-h-56 divide-y divide-gray-100 overflow-y-auto dark:divide-gray-700/50">
        {sorted.map((event) => (
          <EventRow key={event.id} event={event} />
        ))}
      </div>
    </div>
  );
}
