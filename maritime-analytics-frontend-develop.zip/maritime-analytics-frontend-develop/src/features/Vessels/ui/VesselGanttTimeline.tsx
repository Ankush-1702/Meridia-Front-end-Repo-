import { Tooltip } from 'flowbite-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { LuChevronRight } from 'react-icons/lu';
import { useLatestVesselPosition } from '@/features/Vessels/hooks/useLatestVesselPosition';
import {
  useVesselActivityStore,
  GanttGroupMode,
  DateRange,
} from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  CATEGORY_META,
} from '@/features/Vessels/types/vesselActivityTypes';
import {
  Bar,
  BarReplayState,
  buildRowsAndBars,
  buildSpanEvents,
  formatDuration,
  formatDurationShort,
  getBarReplayState,
  HEADER_H,
  LANE_ROW_H,
  MIN_BAR_PX,
  REPLAY_FUTURE_BAR_OPACITY,
  Row,
  SIDEBAR_W,
  TICK_W,
  getTicks,
} from '@/features/Vessels/ui/ganttTimelineHelpers';
import { fmtUtc } from '@/features/Vessels/utils/vesselActivityFormatters';
import { truncateTitle } from '@/shared/utils/formatUtils';

interface Props {
  events: ActivityEvent[];
  dateRange: DateRange;
  height: number;
  imo?: string;
}

export default function VesselGanttTimeline({
  events,
  dateRange,
  height,
  imo,
}: Props) {
  const {
    filters,
    ganttGroupMode,
    setGanttGroupMode,
    replayAt,
    highlightedEventId,
    setHighlightedEventId,
  } = useVesselActivityStore();

  const outerRef = useRef<HTMLDivElement>(null);
  // The single scrollable body — scrolls both X and Y
  const bodyScrollRef = useRef<HTMLDivElement>(null);
  // Header tick strip — x-scroll driven by body onScroll
  const headerScrollRef = useRef<HTMLDivElement>(null);

  const [containerW, setContainerW] = useState(800);
  const [hoveredBar, setHoveredBar] = useState<Bar | null>(null);
  const [tooltipAnchor, setTooltipAnchor] = useState({ x: 0, y: 0 });
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(
    new Set(),
  );

  useEffect(() => {
    const update = () => {
      const el = outerRef.current;
      if (!el) return;
      const w = el.getBoundingClientRect().width;
      if (w > 0) setContainerW(w);
    };
    update();
    const ro = new ResizeObserver(update);
    if (outerRef.current) ro.observe(outerRef.current);
    window.addEventListener('resize', update);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', update);
    };
  }, []);

  useEffect(() => {
    setCollapsedGroups(new Set());
  }, [ganttGroupMode]);

  const ganttEvents = useMemo(() => buildSpanEvents(events), [events]);

  const { rows, bars, minMs, maxMs } = useMemo(
    () => buildRowsAndBars(ganttEvents, filters, ganttGroupMode),
    [ganttEvents, filters, ganttGroupMode],
  );

  const { visibleRows, groupChildCounts } = useMemo(() => {
    const childCounts = new Map<string, number>();
    const visible: Row[] = [];
    let currentGroup: string | null = null;
    for (const row of rows) {
      if (row.isGroupHeader) {
        currentGroup = row.id;
        childCounts.set(row.id, 0);
        visible.push(row);
      } else {
        if (currentGroup !== null) {
          childCounts.set(
            currentGroup,
            (childCounts.get(currentGroup) ?? 0) + 1,
          );
        }
        if (currentGroup === null || !collapsedGroups.has(currentGroup)) {
          visible.push(row);
        }
      }
    }
    return { visibleRows: visible, groupChildCounts: childCounts };
  }, [rows, collapsedGroups]);

  const CANVAS_PAD_PX = 60;

  const { viewStart, viewEnd } = useMemo(() => {
    const startMs = dateRange.from.getTime();
    const endMs = dateRange.to.getTime();
    if (rows.length === 0 || minMs === Infinity) {
      return { viewStart: startMs, viewEnd: endMs };
    }
    const pad = (maxMs - minMs) * 0.045 || 3_600_000;
    return {
      viewStart: startMs,
      viewEnd: Math.max(maxMs, endMs) + pad,
    };
  }, [rows, minMs, maxMs, dateRange]);

  const contentWidth = useMemo(() => {
    const availW = Math.max(containerW - SIDEBAR_W, 400);
    const spanDays = (viewEnd - viewStart) / 86_400_000;
    const pxPerDay =
      spanDays <= 7
        ? 200
        : spanDays <= 30
          ? 120
          : spanDays <= 90
            ? 60
            : spanDays <= 365
              ? 30
              : 16;
    return Math.max(availW, Math.ceil(spanDays * pxPerDay) + CANVAS_PAD_PX * 2);
  }, [viewStart, viewEnd, containerW]);

  const msPerPx = useMemo(
    () => (viewEnd - viewStart) / Math.max(contentWidth - 2 * CANVAS_PAD_PX, 1),
    [viewStart, viewEnd, contentWidth],
  );

  const { position: latestPos } = useLatestVesselPosition(imo ?? '');

  const etaX = useMemo(() => {
    if (!latestPos?.eta) return null;
    const d = new Date(latestPos.eta);
    if (isNaN(d.getTime()) || d.getUTCFullYear() < 2000) return null;
    const ms = d.getTime();
    if (ms < viewStart || ms > viewEnd) return null;
    return Math.round((ms - viewStart) / msPerPx) + CANVAS_PAD_PX;
  }, [latestPos, viewStart, viewEnd, msPerPx]);
  const etaDestination = latestPos?.destination?.trim() ?? null;
  const destinationTooltip = latestPos?.destinationTooltip ?? etaDestination;

  const playheadX = useMemo(() => {
    if (!replayAt) return null;
    return (
      Math.round((replayAt.getTime() - viewStart) / msPerPx) + CANVAS_PAD_PX
    );
  }, [replayAt, viewStart, msPerPx]);

  const rowTops = useMemo(() => {
    const map = new Map<string, number>();
    let y = 0;
    for (const row of visibleRows) {
      map.set(row.id, y);
      y += row.height;
    }
    return map;
  }, [visibleRows]);

  const totalH = visibleRows.reduce((sum, r) => sum + r.height, 0);

  const ticks = useMemo(
    () => getTicks(viewStart, viewEnd, contentWidth),
    [viewStart, viewEnd, contentWidth],
  );

  function xOf(ms: number) {
    return Math.round((ms - viewStart) / msPerPx) + CANVAS_PAD_PX;
  }

  // Only sync the header tick strip horizontally; vertical is handled natively
  function handleBodyScroll(e: React.UIEvent<HTMLDivElement>) {
    if (headerScrollRef.current) {
      headerScrollRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  }

  if (visibleRows.length === 0) {
    return (
      <div
        className="flex items-center justify-center border-t border-gray-200 bg-white text-sm text-gray-500 dark:border-gray-700 dark:bg-gray-800"
        style={{ height }}
      >
        No events to display
      </div>
    );
  }

  const bodyH = height - HEADER_H;

  return (
    <div
      ref={outerRef}
      className="relative flex select-none flex-col overflow-hidden border-t border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800"
      style={{ height, width: '100%', maxWidth: '100%' }}
    >
      {/* ── Header ────────────────────────────────────────────────────── */}
      <div
        className="flex shrink-0 border-b border-gray-200 dark:border-gray-700"
        style={{ height: HEADER_H }}
      >
        {/* Sidebar header — never moves */}
        <div
          className="flex shrink-0 items-center border-r border-gray-200 bg-gray-50/40 px-2 dark:border-gray-700 dark:bg-gray-700/20"
          style={{ width: SIDEBAR_W }}
        >
          <div className="flex items-center gap-1.5">
            <span className="whitespace-nowrap text-[10px] font-normal text-gray-500 dark:text-gray-400">
              Group by
            </span>
            <div className="flex overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
              {(['by-event-type', 'by-location'] as GanttGroupMode[]).map(
                (mode) => (
                  <button
                    key={mode}
                    onClick={() => setGanttGroupMode(mode)}
                    className={`px-2 py-1 text-[10px] font-semibold transition-colors focus-visible:outline-none ${
                      ganttGroupMode === mode
                        ? 'bg-psg-orange-800 text-white'
                        : 'bg-white text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-200'
                    }`}
                  >
                    {mode === 'by-event-type' ? 'Type' : 'Location'}
                  </button>
                ),
              )}
            </div>
          </div>
        </div>

        {/* Tick strip — x-scroll driven by body onScroll */}
        <div
          ref={headerScrollRef}
          className="relative flex-1 overflow-hidden bg-gray-50/20 dark:bg-gray-700/10"
        >
          <div className="relative h-full" style={{ width: contentWidth }}>
            {ticks.map(({ ms, label }) => {
              const x = xOf(ms);
              if (x < -60 || x > contentWidth + 60) return null;
              return (
                <div
                  key={ms}
                  className="absolute bottom-1 flex flex-col items-center"
                  style={{ left: x, transform: 'translateX(-50%)' }}
                >
                  <span className="whitespace-nowrap text-[10px] text-gray-500 dark:text-gray-400">
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Body — single scrollable region for both X and Y ──────────── */}
      {/*
        Layout: a grid with a sticky sidebar column and a scrolling canvas
        column. The entire grid scrolls as one unit (both axes), meaning the
        sidebar rows scroll vertically with the bars automatically. The sidebar
        column is `position: sticky; left: 0` so it never disappears
        horizontally while still moving vertically with the rest of the grid.
      */}
      <div
        ref={bodyScrollRef}
        className="flex-1 overflow-x-auto overflow-y-auto"
        style={{ height: bodyH }}
        onScroll={handleBodyScroll}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: `${SIDEBAR_W}px ${contentWidth}px`,
            width: SIDEBAR_W + contentWidth,
            minHeight: totalH,
          }}
        >
          {/* Sidebar — sticky on X so labels stay visible while scrolling horizontally */}
          <div
            className="sticky left-0 z-10 border-r border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800"
            style={{ height: totalH }}
          >
            {visibleRows.map((row) => {
              if (row.isGroupHeader) {
                const isCollapsed = collapsedGroups.has(row.id);
                const childCount = groupChildCounts.get(row.id) ?? 0;
                const color = CATEGORY_META[row.category].color;
                return (
                  <div
                    key={row.id}
                    role="button"
                    tabIndex={0}
                    className="flex cursor-pointer items-center gap-1 border-b border-gray-200/40 px-2 dark:border-gray-700/40"
                    style={{ height: row.height, background: `${color}18` }}
                    onClick={() =>
                      setCollapsedGroups((prev) => {
                        const next = new Set(prev);
                        if (next.has(row.id)) next.delete(row.id);
                        else next.add(row.id);
                        return next;
                      })
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        setCollapsedGroups((prev) => {
                          const next = new Set(prev);
                          if (next.has(row.id)) next.delete(row.id);
                          else next.add(row.id);
                          return next;
                        });
                      }
                    }}
                  >
                    <LuChevronRight
                      className={`h-2.5 w-2.5 shrink-0 transition-transform ${isCollapsed ? '' : 'rotate-90'}`}
                      style={{ color }}
                    />
                    <span
                      className="flex-1 truncate text-[9px] font-bold uppercase tracking-widest"
                      style={{ color }}
                    >
                      {row.label}
                    </span>
                    {isCollapsed && (
                      <span
                        className="shrink-0 text-[9px] font-bold"
                        style={{ color }}
                      >
                        {childCount}
                      </span>
                    )}
                  </div>
                );
              }

              const isRowHighlighted = bars.some(
                (b) => b.rowId === row.id && b.eventId === highlightedEventId,
              );
              const rowColor = isRowHighlighted
                ? CATEGORY_META[row.category].color
                : undefined;

              return (
                <Tooltip
                  content={row.label}
                  placement={`bottom`}
                  className="rounded text-xs"
                  key={row.id}
                >
                  <div
                    className={`flex items-center truncate border-b border-gray-200/20 text-xs dark:border-gray-700/20 ${isRowHighlighted ? '' : 'text-gray-500 dark:text-gray-400'}`}
                    style={{
                      height: row.height,
                      paddingLeft: row.isIndented ? 20 : 8,
                      fontWeight: isRowHighlighted ? 600 : 400,
                      color: isRowHighlighted ? rowColor : undefined,
                      background: isRowHighlighted
                        ? `${rowColor}18`
                        : 'transparent',
                    }}
                  >
                    {truncateTitle(row.label)}
                  </div>
                </Tooltip>
              );
            })}
          </div>

          {/* Canvas */}
          <div className="relative" style={{ height: totalH }}>
            {/* Playhead */}
            {playheadX !== null && (
              <div
                className="pointer-events-none absolute top-0 z-20"
                style={{
                  left: playheadX - 1,
                  width: 1.5,
                  height: totalH,
                  background: '#ec6436',
                }}
              />
            )}

            {/* ETA milestone */}
            {etaX !== null && (
              <div
                className="pointer-events-none absolute top-0"
                style={{ left: etaX, width: 1, height: totalH, zIndex: 18 }}
              >
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage:
                      'repeating-linear-gradient(to bottom, #F59E0B 0, #F59E0B 4px, transparent 4px, transparent 8px)',
                  }}
                />
                <div
                  className="absolute left-1.5 top-1 flex items-center gap-1 whitespace-nowrap rounded border px-1 py-0.5"
                  style={{ backgroundColor: '#FFFBEB', borderColor: '#FDE68A' }}
                >
                  <span
                    className="text-[9px] font-semibold uppercase tracking-wide"
                    style={{ color: '#B45309' }}
                  >
                    ETA
                  </span>
                  {etaDestination && (
                    <Tooltip
                      content={destinationTooltip}
                      placement="bottom"
                      className="max-w-fit whitespace-nowrap rounded text-xs"
                      arrow={false}
                    >
                      <span
                        className="max-w-16 truncate text-[9px]"
                        style={{ color: '#D97706' }}
                      >
                        {etaDestination}
                      </span>
                    </Tooltip>
                  )}
                </div>
              </div>
            )}

            {/* Grid lines */}
            {ticks.map(({ ms }) => {
              const x = xOf(ms);
              return (
                <div
                  key={`grid-${ms}`}
                  className="absolute bottom-0 top-0 w-px bg-gray-200/25 dark:bg-gray-700/25"
                  style={{ left: x }}
                />
              );
            })}

            {/* Row backgrounds */}
            {visibleRows.map((row) => {
              const top = rowTops.get(row.id) ?? 0;
              const color = CATEGORY_META[row.category].color;
              return (
                <div
                  key={`row-${row.id}`}
                  className="absolute left-0 right-0 border-b border-gray-200/20 dark:border-gray-700/20"
                  style={{
                    top,
                    height: row.height,
                    background: row.isGroupHeader
                      ? `${color}18`
                      : 'transparent',
                  }}
                />
              );
            })}

            {/* Highlighted row strip */}
            {bars.map((bar) => {
              if (bar.eventId !== highlightedEventId) return null;
              const top = rowTops.get(bar.rowId);
              if (top === undefined) return null;
              return (
                <div
                  key={`hl-row-${bar.eventId}`}
                  className="pointer-events-none absolute left-0 right-0"
                  style={{
                    top,
                    height: LANE_ROW_H,
                    background: `${bar.color}22`,
                    borderTop: `1px solid ${bar.color}80`,
                    borderBottom: `1px solid ${bar.color}80`,
                    zIndex: 0,
                  }}
                />
              );
            })}

            {/* Bars and tick marks */}
            {bars.map((bar) => {
              const top = rowTops.get(bar.rowId);
              if (top === undefined) return null;

              const x1 = xOf(bar.startMs);
              const isHighlighted = highlightedEventId === bar.eventId;
              const cursorMs = replayAt?.getTime() ?? Infinity;
              const replayState: BarReplayState =
                replayAt !== null
                  ? getBarReplayState(bar.startMs, bar.endMs, cursorMs)
                  : 'normal';

              if (bar.endMs === null) {
                if (x1 < -TICK_W || x1 > contentWidth + TICK_W) return null;
                return (
                  <div
                    key={bar.eventId}
                    role="button"
                    tabIndex={0}
                    aria-pressed={isHighlighted}
                    className="absolute cursor-pointer"
                    style={{
                      top: top + 3,
                      left: x1 - Math.floor(TICK_W / 2),
                      width: TICK_W,
                      height: LANE_ROW_H - 6,
                      background: isHighlighted ? '#fff' : bar.color,
                      borderRadius: 2,
                      border: isHighlighted
                        ? `2px solid ${bar.color}`
                        : undefined,
                      opacity:
                        replayState === 'future'
                          ? REPLAY_FUTURE_BAR_OPACITY
                          : 1,
                      zIndex: isHighlighted ? 10 : 2,
                    }}
                    onMouseEnter={(e) => {
                      setHoveredBar(bar);
                      const r = e.currentTarget.getBoundingClientRect();
                      setTooltipAnchor({ x: r.left + r.width / 2, y: r.top });
                    }}
                    onMouseLeave={() => setHoveredBar(null)}
                    onClick={() =>
                      setHighlightedEventId(
                        highlightedEventId === bar.eventId ? null : bar.eventId,
                      )
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        setHighlightedEventId(
                          highlightedEventId === bar.eventId
                            ? null
                            : bar.eventId,
                        );
                      }
                    }}
                  />
                );
              }

              const x2 = xOf(bar.endMs);
              const barW = Math.max(x2 - x1, MIN_BAR_PX);
              if (x2 < 0 || x1 > contentWidth) return null;

              const durLabel = formatDurationShort(bar.endMs - bar.startMs);
              const displayLabel =
                barW > 80
                  ? `${durLabel} ${bar.locationLabel}`.trim()
                  : barW > 36
                    ? durLabel
                    : '';

              return (
                <div
                  key={bar.eventId}
                  role="button"
                  tabIndex={0}
                  aria-pressed={isHighlighted}
                  className="absolute cursor-pointer truncate px-1.5 text-[10px] font-medium"
                  style={{
                    top: top + 4,
                    left: Math.max(x1, 0),
                    width: barW,
                    height: LANE_ROW_H - 8,
                    lineHeight: `${LANE_ROW_H - 8}px`,
                    background: isHighlighted
                      ? `repeating-linear-gradient(45deg, #fff, #fff 2px, ${bar.color} 2px, ${bar.color} 4px)`
                      : bar.color,
                    borderRadius: 6,
                    border:
                      isHighlighted || replayState === 'active'
                        ? `2px solid ${bar.color}`
                        : undefined,
                    color: isHighlighted ? bar.color : '#fff',
                    fontWeight:
                      isHighlighted || replayState === 'active' ? 700 : 500,
                    filter:
                      replayState === 'active' && !isHighlighted
                        ? 'brightness(1.15)'
                        : undefined,
                    opacity:
                      replayState === 'future' ? REPLAY_FUTURE_BAR_OPACITY : 1,
                    zIndex: isHighlighted ? 10 : 1,
                  }}
                  onMouseEnter={(e) => {
                    setHoveredBar(bar);
                    const r = e.currentTarget.getBoundingClientRect();
                    setTooltipAnchor({ x: r.left + r.width / 2, y: r.top });
                  }}
                  onMouseLeave={() => setHoveredBar(null)}
                  onClick={() =>
                    setHighlightedEventId(
                      highlightedEventId === bar.eventId ? null : bar.eventId,
                    )
                  }
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setHighlightedEventId(
                        highlightedEventId === bar.eventId ? null : bar.eventId,
                      );
                    }
                  }}
                >
                  {displayLabel}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Hover tooltip */}
      {hoveredBar && (
        <div
          className="fixed z-[9999] min-w-[220px] max-w-xs rounded-md border border-gray-200 bg-white p-0 shadow-lg dark:border-gray-700 dark:bg-gray-800"
          style={{
            left: Math.max(
              8,
              Math.min(tooltipAnchor.x - 110, window.innerWidth - 248),
            ),
            top: tooltipAnchor.y,
            transform: 'translateY(calc(-100% - 6px))',
          }}
        >
          <div className="space-y-2 p-3">
            <div className="flex items-center gap-2 border-b border-gray-200 pb-2 dark:border-gray-700">
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-full"
                style={{ backgroundColor: hoveredBar.color }}
              />
              <span className="text-xs font-semibold text-gray-900 dark:text-white">
                {CATEGORY_META[hoveredBar.event.category].label}
              </span>
            </div>
            <div>
              <div className="text-xs font-medium text-gray-900 dark:text-white">
                {hoveredBar.event.label || hoveredBar.event.subType}
              </div>
              {hoveredBar.event.label && (
                <div className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400">
                  {hoveredBar.event.subType
                    .replace(/_/g, ' ')
                    .toLowerCase()
                    .replace(/\b\w/g, (c) => c.toUpperCase())}
                </div>
              )}
            </div>
            <div className="space-y-1 border-t border-gray-200 pt-2 text-xs dark:border-gray-700">
              <div className="flex justify-between gap-4">
                <span className="text-gray-500 dark:text-gray-400">
                  Started
                </span>
                <span className="text-right text-gray-900 dark:text-white">
                  {fmtUtc(hoveredBar.event.startTime)}
                </span>
              </div>
              {hoveredBar.event.endTime && (
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500 dark:text-gray-400">
                    Ended
                  </span>
                  <span className="text-right text-gray-900 dark:text-white">
                    {fmtUtc(hoveredBar.event.endTime)}
                  </span>
                </div>
              )}
              {hoveredBar.endMs && (
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500 dark:text-gray-400">
                    Duration
                  </span>
                  <span className="text-right text-gray-900 dark:text-white">
                    {formatDuration(hoveredBar.endMs - hoveredBar.startMs)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
