import { Spinner } from 'flowbite-react';
import { FC, useEffect, useState } from 'react';
import { LuArrowUpRight, LuShieldCheck } from 'react-icons/lu';
import { PURPLETRAC_INFO_URL } from '@/app/config/externalLinks';
import { usePtracScreening } from '@/features/Vessels/hooks/usePtracScreening';
import StatusBadge from '@/shared/components/Badge';

const LONG_WAIT_MS = 7_000;
const MESSAGE_ROTATION_MS = 2_500;

const LOADING_MESSAGES = [
  'Screening in progress...',
  'Checking sanctions watchlists...',
  'Reviewing port state control history...',
  'Cross-referencing vessel movements...',
  'Verifying ownership records...',
  'Compiling compliance results...',
];

interface PtracScreeningSectionProps {
  imo: string;
  hasAccess: boolean;
}

const PtracScreeningSection: FC<PtracScreeningSectionProps> = ({
  imo,
  hasAccess,
}) => {
  const { status, loading, error, startedAt, retry } = usePtracScreening(
    hasAccess ? imo : '',
  );

  const [isLongWait, setIsLongWait] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    if (!loading || !startedAt) {
      setIsLongWait(false);
      return;
    }

    const remaining = LONG_WAIT_MS - (Date.now() - startedAt);
    if (remaining <= 0) {
      setIsLongWait(true);
      return;
    }

    setIsLongWait(false);
    const timer = setTimeout(() => setIsLongWait(true), remaining);
    return () => clearTimeout(timer);
  }, [loading, startedAt]);

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % LOADING_MESSAGES.length);
    }, MESSAGE_ROTATION_MS);
    return () => clearInterval(interval);
  }, [loading]);

  if (!hasAccess) {
    return (
      <div className="rounded-lg border border-gray-200 px-3 pb-2.5 pt-3 text-center dark:border-gray-700">
        <div className="flex justify-center">
          <LuShieldCheck className="size-5 text-gray-600 dark:text-gray-400" />
        </div>
        <p className="mt-2 text-[13px] font-semibold text-gray-900 dark:text-gray-50">
          Unlock PurpleTRAC Screening
        </p>
        <p className="mt-1 text-[11px] leading-snug text-gray-700 dark:text-gray-300">
          Streamlined sanctions compliance — clear this vessel against global
          watchlists and demonstrate best efforts.
        </p>
        <p className="mt-2.5 text-[11px] font-semibold text-gray-600 dark:text-gray-400">
          Available on request.
        </p>
        <div className="-mx-3 mt-2.5 h-px bg-gray-200 dark:bg-gray-700" />
        <div className="flex justify-center pt-2">
          <a
            href={PURPLETRAC_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-4 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about PurpleTRAC
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  if (loading || (!status && !error)) {
    return (
      <div className="space-y-2">
        <div className="rounded-lg px-3 py-2 text-center">
          <div className="flex justify-center">
            <Spinner size="sm" color="gray" light />
          </div>
          <p className="mt-2 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
            {LOADING_MESSAGES[messageIndex]}
          </p>
          {isLongWait && (
            <p className="mt-1 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
              You can leave this page - results will be saved.
            </p>
          )}
        </div>
        <div className="pt-1">
          <a
            href={PURPLETRAC_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about PurpleTRAC
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-2">
        <div className="rounded-lg px-3 py-2 text-center">
          <p className="text-[11px] leading-snug text-gray-600 dark:text-gray-400">
            PurpleTRAC screening is temporarily unavailable.
          </p>
        </div>
        <div className="space-y-2 pt-1">
          <button
            type="button"
            onClick={retry}
            className="flex w-full items-center justify-center rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            Retry
          </button>
          <a
            href={PURPLETRAC_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about PurpleTRAC
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2 px-2 pb-3 pt-0.5">
      <div className="flex items-center justify-between rounded-lg px-3 py-2">
        <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">
          Overall
        </span>
        {status && <StatusBadge status={status} />}
      </div>

      <div className="rounded-lg border border-gray-200 px-3 pb-1.5 pt-3 dark:border-gray-700">
        <p className="text-[11px] font-semibold text-gray-900 dark:text-gray-50">
          Get the full breakdown
        </p>
        <p className="mt-1 text-[11px] leading-snug text-gray-600 dark:text-gray-400">
          See every check behind this result — sanctions, PSC history, ship
          movement and more.
        </p>

        <p className="mt-2.5 text-[11px] font-semibold text-gray-600 dark:text-gray-400">
          Available on request.
        </p>
        <div className="-mx-3 mt-2.5 h-px bg-gray-200 dark:bg-gray-700" />
        <div className="pt-2">
          <a
            href={PURPLETRAC_INFO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-1 rounded-lg border border-gray-300 bg-white px-3 py-2 text-[11px] font-medium text-gray-900 transition-colors hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800/50 dark:text-gray-50 dark:hover:bg-gray-700/50"
          >
            More about PurpleTRAC
            <LuArrowUpRight className="size-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default PtracScreeningSection;
