import { Spinner } from 'flowbite-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { LuChevronsUpDown, LuLoader, LuSearch } from 'react-icons/lu';
import { useNavigate } from 'react-router-dom';
import { IVesselFilter } from '@/features/library/hooks/useSearchFilters';
import {
  fetchBookmarks,
  vesselSearch,
} from '@/features/library/services/libraryApi';
import { VesselSearch } from '@/features/library/types/LibraryTypes';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  addRecentVessel,
  getRecentVessels,
} from '@/features/Vessels/utils/recentVessels';
import { useDebounce } from '@/shared/hooks/useDebounce';
import { useEscapeClose } from '@/shared/hooks/useEscapeClose';
import { Vessel } from '@/shared/types/entities';
import { iso3ToIso2 } from '@/shared/utils/formatUtils';

function flagEmoji(code: string | null | undefined): string {
  if (!code) return '🏳';
  const c = code.trim().toUpperCase();
  const twoLetter = c.length === 2 ? c : (iso3ToIso2(c) ?? '');
  if (twoLetter.length !== 2) return '🏳';
  return [...twoLetter]
    .map((ch) => String.fromCodePoint(0x1f1e6 + ch.charCodeAt(0) - 65))
    .join('');
}

const EMPTY_FILTER: IVesselFilter = {
  flag: 'All',
  type: 'All',
  status: 'All',
  deadWeight: { min: 0, max: 500000 },
  draught: { min: 0, max: 25 },
  buildYear: { min: 1950, max: new Date().getFullYear() },
};

interface Props {
  vessel: Vessel;
}

function VesselOption({
  v,
  isActive,
  onSelect,
}: {
  v: VesselSearch;
  isActive: boolean;
  onSelect: (v: VesselSearch) => void;
}) {
  return (
    <button
      key={v.imo}
      onMouseDown={(e) => {
        e.preventDefault();
        onSelect(v);
      }}
      className={`flex w-full items-start gap-2 px-3 py-2 text-left transition-colors hover:bg-gray-50 dark:hover:bg-gray-700/30 ${isActive ? 'bg-gray-100 dark:bg-gray-700/40' : ''}`}
    >
      <span className="mt-0.5 text-sm">{flagEmoji(v.flag_code)}</span>
      <div className="min-w-0">
        <p className="truncate text-xs font-medium text-gray-800 dark:text-gray-100">
          {v.name}
        </p>
        <p className="truncate text-[10px] text-gray-400 dark:text-gray-500">
          {[v.vessel_type, `IMO ${v.imo}`].filter(Boolean).join(' · ')}
        </p>
      </div>
    </button>
  );
}

export default function VesselSwitcher({ vessel }: Props) {
  const navigate = useNavigate();
  const triggerRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
  const [activeTab, setActiveTab] = useState<'recent' | 'saved'>('recent');
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 1100);
  const [recentList, setRecentList] = useState<VesselSearch[]>([]);
  const [savedVessels, setSavedVessels] = useState<VesselSearch[]>([]);
  const [savedLoading, setSavedLoading] = useState(false);
  const [savedFetched, setSavedFetched] = useState(false);
  const [searchResults, setSearchResults] = useState<VesselSearch[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  useEffect(() => {
    if (open) {
      const id = setTimeout(() => inputRef.current?.focus(), 0);
      return () => clearTimeout(id);
    }
  }, [open]);

  // Close on outside pointer down
  useEffect(() => {
    if (!open) return;
    function handler(e: PointerEvent) {
      if (
        triggerRef.current?.contains(e.target as Node) ||
        dropdownRef.current?.contains(e.target as Node)
      )
        return;
      setOpen(false);
      setSearch('');
    }
    document.addEventListener('pointerdown', handler);
    return () => document.removeEventListener('pointerdown', handler);
  }, [open]);

  useEscapeClose(
    useCallback(() => {
      setOpen(false);
      setSearch('');
    }, []),
  );

  function openDropdown() {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    setDropdownPos({ top: rect.bottom + 8, left: rect.left });
    setRecentList(getRecentVessels());
    setSearch('');
    setActiveTab('recent');
    setOpen(true);
  }

  function handleToggle() {
    if (open) {
      setOpen(false);
      setSearch('');
    } else openDropdown();
  }

  async function handleSavedTabClick() {
    setActiveTab('saved');
    if (savedFetched) return;
    setSavedLoading(true);
    try {
      const res = await fetchBookmarks(500, 0);
      const imos = res.data
        .filter((b) => b.entityType === 'VESSEL')
        .map((b) => b.entityRefId)
        .slice(0, 20);
      const settled = await Promise.allSettled(
        imos.map((imo) => vesselSearch(imo, 'nameOrImo', EMPTY_FILTER, 1, 0)),
      );
      const vessels: VesselSearch[] = settled
        .filter(
          (
            r,
          ): r is PromiseFulfilledResult<{
            data: VesselSearch[];
            meta: unknown;
          }> => r.status === 'fulfilled',
        )
        .flatMap((r) => r.value.data ?? []);
      setSavedVessels(vessels);
      setSavedFetched(true);
    } catch {
      // silently ignore
    } finally {
      setSavedLoading(false);
    }
  }

  // Live search
  useEffect(() => {
    const q = debouncedSearch.trim();
    if (q.length < 2) {
      setSearchResults([]);
      return;
    }
    let cancelled = false;
    setSearchLoading(true);
    vesselSearch(q, 'nameOrImo', EMPTY_FILTER, 20, 0)
      .then((res: { data: VesselSearch[] }) => {
        if (!cancelled) setSearchResults(res.data ?? []);
      })
      .catch(() => {
        if (!cancelled) setSearchResults([]);
      })
      .finally(() => {
        if (!cancelled) setSearchLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [debouncedSearch]);

  function handleSelect(v: VesselSearch) {
    addRecentVessel(v);
    useVesselActivityStore.getState().resetActivityState();
    navigate('/analytics/vessel/' + v.imo);
    setOpen(false);
    setSearch('');
  }

  const isSearching = debouncedSearch.trim().length >= 2;

  // Library tab: filter fetched vessels locally when query is set
  const savedFiltered = savedVessels.filter((v) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return v.name.toLowerCase().includes(q) || v.imo.includes(q);
  });

  const showRecentEmpty =
    activeTab === 'recent' && !isSearching && recentList.length === 0;
  const showRecentList =
    activeTab === 'recent' && !isSearching && recentList.length > 0;
  const showSearchResults = activeTab === 'recent' && isSearching;

  return (
    <>
      <button
        ref={triggerRef}
        onClick={handleToggle}
        className="flex w-full items-center gap-3 rounded px-2.5 py-0.5 text-sm font-semibold text-gray-800 transition-colors hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-700/60"
      >
        {vessel.name}
        <LuChevronsUpDown className="h-3 w-3 text-gray-400 dark:text-gray-500" />
      </button>

      {open &&
        createPortal(
          <div
            ref={dropdownRef}
            style={{ top: dropdownPos.top, left: dropdownPos.left }}
            className="fixed z-[9999] w-80 overflow-hidden rounded-lg border border-gray-200 bg-white shadow-lg dark:border-gray-700 dark:bg-gray-800"
          >
            {/* Search input — plain input, no inner border box */}
            <div className="flex items-center gap-2 border-b border-gray-200 px-3 dark:border-gray-700">
              {searchLoading && isSearching ? (
                <LuLoader className="h-3.5 w-3.5 shrink-0 animate-spin text-gray-400 dark:text-gray-500" />
              ) : (
                <LuSearch className="h-3.5 w-3.5 shrink-0 text-gray-400 dark:text-gray-500" />
              )}
              <input
                ref={inputRef}
                type="text"
                placeholder={
                  activeTab === 'saved' ? 'Filter saved…' : 'Search vessels…'
                }
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setOpen(false);
                    setSearch('');
                  }
                }}
                className="h-9 flex-1 !border-0 !border-transparent bg-transparent text-sm text-gray-800 outline-none ring-0 placeholder:text-gray-400 focus:!border-0 focus:!border-transparent focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 dark:text-gray-100 dark:placeholder:text-gray-500"
              />
            </div>

            {/* Tabs — always visible */}
            <div className="flex border-b border-gray-200 dark:border-gray-700">
              <button
                onMouseDown={(e) => {
                  e.preventDefault();
                  setActiveTab('recent');
                }}
                className={`flex-1 py-1.5 text-[11px] font-medium transition-colors ${
                  activeTab === 'recent'
                    ? 'border-b-2 border-psg-orange-800 text-gray-900 dark:text-gray-100'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                }`}
              >
                Recent
              </button>
              <button
                onMouseDown={(e) => {
                  e.preventDefault();
                  handleSavedTabClick();
                }}
                className={`flex-1 py-1.5 text-[11px] font-medium transition-colors ${
                  activeTab === 'saved'
                    ? 'border-b-2 border-psg-orange-800 text-gray-900 dark:text-gray-100'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                }`}
              >
                Library
              </button>
            </div>

            {/* Results */}
            <div className="max-h-72 overflow-y-auto py-1">
              {/* Recent tab — list */}
              {showRecentList &&
                recentList.map((v) => (
                  <VesselOption
                    key={v.imo}
                    v={v}
                    isActive={v.imo === vessel.imo}
                    onSelect={handleSelect}
                  />
                ))}

              {/* Recent tab — search results */}
              {showSearchResults && searchResults.length > 0 && (
                <>
                  <p className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500">
                    Results
                  </p>
                  {searchResults
                    .filter((v) => v.imo !== vessel.imo)
                    .map((v) => (
                      <VesselOption
                        key={v.imo}
                        v={v}
                        isActive={false}
                        onSelect={handleSelect}
                      />
                    ))}
                </>
              )}
              {showSearchResults &&
                !searchLoading &&
                searchResults.length === 0 && (
                  <p className="px-3 py-8 text-center text-xs text-gray-400 dark:text-gray-500">
                    No vessels found
                  </p>
                )}

              {/* Recent tab — empty */}
              {showRecentEmpty && (
                <p className="px-3 py-8 text-center text-xs text-gray-400 dark:text-gray-500">
                  No recent vessels
                </p>
              )}

              {/* Saved tab */}
              {activeTab === 'saved' && savedLoading && (
                <div className="flex justify-center px-3 py-8">
                  <Spinner size="sm" />
                </div>
              )}
              {activeTab === 'saved' &&
                !savedLoading &&
                savedFiltered.length > 0 &&
                savedFiltered.map((v) => (
                  <VesselOption
                    key={v.imo}
                    v={v}
                    isActive={v.imo === vessel.imo}
                    onSelect={handleSelect}
                  />
                ))}
              {activeTab === 'saved' &&
                !savedLoading &&
                savedFiltered.length === 0 && (
                  <p className="px-3 py-8 text-center text-xs text-gray-400 dark:text-gray-500">
                    {search.trim()
                      ? `No vessels match "${search.trim()}"`
                      : 'No saved vessels'}
                  </p>
                )}
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
