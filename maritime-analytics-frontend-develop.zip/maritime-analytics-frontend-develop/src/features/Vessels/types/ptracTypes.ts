export type PtracOverallStatus = 'OK' | 'WARNING' | 'CRITICAL' | 'UNSCORED';

export interface PtracScreeningRequest {
  correlation_id: string;
  websocket_url: string;
  subscribe_destination: string;
}

export interface PtracScreeningMessage {
  correlation_id: string;
  imo_number: string;
  screening_status: PtracOverallStatus | null;
  error?: string | null;
}
