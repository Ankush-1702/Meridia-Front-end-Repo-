import { logger } from '@/shared/utils/logger';

export type ActivityEventCategory =
  | 'port'
  | 'zone'
  | 'ais_gap'
  | 'sts'
  | 'discrepancy'
  | 'psc';

export interface ActivityEvent {
  id: string;
  category: ActivityEventCategory;
  subType: string;
  startTime: string;
  endTime: string | null;
  latitude: number | null;
  longitude: number | null;
  label: string;
  raw: unknown;
}

export interface CategoryMeta {
  label: string;
  color: string;
}

const ARRIVAL_SUBTYPES = new Set([
  'PORT_ARRIVAL',
  'PORT_AREA_ARRIVAL',
  'BERTH_ARRIVAL',
]);

const DEPARTURE_SUBTYPES = new Set([
  'PORT_DEPARTURE',
  'PORT_AREA_DEPARTURE',
  'BERTH_DEPARTURE',
]);

export const CATEGORY_META: Record<ActivityEventCategory, CategoryMeta> = {
  port: { label: 'Port', color: '#2B969C' },
  zone: { label: 'Zone', color: '#1E40AF' },
  sts: { label: 'STS Pairing', color: '#8B5CF6' },
  discrepancy: { label: 'Discrepancy', color: '#F5C842' },
  psc: { label: 'PSC', color: '#D4537E' },
  ais_gap: { label: 'AIS Gap', color: '#DC2626' },
};

export type LegendEventKey =
  | 'port_arrival'
  | 'port_departure'
  | 'zone_entry'
  | 'zone_exit'
  | 'ais_gap'
  | 'sts'
  | 'discrepancy'
  | 'psc';

export const LEGEND_EVENT_KEYS: LegendEventKey[] = [
  'port_arrival',
  'port_departure',
  'zone_entry',
  'zone_exit',
  'sts',
  'discrepancy',
  'psc',
  'ais_gap',
];

export const LEGEND_EVENT_META: Record<LegendEventKey, CategoryMeta> = {
  port_arrival: { label: 'Port Arrival', color: '#2B969C' },
  port_departure: { label: 'Port Departure', color: '#2B969C' },
  zone_entry: { label: 'Zone Entry', color: '#1E40AF' },
  zone_exit: { label: 'Zone Exit', color: '#1E40AF' },
  sts: { label: 'STS Pairing', color: '#8B5CF6' },
  discrepancy: { label: 'Discrepancy', color: '#F5C842' },
  psc: { label: 'PSC', color: '#D4537E' },
  ais_gap: { label: 'AIS Gap', color: '#DC2626' },
};

export function categoryEnabled(
  filters: ActivityFilters,
  category: ActivityEventCategory,
): boolean {
  if (category === 'port')
    return filters.port_arrival || filters.port_departure;
  if (category === 'zone') return filters.zone_entry || filters.zone_exit;
  return filters[category as LegendEventKey];
}

export function getEventLegendKey(event: ActivityEvent): LegendEventKey {
  if (event.category === 'port') {
    if (ARRIVAL_SUBTYPES.has(event.subType)) return 'port_arrival';
    if (DEPARTURE_SUBTYPES.has(event.subType)) return 'port_departure';
    // unknown port subtype — fail visibly in dev
    logger.warn(
      `[getEventLegendKey] unrecognised port subType: ${event.subType}`,
    );
    return 'port_departure'; // safe fallback
  }
  if (event.category === 'zone') {
    if (event.subType === 'ZONE_ENTRY') return 'zone_entry';
    if (event.subType === 'ZONE_EXIT') return 'zone_exit';
    // unknown zone subtype — fail visibly in dev
    logger.warn(
      `[getEventLegendKey] unrecognised zone subType: ${event.subType}`,
    );
    return 'zone_exit';
  }
  return event.category as LegendEventKey;
}

export type ActivityFilters = Record<LegendEventKey, boolean>;

export const DEFAULT_FILTERS: ActivityFilters = {
  port_arrival: true,
  port_departure: true,
  zone_entry: true,
  zone_exit: true,
  sts: true,
  discrepancy: true,
  psc: true,
  ais_gap: true,
};

export type PositionSource = 'ais' | 'blended' | 'lrit' | 'none';

export const ACTIVITY_CATEGORIES: ActivityEventCategory[] = [
  'port',
  'zone',
  'sts',
  'discrepancy',
  'psc',
  'ais_gap',
];
