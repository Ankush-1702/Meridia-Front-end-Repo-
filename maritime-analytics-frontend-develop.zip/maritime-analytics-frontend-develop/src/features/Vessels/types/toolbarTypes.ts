export const PREV_DAYS_OPTIONS = [7, 14, 30, 90] as const;
export type PrevDays = (typeof PREV_DAYS_OPTIONS)[number];

export type ToolbarDateState = {
  prevDays: PrevDays;
  isCustom: boolean;
  customStart: string;
  customEnd: string;
};

export const DEFAULT_TOOLBAR_DATE_STATE: ToolbarDateState = {
  prevDays: 30,
  isCustom: false,
  customStart: '',
  customEnd: '',
};
