export interface VesselPortStateControlEvent {
  inspections: {
    authority: string;
    detained: boolean;
    expanded_inspection: boolean;
    follow_up_inspection: string;
    inspection_date: string;
    inspection_type: string | undefined | null;
    no_days_detained: number | undefined;
    no_defects: number;
    port_information: {
      country_code: string | undefined;
      country_common_name: string;
      name: string;
    };
    release_date: string | undefined;
  }[];
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
}
export interface flattenedVesselPortStateControl {
  authority: string;
  detained: boolean;
  expanded_inspection: boolean;
  follow_up_inspection: string | undefined;
  inspection_date: string;
  inspection_type: string | null | undefined;
  no_days_detained: number | undefined;
  no_defects: number;
  port_information: {
    country_code: string | undefined;
    country_common_name: string;
    name: string;
  };
  release_date: string | undefined;
  asset_id: string;
  callsign: string;
  flag: string;
  flag_code: string;
  imo: string;
  mmsi: string;
  name: string;
  vessel_type: string;
}

export interface VesselAISGapsEvent {
  events: {
    event_id: string;
    gap_duration_hours: number;
    draught_change: number | undefined;
    stopped: {
      course: number;
      draught: number;
      latitude: number;
      longitude: number;
      navigational_status: {
        status: string;
        code: number;
      };
      speed: number;
      timestamp: string;
    };
    resumed: {
      course: number;
      draught: number;
      latitude: number;
      longitude: number;
      navigational_status: {
        status: string;
        code: number;
      };
      speed: number;
      timestamp: string;
    };
  }[];
  vessel_information: {
    asset_id: string;
    callsign: string;
    imo: string;
    mmsi: string;
    name: string;
    flag_code: string;
    flag: string;
    vessel_type: string;
  };
}

export interface flattenedVesselAISGaps {
  event_id: string;
  gap_duration_hours: number;
  draught_change: number | undefined | string;
  stopped: {
    course: number;
    draught: number;
    latitude: number;
    longitude: number;
    navigational_status: { status: string; code: number };
    speed: number;
    timestamp: string;
  };
  resumed: {
    course: null | number | undefined | string;
    draught: number;
    latitude: number;
    longitude: number;
    navigational_status: { status: string; code: number };
    speed: number;
    timestamp: string;
  };
  asset_id: string;
  callsign: string;
  imo: string;
  mmsi: string;
  name: string;
  flag_code: string;
  flag: string;
  vessel_type: string;
}

export interface VesselSTSEvent {
  events: {
    location: {
      latitude: number;
      longitude: number;
    };
    duration_hours: number;
    paired_vessel: {
      asset_id: string;
      callsign: string;
      flag: string;
      flag_code: string;
      imo: string;
      mmsi: string;
      name: string;
      vessel_type: string;
    };
    started: string;
    stopped: string;
    sts_type: string;
  }[];
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
}

export interface flattenedVesselSTSEvents {
  location: { latitude: number; longitude: number };
  duration_hours: number;
  paired_vessel: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
  started: string;
  stopped: string;
  sts_type: string;
  asset_id: string;
  callsign: string;
  flag: string;
  flag_code: string;
  imo: string;
  mmsi: string;
  name: string;
  vessel_type: string;
}

export interface VesselPositionalDiscrepanciesEvents {
  events: {
    has_ended: boolean;
    duration_hours: number;
    event_type: string;
    started: {
      timestamp: string;
      draught: number | undefined;
      latitude: number;
      longitude: number;
      zones: {
        centroid: {
          latitude: number;
          longitude: number;
        };
        id: string;
        name: string;
        type: string;
        sub_type: string;
        description: string;
      }[];
      ports: unknown[];
    };
    stopped: {
      timestamp: string;
      draught: number | undefined;
      latitude: number;
      longitude: number;
      zones: {
        centroid: {
          latitude: number;
          longitude: number;
        };
        id: string;
        name: string;
        type: string;
        sub_type: string;
        description: string;
      }[];
      ports: unknown[];
    };
  }[];
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
}

export interface flattenedVesselPositionalDiscrepancies {
  has_ended: boolean;
  duration_hours: number;
  event_type: string;
  started: {
    timestamp: string;
    draught: undefined | number;
    latitude: number;
    longitude: number;
    zones: {
      centroid: {
        latitude: number;
        longitude: number;
      };
      id: string;
      name: string;
      type: string;
      sub_type: string;
      description: string;
    }[];
    ports: unknown[];
  };
  stopped: {
    timestamp: string;
    draught: number | undefined;
    latitude: number;
    longitude: number;
    zones: {
      centroid: {
        latitude: number;
        longitude: number;
      };
      id: string;
      name: string;
      type: string;
      sub_type: string;
      description: string;
    }[];
    ports: unknown[];
  };
  asset_id: string;
  callsign: string;
  flag: string;
  flag_code: string;
  imo: string;
  mmsi: string;
  name: string;
  vessel_type: string;
}

export interface VesselPortAndZoneEvents {
  vessel_information: {
    asset_id: string;
    callsign: string;
    flag: string;
    flag_code: string;
    imo: string;
    mmsi: string;
    name: string;
    vessel_type: string;
  };
  events: {
    zone_information: {
      centroid: { longitude: number; latitude: number };
      country_official_name: string;
      country_code: string;
      description: string;
      id: string;
      name: string;
      sub_type: string;
      type: string;
      unlocode: string;
      country_common_name: string;
      sub_division_code: string;
      sub_division_name: string;
      wpi_number: null;
    };
    event_details: {
      course: number;
      draught: number;
      event_id: string;
      event_timestamp: string;
      event_type: string;
      heading: number;
      latitude: number;
      longitude: number;
      navigational_status: string;
      reported_destination: string;
      reported_eta: string;
      speed: number;
    };
  }[];
}

export interface flattenedVesselPortAndZone {
  zone_information: {
    centroid: { longitude: number; latitude: number };
    country_official_name: string;
    country_code: string;
    description: string;
    id: string;
    name: string;
    sub_type: string;
    type: string;
    unlocode: string;
    country_common_name: string;
    sub_division_code: string;
    sub_division_name: string;
    wpi_number: null | number | string | undefined;
  };
  event_details: {
    course: number;
    draught: number;
    event_id: string;
    event_timestamp: string;
    event_type: string;
    heading: number;
    latitude: number;
    longitude: number;
    navigational_status: string;
    reported_destination: string;
    reported_eta: string;
    speed: number;
  };
  asset_id: string;
  callsign: string;
  flag: string;
  flag_code: string;
  imo: string;
  mmsi: string;
  name: string;
  vessel_type: string;
}

export type VesselEvents =
  | VesselAISGapsEvent[]
  | VesselSTSEvent[]
  | VesselPortAndZoneEvents[]
  | VesselPortStateControlEvent[]
  | VesselPositionalDiscrepanciesEvents[];

export interface FlatVesselEventsResponse {
  // ── Default Columns ──────────────────────────
  eventTimestamp?: string;
  eventType?: string;
  location?: string;
  country?: string;
  unlocode?: string;
  zoneType?: string;
  zoneId?: string;
  speed?: number;
  course?: number;
  duration?: number;
  countryFlag?: string;

  // ── Vessel Information ──────────────────────────
  callSign: string;
  flag: string;
  flagCode: string;
  imo: string;
  mmsi: string;
  vesselName: string;
  vesselType: string;

  // –– Position & Movement –––––––––––––––––––––––
  heading?: number;
  draught?: number;
  navigationalStatusStatus?: string;
  navigationalStatusCode?: number;
  reportedDestination?: string;
  reportedEta?: string;

  // ── Port State Control ──────────────────────────
  authority?: string;
  inspectionType?: string;
  inspectionDate?: string;
  detained?: boolean;
  daysDetained?: number;
  numberOfDefects?: number;
  releaseDate?: string;

  // ── STS Pairings ──────────────────────────────────────
  stsType?: string;
  pairedVessel?: string;
  pairedIMO?: string;
  stsEnded?: string;

  // ── AIS Gaps ──────────────────────────────────────────
  gapStopped?: string;
  gapResumed?: string;
  draughtChange?: string | number;

  // ── Positional Discrepancies ────────────────────────────────
  hasEnded?: boolean;
  startedLatitude?: number;
  startedLongitude?: number;
  stoppedTimestamp?: string;
  stoppedLatitude?: number;
  stoppedLongitude?: number;
}

export type VesselEventsTypes =
  | 'POSITIONAL_DISCREPANCY'
  | 'STS_PAIRING'
  | 'AIS_GAP'
  | 'PORT_STATE_CONTROL';
