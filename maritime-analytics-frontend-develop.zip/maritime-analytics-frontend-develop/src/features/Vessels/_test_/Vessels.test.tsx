import { describe, it, expect, vi, beforeEach } from 'vitest';
import VesselDetailsPage from '@/features/Vessels/Vessels';
import { renderWithRouter, screen, fireEvent } from '@/test-utils';
import '@/test-setup'; // Import test setup for window.matchMedia mock

// Mock ThemeProvider
vi.mock('@/app/context/ThemeProvider', () => ({
  useTheme: () => ({ theme: 'light' }),
}));

const mockShowToast = vi.fn();
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

/* ---------------- mutable mock ---------------- */

const mockUseVesselDetails = vi.fn();

/* ---------------- mocks ---------------- */

const mockAddOrRemoveBookmark = vi.fn();
const mockIsBookmarked = vi.fn();
const mockExportToCSV = vi.fn();
const mockSetRefresh = vi.fn();
const mockSetDateRange = vi.fn();

function createUseVesselDetailsMock(
  overrides?: Partial<ReturnType<typeof mockUseVesselDetails>>,
) {
  return {
    id: 'vessel-1',
    vessel: undefined,
    loading: false,
    error: null,
    refresh: false,
    setRefresh: mockSetRefresh,
    dateRange: { start: '2024-01-01', end: '2024-01-31' },
    setDateRange: mockSetDateRange,
    toggleBookmarkLoading: false,
    isBookmarked: mockIsBookmarked,
    addOrRemoveBookmark: mockAddOrRemoveBookmark,
    ...overrides,
  };
}

vi.mock('@/features/Vessels/hooks/useVesselDetails', () => ({
  useVesselDetails: () => mockUseVesselDetails(),
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    exportToCSV: mockExportToCSV,
  }),
}));

vi.mock('@/features/Vessels/ui/VesselEventsTab', () => ({
  default: () => <div>EventsPanel</div>,
}));

const mockReplayBar = vi.fn();
vi.mock('@/features/Vessels/ui/VesselReplayBar', () => ({
  default: (props: unknown) => {
    mockReplayBar(props);
    return <div>ReplayBar</div>;
  },
}));

vi.mock('@/features/Vessels/ui/VesselGanttTimeline', () => ({
  default: () => <div>GanttTimeline</div>,
}));

vi.mock('@/features/Vessels/ui/VesselSwitcher', () => ({
  default: () => <div>VesselSwitcher</div>,
}));

vi.mock('@/features/Vessels/ui/VesselActivityMap', () => ({
  default: () => <div>ActivityMap</div>,
}));

vi.mock('@/features/Vessels/ui/VesselActivityToolbar', () => ({
  default: (props: { onToggleSidebar?: () => void; sidebarOpen?: boolean }) => (
    <div>
      {props.onToggleSidebar && (
        <button onClick={props.onToggleSidebar}>
          {props.sidebarOpen ? 'Hide Vessel Details' : 'Show Vessel Details'}
        </button>
      )}
    </div>
  ),
}));

vi.mock('@/features/Vessels/ui/VesselEventTimeline', () => ({
  default: () => <div>EventTimeline</div>,
}));

vi.mock('@/features/Vessels/ui/VesselActivitySidebar', () => ({
  default: (props: { onClose: () => void }) => (
    <div>
      <span>Vessel Details</span>
      <button onClick={props.onClose}>Hide vessel details</button>
    </div>
  ),
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: () => <span>Flag</span>,
}));

vi.mock('@/shared/components/EntityLoadingSkeleton', () => ({
  default: () => <div>LoadingSkeleton</div>,
}));

vi.mock('@/shared/ui/GenericErrorPage', () => ({
  default: () => <div>ErrorPage</div>,
}));

vi.mock('@/shared/ui/EntityToolbar', () => ({
  default: (props: { buttonLabel: string; onToggle: () => void }) => (
    <div>
      <span>{props.buttonLabel}</span>
      <button onClick={props.onToggle}>Bookmark</button>
    </div>
  ),
}));

vi.mock('@/shared/components/EntityTabs', () => ({
  default: (props: {
    onChange: (tab: string) => void;
    renderActions?: React.ReactNode;
  }) => (
    <div>
      <button onClick={() => props.onChange('overview')}>Overview</button>
      <button onClick={() => props.onChange('events')}>Events</button>
      {props.renderActions}
    </div>
  ),
}));

vi.mock('@/shared/components/EntityActionButton', () => ({
  default: (props: { textLabel: string; handleClick: () => void }) => (
    <button onClick={props.handleClick}>{props.textLabel}</button>
  ),
}));

vi.mock('@/shared/ui/EntityDetailsPanel', () => ({
  EntityDetailsPanel: (props: { title: string }) => <div>{props.title}</div>,
}));

/* ---------------- setup ---------------- */

beforeEach(() => {
  vi.clearAllMocks();

  mockUseVesselDetails.mockReturnValue({
    id: 'vessel-1',
    vessel: {
      name: 'Test Vessel',
      imo: '1234567',
      mmsi: '987654321',
      callsign: 'CALL',
      type: 'Cargo',
      ship_status: 'Active',
      flag: { name: 'Norway', country_code: 'NO' },
      port_of_registry: 'Oslo',
      classification_society: 'ABS',
      pandi_club: 'Club',
      build_year: 2010,
      country_of_build: { country_name: 'Norway' },
      shipbuilder: 'Builder',
      dimensions: { length: 100, breadth: 20 },
      draught: 10,
      deadweight: 50000,
      gross_tonnage: 30000,
      ownership: {
        group_beneficial_owner: 'Owner Group',
        registered_owner: 'Owner',
        operator: 'Operator',
        ship_manager: 'Manager',
        technical_manager: 'Tech Manager',
      },
    },
    loading: false,
    error: null,
    refresh: false,
    setRefresh: mockSetRefresh,
    dateRange: { start: '2024-01-01', end: '2024-01-31' },
    setDateRange: mockSetDateRange,
    toggleBookmarkLoading: false,
    isBookmarked: mockIsBookmarked,
    addOrRemoveBookmark: mockAddOrRemoveBookmark,
  });
});

/* ---------------- tests ---------------- */

describe('VesselDetailsPage', () => {
  it('renders loading state', () => {
    mockUseVesselDetails.mockReturnValue(
      createUseVesselDetailsMock({
        loading: true,
      }),
    );

    renderWithRouter(<VesselDetailsPage />);

    expect(screen.getByText('LoadingSkeleton')).toBeInTheDocument();
  });

  it('renders error state', () => {
    mockUseVesselDetails.mockReturnValue(
      createUseVesselDetailsMock({
        loading: false,
        error: true,
      }),
    );

    renderWithRouter(<VesselDetailsPage />);

    expect(screen.getByText('ErrorPage')).toBeInTheDocument();
  });

  it('renders overview tab by default with vessel details sidebar', () => {
    mockIsBookmarked.mockReturnValue(false);

    renderWithRouter(<VesselDetailsPage />);

    expect(screen.getByText('Vessel Details')).toBeInTheDocument();
    expect(screen.getByText('Overview')).toBeInTheDocument();
  });

  it('switches to events tab and renders VesselEventsPanel', () => {
    mockIsBookmarked.mockReturnValue(false);

    renderWithRouter(<VesselDetailsPage />);

    fireEvent.click(screen.getByText('Events'));

    expect(screen.getByText('EventsPanel')).toBeInTheDocument();
  });

  it('shows correct bookmark label when vessel is bookmarked', () => {
    mockIsBookmarked.mockReturnValue(true);

    renderWithRouter(<VesselDetailsPage />);

    expect(screen.getByText('Remove from Library')).toBeInTheDocument();
  });

  it('calls addOrRemoveBookmark when bookmark button is clicked', () => {
    mockIsBookmarked.mockReturnValue(false);

    renderWithRouter(<VesselDetailsPage />);

    fireEvent.click(screen.getByText('Bookmark'));

    expect(mockAddOrRemoveBookmark).toHaveBeenCalledWith('1234567');
  });

  it('resize handle ArrowUp/ArrowDown does not throw or produce NaN', () => {
    mockIsBookmarked.mockReturnValue(false);
    renderWithRouter(<VesselDetailsPage />);

    const handle = screen.getByRole('button', { name: 'Resize Gantt panel' });

    // These should not throw — Enter/Space used to call handleGanttResizeStart
    // with a KeyboardEvent cast as MouseEvent, producing NaN from clientY
    expect(() => fireEvent.keyDown(handle, { key: 'ArrowUp' })).not.toThrow();
    expect(() => fireEvent.keyDown(handle, { key: 'ArrowDown' })).not.toThrow();
    expect(() => fireEvent.keyDown(handle, { key: 'Enter' })).not.toThrow();
    expect(() => fireEvent.keyDown(handle, { key: ' ' })).not.toThrow();
    expect(handle).toBeInTheDocument();
  });

  it('VesselReplayBar receives the memoized replayDateRange (stable reference)', () => {
    mockIsBookmarked.mockReturnValue(false);
    mockReplayBar.mockClear();

    const { rerender } = renderWithRouter(<VesselDetailsPage />);
    rerender(<VesselDetailsPage />);

    const calls = mockReplayBar.mock.calls;
    if (calls.length >= 2) {
      expect(calls[calls.length - 1][0].dateRange).toBe(
        calls[calls.length - 2][0].dateRange,
      );
    }
  });
});
