import { describe, it, expect, vi, beforeEach } from 'vitest';
import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import {
  fetchVesselAISGaps,
  fetchVesselDetails,
  fetchVesselPortCalls,
  fetchVesselPortStateControl,
  fetchVesselPositionalDiscrepancies,
  fetchVesselSTSPairings,
  fetchVesselZoneEvents,
} from '@/features/Vessels/services/vesselServices';

/* ---------------- mocks ---------------- */

const mockFetchWithAuth = vi.fn();
const mockFetch = vi.fn();

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://mock-api-gateway.test',
}));

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: (...args: Parameters<typeof mockFetchWithAuth>) =>
    mockFetchWithAuth(...args),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

vi.stubGlobal('fetch', mockFetch);

beforeEach(() => {
  vi.clearAllMocks();
});

/* ---------------- helpers ---------------- */

function okResponse<T>(data: T) {
  return {
    ok: true,
    json: async () => data,
  };
}

function errorResponse(message = 'Error', status = 500) {
  return {
    ok: false,
    status,
    statusText: 'Server Error',
    json: async () => ({ message }),
    text: async () => message,
  };
}

/* ---------------- fetchVesselDetails ---------------- */

describe('fetchVesselDetails', () => {
  it('returns vessel data on success', async () => {
    const vessel = { imo: '123', name: 'Test Vessel' };

    mockFetchWithAuth.mockResolvedValueOnce(okResponse({ data: vessel }));

    const result = await fetchVesselDetails('123');

    expect(mockFetchWithAuth).toHaveBeenCalledWith(
      `${API_GATEWAY_BASE_URL}/vessel-insights/v1/vessel-characteristics/123`,
      { headers: { Authorization: 'Bearer token' } },
    );

    expect(result).toEqual(vessel);
  });

  it('throws enriched error on failure', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(errorResponse('Not found', 404));

    await expect(fetchVesselDetails('123')).rejects.toMatchObject({
      message: 'Not found',
      status: 404,
    });
  });
});

/* ---------------- fetchVesselPortCalls ---------------- */

describe('fetchVesselPortCalls', () => {
  it('calls the correct endpoint with default params and event_type filter', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        data: {
          events: [{ id: 1 }],
          vessel_information: { name: 'Vessel A' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselPortCalls('123');

    expect(mockFetchWithAuth).toHaveBeenCalledTimes(1);
    const [url, options] = mockFetchWithAuth.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/123?`,
    );
    expect(url).toContain('limit=500');
    expect(url).toContain('offset=0');
    expect(url).toContain(
      'event_type=PORT_ARRIVAL%2CPORT_DEPARTURE%2CPORT_AREA_ARRIVAL%2CPORT_AREA_DEPARTURE',
    );
    expect(options).toEqual({ headers: { Authorization: 'Bearer token' } });

    expect(result.totalCount).toBe(1);
    expect(result.data[0]).toMatchObject({ id: 1, name: 'Vessel A' });
  });

  it('appends custom timestamp and pagination params', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        data: { events: [], vessel_information: {} },
        meta: { total_count: 0 },
      }),
    );

    await fetchVesselPortCalls('123', 'start', 'end', 10, 50);

    const [url] = mockFetchWithAuth.mock.calls[0];
    expect(url).toContain('timestamp_start=start');
    expect(url).toContain('timestamp_end=end');
    expect(url).toContain('offset=10');
    expect(url).toContain('limit=50');
  });

  it('throws enriched error on failure', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(
      errorResponse('Port calls error', 500),
    );

    await expect(fetchVesselPortCalls('123')).rejects.toMatchObject({
      message: 'Port calls error',
      status: 500,
    });
  });
});

/* ---------------- fetchVesselZoneEvents ---------------- */

describe('fetchVesselZoneEvents', () => {
  it('calls the correct endpoint with the zone event_type filter', async () => {
    mockFetch.mockResolvedValueOnce(
      okResponse({
        data: {
          events: [{ id: 2 }],
          vessel_information: { name: 'Zone Vessel' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselZoneEvents('123');

    const [url, options] = mockFetch.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/123?`,
    );
    expect(url).toContain('event_type=ZONE_ENTRY%2CZONE_EXIT');
    expect(options).toEqual({ headers: { Authorization: 'Bearer token' } });

    expect(result.data[0]).toMatchObject({ id: 2, name: 'Zone Vessel' });
  });

  it('throws enriched error on failure', async () => {
    mockFetch.mockResolvedValueOnce(errorResponse('Zone events error', 500));

    await expect(fetchVesselZoneEvents('123')).rejects.toMatchObject({
      message: 'Zone events error',
      status: 500,
    });
  });
});

/* ---------------- fetchVesselAISGaps ---------------- */

describe('fetchVesselAISGaps', () => {
  it('calls the correct endpoint with gap_threshold_gte filter', async () => {
    mockFetch.mockResolvedValueOnce(
      okResponse({
        data: {
          events: [{ gap: 5 }],
          vessel_information: { imo: '123' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselAISGaps('123');

    const [url] = mockFetch.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-ais-reporting-gaps/123?`,
    );
    expect(url).toContain('gap_threshold_gte=3');

    expect(result.data[0]).toMatchObject({ gap: 5, imo: '123' });
  });

  it('throws enriched error on failure', async () => {
    mockFetch.mockResolvedValueOnce(errorResponse('AIS gaps error', 500));

    await expect(fetchVesselAISGaps('123')).rejects.toMatchObject({
      message: 'AIS gaps error',
      status: 500,
    });
  });
});

/* ---------------- fetchVesselSTSPairings ---------------- */

describe('fetchVesselSTSPairings', () => {
  it('calls the correct endpoint', async () => {
    mockFetch.mockResolvedValueOnce(
      okResponse({
        data: {
          events: [{ stsId: 'A' }],
          vessel_information: { name: 'STS Vessel' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselSTSPairings('123');

    const [url] = mockFetch.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-sts-pairings/123?`,
    );

    expect(result.data[0]).toMatchObject({ stsId: 'A', name: 'STS Vessel' });
  });

  it('throws enriched error on failure', async () => {
    mockFetch.mockResolvedValueOnce(errorResponse('STS error', 500));

    await expect(fetchVesselSTSPairings('123')).rejects.toMatchObject({
      message: 'STS error',
      status: 500,
    });
  });
});

/* ---------------- fetchVesselPositionalDiscrepancies ---------------- */

describe('fetchVesselPositionalDiscrepancies', () => {
  it('calls the correct endpoint', async () => {
    mockFetch.mockResolvedValueOnce(
      okResponse({
        data: {
          events: [{ diff: 10 }],
          vessel_information: { name: 'Pos Vessel' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselPositionalDiscrepancies('123');

    const [url] = mockFetch.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-positional-discrepancy/123?`,
    );

    expect(result.data[0]).toMatchObject({ diff: 10, name: 'Pos Vessel' });
  });

  it('throws enriched error on failure', async () => {
    mockFetch.mockResolvedValueOnce(
      errorResponse('Positional discrepancies error', 500),
    );

    await expect(
      fetchVesselPositionalDiscrepancies('123'),
    ).rejects.toMatchObject({
      message: 'Positional discrepancies error',
      status: 500,
    });
  });
});

/* ---------------- fetchVesselPortStateControl ---------------- */

describe('fetchVesselPortStateControl', () => {
  it('calls the correct endpoint and maps inspections', async () => {
    mockFetch.mockResolvedValueOnce(
      okResponse({
        data: {
          inspections: [{ inspectionId: 9 }],
          vessel_information: { name: 'PSC Vessel' },
        },
        meta: { total_count: 1 },
      }),
    );

    const result = await fetchVesselPortStateControl('123');

    const [url] = mockFetch.mock.calls[0];
    expect(url).toContain(
      `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-port-state-control/123?`,
    );

    expect(result.data[0]).toMatchObject({
      inspectionId: 9,
      name: 'PSC Vessel',
    });
  });

  it('throws enriched error on failure', async () => {
    mockFetch.mockResolvedValueOnce(errorResponse('PSC error', 500));

    await expect(fetchVesselPortStateControl('123')).rejects.toMatchObject({
      message: 'PSC error',
      status: 500,
    });
  });
});
