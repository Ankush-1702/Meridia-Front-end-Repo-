import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.test.example.com',
}));

const TEST_MVI_URL =
  'https://api.test.example.com/meridia-voyage-intelligence/v1/latest';

const mockFetchWithAuth = vi.fn();

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: (...args: Parameters<typeof mockFetchWithAuth>) =>
    mockFetchWithAuth(...args),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer test-token' }),
}));

const mockHandleResponse = vi.fn();

vi.mock('@/features/Vessels/services/handleResponse', () => ({
  handleResponse: (...args: Parameters<typeof mockHandleResponse>) =>
    mockHandleResponse(...args),
}));

import {
  fetchLatestVesselPosition,
  type LatestVoyagesResponse,
} from '@/features/Vessels/services/vesselPositionService';

/* ─── helpers ───────────────────────────────────────────────────────────────── */

const IMO = '9815733';

function makeLatestVoyagesResponse(): LatestVoyagesResponse {
  return {
    meta: {
      limit: 1,
      offset: 0,
      request_id: 'req-1',
      request_timestamp: '2026-01-01T00:00:00Z',
    },
    data: [
      {
        vessel: { imo_number: Number(IMO) },
        voyage_last_location: {
          position_timestamp: '2026-07-16T08:55:36',
          latitude: 1.1548,
          longitude: 125.1704,
          speed: 9.8,
          heading: 26,
          raw_destination: 'ES LPA',
          matched_destination: {
            port_name: 'Las Palmas De Gran Canaria',
            unlocode: 'ESLPA',
            country: 'Kingdom of Spain',
          },
          eta: '2026-07-20T04:00:00Z',
        },
      },
    ],
  };
}

function makeFakeResponse() {
  return { ok: true, status: 200 } as unknown as Response;
}

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  mockFetchWithAuth.mockResolvedValue(makeFakeResponse());
});

describe('fetchLatestVesselPosition', () => {
  it('makes a POST request to the MVI /v1/latest endpoint', async () => {
    mockHandleResponse.mockResolvedValueOnce({
      meta: {
        limit: 1,
        offset: 0,
        request_id: 'req-1',
        request_timestamp: '2026-01-01T00:00:00Z',
      },
      data: [],
    });

    await fetchLatestVesselPosition(IMO);

    expect(mockFetchWithAuth).toHaveBeenCalledOnce();
    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(TEST_MVI_URL);

    const options = mockFetchWithAuth.mock.calls[0][1] as RequestInit;
    expect(options.method).toBe('POST');
  });

  it('sends the imo_numbers in the request body', async () => {
    mockHandleResponse.mockResolvedValueOnce({
      meta: {
        limit: 1,
        offset: 0,
        request_id: 'req-1',
        request_timestamp: '2026-01-01T00:00:00Z',
      },
      data: [],
    });

    await fetchLatestVesselPosition(IMO);

    const options = mockFetchWithAuth.mock.calls[0][1] as RequestInit;
    const body = JSON.parse(options.body as string) as Record<string, unknown>;
    expect(body).toHaveProperty('vessel');
    expect((body.vessel as { imo_numbers: string[] }).imo_numbers).toEqual([
      IMO,
    ]);
  });

  it('strips the IMO prefix before sending imo_numbers', async () => {
    mockHandleResponse.mockResolvedValueOnce({
      meta: {
        limit: 1,
        offset: 0,
        request_id: 'req-1',
        request_timestamp: '2026-01-01T00:00:00Z',
      },
      data: [],
    });

    await fetchLatestVesselPosition(`IMO${IMO}`);

    const options = mockFetchWithAuth.mock.calls[0][1] as RequestInit;
    const body = JSON.parse(options.body as string) as Record<string, unknown>;
    expect(body).toHaveProperty('vessel');
    expect((body.vessel as { imo_numbers: string[] }).imo_numbers).toEqual([
      IMO,
    ]);
  });

  it('fetches with limit=1 and offset=0', async () => {
    mockHandleResponse.mockResolvedValueOnce({
      meta: {
        limit: 1,
        offset: 0,
        request_id: 'req-1',
        request_timestamp: '2026-01-01T00:00:00Z',
      },
      data: [],
    });

    await fetchLatestVesselPosition(IMO);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    const params = new URL(calledUrl).searchParams;
    expect(params.get('limit')).toBe('1');
    expect(params.get('offset')).toBe('0');
  });

  it('maps the MVI response to the AISPosition contract', async () => {
    mockHandleResponse.mockResolvedValueOnce(makeLatestVoyagesResponse());

    const result = await fetchLatestVesselPosition(IMO);

    expect(result).toEqual({
      timestamp: '2026-07-16T08:55:36Z',
      latitude: 1.1548,
      longitude: 125.1704,
      speed: 9.8,
      heading: 26,
      destination: 'ESLPA',
      destinationTooltip: 'Las Palmas De Gran Canaria - Kingdom of Spain',
      eta: '2026-07-20T04:00:00Z',
    });
  });

  it('prefers raw_destination when matched_destination is null', async () => {
    const response = makeLatestVoyagesResponse();
    response.data[0].voyage_last_location.matched_destination = null;
    mockHandleResponse.mockResolvedValueOnce(response);

    const result = await fetchLatestVesselPosition(IMO);

    expect(result?.destination).toBe('ES LPA');
  });

  it('returns null when data array is empty', async () => {
    mockHandleResponse.mockResolvedValueOnce({
      meta: {
        limit: 1,
        offset: 0,
        request_id: 'req-1',
        request_timestamp: '2026-01-01T00:00:00Z',
      },
      data: [],
    });

    const result = await fetchLatestVesselPosition(IMO);

    expect(result).toBeNull();
  });

  it('normalizes invalid heading to null', async () => {
    const response = makeLatestVoyagesResponse();
    response.data[0].voyage_last_location.heading = 511;
    mockHandleResponse.mockResolvedValueOnce(response);

    const result = await fetchLatestVesselPosition(IMO);

    expect(result?.heading).toBeNull();
  });

  it('appends Z to timestamp when missing', async () => {
    const response = makeLatestVoyagesResponse();
    response.data[0].voyage_last_location.position_timestamp =
      '2026-07-16T08:55:36';
    mockHandleResponse.mockResolvedValueOnce(response);

    const result = await fetchLatestVesselPosition(IMO);

    expect(result?.timestamp).toBe('2026-07-16T08:55:36Z');
  });

  it('propagates errors thrown by handleResponse', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('Latest voyages fetch failed: 500'),
    );

    await expect(fetchLatestVesselPosition(IMO)).rejects.toThrow(
      'Latest voyages fetch failed: 500',
    );
  });
});
