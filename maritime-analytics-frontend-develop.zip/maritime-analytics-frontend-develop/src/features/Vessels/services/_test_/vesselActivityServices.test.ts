import { describe, it, expect, vi, beforeEach } from 'vitest';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.test.example.com',
}));

const mockFetchWithAuth = vi.fn();

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: (...args: Parameters<typeof mockFetchWithAuth>) =>
    mockFetchWithAuth(...args),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer test-token' }),
}));

const mockHandleResponse = vi.fn();

vi.mock('@/features/Vessels/services/handleResponse', () => ({
  handleResponse: (...args: Parameters<typeof mockHandleResponse>) =>
    mockHandleResponse(...args),
}));

import {
  fetchPortCallsForMap,
  fetchZoneEventsForMap,
  fetchAISGapsForMap,
  fetchSTSForMap,
  fetchDiscrepanciesForMap,
  fetchPSCForMap,
} from '@/features/Vessels/services/vesselActivityServices';

/* ─── helpers ───────────────────────────────────────────────────────────────── */

const IMO = 'IMO1234567';
const TS_START = '2024-01-01T00:00:00Z';
const TS_END = '2024-01-31T00:00:00Z';

const VESSEL_INFO = { imo: IMO, name: 'Test Vessel', flag: 'PA' };

function makeFakeResponse() {
  return { ok: true, status: 200 } as unknown as Response;
}

function portAndZonePayload(eventType: string) {
  return {
    data: {
      events: [
        {
          event_details: {
            event_id: 'evt1',
            event_type: eventType,
            event_timestamp: TS_START,
            latitude: 1,
            longitude: 2,
          },
          zone_information: { name: 'Test Zone' },
        },
      ],
      vessel_information: VESSEL_INFO,
    },
    meta: { total_count: 1 },
  };
}

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
  mockFetchWithAuth.mockResolvedValue(makeFakeResponse());
});

describe('fetchPortCallsForMap', () => {
  it('calls the correct endpoint with port event_type params', async () => {
    const payload = portAndZonePayload('PORT_ARRIVAL');
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchPortCallsForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain('https://api.test.example.com');
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-zone-and-port-events/${IMO}`,
    );
    expect(calledUrl).toContain('timestamp_start=');
    expect(calledUrl).toContain('timestamp_end=');
    expect(calledUrl).toContain(
      'event_type=PORT_ARRIVAL%2CPORT_DEPARTURE%2CPORT_AREA_ARRIVAL%2CPORT_AREA_DEPARTURE',
    );
    expect(calledUrl).toContain('limit=500');
  });

  it('returns flattened events merged with vessel_information', async () => {
    const payload = portAndZonePayload('PORT_ARRIVAL');
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchPortCallsForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      event_details: expect.objectContaining({ event_id: 'evt1' }),
      imo: IMO,
      name: 'Test Vessel',
    });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('Port call fetch failed: 500'),
    );

    await expect(fetchPortCallsForMap(IMO, TS_START, TS_END)).rejects.toThrow(
      'Port call fetch failed: 500',
    );
  });
});

describe('fetchZoneEventsForMap', () => {
  it('calls the correct endpoint with ZONE_ENTRY,ZONE_EXIT event_type', async () => {
    const payload = portAndZonePayload('ZONE_ENTRY');
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchZoneEventsForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-zone-and-port-events/${IMO}`,
    );
    expect(calledUrl).toContain('event_type=ZONE_ENTRY%2CZONE_EXIT');
  });

  it('returns flattened zone events merged with vessel_information', async () => {
    const payload = portAndZonePayload('ZONE_ENTRY');
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchZoneEventsForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ imo: IMO });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('Zone fetch failed: 503'),
    );

    await expect(fetchZoneEventsForMap(IMO, TS_START, TS_END)).rejects.toThrow(
      'Zone fetch failed: 503',
    );
  });
});

describe('fetchAISGapsForMap', () => {
  it('calls the correct endpoint with gap_threshold_gte=3', async () => {
    const payload = {
      data: {
        events: [{ event_id: 'g1', gap_duration_hours: 4 }],
        vessel_information: VESSEL_INFO,
      },
      meta: { total_count: 1 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchAISGapsForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-ais-reporting-gaps/${IMO}`,
    );
    expect(calledUrl).toContain('gap_threshold_gte=3');
  });

  it('does not include event_type param', async () => {
    const payload = {
      data: { events: [], vessel_information: VESSEL_INFO },
      meta: { total_count: 0 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchAISGapsForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).not.toContain('event_type');
  });

  it('returns flattened AIS gap events merged with vessel_information', async () => {
    const payload = {
      data: {
        events: [{ event_id: 'g1', gap_duration_hours: 4 }],
        vessel_information: VESSEL_INFO,
      },
      meta: { total_count: 1 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchAISGapsForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ event_id: 'g1', imo: IMO });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('AIS fetch failed: 500'),
    );

    await expect(fetchAISGapsForMap(IMO, TS_START, TS_END)).rejects.toThrow(
      'AIS fetch failed: 500',
    );
  });
});

describe('fetchSTSForMap', () => {
  it('calls the correct STS endpoint', async () => {
    const payload = {
      data: { events: [], vessel_information: VESSEL_INFO },
      meta: { total_count: 0 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchSTSForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-sts-pairings/${IMO}`,
    );
  });

  it('returns flattened STS events merged with vessel_information', async () => {
    const payload = {
      data: {
        events: [{ event_id: 'sts1', partner_imo: 'IMO9999999' }],
        vessel_information: VESSEL_INFO,
      },
      meta: { total_count: 1 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchSTSForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ event_id: 'sts1', imo: IMO });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('STS fetch failed: 500'),
    );

    await expect(fetchSTSForMap(IMO, TS_START, TS_END)).rejects.toThrow(
      'STS fetch failed: 500',
    );
  });
});

describe('fetchDiscrepanciesForMap', () => {
  it('calls the correct discrepancy endpoint', async () => {
    const payload = {
      data: { events: [], vessel_information: VESSEL_INFO },
      meta: { total_count: 0 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchDiscrepanciesForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-positional-discrepancy/${IMO}`,
    );
  });

  it('returns flattened discrepancy events merged with vessel_information', async () => {
    const payload = {
      data: {
        events: [{ event_id: 'disc1', discrepancy_type: 'AIS_DARK' }],
        vessel_information: VESSEL_INFO,
      },
      meta: { total_count: 1 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchDiscrepanciesForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ event_id: 'disc1', imo: IMO });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('Discrepancy fetch failed: 500'),
    );

    await expect(
      fetchDiscrepanciesForMap(IMO, TS_START, TS_END),
    ).rejects.toThrow('Discrepancy fetch failed: 500');
  });
});

describe('fetchPSCForMap', () => {
  it('calls the correct PSC endpoint', async () => {
    const payload = {
      data: { inspections: [], vessel_information: VESSEL_INFO },
      meta: { total_count: 0 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchPSCForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain(
      `/voyage-insights/v1/vessel-port-state-control/${IMO}`,
    );
  });

  it('maps inspections (not events) merged with vessel_information', async () => {
    const payload = {
      data: {
        inspections: [{ inspection_id: 'psc1', port_name: 'Rotterdam' }],
        vessel_information: VESSEL_INFO,
      },
      meta: { total_count: 1 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    const result = await fetchPSCForMap(IMO, TS_START, TS_END);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ inspection_id: 'psc1', imo: IMO });
  });

  it('throws when handleResponse rejects', async () => {
    mockHandleResponse.mockRejectedValueOnce(
      new Error('PSC fetch failed: 500'),
    );

    await expect(fetchPSCForMap(IMO, TS_START, TS_END)).rejects.toThrow(
      'PSC fetch failed: 500',
    );
  });

  it('uses standard base params (timestamp_start, timestamp_end, limit=500)', async () => {
    const payload = {
      data: { inspections: [], vessel_information: VESSEL_INFO },
      meta: { total_count: 0 },
    };
    mockHandleResponse.mockResolvedValueOnce(payload);

    await fetchPSCForMap(IMO, TS_START, TS_END);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toContain('timestamp_start=');
    expect(calledUrl).toContain('timestamp_end=');
    expect(calledUrl).toContain('limit=500');
  });
});
