import { describe, it, expect, vi, beforeEach } from 'vitest';
import { fetchMTIScore } from '@/features/Vessels/services/mtiService';

/* ---------------- mocks ---------------- */

const { mockFetchWithAuth, API_GATEWAY_BASE_URL } = vi.hoisted(() => ({
  mockFetchWithAuth: vi.fn(),
  API_GATEWAY_BASE_URL: 'https://api.polestar-stage.com',
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL,
}));

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: mockFetchWithAuth,
}));

beforeEach(() => {
  vi.clearAllMocks();
  mockFetchWithAuth.mockClear();
});

/* ---------------- helpers ---------------- */

function okResponse<T>(data: T) {
  return {
    ok: true,
    json: async () => data,
  };
}

/* ---------------- fetchMTIScore ---------------- */

describe('fetchMTIScore', () => {
  it('sends POST request with correct method, headers, and body', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        meta: { request_id: 'req-1', timestamp: 1000 },
        data: {
          totals: { total_requested: 1, total_found: 1, total_not_found: 0 },
          vessels: [
            {
              imo_number: imo,
              mti_score: 4.75,
              updated_at: '2026-01-01',
            },
          ],
        },
      }),
    );

    await fetchMTIScore(imo);

    expect(mockFetchWithAuth).toHaveBeenCalledWith(
      `${API_GATEWAY_BASE_URL}/maritime-analytics/v1/mti/scores`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imo_numbers: [imo],
        }),
      },
    );
  });

  it('returns mti_score when vessel is found', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        meta: { request_id: 'req-1', timestamp: 1000 },
        data: {
          totals: { total_requested: 1, total_found: 1, total_not_found: 0 },
          vessels: [
            {
              imo_number: imo,
              mti_score: 3.5,
              updated_at: '2026-01-01',
            },
          ],
        },
      }),
    );

    const result = await fetchMTIScore(imo);

    expect(result).toBe(3.5);
  });

  it("returns 'unscored' when vessel has mti_score as 'unscored'", async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        meta: { request_id: 'req-1', timestamp: 1000 },
        data: {
          totals: { total_requested: 1, total_found: 1, total_not_found: 0 },
          vessels: [
            {
              imo_number: imo,
              mti_score: 'unscored',
              updated_at: '2026-01-01',
            },
          ],
        },
      }),
    );

    const result = await fetchMTIScore(imo);

    expect(result).toBe('unscored');
  });

  it("returns 'unscored' when vessel is not found (empty vessels array)", async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        meta: { request_id: 'req-1', timestamp: 1000 },
        data: {
          totals: { total_requested: 1, total_found: 0, total_not_found: 1 },
          vessels: [],
        },
      }),
    );

    const result = await fetchMTIScore(imo);

    expect(result).toBe('unscored');
  });

  it('throws error when response is not ok', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce({
      ok: false,
      status: 500,
      statusText: 'Internal Server Error',
    });

    await expect(fetchMTIScore(imo)).rejects.toThrow(
      'Failed to fetch MTI score (500): Internal Server Error',
    );
  });

  it('throws error with status code on 401', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
    });

    await expect(fetchMTIScore(imo)).rejects.toThrow(
      'Failed to fetch MTI score (401): Unauthorized',
    );
  });

  it('throws error with status code on 404', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce({
      ok: false,
      status: 404,
      statusText: 'Not Found',
    });

    await expect(fetchMTIScore(imo)).rejects.toThrow(
      'Failed to fetch MTI score (404): Not Found',
    );
  });

  it('throws error with fallback message when statusText is empty', async () => {
    const imo = '1234567';
    mockFetchWithAuth.mockResolvedValueOnce({
      ok: false,
      status: 500,
      statusText: '',
    });

    await expect(fetchMTIScore(imo)).rejects.toThrow(
      'Failed to fetch MTI score (500): Unknown error',
    );
  });
});
