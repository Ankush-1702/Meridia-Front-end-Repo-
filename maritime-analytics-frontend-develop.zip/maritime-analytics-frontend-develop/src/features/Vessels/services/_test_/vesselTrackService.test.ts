import { describe, it, expect, vi, beforeEach } from 'vitest';
import { fetchVesselTrack } from '@/features/Vessels/services/vesselTrackService';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL: 'https://api.test.example.com',
}));

const TEST_BASE_URL = 'https://api.test.example.com';

const mockFetchWithAuth = vi.fn();

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: (...args: Parameters<typeof mockFetchWithAuth>) =>
    mockFetchWithAuth(...args),
}));

vi.mock('@/shared/utils/authHeaders', () => ({
  getAuthHeaders: () => ({ Authorization: 'Bearer token' }),
}));

/* ─── helpers ───────────────────────────────────────────────────────────────── */

function okResponse<T>(data: T) {
  return { ok: true, status: 200, json: async () => data };
}

function statusResponse(status: number) {
  return { ok: false, status, json: async () => ({}), text: async () => '' };
}

const SAMPLE_POSITIONS = [
  {
    mmsi: 123,
    timestamp: '2024-01-01T02:00:00Z',
    latitude: 2,
    longitude: 2,
    speed: 5,
    course: 90,
    heading: 92,
    status: 'Under Way',
  },
  {
    mmsi: 123,
    timestamp: '2024-01-01T01:00:00Z',
    latitude: 1,
    longitude: 1,
    speed: 3,
    course: 80,
    heading: 82,
    status: 'Under Way',
  },
  {
    mmsi: 123,
    timestamp: '2024-01-01T00:00:00Z',
    latitude: 0,
    longitude: 0,
    speed: 0,
    course: 0,
    heading: 0,
    status: 'Moored',
  },
];

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
});

describe('fetchVesselTrack', () => {
  const FROM = new Date('2024-01-01T00:00:00Z');
  const TO = new Date('2024-01-01T12:00:00Z');

  it('returns empty array when imo is empty string', async () => {
    const result = await fetchVesselTrack('', FROM, TO);
    expect(result).toEqual([]);
    expect(mockFetchWithAuth).not.toHaveBeenCalled();
  });

  it('reverses API response to chronological order', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({ count: 3, data: SAMPLE_POSITIONS }),
    );

    const result = await fetchVesselTrack('IMO1234567', FROM, TO);

    expect(result).toHaveLength(3);
    // API returns newest-first; result must be oldest-first
    expect(result[0].timestamp).toBe('2024-01-01T00:00:00Z');
    expect(result[2].timestamp).toBe('2024-01-01T02:00:00Z');
  });

  it('returns empty array on 404', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(statusResponse(404));
    const result = await fetchVesselTrack('IMO1234567', FROM, TO);
    expect(result).toEqual([]);
  });

  it('throws on non-404 error status', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(statusResponse(500));
    await expect(fetchVesselTrack('IMO1234567', FROM, TO)).rejects.toThrow(
      'Track fetch failed: 500',
    );
  });

  it('includes timestampStart and timestampEnd query params', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(okResponse({ count: 0, data: [] }));

    await fetchVesselTrack('IMO1234567', FROM, TO);

    const calledUrl: string = mockFetchWithAuth.mock.calls[0][0];
    expect(calledUrl).toBe(
      `${TEST_BASE_URL}/maritime-analytics/positions/imo/IMO1234567?timestampStart=2024-01-01T00%3A00%3A00Z&timestampEnd=2024-01-01T12%3A00%3A00Z`,
    );
  });

  it('returns empty array when data field is absent', async () => {
    mockFetchWithAuth.mockResolvedValueOnce(okResponse({ count: 0 }));
    const result = await fetchVesselTrack('IMO1234567', FROM, TO);
    expect(result).toEqual([]);
  });
});
