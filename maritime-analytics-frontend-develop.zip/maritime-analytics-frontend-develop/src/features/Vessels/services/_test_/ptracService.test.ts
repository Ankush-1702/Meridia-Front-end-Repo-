import { describe, it, expect, vi, beforeEach } from 'vitest';
import { requestPtracScreening } from '@/features/Vessels/services/ptracService';

/* ---------------- mocks ---------------- */

const { mockFetchWithAuth, API_GATEWAY_BASE_URL } = vi.hoisted(() => ({
  mockFetchWithAuth: vi.fn(),
  API_GATEWAY_BASE_URL: 'http://localhost:8080',
}));

vi.mock('@/features/auth/utils/authUtil', () => ({
  fetchWithAuth: mockFetchWithAuth,
}));

vi.mock('@/app/config/config', () => ({
  API_GATEWAY_BASE_URL,
}));

beforeEach(() => {
  vi.clearAllMocks();
});

/* ---------------- helpers ---------------- */

function okResponse<T>(data: T) {
  return {
    ok: true,
    json: async () => data,
  };
}

function errorResponse(status: number, body?: unknown) {
  const bodyText = body ? JSON.stringify(body) : '';
  return {
    ok: false,
    status,
    statusText: '',
    json: async () => {
      if (body) return body;
      throw new Error('No JSON');
    },
    text: async () => bodyText,
  };
}

/* ---------------- requestPtracScreening ---------------- */

describe('requestPtracScreening', () => {
  it('sends POST request with correlation_id and imo_number in body', async () => {
    const imo = '1234567';
    const corrId = 'req-12345-abc';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        correlation_id: corrId,
        websocket_url: '/ws?userId=user-1',
        subscribe_destination: '/user/topic/screening-result',
      }),
    );

    await requestPtracScreening(imo, corrId);

    expect(mockFetchWithAuth).toHaveBeenCalledWith(
      `${API_GATEWAY_BASE_URL}/maritime-analytics/v1/ptrac/screening`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          correlation_id: corrId,
          imo_number: imo,
        }),
      },
    );
  });

  it('returns the correlation id and websocket details', async () => {
    const imo = '1234567';
    const corrId = 'req-12345-abc';
    mockFetchWithAuth.mockResolvedValueOnce(
      okResponse({
        correlation_id: corrId,
        websocket_url: '/ws?userId=user-1',
        subscribe_destination: '/user/topic/screening-result',
      }),
    );

    const result = await requestPtracScreening(imo, corrId);

    expect(result).toEqual({
      correlation_id: corrId,
      websocket_url: '/ws?userId=user-1',
      subscribe_destination: '/user/topic/screening-result',
    });
  });

  it('throws error with detail message when response is not ok', async () => {
    const imo = '1234567';
    const corrId = 'req-12345-abc';
    mockFetchWithAuth.mockResolvedValueOnce(
      errorResponse(401, {
        status: 401,
        field: 'authentication',
        title: 'Invalid authentication',
        detail: 'The JWT token which was submitted has expired.',
        resource_uri: '/v1/ptrac/screening',
      }),
    );

    await expect(requestPtracScreening(imo, corrId)).rejects.toThrow(
      'The JWT token which was submitted has expired.',
    );
  });

  it('throws error with generic message when no detail provided', async () => {
    const imo = '1234567';
    const corrId = 'req-12345-abc';
    mockFetchWithAuth.mockResolvedValueOnce(errorResponse(500));

    await expect(requestPtracScreening(imo, corrId)).rejects.toThrow();
  });
});
