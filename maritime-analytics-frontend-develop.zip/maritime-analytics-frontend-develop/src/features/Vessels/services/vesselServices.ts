// legacy-hosted services until ELZ migration
import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import {
  flattenedVesselAISGaps,
  flattenedVesselPortAndZone,
  flattenedVesselPortStateControl,
  flattenedVesselPositionalDiscrepancies,
  flattenedVesselSTSEvents,
  VesselAISGapsEvent,
  VesselPortAndZoneEvents,
  VesselPortStateControlEvent,
  VesselPositionalDiscrepanciesEvents,
  VesselSTSEvent,
} from '@/features/Vessels/types/vesselTypes';
import {
  buildParams,
  handleResponse,
} from '@/features/Vessels/utils/vesselUtils';
import { Vessel } from '@/shared/types/entities';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export async function fetchVesselDetails(imo: string): Promise<Vessel> {
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/vessel-insights/v1/vessel-characteristics/${imo}`,
    {
      headers: getAuthHeaders(),
    },
  );
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err || new Error('Failed to fetch vessel details');
  }
  const response = await res.json();
  return response.data;
}

export async function fetchVesselPortCalls(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{ data: flattenedVesselPortAndZone[]; totalCount: number }> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);
  params.append(
    'event_type',
    'PORT_ARRIVAL,PORT_DEPARTURE,PORT_AREA_ARRIVAL,PORT_AREA_DEPARTURE',
  );

  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselPortAndZoneEvents = actualResponse.data;
  const data: flattenedVesselPortAndZone[] = dataResponse.events.map(
    (event) => ({ ...event, ...dataResponse.vessel_information }),
  );
  return { data, totalCount: actualResponse.meta.total_count };
}

export async function fetchVesselZoneEvents(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{ data: flattenedVesselPortAndZone[]; totalCount: number }> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);
  params.append('event_type', 'ZONE_ENTRY,ZONE_EXIT');

  const res = await fetch(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselPortAndZoneEvents = actualResponse.data;
  const data: flattenedVesselPortAndZone[] = dataResponse.events.map(
    (event) => ({ ...event, ...dataResponse.vessel_information }),
  );
  return { data, totalCount: actualResponse.meta.total_count };
}

export async function fetchVesselAISGaps(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{ data: flattenedVesselAISGaps[]; totalCount: number }> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);
  params.append('gap_threshold_gte', '3');

  const res = await fetch(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-ais-reporting-gaps/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselAISGapsEvent = actualResponse.data;
  const data: flattenedVesselAISGaps[] = dataResponse.events.map((event) => ({
    ...event,
    ...dataResponse.vessel_information,
  }));
  return { data, totalCount: actualResponse.meta.total_count };
}

export async function fetchVesselSTSPairings(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{ data: flattenedVesselSTSEvents[]; totalCount: number }> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);

  const res = await fetch(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-sts-pairings/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselSTSEvent = actualResponse.data;
  const data: flattenedVesselSTSEvents[] = dataResponse.events.map((event) => ({
    ...event,
    ...dataResponse.vessel_information,
  }));
  return { data, totalCount: actualResponse.meta.total_count };
}

export async function fetchVesselPositionalDiscrepancies(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{
  data: flattenedVesselPositionalDiscrepancies[];
  totalCount: number;
}> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);

  const res = await fetch(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-positional-discrepancy/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselPositionalDiscrepanciesEvents = actualResponse.data;
  const data: flattenedVesselPositionalDiscrepancies[] =
    dataResponse.events.map((event) => ({
      ...event,
      ...dataResponse.vessel_information,
    }));
  return { data, totalCount: actualResponse.meta.total_count };
}

export async function fetchVesselPortStateControl(
  imo: string,
  timestamp_start?: string,
  timestamp_end?: string,
  offset?: number,
  limit?: number,
): Promise<{ data: flattenedVesselPortStateControl[]; totalCount: number }> {
  const params = buildParams(limit, offset, timestamp_start, timestamp_end);

  const res = await fetch(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-port-state-control/${imo}?${params.toString()}`,
    { headers: getAuthHeaders() },
  );

  const actualResponse = await handleResponse(res);
  const dataResponse: VesselPortStateControlEvent = actualResponse.data;
  const data: flattenedVesselPortStateControl[] = dataResponse.inspections.map(
    (inspection) => ({
      ...inspection,
      ...dataResponse.vessel_information,
    }),
  );
  return { data, totalCount: actualResponse.meta.total_count };
}
