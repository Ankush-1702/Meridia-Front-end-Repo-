import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { handleResponse } from '@/features/Vessels/services/handleResponse';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export interface AISPosition {
  timestamp: string;
  latitude: number;
  longitude: number;
  speed: number | null;
  heading: number | null;
  destination: string | null;
  destinationTooltip?: string | null;
  eta: string | null;
}

export interface LatestVoyagesResponse {
  meta: {
    limit: number;
    offset: number;
    request_id: string;
    request_timestamp: string;
  };
  data: {
    vessel: { imo_number: number };
    voyage_last_location: {
      position_timestamp: string;
      latitude: number;
      longitude: number;
      speed: number | null;
      heading: number | null;
      raw_destination: string | null;
      matched_destination: {
        port_name: string;
        unlocode: string;
        country: string;
      } | null;
      eta: string | null;
    };
  }[];
}

function normalizeTimestamp(value: string): string {
  if (/(?:Z|[+-]\d{2}:?\d{2})$/i.test(value)) {
    return value;
  }
  return `${value}Z`;
}

function normalizeHeading(value: number | null): number | null {
  if (value === null || value < 0 || value >= 360) {
    return null;
  }
  return value;
}

export async function fetchLatestVesselPosition(
  imo: string,
): Promise<AISPosition | null> {
  const url = new URL(
    `${API_GATEWAY_BASE_URL}/meridia-voyage-intelligence/v1/latest`,
  );
  url.searchParams.set('limit', '1');
  url.searchParams.set('offset', '0');

  const imoNumber = imo.replace(/\D/g, '') || imo;

  const res = await fetchWithAuth(url.toString(), {
    method: 'POST',
    headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ vessel: { imo_numbers: [imoNumber] } }),
  });

  const response = await handleResponse<LatestVoyagesResponse>(res);
  const item = response.data?.[0];
  if (!item) {
    return null;
  }

  const loc = item.voyage_last_location;
  const matched = loc.matched_destination;
  const destination = matched?.unlocode
    ? matched.unlocode
    : loc.raw_destination || null;
  const destinationTooltip = matched
    ? `${matched.port_name} - ${matched.country}`
    : null;

  return {
    timestamp: normalizeTimestamp(loc.position_timestamp),
    latitude: loc.latitude,
    longitude: loc.longitude,
    speed: loc.speed ?? null,
    heading: normalizeHeading(loc.heading),
    destination,
    destinationTooltip,
    eta: loc.eta || null,
  };
}
