import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';

interface MTIScoreResponse {
  meta: {
    request_id: string;
    timestamp: number;
  };
  data: {
    totals: {
      total_requested: number;
      total_found: number;
      total_not_found: number;
    };
    vessels: Array<{
      imo_number: string;
      mti_score: number | 'unscored';
      updated_at: string;
    }>;
  };
}

export async function fetchMTIScore(imo: string): Promise<number | 'unscored'> {
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/maritime-analytics/v1/mti/scores`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        imo_numbers: [imo],
      }),
    },
  );

  if (!res.ok) {
    throw new Error(
      `Failed to fetch MTI score (${res.status}): ${res.statusText || 'Unknown error'}`,
    );
  }

  const response: MTIScoreResponse = await res.json();
  const vessel = response.data?.vessels?.[0];

  return vessel?.mti_score ?? 'unscored';
}
