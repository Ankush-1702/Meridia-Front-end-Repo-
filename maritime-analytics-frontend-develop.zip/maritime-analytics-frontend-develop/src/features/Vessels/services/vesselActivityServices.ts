// legacy-hosted services until ELZ migration
import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { handleResponse } from '@/features/Vessels/services/handleResponse';
import {
  flattenedVesselAISGaps,
  flattenedVesselPortAndZone,
  flattenedVesselPortStateControl,
  flattenedVesselPositionalDiscrepancies,
  flattenedVesselSTSEvents,
  VesselAISGapsEvent,
  VesselPortAndZoneEvents,
  VesselPortStateControlEvent,
  VesselPositionalDiscrepanciesEvents,
  VesselSTSEvent,
} from '@/features/Vessels/types/vesselTypes';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

function buildParams(
  timestampStart: string,
  timestampEnd: string,
): URLSearchParams {
  const params = new URLSearchParams();
  params.append('timestamp_start', timestampStart);
  params.append('timestamp_end', timestampEnd);
  params.append('limit', '500');
  return params;
}

export async function fetchPortCallsForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselPortAndZone[]> {
  const params = buildParams(timestampStart, timestampEnd);
  params.append(
    'event_type',
    'PORT_ARRIVAL,PORT_DEPARTURE,PORT_AREA_ARRIVAL,PORT_AREA_DEPARTURE',
  );
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselPortAndZoneEvents;
    meta: { total_count: number };
  }>(res);
  return json.data.events.map((event) => ({
    ...event,
    ...json.data.vessel_information,
  }));
}

export async function fetchZoneEventsForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselPortAndZone[]> {
  const params = buildParams(timestampStart, timestampEnd);
  params.append('event_type', 'ZONE_ENTRY,ZONE_EXIT');
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-zone-and-port-events/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselPortAndZoneEvents;
    meta: { total_count: number };
  }>(res);
  return json.data.events.map((event) => ({
    ...event,
    ...json.data.vessel_information,
  }));
}

export async function fetchAISGapsForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselAISGaps[]> {
  const params = buildParams(timestampStart, timestampEnd);
  params.append('gap_threshold_gte', '3');
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-ais-reporting-gaps/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselAISGapsEvent;
    meta: { total_count: number };
  }>(res);
  return json.data.events.map((event) => ({
    ...event,
    ...json.data.vessel_information,
  }));
}

export async function fetchSTSForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselSTSEvents[]> {
  const params = buildParams(timestampStart, timestampEnd);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-sts-pairings/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselSTSEvent;
    meta: { total_count: number };
  }>(res);
  return json.data.events.map((event) => ({
    ...event,
    ...json.data.vessel_information,
  }));
}

export async function fetchDiscrepanciesForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselPositionalDiscrepancies[]> {
  const params = buildParams(timestampStart, timestampEnd);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-positional-discrepancy/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselPositionalDiscrepanciesEvents;
    meta: { total_count: number };
  }>(res);
  return json.data.events.map((event) => ({
    ...event,
    ...json.data.vessel_information,
  }));
}

export async function fetchPSCForMap(
  imo: string,
  timestampStart: string,
  timestampEnd: string,
): Promise<flattenedVesselPortStateControl[]> {
  const params = buildParams(timestampStart, timestampEnd);
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/voyage-insights/v1/vessel-port-state-control/${imo}?${params}`,
    { headers: getAuthHeaders() },
  );
  const json = await handleResponse<{
    data: VesselPortStateControlEvent;
    meta: { total_count: number };
  }>(res);
  return json.data.inspections.map((inspection) => ({
    ...inspection,
    ...json.data.vessel_information,
  }));
}
