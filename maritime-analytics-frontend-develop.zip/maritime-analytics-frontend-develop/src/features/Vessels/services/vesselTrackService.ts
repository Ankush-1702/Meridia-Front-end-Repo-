import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { getAuthHeaders } from '@/shared/utils/authHeaders';

export interface VesselPosition {
  mmsi: number;
  timestamp: string; // ISO-8601 UTC
  latitude: number;
  longitude: number;
  speed: number | null;
  course: number | null; // course over ground
  heading: number | null; // compass heading
  status: string | null;
}

interface TrackResponse {
  count: number;
  data: VesselPosition[];
}

function fmtTs(d: Date): string {
  return d.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export async function fetchVesselTrack(
  imo: string,
  from: Date,
  to: Date,
): Promise<VesselPosition[]> {
  if (!imo) return [];

  const url = new URL(
    `${API_GATEWAY_BASE_URL}/maritime-analytics/positions/imo/${imo}`,
  );
  url.searchParams.set('timestampStart', fmtTs(from));
  url.searchParams.set('timestampEnd', fmtTs(to));

  const res = await fetchWithAuth(url.toString(), {
    headers: getAuthHeaders(),
  });

  if (res.status === 404) return [];
  if (!res.ok) throw new Error(`Track fetch failed: ${res.status}`);

  const json: TrackResponse = await res.json();
  // API returns newest-first → reverse for chronological order
  return (json.data ?? []).reverse();
}
