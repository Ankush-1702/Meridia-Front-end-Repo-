import { API_GATEWAY_BASE_URL } from '@/app/config/config';
import { fetchWithAuth } from '@/features/auth/utils/authUtil';
import { PtracScreeningRequest } from '@/features/Vessels/types/ptracTypes';

export async function requestPtracScreening(
  imo: string,
  correlationId: string,
): Promise<PtracScreeningRequest> {
  const res = await fetchWithAuth(
    `${API_GATEWAY_BASE_URL}/maritime-analytics/v1/ptrac/screening`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        correlation_id: correlationId,
        imo_number: imo,
      }),
    },
  );

  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });

    const msg =
      errBody.message ||
      errBody.error ||
      errBody.detail ||
      res.statusText ||
      'Failed to request PurpleTRAC screening';

    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;

    throw err;
  }

  return res.json();
}
