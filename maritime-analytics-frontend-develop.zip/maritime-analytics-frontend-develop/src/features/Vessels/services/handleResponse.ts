export async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    let errBody: { message?: string; error?: string; detail?: string } = {};
    try {
      errBody = JSON.parse(text) as typeof errBody;
    } catch {
      errBody = { message: text || res.statusText };
    }
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number };
    err.status = res.status;
    throw err;
  }
  return res.json() as Promise<T>;
}
