import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import { DEFAULT_FILTERS } from '@/features/Vessels/types/vesselActivityTypes';
import type { ActivityFilters } from '@/features/Vessels/types/vesselActivityTypes';

/* ─── helpers ───────────────────────────────────────────────────────────────── */

/**
 * Reset the Zustand store to its initial state between tests.
 * We call the public reset methods and directly patch via setState.
 */
function resetStore() {
  const store = useVesselActivityStore.getState();
  store.resetReplay();
  store.resetActivityState();
  useVesselActivityStore.setState({
    filters: { ...DEFAULT_FILTERS },
    timelinePanelOpen: false,
    highlightedEventId: null,
    replaySpeed: 1,
    followVessel: false,
    pauseAtEvents: false,
    ganttOpen: false,
    ganttGroupMode: 'by-event-type',
    replayAnnouncedEvent: null,
    replayCountdownPaused: false,
  });
}

const DATE_RANGE = {
  from: new Date('2024-01-01T00:00:00Z'),
  to: new Date('2024-01-01T02:00:00Z'), // 2-hour window
};

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.useFakeTimers();
  resetStore();
});

afterEach(() => {
  vi.useRealTimers();
  resetStore();
});

describe('useVesselActivityStore — initial state', () => {
  it('has all filters enabled by default', () => {
    const { filters } = useVesselActivityStore.getState();
    expect(filters).toEqual(DEFAULT_FILTERS);
    expect(filters.port_arrival).toBe(true);
    expect(filters.port_departure).toBe(true);
    expect(filters.zone_entry).toBe(true);
    expect(filters.zone_exit).toBe(true);
    expect(filters.ais_gap).toBe(true);
    expect(filters.sts).toBe(true);
    expect(filters.discrepancy).toBe(true);
    expect(filters.psc).toBe(true);
  });

  it('has replay disabled at startup', () => {
    const { isReplaying, replayAt } = useVesselActivityStore.getState();
    expect(isReplaying).toBe(false);
    expect(replayAt).toBeNull();
  });

  it('has default replaySpeed of 1', () => {
    expect(useVesselActivityStore.getState().replaySpeed).toBe(1);
  });

  it('has an empty announcedEventIds set', () => {
    const { announcedEventIds } = useVesselActivityStore.getState();
    expect(announcedEventIds.size).toBe(0);
  });

  it('has timelinePanelOpen false', () => {
    expect(useVesselActivityStore.getState().timelinePanelOpen).toBe(false);
  });

  it('has highlightedEventId null', () => {
    expect(useVesselActivityStore.getState().highlightedEventId).toBeNull();
  });

  it('has ganttGroupMode set to by-event-type', () => {
    expect(useVesselActivityStore.getState().ganttGroupMode).toBe(
      'by-event-type',
    );
  });
});

describe('toggleFilter', () => {
  it('flips a true filter to false', () => {
    const { toggleFilter } = useVesselActivityStore.getState();
    toggleFilter('port_arrival');
    expect(useVesselActivityStore.getState().filters.port_arrival).toBe(false);
  });

  it('flips a false filter back to true', () => {
    useVesselActivityStore.setState({
      filters: { ...DEFAULT_FILTERS, ais_gap: false },
    });
    const { toggleFilter } = useVesselActivityStore.getState();
    toggleFilter('ais_gap');
    expect(useVesselActivityStore.getState().filters.ais_gap).toBe(true);
  });

  it('only changes the toggled category, leaving others intact', () => {
    const { toggleFilter } = useVesselActivityStore.getState();
    toggleFilter('zone_entry');

    const { filters } = useVesselActivityStore.getState();
    expect(filters.zone_entry).toBe(false);
    expect(filters.port_arrival).toBe(true);
    expect(filters.port_departure).toBe(true);
    expect(filters.ais_gap).toBe(true);
    expect(filters.sts).toBe(true);
    expect(filters.discrepancy).toBe(true);
    expect(filters.psc).toBe(true);
  });

  it('can toggle multiple different categories independently', () => {
    const { toggleFilter } = useVesselActivityStore.getState();
    toggleFilter('sts');
    toggleFilter('psc');

    const { filters } = useVesselActivityStore.getState();
    expect(filters.sts).toBe(false);
    expect(filters.psc).toBe(false);
    expect(filters.port_arrival).toBe(true);
  });
});

describe('setFilters', () => {
  it('replaces the entire filters object', () => {
    const newFilters: ActivityFilters = {
      port_arrival: false,
      port_departure: false,
      zone_entry: false,
      zone_exit: false,
      ais_gap: false,
      sts: true,
      discrepancy: true,
      psc: false,
    };
    useVesselActivityStore.getState().setFilters(newFilters);
    expect(useVesselActivityStore.getState().filters).toEqual(newFilters);
  });

  it('completely replaces previous filters, not merging', () => {
    useVesselActivityStore.setState({
      filters: { ...DEFAULT_FILTERS, port_arrival: false },
    });

    const allOff: ActivityFilters = {
      port_arrival: false,
      port_departure: false,
      zone_entry: false,
      zone_exit: false,
      ais_gap: false,
      sts: false,
      discrepancy: false,
      psc: false,
    };
    useVesselActivityStore.getState().setFilters(allOff);

    const { filters } = useVesselActivityStore.getState();
    Object.values(filters).forEach((v) => expect(v).toBe(false));
  });
});

describe('startReplay', () => {
  it('sets isReplaying to true', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().isReplaying).toBe(true);
  });

  it('sets replayAt to dateRange.from when cursor is null', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().replayAt).toEqual(DATE_RANGE.from);
  });

  it('resets cursor to dateRange.from when cursor is at or past the end', () => {
    useVesselActivityStore.setState({ replayAt: DATE_RANGE.to });
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().replayAt).toEqual(DATE_RANGE.from);
  });

  it('resumes from current cursor position when it is within the range', () => {
    const midPoint = new Date('2024-01-01T01:00:00Z');
    useVesselActivityStore.setState({ replayAt: midPoint });
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().replayAt).toEqual(midPoint);
  });

  it('clears announcedEventIds on restart (cursor at end)', () => {
    useVesselActivityStore.setState({
      replayAt: DATE_RANGE.to,
      announcedEventIds: new Set(['evt1', 'evt2']),
    });
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().announcedEventIds.size).toBe(0);
  });

  it('does not start a second replay if already replaying', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    const replayAtAfterFirst = useVesselActivityStore.getState().replayAt;

    // Advance time so the timer would normally move replayAt forward
    vi.advanceTimersByTime(500);
    const replayAtMid = useVesselActivityStore.getState().replayAt;

    // Calling startReplay again while replaying should be a no-op
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().replayAt).toEqual(replayAtMid);
    expect(replayAtMid).not.toEqual(replayAtAfterFirst);
  });

  it('bails out without starting when rangeMs <= 0 (from === to)', () => {
    const zeroRange = {
      from: new Date('2024-01-01T00:00:00Z'),
      to: new Date('2024-01-01T00:00:00Z'),
    };
    useVesselActivityStore.getState().startReplay(zeroRange);
    expect(useVesselActivityStore.getState().isReplaying).toBe(false);
  });

  it('bails out without starting when to is before from', () => {
    const negativeRange = {
      from: new Date('2024-01-01T02:00:00Z'),
      to: new Date('2024-01-01T00:00:00Z'),
    };
    useVesselActivityStore.getState().startReplay(negativeRange);
    expect(useVesselActivityStore.getState().isReplaying).toBe(false);
  });

  it('advances replayAt over time via the setInterval ticker', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    const atStart = useVesselActivityStore.getState().replayAt!.getTime();

    vi.advanceTimersByTime(200); // 4 ticks at 50ms each

    const atLater = useVesselActivityStore.getState().replayAt!.getTime();
    expect(atLater).toBeGreaterThan(atStart);
  });

  it('stops replaying and clamps replayAt at dateRange.to when the range is exhausted', () => {
    // Start replay, then manually advance replayAt to just before the end
    // so the very next tick pushes it over the boundary.
    useVesselActivityStore.getState().startReplay(DATE_RANGE);

    // Place cursor 1ms before the end — one tick will overshoot and clamp
    useVesselActivityStore.setState({
      replayAt: new Date(DATE_RANGE.to.getTime() - 1),
    });

    // Fire one tick (50ms interval)
    vi.advanceTimersByTime(50);

    const state = useVesselActivityStore.getState();
    expect(state.isReplaying).toBe(false);
    expect(state.replayAt!.getTime()).toBe(DATE_RANGE.to.getTime());
  });
});

describe('pauseReplay', () => {
  it('sets isReplaying to false', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    expect(useVesselActivityStore.getState().isReplaying).toBe(true);

    useVesselActivityStore.getState().pauseReplay();
    expect(useVesselActivityStore.getState().isReplaying).toBe(false);
  });

  it('stops the timer so replayAt no longer advances', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    useVesselActivityStore.getState().pauseReplay();

    const atPause = useVesselActivityStore.getState().replayAt!.getTime();
    vi.advanceTimersByTime(500);
    const atLater = useVesselActivityStore.getState().replayAt!.getTime();

    expect(atLater).toBe(atPause);
  });

  it('preserves replayAt position after pause', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    vi.advanceTimersByTime(200);
    const atPause = useVesselActivityStore.getState().replayAt;

    useVesselActivityStore.getState().pauseReplay();
    expect(useVesselActivityStore.getState().replayAt).toEqual(atPause);
  });
});

describe('resetReplay', () => {
  it('sets replayAt to null', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    useVesselActivityStore.getState().resetReplay();
    expect(useVesselActivityStore.getState().replayAt).toBeNull();
  });

  it('sets isReplaying to false', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    useVesselActivityStore.getState().resetReplay();
    expect(useVesselActivityStore.getState().isReplaying).toBe(false);
  });

  it('clears announcedEventIds', () => {
    useVesselActivityStore.setState({
      announcedEventIds: new Set(['a', 'b', 'c']),
    });
    useVesselActivityStore.getState().resetReplay();
    expect(useVesselActivityStore.getState().announcedEventIds.size).toBe(0);
  });

  it('clears replayAnnouncedEvent', () => {
    useVesselActivityStore.setState({
      replayAnnouncedEvent: [{ id: 'e1' } as never],
    });
    useVesselActivityStore.getState().resetReplay();
    expect(useVesselActivityStore.getState().replayAnnouncedEvent).toBeNull();
  });

  it('stops the timer so replayAt stays null after reset', () => {
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    useVesselActivityStore.getState().resetReplay();

    vi.advanceTimersByTime(500);
    expect(useVesselActivityStore.getState().replayAt).toBeNull();
  });
});

describe('setReplaySpeed', () => {
  it('updates replaySpeed to the given value', () => {
    useVesselActivityStore.getState().setReplaySpeed(5);
    expect(useVesselActivityStore.getState().replaySpeed).toBe(5);
  });

  it('can set speed to each supported option', () => {
    const speeds = [1, 2, 5, 10];
    speeds.forEach((speed) => {
      useVesselActivityStore.getState().setReplaySpeed(speed);
      expect(useVesselActivityStore.getState().replaySpeed).toBe(speed);
    });
  });

  it('affects how fast replayAt advances during replay', () => {
    // Start at speed 1
    useVesselActivityStore.getState().setReplaySpeed(1);
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    vi.advanceTimersByTime(50); // one tick
    const atSpeed1 = useVesselActivityStore.getState().replayAt!.getTime();

    resetStore();
    vi.clearAllTimers();

    // Start at speed 10
    useVesselActivityStore.getState().setReplaySpeed(10);
    useVesselActivityStore.getState().startReplay(DATE_RANGE);
    vi.advanceTimersByTime(50); // one tick
    const atSpeed10 = useVesselActivityStore.getState().replayAt!.getTime();

    // Speed 10 should have advanced further than speed 1
    expect(atSpeed10 - DATE_RANGE.from.getTime()).toBeGreaterThan(
      atSpeed1 - DATE_RANGE.from.getTime(),
    );
  });
});

describe('markEventsAnnounced', () => {
  it('adds new ids to the announcedEventIds set', () => {
    useVesselActivityStore.getState().markEventsAnnounced(['evt1', 'evt2']);
    const { announcedEventIds } = useVesselActivityStore.getState();
    expect(announcedEventIds.has('evt1')).toBe(true);
    expect(announcedEventIds.has('evt2')).toBe(true);
  });

  it('accumulates ids across multiple calls', () => {
    useVesselActivityStore.getState().markEventsAnnounced(['evt1']);
    useVesselActivityStore.getState().markEventsAnnounced(['evt2', 'evt3']);

    const { announcedEventIds } = useVesselActivityStore.getState();
    expect(announcedEventIds.size).toBe(3);
    expect(announcedEventIds.has('evt1')).toBe(true);
    expect(announcedEventIds.has('evt2')).toBe(true);
    expect(announcedEventIds.has('evt3')).toBe(true);
  });

  it('is idempotent: adding the same id twice does not duplicate it', () => {
    useVesselActivityStore.getState().markEventsAnnounced(['evt1']);
    useVesselActivityStore.getState().markEventsAnnounced(['evt1', 'evt2']);

    const { announcedEventIds } = useVesselActivityStore.getState();
    expect(announcedEventIds.size).toBe(2);
  });

  it('does not affect other store state', () => {
    useVesselActivityStore.getState().markEventsAnnounced(['evt1']);

    const { isReplaying, replayAt, filters } =
      useVesselActivityStore.getState();
    expect(isReplaying).toBe(false);
    expect(replayAt).toBeNull();
    expect(filters).toEqual(DEFAULT_FILTERS);
  });
});
