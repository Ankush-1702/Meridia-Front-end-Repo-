import { create } from 'zustand';
import {
  ActivityEvent,
  ActivityFilters,
  DEFAULT_FILTERS,
  LegendEventKey,
} from '@/features/Vessels/types/vesselActivityTypes';

export type GanttGroupMode = 'by-event-type' | 'by-location';

export type DateRange = {
  from: Date;
  to: Date;
};

interface VesselActivityState {
  filters: ActivityFilters;
  timelinePanelOpen: boolean;
  highlightedEventId: string | null;
  toggleFilter: (key: LegendEventKey) => void;
  setFilters: (filters: ActivityFilters) => void;
  setTimelinePanelOpen: (open: boolean) => void;
  setHighlightedEventId: (id: string | null) => void;

  // Replay state
  replayAt: Date | null;
  isReplaying: boolean;
  replaySpeed: number;
  isScrubbing: boolean;
  followVessel: boolean;
  pauseAtEvents: boolean;
  ganttOpen: boolean;
  ganttGroupMode: GanttGroupMode;
  announcedEventIds: Set<string>;
  replayAnnouncedEvent: ActivityEvent[] | null;
  replayCountdownPaused: boolean;
  setReplayAt: (at: Date | null) => void;
  startReplay: (dateRange: DateRange) => void;
  pauseReplay: () => void;
  resetReplay: () => void;
  setReplaySpeed: (speed: number) => void;
  setIsScrubbing: (v: boolean) => void;
  setFollowVessel: (v: boolean) => void;
  setPauseAtEvents: (v: boolean) => void;
  setGanttOpen: (open: boolean) => void;
  setGanttGroupMode: (mode: GanttGroupMode) => void;
  markEventsAnnounced: (ids: string[]) => void;
  setReplayAnnouncedEvent: (events: ActivityEvent[] | null) => void;
  setReplayCountdownPaused: (paused: boolean) => void;
  resetActivityState: () => void;
}

let _replayTimer: ReturnType<typeof setInterval> | null = null;

function _clearTimer() {
  if (_replayTimer !== null) {
    clearInterval(_replayTimer);
    _replayTimer = null;
  }
}

const REPLAY_TICK_MS = 50;
const REPLAY_FULL_PLAY_SECS = 120; // full range completes in 2 min at 1×

export const REPLAY_SPEED_OPTIONS = [1, 2, 5, 10];

export const useVesselActivityStore = create<VesselActivityState>(
  (set, get) => ({
    filters: { ...DEFAULT_FILTERS },
    timelinePanelOpen: false,
    highlightedEventId: null,
    toggleFilter: (key) =>
      set((state) => ({
        filters: { ...state.filters, [key]: !state.filters[key] },
      })),
    setFilters: (filters) => set({ filters }),
    setTimelinePanelOpen: (open) => set({ timelinePanelOpen: open }),
    setHighlightedEventId: (id) => set({ highlightedEventId: id }),

    // Replay state
    replayAt: null,
    isReplaying: false,
    replaySpeed: 1,
    isScrubbing: false,
    followVessel: false,
    pauseAtEvents: false,
    ganttOpen: false,
    ganttGroupMode: 'by-event-type',
    announcedEventIds: new Set(),
    replayAnnouncedEvent: null,
    replayCountdownPaused: false,

    setReplayAt: (at) => set({ replayAt: at }),

    startReplay: (dateRange: DateRange) => {
      const state = get();
      if (state.isReplaying) return;

      // If cursor is null or at/past the end, restart from the beginning
      const restarting =
        state.replayAt === null ||
        state.replayAt.getTime() >= dateRange.to.getTime();
      const startAt = restarting ? dateRange.from : state.replayAt!;

      set({
        isReplaying: true,
        replayAt: startAt,
        // Clear announced events when restarting so pauses fire again
        announcedEventIds: restarting ? new Set() : state.announcedEventIds,
      });

      _clearTimer();
      const rangeMs = dateRange.to.getTime() - dateRange.from.getTime();
      if (rangeMs <= 0) {
        set({ isReplaying: false });
        return;
      }
      const baseRate = rangeMs / REPLAY_FULL_PLAY_SECS;

      _replayTimer = setInterval(() => {
        const s = get();
        if (!s.isReplaying || s.replayAt === null) return;

        const advanceMs = baseRate * s.replaySpeed * (REPLAY_TICK_MS / 1000);
        const newMs = Math.min(
          s.replayAt.getTime() + advanceMs,
          dateRange.to.getTime(),
        );

        if (newMs >= dateRange.to.getTime()) {
          set({ replayAt: new Date(newMs), isReplaying: false });
          _clearTimer();
        } else {
          set({ replayAt: new Date(newMs) });
        }
      }, REPLAY_TICK_MS);
    },

    pauseReplay: () => {
      _clearTimer();
      set({ isReplaying: false });
    },

    resetReplay: () => {
      _clearTimer();
      set({
        replayAt: null,
        isReplaying: false,
        announcedEventIds: new Set(),
        replayAnnouncedEvent: null,
        replayCountdownPaused: false,
      });
    },

    setReplaySpeed: (speed) => set({ replaySpeed: speed }),
    setIsScrubbing: (v) => set({ isScrubbing: v }),
    setFollowVessel: (v) => set({ followVessel: v }),
    setPauseAtEvents: (v) => set({ pauseAtEvents: v }),
    setGanttOpen: (open) => set({ ganttOpen: open }),
    setGanttGroupMode: (mode) => set({ ganttGroupMode: mode }),
    markEventsAnnounced: (ids) =>
      set((s) => ({
        announcedEventIds: new Set([...s.announcedEventIds, ...ids]),
      })),
    setReplayAnnouncedEvent: (events) =>
      set({
        replayAnnouncedEvent: events,
        ...(events === null ? { replayCountdownPaused: false } : {}),
      }),
    setReplayCountdownPaused: (paused) =>
      set({ replayCountdownPaused: paused }),
    resetActivityState: () => {
      _clearTimer();
      set({
        replayAt: null,
        isReplaying: false,
        isScrubbing: false,
        highlightedEventId: null,
        ganttOpen: false,
        announcedEventIds: new Set(),
        replayAnnouncedEvent: null,
        replayCountdownPaused: false,
      });
    },
  }),
);
