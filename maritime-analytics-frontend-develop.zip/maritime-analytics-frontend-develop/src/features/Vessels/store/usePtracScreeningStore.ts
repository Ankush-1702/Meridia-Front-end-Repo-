import { create } from 'zustand';
import { PtracOverallStatus } from '@/features/Vessels/types/ptracTypes';

export interface PtracScreeningSnapshot {
  status: PtracOverallStatus | null;
  loading: boolean;
  error: Error | null;
  startedAt: number | null;
  correlationId: string | null;
}

export const EMPTY_PTRAC_SNAPSHOT: PtracScreeningSnapshot = {
  status: null,
  loading: false,
  error: null,
  startedAt: null,
  correlationId: null,
};

interface PtracScreeningStoreState {
  sessions: Record<string, PtracScreeningSnapshot>;
  setSnapshot: (imo: string, patch: Partial<PtracScreeningSnapshot>) => void;
}

// Reactive per-IMO screening state only — the live STOMP client and timeout
// handle aren't serializable UI state, so they're kept out of this store
// (see the `connections` map in usePtracScreening.ts).
export const usePtracScreeningStore = create<PtracScreeningStoreState>(
  (set) => ({
    sessions: {},
    setSnapshot: (imo, patch) =>
      set((state) => ({
        sessions: {
          ...state.sessions,
          [imo]: {
            ...(state.sessions[imo] ?? EMPTY_PTRAC_SNAPSHOT),
            ...patch,
          },
        },
      })),
  }),
);
