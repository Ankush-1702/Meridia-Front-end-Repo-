import { VesselSearch } from '@/features/library/types/LibraryTypes';

const STORAGE_KEY = 'meridia_recent_vessels';
const MAX_RECENT = 6;

export function getRecentVessels(): VesselSearch[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as VesselSearch[]) : [];
  } catch {
    return [];
  }
}

export function addRecentVessel(vessel: VesselSearch): void {
  try {
    const existing = getRecentVessels();
    const deduped = [
      vessel,
      ...existing.filter((v) => v.imo !== vessel.imo),
    ].slice(0, MAX_RECENT);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(deduped));
  } catch {
    // silently ignore storage errors
  }
}
