// ─── Mercator interpolation ───────────────────────────────────────────────────
//
// Mapbox renders each GeoJSON LineString segment as a straight line in Web
// Mercator (tile) space.  The midpoint of that rendered segment in screen-pixel
// space therefore corresponds to the midpoint in Mercator coordinates, NOT the
// arithmetic midpoint of the two latitudes.
//
// For short AIS segments (< 5 km) the difference is sub-millimetre, but for
// segments of tens or hundreds of kilometres the divergence can be many pixels
// wide at max zoom.
//
// This helper replicates Mapbox's own interpolation so the vessel icon is
// always placed on the mathematically correct point of the rendered line.
//
// Longitude is linear in Mercator, so only latitude needs the non-linear
// transformation.  Formula:
//   Mercator y  = ln( tan(π/4 + φ/2) )      where φ is latitude in radians
//   latitude    = ( 2·atan(exp(y)) − π/2 ) · (180/π)

/** Web Mercator is only defined within this latitude range. Beyond ±85.0511°
 *  tan(π/4 + lat·π/360) approaches 0 or ∞, making Math.log return -Infinity
 *  or Infinity, which then propagates as NaN through the rest of the math. */
export const MAX_MERCATOR_LAT = 85.0511;

const clampLat = (lat: number): number =>
  Math.max(-MAX_MERCATOR_LAT, Math.min(MAX_MERCATOR_LAT, lat));

const toMercY = (lat: number): number =>
  Math.log(Math.tan(Math.PI / 4 + (clampLat(lat) * Math.PI) / 360));

const fromMercY = (y: number): number =>
  ((2 * Math.atan(Math.exp(y)) - Math.PI / 2) * 180) / Math.PI;

/**
 * Interpolates between two WGS-84 coordinates in Web Mercator space.
 *
 * @param lng1 - Longitude of start point (degrees)
 * @param lat1 - Latitude  of start point (degrees)
 * @param lng2 - Longitude of end point   (degrees)
 * @param lat2 - Latitude  of end point   (degrees)
 * @param t    - Interpolation factor in [0, 1]  (0 → start, 1 → end)
 * @returns [longitude, latitude] of the interpolated point (degrees)
 */
export function mercatorInterpolate(
  lng1: number,
  lat1: number,
  lng2: number,
  lat2: number,
  t: number,
): [number, number] {
  const lng = lng1 + t * (lng2 - lng1);
  const y1 = toMercY(lat1);
  const y2 = toMercY(lat2);
  const y = y1 + t * (y2 - y1);
  return [lng, fromMercY(y)];
}
