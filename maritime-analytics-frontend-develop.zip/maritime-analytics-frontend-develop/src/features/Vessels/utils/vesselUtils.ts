import {
  flattenedVesselAISGaps,
  flattenedVesselPortAndZone,
  flattenedVesselPortStateControl,
  flattenedVesselPositionalDiscrepancies,
  flattenedVesselSTSEvents,
  FlatVesselEventsResponse,
} from '@/features/Vessels/types/vesselTypes';
import { logger } from '@/shared/utils/logger';

function flattenEventsSafely<T>(
  events: T[],
  flatten: (event: T) => FlatVesselEventsResponse,
  eventName: string,
  getEventContext: (event: T) => Record<string, unknown>,
): FlatVesselEventsResponse[] {
  return events.flatMap((event) => {
    try {
      return [flatten(event)];
    } catch (error) {
      logger.warn(`Skipping ${eventName} that could not be flattened`, {
        ...getEventContext(event),
        error,
      });
      return [];
    }
  });
}

export function buildParams(
  limit?: number,
  offset?: number,
  timestamp_start?: string,
  timestamp_end?: string,
): URLSearchParams {
  const params = new URLSearchParams({
    limit: limit?.toString() || '500',
    offset: offset?.toString() || '0',
  });
  if (timestamp_start) params.append('timestamp_start', timestamp_start);
  if (timestamp_end) params.append('timestamp_end', timestamp_end);
  return params;
}

export async function handleResponse(res: Response) {
  if (!res.ok) {
    const errBody = await res.json().catch(async () => {
      const t = await res.text();
      return { message: t };
    });
    const msg =
      errBody.message || errBody.error || errBody.detail || res.statusText;
    const err = new Error(msg) as Error & { status: number; body: unknown };
    err.status = res.status;
    err.body = errBody;
    throw err;
  }
  return res.json();
}

export function flattenPortOrZoneEvent(
  event: flattenedVesselPortAndZone,
  eventType?: string,
): FlatVesselEventsResponse {
  return {
    eventTimestamp: event?.event_details?.event_timestamp ?? '',
    eventType: event?.event_details?.event_type ?? '',
    location: event?.zone_information?.name ?? '',
    country: event?.zone_information?.country_common_name ?? '',
    countryFlag: event?.zone_information?.country_code ?? '',
    unlocode:
      eventType === 'ZONE_EVENTS'
        ? ''
        : (event?.zone_information?.unlocode ?? ''),
    zoneType: event?.zone_information?.type ?? '',
    speed: event?.event_details?.speed ?? 0,
    course: event?.event_details?.course ?? 0,
    vesselName: event?.name ?? '',
    imo: event?.imo ?? '',
    mmsi: event?.mmsi ?? '',
    callSign: event?.callsign ?? '',
    flag: event?.flag ?? '',
    flagCode: event?.flag_code ?? '',
    vesselType: event?.vessel_type ?? '',
    heading: event?.event_details?.heading ?? 0,
    draught: event?.event_details?.draught ?? 0,
    navigationalStatusStatus: event?.event_details?.navigational_status ?? '',
    reportedDestination: event?.event_details?.reported_destination ?? '',
    reportedEta: event?.event_details?.reported_eta ?? '',
    zoneId: event?.zone_information?.id ?? '',
  };
}

export function flattenPositionalDiscrepancy(
  event: flattenedVesselPositionalDiscrepancies,
): FlatVesselEventsResponse {
  return {
    eventType: 'POSITIONAL_DISCREPANCY',
    eventTimestamp: event?.started?.timestamp ?? '',
    callSign: event?.callsign ?? '',
    flag: event?.flag ?? '',
    flagCode: event?.flag_code ?? '',
    imo: event?.imo ?? '',
    mmsi: event?.mmsi ?? '',
    vesselName: event?.name ?? '',
    vesselType: event?.vessel_type ?? '',
    duration: event?.duration_hours ?? 0,
    hasEnded: event?.has_ended ?? false,
    startedLatitude: event?.started?.latitude ?? 0,
    startedLongitude: event?.started?.longitude ?? 0,
    stoppedTimestamp: event?.stopped?.timestamp ?? '',
    stoppedLatitude: event?.stopped?.latitude ?? 0,
    stoppedLongitude: event?.stopped?.longitude ?? 0,
  };
}

export function flattenSTSEvent(
  event: flattenedVesselSTSEvents,
): FlatVesselEventsResponse {
  return {
    callSign: event?.callsign ?? '',
    flag: event?.flag ?? '',
    flagCode: event?.flag_code ?? '',
    imo: event?.imo ?? '',
    mmsi: event?.mmsi ?? '',
    vesselName: event?.name ?? '',
    vesselType: event?.vessel_type ?? '',
    eventType: 'STS_PAIRING',
    eventTimestamp: event?.started ?? '',
    stsType: event?.sts_type ?? '',
    stsEnded: event?.stopped ?? '',
    duration: event?.duration_hours ?? 0,
    pairedVessel: event?.paired_vessel?.name ?? '',
    pairedIMO: event?.paired_vessel?.imo ?? '',
  };
}

export function flattenAISGap(
  event: flattenedVesselAISGaps,
): FlatVesselEventsResponse {
  return {
    callSign: event?.callsign ?? '',
    flag: event?.flag ?? '',
    flagCode: event?.flag_code ?? '',
    imo: event?.imo ?? '',
    mmsi: event?.mmsi ?? '',
    vesselName: event?.name ?? '',
    vesselType: event?.vessel_type ?? '',
    eventType: 'AIS_GAP',
    duration: event?.gap_duration_hours ?? 0,
    speed: event?.stopped?.speed ?? 0,
    course: event?.stopped?.course ?? 0,
    navigationalStatusCode: event?.stopped?.navigational_status?.code ?? 0,
    navigationalStatusStatus: event?.stopped?.navigational_status?.status ?? '',
    eventTimestamp: event?.stopped?.timestamp ?? '',
    draughtChange: event?.draught_change ?? 0,
    gapResumed: event?.resumed?.timestamp ?? '',
    gapStopped: event?.stopped?.timestamp ?? '',
  };
}

export function flattenPortStateControl(
  event: flattenedVesselPortStateControl,
): FlatVesselEventsResponse {
  return {
    callSign: event?.callsign ?? '',
    flag: event?.flag ?? '',
    flagCode: event?.flag_code ?? '',
    imo: event?.imo ?? '',
    mmsi: event?.mmsi ?? '',
    vesselName: event?.name ?? '',
    vesselType: event?.vessel_type ?? '',
    authority: event?.authority ?? '',
    detained: event?.detained ?? false,
    daysDetained: event?.no_days_detained ?? 0,
    inspectionDate: event?.inspection_date ?? '',
    inspectionType: event?.inspection_type ?? '',
    numberOfDefects: event?.no_defects ?? 0,
    releaseDate: event?.release_date ?? '',
    eventType: 'PORT_STATE_CONTROL',
    eventTimestamp: event?.inspection_date ?? '',
    location: event?.port_information?.name ?? '',
    country: event?.port_information?.country_common_name ?? '',
    countryFlag: event?.port_information?.country_code ?? '',
  };
}

export const flattenPortCalls = (
  events: flattenedVesselPortAndZone[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(
    events,
    (event) => flattenPortOrZoneEvent(event),
    'vessel port event',
    (event) => ({
      eventId: event?.event_details?.event_id,
      eventType: event?.event_details?.event_type,
    }),
  );

export const flattenZoneEvents = (
  events: flattenedVesselPortAndZone[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(
    events,
    (event) => flattenPortOrZoneEvent(event, 'ZONE_EVENTS'),
    'vessel zone event',
    (event) => ({
      eventId: event?.event_details?.event_id,
      eventType: event?.event_details?.event_type,
    }),
  );

export const flattenPositionalDiscrepancies = (
  events: flattenedVesselPositionalDiscrepancies[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(
    events,
    flattenPositionalDiscrepancy,
    'vessel positional discrepancy',
    (event) => ({ eventType: event?.event_type, imo: event?.imo }),
  );

export const flattenSTSEvents = (
  events: flattenedVesselSTSEvents[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(events, flattenSTSEvent, 'vessel STS event', (event) => ({
    eventType: 'STS_PAIRING',
    imo: event?.imo,
  }));

export const flattenAISGaps = (
  events: flattenedVesselAISGaps[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(events, flattenAISGap, 'vessel AIS gap', (event) => ({
    eventId: event?.event_id,
    eventType: 'AIS_GAP',
    imo: event?.imo,
  }));

export const flattenPortStateControls = (
  events: flattenedVesselPortStateControl[],
): FlatVesselEventsResponse[] =>
  flattenEventsSafely(
    events,
    flattenPortStateControl,
    'vessel port state control event',
    (event) => ({
      eventType: 'PORT_STATE_CONTROL',
      imo: event?.imo,
      inspectionDate: event?.inspection_date,
    }),
  );

export const TAB_EVENT_TYPES: Record<string, string[]> = {
  PORT_CALLS: [
    'PORT_AREA_ARRIVAL',
    'PORT_AREA_DEPARTURE',
    'PORT_ARRIVAL',
    'PORT_DEPARTURE',
  ],
  ZONE_EVENTS: ['ZONE_ENTRY', 'ZONE_EXIT'],
  AIS_GAPS: ['AIS_GAP'],
  STS_PAIRINGS: ['STS_PAIRING'],
  POSITIONAL_DISCREPANCIES: ['POSITIONAL_DISCREPANCY'],
  PORT_STATE_CONTROL: ['PORT_STATE_CONTROL'],
};

export const EVENT_TYPE_MAP: Record<string, string> = {
  PORT_AREA_ARRIVAL: 'AREA_ARRIVAL',
  PORT_AREA_DEPARTURE: 'AREA_DEPARTURE',
  PORT_ARRIVAL: 'ARRIVAL',
  PORT_DEPARTURE: 'DEPARTURE',
  AIS_GAPS: 'AIS_GAP',
  STS_PAIRINGS: 'STS_PAIRING',
  POSITIONAL_DISCREPANCIES: 'POSITIONAL_DISCREPANCY',
  PORT_STATE_CONTROL: 'PORT_STATE_CONTROL',
};
