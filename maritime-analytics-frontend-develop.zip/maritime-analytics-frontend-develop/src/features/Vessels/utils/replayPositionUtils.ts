import type { VesselPosition } from '@/features/Vessels/services/vesselTrackService';

export interface PositionArrays {
  timestampMs: number[];
  latitudes: number[];
  longitudes: number[];
  cogs: number[]; // course-over-ground bearing between consecutive positions
}

export interface InterpolatedPosition {
  latitude: number;
  longitude: number;
  bearing: number;
}

// ─── Bearing calc ─────────────────────────────────────────────────────────────

function toRad(d: number) {
  return (d * Math.PI) / 180;
}
function toDeg(r: number) {
  return (r * 180) / Math.PI;
}

function calcBearing(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const dLng = toRad(lng2 - lng1);
  const y = Math.sin(dLng) * Math.cos(toRad(lat2));
  const x =
    Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
    Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(dLng);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

// ─── Build parallel arrays ────────────────────────────────────────────────────

export function buildPositionArrays(
  positions: VesselPosition[],
): PositionArrays {
  const n = positions.length;
  const timestampMs = positions.map((p) => new Date(p.timestamp).getTime());
  const latitudes = positions.map((p) => p.latitude);
  const longitudes = positions.map((p) => p.longitude);

  const cogs = positions.map((p, i) => {
    if (i + 1 < n) {
      return calcBearing(
        p.latitude,
        p.longitude,
        positions[i + 1].latitude,
        positions[i + 1].longitude,
      );
    }
    if (i > 0) {
      return calcBearing(
        positions[i - 1].latitude,
        positions[i - 1].longitude,
        p.latitude,
        p.longitude,
      );
    }
    return 0;
  });

  return { timestampMs, latitudes, longitudes, cogs };
}

// ─── Binary search ────────────────────────────────────────────────────────────

/** Largest index i where arr[i] <= target. Returns -1 if none. */
function upperFloor(arr: number[], target: number): number {
  let lo = 0,
    hi = arr.length - 1,
    result = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid] <= target) {
      result = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return result;
}

// ─── Interpolation ────────────────────────────────────────────────────────────

export function interpolatePosition(
  arrays: PositionArrays,
  targetMs: number,
): InterpolatedPosition | null {
  const { timestampMs, latitudes, longitudes, cogs } = arrays;
  if (timestampMs.length === 0) return null;

  const idx = upperFloor(timestampMs, targetMs);
  if (idx === -1) return null;

  if (idx === timestampMs.length - 1) {
    return {
      latitude: latitudes[idx],
      longitude: longitudes[idx],
      bearing: cogs[idx],
    };
  }

  const t0 = timestampMs[idx];
  const t1 = timestampMs[idx + 1];

  if (t1 <= t0) {
    return {
      latitude: latitudes[idx],
      longitude: longitudes[idx],
      bearing: cogs[idx],
    };
  }

  const frac = (targetMs - t0) / (t1 - t0);

  return {
    latitude: latitudes[idx] + frac * (latitudes[idx + 1] - latitudes[idx]),
    longitude: longitudes[idx] + frac * (longitudes[idx + 1] - longitudes[idx]),
    bearing: cogs[idx],
  };
}

// ─── Track split ──────────────────────────────────────────────────────────────

/** Index of the last position at or before targetMs. -1 if none. */
export function findTrackSplitIndex(
  timestampMs: number[],
  targetMs: number,
): number {
  return upperFloor(timestampMs, targetMs);
}

// ─── Track color modes ────────────────────────────────────────────────────────

export type TrackColorMode = 'speed' | 'nav_status';

export function getSpeedColor(speed: number | null): string {
  if (speed === null || speed < 0.1) return '#FAAF89'; // stopped
  if (speed < 5) return '#F5C842'; // slow
  if (speed < 15) return '#2B969C'; // medium
  return '#1E6FA5'; // fast
}

export function getNavStatusColor(status: string | null): string {
  if (!status) return '#2B969C';
  const s = status.toLowerCase();
  if (s.includes('moored') || s.includes('anchor')) return '#FAAF89';
  if (s.includes('under way') || s.includes('underway')) return '#2B969C';
  return '#81E4E3'; // other / unknown
}

export function getTrackColor(
  speed: number | null,
  status: string | null,
  mode: TrackColorMode,
): string {
  if (mode === 'nav_status') return getNavStatusColor(status);
  return getSpeedColor(speed);
}

export const TRACK_COLOR_LEGEND: Record<
  TrackColorMode,
  Array<{ label: string; color: string }>
> = {
  speed: [
    { label: 'Stopped (< 0.1 kn)', color: '#FAAF89' },
    { label: 'Slow (0.1–5 kn)', color: '#F5C842' },
    { label: 'Medium (5–15 kn)', color: '#2B969C' },
    { label: 'Fast (≥ 15 kn)', color: '#1E6FA5' },
  ],
  nav_status: [
    { label: 'Underway', color: '#2B969C' },
    { label: 'Moored / Anchored', color: '#FAAF89' },
    { label: 'Other', color: '#81E4E3' },
  ],
};

// ─── GeoJSON builder ──────────────────────────────────────────────────────────

type GeoJSONFeatureCollection = {
  type: 'FeatureCollection';
  features: Array<{
    type: 'Feature';
    properties: { color: string };
    geometry: { type: 'LineString'; coordinates: [number, number][] };
  }>;
};

export function buildTrackGeoJSON(
  positions: VesselPosition[],
  startIdx: number,
  endIdx: number,
  colorMode: TrackColorMode = 'speed',
): GeoJSONFeatureCollection {
  const slice = positions.slice(
    Math.max(0, startIdx),
    Math.min(positions.length - 1, endIdx) + 1,
  );

  if (slice.length < 2) {
    return { type: 'FeatureCollection', features: [] };
  }

  const features: GeoJSONFeatureCollection['features'] = [];
  let segStart = 0;
  let curColor = getTrackColor(slice[0].speed, slice[0].status, colorMode);

  for (let i = 1; i <= slice.length; i++) {
    const color =
      i < slice.length
        ? getTrackColor(slice[i].speed, slice[i].status, colorMode)
        : null;

    if (color !== curColor || i === slice.length) {
      // Emit current segment
      const coords = slice
        .slice(segStart, i)
        .map((p): [number, number] => [p.longitude, p.latitude]);
      if (coords.length >= 2) {
        features.push({
          type: 'Feature',
          properties: { color: curColor },
          geometry: { type: 'LineString', coordinates: coords },
        });
      }
      // New segment starts at the overlap point
      if (color !== null) {
        curColor = color;
        segStart = i - 1;
      }
    }
  }

  return { type: 'FeatureCollection', features };
}

export const EMPTY_GEOJSON: GeoJSONFeatureCollection = {
  type: 'FeatureCollection',
  features: [],
};
