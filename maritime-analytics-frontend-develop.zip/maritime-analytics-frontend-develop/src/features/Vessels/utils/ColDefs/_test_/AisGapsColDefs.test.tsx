import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { createVesselAISGapsColDefs } from '@/features/Vessels/utils/ColDefs/AisGapsColDefs';

/* ---------------- mocks ---------------- */

const mockConvertUTC = vi.fn();
const mockConvertHuman = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
): string {
  const element = renderer({ value } as CustomCellRendererProps);
  return (element.props.children ?? '') as string;
}

/* ---------------- tests ---------------- */

describe('createVesselAISGapsColDefs', () => {
  it('creates expected number of column definitions', () => {
    const cols = createVesselAISGapsColDefs('utc');
    expect(cols.length).toBe(24);
  });

  it('uses UTC headers and formatting when timezone is utc', () => {
    mockConvertHuman.mockReturnValue('UTC_TIME');

    const cols = createVesselAISGapsColDefs('utc');
    const stoppedCol = cols[0];

    expect(stoppedCol.headerName).toContain('(UTC)');

    const value = renderCell(stoppedCol.cellRenderer!, '2024-01-01');
    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('UTC_TIME');
  });

  it('uses system headers and local formatting when timezone is system', () => {
    mockConvertUTC.mockReturnValue('LOCAL_TIME');

    const cols = createVesselAISGapsColDefs('system');
    const stoppedCol = cols[0];

    expect(stoppedCol.headerName).toContain('(System)');

    const value = renderCell(stoppedCol.cellRenderer!, '2024-01-01');
    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('LOCAL_TIME');
  });

  it('renders "-" when timestamp value is empty', () => {
    mockConvertHuman.mockReturnValue(undefined);

    const cols = createVesselAISGapsColDefs('utc');
    const stoppedCol = cols[0];

    const value = renderCell(stoppedCol.cellRenderer!, undefined);
    expect(value).toBe('-');
  });

  it('renders numeric and string values correctly', () => {
    const cols = createVesselAISGapsColDefs('utc');

    const durationCol = cols.find((c) => c.field === 'gap_duration_hours')!;
    const value = renderCell(durationCol.cellRenderer!, 12);

    expect(value).toBe(12);
  });

  it('renders "-" for falsy numeric values', () => {
    const cols = createVesselAISGapsColDefs('utc');

    const speedCol = cols.find((c) => c.field === 'stopped.speed')!;
    const value = renderCell(speedCol.cellRenderer!, null);

    expect(value).toBe('-');
  });

  it('marks vessel metadata columns as hidden', () => {
    const cols = createVesselAISGapsColDefs('utc');

    const hiddenFields = [
      'name',
      'imo',
      'mmsi',
      'callsign',
      'flag',
      'vessel_type',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });
});
