import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { createVesselPortStateControlColDefs } from '@/features/Vessels/utils/ColDefs/PortStateControlColDefs';

/* ---------------- mocks ---------------- */

const mockConvertHuman = vi.fn();
const mockConvertUTC = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
): string {
  const element = renderer({ value } as CustomCellRendererProps);
  return (element.props.children ?? '-') as string;
}

/* ---------------- tests ---------------- */

describe('createVesselPortStateControlColDefs', () => {
  it('creates expected number of columns', () => {
    const cols = createVesselPortStateControlColDefs('utc');
    expect(cols.length).toBe(11);
  });

  it('uses UTC header and formatting when timezone is utc', () => {
    mockConvertHuman.mockReturnValue('UTC_DATE');

    const cols = createVesselPortStateControlColDefs('utc');
    const dateCol = cols[0];

    expect(dateCol.headerName).toContain('(UTC)');

    const value = renderCell(dateCol.cellRenderer!, '2024-01-01');
    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('UTC_DATE');
  });

  it('uses system header and local formatting when timezone is system', () => {
    mockConvertUTC.mockReturnValue('LOCAL_DATE');

    const cols = createVesselPortStateControlColDefs('system');
    const dateCol = cols[0];

    expect(dateCol.headerName).toContain('(System)');

    const value = renderCell(dateCol.cellRenderer!, '2024-01-01');
    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('LOCAL_DATE');
  });

  it('renders "-" when inspection date is missing', () => {
    mockConvertHuman.mockReturnValue(undefined);

    const cols = createVesselPortStateControlColDefs('utc');
    const dateCol = cols[0];

    const value = renderCell(dateCol.cellRenderer!, undefined);
    expect(value).toBe('-');
  });

  it('renders "-" for empty text fields', () => {
    const cols = createVesselPortStateControlColDefs('utc');
    const portCol = cols.find((c) => c.field === 'port_information.name')!;

    const value = renderCell(portCol.cellRenderer!, undefined);
    expect(value).toBe('-');
  });

  it('marks expected columns as hidden', () => {
    const cols = createVesselPortStateControlColDefs('utc');

    const hiddenFields = [
      'detained',
      'no_days_detained',
      'no_defects',
      'release_date',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });
});
