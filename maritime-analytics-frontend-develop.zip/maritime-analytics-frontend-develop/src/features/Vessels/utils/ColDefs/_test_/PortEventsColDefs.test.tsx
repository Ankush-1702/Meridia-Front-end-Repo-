import { ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { flattenedVesselPortAndZone } from '@/features/Vessels/types/vesselTypes';
import { createVesselPortEventsColDefs } from '@/features/Vessels/utils/ColDefs/PortEventsColDefs';

/* ---------------- mocks ---------------- */

const mockConvertHuman = vi.fn();
const mockConvertUTC = vi.fn();
const mockToTitleCase = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
  toTitleCase: (v: string) => mockToTitleCase(v),
}));

vi.mock('@/shared/components/Badge', () => ({
  default: (props: { status: string }) => <span>{props.status}</span>,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: (props: { flagCode?: string }) => (
    <span>{props.flagCode ?? 'NO_FLAG'}</span>
  ),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
  data?: Record<string, unknown>,
): React.ReactNode {
  const element = renderer({
    value,
    data,
  } as CustomCellRendererProps);
  return element.props.children;
}

/* ---------------- tests ---------------- */

describe('createVesselPortEventsColDefs', () => {
  it('contains required core columns', () => {
    const cols = createVesselPortEventsColDefs('utc');

    const fields = cols.map((c) => c.field);

    expect(fields).toContain('event_details.event_timestamp');
    expect(fields).toContain('event_details.event_type');
    expect(fields).toContain('zone_information.name');
    expect(fields).toContain('zone_information.country_official_name');
  });

  it('uses UTC header and formatting when timezone is utc', () => {
    mockConvertHuman.mockReturnValue('UTC_TIME');

    const cols = createVesselPortEventsColDefs('utc');
    const timestampCol = cols[0];

    expect(timestampCol.headerName).toContain('(UTC)');

    const value = renderCell(timestampCol.cellRenderer!, '2024-01-01');

    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('UTC_TIME');
  });

  it('uses system header and local formatting when timezone is system', () => {
    mockConvertUTC.mockReturnValue('LOCAL_TIME');

    const cols = createVesselPortEventsColDefs('system');
    const timestampCol = cols[0];

    expect(timestampCol.headerName).toContain('(System)');

    const value = renderCell(timestampCol.cellRenderer!, '2024-01-01');

    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('LOCAL_TIME');
  });

  it('formats tooltip value for Event column correctly', () => {
    mockToTitleCase.mockReturnValue('Arrival');

    const cols = createVesselPortEventsColDefs('utc');
    const eventCol = cols[1];

    const params: ITooltipParams<flattenedVesselPortAndZone> = {
      value: 'PORT_ARRIVAL',
      location: 'cell',
      api: {} as ITooltipParams<flattenedVesselPortAndZone>['api'],
      context: {},
    };

    const tooltip = eventCol.tooltipValueGetter?.(params);

    expect(mockToTitleCase).toHaveBeenCalledWith('ARRIVAL');
    expect(tooltip).toBe('Arrival');
  });

  it('renders StatusBadge with correct status', () => {
    const cols = createVesselPortEventsColDefs('utc');
    const eventCol = cols[1];

    const element = eventCol.cellRenderer!({
      value: 'PORT_DEPARTURE',
    } as CustomCellRendererProps);

    expect(element.type).toBeDefined();
  });

  it('passes correct country code to FlagIcon', () => {
    const cols = createVesselPortEventsColDefs('utc');
    const countryCol = cols[3];

    const element = countryCol.cellRenderer!({
      value: 'Norway',
      data: {
        zone_information: {
          country_code: 'NO',
        },
      },
    } as CustomCellRendererProps);

    const flagIcon = element.props.children[0];
    expect(flagIcon.props.flagCode).toBe('NO');
  });

  it('renders "-" when value is missing', () => {
    const cols = createVesselPortEventsColDefs('utc');
    const portCol = cols[2];

    const value = renderCell(portCol.cellRenderer!, undefined);
    expect(value).toBe('-');
  });

  it('marks expected columns as hidden', () => {
    const cols = createVesselPortEventsColDefs('utc');

    const hiddenFields = [
      'zone_information.unlocode',
      'zone_information.sub_division_code',
      'zone_information.sub_division_name',
      'zone_information.wpi_number',
      'zone_information.country_common_name',
      'zone_information.centroid.longitude',
      'zone_information.centroid.latitude',
      'event_details.heading',
      'event_details.course',
      'event_details.draught',
      'event_details.latitude',
      'event_details.longitude',
      'event_details.navigational_status',
      'event_details.reported_destination',
      'event_details.reported_eta',
      'event_details.speed',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });
});
