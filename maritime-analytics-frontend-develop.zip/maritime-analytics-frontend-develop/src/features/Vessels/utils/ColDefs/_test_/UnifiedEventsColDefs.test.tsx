import { render } from '@testing-library/react';
import { ColDef, ColGroupDef } from 'ag-grid-enterprise';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { FlatVesselEventsResponse } from '@/features/Vessels/types/vesselTypes';
import { CreateUnifiedVesselEventsColDefs } from '@/features/Vessels/utils/ColDefs/UnifiedEventsColDefs';

// Mock the format utilities
vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (date?: string) =>
    date ? `UTC: ${date}` : null,
  convertUTCToLocalTime: (date?: string) => (date ? `Local: ${date}` : null),
  getEventLabel: (event: string) => `Label: ${event}`,
}));

// Mock components
vi.mock('@/shared/components/Badge', () => ({
  default: ({ status }: { status: string }) => <div>Badge: {status}</div>,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: ({ flagCode }: { flagCode?: string }) => (
    <div>Flag: {flagCode || 'none'}</div>
  ),
}));

const mockVesselEvent: FlatVesselEventsResponse = {
  eventTimestamp: '2024-01-01T12:00:00Z',
  eventType: 'PORT_ARRIVAL',
  location: 'Rotterdam',
  country: 'Netherlands',
  countryFlag: 'NL',
  unlocode: 'NLRTM',
  zoneType: 'Port Area',
  speed: 12.5,
  course: 180,
  duration: 2.5,
  vesselName: 'Test Vessel',
  imo: '1234567',
  mmsi: '123456789',
  callSign: 'ABC123',
  flag: 'Netherlands',
  flagCode: 'NL',
  vesselType: 'Cargo',
  heading: 175,
  draught: 8.5,
  navigationalStatusStatus: 'Under way using engine',
  navigationalStatusCode: 0,
  reportedDestination: 'USNYC',
  reportedEta: '2024-01-02T08:00:00Z',
  authority: 'Port State Control',
  inspectionType: 'Initial',
  inspectionDate: '2024-01-01T10:00:00Z',
  detained: true,
  daysDetained: 3,
  numberOfDefects: 5,
  releaseDate: '2024-01-04T10:00:00Z',
  stsType: 'Alongside',
  pairedVessel: 'Partner Vessel',
  pairedIMO: '7654321',
  stsEnded: '2024-01-01T14:00:00Z',
  gapStopped: '2024-01-01T06:00:00Z',
  gapResumed: '2024-01-01T08:00:00Z',
  draughtChange: 1.2,
  hasEnded: false,
  startedLatitude: 51.9225,
  startedLongitude: 4.4792,
  stoppedTimestamp: '2024-01-01T09:00:00Z',
  stoppedLatitude: 51.925,
  stoppedLongitude: 4.48,
};

// Type guard to check if a column definition is a ColDef
function isColDef(
  col: ColDef<FlatVesselEventsResponse> | ColGroupDef<FlatVesselEventsResponse>,
): col is ColDef<FlatVesselEventsResponse> {
  return 'field' in col || 'cellRenderer' in col;
}

// Type guard to check if a column definition is a ColGroupDef
function isColGroupDef(
  col: ColDef<FlatVesselEventsResponse> | ColGroupDef<FlatVesselEventsResponse>,
): col is ColGroupDef<FlatVesselEventsResponse> {
  return 'children' in col;
}

describe('CreateUnifiedVesselEventsColDefs', () => {
  describe('UTC timezone setting', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('creates column definitions with correct structure', () => {
      expect(columns).toBeDefined();
      expect(columns.length).toBeGreaterThan(0);
    });

    it('has Overview group as first column group', () => {
      const overviewGroup = columns[0];
      expect(overviewGroup.headerName).toBe('Overview');
      expect(isColGroupDef(overviewGroup)).toBe(true);
    });

    it('formats timestamp column header for UTC', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const timestampCol = overviewGroup.children?.[0];
        expect(timestampCol?.headerName).toBe('TimeStamp (UTC)');
      }
    });

    it('renders timestamp cell with UTC format', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const timestampCol = overviewGroup.children?.[0];
        if (
          timestampCol &&
          isColDef(timestampCol) &&
          timestampCol.cellRenderer
        ) {
          const CellRenderer = timestampCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T12:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T12:00:00Z');
        }
      }
    });

    it('renders event type with StatusBadge', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const eventCol = overviewGroup.children?.[1];
        if (eventCol && isColDef(eventCol) && eventCol.cellRenderer) {
          const CellRenderer = eventCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value="PORT_ARRIVAL" />);
          expect(container.textContent).toBe('Badge: PORT_ARRIVAL');
        }
      }
    });

    it('renders location with dash when null', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const locationCol = overviewGroup.children?.[2];
        if (locationCol && isColDef(locationCol) && locationCol.cellRenderer) {
          const CellRenderer = locationCol.cellRenderer as (props: {
            value: null;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={null} />);
          expect(container.textContent).toBe('-');
        }
      }
    });

    it('renders country with flag icon when value exists', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const countryCol = overviewGroup.children?.[3];
        if (countryCol && isColDef(countryCol) && countryCol.cellRenderer) {
          const CellRenderer = countryCol.cellRenderer as (props: {
            value: string;
            data: FlatVesselEventsResponse;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="Netherlands" data={mockVesselEvent} />,
          );
          expect(container.textContent).toContain('Flag: NL');
          expect(container.textContent).toContain('Netherlands');
        }
      }
    });

    it('renders country with dash when null', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const countryCol = overviewGroup.children?.[3];
        if (countryCol && isColDef(countryCol) && countryCol.cellRenderer) {
          const CellRenderer = countryCol.cellRenderer as (props: {
            value: null;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={null} />);
          expect(container.textContent).toBe('-');
        }
      }
    });

    it('formats speed with knots suffix', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const speedCol = overviewGroup.children?.[6];
        if (speedCol && isColDef(speedCol) && speedCol.cellRenderer) {
          const CellRenderer = speedCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={12.5} />);
          expect(container.textContent).toBe('12.5 kn');
        }
      }
    });

    it('formats course with degree suffix', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const courseCol = overviewGroup.children?.[7];
        if (courseCol && isColDef(courseCol) && courseCol.cellRenderer) {
          const CellRenderer = courseCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={180} />);
          expect(container.textContent).toBe('180°');
        }
      }
    });

    it('formats numeric values as dash when null', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const speedCol = overviewGroup.children?.[6];
        if (speedCol && isColDef(speedCol) && speedCol.cellRenderer) {
          const CellRenderer = speedCol.cellRenderer as (props: {
            value: null;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={null} />);
          expect(container.textContent).toBe('-');
        }
      }
    });
  });

  describe('System timezone setting', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('system');
    });

    it('formats timestamp column header for System time', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const timestampCol = overviewGroup.children?.[0];
        expect(timestampCol?.headerName).toBe('TimeStamp (System)');
      }
    });

    it('renders timestamp cell with local format', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const timestampCol = overviewGroup.children?.[0];
        if (
          timestampCol &&
          isColDef(timestampCol) &&
          timestampCol.cellRenderer
        ) {
          const CellRenderer = timestampCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T12:00:00Z" />,
          );
          expect(container.textContent).toBe('Local: 2024-01-01T12:00:00Z');
        }
      }
    });

    it('formats Reported ETA header for System time', () => {
      const positionGroup = columns.find(
        (col) => col.headerName === 'Position & movement',
      );
      if (positionGroup && isColGroupDef(positionGroup)) {
        const reportedEtaCol = positionGroup.children?.find(
          (col) => isColDef(col) && col.field === 'reportedEta',
        );
        expect(reportedEtaCol?.headerName).toBe('Reported ETA (System)');
      }
    });
  });

  describe('Vessel identity group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('has Vessel identity group', () => {
      const vesselGroup = columns.find(
        (col) => col.headerName === 'Vessel identity',
      );
      expect(vesselGroup).toBeDefined();
    });

    it('renders vessel name with flag icon', () => {
      const vesselGroup = columns.find(
        (col) => col.headerName === 'Vessel identity',
      );
      if (vesselGroup && isColGroupDef(vesselGroup)) {
        const vesselCol = vesselGroup.children?.find(
          (col) => isColDef(col) && col.field === 'vesselName',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (vesselCol && vesselCol.cellRenderer) {
          const CellRenderer = vesselCol.cellRenderer as (props: {
            value: string;
            data: FlatVesselEventsResponse;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="Test Vessel" data={mockVesselEvent} />,
          );
          expect(container.textContent).toContain('Flag: NL');
          expect(container.textContent).toContain('Test Vessel');
        }
      }
    });

    it('hides vessel identity columns by default', () => {
      const vesselGroup = columns.find(
        (col) => col.headerName === 'Vessel identity',
      );
      if (vesselGroup && isColGroupDef(vesselGroup)) {
        vesselGroup.children?.forEach((col) => {
          if (isColDef(col)) {
            expect(col.hide).toBe(true);
          }
        });
      }
    });

    it('includes tooltips for all vessel identity fields', () => {
      const vesselGroup = columns.find(
        (col) => col.headerName === 'Vessel identity',
      );
      if (vesselGroup && isColGroupDef(vesselGroup)) {
        vesselGroup.children?.forEach((col) => {
          if (isColDef(col)) {
            expect('tooltipField' in col || 'tooltipValueGetter' in col).toBe(
              true,
            );
          }
        });
      }
    });
  });

  describe('Position & movement group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('formats heading with degree suffix', () => {
      const positionGroup = columns.find(
        (col) => col.headerName === 'Position & movement',
      );
      if (positionGroup && isColGroupDef(positionGroup)) {
        const headingCol = positionGroup.children?.find(
          (col) => isColDef(col) && col.field === 'heading',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (headingCol && headingCol.cellRenderer) {
          const CellRenderer = headingCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={175} />);
          expect(container.textContent).toBe('175°');
        }
      }
    });

    it('formats draught with meter suffix', () => {
      const positionGroup = columns.find(
        (col) => col.headerName === 'Position & movement',
      );
      if (positionGroup && isColGroupDef(positionGroup)) {
        const draughtCol = positionGroup.children?.find(
          (col) => isColDef(col) && col.field === 'draught',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (draughtCol && draughtCol.cellRenderer) {
          const CellRenderer = draughtCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={8.5} />);
          expect(container.textContent).toBe('8.5 m');
        }
      }
    });

    it('renders navigational status with dash when null', () => {
      const positionGroup = columns.find(
        (col) => col.headerName === 'Position & movement',
      );
      if (positionGroup && isColGroupDef(positionGroup)) {
        const navStatusCol = positionGroup.children?.find(
          (col) => isColDef(col) && col.field === 'navigationalStatusStatus',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (navStatusCol && navStatusCol.cellRenderer) {
          const CellRenderer = navStatusCol.cellRenderer as (props: {
            value: null;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={null} />);
          expect(container.textContent).toBe('-');
        }
      }
    });

    it('renders reported ETA with UTC format when timezone is utc', () => {
      const positionGroup = columns.find(
        (col) => col.headerName === 'Position & movement',
      );
      if (positionGroup && isColGroupDef(positionGroup)) {
        const etaCol = positionGroup.children?.find(
          (col) => isColDef(col) && col.field === 'reportedEta',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (etaCol && etaCol.cellRenderer) {
          const CellRenderer = etaCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-02T08:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-02T08:00:00Z');
        }
      }
    });
  });

  describe('Port State Control group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('formats detained as Yes/No/Dash', () => {
      const pscGroup = columns.find(
        (col) => col.headerName === 'Port State Control',
      );
      if (pscGroup && isColGroupDef(pscGroup)) {
        const detainedCol = pscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'detained',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (detainedCol && detainedCol.cellRenderer) {
          const CellRenderer = detainedCol.cellRenderer as (props: {
            value: boolean | null;
          }) => JSX.Element;

          const { container: trueContainer } = render(
            <CellRenderer value={true} />,
          );
          expect(trueContainer.textContent).toBe('Yes');

          const { container: falseContainer } = render(
            <CellRenderer value={false} />,
          );
          expect(falseContainer.textContent).toBe('No');

          const { container: nullContainer } = render(
            <CellRenderer value={null} />,
          );
          expect(nullContainer.textContent).toBe('-');
        }
      }
    });

    it('formats inspection date with UTC format', () => {
      const pscGroup = columns.find(
        (col) => col.headerName === 'Port State Control',
      );
      if (pscGroup && isColGroupDef(pscGroup)) {
        const inspectionCol = pscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'inspectionDate',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (inspectionCol && inspectionCol.cellRenderer) {
          const CellRenderer = inspectionCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T10:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T10:00:00Z');
        }
      }
    });

    it('formats release date with UTC format', () => {
      const pscGroup = columns.find(
        (col) => col.headerName === 'Port State Control',
      );
      if (pscGroup && isColGroupDef(pscGroup)) {
        const releaseCol = pscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'releaseDate',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (releaseCol && releaseCol.cellRenderer) {
          const CellRenderer = releaseCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-04T10:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-04T10:00:00Z');
        }
      }
    });
  });

  describe('STS pairing group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('formats STS ended with UTC format', () => {
      const stsGroup = columns.find((col) => col.headerName === 'STS pairing');
      if (stsGroup && isColGroupDef(stsGroup)) {
        const stsEndedCol = stsGroup.children?.find(
          (col) => isColDef(col) && col.field === 'stsEnded',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (stsEndedCol && stsEndedCol.cellRenderer) {
          const CellRenderer = stsEndedCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T14:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T14:00:00Z');
        }
      }
    });

    it('renders paired vessel info with dash when null', () => {
      const stsGroup = columns.find((col) => col.headerName === 'STS pairing');
      if (stsGroup && isColGroupDef(stsGroup)) {
        const pairedVesselCol = stsGroup.children?.find(
          (col) => isColDef(col) && col.field === 'pairedVessel',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (pairedVesselCol && pairedVesselCol.cellRenderer) {
          const CellRenderer = pairedVesselCol.cellRenderer as (props: {
            value: null;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={null} />);
          expect(container.textContent).toBe('-');
        }
      }
    });
  });

  describe('AIS gap group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('formats gap stopped with UTC format', () => {
      const aisGroup = columns.find((col) => col.headerName === 'AIS gap');
      if (aisGroup && isColGroupDef(aisGroup)) {
        const gapStoppedCol = aisGroup.children?.find(
          (col) => isColDef(col) && col.field === 'gapStopped',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (gapStoppedCol && gapStoppedCol.cellRenderer) {
          const CellRenderer = gapStoppedCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T06:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T06:00:00Z');
        }
      }
    });

    it('formats gap resumed with UTC format', () => {
      const aisGroup = columns.find((col) => col.headerName === 'AIS gap');
      if (aisGroup && isColGroupDef(aisGroup)) {
        const gapResumedCol = aisGroup.children?.find(
          (col) => isColDef(col) && col.field === 'gapResumed',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (gapResumedCol && gapResumedCol.cellRenderer) {
          const CellRenderer = gapResumedCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T08:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T08:00:00Z');
        }
      }
    });

    it('formats draught change with meter suffix', () => {
      const aisGroup = columns.find((col) => col.headerName === 'AIS gap');
      if (aisGroup && isColGroupDef(aisGroup)) {
        const draughtChangeCol = aisGroup.children?.find(
          (col) => isColDef(col) && col.field === 'draughtChange',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (draughtChangeCol && draughtChangeCol.cellRenderer) {
          const CellRenderer = draughtChangeCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={1.2} />);
          expect(container.textContent).toBe('1.2 m');
        }
      }
    });
  });

  describe('Positional discrepancy group', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('formats hasEnded as Yes/No/Dash', () => {
      const posDiscGroup = columns.find(
        (col) => col.headerName === 'Positional discrepancy',
      );
      if (posDiscGroup && isColGroupDef(posDiscGroup)) {
        const hasEndedCol = posDiscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'hasEnded',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (hasEndedCol && hasEndedCol.cellRenderer) {
          const CellRenderer = hasEndedCol.cellRenderer as (props: {
            value: boolean;
          }) => JSX.Element;

          const { container: falseContainer } = render(
            <CellRenderer value={false} />,
          );
          expect(falseContainer.textContent).toBe('No');
        }
      }
    });

    it('formats latitude with degree suffix and 4 decimals', () => {
      const posDiscGroup = columns.find(
        (col) => col.headerName === 'Positional discrepancy',
      );
      if (posDiscGroup && isColGroupDef(posDiscGroup)) {
        const latCol = posDiscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'startedLatitude',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (latCol && latCol.cellRenderer) {
          const CellRenderer = latCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={51.9225} />);
          expect(container.textContent).toBe('51.9225°');
        }
      }
    });

    it('formats longitude with degree suffix and 4 decimals', () => {
      const posDiscGroup = columns.find(
        (col) => col.headerName === 'Positional discrepancy',
      );
      if (posDiscGroup && isColGroupDef(posDiscGroup)) {
        const lonCol = posDiscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'startedLongitude',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (lonCol && lonCol.cellRenderer) {
          const CellRenderer = lonCol.cellRenderer as (props: {
            value: number;
          }) => JSX.Element;
          const { container } = render(<CellRenderer value={4.4792} />);
          expect(container.textContent).toBe('4.4792°');
        }
      }
    });

    it('formats stopped timestamp with UTC format', () => {
      const posDiscGroup = columns.find(
        (col) => col.headerName === 'Positional discrepancy',
      );
      if (posDiscGroup && isColGroupDef(posDiscGroup)) {
        const stoppedCol = posDiscGroup.children?.find(
          (col) => isColDef(col) && col.field === 'stoppedTimestamp',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (stoppedCol && stoppedCol.cellRenderer) {
          const CellRenderer = stoppedCol.cellRenderer as (props: {
            value: string;
          }) => JSX.Element;
          const { container } = render(
            <CellRenderer value="2024-01-01T09:00:00Z" />,
          );
          expect(container.textContent).toBe('UTC: 2024-01-01T09:00:00Z');
        }
      }
    });
  });

  describe('Tooltip configuration', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('has tooltips for all Overview columns', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        overviewGroup.children?.forEach((col) => {
          if (isColDef(col)) {
            expect('tooltipField' in col || 'tooltipValueGetter' in col).toBe(
              true,
            );
          }
        });
      }
    });

    it('uses tooltipValueGetter for formatted timestamp', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const timestampCol = overviewGroup.children?.[0];
        if (timestampCol && isColDef(timestampCol)) {
          expect('tooltipValueGetter' in timestampCol).toBe(true);
        }
      }
    });

    it('uses tooltipValueGetter for event labels', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        const eventCol = overviewGroup.children?.[1];
        if (
          eventCol &&
          isColDef(eventCol) &&
          'tooltipValueGetter' in eventCol
        ) {
          const getter = eventCol.tooltipValueGetter as (params: {
            value: string;
          }) => string;
          const result = getter({ value: 'PORT_ARRIVAL' } as never);
          expect(result).toBe('Label: PORT_ARRIVAL');
        }
      }
    });

    it('uses tooltipField for simple string fields', () => {
      const vesselGroup = columns.find(
        (col) => col.headerName === 'Vessel identity',
      );
      if (vesselGroup && isColGroupDef(vesselGroup)) {
        const imoCol = vesselGroup.children?.find(
          (col) => isColDef(col) && col.field === 'imo',
        ) as ColDef<FlatVesselEventsResponse> | undefined;
        if (imoCol) {
          expect('tooltipField' in imoCol).toBe(true);
          expect(imoCol.tooltipField).toBe('imo');
        }
      }
    });
  });

  describe('All time-related headers', () => {
    it('all date/time fields show UTC/System in header based on timezone setting', () => {
      const utcColumns = CreateUnifiedVesselEventsColDefs('utc');
      const systemColumns = CreateUnifiedVesselEventsColDefs('system');

      const timeFields = [
        'eventTimestamp',
        'reportedEta',
        'inspectionDate',
        'releaseDate',
        'stsEnded',
        'gapStopped',
        'gapResumed',
        'stoppedTimestamp',
      ];

      timeFields.forEach((field) => {
        // Find the column in UTC config
        let utcCol: ColDef<FlatVesselEventsResponse> | undefined;
        let systemCol: ColDef<FlatVesselEventsResponse> | undefined;

        utcColumns.forEach((group) => {
          if (isColGroupDef(group)) {
            const found = group.children?.find(
              (col) => isColDef(col) && col.field === field,
            ) as ColDef<FlatVesselEventsResponse> | undefined;
            if (found) utcCol = found;
          }
        });

        systemColumns.forEach((group) => {
          if (isColGroupDef(group)) {
            const found = group.children?.find(
              (col) => isColDef(col) && col.field === field,
            ) as ColDef<FlatVesselEventsResponse> | undefined;
            if (found) systemCol = found;
          }
        });

        if (utcCol) {
          expect(utcCol.headerName).toContain('UTC');
        }
        if (systemCol) {
          expect(systemCol.headerName).toContain('System');
        }
      });
    });
  });

  describe('Hidden columns', () => {
    let columns: ReturnType<typeof CreateUnifiedVesselEventsColDefs>;

    beforeEach(() => {
      columns = CreateUnifiedVesselEventsColDefs('utc');
    });

    it('hides all columns except Overview group by default', () => {
      columns.forEach((group, index) => {
        if (isColGroupDef(group) && index > 0) {
          // Skip Overview group (index 0)
          group.children?.forEach((col) => {
            if (isColDef(col)) {
              expect(col.hide).toBe(true);
            }
          });
        }
      });
    });

    it('does not hide Overview columns', () => {
      const overviewGroup = columns[0];
      if (isColGroupDef(overviewGroup)) {
        overviewGroup.children?.forEach((col) => {
          if (isColDef(col)) {
            expect(col.hide).toBeUndefined();
          }
        });
      }
    });
  });
});
