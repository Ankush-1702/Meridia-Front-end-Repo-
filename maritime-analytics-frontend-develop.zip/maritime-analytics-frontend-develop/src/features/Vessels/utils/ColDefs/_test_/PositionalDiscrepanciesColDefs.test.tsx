import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { createVesselPositionalDiscrepanciesColDefs } from '@/features/Vessels/utils/ColDefs/PositionalDiscrepanciesColDefs';

/* ---------------- mocks ---------------- */

const mockConvertHuman = vi.fn();
const mockConvertUTC = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
): string {
  const element = renderer({ value } as CustomCellRendererProps);
  return (element.props.children ?? '') as string;
}

/* ---------------- tests ---------------- */

describe('createVesselPositionalDiscrepanciesColDefs', () => {
  it('creates expected number of columns', () => {
    const cols = createVesselPositionalDiscrepanciesColDefs('utc');
    expect(cols.length).toBe(14);
  });

  it('uses UTC header and formatting for started timestamp', () => {
    mockConvertHuman.mockReturnValue('UTC_STARTED');

    const cols = createVesselPositionalDiscrepanciesColDefs('utc');
    const startedCol = cols[0];

    expect(startedCol.headerName).toContain('(UTC)');

    const value = renderCell(startedCol.cellRenderer!, '2024-01-01');
    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('UTC_STARTED');
  });

  it('uses system header and local formatting for stopped timestamp', () => {
    mockConvertUTC.mockReturnValue('LOCAL_STOPPED');

    const cols = createVesselPositionalDiscrepanciesColDefs('system');
    const stoppedCol = cols[1];

    expect(stoppedCol.headerName).toContain('(System)');

    const value = renderCell(stoppedCol.cellRenderer!, '2024-01-02');
    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-02');
    expect(value).toBe('LOCAL_STOPPED');
  });

  it('marks expected columns as hidden', () => {
    const cols = createVesselPositionalDiscrepanciesColDefs('utc');

    const hiddenFields = [
      'started.latitude',
      'started.longitude',
      'stopped.latitude',
      'stopped.longitude',
      'imo',
      'callsign',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });

  it('exposes vessel name and flag columns', () => {
    const cols = createVesselPositionalDiscrepanciesColDefs('utc');

    const nameCol = cols.find((c) => c.field === 'name');
    const flagCol = cols.find((c) => c.field === 'flag');

    expect(nameCol?.hide).not.toBe(true);
    expect(flagCol?.hide).not.toBe(true);
  });
});
