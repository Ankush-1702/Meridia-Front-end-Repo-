import { ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { flattenedVesselPortAndZone } from '@/features/Vessels/types/vesselTypes';
import { createVesselZoneEventsColDefs } from '@/features/Vessels/utils/ColDefs/ZoneEventsColDefs';

/* ---------------- mocks ---------------- */

const mockConvertHuman = vi.fn();
const mockConvertUTC = vi.fn();
const mockToTitleCase = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
  toTitleCase: (v: string) => mockToTitleCase(v),
}));

vi.mock('@/shared/components/Badge', () => ({
  default: (props: { status: string }) => <span>{props.status}</span>,
}));

vi.mock('@/shared/ui/FlagIcon', () => ({
  default: (props: { flagCode?: string }) => (
    <span>{props.flagCode ?? 'NO_FLAG'}</span>
  ),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
  data?: Record<string, unknown>,
): React.ReactElement {
  return renderer({
    value,
    data,
  } as CustomCellRendererProps);
}

function createTooltipParams(
  value: string,
): ITooltipParams<flattenedVesselPortAndZone> {
  return {
    value,
    location: 'cell',
    api: {} as ITooltipParams<flattenedVesselPortAndZone>['api'],
    context: {},
  };
}

/* ---------------- tests ---------------- */

describe('createVesselZoneEventsColDefs', () => {
  it('contains required core columns', () => {
    const cols = createVesselZoneEventsColDefs('utc');
    const fields = cols.map((c) => c.field);

    expect(fields).toContain('event_details.event_timestamp');
    expect(fields).toContain('event_details.event_type');
    expect(fields).toContain('zone_information.name');
    expect(fields).toContain('zone_information.country_official_name');
  });

  it('uses UTC header and formatting for timestamp when timezone is utc', () => {
    mockConvertHuman.mockReturnValue('UTC_TIME');

    const cols = createVesselZoneEventsColDefs('utc');
    const tsCol = cols[0];

    expect(tsCol.headerName).toContain('(UTC)');

    const element = renderCell(tsCol.cellRenderer!, '2024-01-01');
    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(element.props.children).toBe('UTC_TIME');
  });

  it('uses system header and local formatting for timestamp when timezone is system', () => {
    mockConvertUTC.mockReturnValue('LOCAL_TIME');

    const cols = createVesselZoneEventsColDefs('system');
    const tsCol = cols[0];

    expect(tsCol.headerName).toContain('(System)');

    const element = renderCell(tsCol.cellRenderer!, '2024-01-01');
    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-01');
    expect(element.props.children).toBe('LOCAL_TIME');
  });

  it('formats tooltip value for Event column correctly', () => {
    mockToTitleCase.mockReturnValue('Entry');

    const cols = createVesselZoneEventsColDefs('utc');
    const eventCol = cols[1];

    const tooltip = eventCol.tooltipValueGetter?.(
      createTooltipParams('ZONE_ENTRY'),
    );

    expect(mockToTitleCase).toHaveBeenCalledWith('ENTRY');
    expect(tooltip).toBe('Entry');
  });

  it('renders StatusBadge with correct status', () => {
    const cols = createVesselZoneEventsColDefs('utc');
    const eventCol = cols[1];

    const element = renderCell(eventCol.cellRenderer!, 'ZONE_EXIT');

    expect(element.props.status).toBe('ZONE_EXIT');
  });

  it('passes correct country code to FlagIcon', () => {
    const cols = createVesselZoneEventsColDefs('utc');
    const countryCol = cols[3];

    const element = renderCell(countryCol.cellRenderer!, 'Norway', {
      zone_information: {
        country_code: 'NO',
      },
    });

    const flagIcon = element.props.children[0];
    expect(flagIcon.props.flagCode).toBe('NO');
  });

  it('renders "-" when zone name is missing', () => {
    const cols = createVesselZoneEventsColDefs('utc');
    const zoneNameCol = cols[2];

    const element = renderCell(zoneNameCol.cellRenderer!, undefined);
    expect(element.props.children).toBe('-');
  });

  it('marks expected columns as hidden', () => {
    const cols = createVesselZoneEventsColDefs('utc');

    const hiddenFields = [
      'zone_information.sub_division_code',
      'zone_information.sub_division_name',
      'zone_information.country_common_name',
      'zone_information.centroid.longitude',
      'zone_information.centroid.latitude',
      'event_details.course',
      'event_details.heading',
      'event_details.draught',
      'event_details.latitude',
      'event_details.longitude',
      'event_details.navigational_status',
      'event_details.reported_destination',
      'event_details.reported_eta',
      'event_details.speed',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });
});
