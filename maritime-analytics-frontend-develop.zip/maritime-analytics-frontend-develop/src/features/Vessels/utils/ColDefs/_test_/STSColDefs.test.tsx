import { CustomCellRendererProps } from 'ag-grid-react';
import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { createVesselSTSColDefs } from '@/features/Vessels/utils/ColDefs/STSColDefs';

/* ---------------- mocks ---------------- */

const mockConvertHuman = vi.fn();
const mockConvertUTC = vi.fn();

vi.mock('@/shared/utils/formatUtils', () => ({
  convertDateAndTimeToHumanReadableFormat: (v: unknown) => mockConvertHuman(v),
  convertUTCToLocalTime: (v: unknown) => mockConvertUTC(v),
}));

/* ---------------- helpers ---------------- */

function renderCell(
  renderer: (p: CustomCellRendererProps) => React.ReactElement,
  value: unknown,
): string {
  const element = renderer({ value } as CustomCellRendererProps);
  return (element.props.children ?? '-') as string;
}

/* ---------------- tests ---------------- */

describe('createVesselSTSColDefs', () => {
  it('creates expected number of columns', () => {
    const cols = createVesselSTSColDefs('utc');
    expect(cols.length).toBe(12);
  });

  it('uses UTC header and formatting for started timestamp', () => {
    mockConvertHuman.mockReturnValue('UTC_STARTED');

    const cols = createVesselSTSColDefs('utc');
    const startedCol = cols[0];

    expect(startedCol.headerName).toContain('(UTC)');

    const value = renderCell(startedCol.cellRenderer!, '2024-01-01');
    expect(mockConvertHuman).toHaveBeenCalledWith('2024-01-01');
    expect(value).toBe('UTC_STARTED');
  });

  it('uses system header and local formatting for stopped timestamp', () => {
    mockConvertUTC.mockReturnValue('LOCAL_STOPPED');

    const cols = createVesselSTSColDefs('system');
    const stoppedCol = cols[1];

    expect(stoppedCol.headerName).toContain('(System)');

    const value = renderCell(stoppedCol.cellRenderer!, '2024-01-02');
    expect(mockConvertUTC).toHaveBeenCalledWith('2024-01-02');
    expect(value).toBe('LOCAL_STOPPED');
  });

  it('renders "-" for empty text and numeric fields', () => {
    const cols = createVesselSTSColDefs('utc');

    const durationCol = cols.find((c) => c.field === 'duration_hours')!;
    const value = renderCell(durationCol.cellRenderer!, undefined);

    expect(value).toBe('-');
  });

  it('marks expected columns as hidden', () => {
    const cols = createVesselSTSColDefs('utc');

    const hiddenFields = [
      'location.latitude',
      'location.longitude',
      'paired_vessel.imo',
      'paired_vessel.mmsi',
      'paired_vessel.callsign',
    ];

    hiddenFields.forEach((field) => {
      const col = cols.find((c) => c.field === field);
      expect(col?.hide).toBe(true);
    });
  });

  it('exposes paired vessel name and type columns', () => {
    const cols = createVesselSTSColDefs('utc');

    const nameCol = cols.find((c) => c.field === 'paired_vessel.name');
    const typeCol = cols.find((c) => c.field === 'paired_vessel.vessel_type');

    expect(nameCol?.hide).not.toBe(true);
    expect(typeCol?.hide).not.toBe(true);
  });
});
