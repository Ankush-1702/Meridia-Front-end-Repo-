import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { flattenedVesselPortAndZone } from '@/features/Vessels/types/vesselTypes';
import StatusBadge from '@/shared/components/Badge';
import FlagIcon from '@/shared/ui/FlagIcon';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
  toTitleCase,
} from '@/shared/utils/formatUtils';

export function createVesselZoneEventsColDefs(
  timeZoneSetting: string,
): ColDef<flattenedVesselPortAndZone>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'TimeStamp (UTC)' : 'TimeStamp (System)'}`,
      field: 'event_details.event_timestamp',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Event',
      field: 'event_details.event_type',
      sortable: false,
      flex: 1,
      tooltipValueGetter(params) {
        const newSatus = params.value.split('_').slice(1).join('_');
        return toTitleCase(newSatus);
      },
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <StatusBadge status={params.value} />
      ),
    },
    {
      headerName: 'Zone Name',
      field: 'zone_information.name',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.name',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Country',
      field: 'zone_information.country_official_name',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.country_official_name',

      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <div className="flex items-center gap-2">
          <FlagIcon flagCode={params.data.zone_information?.country_code} />
          <span className="truncate">{params.value ? params.value : '-'}</span>
        </div>
      ),
    },
    {
      headerName: 'Zone Type',
      field: 'zone_information.type',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.type',

      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Sub Type',
      field: 'zone_information.sub_type',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.sub_type',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Sub Division Code',
      field: 'zone_information.sub_division_code',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.sub_division_code',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value || params.value !== '' ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Sub Division name',
      field: 'zone_information.sub_division_name',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.sub_division_name',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value || params.value !== '' ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Country Common Name',
      field: 'zone_information.country_common_name',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.country_common_name',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Centroid (Longitude)',
      field: 'zone_information.centroid.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.centroid.longitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Centroid (Latitude)',
      field: 'zone_information.centroid.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'zone_information.centroid.latitude',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Course',
      field: 'event_details.course',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.course',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Heading',
      field: 'event_details.heading',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.heading',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Draught',
      field: 'event_details.draught',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.draught',
      // lockVisible: true,

      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Latitude',
      field: 'event_details.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.latitude',
      // lockVisible: true,

      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Longitude',
      field: 'event_details.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.longitude',
      // lockVisible: true,

      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Navigational Status (status)',
      field: 'event_details.navigational_status',
      sortable: false,
      flex: 1,
      width: 500,
      tooltipField: 'event_details.navigational_status',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Reported Destination',
      field: 'event_details.reported_destination',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.reported_destination',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Reported ETA (UTC)' : 'Reported ETA (System)'}`,
      field: 'event_details.reported_eta',
      sortable: false,
      flex: 1,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Speed',
      field: 'event_details.speed',
      sortable: false,
      flex: 1,
      tooltipField: 'event_details.speed',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
  ];
}
