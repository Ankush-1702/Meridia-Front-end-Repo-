import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { flattenedVesselSTSEvents } from '@/features/Vessels/types/vesselTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
} from '@/shared/utils/formatUtils';
import { NavigateToDetailsPage } from '@/shared/utils/NavigatetoDetailsPage';

export function createVesselSTSColDefs(
  timeZoneSetting: string,
): ColDef<flattenedVesselSTSEvents>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Started At (UTC)' : 'Started At (System)'}`,
      field: 'started',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Stopped At (UTC)' : 'Stopped At (System)'}`,
      field: 'stopped',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'STS Type',
      field: 'sts_type',
      sortable: false,
      flex: 1,
      tooltipField: 'sts_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Duration',
      field: 'duration_hours',
      sortable: false,
      flex: 1,
      tooltipField: 'duration_hours',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Latitude',
      field: 'location.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'location.latitude',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Longitude',
      field: 'location.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'location.longitude',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Paired Vessel Name',
      field: 'paired_vessel.name',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.name',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => {
        const path = `/analytics/vessel/${params.data.paired_vessel.imo}`;
        return <NavigateToDetailsPage params={params} detailsRoute={path} />;
      },
    },
    {
      headerName: 'Paired Vessel Imo',
      field: 'paired_vessel.imo',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.imo',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Paired Vessel Type',
      field: 'paired_vessel.vessel_type',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.vessel_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Paired Vessel mmsi',
      field: 'paired_vessel.mmsi',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.mmsi',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Paired Vessel Callsign',
      field: 'paired_vessel.callsign',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.callsign',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
    {
      headerName: 'Paired Vessel Flag',
      field: 'paired_vessel.flag',
      sortable: false,
      flex: 1,
      tooltipField: 'paired_vessel.flag',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
      cellStyle: {
        cursor: 'default',
      },
    },
  ];
}
