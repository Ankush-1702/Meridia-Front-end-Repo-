import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { flattenedVesselPortStateControl } from '@/features/Vessels/types/vesselTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
} from '@/shared/utils/formatUtils';

export function createVesselPortStateControlColDefs(
  timeZoneSetting: string,
): ColDef<flattenedVesselPortStateControl>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Inspection Date (UTC)' : 'Inspection Date (System)'}`,
      field: 'inspection_date',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Port',
      field: 'port_information.name',
      sortable: false,
      flex: 1,
      tooltipField: 'port_information.name',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Country',
      field: 'port_information.country_common_name',
      sortable: false,
      flex: 1,
      tooltipField: 'port_information.country_common_name',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Authority',
      field: 'authority',
      sortable: false,
      flex: 1,
      tooltipField: 'authority',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Inspection Type',
      field: 'inspection_type',
      sortable: false,
      flex: 1,
      tooltipField: 'inspection_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Expanded Inspection',
      field: 'expanded_inspection',
      sortable: false,
      flex: 1,
      tooltipField: 'expanded_inspection',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Follow up Inspection',
      field: 'follow_up_inspection',
      sortable: false,
      flex: 1,
      tooltipField: 'follow_up_inspection',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Detained',
      field: 'detained',
      sortable: false,
      flex: 1,
      tooltipField: 'detained',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'No of Days Detained',
      field: 'no_days_detained',
      sortable: false,
      flex: 1,
      tooltipField: 'no_days_detained',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'No of Defects',
      field: 'no_defects',
      sortable: false,
      flex: 1,
      tooltipField: 'no_defects',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Released Date',
      field: 'release_date',
      sortable: false,
      flex: 1,
      tooltipField: 'release_date',
      lockVisible: false,
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
  ];
}
