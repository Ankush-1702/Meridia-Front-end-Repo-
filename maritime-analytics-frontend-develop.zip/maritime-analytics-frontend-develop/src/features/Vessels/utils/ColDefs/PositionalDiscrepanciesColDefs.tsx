import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { flattenedVesselPositionalDiscrepancies } from '@/features/Vessels/types/vesselTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
} from '@/shared/utils/formatUtils';

export function createVesselPositionalDiscrepanciesColDefs(
  timeZoneSetting: string,
): ColDef<flattenedVesselPositionalDiscrepancies>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Started At (UTC)' : 'Started At (System)'}`,
      field: 'started.timestamp',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Stopped At (UTC)' : 'Stopped At (System)'}`,
      field: 'stopped.timestamp',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Has Ended',
      field: 'has_ended',
      sortable: false,
      flex: 1,
      tooltipField: 'has_ended',
      lockVisible: true,
    },
    {
      headerName: 'Duration (Hours)',
      field: 'duration_hours',
      sortable: false,
      flex: 1,
      tooltipField: 'duration_hours',
      lockVisible: true,
    },
    {
      headerName: 'Event Type',
      field: 'event_type',
      sortable: false,
      flex: 1,
      tooltipField: 'event_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
    },
    {
      headerName: 'Started Latitude',
      field: 'started.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'started.latitude',
      lockVisible: false,
      hide: true,
    },
    {
      headerName: 'Started Longitude',
      field: 'started.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'started.longitude',
      lockVisible: false,
      hide: true,
    },
    {
      headerName: 'Stopped Latitude',
      field: 'stopped.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.latitude',
      lockVisible: false,
      hide: true,
    },
    {
      headerName: 'Stopped Longitude',
      field: 'stopped.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.longitude',
      lockVisible: false,
      hide: true,
    },
    {
      headerName: 'Vessel Name',
      field: 'name',
      sortable: false,
      flex: 1,
      tooltipField: 'name',
      lockVisible: true,
    },
    {
      headerName: 'Vessel Imo',
      field: 'imo',
      sortable: false,
      flex: 1,
      tooltipField: 'imo',
      lockVisible: false,
      hide: true,
    },
    {
      headerName: 'Vessel CallSign',
      field: 'callsign',
      sortable: false,
      flex: 1,
      tooltipField: 'callsign',
      lockVisible: false,
      suppressHeaderFilterButton: true,
      hide: true,
    },
    {
      headerName: 'Vessel Flag',
      field: 'flag',
      sortable: false,
      flex: 1,
      tooltipField: 'flag',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
    },
    {
      headerName: 'Vessel Type',
      field: 'vessel_type',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_type',
      lockVisible: true,
      // filter: 'agTextColumnFilter',
      // filterParams: textFilterParams,
    },
  ];
}
