import { ColDef, ITooltipParams } from 'ag-grid-enterprise';
import { CustomCellRendererProps } from 'ag-grid-react';
import { flattenedVesselAISGaps } from '@/features/Vessels/types/vesselTypes';
import {
  convertDateAndTimeToHumanReadableFormat,
  convertUTCToLocalTime,
} from '@/shared/utils/formatUtils';

export function createVesselAISGapsColDefs(
  timeZoneSetting: string,
): ColDef<flattenedVesselAISGaps>[] {
  return [
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Stopped Reporting At (UTC)' : 'Stopped Reporting At (System)'}`,
      field: 'stopped.timestamp',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: `${timeZoneSetting === 'utc' ? 'Resumed Reporting At (UTC)' : 'Resumed Reporting At (System)'}`,
      field: 'resumed.timestamp',
      sortable: false,
      flex: 1,
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>
          {timeZoneSetting === 'utc'
            ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
            : convertUTCToLocalTime(params.value) || '-'}
        </span>
      ),
      tooltipValueGetter: (params: ITooltipParams) =>
        timeZoneSetting === 'utc'
          ? convertDateAndTimeToHumanReadableFormat(params.value) || '-'
          : convertUTCToLocalTime(params.value) || '-',
    },
    {
      headerName: 'Gap Duration (hours)',
      field: 'gap_duration_hours',
      sortable: false,
      flex: 1,
      tooltipField: 'gap_duration_hours',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Draught Change (meters)',
      field: 'draught_change',
      sortable: false,
      flex: 1,
      tooltipField: 'draught_change',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Draught',
      field: 'stopped.draught',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.draught',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Speed',
      field: 'stopped.speed',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.speed',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Course',
      field: 'stopped.course',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.course',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Latitude',
      field: 'stopped.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.latitude',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Longitude',
      field: 'stopped.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.longitude',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Nav Status (Status)',
      field: 'stopped.navigational_status.status',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.navigational_status.status',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Stopped Nav Status (Code)',
      field: 'stopped.navigational_status.code',
      sortable: false,
      flex: 1,
      tooltipField: 'stopped.navigational_status.code',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Draught',
      field: 'resumed.draught',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.draught',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Speed',
      field: 'resumed.speed',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.speed',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Course',
      field: 'resumed.course',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.course',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Latitude',
      field: 'resumed.latitude',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.latitude',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Longitude',
      field: 'resumed.longitude',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.longitude',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Nav Status (Status)',
      field: 'resumed.navigational_status.status',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.navigational_status.status',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Resumed Nav Status (Code)',
      field: 'resumed.navigational_status.code',
      sortable: false,
      flex: 1,
      tooltipField: 'resumed.navigational_status.code',
      lockVisible: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Vessel Name',
      field: 'name',
      sortable: false,
      flex: 1,
      tooltipField: 'name',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'IMO',
      field: 'imo',
      sortable: false,
      flex: 1,
      tooltipField: 'imo',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'MMSI',
      field: 'mmsi',
      sortable: false,
      flex: 1,
      tooltipField: 'mmsi',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Call Sign',
      field: 'callsign',
      sortable: false,
      flex: 1,
      tooltipField: 'callsign',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Flag',
      field: 'flag',
      sortable: false,
      flex: 1,
      tooltipField: 'flag',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
    {
      headerName: 'Vessel Type',
      field: 'vessel_type',
      sortable: false,
      flex: 1,
      tooltipField: 'vessel_type',
      hide: true,
      cellRenderer: (params: CustomCellRendererProps) => (
        <span>{params.value ? params.value : '-'}</span>
      ),
    },
  ];
}
