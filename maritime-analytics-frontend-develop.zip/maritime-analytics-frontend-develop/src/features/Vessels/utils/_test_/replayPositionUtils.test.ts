import { describe, it, expect } from 'vitest';
import type { VesselPosition } from '@/features/Vessels/services/vesselTrackService';
import {
  buildPositionArrays,
  interpolatePosition,
  findTrackSplitIndex,
  getSpeedColor,
  getNavStatusColor,
  getTrackColor,
  buildTrackGeoJSON,
} from '@/features/Vessels/utils/replayPositionUtils';

/* ─── fixtures ─────────────────────────────────────────────────────────────── */

function makePos(
  timestamp: string,
  latitude: number,
  longitude: number,
  overrides: Partial<VesselPosition> = {},
): VesselPosition {
  return {
    mmsi: 123456789,
    timestamp,
    latitude,
    longitude,
    speed: null,
    course: null,
    heading: null,
    status: null,
    ...overrides,
  };
}

const T0 = '2024-01-01T00:00:00Z';
const T1 = '2024-01-01T01:00:00Z';
const T2 = '2024-01-01T02:00:00Z';

const TWO_POSITIONS: VesselPosition[] = [makePos(T0, 0, 0), makePos(T1, 1, 1)];

const THREE_POSITIONS: VesselPosition[] = [
  makePos(T0, 0, 0),
  makePos(T1, 1, 1),
  makePos(T2, 2, 2),
];

/* ─── buildPositionArrays ───────────────────────────────────────────────────── */

describe('buildPositionArrays', () => {
  it('converts positions into parallel arrays', () => {
    const result = buildPositionArrays(TWO_POSITIONS);
    expect(result.timestampMs).toHaveLength(2);
    expect(result.latitudes).toEqual([0, 1]);
    expect(result.longitudes).toEqual([0, 1]);
    expect(result.cogs).toHaveLength(2);
  });

  it('cog for last position mirrors previous segment bearing', () => {
    const result = buildPositionArrays(TWO_POSITIONS);
    // Both positions point the same direction (NE diagonal), so cogs[0] === cogs[1]
    expect(result.cogs[0]).toBeCloseTo(result.cogs[1], 1);
  });

  it('handles single position without throwing', () => {
    const result = buildPositionArrays([makePos(T0, 10, 20)]);
    expect(result.latitudes).toEqual([10]);
    expect(result.cogs).toHaveLength(1);
    expect(result.cogs[0]).toBe(0);
  });
});

/* ─── interpolatePosition ───────────────────────────────────────────────────── */

describe('interpolatePosition', () => {
  it('returns null for empty arrays', () => {
    expect(
      interpolatePosition(
        { timestampMs: [], latitudes: [], longitudes: [], cogs: [] },
        Date.now(),
      ),
    ).toBeNull();
  });

  it('returns null when target is before first timestamp', () => {
    const arrays = buildPositionArrays(TWO_POSITIONS);
    const beforeStart = new Date(T0).getTime() - 1000;
    expect(interpolatePosition(arrays, beforeStart)).toBeNull();
  });

  it('returns exact start position at T0', () => {
    const arrays = buildPositionArrays(TWO_POSITIONS);
    const result = interpolatePosition(arrays, new Date(T0).getTime());
    expect(result?.latitude).toBeCloseTo(0, 5);
    expect(result?.longitude).toBeCloseTo(0, 5);
  });

  it('interpolates midpoint correctly', () => {
    const arrays = buildPositionArrays(TWO_POSITIONS);
    const mid = (new Date(T0).getTime() + new Date(T1).getTime()) / 2;
    const result = interpolatePosition(arrays, mid);
    expect(result?.latitude).toBeCloseTo(0.5, 4);
    expect(result?.longitude).toBeCloseTo(0.5, 4);
  });

  it('returns end position when target is at or past last timestamp', () => {
    const arrays = buildPositionArrays(TWO_POSITIONS);
    const result = interpolatePosition(arrays, new Date(T1).getTime() + 9999);
    expect(result?.latitude).toBeCloseTo(1, 5);
    expect(result?.longitude).toBeCloseTo(1, 5);
  });

  it('handles three positions and interpolates second segment', () => {
    const arrays = buildPositionArrays(THREE_POSITIONS);
    const midT1T2 = (new Date(T1).getTime() + new Date(T2).getTime()) / 2;
    const result = interpolatePosition(arrays, midT1T2);
    expect(result?.latitude).toBeCloseTo(1.5, 4);
    expect(result?.longitude).toBeCloseTo(1.5, 4);
  });

  it('returns idx position without NaN when consecutive timestamps are equal', () => {
    const dupTs = '2024-01-01T01:00:00Z';
    const positions = [
      makePos(T0, 0, 0),
      makePos(dupTs, 1, 1),
      makePos(dupTs, 2, 2), // same timestamp as previous
    ];
    const arrays = buildPositionArrays(positions);
    const result = interpolatePosition(arrays, new Date(dupTs).getTime());
    expect(result).not.toBeNull();
    expect(Number.isNaN(result?.latitude)).toBe(false);
    expect(Number.isNaN(result?.longitude)).toBe(false);
  });
});

/* ─── findTrackSplitIndex ───────────────────────────────────────────────────── */

describe('findTrackSplitIndex', () => {
  it('returns -1 when target is before all timestamps', () => {
    const arrays = buildPositionArrays(THREE_POSITIONS);
    expect(
      findTrackSplitIndex(arrays.timestampMs, new Date(T0).getTime() - 1),
    ).toBe(-1);
  });

  it('returns last index when target is after all timestamps', () => {
    const arrays = buildPositionArrays(THREE_POSITIONS);
    expect(
      findTrackSplitIndex(arrays.timestampMs, new Date(T2).getTime() + 1000),
    ).toBe(2);
  });

  it('returns correct floor index for mid-range target', () => {
    const arrays = buildPositionArrays(THREE_POSITIONS);
    const mid = new Date(T1).getTime() + 1;
    expect(findTrackSplitIndex(arrays.timestampMs, mid)).toBe(1);
  });

  it('returns exact index when target equals a timestamp', () => {
    const arrays = buildPositionArrays(THREE_POSITIONS);
    expect(
      findTrackSplitIndex(arrays.timestampMs, new Date(T1).getTime()),
    ).toBe(1);
  });
});

/* ─── getSpeedColor ─────────────────────────────────────────────────────────── */

describe('getSpeedColor', () => {
  it('returns stopped color for null speed', () => {
    expect(getSpeedColor(null)).toBe('#FAAF89');
  });

  it('returns stopped color for 0 knots', () => {
    expect(getSpeedColor(0)).toBe('#FAAF89');
  });

  it('returns slow color for 0.1 knots', () => {
    expect(getSpeedColor(0.1)).toBe('#F5C842');
  });

  it('returns medium color for 5 knots', () => {
    expect(getSpeedColor(5)).toBe('#2B969C');
  });

  it('returns fast color for 15 knots', () => {
    expect(getSpeedColor(15)).toBe('#1E6FA5');
  });

  it('returns fast color for 20 knots', () => {
    expect(getSpeedColor(20)).toBe('#1E6FA5');
  });
});

/* ─── getNavStatusColor ──────────────────────────────────────────────────────── */

describe('getNavStatusColor', () => {
  it('returns default color for null status', () => {
    expect(getNavStatusColor(null)).toBe('#2B969C');
  });

  it('returns moored color for moored status', () => {
    expect(getNavStatusColor('Moored')).toBe('#FAAF89');
  });

  it('returns moored color for at anchor status', () => {
    expect(getNavStatusColor('At Anchor')).toBe('#FAAF89');
  });

  it('returns underway color for underway status', () => {
    expect(getNavStatusColor('Under Way Using Engine')).toBe('#2B969C');
  });

  it('returns other color for unknown status', () => {
    expect(getNavStatusColor('Not Under Command')).toBe('#81E4E3');
  });
});

/* ─── getTrackColor ──────────────────────────────────────────────────────────── */

describe('getTrackColor', () => {
  it('delegates to getSpeedColor in speed mode', () => {
    expect(getTrackColor(20, null, 'speed')).toBe('#1E6FA5');
  });

  it('delegates to getNavStatusColor in nav_status mode', () => {
    expect(getTrackColor(null, 'Moored', 'nav_status')).toBe('#FAAF89');
  });

  it('defaults to speed color when mode is speed', () => {
    expect(getTrackColor(null, null, 'speed')).toBe('#FAAF89');
  });
});

/* ─── buildTrackGeoJSON ──────────────────────────────────────────────────────── */

describe('buildTrackGeoJSON', () => {
  it('returns empty FeatureCollection for fewer than 2 positions in slice', () => {
    const result = buildTrackGeoJSON(TWO_POSITIONS, 0, 0);
    expect(result.features).toHaveLength(0);
  });

  it('returns at least one feature for a valid 2-position slice', () => {
    const positions = [
      makePos(T0, 0, 0, { speed: 1, status: 'Under Way' }),
      makePos(T1, 1, 1, { speed: 1, status: 'Under Way' }),
    ];
    const result = buildTrackGeoJSON(positions, 0, 1);
    expect(result.type).toBe('FeatureCollection');
    expect(result.features.length).toBeGreaterThan(0);
    expect(result.features[0].geometry.type).toBe('LineString');
  });

  it('splits into multiple features when speed color changes', () => {
    const positions = [
      makePos(T0, 0, 0, { speed: 0, status: null }), // stopped → #FAAF89
      makePos(T1, 1, 1, { speed: 0, status: null }), // stopped
      makePos(T2, 2, 2, { speed: 20, status: null }), // fast → #1E6FA5
    ];
    const result = buildTrackGeoJSON(positions, 0, 2, 'speed');
    expect(result.features.length).toBeGreaterThanOrEqual(2);
    const colors = result.features.map((f) => f.properties.color);
    expect(colors).toContain('#FAAF89');
    expect(colors).toContain('#1E6FA5');
  });

  it('clamps slice indices to valid range', () => {
    const result = buildTrackGeoJSON(THREE_POSITIONS, -10, 999);
    expect(result.features.length).toBeGreaterThan(0);
  });
});
