import { describe, it, expect } from 'vitest';
import {
  mercatorInterpolate,
  MAX_MERCATOR_LAT,
} from '@/features/Vessels/utils/mercatorInterpolate';

// Precision helpers
const DEGREE_PRECISION = 6; // ~0.11 m at the equator — tighter than AIS accuracy
const roundTo = (val: number, decimals: number) =>
  Math.round(val * 10 ** decimals) / 10 ** decimals;

describe('mercatorInterpolate', () => {
  // ── Boundary values of t ──────────────────────────────────────────────────

  describe('t = 0 returns the start point exactly', () => {
    it('equatorial segment', () => {
      const [lng, lat] = mercatorInterpolate(10, 20, 30, 40, 0);
      expect(lng).toBeCloseTo(10, DEGREE_PRECISION);
      expect(lat).toBeCloseTo(20, DEGREE_PRECISION);
    });

    it('negative coordinates', () => {
      const [lng, lat] = mercatorInterpolate(-80, -30, -40, -10, 0);
      expect(lng).toBeCloseTo(-80, DEGREE_PRECISION);
      expect(lat).toBeCloseTo(-30, DEGREE_PRECISION);
    });
  });

  describe('t = 1 returns the end point exactly', () => {
    it('equatorial segment', () => {
      const [lng, lat] = mercatorInterpolate(10, 20, 30, 40, 1);
      expect(lng).toBeCloseTo(30, DEGREE_PRECISION);
      expect(lat).toBeCloseTo(40, DEGREE_PRECISION);
    });

    it('negative coordinates', () => {
      const [lng, lat] = mercatorInterpolate(-80, -30, -40, -10, 1);
      expect(lng).toBeCloseTo(-40, DEGREE_PRECISION);
      expect(lat).toBeCloseTo(-10, DEGREE_PRECISION);
    });
  });

  // ── Midpoint symmetry ─────────────────────────────────────────────────────

  it('t = 0.5 longitude is the arithmetic midpoint (linear in Mercator)', () => {
    const [lng] = mercatorInterpolate(-20, 10, 20, 50, 0.5);
    expect(lng).toBeCloseTo(0, DEGREE_PRECISION);
  });

  it('t = 0.5 latitude is pulled toward the pole vs arithmetic midpoint for long segments', () => {
    // Arithmetic midpoint of lat 0 → 60 is 30°.
    // Mercator midpoint is GREATER than 30° because Mercator stretches high
    // latitudes — the same Mercator y-distance covers less geographic latitude
    // near the poles, so the midpoint in Mercator y-space maps back to a
    // geographic latitude above the arithmetic midpoint.
    //
    // Verification:
    //   toMercY(0)  = ln(tan(45°))        = 0
    //   toMercY(60) = ln(tan(75°))        ≈ 1.3169
    //   midY        = 0.6585
    //   fromMercY(0.6585)                 ≈ 35.26°  >  30°
    const [, lat] = mercatorInterpolate(0, 0, 0, 60, 0.5);
    const arithmeticMid = 30;

    // Mercator midpoint must be strictly GREATER than arithmetic midpoint.
    expect(lat).toBeGreaterThan(arithmeticMid);

    // But still in the same ballpark (within 10° for a 60° span).
    expect(lat).toBeLessThan(arithmeticMid + 10);
  });

  it('produces identical result for symmetric t values around 0.5', () => {
    // Interpolating A→B at t and B→A at (1−t) should give the same point.
    const [lng1, lat1] = mercatorInterpolate(10, 20, 50, 60, 0.3);
    const [lng2, lat2] = mercatorInterpolate(50, 60, 10, 20, 0.7);
    expect(lng1).toBeCloseTo(lng2, DEGREE_PRECISION);
    expect(lat1).toBeCloseTo(lat2, DEGREE_PRECISION);
  });

  // ── Zero-length segment ───────────────────────────────────────────────────

  it('returns the same point when start === end', () => {
    const [lng, lat] = mercatorInterpolate(15, 45, 15, 45, 0.5);
    expect(lng).toBeCloseTo(15, DEGREE_PRECISION);
    expect(lat).toBeCloseTo(45, DEGREE_PRECISION);
  });

  // ── High-latitude clamping ────────────────────────────────────────────────

  it('does not return NaN or Infinity when lat is exactly ±90°', () => {
    const [lng1, lat1] = mercatorInterpolate(0, 90, 0, 0, 0.5);
    const [lng2, lat2] = mercatorInterpolate(0, -90, 0, 0, 0.5);
    expect(isFinite(lng1)).toBe(true);
    expect(isFinite(lat1)).toBe(true);
    expect(isFinite(lng2)).toBe(true);
    expect(isFinite(lat2)).toBe(true);
    expect(isNaN(lat1)).toBe(false);
    expect(isNaN(lat2)).toBe(false);
  });

  it('clamps lat > MAX_MERCATOR_LAT to MAX_MERCATOR_LAT before projection', () => {
    // A point at 91° should behave identically to MAX_MERCATOR_LAT.
    const [, latClamped] = mercatorInterpolate(0, 91, 0, 0, 0);
    const [, latBoundary] = mercatorInterpolate(0, MAX_MERCATOR_LAT, 0, 0, 0);
    expect(roundTo(latClamped, 4)).toBe(roundTo(latBoundary, 4));
  });

  it('clamps lat < -MAX_MERCATOR_LAT to -MAX_MERCATOR_LAT before projection', () => {
    const [, latClamped] = mercatorInterpolate(0, -91, 0, 0, 0);
    const [, latBoundary] = mercatorInterpolate(0, -MAX_MERCATOR_LAT, 0, 0, 0);
    expect(roundTo(latClamped, 4)).toBe(roundTo(latBoundary, 4));
  });

  // ── Dateline / antimeridian crossing ─────────────────────────────────────

  it('interpolates longitude linearly across the antimeridian (no wrap correction)', () => {
    // Raw arithmetic: 170 + 0.5 * (190 - 170) = 180. Longitude is NOT
    // wrapped here — callers are responsible for normalising coordinates to
    // the same side of the antimeridian before passing them in, just as
    // Mapbox itself requires.
    const [lng] = mercatorInterpolate(170, 0, 190, 0, 0.5);
    expect(lng).toBeCloseTo(180, DEGREE_PRECISION);
  });

  it('handles negative-to-positive longitude crossing without wrapping', () => {
    const [lng] = mercatorInterpolate(-10, 0, 10, 0, 0.5);
    expect(lng).toBeCloseTo(0, DEGREE_PRECISION);
  });

  // ── Output is always finite for valid AIS coordinates ─────────────────────

  it.each([
    // [label, lng1, lat1, lng2, lat2, t]
    ['equatorial', 0, 0, 0, 0, 0.5],
    ['north atlantic', -30, 50, 10, 60, 0.3],
    ['south pacific', -170, -40, 170, -20, 0.7],
    ['high north', 20, 80, 30, 82, 0.5],
    ['high south', 20, -80, 30, -82, 0.5],
    ['prime meridian', 0, -85, 0, 85, 0.5],
  ] as const)(
    'returns finite coordinates for %s segment',
    (_label, lng1, lat1, lng2, lat2, t) => {
      const [lng, lat] = mercatorInterpolate(lng1, lat1, lng2, lat2, t);
      expect(isFinite(lng)).toBe(true);
      expect(isFinite(lat)).toBe(true);
      expect(isNaN(lng)).toBe(false);
      expect(isNaN(lat)).toBe(false);
    },
  );

  // ── t out of [0,1] extrapolates (callers must clamp) ─────────────────────

  it('extrapolates beyond the segment when t < 0', () => {
    const [lng] = mercatorInterpolate(10, 0, 20, 0, -1);
    // lng = 10 + (-1) * (20 - 10) = 0
    expect(lng).toBeCloseTo(0, DEGREE_PRECISION);
  });

  it('extrapolates beyond the segment when t > 1', () => {
    const [lng] = mercatorInterpolate(10, 0, 20, 0, 2);
    // lng = 10 + 2 * (20 - 10) = 30
    expect(lng).toBeCloseTo(30, DEGREE_PRECISION);
  });
});
