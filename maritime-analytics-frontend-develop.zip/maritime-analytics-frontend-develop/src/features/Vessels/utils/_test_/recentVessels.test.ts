import { describe, it, expect, beforeEach } from 'vitest';
import type { VesselSearch } from '@/features/library/types/LibraryTypes';
import {
  addRecentVessel,
  getRecentVessels,
} from '@/features/Vessels/utils/recentVessels';

/* ─── helpers ───────────────────────────────────────────────────────────────── */

const STORAGE_KEY = 'meridia_recent_vessels';
const MAX_RECENT = 6;

function makeVessel(imo: string, name = `Vessel ${imo}`): VesselSearch {
  return {
    asset_id: `asset_${imo}`,
    callsign: `CS${imo}`,
    flag: 'Panama',
    flag_code: 'PA',
    imo,
    mmsi: null,
    name,
    vessel_type: 'Tanker',
    vessel_status: 'Active',
  };
}

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  localStorage.clear();
});

describe('getRecentVessels', () => {
  it('returns an empty array when nothing is stored', () => {
    expect(getRecentVessels()).toEqual([]);
  });

  it('returns a parsed array of vessels from localStorage', () => {
    const vessels = [makeVessel('IMO1111111'), makeVessel('IMO2222222')];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(vessels));

    expect(getRecentVessels()).toEqual(vessels);
  });

  it('returns an empty array when the stored value is invalid JSON', () => {
    localStorage.setItem(STORAGE_KEY, 'not-valid-json{{{');
    expect(getRecentVessels()).toEqual([]);
  });
});

describe('addRecentVessel', () => {
  it('adds a vessel to an empty list', () => {
    const vessel = makeVessel('IMO1111111');
    addRecentVessel(vessel);

    expect(getRecentVessels()).toEqual([vessel]);
  });

  it('prepends the new vessel so it appears first', () => {
    const v1 = makeVessel('IMO1111111');
    const v2 = makeVessel('IMO2222222');
    addRecentVessel(v1);
    addRecentVessel(v2);

    const result = getRecentVessels();
    expect(result[0].imo).toBe('IMO2222222');
    expect(result[1].imo).toBe('IMO1111111');
  });

  it('deduplicates: re-adding an existing vessel moves it to the front', () => {
    const v1 = makeVessel('IMO1111111');
    const v2 = makeVessel('IMO2222222');
    addRecentVessel(v1);
    addRecentVessel(v2);
    addRecentVessel(v1);

    const result = getRecentVessels();
    expect(result).toHaveLength(2);
    expect(result[0].imo).toBe('IMO1111111');
    expect(result[1].imo).toBe('IMO2222222');
  });

  it('deduplication is based on imo, not object identity', () => {
    addRecentVessel(makeVessel('IMO1111111', 'Old Name'));
    addRecentVessel(makeVessel('IMO1111111', 'New Name'));

    const result = getRecentVessels();
    expect(result).toHaveLength(1);
    expect(result[0].name).toBe('New Name');
  });

  it(`caps the list at ${MAX_RECENT} entries`, () => {
    for (let i = 1; i <= MAX_RECENT + 4; i++) {
      addRecentVessel(makeVessel(`IMO000000${i}`));
    }
    expect(getRecentVessels()).toHaveLength(MAX_RECENT);
  });

  it('keeps the most recently added vessels when capping', () => {
    for (let i = 1; i <= MAX_RECENT + 2; i++) {
      addRecentVessel(makeVessel(`IMO000000${i}`));
    }
    const result = getRecentVessels();
    // The last two added should be at the front
    expect(result[0].imo).toBe(`IMO0000008`);
    expect(result[1].imo).toBe(`IMO0000007`);
    // The first vessel added should have been evicted
    expect(result.map((v) => v.imo)).not.toContain('IMO0000001');
  });

  it('persists across multiple calls via localStorage', () => {
    addRecentVessel(makeVessel('IMO1111111'));
    addRecentVessel(makeVessel('IMO2222222'));

    // Simulate a fresh read
    const result = getRecentVessels();
    expect(result).toHaveLength(2);
    expect(result[0].imo).toBe('IMO2222222');
  });
});
