import { describe, it, expect, vi } from 'vitest';
import {
  flattenedVesselPortAndZone,
  flattenedVesselPositionalDiscrepancies,
  flattenedVesselSTSEvents,
  flattenedVesselAISGaps,
  flattenedVesselPortStateControl,
} from '@/features/Vessels/types/vesselTypes';
import {
  buildParams,
  handleResponse,
  flattenPortOrZoneEvent,
  flattenPositionalDiscrepancy,
  flattenSTSEvent,
  flattenAISGap,
  flattenPortStateControl,
  flattenPortCalls,
  flattenZoneEvents,
  flattenPositionalDiscrepancies,
  flattenSTSEvents,
  flattenAISGaps,
  flattenPortStateControls,
  TAB_EVENT_TYPES,
  EVENT_TYPE_MAP,
} from '@/features/Vessels/utils/vesselUtils';

describe('buildParams', () => {
  it('should build params with default values when no arguments provided', () => {
    const params = buildParams();

    expect(params.get('limit')).toBe('500');
    expect(params.get('offset')).toBe('0');
    expect(params.get('timestamp_start')).toBeNull();
    expect(params.get('timestamp_end')).toBeNull();
  });

  it('should use provided limit and offset', () => {
    const params = buildParams(100, 50);

    expect(params.get('limit')).toBe('100');
    expect(params.get('offset')).toBe('50');
  });

  it('should append timestamp_start when provided', () => {
    const params = buildParams(undefined, undefined, '2024-01-01T00:00:00Z');

    expect(params.get('timestamp_start')).toBe('2024-01-01T00:00:00Z');
  });

  it('should append timestamp_end when provided', () => {
    const params = buildParams(
      undefined,
      undefined,
      undefined,
      '2024-12-31T23:59:59Z',
    );

    expect(params.get('timestamp_end')).toBe('2024-12-31T23:59:59Z');
  });

  it('should append both timestamps when provided', () => {
    const params = buildParams(
      200,
      100,
      '2024-01-01T00:00:00Z',
      '2024-12-31T23:59:59Z',
    );

    expect(params.get('limit')).toBe('200');
    expect(params.get('offset')).toBe('100');
    expect(params.get('timestamp_start')).toBe('2024-01-01T00:00:00Z');
    expect(params.get('timestamp_end')).toBe('2024-12-31T23:59:59Z');
  });

  it('should handle zero values correctly', () => {
    const params = buildParams(0, 0);

    expect(params.get('limit')).toBe('0');
    expect(params.get('offset')).toBe('0');
  });
});

describe('handleResponse', () => {
  it('should return json when response is ok', async () => {
    const mockData = { data: 'test' };
    const mockResponse = {
      ok: true,
      json: vi.fn().mockResolvedValue(mockData),
    } as unknown as Response;

    const result = await handleResponse(mockResponse);

    expect(result).toEqual(mockData);
    expect(mockResponse.json).toHaveBeenCalledTimes(1);
  });

  it('should throw error with message from json error body', async () => {
    const errorBody = { message: 'Custom error message' };
    const mockResponse = {
      ok: false,
      status: 400,
      statusText: 'Bad Request',
      json: vi.fn().mockResolvedValue(errorBody),
    } as unknown as Response;

    await expect(handleResponse(mockResponse)).rejects.toThrow(
      'Custom error message',
    );
  });

  it('should throw error with error field from json body', async () => {
    const errorBody = { error: 'Error field message' };
    const mockResponse = {
      ok: false,
      status: 500,
      statusText: 'Internal Server Error',
      json: vi.fn().mockResolvedValue(errorBody),
    } as unknown as Response;

    await expect(handleResponse(mockResponse)).rejects.toThrow(
      'Error field message',
    );
  });

  it('should throw error with detail field from json body', async () => {
    const errorBody = { detail: 'Detail field message' };
    const mockResponse = {
      ok: false,
      status: 404,
      statusText: 'Not Found',
      json: vi.fn().mockResolvedValue(errorBody),
    } as unknown as Response;

    await expect(handleResponse(mockResponse)).rejects.toThrow(
      'Detail field message',
    );
  });

  it('should fall back to statusText when no error fields present', async () => {
    const errorBody = { someField: 'value' };
    const mockResponse = {
      ok: false,
      status: 403,
      statusText: 'Forbidden',
      json: vi.fn().mockResolvedValue(errorBody),
    } as unknown as Response;

    await expect(handleResponse(mockResponse)).rejects.toThrow('Forbidden');
  });

  it('should handle json parse failure and use text body', async () => {
    const mockResponse = {
      ok: false,
      status: 500,
      statusText: 'Internal Server Error',
      json: vi.fn().mockRejectedValue(new Error('Parse error')),
      text: vi.fn().mockResolvedValue('Plain text error'),
    } as unknown as Response;

    await expect(handleResponse(mockResponse)).rejects.toThrow(
      'Plain text error',
    );
  });

  it('should attach status and body to error object', async () => {
    const errorBody = { message: 'Test error' };
    const mockResponse = {
      ok: false,
      status: 422,
      statusText: 'Unprocessable Entity',
      json: vi.fn().mockResolvedValue(errorBody),
    } as unknown as Response;

    try {
      await handleResponse(mockResponse);
      expect.fail('Should have thrown an error');
    } catch (error) {
      const err = error as Error & { status: number; body: unknown };
      expect(err.status).toBe(422);
      expect(err.body).toEqual(errorBody);
    }
  });
});

describe('flattenPortOrZoneEvent', () => {
  const mockEvent: flattenedVesselPortAndZone = {
    event_details: {
      event_timestamp: '2024-01-15T10:00:00Z',
      event_type: 'PORT_ARRIVAL',
      speed: 12.5,
      course: 180,
      heading: 175,
      draught: 8.5,
      navigational_status: 'At Anchor',
      reported_destination: 'SINGAPORE',
      reported_eta: '2024-01-16T08:00:00Z',
    },
    zone_information: {
      name: 'Singapore Port',
      country_common_name: 'Singapore',
      country_code: 'SG',
      unlocode: 'SGSIN',
      type: 'PORT',
      id: 'zone123',
    },
    name: 'Test Vessel',
    imo: '1234567',
    mmsi: '123456789',
    callsign: 'ABC123',
    flag: 'Singapore',
    flag_code: 'SG',
    vessel_type: 'Container Ship',
  } as flattenedVesselPortAndZone;

  it('should correctly flatten port event', () => {
    const result = flattenPortOrZoneEvent(mockEvent);

    expect(result).toEqual({
      eventTimestamp: '2024-01-15T10:00:00Z',
      eventType: 'PORT_ARRIVAL',
      location: 'Singapore Port',
      country: 'Singapore',
      countryFlag: 'SG',
      unlocode: 'SGSIN',
      zoneType: 'PORT',
      speed: 12.5,
      course: 180,
      vesselName: 'Test Vessel',
      imo: '1234567',
      mmsi: '123456789',
      callSign: 'ABC123',
      flag: 'Singapore',
      flagCode: 'SG',
      vesselType: 'Container Ship',
      heading: 175,
      draught: 8.5,
      navigationalStatusStatus: 'At Anchor',
      reportedDestination: 'SINGAPORE',
      reportedEta: '2024-01-16T08:00:00Z',
      zoneId: 'zone123',
    });
  });

  it('should fill unlocode with an empty string for ZONE_EVENTS', () => {
    const result = flattenPortOrZoneEvent(mockEvent, 'ZONE_EVENTS');

    expect(result.unlocode).toBe('');
    expect(result.location).toBe('Singapore Port');
  });

  it('should include unlocode for non-ZONE_EVENTS', () => {
    const result = flattenPortOrZoneEvent(mockEvent, 'PORT_CALLS');

    expect(result.unlocode).toBe('SGSIN');
  });
});

describe('flattenPositionalDiscrepancy', () => {
  const mockEvent: flattenedVesselPositionalDiscrepancies = {
    name: 'Test Vessel',
    imo: '9876543',
    mmsi: '987654321',
    callsign: 'XYZ789',
    flag: 'Panama',
    flag_code: 'PA',
    event_type: 'POSITIONAL_DISCREPANCY',
    asset_id: 'asset123',
    vessel_type: 'Tanker',
    started: {
      timestamp: '2024-01-10T12:00:00Z',
      latitude: 1.2345,
      longitude: 103.8765,
    },
    stopped: {
      timestamp: '2024-01-10T18:00:00Z',
      latitude: 1.3456,
      longitude: 103.9876,
    },
    duration_hours: 6.0,
    has_ended: true,
  } as flattenedVesselPositionalDiscrepancies;

  it('should correctly flatten positional discrepancy event', () => {
    const result = flattenPositionalDiscrepancy(mockEvent);

    expect(result).toEqual({
      eventType: 'POSITIONAL_DISCREPANCY',
      eventTimestamp: '2024-01-10T12:00:00Z',
      callSign: 'XYZ789',
      flag: 'Panama',
      flagCode: 'PA',
      imo: '9876543',
      mmsi: '987654321',
      vesselName: 'Test Vessel',
      vesselType: 'Tanker',
      duration: 6.0,
      hasEnded: true,
      startedLatitude: 1.2345,
      startedLongitude: 103.8765,
      stoppedTimestamp: '2024-01-10T18:00:00Z',
      stoppedLatitude: 1.3456,
      stoppedLongitude: 103.9876,
    });
  });

  it('should handle has_ended false', () => {
    const ongoingEvent = {
      ...mockEvent,
      has_ended: false,
    };

    const result = flattenPositionalDiscrepancy(ongoingEvent);
    expect(result.hasEnded).toBe(false);
  });
});

describe('flattenSTSEvent', () => {
  const mockEvent: flattenedVesselSTSEvents = {
    name: 'Tanker A',
    imo: '1111111',
    mmsi: '111111111',
    callsign: 'TKA001',
    flag: 'Liberia',
    flag_code: 'LR',
    vessel_type: 'Oil Tanker',
    started: '2024-01-12T08:00:00Z',
    stopped: '2024-01-12T14:00:00Z',
    sts_type: 'RECEIVING',
    duration_hours: 6.0,
    paired_vessel: {
      name: 'Tanker B',
      imo: '2222222',
    },
  } as flattenedVesselSTSEvents;

  it('should correctly flatten STS event', () => {
    const result = flattenSTSEvent(mockEvent);

    expect(result).toEqual({
      callSign: 'TKA001',
      flag: 'Liberia',
      flagCode: 'LR',
      imo: '1111111',
      mmsi: '111111111',
      vesselName: 'Tanker A',
      vesselType: 'Oil Tanker',
      eventType: 'STS_PAIRING',
      eventTimestamp: '2024-01-12T08:00:00Z',
      stsType: 'RECEIVING',
      stsEnded: '2024-01-12T14:00:00Z',
      duration: 6.0,
      pairedVessel: 'Tanker B',
      pairedIMO: '2222222',
    });
  });
});

describe('flattenAISGap', () => {
  const mockEvent: flattenedVesselAISGaps = {
    name: 'Mystery Vessel',
    imo: '3333333',
    mmsi: '333333333',
    callsign: 'MYS123',
    flag: 'Marshall Islands',
    flag_code: 'MH',
    vessel_type: 'Bulk Carrier',
    stopped: {
      timestamp: '2024-01-08T10:00:00Z',
      speed: 0.5,
      course: 90,
      navigational_status: {
        code: 5,
        status: 'Moored',
      },
    },
    resumed: {
      timestamp: '2024-01-08T22:00:00Z',
    },
    gap_duration_hours: 12.0,
    draught_change: 2.3,
  } as flattenedVesselAISGaps;

  it('should correctly flatten AIS gap event', () => {
    const result = flattenAISGap(mockEvent);

    expect(result).toEqual({
      callSign: 'MYS123',
      flag: 'Marshall Islands',
      flagCode: 'MH',
      imo: '3333333',
      mmsi: '333333333',
      vesselName: 'Mystery Vessel',
      vesselType: 'Bulk Carrier',
      eventType: 'AIS_GAP',
      duration: 12.0,
      speed: 0.5,
      course: 90,
      navigationalStatusCode: 5,
      navigationalStatusStatus: 'Moored',
      eventTimestamp: '2024-01-08T10:00:00Z',
      draughtChange: 2.3,
      gapResumed: '2024-01-08T22:00:00Z',
      gapStopped: '2024-01-08T10:00:00Z',
    });
  });
});

describe('flattenPortStateControl', () => {
  const mockEvent: flattenedVesselPortStateControl = {
    name: 'Inspected Vessel',
    imo: '4444444',
    mmsi: '444444444',
    callsign: 'INS999',
    flag: 'Greece',
    flag_code: 'GR',
    vessel_type: 'General Cargo',
    authority: 'Port Authority Singapore',
    detained: true,
    no_days_detained: 5,
    inspection_date: '2024-01-05T09:00:00Z',
    inspection_type: 'Detailed',
    no_defects: 12,
    release_date: '2024-01-10T09:00:00Z',
    port_information: {
      name: 'Singapore Port',
      country_common_name: 'Singapore',
      country_code: 'SG',
    },
  } as flattenedVesselPortStateControl;

  it('should correctly flatten port state control event', () => {
    const result = flattenPortStateControl(mockEvent);

    expect(result).toEqual({
      callSign: 'INS999',
      flag: 'Greece',
      flagCode: 'GR',
      imo: '4444444',
      mmsi: '444444444',
      vesselName: 'Inspected Vessel',
      vesselType: 'General Cargo',
      authority: 'Port Authority Singapore',
      detained: true,
      daysDetained: 5,
      inspectionDate: '2024-01-05T09:00:00Z',
      inspectionType: 'Detailed',
      numberOfDefects: 12,
      releaseDate: '2024-01-10T09:00:00Z',
      eventType: 'PORT_STATE_CONTROL',
      eventTimestamp: '2024-01-05T09:00:00Z',
      location: 'Singapore Port',
      country: 'Singapore',
      countryFlag: 'SG',
    });
  });

  it('should fill null inspection_type with an empty string', () => {
    const eventWithNullType = {
      ...mockEvent,
      inspection_type: null,
    };

    const result = flattenPortStateControl(eventWithNullType);
    expect(result.inspectionType).toBe('');
  });

  it('should fill undefined inspection_type with an empty string', () => {
    const eventWithUndefinedType = {
      ...mockEvent,
      inspection_type: undefined,
    };

    const result = flattenPortStateControl(eventWithUndefinedType);
    expect(result.inspectionType).toBe('');
  });
});

describe('Batch flattening functions', () => {
  it('fills missing values with empty values of the matching type', () => {
    const [portCall] = flattenPortCalls([{} as flattenedVesselPortAndZone]);
    const [zoneEvent] = flattenZoneEvents([{} as flattenedVesselPortAndZone]);
    const [discrepancy] = flattenPositionalDiscrepancies([
      {} as flattenedVesselPositionalDiscrepancies,
    ]);
    const [stsEvent] = flattenSTSEvents([{} as flattenedVesselSTSEvents]);
    const [aisGap] = flattenAISGaps([{} as flattenedVesselAISGaps]);
    const [inspection] = flattenPortStateControls([
      {} as flattenedVesselPortStateControl,
    ]);

    expect(portCall).toMatchObject({ vesselName: '', eventType: '', speed: 0 });
    expect(zoneEvent).toMatchObject({
      vesselName: '',
      eventType: '',
      speed: 0,
    });
    expect(discrepancy).toMatchObject({
      eventType: 'POSITIONAL_DISCREPANCY',
      hasEnded: false,
      startedLatitude: 0,
    });
    expect(stsEvent).toMatchObject({
      eventType: 'STS_PAIRING',
      pairedVessel: '',
      duration: 0,
    });
    expect(aisGap).toMatchObject({
      eventType: 'AIS_GAP',
      navigationalStatusStatus: '',
      duration: 0,
    });
    expect(inspection).toMatchObject({
      eventType: 'PORT_STATE_CONTROL',
      detained: false,
      location: '',
    });
  });

  describe('flattenPortCalls', () => {
    it('should flatten array of port events', () => {
      const mockEvents: flattenedVesselPortAndZone[] = [
        {
          event_details: {
            event_timestamp: '2024-01-15T10:00:00Z',
            event_type: 'PORT_ARRIVAL',
            speed: 10,
            course: 90,
          },
          zone_information: {
            name: 'Port A',
            unlocode: 'AAA',
            country_common_name: 'Country A',
            country_code: 'CA',
            type: 'PORT',
            id: 'zone1',
          },
          name: 'Vessel 1',
          imo: '1111111',
          mmsi: '111111111',
          callsign: 'V1',
          flag: 'Flag A',
          flag_code: 'FA',
          vessel_type: 'Cargo',
        } as flattenedVesselPortAndZone,
        {
          event_details: {
            event_timestamp: '2024-01-16T10:00:00Z',
            event_type: 'PORT_DEPARTURE',
            speed: 15,
            course: 180,
          },
          zone_information: {
            name: 'Port B',
            unlocode: 'BBB',
            country_common_name: 'Country B',
            country_code: 'CB',
            type: 'PORT',
            id: 'zone2',
          },
          name: 'Vessel 2',
          imo: '2222222',
          mmsi: '222222222',
          callsign: 'V2',
          flag: 'Flag B',
          flag_code: 'FB',
          vessel_type: 'Tanker',
        } as flattenedVesselPortAndZone,
      ];

      const result = flattenPortCalls(mockEvents);

      expect(result).toHaveLength(2);
      expect(result[0].location).toBe('Port A');
      expect(result[0].unlocode).toBe('AAA');
      expect(result[1].location).toBe('Port B');
      expect(result[1].unlocode).toBe('BBB');
    });

    it('should return empty array for empty input', () => {
      const result = flattenPortCalls([]);
      expect(result).toEqual([]);
    });
  });

  describe('flattenZoneEvents', () => {
    it('should flatten array of zone events without unlocode', () => {
      const mockEvents: flattenedVesselPortAndZone[] = [
        {
          event_details: {
            event_timestamp: '2024-01-15T10:00:00Z',
            event_type: 'ZONE_ENTRY',
            speed: 10,
            course: 90,
          },
          zone_information: {
            name: 'Zone A',
            unlocode: 'ZZZ',
            country_common_name: 'Country Z',
            country_code: 'CZ',
            type: 'ZONE',
            id: 'zone1',
          },
          name: 'Vessel 1',
          imo: '1111111',
          mmsi: '111111111',
          callsign: 'V1',
          flag: 'Flag Z',
          flag_code: 'FZ',
          vessel_type: 'Cargo',
        } as flattenedVesselPortAndZone,
      ];

      const result = flattenZoneEvents(mockEvents);

      expect(result).toHaveLength(1);
      expect(result[0].location).toBe('Zone A');
      expect(result[0].unlocode).toBe('');
    });
  });

  describe('flattenPositionalDiscrepancies', () => {
    it('should flatten array of positional discrepancy events', () => {
      const mockEvents: flattenedVesselPositionalDiscrepancies[] = [
        {
          name: 'Vessel A',
          imo: 'A111',
          mmsi: 'A111111',
          callsign: 'VA',
          flag: 'Flag A',
          flag_code: 'FA',
          vessel_type: 'Cargo',
          started: {
            timestamp: '2024-01-10T12:00:00Z',
            latitude: 1.0,
            longitude: 2.0,
          },
          stopped: {
            timestamp: '2024-01-10T18:00:00Z',
            latitude: 1.1,
            longitude: 2.1,
          },
          duration_hours: 6.0,
          has_ended: true,
        } as flattenedVesselPositionalDiscrepancies,
        {
          name: 'Vessel B',
          imo: 'B222',
          mmsi: 'B222222',
          callsign: 'VB',
          flag: 'Flag B',
          flag_code: 'FB',
          vessel_type: 'Tanker',
          started: {
            timestamp: '2024-01-11T12:00:00Z',
            latitude: 3.0,
            longitude: 4.0,
          },
          stopped: {
            timestamp: '2024-01-11T20:00:00Z',
            latitude: 3.1,
            longitude: 4.1,
          },
          duration_hours: 8.0,
          has_ended: false,
        } as flattenedVesselPositionalDiscrepancies,
      ];

      const result = flattenPositionalDiscrepancies(mockEvents);

      expect(result).toHaveLength(2);
      expect(result[0].eventType).toBe('POSITIONAL_DISCREPANCY');
      expect(result[1].eventType).toBe('POSITIONAL_DISCREPANCY');
    });
  });

  describe('flattenSTSEvents', () => {
    it('should flatten array of STS events', () => {
      const mockEvents: flattenedVesselSTSEvents[] = [
        {
          name: 'Tanker 1',
          imo: 'T111',
          mmsi: 'T111111',
          callsign: 'T1',
          flag: 'Flag T',
          flag_code: 'FT',
          vessel_type: 'Oil Tanker',
          started: '2024-01-12T08:00:00Z',
          stopped: '2024-01-12T14:00:00Z',
          sts_type: 'RECEIVING',
          duration_hours: 6.0,
          paired_vessel: {
            name: 'Tanker 2',
            imo: 'T222',
          },
        } as flattenedVesselSTSEvents,
      ];

      const result = flattenSTSEvents(mockEvents);

      expect(result).toHaveLength(1);
      expect(result[0].eventType).toBe('STS_PAIRING');
      expect(result[0].pairedVessel).toBe('Tanker 2');
    });
  });

  describe('flattenAISGaps', () => {
    it('should flatten array of AIS gap events', () => {
      const mockEvents: flattenedVesselAISGaps[] = [
        {
          name: 'Vessel X',
          imo: 'X111',
          mmsi: 'X111111',
          callsign: 'VX',
          flag: 'Flag X',
          flag_code: 'FX',
          vessel_type: 'Bulk Carrier',
          stopped: {
            timestamp: '2024-01-08T10:00:00Z',
            speed: 0.5,
            course: 90,
            navigational_status: {
              code: 5,
              status: 'Moored',
            },
          },
          resumed: {
            timestamp: '2024-01-08T22:00:00Z',
          },
          gap_duration_hours: 12.0,
          draught_change: 2.3,
        } as flattenedVesselAISGaps,
      ];

      const result = flattenAISGaps(mockEvents);

      expect(result).toHaveLength(1);
      expect(result[0].eventType).toBe('AIS_GAP');
    });
  });

  describe('flattenPortStateControls', () => {
    it('should flatten array of port state control events', () => {
      const mockEvents: flattenedVesselPortStateControl[] = [
        {
          name: 'Inspected 1',
          imo: 'I111',
          mmsi: 'I111111',
          callsign: 'I1',
          flag: 'Flag I',
          flag_code: 'FI',
          vessel_type: 'Cargo',
          authority: 'Authority A',
          detained: true,
          no_days_detained: 5,
          inspection_date: '2024-01-05T09:00:00Z',
          inspection_type: 'Detailed',
          no_defects: 12,
          release_date: '2024-01-10T09:00:00Z',
          port_information: {
            name: 'Port A',
            country_common_name: 'Country A',
            country_code: 'CA',
          },
        } as flattenedVesselPortStateControl,
        {
          name: 'Inspected 2',
          imo: 'I222',
          mmsi: 'I222222',
          callsign: 'I2',
          flag: 'Flag J',
          flag_code: 'FJ',
          vessel_type: 'Tanker',
          authority: 'Authority B',
          detained: false,
          no_days_detained: 0,
          inspection_date: '2024-01-06T09:00:00Z',
          inspection_type: 'Basic',
          no_defects: 3,
          release_date: '2024-01-06T15:00:00Z',
          port_information: {
            name: 'Port B',
            country_common_name: 'Country B',
            country_code: 'CB',
          },
        } as flattenedVesselPortStateControl,
      ];

      const result = flattenPortStateControls(mockEvents);

      expect(result).toHaveLength(2);
      expect(result[0].eventType).toBe('PORT_STATE_CONTROL');
      expect(result[0].detained).toBe(true);
      expect(result[1].detained).toBe(false);
    });
  });
});

describe('Constants', () => {
  describe('TAB_EVENT_TYPES', () => {
    it('should have correct PORT_CALLS event types', () => {
      expect(TAB_EVENT_TYPES.PORT_CALLS).toEqual([
        'PORT_AREA_ARRIVAL',
        'PORT_AREA_DEPARTURE',
        'PORT_ARRIVAL',
        'PORT_DEPARTURE',
      ]);
    });

    it('should have correct ZONE_EVENTS event types', () => {
      expect(TAB_EVENT_TYPES.ZONE_EVENTS).toEqual(['ZONE_ENTRY', 'ZONE_EXIT']);
    });

    it('should have correct AIS_GAPS event types', () => {
      expect(TAB_EVENT_TYPES.AIS_GAPS).toEqual(['AIS_GAP']);
    });

    it('should have correct STS_PAIRINGS event types', () => {
      expect(TAB_EVENT_TYPES.STS_PAIRINGS).toEqual(['STS_PAIRING']);
    });

    it('should have correct POSITIONAL_DISCREPANCIES event types', () => {
      expect(TAB_EVENT_TYPES.POSITIONAL_DISCREPANCIES).toEqual([
        'POSITIONAL_DISCREPANCY',
      ]);
    });

    it('should have correct PORT_STATE_CONTROL event types', () => {
      expect(TAB_EVENT_TYPES.PORT_STATE_CONTROL).toEqual([
        'PORT_STATE_CONTROL',
      ]);
    });

    it('should have 6 tab categories', () => {
      expect(Object.keys(TAB_EVENT_TYPES)).toHaveLength(6);
    });
  });

  describe('EVENT_TYPE_MAP', () => {
    it('should map port event types correctly', () => {
      expect(EVENT_TYPE_MAP.PORT_AREA_ARRIVAL).toBe('AREA_ARRIVAL');
      expect(EVENT_TYPE_MAP.PORT_AREA_DEPARTURE).toBe('AREA_DEPARTURE');
      expect(EVENT_TYPE_MAP.PORT_ARRIVAL).toBe('ARRIVAL');
      expect(EVENT_TYPE_MAP.PORT_DEPARTURE).toBe('DEPARTURE');
    });

    it('should map tab names to event types', () => {
      expect(EVENT_TYPE_MAP.AIS_GAPS).toBe('AIS_GAP');
      expect(EVENT_TYPE_MAP.STS_PAIRINGS).toBe('STS_PAIRING');
      expect(EVENT_TYPE_MAP.POSITIONAL_DISCREPANCIES).toBe(
        'POSITIONAL_DISCREPANCY',
      );
      expect(EVENT_TYPE_MAP.PORT_STATE_CONTROL).toBe('PORT_STATE_CONTROL');
    });

    it('should have 8 mappings', () => {
      expect(Object.keys(EVENT_TYPE_MAP)).toHaveLength(8);
    });
  });
});
