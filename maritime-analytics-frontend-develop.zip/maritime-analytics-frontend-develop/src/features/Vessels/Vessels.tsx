import { useState, useRef, useEffect, useMemo } from 'react';
import { MdAutoAwesome } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';
import { useShallow } from 'zustand/react/shallow';
import VesselEventsTab from './ui/VesselEventsTab';
import { isMara2Enabled } from '@/app/config/config';
import {
  ASK_IQ_PATH,
  askIqPrompts,
  buildAskIqNavigationState,
} from '@/features/mara2/utils/askIq';
import { usePauseAtEvents } from '@/features/Vessels/hooks/usePauseAtEvents';
import { useVesselActivity } from '@/features/Vessels/hooks/useVesselActivity';
import { useVesselDetails } from '@/features/Vessels/hooks/useVesselDetails';
import { useVesselActivityStore } from '@/features/Vessels/store/useVesselActivityStore';
import {
  DEFAULT_TOOLBAR_DATE_STATE,
  ToolbarDateState,
} from '@/features/Vessels/types/toolbarTypes';
import VesselActivityMap from '@/features/Vessels/ui/VesselActivityMap';
import VesselActivitySidebar from '@/features/Vessels/ui/VesselActivitySidebar';
import VesselActivityToolbar from '@/features/Vessels/ui/VesselActivityToolbar';
import VesselEventTimeline from '@/features/Vessels/ui/VesselEventTimeline';
import VesselGanttTimeline from '@/features/Vessels/ui/VesselGanttTimeline';
import VesselReplayBar from '@/features/Vessels/ui/VesselReplayBar';
import VesselSwitcher from '@/features/Vessels/ui/VesselSwitcher';
import { addRecentVessel } from '@/features/Vessels/utils/recentVessels';
import EntityLoadingSkeleton from '@/shared/components/EntityLoadingSkeleton';
import EntityTabs from '@/shared/components/EntityTabs';
import EntityToolBar from '@/shared/ui/EntityToolbar';
import GenericErrorPage from '@/shared/ui/GenericErrorPage';

const vesselEventsTabs = [
  {
    label: 'Area Arrival',
    value: 'PORT_AREA_ARRIVAL',
    groupings: 'Port Events',
  },
  { label: 'Arrival', value: 'PORT_ARRIVAL', groupings: 'Port Events' },
  { label: 'Departure', value: 'PORT_DEPARTURE', groupings: 'Port Events' },
  {
    label: 'Area Departure',
    value: 'PORT_AREA_DEPARTURE',
    groupings: 'Port Events',
  },
  { label: 'Zone Entry', value: 'ZONE_ENTRY', groupings: 'Zone Events' },
  { label: 'Zone Exit', value: 'ZONE_EXIT', groupings: 'Zone Events' },
  { label: 'AIS Gap', value: 'AIS_GAPS', groupings: 'Other Events' },
  { label: 'STS Pairing', value: 'STS_PAIRINGS', groupings: 'Other Events' },
  {
    label: 'Positional Discrepancy',
    value: 'POSITIONAL_DISCREPANCIES',
    groupings: 'Other Events',
  },
  {
    label: 'Port State Control',
    value: 'PORT_STATE_CONTROL',
    groupings: 'Other Events',
  },
];

export default function VesselDetailsPage() {
  const {
    id,
    vessel,
    loading,
    error,
    refresh,
    setRefresh,
    dateRange,
    setDateRange,
    toggleBookmarkLoading,
    isBookmarked,
    addOrRemoveBookmark,
  } = useVesselDetails();

  const navigate = useNavigate();
  const handleAskIQ = () => {
    if (!vessel?.name || !vessel?.imo) return;
    navigate(
      ASK_IQ_PATH,
      buildAskIqNavigationState(askIqPrompts.vessel(vessel.name, vessel.imo)),
    );
  };

  const buttonLabel = isBookmarked(vessel?.imo)
    ? 'Remove from Library'
    : 'Add to Library';

  const [activeTab, setActiveTab] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarOpenSection, setSidebarOpenSection] = useState<string | null>(
    null,
  );
  const [toolbarDateState, setToolbarDateState] = useState<ToolbarDateState>(
    DEFAULT_TOOLBAR_DATE_STATE,
  );
  const [ganttHeight, setGanttHeight] = useState(224);
  const preFocusStateRef = useRef<{
    sidebarOpen: boolean;
    ganttOpen: boolean;
    timelinePanelOpen: boolean;
  } | null>(null);
  const ganttDragRef = useRef<{ startY: number; startHeight: number } | null>(
    null,
  );
  const ganttDragCleanupRef = useRef<(() => void) | null>(null);

  const { timelinePanelOpen, setTimelinePanelOpen, ganttOpen, setGanttOpen } =
    useVesselActivityStore(
      useShallow((s) => ({
        timelinePanelOpen: s.timelinePanelOpen,
        setTimelinePanelOpen: s.setTimelinePanelOpen,
        ganttOpen: s.ganttOpen,
        setGanttOpen: s.setGanttOpen,
      })),
    );

  const isInFocusMode = !sidebarOpen && !ganttOpen && !timelinePanelOpen;

  function enterFocusMode() {
    preFocusStateRef.current = { sidebarOpen, ganttOpen, timelinePanelOpen };
    setSidebarOpen(false);
    setGanttOpen(false);
    setTimelinePanelOpen(false);
  }

  function exitFocusMode() {
    const prev = preFocusStateRef.current;
    preFocusStateRef.current = null;
    setSidebarOpen(prev ? prev.sidebarOpen : true);
    setGanttOpen(prev ? prev.ganttOpen : false);
    setTimelinePanelOpen(prev ? prev.timelinePanelOpen : false);
  }

  function toggleFocusMode() {
    if (isInFocusMode) exitFocusMode();
    else enterFocusMode();
  }
  const toggleFocusModeRef = useRef(toggleFocusMode);
  toggleFocusModeRef.current = toggleFocusMode;

  const handleGanttResizeStart = (e: React.MouseEvent) => {
    if (!ganttOpen) return;
    e.preventDefault();
    ganttDragRef.current = { startY: e.clientY, startHeight: ganttHeight };

    function onMove(ev: MouseEvent) {
      if (!ganttDragRef.current) return;
      const delta = ganttDragRef.current.startY - ev.clientY;
      setGanttHeight(
        Math.max(80, Math.min(480, ganttDragRef.current.startHeight + delta)),
      );
    }

    function onUp() {
      ganttDragRef.current = null;
      ganttDragCleanupRef.current = null;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    }

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    ganttDragCleanupRef.current = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  };

  useEffect(() => {
    return () => {
      ganttDragCleanupRef.current?.();
    };
  }, []);

  const toggleGantt = () => {
    setGanttOpen(!ganttOpen);
  };

  // Ctrl+/ (or Cmd+/) toggles focus mode — matches prototype keyboard shortcut
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (!(e.metaKey || e.ctrlKey)) return;
      if (e.code !== 'Slash' && e.key !== '/') return;
      e.preventDefault();
      toggleFocusModeRef.current();
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const activityData = useVesselActivity(vessel?.imo ?? '', dateRange);

  const replayDateRange = useMemo(
    () => ({
      from: new Date(dateRange.start || Date.now() - 7 * 24 * 60 * 60 * 1000),
      to: new Date(dateRange.end || Date.now()),
    }),
    [dateRange.start, dateRange.end],
  );
  usePauseAtEvents(activityData.events, replayDateRange);

  // Add vessel to recent history once it resolves
  useEffect(() => {
    if (!vessel) return;
    addRecentVessel({
      imo: vessel.imo,
      name: vessel.name,
      flag_code: vessel.flag.country_code ?? '',
      flag: vessel.flag.name ?? '',
      vessel_type: vessel.type ?? '',
      vessel_status: vessel.ship_status ?? '',
      mmsi: vessel.mmsi ?? null,
      callsign: vessel.callsign ?? '',
      asset_id: vessel.asset_id ?? '',
    });
  }, [vessel?.imo]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (activityData.events.length === 0 && ganttOpen) {
      setGanttOpen(false);
    }
  }, [activityData.events.length, ganttOpen, setGanttOpen]);

  if (loading)
    return (
      <div className="h-screen p-6 dark:bg-gray-900">
        <EntityLoadingSkeleton />
      </div>
    );
  if (error)
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );
  if (!vessel)
    return (
      <div className="h-screen bg-gray-100 p-6 dark:bg-gray-900">
        <GenericErrorPage />
      </div>
    );

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-gray-100 dark:bg-gray-900">
      <header className="shrink-0 bg-gray-100 dark:bg-gray-900">
        <EntityToolBar
          id={id}
          breadcrumbs={[
            { label: 'Library', href: '/analytics/library' },
            { label: 'Vessels', href: '/analytics/library?tab=Vessels' },
          ]}
          flag={vessel.flag.country_code}
          title={vessel.name}
          renderTitle={<VesselSwitcher vessel={vessel} />}
          subtitle={`IMO: ${vessel.imo} ${vessel.flag.name} ${vessel.type}`}
          onToggle={() => addOrRemoveBookmark(vessel.imo)}
          loading={toggleBookmarkLoading}
          buttonLabel={buttonLabel}
          refresh={refresh}
          setRefresh={setRefresh}
          dontShowDateRange
        />

        <div className="bg-gray-50">
          <EntityTabs
            tabs={[
              { key: 'overview', label: 'Overview' },
              { key: 'events', label: 'Events' },
            ]}
            activeTab={activeTab}
            onChange={setActiveTab}
            renderActions={
              <div className="flex items-center gap-2">
                {isMara2Enabled() && (
                  <button
                    onClick={handleAskIQ}
                    className="-mt-5 flex min-w-[110px] items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-1.5 text-sm text-black hover:bg-gray-200 dark:border-gray-700 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
                  >
                    <MdAutoAwesome className="text-gray-400" />
                    Ask IQ
                  </button>
                )}
              </div>
            }
          />
        </div>
      </header>

      {activeTab === 'overview' ? (
        <main className="flex flex-1 flex-row overflow-hidden">
          {/* Vessel details sidebar */}
          {sidebarOpen && (
            <VesselActivitySidebar
              vessel={vessel}
              openSection={sidebarOpenSection}
              onToggleSection={(id) =>
                setSidebarOpenSection((prev) => (prev === id ? null : id))
              }
            />
          )}

          {/* Map column: toolbar + map + replay + gantt */}
          <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden">
            <VesselActivityToolbar
              onDateRangeChange={setDateRange}
              dateState={toolbarDateState}
              onDateStateChange={setToolbarDateState}
              refresh={refresh}
              setRefresh={setRefresh}
              sidebarOpen={sidebarOpen}
              onToggleSidebar={() => setSidebarOpen((v) => !v)}
              imo={vessel.imo}
              isInFocusMode={isInFocusMode}
              onToggleFocusMode={toggleFocusMode}
            />
            <div className="relative flex-1 overflow-hidden">
              <VesselActivityMap
                activityData={activityData}
                imo={vessel.imo}
                dateRange={replayDateRange}
              />
            </div>

            {/* Replay bar + Gantt timeline */}
            <div className="shrink-0 overflow-hidden bg-white dark:bg-gray-800">
              {/* Resize handle */}
              <div
                role="button"
                tabIndex={0}
                aria-label="Resize Gantt panel"
                onMouseDown={handleGanttResizeStart}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    if (ganttOpen) setGanttHeight((h) => Math.min(480, h + 20));
                  } else if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    if (ganttOpen) setGanttHeight((h) => Math.max(80, h - 20));
                  }
                }}
                className={`h-1 border-t border-gray-200 dark:border-gray-700 ${
                  ganttOpen
                    ? 'cursor-ns-resize hover:border-psg-orange-500/50'
                    : ''
                }`}
              />

              {/* Replay bar */}
              <VesselReplayBar
                events={activityData.events}
                dateRange={replayDateRange}
                ganttOpen={ganttOpen}
                onToggleGantt={toggleGantt}
                disabled={activityData.events.length === 0}
              />

              {/* Gantt timeline */}
              {ganttOpen && activityData.events.length > 0 && (
                <div
                  style={{ height: ganttHeight }}
                  className="overflow-hidden border-t border-gray-200 dark:border-gray-700"
                >
                  <VesselGanttTimeline
                    events={activityData.events}
                    dateRange={{
                      from: new Date(
                        dateRange.start || Date.now() - 7 * 24 * 60 * 60 * 1000,
                      ),
                      to: new Date(dateRange.end || Date.now()),
                    }}
                    height={ganttHeight}
                    imo={vessel.imo}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Timeline panel sits beside the map column, at the same top level */}
          {timelinePanelOpen && (
            <VesselEventTimeline
              events={activityData.events}
              loading={activityData.loading}
            />
          )}
        </main>
      ) : (
        <main className="min-h-0 flex-1 overflow-auto">
          <div className="mt-4 min-h-0 px-6">
            <VesselEventsTab
              vesselName={vessel.name}
              vesselId={id!}
              vesselEventsTabs={vesselEventsTabs}
              setRefresh={setRefresh}
              refresh={refresh}
            />
          </div>
        </main>
      )}
    </div>
  );
}
