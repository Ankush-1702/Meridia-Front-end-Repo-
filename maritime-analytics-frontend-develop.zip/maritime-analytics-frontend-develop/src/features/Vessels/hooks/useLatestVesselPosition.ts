import { useEffect, useState } from 'react';
import {
  AISPosition,
  fetchLatestVesselPosition,
} from '@/features/Vessels/services/vesselPositionService';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';

export interface LatestVesselPositionResult {
  position: AISPosition | null;
  loading: boolean;
  error: string | null;
}

export function useLatestVesselPosition(
  imo: string,
): LatestVesselPositionResult {
  const [position, setPosition] = useState<AISPosition | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { showToast } = useToastNotification();

  useEffect(() => {
    if (!imo) {
      setPosition(null);
      setError(null);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setPosition(null);
    setLoading(true);
    setError(null);

    fetchLatestVesselPosition(imo)
      .then((pos) => {
        if (!cancelled) {
          setPosition(pos);
          setLoading(false);
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          const msg =
            err instanceof Error
              ? err.message
              : 'Failed to load vessel position';
          setError(msg);
          setLoading(false);
          showToast('error', msg, 5000);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [imo, showToast]);

  return { position, loading, error };
}
