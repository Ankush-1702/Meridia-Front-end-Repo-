import { useEffect, useRef } from 'react';
import {
  useVesselActivityStore,
  DateRange,
} from '@/features/Vessels/store/useVesselActivityStore';
import {
  ActivityEvent,
  getEventLegendKey,
} from '@/features/Vessels/types/vesselActivityTypes';

const TICK_MS = 100;
const PAUSE_DURATION_MS = 4500;

export function usePauseAtEvents(
  events: ActivityEvent[],
  dateRange: DateRange,
) {
  const countdownRef = useRef<{ elapsed: number } | null>(null);

  useEffect(() => {
    const id = setInterval(() => {
      const store = useVesselActivityStore.getState();

      // ── Short-circuit when nothing to do ─────────────────────────────────
      if (countdownRef.current === null) {
        if (!store.isReplaying || !store.replayAt || !store.pauseAtEvents)
          return;
      }

      const {
        replayAt,
        isReplaying,
        pauseAtEvents,
        isScrubbing,
        filters,
        announcedEventIds,
        markEventsAnnounced,
        pauseReplay,
        startReplay,
        setReplayAnnouncedEvent,
        replayCountdownPaused,
      } = store;

      // ── Active countdown: waiting before auto-resume ──────────────────────
      if (countdownRef.current !== null) {
        // User manually dismissed the card — abort countdown
        if (store.replayAnnouncedEvent === null) {
          countdownRef.current = null;
          return;
        }
        if (!replayCountdownPaused) {
          countdownRef.current.elapsed += TICK_MS;
        }
        if (countdownRef.current.elapsed >= PAUSE_DURATION_MS) {
          countdownRef.current = null;
          setReplayAnnouncedEvent(null);
          if (!useVesselActivityStore.getState().isScrubbing) {
            startReplay(dateRange);
          }
        }
        return;
      }

      // ── Event detection ───────────────────────────────────────────────────
      if (!isReplaying || !replayAt || isScrubbing || !pauseAtEvents) return;

      const cursorMs = replayAt.getTime();
      const newlyReached = events.filter((ev) => {
        if (!filters[getEventLegendKey(ev)]) return false;
        if (announcedEventIds.has(ev.id)) return false;
        return new Date(ev.startTime).getTime() <= cursorMs;
      });

      if (newlyReached.length === 0) return;

      markEventsAnnounced(newlyReached.map((e) => e.id));
      pauseReplay();
      setReplayAnnouncedEvent(newlyReached);
      countdownRef.current = { elapsed: 0 };
    }, TICK_MS);

    return () => clearInterval(id);
  }, [events, dateRange]);
}
