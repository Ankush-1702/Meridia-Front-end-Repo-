import { useCallback, useEffect, useState } from 'react';
import { fetchMTIScore } from '@/features/Vessels/services/mtiService';

interface UseMTIScoreResult {
  score: number | 'unscored' | null;
  loading: boolean;
  error: Error | null;
  retry: () => void;
}

export function useMTIScore(imo: string): UseMTIScoreResult {
  const [score, setScore] = useState<number | 'unscored' | null>(null);
  const [loading, setLoading] = useState(() => Boolean(imo));
  const [error, setError] = useState<Error | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  const retry = useCallback(() => {
    setRetryCount((prev) => prev + 1);
  }, []);

  useEffect(() => {
    if (!imo) {
      setScore(null);
      setLoading(false);
      setError(null);
      return;
    }

    let cancelled = false;
    setScore(null);
    setLoading(true);
    setError(null);

    fetchMTIScore(imo)
      .then((result) => {
        if (!cancelled) {
          setScore(result);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err : new Error(String(err)));
          setScore(null);
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [imo, retryCount]);

  return { score, loading, error, retry };
}
