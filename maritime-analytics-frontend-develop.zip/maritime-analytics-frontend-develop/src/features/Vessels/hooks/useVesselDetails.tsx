// features/Vessels/hooks/useVesselDetails.ts
import { useState } from 'react';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useLibrary } from '@/features/library/context/LibraryContext';
import { toggleBookmark } from '@/features/library/services/libraryApi';
import { fetchVesselDetails } from '@/features/Vessels/services/vesselServices';
import { useEntityDetails } from '@/shared/hooks/useEntityDetails';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { Vessel } from '@/shared/types/entities';

export function useVesselDetails() {
  const {
    id,
    entity,
    loading,
    error,
    refresh,
    setRefresh,
    dateRange,
    setDateRange,
  } = useEntityDetails<Vessel>(fetchVesselDetails);

  const { bookmarks, fetchSavedEntities } = useLibrary();
  const { showToast } = useToastNotification();
  const handleApiError = useApiErrorHandler();
  const [toggleBookmarkLoading, setToggleBookmarkLoading] = useState(false);

  const isBookmarked = (refId: string | undefined) =>
    bookmarks?.some(
      (bm) =>
        bm.entityRefId === refId && bm.entityType.toLowerCase() === 'vessel',
    );

  const addOrRemoveBookmark = async (refId: string) => {
    setToggleBookmarkLoading(true);
    try {
      const method = isBookmarked(refId) ? 'remove' : 'add';
      await toggleBookmark(method, {
        id: refId,
        type: 'vessel',
      });
      showToast(
        'success',
        `${entity?.name} ${isBookmarked(refId) ? 'removed from' : 'added to'} bookmarks`,
        5000,
      );
      fetchSavedEntities();
    } catch (err) {
      console.error(err);
      handleApiError(err);
    } finally {
      setToggleBookmarkLoading(false);
    }
  };

  return {
    id,
    vessel: entity,
    loading,
    error,
    refresh,
    setRefresh,
    dateRange,
    setDateRange,
    toggleBookmarkLoading,
    isBookmarked,
    addOrRemoveBookmark,
  };
}
