import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useMTIScore } from '@/features/Vessels/hooks/useMTIScore';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

const mockFetch = vi.fn();

vi.mock('@/features/Vessels/services/mtiService', () => ({
  fetchMTIScore: (...a: unknown[]) => mockFetch(...a),
}));

beforeEach(() => {
  vi.clearAllMocks();
});

/* ─── tests ─────────────────────────────────────────────────────────────────── */

describe('useMTIScore', () => {
  it('starts in loading state when imo is provided', () => {
    mockFetch.mockResolvedValue(4.2);
    const { result, unmount } = renderHook(() => useMTIScore('IMO1234567'));
    expect(result.current.loading).toBe(true);
    expect(result.current.score).toBeNull();
    expect(result.current.error).toBeNull();
    unmount();
  });

  it('returns score after successful fetch', async () => {
    mockFetch.mockResolvedValue(4.2);
    const { result } = renderHook(() => useMTIScore('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBe(4.2);
    expect(result.current.error).toBeNull();
  });

  it('returns "unscored" when vessel is not scored', async () => {
    mockFetch.mockResolvedValue('unscored');
    const { result } = renderHook(() => useMTIScore('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBe('unscored');
    expect(result.current.error).toBeNull();
  });

  it('returns null score and loading=false when imo is empty', async () => {
    const { result } = renderHook(() => useMTIScore(''));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBeNull();
    expect(result.current.error).toBeNull();
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it('sets error, stops loading, and clears score on fetch failure', async () => {
    mockFetch.mockRejectedValue(new Error('network error'));
    const { result } = renderHook(() => useMTIScore('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error?.message).toBe('network error');
    expect(result.current.score).toBeNull();
  });

  it('clears stale score when imo changes to empty', async () => {
    mockFetch.mockResolvedValue(4.2);
    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useMTIScore(imo),
      { initialProps: { imo: 'IMO1234567' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBe(4.2);

    act(() => {
      rerender({ imo: '' });
    });

    expect(result.current.score).toBeNull();
    expect(result.current.loading).toBe(false);
  });

  it('clears stale score and fetches new one when imo changes', async () => {
    mockFetch.mockResolvedValue(4.2);
    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useMTIScore(imo),
      { initialProps: { imo: 'IMO1111111' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBe(4.2);

    mockFetch.mockResolvedValue(2.8);

    act(() => {
      rerender({ imo: 'IMO2222222' });
    });

    // Stale score should be cleared while fetching new data
    expect(result.current.score).toBeNull();
    expect(result.current.loading).toBe(true);

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.score).toBe(2.8);
  });

  it('handles non-Error rejections by converting to Error', async () => {
    mockFetch.mockRejectedValue('string error');
    const { result } = renderHook(() => useMTIScore('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error?.message).toBe('string error');
    expect(result.current.score).toBeNull();
  });
});
