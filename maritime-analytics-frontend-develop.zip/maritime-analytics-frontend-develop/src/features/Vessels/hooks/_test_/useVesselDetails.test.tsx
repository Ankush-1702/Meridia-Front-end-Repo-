import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useVesselDetails } from '@/features/Vessels/hooks/useVesselDetails';

/* -------------------- mocks -------------------- */

const mockFetchSavedEntities = vi.fn();
const mockShowToast = vi.fn();
const mockHandleApiError = vi.fn();
const mockToggleBookmark = vi.fn();

vi.mock('@/shared/hooks/useEntityDetails', () => ({
  useEntityDetails: <T,>() => ({
    id: 'vessel-1',
    entity: { name: 'Test Vessel' } as T,
    loading: false,
    error: null,
    refresh: false,
    setRefresh: vi.fn(),
    dateRange: null,
    setDateRange: vi.fn(),
  }),
}));

vi.mock('@/features/library/context/LibraryContext', () => ({
  useLibrary: () => ({
    bookmarks: [
      {
        entityRefId: 'vessel-1',
        entityType: 'vessel',
      },
    ],
    fetchSavedEntities: mockFetchSavedEntities,
  }),
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: mockShowToast,
  }),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: () => mockHandleApiError,
}));

vi.mock('@/features/library/services/libraryApi', () => ({
  toggleBookmark: (...args: Parameters<typeof mockToggleBookmark>) =>
    mockToggleBookmark(...args),
}));

/* -------------------- tests -------------------- */

describe('useVesselDetails', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns vessel details and base state correctly', () => {
    const { result } = renderHook(() => useVesselDetails());

    expect(result.current.id).toBe('vessel-1');
    expect(result.current.vessel?.name).toBe('Test Vessel');
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBeNull();
  });

  it('detects bookmarked vessel correctly', () => {
    const { result } = renderHook(() => useVesselDetails());

    expect(result.current.isBookmarked('vessel-1')).toBe(true);
    expect(result.current.isBookmarked('vessel-2')).toBe(false);
  });

  it('removes bookmark if vessel is already bookmarked', async () => {
    mockToggleBookmark.mockResolvedValueOnce(undefined);

    const { result } = renderHook(() => useVesselDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('vessel-1');
    });

    expect(mockToggleBookmark).toHaveBeenCalledWith('remove', {
      id: 'vessel-1',
      type: 'vessel',
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'success',
      'Test Vessel removed from bookmarks',
      5000,
    );

    expect(mockFetchSavedEntities).toHaveBeenCalled();
    expect(result.current.toggleBookmarkLoading).toBe(false);
  });

  it('adds bookmark if vessel is not bookmarked', async () => {
    mockToggleBookmark.mockResolvedValueOnce(undefined);

    const { result } = renderHook(() => useVesselDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('vessel-2');
    });

    expect(mockToggleBookmark).toHaveBeenCalledWith('add', {
      id: 'vessel-2',
      type: 'vessel',
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'success',
      'Test Vessel added to bookmarks',
      5000,
    );

    expect(mockFetchSavedEntities).toHaveBeenCalled();
  });

  it('handles API errors correctly', async () => {
    const error = new Error('API failure');
    mockToggleBookmark.mockRejectedValueOnce(error);

    const { result } = renderHook(() => useVesselDetails());

    await act(async () => {
      await result.current.addOrRemoveBookmark('vessel-1');
    });

    expect(mockHandleApiError).toHaveBeenCalledWith(error);
    expect(result.current.toggleBookmarkLoading).toBe(false);
  });
});
