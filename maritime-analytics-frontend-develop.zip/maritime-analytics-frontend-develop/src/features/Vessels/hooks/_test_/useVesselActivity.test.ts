import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useVesselActivity } from '@/features/Vessels/hooks/useVesselActivity';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

const mockFetchPort = vi.fn();
const mockFetchZone = vi.fn();
const mockFetchAIS = vi.fn();
const mockFetchSTS = vi.fn();
const mockFetchDisc = vi.fn();
const mockFetchPSC = vi.fn();

const mockShowToast = vi.fn();
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

vi.mock('@/features/Vessels/services/vesselActivityServices', () => ({
  fetchPortCallsForMap: (...a: unknown[]) => mockFetchPort(...a),
  fetchZoneEventsForMap: (...a: unknown[]) => mockFetchZone(...a),
  fetchAISGapsForMap: (...a: unknown[]) => mockFetchAIS(...a),
  fetchSTSForMap: (...a: unknown[]) => mockFetchSTS(...a),
  fetchDiscrepanciesForMap: (...a: unknown[]) => mockFetchDisc(...a),
  fetchPSCForMap: (...a: unknown[]) => mockFetchPSC(...a),
}));

/* ─── helpers ───────────────────────────────────────────────────────────────── */

const DATE_RANGE = { start: '2024-01-01', end: '2024-01-31' };

function makePortEvent(id: string, timestamp: string) {
  return {
    event_details: {
      event_id: id,
      event_type: 'PORT_ENTRY',
      event_timestamp: timestamp,
      latitude: 1,
      longitude: 1,
    },
    zone_information: { name: 'Test Port' },
  };
}

function makeAISGap(id: string, timestamp: string) {
  return {
    event_id: id,
    gap_duration_hours: 2.5,
    stopped: { timestamp, latitude: 2, longitude: 2 },
    resumed: { timestamp: '2024-01-10T02:00:00Z' },
  };
}

/* ─── tests ─────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.clearAllMocks();
});

describe('useVesselActivity', () => {
  it('starts in loading state when imo and dateRange are provided', async () => {
    // Use deferred promises so we can assert the loading state before
    // anything resolves, then drain them at the end to avoid leaking
    // state updates after the test exits
    let resolvePort!: (v: []) => void;
    const deferredPort = new Promise<[]>((res) => (resolvePort = res));

    mockFetchPort.mockReturnValue(deferredPort);
    mockFetchZone.mockResolvedValue([]);
    mockFetchAIS.mockResolvedValue([]);
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    // Synchronous assertion — Promise.allSettled hasn't resolved yet
    expect(result.current.loading).toBe(true);
    expect(result.current.events).toEqual([]);

    // Drain the deferred promise so no state update leaks after the test
    await act(async () => {
      resolvePort([]);
    });
  });

  it('returns empty events when imo is empty', async () => {
    const { result } = renderHook(() => useVesselActivity('', DATE_RANGE));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.events).toEqual([]);
    expect(mockFetchPort).not.toHaveBeenCalled();
  });

  it('merges and normalizes events from all services', async () => {
    mockFetchPort.mockResolvedValue([
      makePortEvent('p1', '2024-01-10T00:00:00Z'),
    ]);
    mockFetchZone.mockResolvedValue([]);
    mockFetchAIS.mockResolvedValue([makeAISGap('g1', '2024-01-05T00:00:00Z')]);
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.events).toHaveLength(2);
    expect(result.current.events[0].category).toBe('port');
    expect(result.current.events[1].category).toBe('ais_gap');
  });

  it('sorts events newest-first', async () => {
    mockFetchPort.mockResolvedValue([
      makePortEvent('p1', '2024-01-01T00:00:00Z'),
      makePortEvent('p2', '2024-01-20T00:00:00Z'),
    ]);
    mockFetchZone.mockResolvedValue([]);
    mockFetchAIS.mockResolvedValue([]);
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    const times = result.current.events.map((e) => e.startTime);
    expect(times[0] > times[1]).toBe(true);
  });

  it('still returns fulfilled results when some services reject', async () => {
    mockFetchPort.mockResolvedValue([
      makePortEvent('p1', '2024-01-10T00:00:00Z'),
    ]);
    mockFetchZone.mockRejectedValue(new Error('zone failed'));
    mockFetchAIS.mockRejectedValue(new Error('ais failed'));
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.events).toHaveLength(1);
    expect(result.current.events[0].category).toBe('port');
  });

  it('does not update state after unmount (cancellation guard)', async () => {
    let resolvePromise!: () => void;
    mockFetchPort.mockReturnValue(
      new Promise<[]>((res) => {
        resolvePromise = () => res([]);
      }),
    );
    mockFetchZone.mockResolvedValue([]);
    mockFetchAIS.mockResolvedValue([]);
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { unmount, result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    unmount();

    // Resolve inside act so the Promise.allSettled chain drains within
    // an act boundary — cancellation guard prevents any setState calls
    await act(async () => {
      resolvePromise();
    });

    expect(result.current.events).toEqual([]);
  });

  it('sets error and returns no events when all services reject', async () => {
    const err = new Error('network error');
    mockFetchPort.mockRejectedValue(err);
    mockFetchZone.mockRejectedValue(err);
    mockFetchAIS.mockRejectedValue(err);
    mockFetchSTS.mockRejectedValue(err);
    mockFetchDisc.mockRejectedValue(err);
    mockFetchPSC.mockRejectedValue(err);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.events).toEqual([]);
    expect(result.current.error).toBeTruthy();
    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'Failed to load vessel activity data.',
      5000,
    );
  });

  it('assigns correct id prefixes per category', async () => {
    mockFetchPort.mockResolvedValue([
      makePortEvent('123', '2024-01-10T00:00:00Z'),
    ]);
    mockFetchZone.mockResolvedValue([
      makePortEvent('456', '2024-01-09T00:00:00Z'),
    ]);
    mockFetchAIS.mockResolvedValue([makeAISGap('789', '2024-01-08T00:00:00Z')]);
    mockFetchSTS.mockResolvedValue([]);
    mockFetchDisc.mockResolvedValue([]);
    mockFetchPSC.mockResolvedValue([]);

    const { result } = renderHook(() =>
      useVesselActivity('IMO1234567', DATE_RANGE),
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    const ids = result.current.events.map((e) => e.id);
    expect(ids.some((id) => id.startsWith('port-'))).toBe(true);
    expect(ids.some((id) => id.startsWith('zone-'))).toBe(true);
    expect(ids.some((id) => id.startsWith('ais_gap-'))).toBe(true);
  });
});
