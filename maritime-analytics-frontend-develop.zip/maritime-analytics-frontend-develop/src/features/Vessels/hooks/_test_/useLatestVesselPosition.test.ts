import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useLatestVesselPosition } from '@/features/Vessels/hooks/useLatestVesselPosition';

/* ─── mocks ─────────────────────────────────────────────────────────────────── */

const mockFetch = vi.fn();

const mockShowToast = vi.fn();
vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

vi.mock('@/features/Vessels/services/vesselPositionService', () => ({
  fetchLatestVesselPosition: (...a: unknown[]) => mockFetch(...a),
}));

const SAMPLE_POSITION = {
  timestamp: '2024-01-01T12:00:00Z',
  latitude: 51.5,
  longitude: -0.1,
  speed: 5,
  heading: 90,
  destination: 'ROTTERDAM',
  eta: '2024-01-05T08:00:00Z',
};

beforeEach(() => {
  vi.clearAllMocks();
});

/* ─── tests ─────────────────────────────────────────────────────────────────── */

describe('useLatestVesselPosition', () => {
  it('starts in loading state when imo is provided', () => {
    mockFetch.mockResolvedValue(SAMPLE_POSITION);
    const { result, unmount } = renderHook(() =>
      useLatestVesselPosition('IMO1234567'),
    );
    expect(result.current.loading).toBe(true);
    expect(result.current.position).toBeNull();
    unmount(); // cancel in-flight effect before test exits to avoid act() warning
  });

  it('returns position after fetch resolves', async () => {
    mockFetch.mockResolvedValue(SAMPLE_POSITION);
    const { result } = renderHook(() => useLatestVesselPosition('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.position).toEqual(SAMPLE_POSITION);
    expect(result.current.error).toBeNull();
  });

  it('returns null position and loading=false when imo is empty', async () => {
    const { result } = renderHook(() => useLatestVesselPosition(''));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.position).toBeNull();
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it('clears stale position when imo changes to empty', async () => {
    mockFetch.mockResolvedValue(SAMPLE_POSITION);
    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useLatestVesselPosition(imo),
      { initialProps: { imo: 'IMO1234567' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.position).toEqual(SAMPLE_POSITION);

    act(() => {
      rerender({ imo: '' });
    });

    expect(result.current.position).toBeNull();
    expect(result.current.loading).toBe(false);
  });

  it('clears stale position when imo changes to a new vessel', async () => {
    mockFetch.mockResolvedValue(SAMPLE_POSITION);
    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useLatestVesselPosition(imo),
      { initialProps: { imo: 'IMO1111111' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    const newPosition = { ...SAMPLE_POSITION, destination: 'HAMBURG' };
    mockFetch.mockResolvedValue(newPosition);

    act(() => {
      rerender({ imo: 'IMO2222222' });
    });

    // During fetch for new IMO, stale position should be cleared
    expect(result.current.position).toBeNull();

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.position?.destination).toBe('HAMBURG');
  });

  it('sets error, stops loading, and shows toast on fetch failure', async () => {
    mockFetch.mockRejectedValue(new Error('network error'));
    const { result } = renderHook(() => useLatestVesselPosition('IMO1234567'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error).toBeTruthy();
    expect(result.current.position).toBeNull();
    expect(mockShowToast).toHaveBeenCalledWith('error', 'network error', 5000);
  });
});
