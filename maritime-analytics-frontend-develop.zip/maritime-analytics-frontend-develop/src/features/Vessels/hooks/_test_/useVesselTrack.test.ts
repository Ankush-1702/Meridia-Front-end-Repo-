import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useVesselTrack } from '@/features/Vessels/hooks/useVesselTrack';

const mockFetchVesselTrack = vi.fn();
const mockShowToast = vi.fn();

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({ showToast: mockShowToast }),
}));

vi.mock('@/features/Vessels/services/vesselTrackService', () => ({
  fetchVesselTrack: (...args: unknown[]) => mockFetchVesselTrack(...args),
}));

const SAMPLE_POSITIONS = [
  {
    mmsi: 1,
    timestamp: '2024-01-01T00:00:00Z',
    latitude: 0,
    longitude: 0,
    speed: 0,
    course: 0,
    heading: 0,
    status: null,
  },
  {
    mmsi: 1,
    timestamp: '2024-01-01T01:00:00Z',
    latitude: 1,
    longitude: 1,
    speed: 5,
    course: 45,
    heading: 45,
    status: null,
  },
];

const FROM = new Date('2024-01-01T00:00:00Z');
const TO = new Date('2024-01-01T12:00:00Z');

beforeEach(() => {
  vi.clearAllMocks();
});

describe('useVesselTrack', () => {
  it('starts in loading state when imo is provided', async () => {
    // Use a promise we control so we can assert the loading state
    // before it resolves, then drain it at the end to avoid warnings
    let resolveTrack!: (v: typeof SAMPLE_POSITIONS) => void;
    const deferred = new Promise<typeof SAMPLE_POSITIONS>(
      (res) => (resolveTrack = res),
    );
    mockFetchVesselTrack.mockReturnValue(deferred);

    const { result } = renderHook(() => useVesselTrack('IMO1234567', FROM, TO));

    // Still in the synchronous render — loading should be true immediately
    expect(result.current.loading).toBe(true);
    expect(result.current.positions).toEqual([]);

    // Drain the deferred promise so no state update leaks after the test
    await act(async () => {
      resolveTrack(SAMPLE_POSITIONS);
    });
  });

  it('returns positions and posArrays after fetch resolves', async () => {
    mockFetchVesselTrack.mockResolvedValue(SAMPLE_POSITIONS);

    const { result } = renderHook(() => useVesselTrack('IMO1234567', FROM, TO));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.positions).toHaveLength(2);
    expect(result.current.posArrays.latitudes).toEqual([0, 1]);
    expect(result.current.posArrays.longitudes).toEqual([0, 1]);
  });

  it('returns empty arrays and stops loading when imo is empty', async () => {
    const { result } = renderHook(() => useVesselTrack('', FROM, TO));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.positions).toEqual([]);
    expect(mockFetchVesselTrack).not.toHaveBeenCalled();
  });

  it('returns empty positions, stops loading, and shows toast on fetch error', async () => {
    mockFetchVesselTrack.mockRejectedValue(new Error('network error'));

    const { result } = renderHook(() => useVesselTrack('IMO1234567', FROM, TO));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.positions).toEqual([]);
    expect(result.current.posArrays.timestampMs).toHaveLength(0);
    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'Failed to load vessel track',
      5000,
    );
  });

  it('re-fetches when imo changes', async () => {
    mockFetchVesselTrack.mockResolvedValue(SAMPLE_POSITIONS);

    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useVesselTrack(imo, FROM, TO),
      { initialProps: { imo: 'IMO0000001' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(mockFetchVesselTrack).toHaveBeenCalledTimes(1);

    // async act so the new useEffect (fetch) is fully drained
    await act(async () => {
      rerender({ imo: 'IMO0000002' });
    });

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(mockFetchVesselTrack).toHaveBeenCalledTimes(2);
  });

  it('clears stale positions when imo changes to empty', async () => {
    mockFetchVesselTrack.mockResolvedValue(SAMPLE_POSITIONS);

    const { result, rerender } = renderHook(
      ({ imo }: { imo: string }) => useVesselTrack(imo, FROM, TO),
      { initialProps: { imo: 'IMO1234567' } },
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.positions).toHaveLength(2);

    await act(async () => {
      rerender({ imo: '' });
    });

    expect(result.current.positions).toEqual([]);
    expect(result.current.loading).toBe(false);
  });

  it('builds empty posArrays when positions array is empty', async () => {
    mockFetchVesselTrack.mockResolvedValue([]);

    const { result } = renderHook(() => useVesselTrack('IMO1234567', FROM, TO));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.posArrays.timestampMs).toHaveLength(0);
    expect(result.current.posArrays.latitudes).toHaveLength(0);
  });
});
