import type { IMessage } from '@stomp/stompjs';
import { renderHook, act, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  __resetPtracConnectionsForTests,
  usePtracScreening,
} from '@/features/Vessels/hooks/usePtracScreening';
import { usePtracScreeningStore } from '@/features/Vessels/store/usePtracScreeningStore';

const {
  subscribeMock,
  activateMock,
  deactivateMock,
  getOnMessage,
  triggerConnect,
  getOnStompError,
  mockRequestPtracScreening,
} = vi.hoisted(() => {
  let onConnect: (() => void) | undefined;
  let onStompError:
    | ((frame: { headers: Record<string, string> }) => void)
    | undefined;
  let onMessage: ((msg: IMessage) => void) | undefined;

  return {
    subscribeMock: vi.fn((_dest: string, cb: (msg: IMessage) => void) => {
      onMessage = cb;
    }),
    activateMock: vi.fn(() => {
      onConnect?.();
    }),
    deactivateMock: vi.fn(),
    triggerConnect: (
      cb: () => void,
      errCb: (frame: { headers: Record<string, string> }) => void,
    ) => {
      onConnect = cb;
      onStompError = errCb;
    },
    getOnMessage: () => onMessage,
    getOnStompError: () => onStompError,
    mockRequestPtracScreening: vi.fn(),
  };
});

vi.mock('@stomp/stompjs', () => {
  class MockClient {
    active = true;
    subscribe = subscribeMock;
    activate = activateMock;
    deactivate = deactivateMock;

    constructor(config: {
      webSocketFactory?: () => unknown;
      onConnect: () => void;
      onStompError: (frame: { headers: Record<string, string> }) => void;
    }) {
      triggerConnect(config.onConnect, config.onStompError);
    }
  }

  return { Client: MockClient };
});

vi.mock('sockjs-client', () => ({
  default: vi.fn(() => ({})),
}));

vi.mock('@/app/config/config', () => ({
  API_BASE_URL: 'http://localhost:8080/v1',
  API_GATEWAY_BASE_URL: 'http://localhost:8080/v1',
}));

vi.mock('@/features/Vessels/services/ptracService', () => ({
  requestPtracScreening: (...a: unknown[]) => mockRequestPtracScreening(...a),
}));

const IMO = 'IMO1234567';

function requestResult(
  overrides: Partial<{ subscribe_destination: string }> = {},
) {
  return {
    correlation_id: 'corr-1',
    websocket_url: '/ws?userId=user-1',
    subscribe_destination: '/user/topic/screening-result',
    ...overrides,
  };
}

beforeEach(() => {
  __resetPtracConnectionsForTests();
  vi.clearAllMocks();
  usePtracScreeningStore.setState({ sessions: {} });
});

describe('usePtracScreening', () => {
  it('starts in loading state when imo is provided', () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { result, unmount } = renderHook(() => usePtracScreening(IMO));
    expect(result.current.loading).toBe(true);
    expect(result.current.status).toBeNull();
    expect(result.current.error).toBeNull();
    unmount();
  });

  it('returns null status and loading=false when imo is empty', async () => {
    const { result } = renderHook(() => usePtracScreening(''));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.status).toBeNull();
    expect(result.current.error).toBeNull();
    expect(mockRequestPtracScreening).not.toHaveBeenCalled();
  });

  it('opens websocket immediately after hook creation', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(activateMock).toHaveBeenCalled());
    expect(activateMock).toHaveBeenCalledTimes(1);
  });

  it('subscribes to screening-result topic', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    renderHook(() => usePtracScreening(IMO));

    await waitFor(() =>
      expect(subscribeMock).toHaveBeenCalledWith(
        '/user/topic/screening-result',
        expect.any(Function),
      ),
    );
  });

  it('makes API call after websocket is connected', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(subscribeMock).toHaveBeenCalled());

    await waitFor(() =>
      expect(mockRequestPtracScreening).toHaveBeenCalledTimes(1),
    );
  });

  it('sends correlation_id and imo_number in the request body', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    renderHook(() => usePtracScreening(IMO));

    await waitFor(() =>
      expect(mockRequestPtracScreening).toHaveBeenCalledWith(
        IMO,
        expect.any(String),
      ),
    );

    const callArgs = mockRequestPtracScreening.mock.calls[0];
    expect(callArgs[0]).toBe(IMO);
    expect(typeof callArgs[1]).toBe('string');
  });

  it('sets error when the initial REST request fails', async () => {
    mockRequestPtracScreening.mockRejectedValue(new Error('network error'));
    const { result } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error?.message).toBe('network error');
    expect(result.current.status).toBeNull();
  });

  it('sets error when the STOMP connection reports a broker error', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { result } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(subscribeMock).toHaveBeenCalled());

    act(() => {
      getOnStompError()?.({ headers: { message: 'broker down' } });
    });

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error?.message).toContain('broker');
  });

  it('requests a fresh screening when retry is called', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { result } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() =>
      expect(mockRequestPtracScreening).toHaveBeenCalledTimes(1),
    );

    act(() => {
      result.current.retry();
    });

    await waitFor(() =>
      expect(mockRequestPtracScreening).toHaveBeenCalledTimes(2),
    );
  });

  it('deactivates the STOMP client once the result is received', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { result } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(subscribeMock).toHaveBeenCalled());

    act(() => {
      getOnMessage()?.({
        body: JSON.stringify({ imo_number: IMO, screening_status: 'OK' }),
        headers: {},
      } as IMessage);
    });

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(deactivateMock).toHaveBeenCalled();
  });

  it('does not fire a duplicate request when reopened while still loading', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { rerender } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(subscribeMock).toHaveBeenCalled());

    rerender();

    expect(mockRequestPtracScreening).toHaveBeenCalledTimes(1);
  });

  it('does not deactivate the STOMP client when unmounted while still loading', async () => {
    mockRequestPtracScreening.mockResolvedValue(requestResult());
    const { unmount } = renderHook(() => usePtracScreening(IMO));

    await waitFor(() => expect(subscribeMock).toHaveBeenCalled());

    unmount();

    expect(deactivateMock).not.toHaveBeenCalled();
  });
});
