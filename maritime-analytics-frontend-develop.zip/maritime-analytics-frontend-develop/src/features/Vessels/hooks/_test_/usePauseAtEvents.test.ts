import { renderHook } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { usePauseAtEvents } from '@/features/Vessels/hooks/usePauseAtEvents';
import type { DateRange } from '@/features/Vessels/store/useVesselActivityStore';
import type { ActivityEvent } from '@/features/Vessels/types/vesselActivityTypes';

/* ─── store mock ─────────────────────────────────────────────────────────────── */

const mockGetState = vi.fn();

vi.mock('@/features/Vessels/store/useVesselActivityStore', () => ({
  useVesselActivityStore: Object.assign(
    // selector form — not used by the hook directly, but required for module shape
    vi.fn(),
    { getState: (...args: unknown[]) => mockGetState(...args) },
  ),
}));

/* ─── helpers ────────────────────────────────────────────────────────────────── */

function makeEvent(
  id: string,
  startTime: string,
  category: ActivityEvent['category'] = 'port',
): ActivityEvent {
  return {
    id,
    category,
    subType: '',
    startTime,
    endTime: null,
    latitude: null,
    longitude: null,
    label: id,
    raw: null,
  };
}

function buildStoreState(
  overrides: Partial<ReturnType<typeof defaultStoreState>> = {},
) {
  return { ...defaultStoreState(), ...overrides };
}

function defaultStoreState() {
  return {
    isReplaying: true,
    replayAt: new Date('2024-01-10T12:00:00Z'),
    pauseAtEvents: true,
    isScrubbing: false,
    replayAnnouncedEvent: null as ActivityEvent[] | null,
    replayCountdownPaused: false,
    filters: {
      port_arrival: true,
      port_departure: true,
      zone_entry: true,
      zone_exit: true,
      ais_gap: true,
      sts: true,
      discrepancy: true,
      psc: true,
    },
    announcedEventIds: new Set<string>(),
    markEventsAnnounced: vi.fn(),
    pauseReplay: vi.fn(),
    startReplay: vi.fn(),
    setReplayAnnouncedEvent: vi.fn(),
  };
}

const DATE_RANGE: DateRange = {
  from: new Date('2024-01-01T00:00:00Z'),
  to: new Date('2024-01-31T00:00:00Z'),
};

/* ─── tests ──────────────────────────────────────────────────────────────────── */

beforeEach(() => {
  vi.useFakeTimers();
  vi.clearAllMocks();
});

afterEach(() => {
  vi.useRealTimers();
});

describe('usePauseAtEvents', () => {
  it('does nothing when pauseAtEvents is false', () => {
    const state = buildStoreState({ pauseAtEvents: false });
    mockGetState.mockReturnValue(state);

    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(200);

    expect(state.pauseReplay).not.toHaveBeenCalled();
    expect(state.setReplayAnnouncedEvent).not.toHaveBeenCalled();
  });

  it('does nothing when isReplaying is false', () => {
    const state = buildStoreState({ isReplaying: false });
    mockGetState.mockReturnValue(state);

    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(200);

    expect(state.pauseReplay).not.toHaveBeenCalled();
    expect(state.setReplayAnnouncedEvent).not.toHaveBeenCalled();
  });

  it('pauses replay and announces events when cursor crosses an event', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    // replayAt is after event.startTime, so the event has been "crossed"
    const state = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
    });
    mockGetState.mockReturnValue(state);

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    // Advance one tick (TICK_MS = 100ms)
    vi.advanceTimersByTime(100);

    expect(state.markEventsAnnounced).toHaveBeenCalledWith(['e1']);
    expect(state.pauseReplay).toHaveBeenCalledTimes(1);
    expect(state.setReplayAnnouncedEvent).toHaveBeenCalledWith([event]);
  });

  it('does not announce an event that is already in announcedEventIds', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    const state = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
      announcedEventIds: new Set(['e1']),
    });
    mockGetState.mockReturnValue(state);

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(200);

    expect(state.pauseReplay).not.toHaveBeenCalled();
  });

  it('auto-resumes after countdown (4500ms)', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    const state = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
    });
    // After the first tick, replayAnnouncedEvent will be set; subsequent ticks
    // need to return it as non-null so the countdown continues.
    const announcedEvent = [event];
    mockGetState.mockImplementation(() => ({
      ...state,
      replayAnnouncedEvent: announcedEvent,
    }));

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    // First tick: event detected, countdown starts
    vi.advanceTimersByTime(100);
    expect(state.pauseReplay).toHaveBeenCalledTimes(1);

    // Advance through countdown (4500ms = 45 ticks of 100ms each)
    vi.advanceTimersByTime(4500);

    expect(state.setReplayAnnouncedEvent).toHaveBeenLastCalledWith(null);
    expect(state.startReplay).toHaveBeenCalledWith(DATE_RANGE);
  });

  it('aborts countdown when replayAnnouncedEvent is set to null', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    const stateWithEvent = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
    });

    // Phase 1: event present
    mockGetState.mockReturnValue({
      ...stateWithEvent,
      replayAnnouncedEvent: [event],
    });

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(100); // first tick — event detected

    // Phase 2: user dismisses the card (replayAnnouncedEvent → null)
    mockGetState.mockReturnValue({
      ...stateWithEvent,
      replayAnnouncedEvent: null,
    });

    // Advance additional time — countdown should abort, startReplay not called
    vi.advanceTimersByTime(4500);

    expect(stateWithEvent.startReplay).not.toHaveBeenCalled();
  });

  it('replayCountdownPaused prevents countdown from advancing', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z');
    const announcedEvent = [event];

    const state = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
    });

    // All subsequent getState calls see countdown paused
    mockGetState.mockReturnValue({
      ...state,
      replayAnnouncedEvent: announcedEvent,
      replayCountdownPaused: true,
    });

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(100); // trigger first tick to start countdown

    // Advance well past PAUSE_DURATION_MS without unpausing
    vi.advanceTimersByTime(10000);

    // Auto-resume must not have been called
    expect(state.startReplay).not.toHaveBeenCalled();
  });

  it('does not announce events whose category is filtered out', () => {
    const event = makeEvent('e1', '2024-01-10T11:00:00Z', 'zone');
    const state = buildStoreState({
      replayAt: new Date('2024-01-10T12:00:00Z'),
      filters: {
        port_arrival: true,
        port_departure: true,
        zone_entry: true,
        zone_exit: false, // zone_exit filtered out
        ais_gap: true,
        sts: true,
        discrepancy: true,
        psc: true,
      },
    });
    mockGetState.mockReturnValue(state);

    renderHook(() => usePauseAtEvents([event], DATE_RANGE));

    vi.advanceTimersByTime(200);

    expect(state.pauseReplay).not.toHaveBeenCalled();
  });

  it('cleans up the interval on unmount', () => {
    const clearIntervalSpy = vi.spyOn(globalThis, 'clearInterval');
    const state = buildStoreState({ isReplaying: false });
    mockGetState.mockReturnValue(state);

    const { unmount } = renderHook(() => usePauseAtEvents([], DATE_RANGE));

    unmount();

    expect(clearIntervalSpy).toHaveBeenCalled();
  });
});
