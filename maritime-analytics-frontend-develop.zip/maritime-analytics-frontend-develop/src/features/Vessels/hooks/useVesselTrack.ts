import { useEffect, useMemo, useState } from 'react';
import {
  fetchVesselTrack,
  VesselPosition,
} from '@/features/Vessels/services/vesselTrackService';
import {
  buildPositionArrays,
  PositionArrays,
} from '@/features/Vessels/utils/replayPositionUtils';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';

const EMPTY_ARRAYS: PositionArrays = {
  timestampMs: [],
  latitudes: [],
  longitudes: [],
  cogs: [],
};

interface State {
  positions: VesselPosition[];
  posArrays: PositionArrays;
  loading: boolean;
}

export function useVesselTrack(imo: string, from: Date, to: Date): State {
  const [positions, setPositions] = useState<VesselPosition[]>([]);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToastNotification();

  const fromMs = from.getTime();
  const toMs = to.getTime();

  useEffect(() => {
    if (!imo) {
      setPositions([]);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    fetchVesselTrack(imo, new Date(fromMs), new Date(toMs))
      .then((pos) => {
        if (!cancelled) setPositions(pos);
      })
      .catch(() => {
        if (!cancelled) {
          setPositions([]);
          showToast('error', 'Failed to load vessel track', 5000);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [imo, fromMs, toMs, showToast]);

  const posArrays = useMemo(
    () =>
      positions.length > 0 ? buildPositionArrays(positions) : EMPTY_ARRAYS,
    [positions],
  );

  return { positions, posArrays, loading };
}
