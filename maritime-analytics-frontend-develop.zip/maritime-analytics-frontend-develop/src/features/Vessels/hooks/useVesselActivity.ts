import { useEffect, useState } from 'react';
import {
  fetchAISGapsForMap,
  fetchDiscrepanciesForMap,
  fetchPortCallsForMap,
  fetchPSCForMap,
  fetchSTSForMap,
  fetchZoneEventsForMap,
} from '@/features/Vessels/services/vesselActivityServices';
import {
  ActivityEvent,
  ActivityEventCategory,
} from '@/features/Vessels/types/vesselActivityTypes';
import {
  flattenedVesselAISGaps,
  flattenedVesselPortAndZone,
  flattenedVesselPortStateControl,
  flattenedVesselPositionalDiscrepancies,
  flattenedVesselSTSEvents,
} from '@/features/Vessels/types/vesselTypes';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { DateRange } from '@/shared/types/entities';

function toISODate(date: string, endOfDay = false): string {
  if (date.includes('T')) return date;
  return endOfDay ? `${date}T23:59:59Z` : `${date}T00:00:00Z`;
}

function normalizePortZone(
  events: flattenedVesselPortAndZone[],
  category: ActivityEventCategory,
): ActivityEvent[] {
  return events.map((e, i) => ({
    id: `${category}-${e.event_details?.event_id || i}`,
    category,
    subType: e.event_details?.event_type ?? '',
    startTime: e.event_details?.event_timestamp ?? '',
    endTime: null,
    latitude: e.event_details?.latitude ?? null,
    longitude: e.event_details?.longitude ?? null,
    label: e.zone_information?.name ?? e.event_details?.event_type ?? '',
    raw: e,
  }));
}

function normalizeAISGaps(events: flattenedVesselAISGaps[]): ActivityEvent[] {
  return events.map((e, i) => ({
    id: `ais_gap-${e.event_id || i}`,
    category: 'ais_gap' as ActivityEventCategory,
    subType: 'AIS_GAP',
    startTime: e.stopped?.timestamp ?? '',
    endTime: e.resumed?.timestamp ?? null,
    latitude: e.stopped?.latitude ?? null,
    longitude: e.stopped?.longitude ?? null,
    label: `AIS Gap (${e.gap_duration_hours?.toFixed(1) ?? '?'}h)`,
    raw: e,
  }));
}

function normalizeSTS(events: flattenedVesselSTSEvents[]): ActivityEvent[] {
  return events.map((e, i) => ({
    id: `sts-${e.started ?? i}-${e.sts_type ?? ''}-${e.paired_vessel?.imo ?? i}`,
    category: 'sts' as ActivityEventCategory,
    subType: e.sts_type ?? 'UNKNOWN',
    startTime: e.started ?? '',
    endTime: e.stopped ?? null,
    latitude: e.location?.latitude ?? null,
    longitude: e.location?.longitude ?? null,
    label: `STS (${e.sts_type ?? 'Unknown'})`,
    raw: e,
  }));
}

function normalizeDiscrepancies(
  events: flattenedVesselPositionalDiscrepancies[],
): ActivityEvent[] {
  return events.map((e, i) => ({
    id: `discrepancy-${e.event_type ?? i}-${e.started?.timestamp ?? i}`,
    category: 'discrepancy' as ActivityEventCategory,
    subType: e.event_type ?? '',
    startTime: e.started?.timestamp ?? '',
    endTime: e.stopped?.timestamp ?? null,
    latitude: e.started?.latitude ?? null,
    longitude: e.started?.longitude ?? null,
    label: `${e.event_type ?? 'Discrepancy'} (${e.duration_hours?.toFixed(1) ?? '?'}h)`,
    raw: e,
  }));
}

function normalizePSC(
  events: flattenedVesselPortStateControl[],
): ActivityEvent[] {
  return events.map((e, i) => ({
    id: `psc-${e.inspection_date ?? i}-${e.authority ?? e.port_information?.name ?? i}`,
    category: 'psc' as ActivityEventCategory,
    subType: e.inspection_type ?? 'PSC',
    startTime: e.inspection_date ?? '',
    endTime: null,
    latitude: null,
    longitude: null,
    label: `PSC – ${e.port_information?.name ?? e.authority ?? ''}`,
    raw: e,
  }));
}

export interface VesselActivityResult {
  events: ActivityEvent[];
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useVesselActivity(
  imo: string,
  dateRange: DateRange,
): VesselActivityResult {
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const { showToast } = useToastNotification();

  useEffect(() => {
    if (!imo || !dateRange.start || !dateRange.end) {
      setEvents([]);
      setError(null);
      setLoading(false);
      return;
    }

    const start = toISODate(dateRange.start);
    const end = toISODate(dateRange.end, true);

    setLoading(true);
    setError(null);

    let cancelled = false;

    Promise.allSettled([
      fetchPortCallsForMap(imo, start, end),
      fetchZoneEventsForMap(imo, start, end),
      fetchAISGapsForMap(imo, start, end),
      fetchSTSForMap(imo, start, end),
      fetchDiscrepanciesForMap(imo, start, end),
      fetchPSCForMap(imo, start, end),
    ]).then(
      ([
        portResult,
        zoneResult,
        aisResult,
        stsResult,
        discResult,
        pscResult,
      ]) => {
        if (cancelled) return;

        const results = [
          portResult,
          zoneResult,
          aisResult,
          stsResult,
          discResult,
          pscResult,
        ];
        const allFailed = results.every((r) => r.status === 'rejected');
        if (allFailed) {
          const msg = 'Failed to load vessel activity data.';
          setError(msg);
          setLoading(false);
          showToast('error', msg, 5000);
          return;
        }

        const all: ActivityEvent[] = [];

        if (portResult.status === 'fulfilled')
          all.push(...normalizePortZone(portResult.value, 'port'));
        if (zoneResult.status === 'fulfilled')
          all.push(...normalizePortZone(zoneResult.value, 'zone'));
        if (aisResult.status === 'fulfilled')
          all.push(...normalizeAISGaps(aisResult.value));
        if (stsResult.status === 'fulfilled')
          all.push(...normalizeSTS(stsResult.value));
        if (discResult.status === 'fulfilled')
          all.push(...normalizeDiscrepancies(discResult.value));
        if (pscResult.status === 'fulfilled')
          all.push(...normalizePSC(pscResult.value));

        all.sort(
          (a, b) =>
            new Date(b.startTime).getTime() - new Date(a.startTime).getTime(),
        );

        setEvents(all);
        setLoading(false);
      },
    );

    return () => {
      cancelled = true;
    };
  }, [imo, dateRange.start, dateRange.end, tick, showToast]);

  return {
    events,
    loading,
    error,
    refetch: () => setTick((t) => t + 1),
  };
}
