import { Client, IMessage } from '@stomp/stompjs';
import { useCallback, useEffect } from 'react';
import SockJS from 'sockjs-client';
import { API_BASE_URL } from '@/app/config/config';
import { requestPtracScreening } from '@/features/Vessels/services/ptracService';
import {
  EMPTY_PTRAC_SNAPSHOT,
  usePtracScreeningStore,
} from '@/features/Vessels/store/usePtracScreeningStore';
import {
  PtracOverallStatus,
  PtracScreeningMessage,
} from '@/features/Vessels/types/ptracTypes';

const RESULT_TIMEOUT_MS = 160_000;

interface PtracConnection {
  stompClient: Client | null;
  timeoutId: ReturnType<typeof setTimeout> | null;
}

interface UsePtracScreeningResult {
  status: PtracOverallStatus | null;
  loading: boolean;
  error: Error | null;
  startedAt: number | null;
  retry: () => void;
}

// Keyed by IMO so the live STOMP client/timeout survive the requesting
// component unmounting (e.g. collapsing the accordion section). The
// reactive status itself lives in usePtracScreeningStore; this map only
// holds the non-serializable connection handles.
const connections = new Map<string, PtracConnection>();

function teardownConnection(imo: string) {
  const connection = connections.get(imo);
  if (!connection) return;
  if (connection.timeoutId) clearTimeout(connection.timeoutId);
  if (connection.stompClient?.active) connection.stompClient.deactivate();
  connections.delete(imo);
}

// Test-only: tears down and clears every tracked connection. Needed because
// `connections` is a module-level map — tests that intentionally leave a
// screening "in flight" would otherwise leak a live connection into the
// next test's run.
export function __resetPtracConnectionsForTests() {
  for (const imo of Array.from(connections.keys())) {
    teardownConnection(imo);
  }
}

function generateCorrelationId(): string {
  return crypto.randomUUID();
}

function startSession(imo: string) {
  teardownConnection(imo);

  const { setSnapshot } = usePtracScreeningStore.getState();
  const connection: PtracConnection = { stompClient: null, timeoutId: null };
  const correlationId = generateCorrelationId();
  connections.set(imo, connection);
  setSnapshot(imo, {
    status: null,
    loading: true,
    error: null,
    startedAt: Date.now(),
    correlationId,
  });

  const fail = (err: unknown) => {
    teardownConnection(imo);
    setSnapshot(imo, {
      error: err instanceof Error ? err : new Error(String(err)),
      status: null,
      loading: false,
      startedAt: null,
      correlationId: null,
    });
  };

  if (!API_BASE_URL) {
    fail(new Error('API configuration is missing'));
    return;
  }

  const subscribeDestination = '/user/topic/screening-result';
  const sockJsUrl = `${API_BASE_URL.replace(/\/v1$/, '/ws')}?correlationId=${correlationId}`;

  const stompClient = new Client({
    webSocketFactory: () => new SockJS(sockJsUrl),
    reconnectDelay: 5000,
    debug: () => {},
    onConnect: () => {
      if (connections.get(imo) !== connection) return;

      stompClient.subscribe(subscribeDestination, (message: IMessage) => {
        if (connections.get(imo) !== connection) return;

        try {
          const payload = JSON.parse(message.body) as PtracScreeningMessage;

          if (!payload.correlation_id) {
            fail(new Error('Screening result missing correlation_id'));
            return;
          }

          if (payload.correlation_id !== correlationId) {
            return;
          }

          teardownConnection(imo);

          if (payload.screening_status != null) {
            setSnapshot(imo, {
              status: payload.screening_status,
              loading: false,
              startedAt: null,
              correlationId: null,
            });
          } else {
            fail(new Error('PurpleTRAC screening failed'));
          }
        } catch {
          fail(new Error('Failed to process screening result'));
        }
      });

      if (connections.get(imo) !== connection) return;

      requestPtracScreening(imo, correlationId).catch(fail);
    },
    onDisconnect: () => {},
    onStompError: (frame) => {
      const errorMsg = frame.headers['message'] || 'STOMP connection error';
      fail(new Error(errorMsg));
    },
  });

  connection.stompClient = stompClient;
  connection.timeoutId = setTimeout(() => {
    fail(new Error('Timed out waiting for PurpleTRAC screening result'));
  }, RESULT_TIMEOUT_MS);

  stompClient.activate();
}

function ensureSessionStarted(imo: string) {
  const { sessions } = usePtracScreeningStore.getState();
  if (sessions[imo]?.loading) return;
  startSession(imo);
}

export function usePtracScreening(imo: string): UsePtracScreeningResult {
  const snapshot = usePtracScreeningStore((state) =>
    imo ? (state.sessions[imo] ?? EMPTY_PTRAC_SNAPSHOT) : EMPTY_PTRAC_SNAPSHOT,
  );

  useEffect(() => {
    if (!imo) return;
    ensureSessionStarted(imo);
    // No cleanup — the screening request must keep running after this
    // component unmounts; `connections` (module-level) owns the STOMP
    // client's lifecycle independent of any component instance.
  }, [imo]);

  const retry = useCallback(() => {
    if (!imo) return;
    startSession(imo);
  }, [imo]);

  return { ...snapshot, retry };
}
