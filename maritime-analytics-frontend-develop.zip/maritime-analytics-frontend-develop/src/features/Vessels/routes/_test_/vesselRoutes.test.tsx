import React from 'react';
import { describe, it, expect } from 'vitest';
import { vesselRoutes } from '@/features/Vessels/routes/vesselRoutes';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

describe('vesselRoutes', () => {
  it('defines vessel details route correctly', () => {
    expect(vesselRoutes).toHaveLength(1);

    const route = vesselRoutes[0];

    expect(route.path).toBe('/analytics/vessel/:id');
    expect(React.isValidElement(route.element)).toBe(true);
    expect(route.element.type).toBe(SuspenseWrapper);

    const child = route.element.props.children;
    expect(child.type.$$typeof).toBe(Symbol.for('react.lazy'));
  });
});
