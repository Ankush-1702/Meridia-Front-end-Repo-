import { lazy } from 'react';
import SuspenseWrapper from '@/shared/lib/SuspenseWrapper';

const VesselDetailsPage = lazy(() => import('@/features/Vessels/Vessels'));

export const vesselRoutes = [
  {
    path: '/analytics/vessel/:id',
    element: (
      <SuspenseWrapper>
        <VesselDetailsPage />
      </SuspenseWrapper>
    ),
  },
];
