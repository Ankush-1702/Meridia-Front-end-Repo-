import { render, screen, waitFor } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { ThemeProvider, useTheme } from '@/app/context/ThemeProvider';

// Mock matchMedia
function mockMatchMedia(matches: boolean) {
  window.matchMedia = vi.fn().mockReturnValue({
    matches,
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
  });
}

beforeEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
  mockMatchMedia(false); // system = light
  document.documentElement.classList.remove('dark');
});

// -------------------------------
// Helpers
// -------------------------------
function TestComponent() {
  const { theme, setTheme, saveTheme } = useTheme();
  return (
    <div>
      <div data-testid="theme-value">{theme}</div>
      <button data-testid="set-theme" onClick={() => setTheme('dark')}>
        Set Theme Dark
      </button>
      <button data-testid="save-theme" onClick={() => saveTheme('dark')}>
        Save Theme Dark
      </button>
    </div>
  );
}

function renderWithProvider(ui: React.ReactNode) {
  return render(<ThemeProvider>{ui}</ThemeProvider>);
}

// -------------------------------
// Tests
// -------------------------------

describe('ThemeProvider', () => {
  it('loads theme from localStorage on init', () => {
    localStorage.setItem('theme', 'dark');

    renderWithProvider(<TestComponent />);

    expect(screen.getByTestId('theme-value').textContent).toBe('dark');
  });

  it('defaults to light if no theme in localStorage', () => {
    renderWithProvider(<TestComponent />);
    expect(screen.getByTestId('theme-value').textContent).toBe('light');
  });

  it('setTheme updates preview only and toggles dark mode class', () => {
    const dispatchSpy = vi.spyOn(document, 'dispatchEvent');

    renderWithProvider(<TestComponent />);

    screen.getByTestId('set-theme').click();

    // Preview stored
    expect(localStorage.getItem('theme-preview')).toBe('dark');

    // Dark mode applied
    expect(document.documentElement.classList.contains('dark')).toBe(true);

    // Notifies Flowbite components via sync event
    expect(dispatchSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'flowbite-theme-mode-sync',
        detail: 'dark',
      }),
    );
  });

  it('saveTheme persists theme and preview + toggles dark mode', () => {
    const dispatchSpy = vi.spyOn(document, 'dispatchEvent');

    renderWithProvider(<TestComponent />);

    screen.getByTestId('save-theme').click();

    expect(localStorage.getItem('theme')).toBe('dark');
    expect(localStorage.getItem('theme-preview')).toBe('dark');

    expect(document.documentElement.classList.contains('dark')).toBe(true);
    expect(dispatchSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'flowbite-theme-mode-sync',
        detail: 'dark',
      }),
    );
  });

  it('applies system theme when theme=system and system is dark', () => {
    mockMatchMedia(true); // system dark

    renderWithProvider(<TestComponent />);

    // set preview to system
    localStorage.setItem('theme-preview', 'system');

    // trigger effect manually
    window.dispatchEvent(
      new StorageEvent('storage', { key: 'theme-preview', newValue: 'system' }),
    );

    expect(document.documentElement.classList.contains('dark')).toBe(true);
  });

  it('responds to storage event: theme-preview changes across tabs', () => {
    const dispatchSpy = vi.spyOn(document, 'dispatchEvent');

    renderWithProvider(<TestComponent />);

    const event = new StorageEvent('storage', {
      key: 'theme-preview',
      newValue: 'dark',
    });
    window.dispatchEvent(event);

    expect(document.documentElement.classList.contains('dark')).toBe(true);
    expect(dispatchSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'flowbite-theme-mode-sync',
        detail: 'dark',
      }),
    );
  });

  it('responds to storage event: theme change updates state', async () => {
    renderWithProvider(<TestComponent />);

    const event = new StorageEvent('storage', {
      key: 'theme',
      newValue: 'dark',
    });
    window.dispatchEvent(event);

    await waitFor(() =>
      expect(screen.getByTestId('theme-value').textContent).toBe('dark'),
    );
  });

  it('throws an error when useTheme is used outside provider', () => {
    const BadComponent = () => {
      useTheme();
      return null;
    };

    expect(() => render(<BadComponent />)).toThrow(
      'useTheme must be used within a ThemeProvider',
    );
  });
});
