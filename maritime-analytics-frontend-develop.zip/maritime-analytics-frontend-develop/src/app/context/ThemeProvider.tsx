import {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';

export type Theme = 'light' | 'dark' | 'system';

interface ThemeContextValue {
  theme: Theme; // The saved theme
  setTheme: (theme: Theme) => void; // Preview only
  saveTheme: (theme: Theme) => void; // Persist to localStorage
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

// Flowbite's internal sync event — keeps useThemeMode() instances in sync
// without going through the hook (which has an unstable setMode reference).
const FLOWBITE_SYNC_EVENT = 'flowbite-theme-mode-sync';

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    return (localStorage.getItem('theme') as Theme) || 'light';
  });

  const [previewTheme, setPreviewTheme] = useState<Theme>(() => {
    return (localStorage.getItem('theme-preview') as Theme) || theme;
  });

  const applyTheme = useCallback((targetTheme: Theme) => {
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)')
      .matches
      ? 'dark'
      : 'light';
    const appliedTheme = targetTheme === 'system' ? systemTheme : targetTheme;
    document.documentElement.classList.toggle('dark', appliedTheme === 'dark');
    document.dispatchEvent(
      new CustomEvent(FLOWBITE_SYNC_EVENT, { detail: appliedTheme }),
    );
  }, []);

  const setTheme = (newTheme: Theme) => {
    setPreviewTheme(newTheme); // only preview
    localStorage.setItem('theme-preview', newTheme); // sync across tabs
    applyTheme(newTheme);
  };

  const saveTheme = (newTheme: Theme) => {
    localStorage.setItem('theme', newTheme);
    localStorage.setItem('theme-preview', newTheme);
    setThemeState(newTheme);
    setPreviewTheme(newTheme);
    applyTheme(newTheme);
  };

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const handleSystemChange = () => {
      if (previewTheme === 'system') {
        applyTheme(previewTheme);
      }
    };

    const handleStorage = (event: StorageEvent) => {
      if (event.key === 'theme-preview' && event.newValue) {
        const newPreview = event.newValue as Theme;
        setPreviewTheme(newPreview);
        applyTheme(newPreview);
      }

      if (event.key === 'theme' && event.newValue) {
        const newTheme = event.newValue as Theme;
        setThemeState(newTheme);
      }
    };

    // Avoid reapplying if not needed
    const systemTheme = mediaQuery.matches ? 'dark' : 'light';
    const effectiveTheme =
      previewTheme === 'system' ? systemTheme : previewTheme;
    const isAlreadyDark = document.documentElement.classList.contains('dark');

    if ((effectiveTheme === 'dark') !== isAlreadyDark) {
      applyTheme(previewTheme);
    }

    mediaQuery.addEventListener('change', handleSystemChange);
    window.addEventListener('storage', handleStorage);

    return () => {
      mediaQuery.removeEventListener('change', handleSystemChange);
      window.removeEventListener('storage', handleStorage);
    };
  }, [previewTheme, applyTheme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, saveTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
}
