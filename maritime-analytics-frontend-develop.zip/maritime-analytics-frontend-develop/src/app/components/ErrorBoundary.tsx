import { Component, type ErrorInfo, type ReactNode } from 'react';
import GenericError from '@/shared/components/GenericError';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ErrorBoundary]', error, errorInfo);
    // Future: send to logging service
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        this.props.fallback ?? (
          <div className="flex min-h-screen items-center justify-center bg-white dark:bg-gray-800">
            <GenericError
              errorHeading="Something went wrong"
              errorText="An unexpected error occurred. Please try reloading the page."
              action={this.handleReload}
              actionLabel="Reload"
            />
          </div>
        )
      );
    }

    return this.props.children;
  }
}
