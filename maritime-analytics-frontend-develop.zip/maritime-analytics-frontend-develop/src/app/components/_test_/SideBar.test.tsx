import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import SideBar, { SideBarProps } from '@/app/components/SideBar';

// Mock the PoleStarSidebar component
vi.mock('@/shared/lib/PoleStarSidebar', () => {
  return {
    default: ({
      title,
      logo: Logo,
      primaryItems,
      optionalItems,
      notifications,
      user,
      onSignOut,
      expanded,
      setExpanded,
    }: SideBarProps) => {
      return (
        <div data-testid="polestar-sidebar" data-expanded={expanded}>
          <div data-testid="sidebar-title">{title}</div>
          <div data-testid="sidebar-logo">{Logo && <Logo />}</div>

          <div data-testid="primary-items">
            {primaryItems?.map((item) => (
              <div key={item.label}>{item.label}</div>
            ))}
          </div>

          {optionalItems && (
            <div data-testid="optional-items">
              {optionalItems.map((item) => (
                <div key={item.label}>{item.label}</div>
              ))}
            </div>
          )}

          {notifications && (
            <div data-testid="notifications">
              {notifications.map((item) => (
                <div key={item.label}>{item.label}</div>
              ))}
            </div>
          )}

          <div data-testid="user-info">{user?.name}</div>

          <button onClick={onSignOut} data-testid="signout-btn">
            Sign out
          </button>

          <button
            onClick={() => setExpanded(!expanded)}
            data-testid="toggle-btn"
          >
            Toggle
          </button>
        </div>
      );
    },
  };
});

describe('SideBar Component', () => {
  const MockLogo = () => <div>Mock Logo</div>;

  const mockPrimaryItems = [
    { label: 'Dashboard', icon: () => <div />, href: '/dashboard' },
    { label: 'Settings', icon: () => <div />, href: '/settings' },
  ];

  const mockOptionalItems = [{ label: 'Help', icon: () => <div /> }];

  const mockNotifications = [{ label: 'Alerts', icon: () => <div /> }];

  const mockUser = { name: 'John Doe', email: 'john@example.com' };

  const defaultProps: SideBarProps = {
    title: 'Test Sidebar',
    logo: MockLogo,
    primaryItems: mockPrimaryItems,
    user: mockUser,
    onSignOut: vi.fn(),
    expanded: true,
    setExpanded: vi.fn(),
  };

  it('renders without crashing', () => {
    render(
      <SideBar
        {...defaultProps}
        optionalItems={mockOptionalItems}
        notifications={mockNotifications}
      />,
    );

    expect(screen.getByTestId('polestar-sidebar')).toBeInTheDocument();
  });

  it('passes title and logo to PoleStarSidebar', () => {
    render(<SideBar {...defaultProps} title="My Title" />);

    expect(screen.getByTestId('sidebar-title').textContent).toBe('My Title');
    expect(screen.getByText('Mock Logo')).toBeInTheDocument();
  });

  it('renders primary items', () => {
    render(<SideBar {...defaultProps} />);

    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });

  it('renders optional items when provided', () => {
    render(<SideBar {...defaultProps} optionalItems={mockOptionalItems} />);

    expect(screen.getByTestId('optional-items')).toBeInTheDocument();
    expect(screen.getByText('Help')).toBeInTheDocument();
  });

  it('renders notifications when provided', () => {
    render(<SideBar {...defaultProps} notifications={mockNotifications} />);

    expect(screen.getByTestId('notifications')).toBeInTheDocument();
    expect(screen.getByText('Alerts')).toBeInTheDocument();
  });

  it('passes user info to PoleStarSidebar', () => {
    render(<SideBar {...defaultProps} />);

    expect(screen.getByTestId('user-info').textContent).toBe('John Doe');
  });

  it('calls onSignOut when signout button is clicked', () => {
    const onSignOut = vi.fn();
    render(<SideBar {...defaultProps} onSignOut={onSignOut} />);

    screen.getByTestId('signout-btn').click();
    expect(onSignOut).toHaveBeenCalled();
  });

  it('passes expanded prop to PoleStarSidebar', () => {
    render(<SideBar {...defaultProps} expanded={true} />);
    expect(screen.getByTestId('polestar-sidebar')).toHaveAttribute(
      'data-expanded',
      'true',
    );
  });

  it('passes expanded=false to PoleStarSidebar', () => {
    render(<SideBar {...defaultProps} expanded={false} />);
    expect(screen.getByTestId('polestar-sidebar')).toHaveAttribute(
      'data-expanded',
      'false',
    );
  });

  it('calls setExpanded when toggle is clicked', () => {
    const setExpanded = vi.fn();
    render(
      <SideBar {...defaultProps} expanded={true} setExpanded={setExpanded} />,
    );

    screen.getByTestId('toggle-btn').click();
    expect(setExpanded).toHaveBeenCalledWith(false);
  });
});
