import React from 'react';
import PoleStarSidebar from '@/shared/lib/PoleStarSidebar';

export interface SideBarProps {
  title: string;
  logo: React.ElementType;
  primaryItems: {
    label: string;
    href?: string;
    icon: React.ElementType;
    show?: boolean;
    color?: string;
  }[];
  optionalItems?: {
    label: string;
    icon: React.ElementType;
    show?: boolean;
    href?: string;
    color?: string;
  }[];
  notifications?: {
    label: string;
    icon: React.ElementType;
    show?: boolean;
    href?: string;
    color?: string;
  }[];
  user: { name: string; email: string; avatar?: string };
  expanded: boolean;
  setExpanded: (value: boolean) => void;
  onSignOut: () => void;
}

export default function SideBar({
  title,
  logo,
  optionalItems,
  primaryItems,
  user,
  onSignOut,
  notifications,
  expanded,
  setExpanded,
}: SideBarProps) {
  return (
    <div>
      <PoleStarSidebar
        logo={logo}
        optionalItems={optionalItems}
        title={title}
        primaryItems={primaryItems}
        user={user}
        onSignOut={onSignOut}
        notifications={notifications}
        expanded={expanded}
        setExpanded={setExpanded}
      />
    </div>
  );
}
