import { render, screen } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import App from '@/app/App';

// -------------------------------------------------------
// Mock AuthProvider
// -------------------------------------------------------
const MockAuthProvider = vi.fn(({ children }) => (
  <div data-testid="auth-provider">{children}</div>
));

vi.mock('@/features/auth/context/AuthContext', () => ({
  AuthProvider: (props: unknown) => MockAuthProvider(props),
}));

// -------------------------------------------------------
// Mock TimeoutProvider
// -------------------------------------------------------
const MockTimeoutProvider = vi.fn(({ children }) => (
  <div data-testid="timeout-provider">{children}</div>
));

vi.mock('@/app/providers/TimeoutProvider', () => ({
  TimeoutProvider: (props: unknown) => MockTimeoutProvider(props),
}));

// -------------------------------------------------------
// Mock LibraryProvider
// -------------------------------------------------------
const MockLibraryProvider = vi.fn(({ children }) => (
  <div data-testid="library-provider">{children}</div>
));

vi.mock('@/features/library/context/LibraryContext', () => ({
  __esModule: true,
  default: (props: unknown) => MockLibraryProvider(props),
}));

// -------------------------------------------------------
// Mock MeridiaIQProvider  ← was missing entirely
// -------------------------------------------------------
const MockMeridiaIQProvider = vi.fn(({ children }) => (
  <div data-testid="meridia-iq-provider">{children}</div>
));

vi.mock('@/app/providers/MeridiaIQProvider', () => ({
  MeridiaIQProvider: (props: unknown) => MockMeridiaIQProvider(props),
}));

// -------------------------------------------------------
// Mock NotifStompProvider
// -------------------------------------------------------
const MockNotifProvider = vi.fn(({ children }) => (
  <div data-testid="notif-provider">{children}</div>
));

vi.mock('@/features/Notifications/Context/NotificationsStompContext', () => ({
  NotifStompProvider: (props: unknown) => MockNotifProvider(props),
}));

// -------------------------------------------------------
// Mock BrowserRouter
// -------------------------------------------------------
const MockRouter = vi.fn(({ children }: { children: React.ReactNode }) => (
  <div data-testid="router">{children}</div>
));

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    BrowserRouter: (props: { children: React.ReactNode }) => MockRouter(props),
    useLocation: () => ({ pathname: '/' }),
  };
});

// -------------------------------------------------------
// Mock AppRoutes
// -------------------------------------------------------
vi.mock('@/app/routes/AppRoutes', () => ({
  __esModule: true,
  default: () => <div data-testid="app-routes">AppRoutesContent</div>,
}));

// -------------------------------------------------------

beforeEach(() => {
  vi.clearAllMocks();
});

describe('App Component', () => {
  it('renders AppRoutes inside all providers and router', () => {
    render(<App />);

    const auth = screen.getByTestId('auth-provider');
    const router = screen.getByTestId('router');
    const timeOut = screen.getByTestId('timeout-provider');
    const library = screen.getByTestId('library-provider');
    const meridiaIQ = screen.getByTestId('meridia-iq-provider');
    const notif = screen.getByTestId('notif-provider');
    const routes = screen.getByTestId('app-routes');

    // Every node exists
    expect(auth).toBeInTheDocument();
    expect(router).toBeInTheDocument();
    expect(timeOut).toBeInTheDocument();
    expect(library).toBeInTheDocument();
    expect(meridiaIQ).toBeInTheDocument();
    expect(notif).toBeInTheDocument();
    expect(routes).toBeInTheDocument();

    expect(auth).toContainElement(router);
    expect(router).toContainElement(timeOut);
    expect(timeOut).toContainElement(library);
    expect(library).toContainElement(meridiaIQ);
    expect(meridiaIQ).toContainElement(notif);
    expect(notif).toContainElement(routes);
  });

  it('ensures all providers were called', () => {
    render(<App />);

    expect(MockAuthProvider).toHaveBeenCalled();
    expect(MockRouter).toHaveBeenCalled();
    expect(MockTimeoutProvider).toHaveBeenCalled();
    expect(MockLibraryProvider).toHaveBeenCalled();
    expect(MockMeridiaIQProvider).toHaveBeenCalled();
    expect(MockNotifProvider).toHaveBeenCalled();
  });
});
