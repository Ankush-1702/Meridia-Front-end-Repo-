import { hasGroupPermission } from '@/features/auth/utils/authTokenUtils';

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
export const API_GATEWAY_BASE_URL = import.meta.env.VITE_API_GATEWAY_BASE_URL;
export const ACCOUNT_SERVICE_URL =
  import.meta.env.VITE_ACCOUNT_SERVICE_URL || API_GATEWAY_BASE_URL;
// ELZ dev only: legacy-hosted services (zone/vessel/voyage/unified-position)
// not yet migrated to ELZ. Unset in legacy envs -> falls back to API_GATEWAY_BASE_URL.
export const LEGACY_API_GATEWAY_BASE_URL =
  import.meta.env.VITE_LEGACY_API_GATEWAY_BASE_URL || API_GATEWAY_BASE_URL;
export const MARITIME_ANALYTICS_API_PATH = '/maritime-analytics/v1';
export const FLEET_MANAGEMENT_BASE_API_URL = API_GATEWAY_BASE_URL?.includes(
  'test',
)
  ? 'https://api.polestar-dev.com'
  : API_GATEWAY_BASE_URL;
export const FLEET_MANAGEMENT_SLUG = 'fleet-management/v2';
// Base URL for fleet READ (GET) calls.
// ELZ dev only (VITE_LEGACY_API_GATEWAY_BASE_URL is set): the ELZ fleet-management
// gateway now exposes the V2 GETs, so reads use FLEET_MANAGEMENT_BASE_API_URL.
// Legacy test/stage/prod (variable unset): unchanged legacy gateway + slug.
export const FLEET_READ_BASE_URL = import.meta.env
  .VITE_LEGACY_API_GATEWAY_BASE_URL
  ? `${FLEET_MANAGEMENT_BASE_API_URL}/fleet-management/v2`
  : `${LEGACY_API_GATEWAY_BASE_URL}/${FLEET_MANAGEMENT_SLUG}`;
export const AG_GRID_LICENSE_KEY = import.meta.env.VITE_AG_GRID_LICENSE_KEY;
export const CMAP_TILE_URLS =
  import.meta.env.VITE_CMAP_TILE_URLS?.split(',') || [];
export const INBOUND_VESSELS_DESTINATION_UPDATE_DAYS = 60;
export const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;

export function isMara2Enabled(): boolean {
  return hasGroupPermission('meridia-iq') || hasGroupPermission('mara');
}
