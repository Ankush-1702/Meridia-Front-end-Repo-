import type { CustomFlowbiteTheme } from 'flowbite-react';

export const searchFieldTheme = {
  field: {
    input: {
      sizes: {
        md: 'px-2.5 py-1.5 text-sm bg-white dark:bg-gray-800',
      },
    },
    icon: { svg: 'h-4 w-4 text-gray-400' },
  },
};

export const menuTheme = {
  floating: {
    base: 'z-50 w-fit rounded-lg p-2 shadow-lg focus:outline-none',
    style: {
      auto: 'border border-gray-300 dark:border-gray-700 bg-white text-gray-900/70 dark:text-white/70 dark:bg-gray-800',
    },
    divider: 'my-1 h-px bg-gray-300 dark:bg-gray-700',
    item: {
      base: 'flex w-full cursor-pointer items-center gap-2 whitespace-nowrap rounded-md px-3 py-2 text-left text-sm text- gray-900/70 hover:bg-gray-300 focus:bg-gray-100 focus:outline-none dark:text-white/70 dark:hover:bg-gray-700 dark:focus:bg-gray-700',
    },
  },
};

export const filterPanelTheme = {
  floating: {
    base: 'z-50 w-fit rounded-lg p-0 shadow-lg focus:outline-none',
    style: {
      auto: 'border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 ext-gray-900/70 dark:text-white/70',
    },
  },
};

const customTheme: CustomFlowbiteTheme = {
  button: {
    color: {
      primary:
        'text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800',
      secondary:
        'text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600 dark:focus:ring-gray-800',
      success:
        'text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800',
      danger:
        'text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800',
      light:
        'text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-gray-200',
      dark: 'text-white bg-gray-800 hover:bg-gray-900 focus:ring-4 focus:ring-gray-300 dark:bg-gray-800 dark:hover:bg-gray-900 dark:focus:ring-gray-700',
    },
  },
  toggleSwitch: {
    toggle: {
      base: 'relative rounded-full after:absolute after:rounded-full after:border after:bg-white after:transition-all group-focus:ring-4',
      checked: {
        on: 'after:translate-x-full after:border-transparent rtl:after:-translate-x-full',
        off: 'bg-gray-200 after:border-gray-300 dark:bg-gray-700',
        color: {
          blue: 'bg-blue-700 group-focus:ring-blue-300 dark:group-focus:ring-blue-800',
          psg: 'bg-psg-orange-700 group-focus:ring-psg-orange-300 dark:group-focus:ring-psg-orange-800',
        },
      },
    },
  },
  checkbox: {
    root: {
      base: 'h-4 w-4 appearance-none rounded border border-gray-300 bg-gray-100 bg-[length:0.55em_0.55em] bg-center bg-no-repeat checked:border-transparent checked:bg-current checked:bg-check-icon focus:outline-none focus:ring-2 focus:ring-offset-2 dark:border-gray-600 dark:bg-gray-700 dark:checked:border-transparent dark:checked:bg-current',
      color: {
        default:
          'text-primary-600 focus:ring-primary-600 dark:ring-offset-gray-800 dark:focus:ring-primary-600',
        psgLightPrimary:
          'text-psg-orange-700 focus:ring-psg-orange-700 dark:ring-offset-gray-800 dark:focus:ring-psg-orange-700',
      },
    },
  },
  modal: {
    root: {
      base: 'fixed inset-0 z-50 flex items-center justify-center p-4',
      sizes: {
        sm: 'max-w-[420px]',
        md: 'max-w-md',
        lg: 'max-w-lg',
        xl: 'max-w-2xl',
        '2xl': 'max-w-3xl',
        '3xl': 'max-w-[1024px]',
      },
    },
    content: {
      base: 'relative h-full w-full md:h-auto',
      inner: 'relative rounded-lg bg-white shadow dark:bg-gray-800',
    },
    header: {
      base: 'flex items-start justify-between rounded-t px-5 pt-5',
    },
  },
  dropdown: {
    floating: {
      base: 'z-10 w-fit rounded-md divide-y divide-gray-100 shadow',
      content: 'rounded-xl text-sm text-gray-700 dark:text-gray-200',
      target: 'w-32 dark:text-white',
    },
    content: '',
  },
  datepicker: {
    popup: {
      root: {
        base: 'absolute top-10 z-50 block pt-2',
        inner:
          'inline-block rounded-lg border border-gray-200 bg-white p-4 shadow-lg dark:border-gray-700 dark:bg-gray-800',
      },
      header: {
        title:
          'px-2 py-3 text-center font-semibold text-gray-900 dark:text-gray-100',
        selectors: {
          button: {
            base: 'rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-psg-orange-500 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700',
          },
        },
      },
      footer: {
        base: 'mt-2 flex space-x-2',
        button: {
          base: 'w-full rounded-lg px-5 py-2 text-center text-sm font-medium focus:ring-4 focus:ring-psg-orange-500',
          today:
            'bg-psg-orange-700 text-white hover:bg-psg-orange-800 dark:bg-psg-orange-700 dark:text-white dark:hover:bg-psg-orange-800',
          clear:
            'border border-gray-200 bg-white text-gray-900 hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700',
        },
      },
    },
    views: {
      days: {
        header: {
          title:
            'h-6 text-center text-sm font-medium leading-6 text-gray-500 dark:text-gray-400',
        },
        items: {
          item: {
            base: 'block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-700',
            selected:
              'bg-psg-orange-700 text-white hover:bg-psg-orange-800 dark:bg-psg-orange-700 dark:text-white dark:hover:bg-psg-orange-800',
          },
        },
      },
      months: {
        items: {
          item: {
            base: 'block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-700',
            selected:
              'bg-psg-orange-700 text-white hover:bg-psg-orange-800 dark:bg-psg-orange-700 dark:text-white dark:hover:bg-psg-orange-800',
          },
        },
      },
      years: {
        items: {
          item: {
            base: 'block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-700',
            selected:
              'bg-psg-orange-700 text-white hover:bg-psg-orange-800 dark:bg-psg-orange-700 dark:text-white dark:hover:bg-psg-orange-800',
          },
        },
      },
      decades: {
        items: {
          item: {
            base: 'block flex-1 cursor-pointer rounded-lg border-0 text-center text-sm font-semibold leading-9 text-gray-900 hover:bg-gray-100 dark:text-gray-100 dark:hover:bg-gray-700',
            selected:
              'bg-psg-orange-700 text-white hover:bg-psg-orange-800 dark:bg-psg-orange-700 dark:text-white dark:hover:bg-psg-orange-800',
          },
        },
      },
    },
  },
  radio: {
    root: {
      base: 'h-4 w-4 cursor-pointer appearance-none rounded-full border border-gray-300 bg-gray-100 bg-[length:1em_1em] bg-center bg-no-repeat checked:border-transparent checked:bg-current checked:bg-dot-icon focus:outline-none focus:ring-2 focus:ring-offset-2 dark:border-gray-600 dark:bg-gray-700 dark:checked:border-transparent dark:checked:bg-current',
    },
  },
  sidebar: {
    root: {
      base: 'h-full',
      collapsed: {
        on: 'w-16',
        off: 'w-64',
      },
      inner:
        'h-full overflow-y-auto overflow-x-hidden rounded bg-white px-3 py-4 dark:bg-gray-800',
    },
  },
  spinner: {
    base: 'inline animate-spin text-gray-200',
    color: {
      default: 'fill-primary-600',
      failure: 'fill-red-600',
      gray: 'fill-gray-600',
      info: 'fill-cyan-600',
      pink: 'fill-pink-600',
      purple: 'fill-purple-600',
      success: 'fill-green-500',
      warning: 'fill-yellow-400',
      psgPrimary: 'fill-psg-orange-600',
    },
    light: {
      off: {
        base: 'dark:text-gray-600',
        color: {
          default: '',
          failure: '',
          gray: 'dark:fill-gray-300',
          info: '',
          pink: '',
          purple: '',
          success: '',
          warning: '',
        },
      },
      on: {
        base: '',
        color: {
          default: '',
          failure: '',
          gray: '',
          info: '',
          pink: '',
          purple: '',
          success: '',
          warning: '',
        },
      },
    },
    size: {
      xs: 'h-3 w-3',
      sm: 'h-4 w-4',
      md: 'h-6 w-6',
      lg: 'h-8 w-8',
      xl: 'h-10 w-10',
    },
  },
  rangeSlider: {
    root: {
      base: 'flex',
    },
    field: {
      base: 'relative w-full',
      input: {
        base: 'w-full cursor-pointer appearance-none rounded-lg bg-gray-200 dark:bg-gray-700',
        sizes: {
          sm: 'h-1',
          md: 'h-2',
          lg: 'h-3',
        },
      },
    },
  },
  progress: {
    base: 'w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700',
    label: 'mb-1 flex justify-between font-medium dark:text-white',
    bar: 'space-x-2 rounded-full text-center font-medium leading-none text-primary-300 dark:text-primary-100',
    color: {
      default: 'bg-primary-600',
      psgOrange: 'bg-psg-orange-700',
    },
    size: {
      sm: 'h-1.5',
      md: 'h-2.5',
      lg: 'h-4',
      xl: 'h-6',
    },
  },
  textInput: {
    field: {
      input: {
        colors: {
          gray: 'border-gray-300 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 dark:text-white text-gray-900 placeholder:text-muted-foreground focus:border-psg-orange-700 focus:ring-2 focus:ring-psg-orange-700 dark:placeholder:text-muted-foreground dark:focus:border-psg-orange-700 dark:focus:ring-psg-orange-700',
        },
      },
    },
  },
  textarea: {
    colors: {
      gray: 'border-gray-300 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 dark:text-white text-gray-900 placeholder:text-muted-foreground focus:border-psg-orange-700 focus:ring-2 focus:ring-psg-orange-700 dark:placeholder:text-muted-foreground dark:focus:border-psg-orange-700 dark:focus:ring-psg-orange-700',
    },
  },
  badge: {
    root: {
      base: 'flex h-fit items-center gap-1 font-semibold',
      color: {
        info: 'bg-cyan-100 text-cyan-800 hover:bg-cyan-200 dark:bg-cyan-200 dark:text-cyan-800 dark:hover:bg-cyan-300',
        gray: 'bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600',
        failure:
          'bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-200 dark:text-red-900 dark:hover:bg-red-300',
        success:
          'bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-200 dark:text-green-900 dark:hover:bg-green-300',
        warning:
          'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 dark:bg-yellow-200 dark:text-yellow-900 dark:hover:bg-yellow-300',
        indigo:
          'bg-indigo-100 text-indigo-800 hover:bg-indigo-200 dark:bg-indigo-200 dark:text-indigo-900 dark:hover:bg-indigo-300',
        purple:
          'bg-purple-100 text-purple-800 hover:bg-purple-200 dark:bg-purple-200 dark:text-purple-900 dark:hover:bg-purple-300',
        pink: 'bg-pink-100 text-pink-800 hover:bg-pink-200 dark:bg-pink-200 dark:text-pink-900 dark:hover:bg-pink-300',
        blue: 'bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-200 dark:text-blue-900 dark:hover:bg-blue-300',
        cyan: 'bg-cyan-100 text-cyan-800 hover:bg-cyan-200 dark:bg-cyan-200 dark:text-cyan-900 dark:hover:bg-cyan-300',
        dark: 'bg-gray-600 text-gray-100 hover:bg-gray-500 dark:bg-gray-900 dark:text-gray-200 dark:hover:bg-gray-700',
        light:
          'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-400 dark:text-gray-900 dark:hover:bg-gray-500',
        green:
          'bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-200 dark:text-green-900 dark:hover:bg-green-300',
        lime: 'bg-lime-100 text-lime-800 hover:bg-lime-200 dark:bg-lime-200 dark:text-lime-900 dark:hover:bg-lime-300',
        red: 'bg-red-100 text-red-800 hover:bg-red-200 dark:bg-red-200 dark:text-red-900 dark:hover:bg-red-300',
        teal: 'bg-teal-100 text-teal-800 hover:bg-teal-200 dark:bg-teal-200 dark:text-teal-900 dark:hover:bg-teal-300',
        yellow:
          'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 dark:bg-yellow-200 dark:text-yellow-900 dark:hover:bg-yellow-300',
        'psg-orange':
          'bg-psg-orange-300 text-psg-orange-800 hover:bg-psg-orange-400 dark:bg-psg-orange-300 dark:text-psg-orange-800 dark:hover:bg-psg-orange-400',
      },
      size: {
        xs: 'p-1 text-xs',
        sm: 'p-1.5 text-sm',
      },
    },
    icon: {
      off: 'rounded px-2 py-0.5',
      on: 'rounded-full p-1.5',
      size: {
        xs: 'h-3 w-3',
        sm: 'h-3.5 w-3.5',
      },
    },
  },
};

export default customTheme;
