export const MDAURL = 'https://mda-gov.polestarglobal.com/';
export const MERIDIAURL = 'https://platform.polestarglobal.com/';
export const PODIUMURL = 'https://podium.stratumfive.com/';
export const PURPLETRACURL = 'https://www.purpletrac.com/';
export const POLESTARONDEMANDURL = 'https://ondemand.polestarglobal.com/';
export const MTIURL = 'https://mti.polestarglobal.com';
export const MTI_INFO_URL =
  'https://www.polestarglobal.com/maritime-transparency-index/';
export const PURPLETRAC_INFO_URL = 'https://www.polestarglobal.com/purpletrac/';
export const WPIURL =
  'https://msi.pub.kubic.nga.mil/api/publications/world-port-index';
