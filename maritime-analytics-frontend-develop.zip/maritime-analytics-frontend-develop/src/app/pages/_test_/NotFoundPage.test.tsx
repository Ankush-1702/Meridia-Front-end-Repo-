import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import NotFoundPage from '@/app/pages/NotFoundPage';

// --- Optional: Mock Flowbite Button to keep tests minimal ---
vi.mock('flowbite-react', () => ({
  Button: ({ children, href }: { children: React.ReactNode; href: string }) => (
    <a data-testid="mock-button" href={href}>
      {children}
    </a>
  ),
}));

describe('NotFoundPage', () => {
  it('renders the page layout container', () => {
    const { container } = render(<NotFoundPage />);
    expect(container.firstChild).toHaveClass(
      'flex',
      'min-h-screen',
      'flex-col',
      'items-center',
      'justify-center',
      'py-16',
    );
  });

  it('renders the 404 image', () => {
    render(<NotFoundPage />);
    const image = screen.getByAltText(''); // alt text is empty
    expect(image).toHaveAttribute('src', '/images/404.svg');
  });

  it('renders the heading', () => {
    render(<NotFoundPage />);
    const heading = screen.getByRole('heading', { name: /page not found/i });
    expect(heading).toBeInTheDocument();
  });

  it('renders the description text', () => {
    render(<NotFoundPage />);
    expect(
      screen.getByText(/oops! looks like you followed a bad link/i),
    ).toBeInTheDocument();
  });

  it('renders the back home button with correct link', () => {
    render(<NotFoundPage />);
    const button = screen.getByTestId('mock-button');
    expect(button).toHaveAttribute('href', '/');
    expect(button).toHaveTextContent(/go back home/i);
  });

  it('renders the back icon inside the button', () => {
    render(<NotFoundPage />);
    const icon = screen.getByTestId('mock-button').querySelector('svg');
    expect(icon).toBeInTheDocument();
  });
});
