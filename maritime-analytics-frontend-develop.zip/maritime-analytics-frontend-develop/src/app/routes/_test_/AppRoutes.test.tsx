import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, vi, beforeEach } from 'vitest';

import AppRoutes from '@/app/routes/AppRoutes';

// --------------------------------------------------
// Mock useAuth
// --------------------------------------------------
const mockUseAuth = vi.fn();
vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => mockUseAuth(),
}));

// --------------------------------------------------
// Mock route modules (each must return an OBJECT!)
// --------------------------------------------------

vi.mock('@/features/auth/routes/publicAuthRoutes', () => ({
  __esModule: true,
  publicAuthRoutes: () => [
    { path: '/login', element: <div>LoginPage</div> },
    { path: '/register', element: <div>RegisterPage</div> },
  ],
}));

vi.mock('@/features/auth/routes/privateAuthRoutes', () => ({
  __esModule: true,
  privateAuthRoutes: [{ path: '/profile', element: <div>ProfilePage</div> }],
}));

vi.mock('@/features/library/routes/libraryRoutes', () => ({
  __esModule: true,
  libraryRoutes: () => [{ path: '/library', element: <div>LibraryPage</div> }],
}));

vi.mock('@/features/mara/routes/maraRoutes', () => ({
  __esModule: true,
  maraRoutes: () => [{ path: '/mara', element: <div>MaraPage</div> }],
}));

vi.mock('@/features/Notifications/routes/NotificationsRoute', () => ({
  __esModule: true,
  notificationsRoutes: () => [
    { path: '/notifications', element: <div>NotificationsPage</div> },
  ],
}));

vi.mock('@/features/Ports/routes/portsRoute', () => ({
  __esModule: true,
  portRoutes: [{ path: '/ports', element: <div>PortsPage</div> }],
}));

vi.mock('@/features/Vessels/routes/vesselRoutes', () => ({
  __esModule: true,
  vesselRoutes: [{ path: '/vessels', element: <div>VesselsPage</div> }],
}));

vi.mock('@/features/Zones/routes/zoneRoutes', () => ({
  __esModule: true,
  zoneRoutes: [{ path: '/zones', element: <div>ZonesPage</div> }],
}));

// --------------------------------------------------
// Mock NotFoundPage
// --------------------------------------------------
vi.mock('@/app/pages/NotFoundPage', () => ({
  __esModule: true,
  default: () => <div>NotFoundPage</div>,
}));

// --------------------------------------------------
// Mock AppLayout to detect private route rendering
// --------------------------------------------------
const mockLayout = vi.fn();
interface AppLayoutProps {
  children?: React.ReactNode;
}

vi.mock('@/app/layouts/AppLayout', () => ({
  __esModule: true,
  default: (props: AppLayoutProps) => {
    mockLayout(props);
    return <div data-testid="app-layout">{props.children}</div>;
  },
}));

// --------------------------------------------------
// Mock Spinner from Flowbite
// --------------------------------------------------
vi.mock('flowbite-react', () => ({
  Spinner: () => <div data-testid="spinner">LoadingSpinner</div>,
}));

// --------------------------------------------------
beforeEach(() => {
  vi.clearAllMocks();
});

// --------------------------------------------------
// TEST SUITE
// --------------------------------------------------
describe('AppRoutes', () => {
  it('renders spinner when authChecked = false', () => {
    mockUseAuth.mockReturnValue({
      authChecked: false,
      isAuthenticated: false,
    });

    render(
      <MemoryRouter>
        <AppRoutes />
      </MemoryRouter>,
    );

    expect(screen.getByTestId('spinner')).toBeInTheDocument();
  });

  it('redirects to /login when not authenticated', () => {
    mockUseAuth.mockReturnValue({
      authChecked: true,
      isAuthenticated: false,
    });

    render(
      <MemoryRouter initialEntries={['/library']}>
        <AppRoutes />
      </MemoryRouter>,
    );

    expect(screen.getByText('LoginPage')).toBeInTheDocument();
  });

  it('renders private route inside AppLayout when authenticated', () => {
    mockUseAuth.mockReturnValue({
      authChecked: true,
      isAuthenticated: true,
    });

    render(
      <MemoryRouter initialEntries={['/library']}>
        <AppRoutes />
      </MemoryRouter>,
    );

    expect(screen.getByTestId('app-layout')).toBeInTheDocument();
    expect(screen.getByText('LibraryPage')).toBeInTheDocument();
  });

  it('renders public routes', () => {
    mockUseAuth.mockReturnValue({
      authChecked: true,
      isAuthenticated: true,
    });

    render(
      <MemoryRouter initialEntries={['/login']}>
        <AppRoutes />
      </MemoryRouter>,
    );

    expect(screen.getByText('LoginPage')).toBeInTheDocument();
  });

  it('renders NotFoundPage for unknown routes', () => {
    mockUseAuth.mockReturnValue({
      authChecked: true,
      isAuthenticated: true,
    });

    render(
      <MemoryRouter initialEntries={['/does-not-exist']}>
        <AppRoutes />
      </MemoryRouter>,
    );

    expect(screen.getByText('NotFoundPage')).toBeInTheDocument();
  });

  describe('renders all private feature routes when authenticated', () => {
    const privatePaths = [
      '/profile',
      '/library',
      '/zones',
      '/ports',
      '/vessels',
      '/mara',
      '/notifications',
    ];

    privatePaths.forEach((path) => {
      it(`renders AppLayout for route: ${path}`, () => {
        mockUseAuth.mockReturnValue({
          authChecked: true,
          isAuthenticated: true,
        });

        render(
          <MemoryRouter initialEntries={[path]}>
            <AppRoutes />
          </MemoryRouter>,
        );

        expect(screen.getByTestId('app-layout')).toBeInTheDocument();
      });
    });
  });
});
