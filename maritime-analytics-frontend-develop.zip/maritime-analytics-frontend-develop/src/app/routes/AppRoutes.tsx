import { Spinner } from 'flowbite-react';
import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import AppLayout from '@/app/layouts/AppLayout';
import NotFoundPage from '@/app/pages/NotFoundPage';
import { useAuth } from '@/features/auth/context/AuthContext';
import { privateAuthRoutes } from '@/features/auth/routes/privateAuthRoutes';
import { publicAuthRoutes } from '@/features/auth/routes/publicAuthRoutes';
import { customZonesRoutes } from '@/features/custom-zones/routes/customZonesRoutes';
import { fleetRoutes } from '@/features/Fleets/routes/FleetRoutes';
import { libraryRoutes } from '@/features/library/routes/libraryRoutes';
import { maraRoutes } from '@/features/mara/routes/maraRoutes';
import { mara2Routes } from '@/features/mara2/routes/mara2Routes';
import { notificationsRoutes } from '@/features/Notifications/routes/NotificationsRoute';
import { portRoutes } from '@/features/Ports/routes/portsRoute';
import { vesselRoutes } from '@/features/Vessels/routes/vesselRoutes';
import { zoneRoutes } from '@/features/Zones/routes/zoneRoutes';

function AuthLayout() {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  return (
    <AppLayout>
      <Outlet />
    </AppLayout>
  );
}

export default function AppRoutes() {
  const { isAuthenticated, authChecked } = useAuth();

  if (!authChecked) {
    return (
      <div
        className="flex min-h-screen items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: `url('/images/PSG-Defense-ISR.webp')` }}
      >
        <Spinner />
      </div>
    );
  }

  return (
    <Routes>
      {/* Public routes */}
      {publicAuthRoutes(isAuthenticated).map((route, idx) => (
        <Route key={idx} {...route} />
      ))}
      <Route path="*" element={<NotFoundPage />} />

      {/* Private routes */}
      <Route element={<AuthLayout />}>
        {[
          ...libraryRoutes(),
          ...privateAuthRoutes,
          ...customZonesRoutes(),
          ...zoneRoutes,
          ...portRoutes,
          ...vesselRoutes,
          ...fleetRoutes,
          {
            path: '/analytics/chats/*',
            element: <Navigate to="/analytics/chat2" replace />,
          },
          ...maraRoutes(),
          ...mara2Routes(),
          ...notificationsRoutes(),
        ].map((route, idx) => (
          <Route key={idx} {...route} />
        ))}
      </Route>
    </Routes>
  );
}
