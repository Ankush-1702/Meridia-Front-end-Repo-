import { Flowbite } from 'flowbite-react';
import type { ThemeMode } from 'flowbite-react';
import type { FC } from 'react';
import { useState } from 'react';
import theme from '@/app/config/flowbite-theme';

function resolveInitialMode(): ThemeMode {
  const preview = localStorage.getItem('theme-preview');
  const saved = localStorage.getItem('theme');
  const raw: string = preview || saved || 'light';

  if (raw === 'system') {
    return window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  }

  return raw === 'dark' ? 'dark' : 'light';
}

const FlowbiteWrapper: FC<{ children: React.ReactNode }> = function ({
  children,
}) {
  const [initialMode] = useState<ThemeMode>(resolveInitialMode);

  return <Flowbite theme={{ mode: initialMode, theme }}>{children}</Flowbite>;
};

export default FlowbiteWrapper;
