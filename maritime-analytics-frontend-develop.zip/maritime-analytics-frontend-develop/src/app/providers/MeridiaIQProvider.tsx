import {
  createContext,
  FC,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import { useAuth } from '@/features/auth/context/AuthContext';
import { getPreviousSessions } from '@/features/mara/services/sessionService';
import {
  getSessionLabel,
  groupSessions,
} from '@/features/mara/utils/messageFormatter';
import {
  deleteMara2Session,
  getMara2Sessions,
} from '@/features/mara2/services/mara2ApiService';
import type { ChatGroupEntry } from '@/shared/components/ChatList';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { logger } from '@/shared/utils/logger';

type ChatVersion = 'v1' | 'v2';

interface MeridiaIQContextValue {
  version: ChatVersion;
  groups: ChatGroupEntry[];
  activeSessionId: string | null;
  newSessionId: string | null;
  isLoading: boolean;
  setVersion: (v: ChatVersion) => void;
  setGroups: (groups: ChatGroupEntry[]) => void;
  setActiveSessionId: (id: string | null) => void;
  setNewSessionId: (id: string | null) => void;
  setIsLoading: (loading: boolean) => void;
  onNewChat: () => void;
  setOnNewChat: (fn: () => void) => void;
  onSelectChat: (id: string) => void;
  setOnSelectChat: (fn: (id: string) => void) => void;
  onDeleteChat: (id: string, title: string) => void;
  setOnDeleteChat: (fn: (id: string, title: string) => void) => void;
  refreshSessions: () => void;
}

const MeridiaIQContext = createContext<MeridiaIQContextValue | null>(null);

export const useMeridiaIQ = () => {
  const ctx = useContext(MeridiaIQContext);
  if (!ctx)
    throw new Error('useMeridiaIQ must be used within MeridiaIQProvider');
  return ctx;
};

const noop = () => {};
const noopStr = () => {};
export const deleteHandlerNoop = () => {};

export const MeridiaIQProvider: FC<{ children: ReactNode }> = ({
  children,
}) => {
  const { user } = useAuth();
  const handleApiError = useApiErrorHandler();
  const { showToast } = useToastNotification();
  const userId = user?.user_id;

  const [version, setVersion] = useState<ChatVersion>(() => {
    const stored = localStorage.getItem('meridia-iq-version');
    return (stored as ChatVersion) ?? 'v2';
  });
  const [rawGroups, setRawGroups] = useState<ChatGroupEntry[]>(() => {
    try {
      const stored = localStorage.getItem('meridia-iq-groups');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [newSessionId, setNewSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const onNewChatRef = useRef<() => void>(noop);
  const onSelectChatRef = useRef<(id: string) => void>(noopStr);
  const onDeleteChatRef =
    useRef<(id: string, title: string) => void>(deleteHandlerNoop);

  const onNewChat = useCallback(() => onNewChatRef.current(), []);
  const onSelectChat = useCallback(
    (id: string) => onSelectChatRef.current(id),
    [],
  );
  const onDeleteChat = useCallback(
    async (id: string, title: string) => {
      if (onDeleteChatRef.current !== deleteHandlerNoop) {
        // Mara2Page is mounted — delegate to it (handles post-delete navigation too)
        onDeleteChatRef.current(id, title);
        return;
      }
      // Mara2Page is not mounted — delete directly from provider
      if (!userId) return;
      try {
        await deleteMara2Session(userId, id);
        showToast('success', `"${title}" deleted successfully`, 5000);
        setRawGroups((prev) =>
          prev
            .map((g) => ({
              ...g,
              sessions: g.sessions.filter((s) => s.id !== id),
            }))
            .filter((g) => g.sessions.length > 0),
        );
      } catch (error) {
        handleApiError(error);
      }
    },
    [userId, showToast, handleApiError],
  );

  const fetchAndSetGroups = useCallback(
    async (v: ChatVersion) => {
      if (!userId) return;
      setIsLoading(true);
      try {
        if (v === 'v1') {
          const data = await getPreviousSessions(userId);
          const sessionsArray = Object.entries(data)
            .map(([session_id, sessionData]) => ({
              session_id,
              ...sessionData,
            }))
            .sort(
              (a, b) =>
                new Date(b.timestamp).getTime() -
                new Date(a.timestamp).getTime(),
            );

          const grouped = groupSessions(sessionsArray);
          const entries: ChatGroupEntry[] = (
            Object.entries(grouped) as [string, typeof sessionsArray][]
          )
            .filter(([, s]) => s.length > 0)
            .map(([label, s]) => ({
              label,
              sessions: s.map((session) => ({
                id: session.session_id,
                title:
                  getSessionLabel(session.content, session.session_id) ??
                  'Untitled',
              })),
            }));
          setRawGroups(entries);
        } else {
          const data = await getMara2Sessions(userId);
          const chats = Object.entries(data)
            .map(([id, chatData]) => ({
              id,
              ...chatData,
            }))
            .sort(
              (a, b) =>
                new Date(b.timestamp ?? 0).getTime() -
                new Date(a.timestamp ?? 0).getTime(),
            );

          const now = new Date();
          const startOfToday = new Date(now);
          startOfToday.setHours(0, 0, 0, 0);
          const sevenDaysAgo = new Date(now);
          sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
          const thirtyDaysAgo = new Date(now);
          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

          const buckets: Record<string, ChatGroupEntry['sessions']> = {
            Today: [],
            'Last 7 Days': [],
            'Last 30 Days': [],
            Older: [],
          };

          chats.forEach((chat) => {
            const item = { id: chat.id, title: chat.content ?? 'Untitled' };
            const ts = chat.timestamp
              ? new Date(Number(chat.timestamp) * 1000)
              : new Date();
            if (ts >= startOfToday) buckets['Today'].push(item);
            else if (ts >= sevenDaysAgo) buckets['Last 7 Days'].push(item);
            else if (ts >= thirtyDaysAgo) buckets['Last 30 Days'].push(item);
            else buckets['Older'].push(item);
          });

          setRawGroups(
            Object.entries(buckets)
              .filter(([, s]) => s.length > 0)
              .map(([label, sessions]) => ({ label, sessions })),
          );
        }
      } catch (error) {
        logger.error('[MeridiaIQ] Failed to fetch sessions:', error);
      } finally {
        setIsLoading(false);
      }
    },
    [userId],
  );

  useEffect(() => {
    if (userId) {
      fetchAndSetGroups(version);
    }
  }, [userId, version, fetchAndSetGroups]);

  useEffect(() => {
    if (rawGroups.length > 0) {
      localStorage.setItem('meridia-iq-groups', JSON.stringify(rawGroups));
    }
  }, [rawGroups]);

  useEffect(() => {
    localStorage.setItem('meridia-iq-version', version);
  }, [version]);

  const setOnNewChat = useCallback((fn: () => void) => {
    onNewChatRef.current = fn;
  }, []);

  const setOnSelectChat = useCallback((fn: (id: string) => void) => {
    onSelectChatRef.current = fn;
  }, []);

  const setOnDeleteChat = useCallback(
    (fn: (id: string, title: string) => void) => {
      onDeleteChatRef.current = fn;
    },
    [],
  );

  const refreshSessions = useCallback(() => {
    fetchAndSetGroups(version);
  }, [version, fetchAndSetGroups]);

  const value = useMemo<MeridiaIQContextValue>(
    () => ({
      version,
      groups: rawGroups,
      activeSessionId,
      newSessionId,
      isLoading,
      setVersion,
      setGroups: setRawGroups,
      setActiveSessionId,
      setNewSessionId,
      setIsLoading,
      onNewChat,
      setOnNewChat,
      onSelectChat,
      setOnSelectChat,
      onDeleteChat,
      setOnDeleteChat,
      refreshSessions,
    }),
    [
      version,
      rawGroups,
      activeSessionId,
      newSessionId,
      isLoading,
      onNewChat,
      onSelectChat,
      onDeleteChat,
      setOnNewChat,
      setOnSelectChat,
      setOnDeleteChat,
      refreshSessions,
    ],
  );

  return (
    <MeridiaIQContext.Provider value={value}>
      {children}
    </MeridiaIQContext.Provider>
  );
};
