import {
  render,
  screen,
  act,
  waitFor,
  renderHook,
} from '@testing-library/react';
import { ReactNode } from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';
import {
  MeridiaIQProvider,
  useMeridiaIQ,
} from '@/app/providers/MeridiaIQProvider';
import { useAuth } from '@/features/auth/context/AuthContext';
import { getPreviousSessions } from '@/features/mara/services/sessionService';
import {
  getSessionLabel,
  groupSessions,
} from '@/features/mara/utils/messageFormatter';
import { getMara2Sessions } from '@/features/mara2/services/mara2ApiService';
import type { ChatGroupEntry } from '@/shared/components/ChatList';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';
import { logger } from '@/shared/utils/logger';

/* ------------------------------------------------------------------ */
/* Types                                                                */
/* ------------------------------------------------------------------ */

type V1SessionData = Record<
  string,
  { role: 'user'; content: string; messageType: string; timestamp: number }
>;

type V2ChatData = Record<string, { timestamp?: string; content?: string }>;

/* ------------------------------------------------------------------ */
/* Mocks                                                                */
/* ------------------------------------------------------------------ */

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: vi.fn(),
}));

vi.mock('@/features/mara/services/sessionService', () => ({
  getPreviousSessions: vi.fn(),
}));

vi.mock('@/features/mara/utils/messageFormatter', () => ({
  getSessionLabel: vi.fn((content: string) => content ?? null),
  groupSessions: vi.fn(),
}));

vi.mock('@/features/mara2/services/mara2ApiService', () => ({
  getMara2Sessions: vi.fn(),
  deleteMara2Session: vi.fn(),
}));

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: vi.fn(() => ({
    showToast: vi.fn(),
  })),
}));

vi.mock('@/app/hooks/useApiErrorHandler', () => ({
  useApiErrorHandler: vi.fn(() => vi.fn()),
}));

vi.mock('@/shared/utils/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}));

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

const wrapper = ({ children }: { children: ReactNode }) => (
  <MeridiaIQProvider>{children}</MeridiaIQProvider>
);

/**
 * Renders the hook and flushes all pending async state updates
 * (including the initial fetchAndSetGroups useEffect) inside act().
 * This prevents "not wrapped in act(...)" warnings caused by deferred
 * state updates from the provider's async fetch on mount.
 */
const renderMeridiaIQ = async () => {
  let hookResult!: ReturnType<
    typeof renderHook<ReturnType<typeof useMeridiaIQ>, { children: ReactNode }>
  >;
  await act(async () => {
    hookResult = renderHook(() => useMeridiaIQ(), { wrapper });
  });
  return hookResult;
};

const makeV1Data = (
  overrides: Partial<{
    role: 'user';
    timestamp: number;
    content: string;
    messageType: string;
  }> = {},
): V1SessionData => ({
  'session-1': {
    role: 'user',
    messageType: 'query',
    timestamp: Math.floor(new Date('2024-01-01T12:00:00Z').getTime() / 1000),
    content: 'Hello from session 1',
    ...overrides,
  },
});

const makeV2Data = (
  overrides: Partial<{ timestamp: string; content: string }> = {},
): V2ChatData => ({
  'chat-1': {
    timestamp: String(Math.floor(Date.now() / 1000)),
    content: 'Hello from chat 1',
    ...overrides,
  },
});

/* ------------------------------------------------------------------ */
/* Setup / Teardown                                                     */
/* ------------------------------------------------------------------ */

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.clear();

  vi.mocked(useAuth).mockReturnValue({
    user: { user_id: 'user-42' },
  } as unknown as ReturnType<typeof useAuth>);

  vi.mocked(useToastNotification).mockReturnValue({
    showToast: vi.fn(),
  } as unknown as ReturnType<typeof useToastNotification>);

  vi.mocked(useApiErrorHandler).mockReturnValue(vi.fn());

  vi.mocked(getSessionLabel).mockImplementation(
    (content: string) => content ?? null,
  );

  vi.mocked(getPreviousSessions).mockResolvedValue({} as V1SessionData);
  vi.mocked(getMara2Sessions).mockResolvedValue({} as V2ChatData);
  vi.mocked(groupSessions).mockReturnValue({
    Today: [],
    'Last 7 Days': [],
    'Last 30 Days': [],
    Older: [],
  });
});

afterEach(() => {
  localStorage.clear();
});

/* ------------------------------------------------------------------ */
/* useMeridiaIQ guard                                                   */
/* ------------------------------------------------------------------ */

describe('useMeridiaIQ', () => {
  it('throws when used outside the provider', () => {
    const consoleError = vi
      .spyOn(console, 'error')
      .mockImplementation(() => {});
    expect(() => renderHook(() => useMeridiaIQ())).toThrow(
      'useMeridiaIQ must be used within MeridiaIQProvider',
    );
    consoleError.mockRestore();
  });

  it('does not throw when used inside the provider', async () => {
    await expect(renderMeridiaIQ()).resolves.not.toThrow();
  });
});

/* ------------------------------------------------------------------ */
/* Initial state                                                        */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — initial state', () => {
  it('defaults version to "v2" when localStorage is empty', async () => {
    const { result } = await renderMeridiaIQ();
    expect(result.current.version).toBe('v2');
  });

  it('reads version from localStorage on mount', async () => {
    localStorage.setItem('meridia-iq-version', 'v2');
    const { result } = await renderMeridiaIQ();
    expect(result.current.version).toBe('v2');
  });

  it('defaults groups to [] when localStorage is empty', async () => {
    const { result } = await renderMeridiaIQ();
    expect(result.current.groups).toEqual([]);
  });

  it('reads groups from localStorage on mount', async () => {
    // No user → fetchAndSetGroups early-returns, so the localStorage
    // initial state is never overwritten by an empty API response.
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);
    const stored: ChatGroupEntry[] = [
      { label: 'Today', sessions: [{ id: 's1', title: 'T' }] },
    ];
    localStorage.setItem('meridia-iq-groups', JSON.stringify(stored));
    const { result } = await renderMeridiaIQ();
    expect(result.current.groups).toEqual(stored);
  });

  it('falls back to [] when localStorage groups JSON is invalid', async () => {
    localStorage.setItem('meridia-iq-groups', 'not-json{{{');
    const { result } = await renderMeridiaIQ();
    expect(result.current.groups).toEqual([]);
  });

  it('initialises activeSessionId and newSessionId to null', async () => {
    const { result } = await renderMeridiaIQ();
    expect(result.current.activeSessionId).toBeNull();
    expect(result.current.newSessionId).toBeNull();
  });

  it('initialises isLoading to false', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);

    const { result } = await renderMeridiaIQ();
    expect(result.current.isLoading).toBe(false);
  });
});

/* ------------------------------------------------------------------ */
/* Session fetching — v1                                                */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — v1 session fetching', () => {
  beforeEach(() => {
    localStorage.setItem('meridia-iq-version', 'v1');
  });

  it('calls getPreviousSessions with the user id on mount', async () => {
    vi.mocked(getPreviousSessions).mockResolvedValue({} as V1SessionData);
    vi.mocked(groupSessions).mockReturnValue({
      Today: [],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });

    await renderMeridiaIQ();

    expect(getPreviousSessions).toHaveBeenCalledWith('user-42');
  });

  it('does not fetch sessions when userId is undefined', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);

    await renderMeridiaIQ();

    expect(getPreviousSessions).not.toHaveBeenCalled();
  });

  it('populates groups after a successful v1 fetch', async () => {
    vi.mocked(getPreviousSessions).mockResolvedValue(makeV1Data());
    vi.mocked(groupSessions).mockReturnValue({
      Today: [
        {
          session_id: 'session-1',
          timestamp: Math.floor(
            new Date('2024-01-01T12:00:00Z').getTime() / 1000,
          ),
          content: 'Hello from session 1',
          role: 'user',
          messageType: 'query',
        },
      ],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });
    vi.mocked(getSessionLabel).mockReturnValue('Hello from session 1');

    const { result } = await renderMeridiaIQ();

    expect(result.current.groups).toHaveLength(1);
    expect(result.current.groups[0].label).toBe('Today');
    expect(result.current.groups[0].sessions[0]).toMatchObject({
      id: 'session-1',
      title: 'Hello from session 1',
    });
  });

  it('falls back to "Untitled" when getSessionLabel returns null', async () => {
    vi.mocked(getPreviousSessions).mockResolvedValue(makeV1Data());
    vi.mocked(groupSessions).mockReturnValue({
      Today: [
        {
          session_id: 'session-1',
          timestamp: Math.floor(
            new Date('2024-01-01T12:00:00Z').getTime() / 1000,
          ),
          content: '',
          role: 'user',
          messageType: 'query',
        },
      ],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });
    vi.mocked(getSessionLabel).mockReturnValue(undefined);

    const { result } = await renderMeridiaIQ();

    expect(result.current.groups[0].sessions[0].title).toBe('Untitled');
  });

  it('filters out groups with zero sessions', async () => {
    vi.mocked(getPreviousSessions).mockResolvedValue({} as V1SessionData);
    vi.mocked(groupSessions).mockReturnValue({
      Today: [],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });

    const { result } = await renderMeridiaIQ();

    expect(result.current.groups).toHaveLength(0);
  });

  it('sets isLoading to true during fetch and false after', async () => {
    let resolve!: (v: V1SessionData) => void;
    vi.mocked(getPreviousSessions).mockReturnValue(
      new Promise<V1SessionData>((r) => (resolve = r)),
    );

    // Do NOT use renderMeridiaIQ() here — we intentionally want to
    // observe the in-flight loading state before the promise resolves.
    let hookResult!: ReturnType<
      typeof renderHook<
        ReturnType<typeof useMeridiaIQ>,
        { children: ReactNode }
      >
    >;
    act(() => {
      hookResult = renderHook(() => useMeridiaIQ(), { wrapper });
    });

    await waitFor(() => expect(hookResult.result.current.isLoading).toBe(true));

    await act(async () => {
      resolve({} as V1SessionData);
    });

    await waitFor(() =>
      expect(hookResult.result.current.isLoading).toBe(false),
    );
  });

  it('sets isLoading to false even when the fetch throws', async () => {
    vi.mocked(getPreviousSessions).mockRejectedValue(new Error('network'));
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const { result } = await renderMeridiaIQ();

    expect(result.current.isLoading).toBe(false);
    spy.mockRestore();
  });

  it('logs an error when the v1 fetch fails', async () => {
    const loggerSpy = vi.spyOn(logger, 'error').mockImplementation(() => {});
    vi.mocked(getPreviousSessions).mockRejectedValue(new Error('oops'));

    await renderMeridiaIQ();

    expect(loggerSpy).toHaveBeenCalledWith(
      '[MeridiaIQ] Failed to fetch sessions:',
      expect.any(Error),
    );

    loggerSpy.mockRestore();
  });

  it('persists fetched groups to localStorage', async () => {
    vi.mocked(getPreviousSessions).mockResolvedValue(makeV1Data());
    vi.mocked(groupSessions).mockReturnValue({
      Today: [
        {
          session_id: 'session-1',
          timestamp: Math.floor(
            new Date('2024-01-01T12:00:00Z').getTime() / 1000,
          ),
          content: 'Hello',
          role: 'user',
          messageType: 'query',
        },
      ],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });
    vi.mocked(getSessionLabel).mockReturnValue('Hello');

    await renderMeridiaIQ();

    const stored = JSON.parse(
      localStorage.getItem('meridia-iq-groups') ?? '[]',
    ) as ChatGroupEntry[];
    expect(stored).toHaveLength(1);
  });
});

/* ------------------------------------------------------------------ */
/* Session fetching — v2                                                */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — v2 session fetching', () => {
  beforeEach(() => {
    localStorage.setItem('meridia-iq-version', 'v2');
  });

  it('calls getMara2Sessions with the user id when version is v2', async () => {
    await renderMeridiaIQ();
    expect(getMara2Sessions).toHaveBeenCalledWith('user-42');
  });

  it('buckets today\'s chats under "Today"', async () => {
    vi.mocked(getMara2Sessions).mockResolvedValue(makeV2Data());

    const { result } = await renderMeridiaIQ();

    const today = result.current.groups.find((g) => g.label === 'Today');
    expect(today).toBeDefined();
    expect(today!.sessions[0]).toMatchObject({
      id: 'chat-1',
      title: 'Hello from chat 1',
    });
  });

  it('buckets old chats under "Older"', async () => {
    const oldTimestamp = Math.floor(new Date('2000-01-01').getTime() / 1000);
    vi.mocked(getMara2Sessions).mockResolvedValue(
      makeV2Data({ timestamp: String(oldTimestamp) }),
    );

    const { result } = await renderMeridiaIQ();

    const older = result.current.groups.find((g) => g.label === 'Older');
    expect(older).toBeDefined();
  });

  it('falls back to "Untitled" when content is null', async () => {
    vi.mocked(getMara2Sessions).mockResolvedValue(
      makeV2Data({ content: undefined }),
    );

    const { result } = await renderMeridiaIQ();

    const today = result.current.groups.find((g) => g.label === 'Today');
    expect(today!.sessions[0].title).toBe('Untitled');
  });

  it('filters out empty buckets', async () => {
    vi.mocked(getMara2Sessions).mockResolvedValue({} as V2ChatData);

    const { result } = await renderMeridiaIQ();

    expect(result.current.groups).toHaveLength(0);
  });

  it('buckets both chats into "Today" when both timestamps are recent', async () => {
    const now = Math.floor(Date.now() / 1000);
    vi.mocked(getMara2Sessions).mockResolvedValue({
      'chat-old': { timestamp: String(now - 60), content: 'Old' },
      'chat-new': { timestamp: String(now), content: 'New' },
    } satisfies V2ChatData);

    const { result } = await renderMeridiaIQ();

    const today = result.current.groups.find((g) => g.label === 'Today');
    expect(today).toBeDefined();
    const ids = today!.sessions.map((s) => s.id);
    expect(ids).toContain('chat-new');
    expect(ids).toContain('chat-old');
  });

  it('uses current time when chat has no timestamp', async () => {
    vi.mocked(getMara2Sessions).mockResolvedValue({
      'chat-no-ts': { content: 'No timestamp' },
    } satisfies V2ChatData);

    const { result } = await renderMeridiaIQ();

    const today = result.current.groups.find((g) => g.label === 'Today');
    expect(today).toBeDefined();
  });
});

/* ------------------------------------------------------------------ */
/* localStorage persistence                                             */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — localStorage persistence', () => {
  it('writes version to localStorage when setVersion is called', async () => {
    const { result } = await renderMeridiaIQ();

    await act(async () => {
      result.current.setVersion('v2');
    });

    expect(localStorage.getItem('meridia-iq-version')).toBe('v2');
  });

  it('persists groups to localStorage when rawGroups changes', async () => {
    localStorage.setItem('meridia-iq-version', 'v1');
    vi.mocked(getPreviousSessions).mockResolvedValue(makeV1Data());
    vi.mocked(groupSessions).mockReturnValue({
      Today: [
        {
          session_id: 'session-1',
          timestamp: Math.floor(
            new Date('2024-01-01T12:00:00Z').getTime() / 1000,
          ),
          content: 'Hello',
          role: 'user',
          messageType: 'query',
        },
      ],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });
    vi.mocked(getSessionLabel).mockReturnValue('Hello');

    await renderMeridiaIQ();

    const raw = localStorage.getItem('meridia-iq-groups');
    expect(raw).not.toBeNull();
    const parsed = JSON.parse(raw!) as ChatGroupEntry[];
    expect(parsed[0].label).toBe('Today');
  });
});

/* ------------------------------------------------------------------ */
/* groups derived value (useMemo)                                       */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — groups value', () => {
  it('returns rawGroups as-is', async () => {
    // No user → fetchAndSetGroups early-returns, so localStorage groups
    // are not overwritten by an empty API response.
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);
    const stored: ChatGroupEntry[] = [
      { label: 'Today', sessions: [{ id: 'x', title: 'X' }] },
    ];
    localStorage.setItem('meridia-iq-groups', JSON.stringify(stored));

    const { result } = await renderMeridiaIQ();

    expect(result.current.groups).toEqual(stored);
  });
});

/* ------------------------------------------------------------------ */
/* Ref-backed callbacks                                                 */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — ref-backed callbacks', () => {
  it('onNewChat invokes the registered handler', async () => {
    const { result } = await renderMeridiaIQ();
    const handler = vi.fn();

    act(() => result.current.setOnNewChat(handler));
    act(() => {
      result.current.onNewChat();
    });

    expect(handler).toHaveBeenCalledTimes(1);
  });

  it('onSelectChat invokes the registered handler with the id', async () => {
    const { result } = await renderMeridiaIQ();
    const handler = vi.fn();

    act(() => result.current.setOnSelectChat(handler));
    act(() => {
      result.current.onSelectChat('session-abc');
    });

    expect(handler).toHaveBeenCalledWith('session-abc');
  });

  it('onDeleteChat invokes the registered handler with the id and title', async () => {
    const { result } = await renderMeridiaIQ();
    const handler = vi.fn();

    act(() => result.current.setOnDeleteChat(handler));
    await act(async () => {
      await result.current.onDeleteChat('session-xyz', 'Test Title');
    });

    expect(handler).toHaveBeenCalledWith('session-xyz', 'Test Title');
  });

  it('onNewChat is a no-op before any handler is registered', async () => {
    const { result } = await renderMeridiaIQ();
    expect(() => {
      act(() => {
        result.current.onNewChat();
      });
    }).not.toThrow();
  });

  it('onSelectChat is a no-op before any handler is registered', async () => {
    const { result } = await renderMeridiaIQ();
    expect(() => {
      act(() => {
        result.current.onSelectChat('x');
      });
    }).not.toThrow();
  });

  it('onDeleteChat is a no-op before any handler is registered', async () => {
    const { result } = await renderMeridiaIQ();
    await expect(
      act(async () => {
        await result.current.onDeleteChat('x', 'Title');
      }),
    ).resolves.not.toThrow();
  });

  it('replaces the handler when setOnNewChat is called a second time', async () => {
    const { result } = await renderMeridiaIQ();
    const first = vi.fn();
    const second = vi.fn();

    act(() => result.current.setOnNewChat(first));
    act(() => result.current.setOnNewChat(second));
    act(() => {
      result.current.onNewChat();
    });

    expect(first).not.toHaveBeenCalled();
    expect(second).toHaveBeenCalledTimes(1);
  });
});

/* ------------------------------------------------------------------ */
/* State setters                                                        */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — state setters', () => {
  it('setVersion updates the version', async () => {
    const { result } = await renderMeridiaIQ();

    await act(async () => {
      result.current.setVersion('v2');
    });

    expect(result.current.version).toBe('v2');
  });

  it('setActiveSessionId updates the activeSessionId', async () => {
    const { result } = await renderMeridiaIQ();

    await act(async () => {
      result.current.setActiveSessionId('abc');
    });

    expect(result.current.activeSessionId).toBe('abc');
  });

  it('setNewSessionId updates the newSessionId', async () => {
    const { result } = await renderMeridiaIQ();

    await act(async () => {
      result.current.setNewSessionId('new-123');
    });

    expect(result.current.newSessionId).toBe('new-123');
  });

  it('setIsLoading updates the isLoading flag', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);

    const { result } = await renderMeridiaIQ();

    await act(async () => {
      result.current.setIsLoading(true);
    });

    expect(result.current.isLoading).toBe(true);
  });

  it('setGroups replaces rawGroups', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: null } as unknown as ReturnType<
      typeof useAuth
    >);

    const { result } = await renderMeridiaIQ();
    const newGroups: ChatGroupEntry[] = [
      { label: 'Today', sessions: [{ id: 'z', title: 'Z' }] },
    ];

    await act(async () => {
      result.current.setGroups(newGroups);
    });

    expect(result.current.groups).toEqual(newGroups);
  });
});

/* ------------------------------------------------------------------ */
/* refreshSessions                                                      */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — refreshSessions', () => {
  it('re-fetches v1 sessions', async () => {
    localStorage.setItem('meridia-iq-version', 'v1');
    vi.mocked(getPreviousSessions).mockResolvedValue({} as V1SessionData);
    vi.mocked(groupSessions).mockReturnValue({
      Today: [],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });

    const { result } = await renderMeridiaIQ();

    expect(getPreviousSessions).toHaveBeenCalledTimes(1);

    await act(async () => {
      result.current.refreshSessions();
    });

    await waitFor(() => expect(getPreviousSessions).toHaveBeenCalledTimes(2));
  });

  it('re-fetches v2 sessions', async () => {
    localStorage.setItem('meridia-iq-version', 'v2');
    vi.mocked(getMara2Sessions).mockResolvedValue({} as V2ChatData);

    const { result } = await renderMeridiaIQ();

    expect(getMara2Sessions).toHaveBeenCalledTimes(1);

    await act(async () => {
      result.current.refreshSessions();
    });

    await waitFor(() => expect(getMara2Sessions).toHaveBeenCalledTimes(2));
  });

  it('uses the current version when refreshing after a version change', async () => {
    localStorage.setItem('meridia-iq-version', 'v1');
    vi.mocked(getPreviousSessions).mockResolvedValue({} as V1SessionData);
    vi.mocked(groupSessions).mockReturnValue({
      Today: [],
      'Last 7 Days': [],
      'Last 30 Days': [],
      Older: [],
    });

    const { result } = await renderMeridiaIQ();
    expect(getPreviousSessions).toHaveBeenCalledTimes(1);

    await act(async () => {
      result.current.setVersion('v2');
    });
    await waitFor(() => expect(getMara2Sessions).toHaveBeenCalledTimes(1));

    await act(async () => {
      result.current.refreshSessions();
    });
    await waitFor(() => expect(getMara2Sessions).toHaveBeenCalledTimes(2));
  });
});

/* ------------------------------------------------------------------ */
/* Children rendering                                                   */
/* ------------------------------------------------------------------ */

describe('MeridiaIQProvider — children', () => {
  it('renders its children', async () => {
    await act(async () => {
      render(
        <MeridiaIQProvider>
          <span data-testid="child">hello</span>
        </MeridiaIQProvider>,
      );
    });
    expect(screen.getByTestId('child')).toBeInTheDocument();
  });
});
