import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import FlowbiteWrapper from '@/app/providers/FlowbiteWrapper';

interface MockFlowbiteProps {
  children: React.ReactNode;
  theme?: unknown;
  [key: string]: unknown;
}

const mockFlowbite = vi.fn(({ children }: MockFlowbiteProps) => (
  <div data-testid="flowbite-mock">{children}</div>
));

vi.mock('flowbite-react', () => ({
  Flowbite: (props: MockFlowbiteProps) => mockFlowbite(props),
}));

vi.mock('@/app/config/flowbite-theme', () => ({
  default: { testTheme: true },
}));

function mockMatchMedia(prefersDark: boolean) {
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: vi.fn().mockReturnValue({
      matches: prefersDark,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    }),
  });
}

beforeEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
  mockMatchMedia(false); // default: prefers light
});

describe('FlowbiteWrapper', () => {
  it('passes light mode to Flowbite by default', () => {
    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child</div>
      </FlowbiteWrapper>,
    );

    const passedProps = mockFlowbite.mock.calls[0][0];
    const theme = passedProps.theme as { mode: string };
    expect(theme.mode).toBe('light');
  });

  it('passes dark mode to Flowbite when theme in localStorage is "dark"', () => {
    localStorage.setItem('theme', 'dark');

    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child</div>
      </FlowbiteWrapper>,
    );

    const passedProps = mockFlowbite.mock.calls[0][0];
    const theme = passedProps.theme as { mode: string; theme: unknown };
    expect(theme.mode).toBe('dark');
    expect(theme.theme).toEqual({ testTheme: true });
  });

  it('resolves "system" to "light" when system preference is light', () => {
    mockMatchMedia(false);
    localStorage.setItem('theme', 'system');

    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child</div>
      </FlowbiteWrapper>,
    );

    const passedProps = mockFlowbite.mock.calls[0][0];
    const theme = passedProps.theme as { mode: string; theme: unknown };
    expect(theme.mode).toBe('light');
    expect(theme.theme).toEqual({ testTheme: true });
  });

  it('resolves "system" to "dark" when system preference is dark', () => {
    mockMatchMedia(true);
    localStorage.setItem('theme', 'system');

    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child</div>
      </FlowbiteWrapper>,
    );

    const passedProps = mockFlowbite.mock.calls[0][0];
    const theme = passedProps.theme as { mode: string; theme: unknown };
    expect(theme.mode).toBe('dark');
    expect(theme.theme).toEqual({ testTheme: true });
  });

  it('prefers theme-preview over theme and resolves "system" via matchMedia', () => {
    mockMatchMedia(true); // system → dark
    localStorage.setItem('theme', 'dark');
    localStorage.setItem('theme-preview', 'system');

    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child</div>
      </FlowbiteWrapper>,
    );

    const passedProps = mockFlowbite.mock.calls[0][0];
    const theme = passedProps.theme as { mode: string; theme: unknown };
    expect(theme.mode).toBe('dark'); // 'system' resolved via matchMedia(true)
    expect(theme.theme).toEqual({ testTheme: true });
  });

  it('renders its children', () => {
    render(
      <FlowbiteWrapper>
        <div data-testid="child">Child content</div>
      </FlowbiteWrapper>,
    );

    expect(screen.getByTestId('child')).toBeInTheDocument();
  });
});
