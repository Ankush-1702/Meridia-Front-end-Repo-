import { render, screen, fireEvent, act } from '@testing-library/react';
import { useLocation } from 'react-router-dom';
import { describe, it, expect, vi, beforeEach, afterEach, Mock } from 'vitest';
import { KEEP_LOGGED_IN_KEY } from '@/app/constants/constants';
import { TimeoutProvider } from '@/app/providers/TimeoutProvider';
import { useAuth } from '@/features/auth/context/AuthContext';

vi.mock('react-router-dom', () => ({
  useLocation: vi.fn(),
}));

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: vi.fn(),
}));

describe('TimeoutProvider', () => {
  const mockUseLocation = useLocation as Mock;
  const mockUseAuth = useAuth as Mock;
  const ONE_HOUR = 3600000;
  let mockLogout: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();

    mockLogout = vi.fn();
    mockUseAuth.mockReturnValue({ logout: mockLogout });

    Object.defineProperty(window, 'localStorage', {
      value: {
        clear: vi.fn(),
        getItem: vi.fn().mockReturnValue(null), // keepLoggedIn = false
        setItem: vi.fn(),
        removeItem: vi.fn(),
      },
      writable: true,
    });
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('renders children correctly', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    render(
      <TimeoutProvider>
        <h1>Application Content</h1>
      </TimeoutProvider>,
    );

    expect(
      screen.getByRole('heading', { name: /application content/i }),
    ).toBeInTheDocument();
  });

  it('logs out the user after 1 hour of inactivity', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR);
    });

    expect(mockLogout).toHaveBeenCalledTimes(1);
    expect(mockLogout).toHaveBeenCalledWith(true);
  });

  it('resets the timer on window events (e.g., mousemove)', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR - 100000);
    });

    expect(mockLogout).not.toHaveBeenCalled();

    fireEvent.mouseMove(window);

    act(() => {
      vi.advanceTimersByTime(1200000); // 20 mins
    });

    expect(mockLogout).not.toHaveBeenCalled();

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR);
    });

    expect(mockLogout).toHaveBeenCalledTimes(1);
    expect(mockLogout).toHaveBeenCalledWith(true);
  });

  it('does not trigger timeout on exempted routes (/login)', () => {
    mockUseLocation.mockReturnValue({ pathname: '/login' });

    render(
      <TimeoutProvider>
        <div>Login Page</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR + 1000);
    });

    expect(mockLogout).not.toHaveBeenCalled();
  });

  it('does not trigger timeout on exempted routes (/reset-password)', () => {
    mockUseLocation.mockReturnValue({ pathname: '/reset-password' });

    render(
      <TimeoutProvider>
        <div>Reset Password</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR + 1000);
    });

    expect(mockLogout).not.toHaveBeenCalled();
  });

  it('cleans up event listeners when unmounted', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });
    const removeEventListenerSpy = vi.spyOn(window, 'removeEventListener');

    const { unmount } = render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    unmount();

    expect(removeEventListenerSpy).toHaveBeenCalledWith(
      'mousemove',
      expect.any(Function),
    );
    expect(removeEventListenerSpy).toHaveBeenCalledWith(
      'keydown',
      expect.any(Function),
    );
    expect(removeEventListenerSpy).toHaveBeenCalledWith(
      'click',
      expect.any(Function),
    );
    expect(removeEventListenerSpy).toHaveBeenCalledWith(
      'scroll',
      expect.any(Function),
    );
  });

  it('resets timer on keydown and click events as well', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    act(() => vi.advanceTimersByTime(ONE_HOUR - 100));
    fireEvent.keyDown(window);
    act(() => vi.advanceTimersByTime(1000));
    expect(mockLogout).not.toHaveBeenCalled();

    act(() => vi.advanceTimersByTime(ONE_HOUR - 2000));
    fireEvent.click(window);
    act(() => vi.advanceTimersByTime(3000));
    expect(mockLogout).not.toHaveBeenCalled();
  });

  it('does not trigger timeout when keepLoggedIn is true', () => {
    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    // Override getItem to return 'true' for keepLoggedIn
    window.localStorage.getItem = vi.fn().mockReturnValue('true');

    render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR + 1000);
    });

    expect(mockLogout).not.toHaveBeenCalled();
  });

  it('re-reads keepLoggedIn inside the effect — not stale from initial mount', () => {
    // This is the regression guard for the stale-closure bug:
    // keepLoggedIn used to be read once at component-render scope and then
    // captured forever by the effect closure. After logout clears localStorage,
    // the stale 'true' value would permanently disable the inactivity timer
    // for the new session.

    mockUseLocation.mockReturnValue({ pathname: '/dashboard' });

    // First render: keepLoggedIn is true → timer should NOT fire
    window.localStorage.getItem = vi.fn().mockReturnValue('true'); // all keys return 'true' initially

    const { rerender } = render(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    act(() => {
      vi.advanceTimersByTime(ONE_HOUR + 1000);
    });
    expect(mockLogout).not.toHaveBeenCalled();

    // Simulate logout: keepLoggedIn is now cleared from storage
    window.localStorage.getItem = vi.fn().mockImplementation((key: string) => {
      if (key === KEEP_LOGGED_IN_KEY) return null; // cleared after logout
      return null;
    });

    // Simulate a route change (e.g. navigating within the app after new login)
    // This causes the effect to re-run and re-read keepLoggedIn
    mockUseLocation.mockReturnValue({ pathname: '/vessels' });
    rerender(
      <TimeoutProvider>
        <div>Child</div>
      </TimeoutProvider>,
    );

    // Now the timer should be active and fire after 1 hour
    act(() => {
      vi.advanceTimersByTime(ONE_HOUR + 1000);
    });
    expect(mockLogout).toHaveBeenCalledTimes(1);
    expect(mockLogout).toHaveBeenCalledWith(true);
  });
});
