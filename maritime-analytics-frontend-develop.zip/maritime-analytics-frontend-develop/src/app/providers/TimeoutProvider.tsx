import { ReactNode, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

import { KEEP_LOGGED_IN_KEY } from '@/app/constants/constants';
import { useAuth } from '@/features/auth/context/AuthContext';

export function TimeoutProvider({ children }: { children: ReactNode }) {
  const { logout } = useAuth();
  const location = useLocation();
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const exemptedRoutes = ['/login', '/reset-password'];
    // Read inside the effect so the value is always fresh — not captured once
    // at mount and then stale for the lifetime of the component.
    const keepLoggedIn = localStorage.getItem(KEEP_LOGGED_IN_KEY) === 'true';
    if (exemptedRoutes.includes(location.pathname) || keepLoggedIn) return;

    const handleWindowEvents = () => {
      clearTimeout(timeoutRef.current);

      timeoutRef.current = setTimeout(() => {
        sessionStorage.setItem(
          'toastMessage',
          'Your session has expired. Please log in again.',
        );
        logout(true);
      }, 3600000);
    };

    // listen for specific window events to ensure user is still active
    window.addEventListener('mousemove', handleWindowEvents);
    window.addEventListener('keydown', handleWindowEvents);
    window.addEventListener('click', handleWindowEvents);
    window.addEventListener('scroll', handleWindowEvents);

    handleWindowEvents();

    return () => {
      clearTimeout(timeoutRef.current);
      window.removeEventListener('mousemove', handleWindowEvents);
      window.removeEventListener('keydown', handleWindowEvents);
      window.removeEventListener('click', handleWindowEvents);
      window.removeEventListener('scroll', handleWindowEvents);
    };
  }, [location.pathname, logout]);

  return children;
}
