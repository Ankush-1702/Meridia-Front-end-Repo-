import classNames from 'classnames';
import { FC, PropsWithChildren, useState } from 'react';
import { FaAnchor, FaGlobe, FaShip, FaVectorSquare } from 'react-icons/fa6';
import { HiSearch } from 'react-icons/hi';
import { HiPencilSquare } from 'react-icons/hi2';
import { Outlet } from 'react-router';
import SideBar from '@/app/components/SideBar';
import { useAuth } from '@/features/auth/context/AuthContext';
import MeridiaLogo from '@/shared/assets/MeridiaLogo';
import { NotificationsMenu } from '@/shared/components/NotificationsMenu';

interface AppLayoutProps {
  isFooter?: boolean;
}

const AppLayout: FC<PropsWithChildren<AppLayoutProps>> = () => {
  const { user, logout, userGroups } = useAuth();
  const [expanded, setExpanded] = useState(() => {
    const stored = localStorage.getItem('sidebarExpanded');
    return stored !== null ? JSON.parse(stored) : true;
  });

  const toggleExpanded = (value: boolean) => {
    setExpanded(value);
    localStorage.setItem('sidebarExpanded', JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('sidebarToggle', { detail: value }));
  };

  const logo = MeridiaLogo;
  const optionalItems = [
    {
      label: 'Search',
      icon: HiSearch,
      show:
        userGroups.includes('meridia') ||
        userGroups.includes('maritime-analytics'),
      color: 'text-psg-orange-700',
    },
  ];

  const notifications = [
    {
      label: 'Notifications',
      icon: NotificationsMenu,
      show:
        userGroups.includes('meridia') ||
        userGroups.includes('maritime-analytics'),
      href: '/analytics/notifications',
      color: 'text-psg-orange-700',
    },
  ];

  const primaryItems = [
    {
      label: 'Fleets',
      href: '/analytics/library?tab=Fleets',
      icon: FaGlobe,
      show: userGroups.includes('fleet-management'),
      color: 'text-psg-orange-700',
    },
    {
      label: 'Vessels',
      href: '/analytics/library?tab=Vessels',
      icon: FaShip,
      show:
        userGroups.includes('meridia') ||
        userGroups.includes('maritime-analytics'),
      color: 'text-psg-orange-700',
    },
    {
      label: 'Ports',
      href: '/analytics/library?tab=Ports',
      icon: FaAnchor,
      show:
        userGroups.includes('meridia') ||
        userGroups.includes('maritime-analytics'),
      color: 'text-psg-orange-700',
    },
    {
      label: 'Zones',
      href: '/analytics/library?tab=Zones',
      icon: FaVectorSquare,
      show:
        userGroups.includes('meridia') ||
        userGroups.includes('maritime-analytics'),
      color: 'text-psg-orange-700',
    },
    {
      label: 'New Chat',
      href: '/analytics/chats',
      icon: HiPencilSquare,
      show: userGroups.includes('meridia-iq') || userGroups.includes('mara'),
      color: 'text-psg-orange-700',
    },
  ];

  return (
    <div className="flex items-start bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100">
      {/* Sidebar Component */}
      <SideBar
        title="Meridia"
        logo={logo}
        primaryItems={primaryItems}
        optionalItems={optionalItems}
        notifications={notifications}
        user={{
          name:
            `${user?.first_name ?? ''} ${user?.last_name ?? ''}`.trim() ||
            'User',
          email: user?.email || '',
          avatar:
            `${user?.first_name?.charAt(0) ?? ''}${user?.last_name?.charAt(0) ?? ''}`.toUpperCase(),
        }}
        onSignOut={logout}
        expanded={expanded}
        setExpanded={toggleExpanded}
      />
      {/* Main Content */}
      <main
        className={classNames(
          'overflow-x-hidden overflow-y-hidden relative w-full h-full transition-all duration-300',
          `${expanded ? 'ml-[240px]' : 'ml-12'}`,
        )}
      >
        <Outlet />
      </main>
    </div>
  );
};

export default AppLayout;
