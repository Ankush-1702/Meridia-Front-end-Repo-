import { render, screen } from '@testing-library/react';
import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import AppLayout from '@/app/layouts/AppLayout';

// ─── Mocks ────────────────────────────────────────────────────────────────────

const mockLogout = vi.fn();
const mockUserGroups: string[] = [
  'meridia',
  'meridia-iq',
  'maritime-analytics',
  'mara',
  'fleet-management',
];

vi.mock('@/features/auth/context/AuthContext', () => ({
  useAuth: () => ({
    user: {
      first_name: 'John',
      last_name: 'Doe',
      email: 'john@example.com',
    },
    userGroups: mockUserGroups,
    logout: mockLogout,
  }),
}));

const mockSideBar = vi.fn();

interface SideBarUser {
  name: string;
  email: string;
  avatar: string;
}

interface SideBarItem {
  label: string;
  href?: string;
  show: boolean;
  color?: string;
  icon: React.ElementType;
}

interface SideBarProps {
  title: string;
  logo: React.ElementType;
  onSignOut: () => void;
  user: SideBarUser;
  primaryItems: SideBarItem[];
  optionalItems: SideBarItem[];
  notifications: SideBarItem[];
  expanded: boolean;
  setExpanded: (value: boolean) => void;
}

vi.mock('@/app/components/SideBar', () => ({
  __esModule: true,
  default: (props: SideBarProps) => {
    mockSideBar(props);
    return <div data-testid="mock-sidebar">Sidebar</div>;
  },
}));

vi.mock('react-router', () => ({
  Outlet: () => <div data-testid="outlet">Outlet Content</div>,
}));

vi.mock('@/shared/assets/MeridiaLogo', () => ({
  __esModule: true,
  default: () => <div data-testid="logo">Logo</div>,
}));

vi.mock('@/shared/components/NotificationsMenu', () => ({
  NotificationsMenu: () => <div>NotifIcon</div>,
}));

// ─── Setup ────────────────────────────────────────────────────────────────────

const DEFAULT_USER_GROUPS = [
  'meridia',
  'meridia-iq',
  'maritime-analytics',
  'mara',
  'fleet-management',
];

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.clear();
  mockUserGroups.length = 0;
  mockUserGroups.push(...DEFAULT_USER_GROUPS);
});

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('AppLayout', () => {
  it('renders the layout with sidebar and outlet', () => {
    render(<AppLayout />);
    expect(screen.getByTestId('mock-sidebar')).toBeInTheDocument();
    expect(screen.getByTestId('outlet')).toBeInTheDocument();
  });

  it('passes correct props to SideBar', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;

    expect(props.title).toBe('Meridia');
    expect(props.logo).toBeDefined();
    expect(props.onSignOut).toBe(mockLogout);

    expect(props.user).toEqual({
      name: 'John Doe',
      email: 'john@example.com',
      avatar: 'JD',
    });
  });

  it('includes correct primaryItems based on userGroups', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    const { primaryItems } = props;

    expect(primaryItems).toHaveLength(5);

    expect(primaryItems[0]).toMatchObject({
      label: 'Fleets',
      href: '/analytics/library?tab=Fleets',
      show: true,
      color: 'text-psg-orange-700',
    });

    expect(primaryItems[1]).toMatchObject({
      label: 'Vessels',
      href: '/analytics/library?tab=Vessels',
      show: true,
      color: 'text-psg-orange-700',
    });
    expect(primaryItems[2]).toMatchObject({
      label: 'Ports',
      href: '/analytics/library?tab=Ports',
      show: true,
      color: 'text-psg-orange-700',
    });
    expect(primaryItems[3]).toMatchObject({
      label: 'Zones',
      href: '/analytics/library?tab=Zones',
      show: true,
      color: 'text-psg-orange-700',
    });
    expect(primaryItems[4]).toMatchObject({
      label: 'New Chat',
      href: '/analytics/chats',
      show: true,
      color: 'text-psg-orange-700',
    });
  });

  it('hides the Fleets nav item when userGroups lacks fleet-management', () => {
    mockUserGroups.length = 0;
    mockUserGroups.push('meridia', 'meridia-iq', 'maritime-analytics', 'mara');

    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    const { primaryItems } = props;

    expect(primaryItems[0]).toMatchObject({
      label: 'Fleets',
      href: '/analytics/library?tab=Fleets',
      show: false,
      color: 'text-psg-orange-700',
    });
  });

  it('includes correct optionalItems based on userGroups', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    const { optionalItems } = props;

    expect(optionalItems).toHaveLength(1);
    expect(optionalItems[0]).toMatchObject({
      label: 'Search',
      show: true,
      color: 'text-psg-orange-700',
    });
  });

  it('includes notifications items based on userGroups', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    const { notifications } = props;

    expect(notifications).toHaveLength(1);
    expect(notifications[0]).toMatchObject({
      label: 'Notifications',
      href: '/analytics/notifications',
      show: true,
      color: 'text-psg-orange-700',
    });
  });

  // ── Expanded state (default: true) ──────────────────────

  it('applies ml-[240px] when sidebar is expanded by default', () => {
    render(<AppLayout />);
    const main = screen.getByRole('main');

    expect(main).toHaveClass('ml-[240px]');
    expect(main).not.toHaveClass('ml-[56px]');
  });

  it('applies ml-12 when localStorage has sidebarExpanded=false', () => {
    localStorage.setItem('sidebarExpanded', JSON.stringify(false));
    render(<AppLayout />);
    const main = screen.getByRole('main');

    expect(main).toHaveClass('ml-12');
    expect(main).not.toHaveClass('ml-[240px]');
  });

  it('passes expanded=true to SideBar by default', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    expect(props.expanded).toBe(true);
  });

  it('passes expanded=false when localStorage has sidebarExpanded=false', () => {
    localStorage.setItem('sidebarExpanded', JSON.stringify(false));
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;
    expect(props.expanded).toBe(false);
  });

  // ── Toggle sidebar ─────────────────────────────────────

  it('toggles expanded state and persists to localStorage', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;

    // Simulate sidebar calling setExpanded(false)
    const dispatchSpy = vi.spyOn(window, 'dispatchEvent');
    props.setExpanded(false);

    expect(localStorage.getItem('sidebarExpanded')).toBe('false');
    expect(dispatchSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'sidebarToggle',
        detail: false,
      }),
    );
    dispatchSpy.mockRestore();
  });

  it('dispatches sidebarToggle custom event when toggled', () => {
    render(<AppLayout />);
    const props = mockSideBar.mock.calls[0][0] as SideBarProps;

    const dispatchSpy = vi.spyOn(window, 'dispatchEvent');
    props.setExpanded(true);

    expect(dispatchSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'sidebarToggle',
        detail: true,
      }),
    );
    dispatchSpy.mockRestore();
  });
});
