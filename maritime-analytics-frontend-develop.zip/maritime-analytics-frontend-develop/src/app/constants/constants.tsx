export const ACCESS_TOKEN_KEY = 'access_token';
export const REFRESH_TOKEN_KEY = 'refresh_token';
export const USER_DETAILS_KEY = 'user';
export const TIME_ZONE_KEY = 'time_zone';
export const INBOUND_VESSEL_TIMEFRAME_KEY = 'inboundVesselsTimeFrame';
export const KEEP_LOGGED_IN_KEY = 'keepLoggedIn';
