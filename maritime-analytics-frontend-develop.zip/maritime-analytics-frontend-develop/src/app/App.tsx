import { BrowserRouter as Router } from 'react-router-dom';
import ErrorBoundary from '@/app/components/ErrorBoundary';
import { MeridiaIQProvider } from '@/app/providers/MeridiaIQProvider';
import { TimeoutProvider } from '@/app/providers/TimeoutProvider';
import AppRoutes from '@/app/routes/AppRoutes';
import { AuthProvider } from '@/features/auth/context/AuthContext';
import LibraryProvider from '@/features/library/context/LibraryContext';
import { NotifStompProvider } from '@/features/Notifications/Context/NotificationsStompContext';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <TimeoutProvider>
          <LibraryProvider>
            <MeridiaIQProvider>
              <NotifStompProvider>
                <ErrorBoundary>
                  <AppRoutes />
                </ErrorBoundary>
              </NotifStompProvider>
            </MeridiaIQProvider>
          </LibraryProvider>
        </TimeoutProvider>
      </Router>
    </AuthProvider>
  );
}
