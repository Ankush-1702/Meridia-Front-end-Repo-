import { renderHook, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useApiErrorHandler } from '@/app/hooks/useApiErrorHandler';

// ---------------------------
// Mock useToastNotification
// ---------------------------
const mockShowToast = vi.fn();

vi.mock('@/shared/lib/PoleStarNotification', () => ({
  useToastNotification: () => ({
    showToast: mockShowToast,
  }),
}));

beforeEach(() => {
  vi.clearAllMocks();
});

function createMockResponse(
  body: unknown,
  status = 400,
  statusText = 'Bad Request',
) {
  const jsonString = JSON.stringify(body);

  const response = new Response(jsonString, {
    status,
    statusText,
    headers: { 'Content-Type': 'application/json' },
  });

  // Patch clone() so it returns the same mocked response
  vi.spyOn(response, 'clone').mockImplementation(() => response);

  return response;
}

describe('useApiErrorHandler', () => {
  it('handles Response error with valid ErrorResponse JSON', async () => {
    const mockError = createMockResponse({
      status: 400,
      detail: 'Invalid request',
    });

    const { result } = renderHook(() => useApiErrorHandler());

    await act(async () => {
      await result.current(mockError);
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'Invalid request',
      5000,
    );
  });

  it('handles Response error with invalid JSON shape', async () => {
    const mockError = createMockResponse({
      message: 'Something else',
    });

    const { result } = renderHook(() => useApiErrorHandler());

    await act(async () => {
      await result.current(mockError);
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'An unknown error occurred',
      5000,
    );
  });

  it('handles Response.error where json() fails (invalid JSON)', async () => {
    // Create a real Response (so instanceof Response passes)
    const realResponse = new Response('invalid json', {
      status: 500,
      statusText: 'Server Error',
    });

    // Override clone()
    vi.spyOn(realResponse, 'clone').mockReturnValue(realResponse);

    // Force json() to throw
    vi.spyOn(realResponse, 'json').mockRejectedValue(new Error('bad json'));

    const { result } = renderHook(() => useApiErrorHandler());

    await act(async () => {
      await result.current(realResponse);
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'HTTP 500: Server Error',
      5000,
    );
  });

  it('handles native Error objects', async () => {
    const mockError = new Error('Something went wrong');

    const { result } = renderHook(() => useApiErrorHandler());

    await act(async () => {
      await result.current(mockError);
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'Something went wrong',
      5000,
    );
  });

  it('handles unknown error types', async () => {
    const mockError = null;

    const { result } = renderHook(() => useApiErrorHandler());

    await act(async () => {
      await result.current(mockError);
    });

    expect(mockShowToast).toHaveBeenCalledWith(
      'error',
      'Please check your internet connection and try again.',
      5000,
    );
  });
});
