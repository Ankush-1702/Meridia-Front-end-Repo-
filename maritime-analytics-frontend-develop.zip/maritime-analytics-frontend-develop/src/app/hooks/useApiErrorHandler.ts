import { useCallback } from 'react';
import { useToastNotification } from '@/shared/lib/PoleStarNotification';

export interface ErrorResponse {
  status: number;
  field: string;
  title: string;
  detail: string;
  resource_uri: string;
  documentation: string;
  request_id: string;
  timestamp: string;
}

export const useApiErrorHandler = () => {
  const { showToast } = useToastNotification();

  return useCallback(
    async (error: unknown) => {
      const isFetchResponse = (err: unknown): err is Response =>
        err instanceof Response;

      if (isFetchResponse(error)) {
        try {
          const data = await error.clone().json(); // attempt to parse JSON body

          const isErrorResponse = (data: unknown): data is ErrorResponse => {
            return (
              typeof data === 'object' &&
              data !== null &&
              'status' in data &&
              typeof (data as ErrorResponse).status === 'number' &&
              'detail' in data &&
              typeof (data as ErrorResponse).detail === 'string'
            );
          };

          if (isErrorResponse(data)) {
            showToast('error', data.detail, 5000);
          } else {
            showToast('error', 'An unknown error occurred', 5000);
          }
        } catch {
          showToast('error', `HTTP ${error.status}: ${error.statusText}`, 5000);
        }
      } else if (error instanceof Error) {
        showToast('error', error.message, 5000);
      } else {
        showToast(
          'error',
          'Please check your internet connection and try again.',
          5000,
        );
      }
    },
    [showToast],
  );
};
