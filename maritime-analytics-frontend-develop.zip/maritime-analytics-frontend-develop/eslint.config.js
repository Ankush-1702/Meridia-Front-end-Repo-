import js from '@eslint/js'; // Base ESLint rules for JavaScript
import eslintConfigPrettier from 'eslint-config-prettier';
import importPlugin from 'eslint-plugin-import'; // Manage and lint import/export statements
import jsxA11y from 'eslint-plugin-jsx-a11y'; // Accessibility rules for JSX
import prettierPlugin from 'eslint-plugin-prettier'; // Integrate Prettier formatting into ESLint
import reactHooks from 'eslint-plugin-react-hooks'; // Plugin for React Hooks rules
import reactRefresh from 'eslint-plugin-react-refresh'; // Plugin for React Fast Refresh rules
import tailwindcss from 'eslint-plugin-tailwindcss'; // Validate TailwindCSS classnames
import globals from 'globals'; // Common global variables (e.g., window, document)
import tseslint from 'typescript-eslint'; // TypeScript-specific rules and configurations

export default tseslint.config(
  {
    // Ignore specific directories or files to avoid unnecessary linting
    ignores: ['dist', 'node_modules', 'coverage'],
  },
  {
    // Extend recommended configurations
    extends: [
      js.configs.recommended, // Base JavaScript rules
      ...tseslint.configs.recommended, // TypeScript-specific recommended rules
      eslintConfigPrettier, // Prettier integration
    ],

    // Define applicable files for this configuration
    files: ['**/*.{ts,tsx}'], // Apply to all TypeScript and TSX files

    // Language options
    languageOptions: {
      ecmaVersion: 2020, // Enable modern JavaScript features
      globals: globals.browser, // Define browser-specific global variables
    },

    // Define plugins
    plugins: {
      'react-hooks': reactHooks, // React Hooks linting rules
      'react-refresh': reactRefresh, // Ensure Fast Refresh compatibility
      'jsx-a11y': jsxA11y, // Enforce accessibility rules in JSX
      import: importPlugin, // Manage and validate ES module imports
      tailwindcss: tailwindcss, // Validate TailwindCSS classnames
      prettier: prettierPlugin, // Integrate Prettier into linting
    },

    // Define linting rules
    rules: {
      // React Hooks rules (e.g., dependency arrays, lifecycle issues)
      ...reactHooks.configs.recommended.rules,

      // Accessibility rules for JSX
      ...jsxA11y.configs.recommended.rules,

      // Import management rules
      'import/order': [
        'error',
        {
          groups: [
            'builtin', // Built-in Node.js modules (e.g., `fs`, `path`)
            'external', // External libraries (e.g., `react`, `lodash`)
            'internal', // Internal project modules
            'parent', // Parent directory imports
            'sibling', // Sibling file imports
            'index', // Index file imports (e.g., `index.ts`)
          ],
          alphabetize: { order: 'asc', caseInsensitive: true }, // Sort imports alphabetically
        },
      ],

      // TailwindCSS rules
      'tailwindcss/classnames-order': 'error', // Enforce proper class order in TailwindCSS

      'tailwindcss/no-custom-classname': [
        'warn',
        {
          whitelist: [
            'ag-theme-alpine',
            'ag-theme-alpine-dark',
            '^fi$',
            '^fi-$',
          ],
        },
      ],
      // Prettier integration
      'prettier/prettier': 'error', // Enforce Prettier formatting as lint errors
    },
  },
);
